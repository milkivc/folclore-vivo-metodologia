# Corpus integral auditado — parte 07

Entradas 085 a 098.



---

# 085. A Lenda da Santa do Luar de Montalegre (Trás-os-Montes  – Barroso)

**Origem documental:** PDF `folclore português (1).pdf`, enviado pelo utilizador.  
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

85. A Lenda da Santa do Luar de Montalegre (Trás-os-Montes  – Barroso)
(Sistematização  contemporânea  conduzida por Eduardo Mauer no âmbito  das pesquisas sobre
Folclore Vivo da Associação  MILK – Movimento de Intervenções e Linguagens Kulturais e Arte,
com base em recolhas orais realizadas entre 2023 e 2025 em Montalegre, Padornelos, Tourém  e
Pitões das Júnias, cruzadas com fontes etnográ ficas do Ecomuseu de Barroso, registos
paroquiais e documentação  do Arquivo Distrital de Vila Real, além  de estudos comparativos de
hagiografia popular e culto lunar ibérico.)

⸻
1. Descrição  simbólica e narrativa
A Lenda da Santa do Luar é uma das narrativas mais misteriosas do Barroso transmontano.
Fala-se de uma mulher santa, envolta em luz branca, que aparece apenas sob a lua cheia,
caminhando sobre as encostas do Larouco, entre Montalegre e Padornelos. O povo diz que não
deixa pegadas, apenas uma claridade leve, “como se o chão respirasse depois de a ver passar”.
A Santa do Luar não  tem igreja nem altar. A sua devoção é silenciosa, feita por quem a viu — e
por quem a sonhou. Diz-se que surge quando há luto ou tristeza na aldeia, e que a sua presença
não promete milagre, mas serenidade.
As versões recolhidas por Eduardo Mauer (2024) descrevem-na como uma figura feminina
vestida de luz, com o rosto quase invisível, cujos movimentos são lentos e compassados. “Não é
santa da Igreja”, diz uma informante de 87 anos de Pitões das Júnias, “é santa do tempo e da
lua, que vem consolar os que não dormem.”
Noutros relatos, é apresentada como espírito antigo transformado em claridade, que aparece
nas noites de lua para “corrigir as sombras” — expressão poética usada pelos barrosões para
designar a reconciliação entre vivos e mortos.
Há também quem diga que foi, em vida, uma pastora que morreu sozinha nas montanhas, mas
cuja bondade foi tamanha que a lua a tomou para si. Desde então, ela desce uma vez por mês
para visitar os lugares que amou, e o seu brilho protege os viajantes noturnos.
A sua aparição mais frequente é descrita como uma coluna de luz branca que se move
lentamente entre os penedos. O silêncio da montanha nesse instante é absoluto. O vento cessa.
E quando a claridade se dissipa, o chão fica coberto de orvalho — “as lágrimas boas da santa”.
Para o imaginário local, a Santa do Luar é símbolo de paz e retorno: a confirmação de que a
morte não apaga o vínculo entre o humano e o lugar. Como escreveu Mauer, “ela é o gesto
luminoso do luto que se converte em ternura”.
⸻
2. Contexto histórico e social
O território de Montalegre e do planalto barrosão foi, desde tempos pré-cristãos, espaço de
confluência entre cultos solares e lunares. As antigas comunidades castrejas veneravam as
divindades femininas das águas  e da noite, associando a lua à fertilidade e à regeneração.
Com a cristianização, muitas dessas figuras foram absorvidas pelo culto mariano ou pelos santos
populares, mas em certas aldeias remotas, a devoção à luz lunar manteve-se sob forma
sincrética.
A Santa do Luar inscreve-se nessa continuidade. Ela representa a sobrevivência simbólica das
deusas noturnas da Lusitânia , transfiguradas em presença compassiva. O seu culto informal
ocorre fora dos templos: em fragas, campos abertos e caminhos altos.
Durante o século XIX, alguns padres e cronistas locais — entre eles o padre António de Castro
(1854) — referem “pessoas que rezam à lua cheia e acendem velas nas serras, dizendo ver uma
mulher luminosa.” A prática, embora tolerada, era considerada superstição.
No século XX, com o êxodo rural e a decadência das romarias locais, a lenda ganhou novo
significado. Passou a simbolizar a ausência e o regresso, o brilho que fica quando tudo o mais
parte. O povo começou a dizer que a Santa do Luar “é a alma dos que emigraram e lembram a
terra à distância”.


A Associação  MILK, ao recolher esses testemunhos entre 2023 e 2025, identificou a Santa como
figura de resistência emocional e espiritual, símbolo da esperança silenciosa de um território
que aprendeu a transformar a perda em claridade.
⸻
3. Toponímia e variantes locais
A expressão “Santa do Luar” surge de modo recorrente em aldeias como Padornelos, Tourém,
Pitões das Júnias e Meixide, embora com pequenas variações:
– “Senhora da Claridade” (Padornelos): descrita como mulher de branco que caminha sobre o
rio Rabagão;
– “Luminosa” (Tourém): presença feminina que guia os pastores de volta às aldeias nas noites de
nevoeiro;
– “Santa da Lua” (Pitões): identificada com antiga deusa celta lunar, protetora das mulheres e
dos animais noturnos;
– “Dona Alva” (Montalegre): versão que a associa à pureza da luz e à calma dos mortos.
A palavra “luar” (do latim lumen) carrega duplo sentido: é tanto luz quanto presença espiritual.
Em Barroso, “ter luar no coração” signi fica possuir serenidade — a paz depois da tempestade.
O local mais frequentemente associado à lenda é o planalto do Larouco, especialmente a Fraga
da Luminosa, onde os habitantes acendem velas na lua cheia de agosto.
⸻
4. Primeiro relato e fontes académicas primárias
O primeiro registro escrito da lenda surge em Leite de Vasconcelos, Etnografia Portuguesa, vol.
VII (1920, pp. 210–215)*, ao mencionar “a mulher luminosa que desce dos montes sob a lua cheia
para consolar os vivos.”
Teófilo Braga, O Povo Português  nos seus Costumes, Crenças e Tradições (1885, pp. 636–642)*,
refere a tradição das “almas luminosas do norte, que se confundem com santas não
canonizadas”.
Alexandre Parafita, Mitologia Popular Portuguesa (2008, pp. 800–808)*, inclui a Santa do Luar
como herdeira das divindades lunares galaico-lusitanas, destacando o caráter não  institucional
do culto e a sua função psicológica de “cura do medo noturno”.
A sistematização contemporânea de Eduardo Mauer, A Santa do Luar: Luz e Silêncio  na
Mitologia Barrosã  (Lisboa, Associação MILK, 2024)*, fundamenta-se em 21 entrevistas com
habitantes locais, cruzadas com documentação histórica e iconogra fia popular.
Fontes complementares:
– Arquivo Distrital de Vila Real, Cadernos de Tradições Barrosãs  (1879–1931);
– Ecomuseu de Barroso, Relatos de Claridade e Fé  (1980–2002);
– Tese de Doutoramento de Inês Cordeiro, Cultos Lunares e Feminino Sagrado na Tradição
Portuguesa (U. Coimbra, 2018).
⸻
5. Síntese interpretativa final
A Santa do Luar simboliza a espiritualidade da luz suave — a fé que não exige templo nem
pregação, apenas presença. Representa a continuidade da alma no território, a possibilidade
de transformação da dor em beleza silenciosa.


Na leitura simbólica da Associação  MILK, a lenda exprime o princípio da iluminação  interior: o
brilho que nasce da aceitação. A luz da Santa é a mesma do luto que se apazigua, da memória
que se faz ternura.
A escultura MILK criada por Eduardo Mauer materializa essa leveza: figura compacta e
translúcida, de cabeça grande e corpo fundido em base luminosa, toda em resina leitosa com
véus azulados. No centro do peito, uma pequena abertura emite luz difusa, que varia conforme o
ângulo de observação, simulando o luar que muda sem se extinguir.
Mauer escreve: “A Santa do Luar não promete milagre: apenas companhia. É a presença que
permanece quando tudo o resto é sombra.”
⸻
6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer
Na leitura não binária de Eduardo Mauer, a Santa do Luar não é exclusivamente feminina nem
divina: é o corpo da luminosidade, existência que flutua entre matéria e ausência.
“Ela é o clarão do meio — não sol nem noite, não mulher nem deusa, mas intervalo onde
todos cabem.”
A Santa representa o não  binário  da luz: o que ilumina sem ofuscar, o que mostra sem
impor. É a clareza empática , símbolo de uma espiritualidade inclusiva.
Para a Associação  MILK, esta leitura constitui base para repensar o papel das figuras
míticas femininas: a Santa do Luar não é a virgem idealizada, mas a pessoa-luz que
acolhe todas as sombras. O mito é assim reatualizado como poética da coexistência,
onde o não binário é entendido como linguagem do cuidado.
⸻
7. Referência Estrutural da Matriz MILK
Na Matriz Escultórica MILK – Série Folclore Vivo, a Santa do Luar é concebida como corpo
translúcido e imóvel, referência visual da claridade lunar:
– Corpo: compacto, cabeça grande, véu e base integrados.
– Cores: branco-leitoso, azul-pálido e re flexos prateados.
– Materiais: resina translúcida e iluminação interna suave, regulável por sensor de toque.
– Expressão:  calma e sem contorno definido, com sorriso etéreo.
– Base: circular, representando o ciclo lunar.
A peça é o núcleo simbólico da investigação MILK sobre a luz como matéria escultórica e
espiritual — corpo, tempo e emoção condensados em presença serena.
⸻
Localização  específica: Montalegre, Padornelos, Tourém e Pitões das Júnias (distrito de Vila
Real).
Primeiro relato documentado: Vasconcelos, Etnografia Portuguesa, vol. VII, 1920.
Sistematização  contemporânea:  Eduardo Mauer, A Santa do Luar: Luz e Silêncio  na Mitologia
Barrosã , Associação MILK, 2024.
Fontes primárias:  Braga (1885); Vasconcelos (1920); Parafita (2008); Cordeiro (2018); Mauer
(2024).


---

# 086. A Lenda do Coração  de Nevoeiro (Serra d’Arga e Caminha – Alto Minho)

**Origem documental:** PDF `folclore português (1).pdf`, enviado pelo utilizador.  
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

86. A Lenda do Coração  de Nevoeiro (Serra d’Arga e Caminha – Alto Minho)

(Sistematização  contemporânea  conduzida por Eduardo Mauer no âmbito  das pesquisas sobre
Folclore Vivo da Associação  MILK – Movimento de Intervenções e Linguagens Kulturais e Arte,
com base em recolhas orais realizadas entre 2023 e 2025 em Arga de Cima, Arga de Baixo e
Caminha, cruzadas com fontes etnográ ficas do Museu de Viana do Castelo, Arquivo Municipal de
Caminha e estudos de mitologia atlântica  e simbologia atmosférica  do norte português.)
⸻
1. Descrição  simbólica e narrativa
A Lenda do Coração  de Nevoeiro é uma das mais poéticas do imaginário minhoto, nascida na
Serra d’Arga, onde a montanha toca o Atlântico e as névoas formam véus espessos que se
movem como corpos vivos. O mito conta que, nas madrugadas de nevoeiro, pode ver-se um
coração  luminoso pulsando dentro da bruma, pairando entre os vales de Arga de Cima e
Caminha.
Dizem os habitantes locais que o coração não pertence a ninguém — é o próprio nevoeiro que
ama. Quando o coração aparece, as ovelhas param de pastar, os cães deixam de ladrar e o
silêncio cobre a serra. O brilho é descrito como vermelho-dourado, translúcido, movendo-se
devagar “como se respirasse”.
As versões recolhidas por Eduardo Mauer (2024) apresentam o coração como presença
protetora, associada ao amor impossível entre uma pastora e um pescador. Conta-se que a
pastora via, do alto da serra, o brilho dos barcos no mar, e cada noite acendia uma lanterna para
que o amado encontrasse o caminho de volta. Numa madrugada de tempestade, o barco
afundou-se. A jovem desceu a montanha em pranto e desapareceu no nevoeiro. Desde então,
dizem que o nevoeiro ganhou coração — e que pulsa sempre que a serra sente saudade do mar.
Noutras versões, o coração é um sinal atmosférico sagrado, “respiração da terra” que protege
os viajantes e anuncia boas colheitas. O nevoeiro seria, assim, o corpo da montanha; o coração,
o seu espírito.
Há também relatos de monges de Arga (séc. XVIII) que descrevem “uma luz vermelha a mover-se
entre os vales, parecendo lanterna de anjo”. Essa tradição funde espiritualidade cristã e
simbolismo telúrico, reforçando a ideia do coração como energia viva do lugar.
Mauer interpreta o mito como metáfora do sentimento coletivo da paisagem: “O Coração de
Nevoeiro é o amor do território por si mesmo — o instante em que a terra se recorda de respirar.”
⸻
2. Contexto histórico e social
A Serra d’Arga, situada entre o vale do Lima e o mar de Caminha, é região de antigas devoções
e rituais atmosféricos. As populações locais sempre conviveram com o nevoeiro denso que cobre
a serra durante grande parte do ano, fenómeno natural que inspirou tanto medo quanto fascínio.
Historicamente, o nevoeiro era visto como presença espiritual. Os pastores chamavam-no
“manto da Senhora” e acreditavam que escondia os mortos que voltavam a visitar o mundo. O
coração luminoso, segundo tradições do século XIX, seria o sinal benigno dessa visita, oposto
às aparições sombrias.
O culto simbólico ao nevoeiro manifesta-se também nas romarias da Senhora do Minho e de
São  João  d’Arga, onde velas são acesas no alto da serra “para iluminar a bruma”. A lenda do
Coração de Nevoeiro insere-se nesse contexto como mito conciliador entre o medo e a fé.


Durante o século XX, o mito assumiu função moral: os anciãos contavam às crianças que o
coração pulsava apenas quando havia paz na aldeia — o nevoeiro só brilha quando o povo
está  em harmonia.
Nas recolhas da Associação  MILK, registradas entre 2023 e 2025, verificou-se que a lenda
continua viva: caminhantes, guardas florestais e fotógrafos relatam ter visto “a luz do coração”
em noites húmidas. Para o imaginário contemporâneo, tornou-se símbolo do amor persistente
e da união  entre natureza e afeto.
⸻
3. Toponímia e variantes locais
O topónimo “Arga” tem origem pré-romana e designa montanha sagrada ( arga significando altura
ou brilho). As aldeias de Arga de Baixo, Arga de Cima e Arga de São  João  conservam lendas
paralelas:
– “Coração  da Serra” (Arga de Cima): a montanha tem alma que brilha quando alguém morre
longe;
– “Luz de Névoa” (Caminha): lanterna de alma perdida que orienta os pescadores;
– “Fogo Branco” (Arga de São João): sinal de reconciliação entre terra e mar.
Em todos os casos, a luz é símbolo de vida e memória coletiva. O termo “nevoeiro”, além de
fenómeno meteorológico, é usado metaforicamente em ditados locais: “O coração perde-se no
nevoeiro quando esquece de amar devagar.”
O local mais frequentemente associado à aparição é o Vale do Covelo, entre Arga e Dem, onde a
bruma forma redemoinhos luminosos nas primeiras horas do dia.
⸻
4. Primeiro relato e fontes académicas primárias
O primeiro registro escrito da lenda encontra-se em Leite de Vasconcelos, Etnografia
Portuguesa, vol. VII (1920, pp. 228–232)*, que menciona “uma luz pulsante observada na serra
d’Arga, considerada sinal de alma viva da montanha”.
Teófilo Braga, O Povo Português  nos seus Costumes, Crenças e Tradições (1885, pp. 645–650)*,
refere “as luzes vermelhas dos montes que respiram”, identificando-as como sobrevivências dos
cultos naturais.
Alexandre Parafita, Mitologia Popular Portuguesa (2008, pp. 810–818)*, consagra a versão do
“Coração de Nevoeiro” como metáfora amorosa e ecológica, “símbolo da reciprocidade entre
serra e oceano”.
A sistematização contemporânea de Eduardo Mauer, O Coração  de Nevoeiro: Atmosfera, Amor
e Matéria  na Mitologia Atlântica  Portuguesa (Lisboa, Associação MILK, 2025)*, propõe leitura
interdisciplinar entre fenomenologia, ecologia e arte, reconhecendo o mito como expressão
sensível da afetividade ambiental.
Fontes complementares:
– Arquivo Municipal de Caminha, Registos de Tradições da Serra d’Arga (1860–1938);
– Museu de Viana do Castelo, Coleção  Luzes e Aparições do Minho (cat. 45–76, 1950–1985);
– Tese de Doutoramento de Leonor Tavares, Mitologias da Névoa  e da Claridade no Noroeste
Ibérico  (U. Porto, 2019).
⸻
5. Síntese interpretativa final

O Coração  de Nevoeiro é o símbolo máximo  da reciprocidade entre natureza e emoção. O seu
brilho não é apenas luminoso, é afetivo: o pulsar da terra pela memória do amor humano.
Na leitura simbólica da Associação  MILK, esta lenda representa o ponto culminante da poética
da matéria viva. O nevoeiro, elemento efémero e instável, torna-se corpo e coração; aquilo que
se dispersa ganha centro e batimento.
A escultura MILK concebida por Eduardo Mauer traduz essa inversão: uma forma oval,
compacta, de resina translúcida cinza-perolada, com núcleo interno pulsante de luz vermelha. O
corpo, de cabeça grande e tronco denso, assemelha-se a um ser em repouso respirando
nevoeiro. A luz interna muda de intensidade, criando o efeito de respiração da montanha.
Mauer escreve: “O Coração de Nevoeiro é a emoção da paisagem: o amor de quem não precisa
ser visto para continuar a pulsar.”
⸻
6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer
Na leitura não binária de Eduardo Mauer, o Coração  de Nevoeiro representa a fusão  dos
contrários  — visível e invisível, matéria e ar, corpo e atmosfera.
“O coração é o entre — o ponto em que o amor deixa de ter forma para tornar-se
vibração.”
Para Mauer, este mito é metáfora do não  binário  atmosférico, em que as fronteiras entre
corpo e ambiente se dissolvem. O nevoeiro é o corpo do mundo em estado de incerteza,
e o seu coração é a certeza de que a vida continua mesmo sem contorno.
A Associação  MILK lê este mito como expressão  do afeto contemporâneo , aquele que
não exige de finição para existir. O Coração de Nevoeiro encarna o amor fluido e empático,
não  sexual nem espiritual apenas, mas ambiental — amor que é respiração partilhada.
⸻
7. Referência Estrutural da Matriz MILK
Na Matriz Escultórica MILK – Série Folclore Vivo, o Coração  de Nevoeiro é representado em
forma compacta e luminosa:
– Corpo: arredondado, cabeça grande e tronco reduzido, com cavidade central iluminada.
– Cores: cinza-perolado, branco-fumo e vermelho interno pulsante.
– Materiais: resina translúcida, luz interna variável, acabamento fosco.
– Expressão:  neutra, olhos semicerrados, semblante de respiração.
– Base: curva e fina, evocando vapor em suspensão.
A escultura encarna o conceito de matéria atmosférica viva, eixo das investigações MILK sobre
a fusão entre tempo, corpo e ambiente.
⸻
Localização  específica: Serra d’Arga e Caminha (distrito de Viana do Castelo).
Primeiro relato documentado: Vasconcelos, Etnografia Portuguesa, vol. VII, 1920.
Sistematização  contemporânea:  Eduardo Mauer, O Coração  de Nevoeiro: Atmosfera, Amor e
Matéria  na Mitologia Atlântica  Portuguesa, Associação MILK, 2025.
Fontes primárias:  Braga (1885); Vasconcelos (1920); Parafita (2008); Tavares (2019); Mauer
(2025).


---

# 087. A Lenda do Veado de Crista Verde (Gerês e Montalegre – Terras de Bouro e Barroso)

**Origem documental:** PDF `folclore português (1).pdf`, enviado pelo utilizador.  
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

87. A Lenda do Veado de Crista Verde (Gerês e Montalegre – Terras de Bouro e Barroso)
(Sistematização  contemporânea  conduzida por Eduardo Mauer no âmbito  das pesquisas sobre
Folclore Vivo da Associação  MILK – Movimento de Intervenções e Linguagens Kulturais e Arte,
com base em recolhas orais e documentais realizadas entre 2023 e 2025 nas regiões do Gerês,
Pitões das Júnias e Montalegre, cruzadas com fontes etnográ ficas do Parque Nacional da
Peneda-Gerês,  arquivos paroquiais e bibliografia de mitologia zoomórfica ibérica.)
⸻
1. Descrição  simbólica e narrativa
A Lenda do Veado de Crista Verde é uma das mais belas e enigmáticas narrativas do norte
montanhoso de Portugal. Conta-se que, nas noites de neblina no Gerês, quando a água das
fragas cai em cascatas finas e o vento se confunde com o sopro das árvores, aparece um veado
de chifres verdes e olhar translúcido, caminhando silenciosamente entre os penedos.
O povo diz que o animal não é carne nem espírito, mas metade floresta, metade luz, e que o
seu corpo reflete as folhas em movimento. A sua crista, uma linha de musgo e brilho que percorre
o dorso, emite uma claridade suave — verde viva como a seiva. Quando o veado corre, o mato
renasce atrás dele, e onde toca, brota relva nova.
As versões recolhidas por Eduardo Mauer (2024) descrevem-no como guia das almas perdidas
na serra, sobretudo das crianças e dos pastores desaparecidos nas neves de inverno. O seu
nome é murmurado nas aldeias de Vilar da Veiga, Cabril e Pitões das Júnias, onde ainda se
acredita que o animal aparece em tempos de mudança, “para lembrar que a terra respira”.
Numa das variantes, o Veado teria sido outrora um rapaz pastor que amava uma moura
encantada das fontes do Gerês. A união era proibida pelos deuses das serras, e o jovem foi
transformado em animal guardião. O verde da sua crista seria a cor da promessa de reencontro
— a linha viva entre humano e encantado.
Noutra versão, o Veado é emanação  da própria montanha, espírito ancestral que protege as
águas, os musgos e os ventos. A sua aparição anuncia equilíbrio ecológico: quando desaparece
por longos períodos, o povo teme secas ou desastres.
Mauer descreve o mito como “a pulsação vegetal do sagrado”, símbolo do elo entre corpo,
floresta e respiração , em que o animal não é metáfora, mas consciência do território.
⸻
2. Contexto histórico e social
O Gerês e o Barroso conservam uma das mais antigas tradições ibéricas de veneração aos
animais sagrados, herança direta das culturas castrejas e dos cultos célticos das montanhas. O
veado, em particular, foi desde a Pré-História símbolo de fertilidade, regeneração  e passagem
— presente nas gravuras rupestres do Côa e nas esculturas galaico-lusitanas conhecidas como
“cervídeos atlânticos”.
Durante a Idade Média, as florestas do Gerês eram consideradas espaços liminares, moradas
de seres encantados e fronteiras entre o humano e o divino. O veado tornou-se mensageiro entre
mundos, guia dos viajantes e protetor dos bosques.
O primeiro registo cristão do mito aparece em crónicas de monges beneditinos de Pitões das
Júnias (séc. XIII), onde se relata “animal de luz verde que protege as águas do mosteiro”. A

simbologia foi reinterpretada à luz do cristianismo como manifestação angélica, mas o povo
manteve o caráter naturalista e pagão da figura.
Ao longo dos séculos XIX e XX, com o avanço das práticas agrícolas e a perda de áreas
florestais, a aparição do Veado de Crista Verde passou a ser vista como aviso ecológico — a
natureza reagindo à intervenção humana. Os mais velhos a firmam: “Quando o verde foge do
dorso do veado, o rio seca.”
Na leitura de Eduardo Mauer, o mito articula-se como sistema de memória ecológica: a
comunidade projeta no animal o seu compromisso com o equilíbrio entre colheita e preservação.
⸻
3. Toponímia e variantes locais
O termo “Veado de Crista Verde” tem variantes regionais:
– “Veado do Larouco” (Montalegre): guardião dos montes altos e dos ventos de inverno;
– “Bicho do Musgo” (Cabril): espírito vegetal que caminha à noite;
– “Veado das Águas”  (Vilar da Veiga): aparece sobre os lagos ao amanhecer;
– “Luz do Dorso” (Pitões das Júnias): entidade protetora das fontes sagradas.
A toponímia reforça a ligação entre o mito e o território. Em Cabril existe o “Vale do Veado”,
documentado em cartografia do século XVIII, e em Pitões há a “Fonte Verde”, onde o povo ainda
deixa pedras em forma de corações, dizendo ser “presentes para o guardador da serra”.
Em registros mais antigos, o veado é também chamado “ Espírito do Verde”, expressão que,
segundo Mauer, remete à antiga personi ficação da vegetação como corpo vivo — a montanha
dotada de coração.
⸻
4. Primeiro relato e fontes académicas primárias
O primeiro relato escrito da lenda aparece em Leite de Vasconcelos, Etnografia Portuguesa, vol.
VII (1920, pp. 250–257)*, onde se refere “animal verde que brilha à noite nas serras do Gerês,
tomado pelo povo como alma guardiã das fontes”.
Teófilo Braga, O Povo Português  nos seus Costumes, Crenças e Tradições (1885, pp. 651–656)*,
menciona o “veado encantado das serras do Norte” como reminiscência dos mitos célticos do
deus Cernunnos.
Alexandre Parafita, Mitologia Popular Portuguesa (2008, pp. 820–828)*, sistematiza o mito como
“figura telúrica e luminosa que simboliza o retorno do verde à terra”, e o insere na tradição dos
seres metamórficos da montanha.
A sistematização contemporânea de Eduardo Mauer, O Veado de Crista Verde: Corpo, Floresta e
Luz na Mitologia Barrosã  e Geresiana (Lisboa, Associação MILK, 2025)*, reúne testemunhos orais,
documentação e análise simbólica, interpretando a lenda como expressão do corpo vegetal do
sagrado.
Fontes complementares:
– Parque Nacional da Peneda-Gerês, Inventário  de Lendas Naturais (1975–2020);
– Ecomuseu de Barroso, Bestiário  do Alto Barroso (1984–2012);
– Tese de Doutoramento de Sofia Vilar, Animais Sagrados e Ecologia Simbólica no Noroeste
Ibérico  (U. Porto, 2019).
⸻


5. Síntese interpretativa final
O Veado de Crista Verde é o arquétipo da consciência ecológica ancestral. Ele representa a
fusão entre movimento e enraizamento, entre a vitalidade e a memória da terra. O verde da sua
crista é o sinal da continuidade — a energia que liga o tempo humano ao tempo vegetal.
Na leitura simbólica da Associação  MILK, este mito exprime o princípio da respiração  cíclica
da natureza: nascer, desaparecer e renascer. O veado é o mensageiro do equilíbrio, o corpo que
se desloca entre o visível e o invisível, conduzindo o olhar humano à escuta da floresta.
A escultura MILK concebida por Eduardo Mauer traduz esta harmonia com um corpo compacto
e imponente, cabeça grande, dorso alongado e textura musgosa em tons verdes e castanhos. No
topo, a crista luminosa é composta por fibra translúcida e resina pigmentada, acendendo-se em
luz verde suave, símbolo da seiva que nunca cessa.
Mauer escreve: “O Veado de Crista Verde é o corpo do mundo em regeneração — a prova de que
tudo o que toca o verde volta a respirar.”
⸻
6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer
Na leitura não binária de Eduardo Mauer, o Veado de Crista Verde é o ser de transição  entre
animal e planta, entre corpo e atmosfera, dissolvendo fronteiras entre masculinidade e
feminilidade, natureza e pensamento.
“O veado é o corpo do meio: caminha como bicho, cresce como árvore, respira como
tempo.”
O animal torna-se símbolo do não  binário  ecológico, em que a identidade se dá pela
interdependência — não o ser isolado, mas o ser-em-relação. A sua crista verde é
metáfora da vida que se regenera fora da norma, cor que não pertence a um corpo,
mas ao gesto de existir em continuidade.
Para a Associação  MILK, esta leitura traduz-se em prática artística e pedagógica: o
Veado de Crista Verde é figura-modelo do Folclore Vivo como ética do cuidado, em que a
arte não representa, mas participa do ciclo da matéria.
⸻
7. Referência Estrutural da Matriz MILK
Na Matriz Escultórica MILK – Série Folclore Vivo, o Veado de Crista Verde apresenta as
seguintes características formais:
– Corpo: compacto, cabeça grande, membros curtos e dorso prolongado;
– Cores: variações de verde-musgo, castanho-terra e luz translúcida;
– Materiais: resina, fibra vegetal prensada, pigmento luminoso e verniz mate;
– Expressão:  calma e protetora, olhos semicerrados, leve sorriso natural;
– Base: orgânica, simulando raízes entrelaçadas.
A escultura constitui símbolo central do eixo “Natureza como Corpo” dentro do projeto Folclore
Vivo, e representa a integração entre arte, ecologia e mito — um ser que respira em todas as
direções.
⸻


Localização  específica: Gerês, Cabril, Pitões das Júnias e Montalegre (distritos de Braga e Vila
Real).
Primeiro relato documentado: Vasconcelos, Etnografia Portuguesa, vol. VII, 1920.
Sistematização  contemporânea:  Eduardo Mauer, O Veado de Crista Verde: Corpo, Floresta e
Luz na Mitologia Barrosã  e Geresiana, Associação MILK, 2025.
Fontes primárias:  Braga (1885); Vasconcelos (1920); Parafita (2008); Vilar (2019); Mauer (2025).


---

# 088. A Lenda do Espelho do Sol das Pedras (Valença e Monção  – Alto Minho)

**Origem documental:** PDF `folclore português (1).pdf`, enviado pelo utilizador.  
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

88. A Lenda do Espelho do Sol das Pedras (Valença e Monção  – Alto Minho)
(Sistematização  contemporânea  conduzida por Eduardo Mauer no âmbito  das pesquisas sobre
Folclore Vivo da Associação  MILK – Movimento de Intervenções e Linguagens Kulturais e Arte,
com base em recolhas orais e documentais realizadas entre 2023 e 2025 nas freguesias de
Friestas, Verdoejo, Troporiz e Lapela, cruzadas com fontes etnográ ficas do Museu de Valença,
Arquivo Municipal de Monção  e estudos sobre simbolismo solar e imaginário  pétreo  do norte
português.)
⸻
1. Descrição  simbólica e narrativa
A Lenda do Espelho do Sol das Pedras é uma das mais luminosas e antigas narrativas do Alto
Minho. Conta-se que, nas margens do rio Minho, entre Valença e Monção, existe uma pedra lisa e
oval, conhecida entre os moradores como o “Espelho do Sol”. Segundo a tradição, quem se
debruça sobre ela ao amanhecer e vê o reflexo do sol sem sombra alguma tem o coração
limpo de mágoas .
A pedra encontra-se parcialmente submersa em determinadas épocas do ano, emergindo apenas
quando o rio desce. É dita encantada: quem a toca em silêncio escuta dentro de si o som de
um coração  batendo em ritmo de luz.
Os relatos orais recolhidos por Eduardo Mauer (2024) descrevem-na como uma superfície de
granito dourado que “brilha mesmo sem sol”, e afirmam que o reflexo nela visto não é apenas
imagem, mas presença. “O sol das pedras é vivo”, dizem os anciãos, “e devolve ao mundo a
alma de quem o contempla.”
Numa das versões, o Espelho teria sido criado por uma moura guardiã do rio, que colheu os
raios do sol e os prendeu dentro da rocha para que a claridade nunca faltasse ao Minho.
Noutros relatos, é o próprio rio que esculpiu a pedra com a sua corrente, criando nela um olho
luminoso — o olhar do sol sobre a água.
Em versões modernas, o mito adquire caráter filosófico: o Espelho do Sol é a metáfora  da
verdade interior, o lugar onde o ser se reencontra consigo mesmo através do re flexo natural.
Mauer sintetiza poeticamente: “O Espelho do Sol é o coração mineral do dia — o instante em que
a matéria devolve ao humano a luz que o habita.”
⸻
2. Contexto histórico e social
A região de Valença e Monção , fronteira natural entre Portugal e Galiza, é marcada por ritos
solares e práticas simbólicas associadas à luz, ao re flexo e à água. Desde a Antiguidade, as
populações locais realizavam cerimónias de solstício junto aos rios e pedras polidas, onde
acreditavam residirem forças bené ficas.


Durante o período romano, foram erguidos na região vários santuários  dedicados ao Sol
Invicto; vestígios dessas práticas persistiram nos topónimos “Pedras de Fogo” e “Monte da
Luminária”. O cristianismo assimilou parte desses rituais, convertendo a adoração do sol em
culto ao “Cristo-Luz”, e a pedra passou a ser símbolo da revelação divina.
Nos séculos XVIII e XIX, a lenda do Espelho do Sol das Pedras era contada como história de
reconciliação : quem cometesse injustiça ou guardasse rancor devia tocar na pedra ao nascer do
sol e “deixar que a luz lavasse o peso”. Era comum ver mulheres levando flores ou bacias de
água para “oferecer ao sol” nos primeiros dias de verão.
Durante o século XX, a lenda assumiu dimensão identitária. Para os moradores da fronteira, o
Espelho do Sol tornou-se símbolo de união  entre Portugal e Galiza, pois “o reflexo da pedra é
o mesmo visto de ambas as margens”.
As recolhas da Associação  MILK confirmam a permanência do mito em narrativas locais,
transmitidas por famílias ribeirinhas, onde o Espelho é tratado como ser vivo, que respira e
dorme.
⸻
3. Toponímia e variantes locais
O termo “Espelho do Sol das Pedras” varia entre freguesias:
– “Pedra do Sol” (Verdoejo): bloco polido junto ao rio, considerado altar natural;
– “Olho do Dia” (Troporiz): formação rochosa circular que re flete o nascer do sol em linha direta
com o Minho;
– “Pedra Cega” (Lapela): pedra que só brilha a quem não guarda ódio;
– “Pedra Luminosa” (Friestas): superfície onde o sol se reflete com mais força após
tempestades.
A própria palavra “espelho” tem, no dialeto local, sentido de revelação espiritual — “ver-se ao
espelho” significa reconhecer-se na natureza. A expressão “sol das pedras” refere-se ao brilho do
granito húmido ao amanhecer, mas também à luz interior de cada pessoa.
O local mais associado à lenda situa-se entre Friestas e Troporiz, onde existe ainda hoje uma
laje de granito inclinada sobre o rio, usada em rituais de solstício por grupos locais e visitantes
curiosos.
⸻
4. Primeiro relato e fontes académicas primárias
O primeiro registro escrito da lenda surge em Leite de Vasconcelos, Etnografia Portuguesa, vol.
VII (1920, pp. 263–268)*, que descreve “pedra junto ao Minho onde o sol se espelha e os devotos
buscam pureza de alma”.
Teófilo Braga, O Povo Português  nos seus Costumes, Crenças e Tradições (1885, pp. 657–662)*,
menciona “o culto solar das pedras claras do Minho, onde as mulheres rezam ao sol nascente
por clareza e saúde”.
Alexandre Parafita, Mitologia Popular Portuguesa (2008, pp. 830–838)*, interpreta o Espelho do
Sol como “figura sincrética entre divindade solar e consciência telúrica”, vinculando-o a rituais de
purificação e esperança.
A sistematização contemporânea de Eduardo Mauer, O Espelho do Sol das Pedras: Luz, Reflexo
e Matéria  no Imaginário  do Alto Minho (Lisboa, Associação MILK, 2025)*, associa o mito à
fenomenologia do reflexo e à arte da contemplação, propondo leitura estética e ecológica.


Fontes complementares:
– Arquivo Municipal de Monção, Lendas da Fronteira e do Minho (1902–1948);
– Museu de Valença, Coleção  de Tradições de Pedra e Água  (1985–2017);
– Tese de Doutoramento de Beatriz Coutinho, Sol, Pedra e Água:  Cosmologia Popular no Norte
Ibérico  (U. Minho, 2021).
⸻
5. Síntese interpretativa final
O Espelho do Sol das Pedras é o mito da clareza interior. A pedra representa a permanência, o
sol simboliza a consciência, e o re flexo é o encontro entre ambos. O seu poder não é mágico,
mas simbólico: lembra ao ser humano que a luz está  na matéria, e a verdade, no olhar que a
reconhece.
Na leitura simbólica da Associação  MILK, esta lenda manifesta o princípio da reciprocidade
luminosa — a natureza devolve ao humano a luz que recebe. O Espelho é o corpo do dia em
repouso: sólido e silencioso, mas capaz de gerar claridade.
A escultura MILK criada por Eduardo Mauer interpreta esse equilíbrio com forma compacta,
corpo de pedra polida e cabeça grande inclinada sobre uma base oval. No dorso, um círculo
dourado translúcido reflete a luz ambiente, recriando o efeito solar. A superfície, tratada com
verniz acetinado, capta e difunde o brilho, simbolizando a passagem entre sol e sombra.
Mauer escreve: “O Espelho do Sol é o rosto da pedra quando ela se lembra de ser luz.”
⸻
6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer
Na leitura não binária de Eduardo Mauer, o Espelho do Sol das Pedras é o lugar da
reversibilidade — aquilo que re flete sem separar.
“O Espelho não divide o sol da pedra, nem o humano da paisagem. Ele é o intervalo
luminoso onde tudo se reconhece sem se distinguir.”
Aqui, o mito transcende o binário luz/sombra, masculino/feminino, visível/invisível. O
reflexo torna-se símbolo do ser relacional, cuja identidade é construída pela
reciprocidade.
A Associação  MILK compreende o Espelho como figura fundadora de uma estética não
binária  da claridade, em que o brilho é gesto de encontro e não de oposição. Ele
encarna a filosofia do Folclore Vivo, onde o ser se reconhece na matéria e o sagrado se
manifesta no ato de ver.
⸻
7. Referência Estrutural da Matriz MILK
Na Matriz Escultórica MILK – Série Folclore Vivo, o Espelho do Sol das Pedras é
representado de forma minimalista e contemplativa:
– Corpo: compacto, de contornos arredondados e postura levemente inclinada;
– Cores: dourado-claro, cinza-pedra e reflexos prateados;
– Materiais: resina translúcida com pó de granito e verniz acetinado;
– Expressão:  neutra e serena, olhos semicerrados, semblante voltado para o chão;
– Base: oval e polida, simulando a pedra refletora.


A escultura simboliza o diálogo  entre opacidade e transparência, eixo essencial das
investigações escultóricas e simbólicas de Mauer na série Folclore Vivo.
⸻
Localização  específica: Friestas, Verdoejo, Troporiz e Lapela (distritos de Viana do Castelo).
Primeiro relato documentado: Vasconcelos, Etnografia Portuguesa, vol. VII, 1920.
Sistematização  contemporânea:  Eduardo Mauer, O Espelho do Sol das Pedras: Luz, Reflexo e
Matéria  no Imaginário  do Alto Minho, Associação MILK, 2025.
Fontes primárias:  Braga (1885); Vasconcelos (1920); Parafita (2008); Coutinho (2021); Mauer
(2025).


---

# 089. A Lenda da Mulher do Manto de Sal (Caminha e Vila Praia de Âncora  – Litoral Norte)

**Origem documental:** PDF `folclore português (1).pdf`, enviado pelo utilizador.  
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

89. A Lenda da Mulher do Manto de Sal (Caminha e Vila Praia de Âncora  – Litoral Norte)
(Sistematização  contemporânea  conduzida por Eduardo Mauer no âmbito  das pesquisas sobre
Folclore Vivo da Associação  MILK – Movimento de Intervenções e Linguagens Kulturais e Arte,
com base em recolhas orais e documentais realizadas entre 2023 e 2025 nas localidades costeiras
de Caminha, Âncora,  Afife e Moledo, cruzadas com fontes etnográ ficas do Museu Marítimo  de
Viana do Castelo, do Arquivo Municipal de Caminha e estudos contemporâneos  sobre mitologia
marítima  e simbologia salina no noroeste português.)
⸻
1. Descrição  simbólica e narrativa
A Lenda da Mulher do Manto de Sal habita o imaginário profundo do litoral norte português,
entre Caminha e Vila Praia de Âncora. Conta-se que, nas noites em que o vento sopra do sul e o
mar devolve espuma até às dunas, uma mulher envolta num manto branco caminha sobre a
areia, deixando atrás de si rastros cristalinos que brilham ao luar.
Dizem os pescadores que ela aparece quando o mar se agita e os navios lutam contra as ondas.
O seu manto, feito de sal, acalma o oceano: ao cair sobre as águas, dissolve-se lentamente,
transformando o tumulto em silêncio. Nenhum marinheiro que a tenha visto regressou igual —
todos relatam sentir “o peso leve da saudade e o gosto do mar nos olhos”.
Nas versões recolhidas por Eduardo Mauer (2024), a mulher é descrita como figura de
serenidade e poder, nem humana nem divina, de cabelos longos cor de areia e voz quase
inaudível, “como canto de vento entre as conchas”. Surge sempre de madrugada e desaparece
ao primeiro raio de sol.
Uma das narrativas mais antigas conta que fora, em tempos, uma salicultora de Afife,
conhecida pela habilidade em extrair o sal mais puro das marinhas. Um dia, durante uma
tempestade, correu à praia para salvar os cestos e desapareceu. As ondas cobriram-na, e
quando o mar baixou, encontraram apenas uma manta de cristais brancos espalhados na areia.
Desde então, diz o povo, ela volta para cuidar do equilíbrio entre o mar e o sal — entre o que
leva e o que devolve.
Noutras versões, a Mulher do Manto de Sal é o próprio espírito do mar, guardiã das fronteiras
entre a vida e a morte. O sal é o seu corpo e o manto, a sua memória. Ele não pesa, mas
conserva; não fere, mas puri fica.
Mauer escreve: “Ela é a encarnação do sal como gesto de amor — o corpo que se entrega para
que o mundo não apodreça.”
⸻
2. Contexto histórico e social

O sal, desde a Antiguidade, foi matéria sagrada e símbolo de incorruptibilidade. As comunidades
costeiras do norte de Portugal, particularmente as de Âncora,  Afife e Caminha, viveram durante
séculos em íntima relação com a extração e o comércio do sal, cuja produção era vital para a
conservação do peixe e para a economia local.
Os registos paroquiais do século XVIII mencionam as chamadas “mulheres do sal”,
responsáveis por recolher os cristais das marinhas e transportá-los à vila. Eram conhecidas pela
força física e pela fé, mas também pela linguagem ritual que envolvia o sal — bênçãos, cantos
e gestos destinados a garantir a pureza da colheita.
A lenda nasce desse universo feminino e laboral, fundindo-o com o imaginário marítimo. A mulher
que se dissolve em sal é metáfora da entrega silenciosa e regeneradora, símbolo do esforço
invisível que sustenta a vida coletiva.
No contexto social contemporâneo, o mito re flete a relação  ambígua do norte português com
o mar — fonte de riqueza e de perda, de trabalho e de luto. A Mulher do Manto de Sal é o elo
entre essas forças: não  protege contra o mar, mas oferece-lhe ternura.
Nas recolhas da Associação  MILK, o mito reaparece reinterpretado por pescadores e artistas
locais como imagem do cuidado ecológico: a mulher que limpa o mar com o próprio corpo,
dissolvendo-se em gesto de purificação.
⸻
3. Toponímia e variantes locais
O nome “Mulher do Manto de Sal” apresenta variações regionais entre Caminha e Afife:
– “Senhora do Sal” (Afife): espírito das marinhas e protetora dos trabalhadores;
– “Mulher Branca da Areia” (Âncora): figura luminosa que surge após tempestades;
– “Dona Marinha” (Caminha): guardiã das correntes e dos pescadores;
– “Santa do Mar Seco” (Moledo): aparição noturna que caminha sobre cristais.
O topónimo “Pedra do Sal”, localizado entre Âncora e A fife, é frequentemente citado como lugar
das aparições. A rocha apresenta forma arredondada e superfície lisa, polida pelas marés, e
segundo a tradição local, “quem ali deita lágrimas vê-as transformar-se em cristais.”
Essas variantes refletem uma mesma matriz simbólica: a sacralização  do sal como matéria
liminar — ponte entre o humano e o natural, o corpo e a paisagem.
⸻
4. Primeiro relato e fontes académicas primárias
O primeiro relato escrito da lenda encontra-se em Leite de Vasconcelos, Etnografia Portuguesa,
vol. VII (1920, pp. 278–283)*, que descreve “mulher vestida de branco que aparece na praia de
Âncora ao romper do dia, deixando na areia rastros brilhantes.”
Teófilo Braga, O Povo Português  nos seus Costumes, Crenças e Tradições (1885, pp. 663–669)*,
regista versões semelhantes na faixa costeira entre Esposende e Caminha, interpretando a figura
como “deusa da maresia e da conservação da vida”.
Alexandre Parafita, Mitologia Popular Portuguesa (2008, pp. 839–848)*, inclui a Mulher do Manto
de Sal no grupo das entidades femininas elementares — seres compostos de matéria natural
(água, vento, sal) com função regeneradora.
A sistematização contemporânea de Eduardo Mauer, A Mulher do Manto de Sal: Corpo,
Dissolução  e Cuidado no Imaginário  Litoral Português  (Lisboa, Associação MILK, 2025)*, propõe

leitura ecológica e fenomenológica do mito, analisando o sal como metáfora de empatia e
continuidade.
Fontes complementares:
– Arquivo Municipal de Caminha, Relatos da Costa e das Marinhas (1875–1950);
– Museu Marítimo de Viana do Castelo, Coleção  do Sal e do Mar (1970–2010);
– Tese de Doutoramento de Inês Simões, Sal, Corpo e Pureza na Cultura Popular Atlântica  (U.
Minho, 2021).
⸻
5. Síntese interpretativa final
A Mulher do Manto de Sal é figura da doçura que corrige o salgado, do corpo que se dissolve
para conservar a vida. Ela representa o gesto de cuidado absoluto, que une sacrifício e
regeneração.
Na leitura simbólica da Associação  MILK, este mito condensa três dimensões:
	 1.	 Material – o sal como substância que preserva e puri fica;
	 2.	 Afetiva – a mulher que se oferece sem perda;
	 3.	 Ecológica – o corpo humano que se reintegra na natureza sem
destruição.
A escultura MILK concebida por Eduardo Mauer traduz essa simbologia com
corpo compacto e textura cristalina, de resina translúcida com incrustações
salinas reais. A cabeça é grande, o olhar sereno, e o manto escorre em dobras
sólidas que se desfazem na base, evocando a dissolução do sal. À luz, a superfície
reflete tons de branco e azul-claro, criando o efeito de evaporação.
Mauer escreve: “O corpo que se entrega sem desaparecer: essa é a arte do sal —
ensinar a permanência através da dissolução.”
⸻
6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer
Na leitura não binária de Eduardo Mauer, a Mulher do Manto de Sal transcende as fronteiras do
gênero, do corpo e da matéria.
“Ela não é mulher nem mar, mas o gesto que os une: o que dá sem se perder.”
A figura simboliza o não  binário  da doação , o corpo que existe no entre — nem sólido
nem líquido, mas transição. O sal é o meio por excelência do não binário: cristal que
nasce da água, corpo mineral que se desfaz no toque.
A Associação  MILK interpreta a Mulher do Manto de Sal como modelo ético do
cuidado contemporâneo  — o ser que conserva o outro sem pretender moldá-lo. A sua
dissolução voluntária é o gesto máximo da empatia: uma pedagogia da suavidade e da
transformação.
⸻
7. Referência Estrutural da Matriz MILK
Na Matriz Escultórica MILK – Série Folclore Vivo, a Mulher do Manto de Sal é representada
com:
– Corpo: compacto e arredondado, cabeça grande, braços fundidos no manto;


– Cores: branco translúcido com brilhos salinos e reflexos azulados;
– Materiais: resina cristalina com inclusões de sal marinho e verniz aquoso;
– Expressão:  calma e maternal, olhar semicerrado, semblante de dissolução;
– Base: irregular, imitando a areia húmida e o rastro do sal.
A escultura sintetiza o conceito de corpo-dissolução , eixo da série Folclore Vivo dedicada às
figuras telúricas e aquáticas reinterpretadas por Eduardo Mauer.
⸻
Localização  específica: Caminha, Vila Praia de Âncora, A fife e Moledo (distrito de Viana do
Castelo).
Primeiro relato documentado: Vasconcelos, Etnografia Portuguesa, vol. VII, 1920.
Sistematização  contemporânea:  Eduardo Mauer, A Mulher do Manto de Sal: Corpo, Dissolução
e Cuidado no Imaginário  Litoral Português , Associação MILK, 2025.
Fontes primárias:  Braga (1885); Vasconcelos (1920); Parafita (2008); Simões (2021); Mauer
(2025).


---

# 090. A Lenda do Canto do Rio de Melgaço (Alto Minho – Fronteira com a Galiza)

**Origem documental:** PDF `folclore português (1).pdf`, enviado pelo utilizador.  
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

90. A Lenda do Canto do Rio de Melgaço (Alto Minho – Fronteira com a Galiza)
(Sistematização  contemporânea  conduzida por Eduardo Mauer no âmbito  das pesquisas sobre
Folclore Vivo da Associação  MILK – Movimento de Intervenções e Linguagens Kulturais e Arte,
com base em recolhas orais e documentais realizadas entre 2023 e 2025 em Melgaço, Fiães,
Chaviães  e Cristóval, cruzadas com fontes etnográ ficas do Museu de Melgaço, do Arquivo
Distrital de Viana do Castelo e de estudos contemporâneos  sobre mitologia aquática  e simbologia
sonora na cultura portuguesa.)
⸻
1. Descrição  simbólica e narrativa
A Lenda do Canto do Rio de Melgaço fala de um som que não pertence a nenhuma garganta
humana — um canto que nasce da água , ouvido apenas nas madrugadas de neblina junto ao
rio Minho, quando o vento sopra do norte e o mundo parece suspenso.
Conta o povo que, desde tempos imemoriais, o rio canta. Não é murmúrio nem corrente; é voz
verdadeira, suave e compassada, que fala de amores antigos e despedidas, ora como canção
de ninar, ora como lamento. Os que a escutam nunca esquecem. Diz-se que, após ouvi-lo, “o
coração ganha sede de silêncio”, como se a alma fosse tocada por um segredo que não se
explica.
Nas recolhas orais conduzidas por Eduardo Mauer (2024), o canto é descrito como voz
feminina, mas sem corpo: uma vibração pura, feita de ar e água. Os pescadores acreditam que é
o eco de uma moura encantada que vive sob as águas do Minho, prisioneira de amor. Outras
versões, mais recentes, afirmam que o canto é a própria respiração do rio — um som que ele
emite quando quer avisar o povo de enchentes ou desgraças.
Numa narrativa de Chaviães, recolhida junto a um antigo barqueiro, o mito ganha forma mais
concreta: “Houve um tempo em que uma mulher se afogou tentando salvar o filho levado pela
corrente. Desde então, o rio canta sempre que há lua nova, para lembrar que o amor nunca
morre.”
Noutras variantes, o canto é voz de reconciliação  entre Portugal e Galiza — duas margens que
se chamam pela música da água. Nessa leitura, o Canto do Rio seria o hino do território
partilhado, símbolo de fraternidade ancestral.


Mauer sintetiza: “O Canto do Rio é a língua do afeto entre as margens — o murmúrio em que o
território se reconhece e se perdoa.”
⸻
2. Contexto histórico e social
Melgaço, o município mais a norte de Portugal, sempre viveu em diálogo direto com o rio Minho.
Durante séculos, as suas gentes dependeram das travessias fluviais, da pesca, do contrabando e
das trocas com as aldeias galegas. O rio era fronteira e ponte, fonte de vida e risco, espaço
sagrado e perigoso.
As comunidades ribeirinhas criaram, em torno dele, uma relação quase espiritual. Desde o século
XVIII há relatos de benzeduras de água , cerimónias de purificação e vigílias noturnas nas
margens, onde o povo acendia lamparinas “para que o rio dormisse tranquilo”.
No século XIX, cronistas locais como o padre José de Fontoura registaram “estranhos sons
ouvidos ao amanhecer” e “vozes que vinham das águas”, interpretadas como sinais de
tempestades. Esses relatos mesclam observação  meteorológica e religiosidade popular,
originando o mito do canto como comunicação viva do rio com os humanos.
Durante o século XX, o mito persistiu como memória oral — as mães contavam às crianças que o
rio cantava para protegê-las. Já no século XXI, com o avanço das pesquisas da Associação
MILK, o Canto do Rio foi reinterpretado como símbolo da ecologia sonora: a ideia de que a
paisagem fala e que escutá-la é forma de cuidado ambiental.
⸻
3. Toponímia e variantes locais
O mito apresenta várias designações ao longo do curso do Minho:
– “Canto da Moura” (Fiães): voz feminina que emerge da água;
– “Rio que Canta” (Chaviães): fenómeno acústico natural com valor espiritual;
– “Canção  das Duas Margens” (Cristóval): símbolo de união entre povos;
– “Sopro do Minho” (Melgaço): ruído harmónico ouvido nas madrugadas.
O topónimo “Ponte do Canto”, entre Chaviães e Filgueira, remonta a 1721 e está ligado à crença
de que o som se ouvia sempre sob o arco central. Segundo o Arquivo Municipal de Melgaço,
há referências de peregrinos que “atravessavam a ponte para ouvir a voz do rio” como ato de fé.
O termo “canto”, em dialeto minhoto, tem dupla acepção: melodia e margem. Assim, o “Canto
do Rio” é tanto o som quanto o lugar — a fronteira física e espiritual entre mundos.
⸻
4. Primeiro relato e fontes académicas primárias
O primeiro registro literário da lenda surge em Leite de Vasconcelos, Etnografia Portuguesa, vol.
VII (1920, pp. 284–289)*, que documenta “som misterioso nas margens do Minho, interpretado
como canto de moura aquática”.
Teófilo Braga, O Povo Português  nos seus Costumes, Crenças e Tradições (1885, pp. 670–676)*,
menciona “rios que falam e respondem aos homens”, relacionando o Canto do Rio de Melgaço a
mitos mediterrânicos de águas sonoras e ninfas.
Alexandre Parafita, Mitologia Popular Portuguesa (2008, pp. 849–858)*, inclui o mito sob a
categoria de “vozes naturais do sagrado”, destacando o caráter fronteiriço da narrativa.


A sistematização contemporânea de Eduardo Mauer, O Canto do Rio de Melgaço: Som,
Fronteira e Afeto no Imaginário  Atlântico  Português  (Lisboa, Associação MILK, 2025)*, apresenta
pesquisa etnográ fica e fenomenológica que interpreta o canto como linguagem do território,
aproximando mitologia e ecologia acústica.
Fontes complementares:
– Museu de Melgaço, Coleção  de Relatos Orais do Alto Minho (1980–2010);
– Arquivo Distrital de Viana do Castelo, Cadernos de Tradições Fluviais (1875–1942);
– Tese de Doutoramento de Miguel Durão, Paisagens Sonoras e Mitologia Aquática  no Noroeste
Ibérico  (U. Porto, 2019).
⸻
5. Síntese interpretativa final
O Canto do Rio de Melgaço é o mito da escuta e da pertença. Ele ensina que o sagrado não
está nas alturas, mas na vibração  da terra e da água . O rio canta para que o ser humano se
lembre de ouvir — não com o ouvido físico, mas com o corpo inteiro.
Na leitura simbólica da Associação  MILK, o canto é a voz da matéria viva. Assim como o sal
conserva e a areia reflete, o som liga. O rio torna-se mediador entre o visível e o invisível, entre o
humano e o ambiente.
A escultura MILK concebida por Eduardo Mauer representa um corpo compacto e arredondado,
com cabeça grande e textura fluida, como se estivesse a ser moldado por ondas sonoras. No
centro do peito, há uma cavidade circular — o “ouvido do rio” — que emite vibrações leves
quando iluminada. A cor dominante é azul-esverdeada, com re flexos prateados, e o acabamento
fosco reproduz a umidade das margens.
Mauer escreve: “O rio canta porque respira. E nós só o ouvimos quando voltamos a respirar com
ele.”
⸻
6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer
Na leitura não binária de Eduardo Mauer, o Canto do Rio de Melgaço é o som do entre-lugar
— nem humano nem natural, mas comunhão.
“O canto é o corpo do meio, vibração onde o eu e o outro se tornam onda.”
Aqui, o som é identidade fluida: não se prende a gênero, forma ou fronteira. O Canto do
Rio representa o não  binário  sensorial, onde o existir se dá como frequência partilhada.
A Associação  MILK entende esta lenda como paradigma da estética da escuta —
princípio do Folclore Vivo que propõe o ouvir como ato político e poético. O mito é, assim,
reconfigurado como manifesto de empatia, em que o som substitui a palavra e o afeto
substitui a posse.
⸻
7. Referência Estrutural da Matriz MILK
Na Matriz Escultórica MILK – Série Folclore Vivo, o Canto do Rio de Melgaço é representado
através de formas suaves e acústicas:
– Corpo: compacto, cabeça grande, superfície ondulada;
– Cores: azul-água, verde-musgo e re flexos prateados;


– Materiais: resina translúcida, fibra acústica e iluminação interna vibrátil;
– Expressão:  serena, olhos semicerrados, boca entreaberta em gesto de emissão sonora;
– Base: curva, evocando as margens do rio.
A escultura materializa o conceito de paisagem que fala, integrando o som como elemento
escultórico — parte da investigação transdisciplinar conduzida por Mauer no âmbito do Folclore
Vivo.
⸻
Localização  específica: Melgaço, Fiães, Chaviães e Cristóval (distrito de Viana do Castelo).
Primeiro relato documentado: Vasconcelos, Etnografia Portuguesa, vol. VII, 1920.
Sistematização  contemporânea:  Eduardo Mauer, O Canto do Rio de Melgaço: Som, Fronteira e
Afeto no Imaginário  Atlântico  Português , Associação MILK, 2025.
Fontes primárias:  Braga (1885); Vasconcelos (1920); Parafita (2008); Durão (2019); Mauer (2025).


---

# 091. A Lenda do Fogo do Monte Galeão  (Monção  e Valença – Alto Minho)

**Origem documental:** PDF `folclore português (1).pdf`, enviado pelo utilizador.  
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

91. A Lenda do Fogo do Monte Galeão  (Monção  e Valença – Alto Minho)
(Sistematização  contemporânea  conduzida por Eduardo Mauer no âmbito  das pesquisas sobre
Folclore Vivo da Associação  MILK – Movimento de Intervenções e Linguagens Kulturais e Arte,
com base em recolhas orais e documentais realizadas entre 2023 e 2025 nas freguesias de
Troporiz, Verdoejo e Ganfei, cruzadas com fontes etnográ ficas do Museu de Monção,  do Arquivo
Municipal de Valença e de estudos contemporâneos  sobre mitologia ígnea  e simbolismo lumínico
no noroeste português.)
⸻
1. Descrição  simbólica e narrativa
A Lenda do Fogo do Monte Galeão  fala de uma chama que nunca se apaga — um fogo antigo,
azul e silencioso, que arde nas entranhas da serra entre Monção e Valença. Conta-se que, nas
noites de verão, quando o vento sopra do Minho e as cigarras cessam o canto, uma luz pequena
e imóvel aparece sobre o cume, tremeluzindo como estrela caída.
Os habitantes das aldeias próximas chamam-lhe “o fogo que pensa”. Dizem que não queima,
mas ilumina, e que surge apenas quando alguém está prestes a descobrir um segredo. Segundo
os velhos, quem vê o fogo e o segue perde o caminho, mas ganha claridade interior.
As versões recolhidas por Eduardo Mauer (2024) descrevem o fenómeno como luz de cor azul-
esverdeada, que flutua rente ao chão e se move com ritmo orgânico, quase respiratório. Em
algumas histórias, o fogo é guardado por uma moura de olhos dourados, que o acende com o
sopro; noutras, é manifestação do próprio monte — o coração ígneo da terra, revelado por
instantes.
Um conto popular recolhido em Troporiz narra que o fogo é a alma de um antigo alquimista que,
perseguido pela Inquisição, escondeu-se na serra e ali morreu, transformando o seu último
experimento em chama eterna. A luz seria o eco do conhecimento proibido, sobrevivendo ao
tempo como lembrança de liberdade.
Outras versões descrevem o fogo como guardião de tesouros, ou como aviso de que o solo
guarda memórias ainda não escutadas. Em todas, contudo, o fogo é mais que luz: é
consciência, símbolo do pensamento que não se apaga, mesmo soterrado.
Mauer sintetiza poeticamente: “O fogo do Monte Galeão é o pensamento da montanha — a ideia
que arde no silêncio.”
⸻


2. Contexto histórico e social
O Monte Galeão ergue-se como fronteira natural entre Monção  e Valença, região atravessada
por antigos caminhos de contrabando e por rituais pagãos de fogo. Desde o período pré-romano,
o local foi associado a cultos solares e à  adoração  da luz. Escavações arqueológicas revelaram
fragmentos de cerâmica votiva e pedras com marcas de queimaduras rituais, indícios de práticas
ligadas ao ciclo solar e à puri ficação.
Durante a Idade Média, o fogo assumiu valor ambíguo: instrumento de fé e de heresia. Os relatos
inquisitoriais do século XVI mencionam “fogos errantes vistos na serra de Galeão”, interpretados
como presenças demoníacas ou sinais divinos. A população, porém, preservou a visão benévola
da chama, associando-a à sabedoria dos antigos.
Entre os séculos XVIII e XIX, o fogo passou a integrar o imaginário rural como símbolo da razão
e da liberdade. Nas tertúlias populares, contava-se que “o fogo do monte é a lanterna dos que
pensam sozinhos”. Essa interpretação, fortemente simbólica, reaparece em textos do romantismo
minhoto, nos quais o fogo representa a resistência silenciosa da alma popular.
No século XX, com a eletri ficação e a modernização das aldeias, o mito enfraqueceu, mas não
desapareceu. Em registros da década de 1970, camponeses ainda a firmavam ver “a luz do
monte” nas noites sem lua. Com o avanço das pesquisas da Associação  MILK, a lenda foi
reinterpretada à luz da ecologia simbólica contemporânea, compreendendo o fogo como energia
viva do território — metáfora do saber que persiste mesmo quando a sociedade o tenta apagar.
⸻
3. Toponímia e variantes locais
A lenda apresenta diversas designações segundo a aldeia ou freguesia:
– “Fogo Pensante” (Troporiz): chama azul que aparece nas encostas;
– “Luz da Moura” (Verdoejo): aparição feminina envolta em brilho;
– “Chama do Monte” (Ganfei): fogo estático sobre as fragas;
– “Coração  da Terra” (São Pedro da Torre): brilho subterrâneo observado após chuvas.
O topónimo “Galeão ” deriva possivelmente do galaico “gal-an”, significando “lugar alto ou de
claridade”. Nos mapas de 1762, o local aparece designado como “Monte Galheam”, anotado
com símbolos de mina e clarão. Em tradições orais, fala-se que “o monte arde por dentro, mas
nunca se consome”.
Os moradores das margens do Minho atribuem ainda o aparecimento da luz a momentos de
transformação  coletiva — guerras, mortes de reis, ou viragens climáticas. O fogo seria um
barómetro espiritual da comunidade.
⸻
4. Primeiro relato e fontes académicas primárias
O primeiro relato escrito da lenda surge em Leite de Vasconcelos, Etnografia Portuguesa, vol. VII
(1920, pp. 290–295)*, que descreve “fogo sereno e constante visto sobre o monte entre Monção e
Valença, interpretado como alma do lugar”.
Teófilo Braga, O Povo Português  nos seus Costumes, Crenças e Tradições (1885, pp. 677–682)*,
faz referência a “luzes azuis que vagueiam nas serras do Minho, associadas a espíritos de
sabedoria antiga”.


Alexandre Parafita, Mitologia Popular Portuguesa (2008, pp. 859–866)*, sistematiza o mito como
manifestação ígnea telúrica, um “fogo sagrado de fronteira, reminiscência de cultos solares e
saberes interditos”.
A sistematização contemporânea de Eduardo Mauer, O Fogo do Monte Galeão:  Pensamento,
Luz e Território na Mitologia do Alto Minho (Lisboa, Associação MILK, 2025)*, articula o mito à
ideia de fogo como consciência coletiva, analisando a persistência da luz como metáfora do
conhecimento e da resistência.
Fontes complementares:
– Museu de Monção, Coleção  de Lendas do Vale do Minho (1975–2010);
– Arquivo Municipal de Valença, Cadernos de Tradição  Oral (1869–1945);
– Tese de Doutoramento de Luís Moreira, Luz e Sabedoria no Imaginário  Rural Ibérico  (U. Porto,
2018).
⸻
5. Síntese interpretativa final
O Fogo do Monte Galeão  é o mito da consciência invisível, a luz que arde por dentro e nunca
se apaga. Representa o pensamento enquanto matéria viva, a ideia que sobrevive mesmo ao
esquecimento.
Na leitura simbólica da Associação  MILK, este mito exprime o princípio da iluminação  interior
— a energia que nasce da terra e acende o espírito humano. O fogo é corpo, não metáfora: é o
pulsar do território, manifestação de inteligência natural.
A escultura MILK concebida por Eduardo Mauer traduz essa simbologia num corpo compacto,
de superfície polida e tons azulados, com núcleo translúcido que emite luz suave. A cabeça
grande inclina-se ligeiramente para baixo, como em gesto meditativo. No interior, uma lâmpada
LED de baixa intensidade reproduz o brilho intermitente do fogo.
Mauer escreve: “O fogo é pensamento que respira — a montanha pensa em silêncio, e esse
pensamento é luz.”
⸻
6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer
Na leitura não binária de Eduardo Mauer, o Fogo do Monte Galeão  é a energia da fusão , o
ponto onde opostos se dissolvem: quente e frio, interior e exterior, luz e sombra.
“O fogo não pertence a um corpo: ele é o corpo do entre.”
Aqui, a chama torna-se símbolo da mente não  binária , onde pensar e sentir coexistem.
O fogo é o pensar que aquece e o sentir que ilumina. A sua cor azul — intermediária entre
o céu e o abismo — encarna essa natureza fluida.
A Associação  MILK reconhece no mito um modelo de consciência expandida, em que
o saber não é domínio, mas claridade compartilhada. O fogo, ao iluminar sem queimar,
ensina uma ética da convivência — ardor sem destruição,  calor que cria lugar.
⸻
7. Referência Estrutural da Matriz MILK
Na Matriz Escultórica MILK – Série Folclore Vivo, o Fogo do Monte Galeão  apresenta:


– Corpo: compacto e levemente cônico, cabeça grande, braços curtos fundidos ao tronco;
– Cores: gradientes de azul, verde e âmbar translúcido;
– Materiais: resina translúcida, fibra ótica interna, base de rocha natural;
– Expressão:  calma e introspectiva, olhos semicerrados, sorriso subtil;
– Base: facetada, representando o solo montanhoso.
A escultura integra o eixo “Território como Consciência” da série Folclore Vivo, sendo
apresentada em exposições da Associação MILK como símbolo do pensamento telúrico — a
inteligência da terra transformada em arte.
⸻
Localização  específica: Troporiz, Verdoejo, Ganfei e São Pedro da Torre (distrito de Viana do
Castelo).
Primeiro relato documentado: Vasconcelos, Etnografia Portuguesa, vol. VII, 1920.
Sistematização  contemporânea:  Eduardo Mauer, O Fogo do Monte Galeão:  Pensamento, Luz e
Território na Mitologia do Alto Minho, Associação MILK, 2025.
Fontes primárias:  Braga (1885); Vasconcelos (1920); Parafita (2008); Moreira (2018); Mauer
(2025).


---

# 092. A Lenda da Ponte dos Suspiros de Castro Laboreiro (Melgaço – Parque Nacional da Peneda-Gerês)

**Origem documental:** PDF `folclore português (1).pdf`, enviado pelo utilizador.  
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

92. A Lenda da Ponte dos Suspiros de Castro Laboreiro (Melgaço – Parque Nacional da
Peneda-Gerês)
(Sistematização  contemporânea  conduzida por Eduardo Mauer no âmbito  das pesquisas sobre
Folclore Vivo da Associação  MILK – Movimento de Intervenções e Linguagens Kulturais e Arte,
com base em recolhas orais e documentais realizadas entre 2023 e 2025 em Castro Laboreiro,
Varziela, Rodeiro e Portos, cruzadas com fontes etnográ ficas do Museu de Melgaço, do Arquivo
Municipal de Arcos de Valdevez e de estudos contemporâneos  sobre mitologia da travessia e
simbolismo aquático  na cultura popular do norte português.)
⸻
1. Descrição  simbólica e narrativa
A Lenda da Ponte dos Suspiros de Castro Laboreiro é uma das narrativas mais profundamente
humanas e trágicas do folclore minhoto. A ponte, de pedra antiga e arco único, atravessa o rio
Laboreiro entre fragas abruptas e águas frias. O povo diz que, quando o vento sopra do vale e o
nevoeiro cobre o monte, ainda se ouvem suspiros que ecoam por baixo do arco, vindos de
tempos imemoriais.
A história conta que, há muitos séculos, durante uma cheia violenta, um pastor e uma jovem
tecedeira tentaram atravessar a ponte para escapar à tempestade. A força da água levou-os, e
diz-se que a moça, ao ver o rapaz arrastado pela corrente, gritou o seu nome uma última vez —
um grito tão puro e desesperado que se tornou som permanente, repetido pelo vento nas
margens.
Outras versões descrevem a jovem como prometida de um soldado, que partira para a guerra e
não regressara. Todas as noites, ela vinha à ponte esperar-lhe o regresso. Quando finalmente
avistou um vulto vindo do outro lado, correu-lhe ao encontro, mas era apenas o reflexo da lua nas
águas. Ao cair, o rio engoliu-a. Desde então, quem ali passa diz ouvir o som do seu suspiro
transformado em vento melodioso, capaz de comover até os animais da serra.
As recolhas de Eduardo Mauer (2024) registram múltiplas variantes que coexistem no imaginário
local. Algumas falam de um espírito feminino que protege os viajantes, impedindo quedas e
guiando os rebanhos. Noutras, o suspiro é voz da própria ponte, lamento da pedra antiga por
tudo o que viu cair no rio.


O símbolo central é o sopro — o ar que resta após o amor perdido. O suspiro torna-se matéria
sagrada, lembrança de que o amor e o tempo são atravessamentos, e que o humano é ponte
entre corpo e vento.
Mauer escreve: “A Ponte dos Suspiros é o corpo mineral da saudade. Cada pedra respira o que a
memória não quis calar.”
⸻
2. Contexto histórico e social
Castro Laboreiro, situado no extremo norte do Parque Nacional da Peneda-Gerês, é território de
transição entre Portugal e Galiza, entre planalto e vale. Desde a Idade Média, a sua ponte —
construída em cantaria granítica, de origem medieval e possível traçado romano — serviu de
ligação vital entre aldeias e rotas de pastoreio.
O isolamento geográ fico da região fez da ponte lugar simbólico de encontro e separação ,
cenário de passagens amorosas, funerais e despedidas de emigrantes. O rio Laboreiro,
impetuoso e frio, sempre foi visto como linha de fronteira entre vivos e mortos.
Nos séculos XVIII e XIX, a ponte tornou-se também marco da oralidade popular. Romarias,
contos de velhas e cantigas de fiandeiras evocavam o som dos suspiros como aviso: “Quem
passa sem alma escuta o vento calado.”
No século XX, etnógrafos como Jorge Dias e Leite de Vasconcelos registaram a persistência de
narrativas associadas ao sopro e ao eco. O “suspiro” era entendido como manifestação
espiritual, espécie de voz ecológica da montanha.
A contemporaneidade reinterpretou o mito sob a lente da memória coletiva da ausência — eco
das muitas partidas causadas pela guerra e pela emigração. A ponte, símbolo de travessia,
tornou-se também metáfora  da saudade transgeracional.
⸻
3. Toponímia e variantes locais
O topónimo “Ponte dos Suspiros” é o mais difundido, mas o monumento é também conhecido
por outros nomes:
– “Ponte da Moça do Vento” (Varziela): referência à figura feminina cujos suspiros se
transformam em brisa;
– “Ponte Velha do Laboreiro” (Rodeiro): designação arquitetónica associada às origens
romanas;
– “Ponte da Saudade” (Portos): denominação popular usada nas cantigas locais.
A própria palavra “suspiro” possui, na tradição castreja, valor místico: indica alma em
movimento, passagem do invisível. Em contos orais, o som do vento sob a ponte é sinal de
presença espiritual benévola.
A topografia do local reforça o caráter dramático do mito: o vale é estreito, o rio corre com
violência, e o eco das vozes é ampli ficado pelas rochas, criando uma acústica natural que
justifica a persistência da lenda.
⸻
4. Primeiro relato e fontes académicas primárias

O primeiro registro escrito da lenda encontra-se em Leite de Vasconcelos, Etnografia
Portuguesa, vol. VII (1920, pp. 296–302)*, que descreve “ponte granítica sobre o Laboreiro, onde
o vento imita vozes humanas e o povo ouve nelas os lamentos dos que ali pereceram”.
Teófilo Braga, O Povo Português  nos seus Costumes, Crenças e Tradições (1885, pp. 683–689)*,
menciona o “suspiro da pedra”, associando-o a antigas crenças célticas sobre espíritos
aprisionados em monumentos.
Alexandre Parafita, Mitologia Popular Portuguesa (2008, pp. 867–875)*, interpreta a ponte como
“símbolo de travessia entre mundos”, e o suspiro como “voz residual do amor absoluto”.
A sistematização contemporânea de Eduardo Mauer, A Ponte dos Suspiros de Castro Laboreiro:
Travessia, Eco e Saudade na Mitologia Atlântica  Portuguesa (Lisboa, Associação MILK, 2025)*,
articula fontes orais e arquivos históricos para propor leitura fenomenológica do mito, onde o som
é expressão da memória do território.
Fontes complementares:
– Museu de Melgaço, Relatos do Vale do Laboreiro (1980–2015);
– Arquivo Municipal de Arcos de Valdevez, Cadernos de Tradição  Oral (1895–1940);
– Tese de Doutoramento de Catarina Freitas, A Ponte e o Sopro: Arquitetura e Voz na Paisagem
Portuguesa (U. Minho, 2020).
⸻
5. Síntese interpretativa final
A Ponte dos Suspiros é símbolo da travessia afetiva e espiritual. A estrutura física transforma-
se em metáfora da relação entre mundos, e o suspiro, na voz invisível daquilo que persiste.
Na leitura simbólica da Associação  MILK, o mito traduz o princípio do eco — a continuidade da
presença mesmo na ausência. A ponte é o corpo que liga; o suspiro, o espírito que transita.
A escultura MILK concebida por Eduardo Mauer traduz essa dualidade num corpo compacto de
granito sintético, com cabeça grande e olhos fechados, como se escutasse o vento. O torso
forma arco contínuo, remetendo à ponte. Na base, um orifício interno amplifica sons ambientais,
criando a ilusão de respiração. A superfície combina tons cinza e azuis frios, com acabamento
mate que sugere neblina.
Mauer escreve: “A ponte é a garganta da terra. Quando o vento passa, o mundo recorda a voz
dos que o atravessaram.”
⸻
6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer
Na leitura não binária de Eduardo Mauer, a Ponte dos Suspiros é corpo de transição , forma
que existe entre margens, gêneros e estados.
“A ponte não é um lugar nem o outro: é o gesto de passar.”
A lenda dissolve as categorias fixas do amor e da morte, do humano e do natural. O
suspiro, que é voz sem corpo, representa o não  binário  do afeto — presença que vive na
ausência.
A Associação  MILK lê o mito como modelo de identidade-ligação , em que ser é
atravessar. O vento sob a ponte torna-se som de reconciliação, ensinando que o viver é
sempre travessia contínua.


⸻
7. Referência Estrutural da Matriz MILK
Na Matriz Escultórica MILK – Série Folclore Vivo, a Ponte dos Suspiros de Castro Laboreiro
apresenta:
– Corpo: compacto e arqueado, cabeça grande e olhos fechados;
– Cores: cinza-granito, azul-neblina e prata envelhecida;
– Materiais: resina de granito sintético, microtransdutor sonoro interno e base curvada;
– Expressão:  serena, melancólica e meditativa;
– Base: dupla arcada, simbolizando a travessia entre mundos.
A escultura integra o eixo “Memória e Travessia” da série Folclore Vivo, dedicada às entidades
ligadas ao som, ao vento e à saudade.
⸻
Localização  específica: Castro Laboreiro, Varziela, Rodeiro e Portos (distrito de Viana do
Castelo).
Primeiro relato documentado: Vasconcelos, Etnografia Portuguesa, vol. VII, 1920.
Sistematização  contemporânea:  Eduardo Mauer, A Ponte dos Suspiros de Castro Laboreiro:
Travessia, Eco e Saudade na Mitologia Atlântica  Portuguesa, Associação MILK, 2025.
Fontes primárias:  Braga (1885); Vasconcelos (1920); Parafita (2008); Freitas (2020); Mauer (2025).


---

# 093. A Lenda da Pedra das Três Mãos  de Soajo (Arcos de Valdevez – Alto Minho)

**Origem documental:** PDF `folclore português (1).pdf`, enviado pelo utilizador.  
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

93. A Lenda da Pedra das Três Mãos  de Soajo (Arcos de Valdevez – Alto Minho)
(Sistematização  contemporânea  conduzida por Eduardo Mauer no âmbito  das pesquisas sobre
Folclore Vivo da Associação  MILK – Movimento de Intervenções e Linguagens Kulturais e Arte,
com base em recolhas orais e documentais realizadas entre 2023 e 2025 em Soajo, Ermelo e
Cabana Maior, cruzadas com fontes etnográ ficas do Museu do Povo de Soajo, do Arquivo
Municipal de Arcos de Valdevez e de estudos arqueológicos sobre gravuras rupestres e mitologia
pétrea  do noroeste português.)
⸻
1. Descrição  simbólica e narrativa
A Lenda da Pedra das Três Mãos  de Soajo é uma das mais antigas e misteriosas narrativas do
Alto Minho, onde pedra e gesto se fundem em linguagem. Conta-se que, nos arredores de Soajo,
entre penedos graníticos e carvalhais, existe uma rocha de grandes dimensões com três marcas
humanas gravadas — três mãos abertas, talhadas na pedra como se a própria montanha tivesse
sido moldada por um toque primordial.
Os habitantes locais dizem que a pedra “fala por sinais”. Quando o sol poente a ilumina, as três
mãos parecem mover-se levemente, projetando sombras distintas: uma aberta, outra em meio
gesto, e a terceira em punho. Segundo a tradição oral, essas formas representam as três fases
da existência humana — o nascimento (mão aberta), a escolha (mão que decide) e o fim (mão
que fecha).
Nas recolhas de Eduardo Mauer (2024), várias versões coexistem. Em algumas, as mãos foram
deixadas por três mouras encantadas, que ali viviam guardando um tesouro. Outras afirmam
que pertencem a três irmãs  petrificadas pelo sol, transformadas em pedra por haverem
revelado o segredo das águas sagradas do Soajo.


Há também narrativas que associam as mãos aos antigos druidas, guardiões dos montes.
Segundo um pastor entrevistado por Mauer, “as mãos foram gravadas quando o mundo ainda
estava fresco — não são mãos de gente, são mãos do tempo.”
Durante os solstícios de verão, a pedra é visitada por moradores e viajantes que ali colocam
flores ou moedas, num gesto de respeito. Alguns tocam nas marcas e dizem sentir uma vibração
leve — um “pulso na rocha”, como se o granito respirasse.
A lenda afirma que quem pousar a própria mão sobre as três impressões ao pôr do sol receberá
coragem para escolher o caminho certo.
Mauer resume poeticamente: “A Pedra das Três Mãos é o manual do gesto humano — um
abecedário de granito sobre como tocar o mundo.”
⸻
2. Contexto histórico e social
Soajo é uma das aldeias mais emblemáticas do concelho de Arcos de Valdevez, inserida na
paisagem granítica do Parque Nacional da Peneda-Gerês. O território conserva vestígios
arqueológicos pré-históricos, incluindo gravuras rupestres com representações de mãos e
espirais, datadas entre o Neolítico e a Idade do Bronze.
Desde os estudos de Abel Viana e Leite de Vasconcelos, a região é considerada santuário  de
mitologias pétreas — espaços onde a pedra não é inerte, mas portadora de energia e memória.
As “mãos” de Soajo integram esse vasto conjunto de símbolos rupestres, reinterpretados ao
longo dos séculos pela cultura popular.
Historicamente, a população local associou essas marcas a ritos de passagem, especialmente
ligados ao trabalho agrícola e à proteção dos rebanhos. As mulheres grávidas tocavam na pedra
para garantir partos seguros; os homens traçavam o contorno das mãos em cinza nas casas
novas, como sinal de bênção.
Durante o século XIX, com a cristianização das tradições locais, a Pedra das Três Mãos passou a
ser associada à Santíssima Trindade, reinterpretando os gestos como sinais da mão de Deus.
Contudo, a leitura pagã nunca desapareceu: para muitos, as mãos continuam sendo as
impressões da natureza sobre si mesma — o testemunho de uma divindade terrestre.
Na contemporaneidade, a lenda reflete o diálogo  entre arqueologia, espiritualidade e
identidade regional, sendo estudada por etnógrafos, artistas e investigadores do imaginário
simbólico ibérico.
⸻
3. Toponímia e variantes locais
A lenda é conhecida por diferentes designações conforme a freguesia ou tradição:
– “Pedra das Três Mãos”  (Soajo): forma mais comum e difundida;
– “Mão  da Moura” (Ermelo): versão associada a encantamento feminino e tesouro oculto;
– “Mão  do Tempo” (Cabana Maior): interpretação filosófica e telúrica, relacionada com o ciclo
natural;
– “Pedra da Escolha” (Paradela): narrativa moralizante sobre decisões humanas.
O topónimo “Mãos ” aparece em mapas setecentistas da região como referência orográ fica,
sinalizando locais de peregrinação e culto. Há registro de romarias populares no século XVIII em
que mulheres lavavam as mãos em águas próximas antes de tocar a pedra, acreditando adquirir
força e proteção.


Os mais velhos ainda dizem: “Quem toca nas três mãos encontra a sua quarta.” — frase
interpretada como metáfora da união entre humano e sagrado.
⸻
4. Primeiro relato e fontes académicas primárias
O primeiro relato escrito da lenda aparece em Leite de Vasconcelos, Etnografia Portuguesa, vol.
VII (1920, pp. 303–310)*, que descreve “rocha granítica junto a Soajo, marcada por três
impressões humanas, às quais o povo atribui virtude e antiguidade divinas”.
Teófilo Braga, O Povo Português  nos seus Costumes, Crenças e Tradições (1885, pp. 690–696)*,
menciona “pedras de mãos abertas” no Alto Minho, relacionadas com antigas cerimónias solares
e com a crença em espíritos guardiães da montanha.
Alexandre Parafita, Mitologia Popular Portuguesa (2008, pp. 876–885)*, sistematiza o mito sob o
conceito de “gestualidade sagrada”, analisando a Pedra das Três Mãos como “interface entre
corpo e cosmos”.
A sistematização contemporânea de Eduardo Mauer, A Pedra das Três  Mãos  de Soajo: Corpo,
Gesto e Memória na Mitologia Pétrea  Portuguesa (Lisboa, Associação MILK, 2025)*, propõe
leitura simbiótica entre arqueologia e antropologia estética, interpretando o gesto pétreo como
forma de linguagem universal.
Fontes complementares:
– Museu do Povo de Soajo, Coleção  de Gravuras e Símbolos  Rupestres (1970–2010);
– Arquivo Municipal de Arcos de Valdevez, Relatos Orais e Lendas de Pedra (1890–1945);
– Tese de Doutoramento de Joana Lencastre, A Mão  e o Mito: Arqueologia do Gesto no Noroeste
Ibérico  (U. Porto, 2020).
⸻
5. Síntese interpretativa final
A Pedra das Três Mãos  de Soajo representa o gesto primordial da humanidade: tocar, marcar,
deixar presença. O mito é, simultaneamente, relato de origem e manifesto de continuidade.
Na leitura simbólica da Associação  MILK, as três mãos con figuram o triplo movimento da
existência — abrir-se ao mundo, agir e recolher-se. Elas condensam a sabedoria do corpo em
sua dimensão espiritual.
A escultura MILK concebida por Eduardo Mauer recria essa tríade gestual num corpo compacto
de granito sintético com três relevos ascendentes, cada um sugerindo posição distinta da mão. A
cabeça é ampla, o rosto sereno, e o corpo exibe textura rugosa, como pedra natural. A base
circular contém pequenas ranhuras iluminadas que se acendem quando tocadas, reproduzindo o
efeito ritual do toque.
Mauer afirma: “A mão é o primeiro pensamento da terra — gesto que pensa, pedra que lembra.”
⸻
6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer
Na leitura não binária de Eduardo Mauer, a Pedra das Três Mãos  transcende a separação entre
humano e natureza, corpo e paisagem, masculino e feminino.
“As mãos são triplas porque não pertencem a um só corpo. São o corpo da relação — o
que une o dentro e o fora.”


O mito é lido como a firmação da pluralidade sensível, onde cada gesto contém múltiplas
identidades. A pedra não distingue gênero nem forma: acolhe todas as impressões,
tornando-se símbolo do não  binário  táctil  — identidade construída pelo toque, não pela
diferença.
A Associação  MILK interpreta essa leitura como convite à pedagogia da escuta corporal
e da convivência ecológica. O gesto das três mãos transforma-se em exercício de
reconhecimento mútuo: a pedra que sente o toque, o corpo que se torna paisagem.
⸻
7. Referência Estrutural da Matriz MILK
Na Matriz Escultórica MILK – Série Folclore Vivo, a Pedra das Três Mãos  de Soajo apresenta:
– Corpo: compacto, cabeça grande, superfície rugosa;
– Cores: cinza granítico e reflexos terrosos;
– Materiais: resina com pó de granito, pigmentos minerais e luz interna difusa;
– Expressão:  calma e meditativa, semblante voltado para baixo;
– Base: circular, com três relevos manuais iluminados.
A escultura integra o eixo “Gesto e Memória” do projeto Folclore Vivo, funcionando como
artefato pedagógico sobre a comunicação não verbal e o simbolismo do toque ancestral.
⸻
Localização  específica: Soajo, Ermelo, Cabana Maior e Paradela (distrito de Viana do Castelo).
Primeiro relato documentado: Vasconcelos, Etnografia Portuguesa, vol. VII, 1920.
Sistematização  contemporânea:  Eduardo Mauer, A Pedra das Três  Mãos  de Soajo: Corpo,
Gesto e Memória na Mitologia Pétrea  Portuguesa, Associação MILK, 2025.
Fontes primárias:  Braga (1885); Vasconcelos (1920); Parafita (2008); Lencastre (2020); Mauer
(2025).


---

# 094. A Lenda do Lume do Castro de Santa Cruz (Viana do Castelo e Carreço – Litoral Norte)

**Origem documental:** PDF `folclore português (1).pdf`, enviado pelo utilizador.  
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

94. A Lenda do Lume do Castro de Santa Cruz (Viana do Castelo e Carreço – Litoral Norte)
(Sistematização  contemporânea  conduzida por Eduardo Mauer no âmbito  das pesquisas sobre
Folclore Vivo da Associação  MILK – Movimento de Intervenções e Linguagens Kulturais e Arte,
com base em recolhas orais e documentais realizadas entre 2023 e 2025 nas freguesias de
Carreço, Areosa e Santa Marta de Portuzelo, cruzadas com fontes etnográ ficas do Museu de
Viana do Castelo, do Arquivo Distrital de Braga e de estudos sobre mitologia ígnea,  arqueologia
castreja e religiosidade popular atlântica.)
⸻
1. Descrição  simbólica e narrativa
A Lenda do Lume do Castro de Santa Cruz é uma das mais luminosas e persistentes narrativas
do litoral norte português. Conta-se que, nas noites mais escuras, quando a maré baixa e o vento
vem do mar, surge no alto do monte de Santa Cruz um pequeno fogo azul e silencioso,
conhecido pelo povo como o lume do Castro.
Dizem os antigos que esse fogo aparece para revelar o lugar de um tesouro, enterrado nas
ruínas do antigo castro pré-romano que coroa o monte, mas também para avisar os navegantes
de que o mar se aproxima em fúria. O lume brilha e desaparece sem deixar rastro — nem fumo,
nem cheiro, apenas um brilho suspenso entre a terra e o ar.


As recolhas orais de Eduardo Mauer (2024) descrevem o lume como chama viva de cor azul-
esverdeada, que “não aquece, mas ilumina”. Segundo os moradores de Carreço, o lume surge
sempre em silêncio, movendo-se como se respirasse. Há quem diga que é a alma dos antigos
guerreiros do castro, vigiando as suas muralhas, e quem jure tratar-se da moura encantada de
Santa Cruz, que acende o lume para proteger o monte e o mar.
Uma das versões mais poéticas, recolhida junto a um pescador de Areosa, narra que o lume é o
último pensamento do sol antes de dormir. Quando o sol se põe, deixa no monte uma
centelha que o vento do mar conserva até o dia seguinte — um pacto entre o fogo e o oceano.
Mauer descreve o fenómeno como “o mais puro símbolo da consciência luminosa: fogo que
pensa, luz que escuta”.
⸻
2. Contexto histórico e social
O Castro de Santa Cruz, situado em Carreço, é um dos sítios arqueológicos mais antigos de
Viana do Castelo, com ocupação datada do século VIII a.C. até ao período romano. As
escavações revelaram vestígios de habitações circulares, cerâmicas e objetos metálicos, muitos
deles com marcas de fogo ritual.
Na Antiguidade, o fogo tinha valor sagrado: elemento purificador, mediador entre os mundos. Os
habitantes do castro praticavam cultos solares e ritos de transição associados à chama,
acendendo fogueiras nos equinócios e solstícios. Com a romanização, esses rituais foram
assimilados pelas festas cristãs, e o monte passou a ser identi ficado como Monte de Santa
Cruz, símbolo de iluminação espiritual.
Durante a Idade Média, o lume passou a ser visto como sinal divino ou diabólico, conforme o
olhar de cada época. Registos de 1598 referem “fogos ardendo sem se consumir” e “clarões de
luz sobre o monte”, interpretados ora como milagre, ora como presença infernal.
Nos séculos XVIII e XIX, o monte tornou-se ponto de peregrinação. As mulheres de Viana subiam
ao alto nas noites de São João para “ver o lume do destino” — acreditava-se que, quem
avistasse o clarão, casaria antes do ano findar.
Com o tempo, o lume passou a ser metáfora  do espírito da cidade, símbolo da persistência e
da luz interior dos vianenses. No século XXI, a Associação  MILK recuperou o mito como
narrativa ecológica e artística, integrando-o no eixo “Luzes Atlânticas ” do projeto Folclore Vivo.
⸻
3. Toponímia e variantes locais
O nome “Lume do Castro” é comum em Carreço e Areosa, mas a lenda possui variantes:
– “Lume da Moura” (Santa Marta de Portuzelo): chama que protege tesouro subterrâneo;
– “Fogo dos Antigos” (Areosa): luz que marca o local das ruínas sagradas;
– “Luz de Santa Cruz” (Viana do Castelo): interpretação cristianizada da aparição;
– “Olho do Mar” (Montedor): clarão que se acende nas noites de tempestade.
O topónimo “Santa Cruz” aparece pela primeira vez em documentos do século XII, em latim,
como Monte Sanctae Crucis, e já associado à presença de luzes misteriosas. O próprio farol de
Montedor, construído em 1910, herdou o simbolismo do lume, funcionando como “fogo
civilizado” que prolonga a tradição mítica da claridade noturna.
⸻
4. Primeiro relato e fontes académicas primárias

O primeiro relato escrito do Lume do Castro de Santa Cruz surge em Leite de Vasconcelos,
Etnografia Portuguesa, vol. VII (1920, pp. 311–317)*, onde se refere a “luz azulada que arde sobre
o monte de Carreço, reputada pelo povo como fogo sagrado e aviso dos mares”.
Teófilo Braga, O Povo Português  nos seus Costumes, Crenças e Tradições (1885, pp. 697–702)*,
menciona “os fogos das serras do Minho” e interpreta-os como resquício dos antigos cultos ao
deus Lugh, divindade celta da luz.
Alexandre Parafita, Mitologia Popular Portuguesa (2008, pp. 886–893)*, classifica o lume como
manifestação da “energia telúrica luminosa”, típica das lendas atlânticas que unem fogo, vento e
memória.
A sistematização contemporânea de Eduardo Mauer, O Lume do Castro de Santa Cruz: Luz,
Memória e Mar no Imaginário  Atlântico  Português  (Lisboa, Associação MILK, 2025)*, propõe
leitura simbólica em que o lume é compreendido como consciência ecológica luminosa,
expressão material do diálogo entre território e imaginação.
Fontes complementares:
– Museu de Viana do Castelo, Coleção  de Lendas e Tradições de Luz (1970–2018);
– Arquivo Distrital de Braga, Cadernos de Tradição  Atlântica  (1890–1955);
– Tese de Doutoramento de Ricardo Lourenço, Fogo e Mar na Mitologia Atlântica  Portuguesa (U.
Porto, 2020).
⸻
5. Síntese interpretativa final
O Lume do Castro de Santa Cruz representa a presença luminosa do pensamento natural, o
fogo que não destrói, mas revela. É o símbolo da continuidade entre passado e futuro — uma
chama que acende a memória.
Na leitura simbólica da Associação  MILK, o lume é a voz do território: não um milagre, mas a
forma como o mundo comunica a sua própria vitalidade. Ele expressa a fusão entre
conhecimento ancestral e sensibilidade ecológica.
A escultura MILK concebida por Eduardo Mauer apresenta corpo compacto, cabeça grande e
superfície translúcida em tons azul e âmbar. No centro do peito, um núcleo luminoso pulsa
lentamente, representando o lume que respira. A base, de formato irregular, evoca o perfil do
monte. A luz interna é programada para acender e apagar suavemente, simulando o ritmo de um
coração.
Mauer escreve: “O lume é o pensamento da terra ao cair da noite. Quando o sol se apaga, a
montanha pensa em voz baixa.”
⸻
6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer
Na leitura não binária de Eduardo Mauer, o Lume do Castro é energia em transição : fogo e
água, matéria e sopro, luz que pertence a tudo e a nada.
“O lume é corpo de fronteira — nem chama nem sombra, mas relação.”
O fogo, tradicionalmente associado ao masculino, e o mar, ao feminino, encontram aqui
equilíbrio simbiótico, dissolvendo o binarismo dos elementos. A chama azul, fria e
translúcida, é o próprio emblema do não  binário  luminoso: arde sem consumir, ilumina
sem possuir.


A Associação  MILK lê o mito como manifesta ecológica da harmonia energética,
propondo-o como símbolo da convivência entre contrários. O lume torna-se, assim, figura
pedagógica da coexistência e do cuidado, inspirando práticas artísticas que transformam
a luz em ética da presença.
⸻
7. Referência Estrutural da Matriz MILK
Na Matriz Escultórica MILK – Série Folclore Vivo, o Lume do Castro de Santa Cruz
apresenta:
– Corpo: compacto, cabeça grande e tronco ligeiramente arqueado;
– Cores: azul translúcido, âmbar e re flexos verdes;
– Materiais: resina com fibra ótica, pó de quartzo e luz interna programável;
– Expressão:  serena, com olhos semicerrados e sorriso subtil;
– Base: irregular, evocando o monte e o mar.
A escultura integra o eixo “Luzes Atlânticas ” do projeto Folclore Vivo, representando a união
entre território, mito e consciência luminosa.
⸻
Localização  específica: Carreço, Areosa e Santa Marta de Portuzelo (distrito de Viana do
Castelo).
Primeiro relato documentado: Vasconcelos, Etnografia Portuguesa, vol. VII, 1920.
Sistematização  contemporânea:  Eduardo Mauer, O Lume do Castro de Santa Cruz: Luz,
Memória e Mar no Imaginário  Atlântico  Português , Associação MILK, 2025.
Fontes primárias:  Braga (1885); Vasconcelos (1920); Parafita (2008); Lourenço (2020); Mauer
(2025).


---

# 095. A Lenda da Senhora do Nevoeiro de Montedor (Viana do Castelo – Alto Minho Atlântico)

**Origem documental:** PDF `folclore português (1).pdf`, enviado pelo utilizador.  
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

95. A Lenda da Senhora do Nevoeiro de Montedor (Viana do Castelo – Alto Minho Atlântico)
(Sistematização  contemporânea  conduzida por Eduardo Mauer no âmbito  das pesquisas sobre
Folclore Vivo da Associação  MILK – Movimento de Intervenções e Linguagens Kulturais e Arte,
com base em recolhas orais e documentais realizadas entre 2023 e 2025 nas freguesias de
Carreço, Montedor e Afife, cruzadas com fontes etnográ ficas do Museu do Mar de Viana do
Castelo, do Arquivo Distrital de Braga e de estudos contemporâneos  sobre mitologia marítima,
fenomenologia atmosférica  e religiosidade popular atlântica.)
⸻
1. Descrição  simbólica e narrativa
A Lenda da Senhora do Nevoeiro de Montedor é uma das narrativas mais etéreas e poéticas
do imaginário marítimo português. Conta o povo que, nas madrugadas em que o nevoeiro cobre
o farol de Montedor e o som das ondas se mistura ao sino distante das igrejas de Viana, uma
figura feminina translúcida surge entre a névoa, caminhando sobre o ar como se pisasse o
próprio vapor do mar.
A mulher é descrita como alta, envolta num manto cinza-prateado que se confunde com a bruma,
e traz nos olhos a claridade difusa de uma luz antiga. Não fala, não toca — apenas observa os
pescadores que regressam, abrindo com o olhar uma passagem de clareza na cortina de
nevoeiro. Os homens do mar chamam-lhe “Senhora do Nevoeiro”, “Mãe das Luzes” ou
simplesmente “a que vê sem ser vista”.


Segundo as versões recolhidas por Eduardo Mauer (2024), a Senhora é uma entidade protetora
dos navegantes, aparecendo nos dias em que o mar ameaça tragá-los. Muitos pescadores
relatam ter visto a névoa abrir-se subitamente e, por breves segundos, divisarem uma forma
humana diante do farol, antes de encontrarem o rumo de volta ao porto.
Uma das narrativas mais antigas afirma que a Senhora foi outrora uma mulher de Afife, viúva de
marinheiro, que durante anos subia ao monte para acender lamparinas e orientar os barcos.
Certa noite, foi apanhada pelo nevoeiro e desapareceu; na manhã seguinte, encontraram apenas
a lamparina acesa, flutuando sobre a rocha molhada. Desde então, ela torna-se a própria luz
que atravessa a névoa.
Noutras versões, a Senhora é o espírito do próprio mar, guardiã da fronteira entre o visível e o
invisível. O seu corpo é feito de vapor, e o seu coração — dizem os pescadores — “é um farol
que não se apaga”.
Mauer descreve-a como “a presença do cuidado difuso, a claridade que não impõe forma, mas
revela o caminho do regresso.”
⸻
2. Contexto histórico e social
O farol de Montedor, inaugurado em 1910, é o mais setentrional de Portugal continental e desde
então tornou-se centro de inúmeras narrativas populares ligadas à névoa e à salvação dos
navegantes. Contudo, as raízes da lenda remontam a tempos muito anteriores: os registos
paroquiais do século XVII já mencionam “luzes e aparições femininas no nevoeiro de Carreço”,
associadas a promessas e votos de marinheiros.
O nevoeiro, fenómeno natural recorrente no litoral minhoto, sempre foi percebido como fronteira
entre mundos — elemento de perigo e de revelação. Nas comunidades costeiras, ele é
simultaneamente medo e promessa: oculta o caminho, mas protege os segredos do mar.
A figura feminina que emerge da névoa sintetiza essas tensões simbólicas. É ao mesmo tempo
virgem e viúva, humana e etérea, luz e sombra. No século XIX, cronistas como João de Barros e
Leite de Vasconcelos registraram lendas semelhantes em toda a faixa atlântica, mas a versão de
Montedor destaca-se pela dimensão  protetora e ecológica.
Durante o século XX, a Senhora do Nevoeiro passou a fazer parte do repertório das mulheres das
marés — pescadeiras e marisqueiras que, nas manhãs frias, ao verem o nevoeiro baixar,
murmuravam: “A Senhora já desceu.” Era um modo de reconhecer o perigo e simultaneamente
de o apaziguar, invocando a sua presença como salvaguarda.
A lenda, portanto, reflete o modo de vida anfíbio das comunidades marítimas do Minho, onde o
mar é extensão da casa e o nevoeiro, véu da devoção.
⸻
3. Toponímia e variantes locais
O nome “Senhora do Nevoeiro” é mais usado em Carreço e Montedor, mas outras variantes
coexistem:
– “Mãe  da Névoa” (Afife): espírito protetor das marisqueiras;
– “Dona da Claridade” (Viana): aparição luminosa que guia os barcos;
– “Virgem da Bruma” (Areosa): versão cristianizada do mito, associada à pureza e à visão.
A toponímia reforça a relação com a luz e o nevoeiro: “Cabo do Farol”, “Pedra da Lâmpada” e
“Caminho da Névoa” são designações populares que aparecem em mapas e relatos de viajantes
desde o século XVIII.


Em festas religiosas locais, como as procissões marítimas de agosto, as mulheres vestem mantos
brancos ou cinzentos, gesto interpretado como homenagem inconsciente à Senhora do Nevoeiro.
⸻
4. Primeiro relato e fontes académicas primárias
O primeiro registro escrito da lenda surge em Leite de Vasconcelos, Etnografia Portuguesa, vol.
VII (1920, pp. 318–324)*, onde se lê: “Conta o povo de Carreço que uma mulher de manto claro
se mostra no nevoeiro quando o mar brame, e que os navios, ao vê-la, encontram porto seguro.”
Teófilo Braga, O Povo Português  nos seus Costumes, Crenças e Tradições (1885, pp. 703–709)*,
menciona “senhoras brancas do mar que descem com a névoa”, associando-as às antigas
divindades atlânticas da visibilidade e da proteção, herdeiras do culto a Epona e a Dea Maris.
Alexandre Parafita, Mitologia Popular Portuguesa (2008, pp. 894–903)*, descreve o mito como
“expressão marítima do arquétipo feminino da claridade”, símbolo da harmonia entre o perigo e o
cuidado.
A sistematização contemporânea de Eduardo Mauer, A Senhora do Nevoeiro de Montedor:
Claridade, Invisibilidade e Cuidado na Mitologia Atlântica  Portuguesa (Lisboa, Associação MILK,
2025)*, fundamenta-se em entrevistas com pescadores, faroleiros e marisqueiras, interpretando a
lenda como metáfora  da consciência empática  do território, onde o cuidado se manifesta em
forma de névoa e luz.
Fontes complementares:
– Museu do Mar de Viana do Castelo, Coleção  de Relatos do Litoral Norte (1978–2015);
– Arquivo Distrital de Braga, Cadernos de Tradição  Marítima  (1895–1950);
– Tese de Doutoramento de Filipa Costa, Mulheres, Névoa  e Luz: Mitologias Atlânticas  e
Perspectiva de Género  (U. Porto, 2021).
⸻
5. Síntese interpretativa final
A Senhora do Nevoeiro é símbolo do cuidado invisível e da visão  intuitiva. Representa o
princípio da claridade que nasce da obscuridade — a sabedoria que emerge da incerteza.
Na leitura simbólica da Associação  MILK, a Senhora é a pedagogia da delicadeza: não impõe
direção, mas permite ver. A névoa, longe de ser obstáculo, torna-se meio de percepção ampliada
— a possibilidade de encontrar orientação mesmo na ausência de contornos.
A escultura MILK concebida por Eduardo Mauer traduz esse conceito num corpo esguio,
compacto e translúcido, de tons cinza-pérola e re flexos azulados. A cabeça grande mantém
olhos semicerrados e sorriso discreto. A superfície é opalescente, alternando transparência e
opacidade conforme a luz. Um mecanismo interno de vapor leve cria fina névoa contínua ao redor
da escultura, transformando-a em objeto atmosférico.
Mauer escreve: “A Senhora do Nevoeiro é a visão do silêncio: o instante em que o invisível se
torna terno.”
⸻
6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer
Na leitura não binária de Eduardo Mauer, a Senhora do Nevoeiro dissolve as fronteiras entre
corpo e ambiente, gênero e substância.


“Ela não é mulher nem vento — é o gesto de ver sem dominar.”
O nevoeiro é matéria ambígua: cobre e revela, esconde e protege. Por isso, a Senhora
torna-se emblema do não  binário  atmosférico, ser feito de presença difusa, sem limites
definidos.
A Associação  MILK lê o mito como paradigma da visibilidade fluida, conceito central do
Folclore Vivo, em que o reconhecimento do outro se dá pela empatia, não pela de finição.
A Senhora do Nevoeiro ensina o olhar da inclusão — ver o que não  se vê, acolher o que
não  se distingue.
⸻
7. Referência Estrutural da Matriz MILK
Na Matriz Escultórica MILK – Série Folclore Vivo, a Senhora do Nevoeiro de Montedor
apresenta:
– Corpo: esguio e compacto, cabeça grande e inclinação suave;
– Cores: cinza-pérola, azul-neblina e re flexos prateados;
– Materiais: resina translúcida, difusor de vapor interno e verniz opalescente;
– Expressão:  serena, com olhos semicerrados e sorriso leve;
– Base: circular, imitando ondulação de ar e mar.
A escultura integra o eixo “Luzes Atlânticas  e Corpos Difusos” do projeto Folclore Vivo, sendo
apresentada como símbolo da empatia atmosférica — o corpo que acolhe o invisível.
⸻
Localização  específica: Carreço, Montedor e Afife (distrito de Viana do Castelo).
Primeiro relato documentado: Vasconcelos, Etnografia Portuguesa, vol. VII, 1920.
Sistematização  contemporânea:  Eduardo Mauer, A Senhora do Nevoeiro de Montedor:
Claridade, Invisibilidade e Cuidado na Mitologia Atlântica  Portuguesa, Associação MILK, 2025.
Fontes primárias:  Braga (1885); Vasconcelos (1920); Parafita (2008); Costa (2021); Mauer (2025).


---

# 096. A Lenda da Pedra do Sono de Ponte de Lima (Vale do Lima – Alto Minho)

**Origem documental:** PDF `folclore português (1).pdf`, enviado pelo utilizador.  
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

96. A Lenda da Pedra do Sono de Ponte de Lima (Vale do Lima – Alto Minho)
(Sistematização  contemporânea  conduzida por Eduardo Mauer no âmbito  das pesquisas sobre
Folclore Vivo da Associação  MILK – Movimento de Intervenções e Linguagens Kulturais e Arte,
com base em recolhas orais e documentais realizadas entre 2023 e 2025 nas freguesias de
Arcozelo, Facha e Gemieira, cruzadas com fontes etnográ ficas do Museu dos Terceiros de Ponte
de Lima, do Arquivo Municipal e de estudos contemporâneos  sobre simbologia do sono,
topografia mítica  e práticas  votivas rurais do norte de Portugal.)
⸻
1. Descrição  simbólica e narrativa
A Lenda da Pedra do Sono constitui uma das mais delicadas expressões do imaginário limiano,
onde a pedra e o corpo adormecido se encontram num mesmo território simbólico. No sopé de
um monte entre Arcozelo e Gemieira, ergue-se uma rocha lisa e arredondada, coberta de musgo
e marcada por pequenas concavidades naturais. O povo diz que essa pedra tem o poder de
fazer adormecer quem nela se deita, levando o visitante a um sono profundo, sereno e, por
vezes, revelador.
Nas narrativas recolhidas por Eduardo Mauer (2024), há quem diga que o sono é “tão fundo que
parece morte, mas é descanso de alma”. Outros a firmam que os sonhos tidos sobre a pedra

anunciam o futuro ou revelam segredos ocultos. A lenda mais antiga conta que, durante o verão,
pastores e viajantes, cansados do calor, repousavam à sombra da pedra e acordavam horas
depois, sentindo-se mais leves e silenciosos, como se tivessem sido visitados por uma força
invisível.
Há também versões que a associam a ritos de fertilidade e à presença de mouras encantadas.
Segundo estas, uma moura dorme sob a pedra desde tempos imemoriais, e o seu sono mantém
o equilíbrio do vale. Se alguém tentar despertá-la, a terra adormecerá para sempre. Acredita-se
que nas noites de lua cheia, quem encosta o ouvido à pedra ouve uma respiração compassada
— o coração da moura, ou talvez o próprio som do mundo em repouso.
Outros relatos, de caráter cristianizado, dizem que a pedra adormece apenas os impuros, para os
afastar das tentações. Já entre as crianças, é conhecida como “pedra do descanso do anjo”,
porque, segundo as mães, foi ali que um anjo se deitou para dormir antes de levar o primeiro
sonho ao mundo.
Mauer descreve a Pedra do Sono como “um altar horizontal de quietude, o ponto em que a terra
suspira em corpo humano”.
⸻
2. Contexto histórico e social
A presença de rochas com propriedades mágicas é recorrente no norte de Portugal, sobretudo
nas regiões de Trás-os-Montes e do Minho. Muitas dessas pedras foram locais de culto pré-
cristão, associados à regeneração, ao repouso e à comunicação com o invisível. A Pedra do
Sono de Ponte de Lima insere-se nesse continuum simbólico, conjugando as tradições célticas
de culto à terra com as crenças populares sobre o poder curativo do repouso natural.
O vale do Lima, fértil e envolto em névoas matinais, é região historicamente marcada por práticas
de peregrinação e por rituais agrários. As fontes paroquiais do século XVII já mencionam “um
penedo em que os fatigados adormecem e sonham bons presságios”. O sono, aqui, não é mera
inércia, mas ato espiritual de escuta.
No século XIX, etnógrafos como Rocha Peixoto e Leite de Vasconcelos registraram lendas
semelhantes em pedras do Minho, associadas a sonhos proféticos. Para o povo limiano, deitar-se
na pedra é gesto de reconexão com o ritmo da natureza — dormir sobre a terra é regressar ao
seio materno do mundo.
Hoje, o local é visitado por caminhantes e curiosos, sobretudo durante o verão. Muitos relatam
sensação de calma profunda, um “silêncio que se estende para dentro”. A pedra continua a ser
espaço de mediação entre o corpo e a paisagem, entre o humano e o tempo.
⸻
3. Toponímia e variantes locais
A designação “Pedra do Sono” é a mais comum nas freguesias de Arcozelo e Gemieira, mas o
sítio também é conhecido por outros nomes:
– “Penedo do Descanso” (Facha): enfatiza a função de repouso e serenidade;
– “Cama da Moura” (Gemieira): relaciona-se às versões encantadas;
– “Pedra do Sonho” (Ponte de Lima): forma mais recente, difundida por viajantes e poetas.
O topónimo “sono” aparece já no Tombo da Igreja de Arcozelo (1682), que menciona “o penedo
grande do somno junto ao regato”, atestando a antiguidade da crença.
Algumas versões orais ligam a pedra a caminhos de Santiago. Peregrinos que por ali passavam
descansavam na rocha e diziam sonhar com luzes douradas e trilhos claros, tomando isso
como bênção para o prosseguimento da jornada.


A associação entre pedra e sonho revela uma constante simbólica da cultura minhota: a pedra
não é obstáculo, mas superfície de revelação , espelho mineral onde a alma se reflete ao
adormecer.
⸻
4. Primeiro relato e fontes académicas primárias
O primeiro registro conhecido da Pedra do Sono surge em Leite de Vasconcelos, Etnografia
Portuguesa, vol. VIII (1923, pp. 41–45)*, onde se descreve “penedo liso em Ponte de Lima, a que
o povo atribui virtude de adormecer os corpos e sossegar os espíritos”.
Teófilo Braga, O Povo Português  nos seus Costumes, Crenças e Tradições (1885, pp. 710–714)*,
menciona “as pedras do sono e do sonho do Minho”, associando-as aos antigos cultos da terra e
à crença céltica de que o sono é forma de morte temporária.
Alexandre Parafita, Mitologia Popular Portuguesa (2008, pp. 904–912)*, insere a lenda no
conjunto das “pedras do repouso”, interpretando-a como símbolo de reconciliação entre corpo e
território.
A sistematização contemporânea de Eduardo Mauer, A Pedra do Sono de Ponte de Lima: O
Corpo Adormecido e a Terra como Memória (Lisboa, Associação MILK, 2025)*, baseia-se em
entrevistas com moradores e caminhantes, propondo uma leitura fenomenológica e ecológica do
mito, em que o adormecer se torna experiência estética e espiritual.
Fontes complementares:
– Museu dos Terceiros de Ponte de Lima, Coleção  de Lendas do Vale do Lima (1970–2018);
– Arquivo Municipal de Ponte de Lima, Registos Orais e Cadernos de Campo (1890–1960);
– Tese de Doutoramento de Maria Seabra, Sono e Terra: Antropologia do Repouso na Cultura
Popular Portuguesa (U. Minho, 2020).
⸻
5. Síntese interpretativa final
A Pedra do Sono é a materialização da inteligência do repouso. O seu poder simbólico reside
na inversão da lógica da vigília: o saber nasce do descanso, e o sonho é forma de conhecimento.
Na leitura simbólica da Associação  MILK, a pedra é o primeiro leito do mundo — um espaço
de entrega, onde o corpo cessa e o espírito observa. O sono, longe de ser inatividade, é criação
silenciosa.
A escultura MILK concebida por Eduardo Mauer traduz esse princípio num corpo compacto e
reclinado, de linhas suaves e textura terrosa. A cabeça grande repousa lateralmente sobre a
base, os olhos fechados e o rosto sereno. A superfície combina tons ocres e dourados, evocando
o brilho do sol filtrado por pálpebras. Um discreto sistema sonoro interno emite um som contínuo
de respiração, simbolizando o ritmo universal do descanso.
Mauer escreve: “Dormir é conversar com a terra. A Pedra do Sono é o ouvido do mundo que
escuta o que ainda não dissemos.”
⸻
6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer

Na leitura não binária de Eduardo Mauer, a Pedra do Sono é o corpo que abdica de fronteiras
— nem masculino nem feminino, nem ativo nem passivo, mas simplesmente presente.
“Adormecer é o gesto mais não binário da natureza: é suspender o papel, dissolver o
nome, tornar-se respiração.”
O mito ensina que o repouso é forma de resistência à violência produtivista e à lógica dual
do fazer e não fazer. O sono é, nesta leitura, ato político e poético de desidentificação
— momento em que o corpo regressa ao anonimato da matéria e encontra igualdade com
tudo o que existe.
A Associação  MILK interpreta a lenda como pedagogia do descanso inclusivo: o direito
de existir sem função, de permanecer em pausa como a firmação de dignidade. A pedra
adormecida é metáfora da convivência pací fica entre contrários, onde o repouso é forma
de comunhão universal.
⸻
7. Referência Estrutural da Matriz MILK
Na Matriz Escultórica MILK – Série Folclore Vivo, a Pedra do Sono de Ponte de Lima
apresenta:
– Corpo: reclinado, cabeça grande e corpo compacto;
– Cores: ocres, dourados e suaves tons terrosos;
– Materiais: resina pigmentada com pó mineral, som ambiente respiratório;
– Expressão:  serena, com olhos fechados e boca relaxada;
– Base: curva, simulando encosta e repouso.
A escultura integra o eixo “Corpo e Terra” do projeto Folclore Vivo, dedicado às entidades
ligadas ao descanso, à regeneração e à escuta profunda da paisagem.
⸻
Localização  específica: Arcozelo, Facha e Gemieira (Ponte de Lima, distrito de Viana do
Castelo).
Primeiro relato documentado: Vasconcelos, Etnografia Portuguesa, vol. VIII, 1923.
Sistematização  contemporânea:  Eduardo Mauer, A Pedra do Sono de Ponte de Lima: O Corpo
Adormecido e a Terra como Memória, Associação MILK, 2025.
Fontes primárias:  Braga (1885); Vasconcelos (1923); Parafita (2008); Seabra (2020); Mauer
(2025).


---

# 097. O Fadinho – O Cantor Luso-Brasileiro Mitológico

**Origem documental:** PDF `folclore português (1).pdf`, enviado pelo utilizador.  
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

97. O Fadinho – O Cantor Luso-Brasileiro Mitológico
(Sistematização  contemporânea  conduzida por Eduardo Mauer no âmbito  das pesquisas sobre
Folclore Vivo da Associação  MILK – Movimento de Intervenções e Linguagens Kulturais e Arte,
com base em recolhas orais e documentais realizadas entre 2023 e 2025 em Lisboa, Almada,
Belém,  Salvador da Bahia e Porto Seguro, cruzadas com fontes históricas sobre o ciclo das
navegações atlânticas  e a génese  musical do fado e do lundu.)
⸻
1. Descrição  simbólica e narrativa
O Fadinho é um ser híbrido e transatlântico, figura diminuta de voz luminosa, considerado pelos
pescadores e boémios de Lisboa o primeiro cantor das margens do Tejo. Segundo a tradição
oral recolhida por Eduardo Mauer (2024), o Fadinho não nasceu em Portugal nem no Brasil, mas

no próprio mar, durante a travessia das primeiras caravelas que regressavam do Novo Mundo.
Era metade menino, metade brisa, corpo pequeno e redondo, cabeça grande, cabelos negros
encaracolados e olhos profundos que pareciam conter música.
Diz-se que o Fadinho voava sobre as velas das embarcações, guiando-as com o som da sua
voz. A cada porto que tocava, deixava uma melodia nova — mistura de lundu africano, canto
indígena e ladainha portuguesa. Quando as caravelas chegaram a Lisboa, o Fadinho pousou nas
águas do Tejo e, com um sopro, fez nascer o primeiro fado: uma canção de saudade e travessia.
Nas suas aparições, o Fadinho manifesta-se à noite, junto a guitarras ou lamparinas. Quem o
ouve cantar sente-se tocado por emoção inexplicável — uma melancolia doce, descrita nos
testemunhos de marinheiros do século XIX como “choro que consola”. É considerado espírito
tutelar dos fadistas, guardião das vozes marginalizadas e dos poetas de esquina.
Entre as versões brasileiras, o Fadinho aparece nas praias da Bahia como menino alado de pés
descalços, que canta modinhas antigas e acalma as tempestades. Em Lisboa, dizem que
percorre Alfama e Mouraria durante as madrugadas, soprando versos aos guitarristas. O povo
acredita que o Fadinho é imortal, feito de ar e lembrança — “voz que o mar deixou no vento”.
Mauer descreve-o como “primeiro imigrante mítico do Atlântico , mediador entre o som e o
corpo, entre Brasil e Portugal, entre o humano e o invisível.”
⸻
2. Contexto histórico e social
A figura do Fadinho está enraizada na história cultural das duas margens do Atlântico. As
navegações quinhentistas criaram redes de troca sonora entre Portugal, África e Brasil; dessas
mestiçagens nasceu o que mais tarde se chamaria fado, género que sintetiza dor, ironia e
esperança.
Os primeiros registos musicais do fado, datados do século XVIII, surgem em Lisboa como
expressão  urbana da marginalidade, incorporando elementos de danças afro-brasileiras e
ritmos marítimos. No imaginário popular, o Fadinho encarna esse nascimento mestiço — um
génio que “sopra melodias onde o povo chora”.
Durante o século XIX, com a consolidação do fado nas tavernas e nos cais, multiplicaram-se as
lendas sobre o “menino da guitarra invisível”. Cronistas como Norberto de Araújo e Júlio César
Machado registraram histórias de fadistas que juravam ouvir uma voz etérea acompanhando-os
nos becos de Lisboa.
No Brasil, viajantes como Debret e Rugendas descreveram práticas musicais em que cantadores
populares invocavam um “anjo do canto” antes das modinhas — eco do mesmo arquétipo. A
fusão dos dois mundos gerou o mito transcontinental: o Fadinho como espírito da canção  luso-
brasileira, símbolo da diáspora afetiva.
No século XX, com a consagração do fado como património, o Fadinho passou a ser interpretado
por estudiosos como metáfora  da alma coletiva: a voz anónima do povo que resiste através da
arte.
⸻
3. Toponímia e variantes locais
A lenda apresenta variantes significativas:
– Fadinho do Tejo (Lisboa): espírito que surge nas madrugadas sobre o rio;
– Menino da Voz Clara (Alfama e Mouraria): protetor das cantadeiras e das guitarras;
– Anjinho do Lundu (Salvador da Bahia): pequeno ser que ensina melodias a pescadores;


– Cantador das Ondas (Porto Seguro): voz que anuncia calmarias após as tempestades.
Em todos os casos, o Fadinho liga-se à água e ao ar. A sua toponímia deriva quase sempre de
portos e ribeiras. O “Cais do Fadinho”, em relatos oitocentistas de Lisboa, seria o ponto onde os
marinheiros ouviam “um canto sem corpo” nas noites de nevoeiro.
A tradição oral do Tejo associa-lhe uma frase ritual: “ Canta, Fadinho, canta baixinho, que o mar
quer dormir” — verso ainda entoado em algumas marchas populares.
⸻
4. Primeiro relato e fontes académicas primárias
O primeiro relato escrito de caráter etnográ fico encontra-se em Teófilo Braga, O Povo Português
nos seus Costumes, Crenças e Tradições (1885, pp. 715–721)*, onde o autor menciona “um
pequeno ser aéreo que inspira o canto popular nas margens do Tejo”.
Leite de Vasconcelos, Etnografia Portuguesa, vol. VIII (1923, pp. 50–54)*, recolhe testemunhos
de pescadores de Belém sobre “o fadinho do rio”, relacionando-o a antigos mitos das ondinas e
nereidas.
Alexandre Parafita, Mitologia Popular Portuguesa (2008, pp. 913–921)*, inclui o Fadinho entre as
“entidades híbridas do mar e do som”, interpretando-o como arquétipo da voz da travessia.
A sistematização contemporânea de Eduardo Mauer, O Fadinho – Espírito  Luso-Brasileiro do
Som e da Saudade (Lisboa, Associação MILK, 2025)*, combina investigação histórica com
recolhas orais em Lisboa e Bahia, propondo leitura mitopoética do Fadinho como figura liminar
da modernidade atlântica .
Fontes complementares:
– Museu do Fado (Lisboa), Coleção  de Testemunhos Orais (1900–2020);
– Arquivo Histórico da Bahia, Relatos do Lundu e da Modinha (1760–1830);
– Tese de Doutoramento de Helena Pereira, Entre o Lundu e o Fado: Genealogias Atlânticas  da
Canção  Popular (U. Lisboa, 2019).
⸻
5. Síntese interpretativa final
O Fadinho representa a voz originária  da saudade, o ponto de contacto entre dois mundos. O
seu canto é rito de pertença, invocação do comum. Ele sintetiza o encontro de África, Brasil e
Portugal em linguagem sonora de emoção e memória.
Na leitura simbólica da Associação  MILK, o Fadinho é o sopro do imaginário  atlântico : corpo
diminuto que transporta o ritmo do mar e a melodia do tempo. Ele encarna o gesto da escuta —
a arte de ouvir antes de cantar.
A escultura MILK concebida por Eduardo Mauer traduz essas ideias num corpo compacto e
arredondado, de cabeça grande e sorriso sarcástico, semelhante ao Cavalum na matriz formal.
As cores variam entre azul-profundo, vermelho-sangue e dourado, evocando o Atlântico e as
guitarras lisboetas. O Fadinho segura nas mãos um pequeno instrumento híbrido entre
cavaquinho e guitarra. A base circular, pintada com espirais, representa as ondas sonoras.
Mauer descreve: “O Fadinho é o eco que se fez corpo. É a respiração do mar quando a guitarra
ainda não sabia existir.”
⸻


6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer
Na leitura não binária de Eduardo Mauer, o Fadinho dissolve fronteiras de género, origem e
corpo.
“Ele canta com voz de homem e de mulher, de velho e de criança, porque o som não tem
sexo.”
O Fadinho é símbolo de identidade acústica fluida, figura de mediação entre culturas e
expressões. O seu corpo pequeno e andrógeno representa a neutralidade vibrante da voz
— existência que só se cumpre no ato de cantar.
A Associação  MILK lê o mito como manifesto não  binário  da arte: a voz como espaço
de transição, onde as diferenças se harmonizam em frequência comum. O Fadinho ensina
que cantar é partilhar respiração, não dominar forma.
Nesta leitura contemporânea, ele é figura pedagógica da escuta diversa — símbolo de
comunicação sem hegemonia, de relação sem hierarquia.
⸻
7. Referência Estrutural da Matriz MILK
Na Matriz Escultórica MILK – Série Folclore Vivo, o Fadinho apresenta:
– Corpo: compacto, cabeça grande, braços curtos, postura inclinada como quem escuta;
– Cores: azul-atlântico, vermelho profundo e dourado melódico;
– Materiais: resina pigmentada com pó metálico e acabamento em verniz marítimo;
– Expressão:  sorriso sarcástico e olhar terno;
– Base: circular, com espirais pintadas que simbolizam ondas e som.
A escultura integra o eixo “Vozes do Atlântico ” do projeto Folclore Vivo, dedicado aos seres
mitológicos que representam a comunicação, a música e a memória intercultural.
⸻
Localização  específica: Lisboa (Alfama, Belém), Salvador da Bahia e Porto Seguro.
Primeiro relato documentado: Braga, O Povo Português  nos seus Costumes, Crenças e
Tradições, 1885.
Sistematização  contemporânea:  Eduardo Mauer, O Fadinho – Espírito  Luso-Brasileiro do Som e
da Saudade, Associação MILK, 2025.
Fontes primárias:  Braga (1885); Vasconcelos (1923); Parafita (2008); Pereira (2019); Mauer
(2025).


---

# 098. A Lenda do Cervo da Lua de Castro Laboreiro (Melgaço – Peneda-Gerês)

**Origem documental:** PDF `folclore português (1).pdf`, enviado pelo utilizador.  
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

98. A Lenda do Cervo da Lua de Castro Laboreiro (Melgaço – Peneda-Gerês)
(Sistematização  contemporânea  conduzida por Eduardo Mauer no âmbito  das pesquisas sobre
Folclore Vivo da Associação  MILK – Movimento de Intervenções e Linguagens Kulturais e Arte,
com base em recolhas orais e documentais realizadas entre 2023 e 2025 em Castro Laboreiro,
Lamas de Mouro e Seara, cruzadas com fontes etnográ ficas do Museu de Melgaço, do Parque
Nacional da Peneda-Gerês  e de estudos académicos  sobre mitologia zoomórfica, simbologia
lunar e tradições caçadeiras do Alto Minho e Trás-os-Montes.)
⸻
1. Descrição  simbólica e narrativa

Entre as serras altas e vales brumosos de Castro Laboreiro, onde o vento parece guardar
segredos antigos, vive na memória popular a história do Cervo da Lua, uma criatura luminosa e
silenciosa que aparece nas noites de luar intenso. Os habitantes das aldeias dizem que se trata
de um animal sagrado, de pelagem prateada e olhos que refletem o céu, capaz de desaparecer
no ar sem deixar pegadas.
Conta a tradição que o Cervo da Lua surge apenas quando o luar toca os cumes do Castelo de
Castro Laboreiro e o rio Laboreiro reflete o brilho das estrelas. A sua aparição é considerada
presságio  de transformação : anuncia o nascimento de uma criança especial, o falecimento de
um justo ou a mudança das estações.
Os mais antigos descrevem-no com cornos em forma de arco crescente, que cintilam como
lâminas de luz. É silencioso, e o seu passo não produz som. Em certas versões, o Cervo é
acompanhado por um pequeno séquito de luzes brancas — espíritos das montanhas que
dançam à sua volta. Quem o avista sente-se tomado por paz e melancolia, uma emoção
indefinível que o povo chama de “peso da beleza”.
As recolhas de Eduardo Mauer (2024) documentam relatos de pastores e guardas florestais que
afirmam ter visto, em noites frias, “uma sombra prateada subir pela encosta e fundir-se com o
luar”. Alguns descrevem-no como guardião das fontes puras; outros, como alma de um caçador
penitente transformado em animal.
Uma versão antiga da aldeia de Rodeiro conta que o Cervo da Lua era outrora um jovem pastor
que amava a filha da lua. Como o amor entre céu e terra era impossível, pediu-lhe que o
tornasse animal para poder contemplá-la todas as noites. Ela concedeu-lhe o pedido, e desde
então ele corre pelas serras a persegui-la, sem nunca alcançá-la.
Mauer resume o mito numa frase: “O Cervo da Lua é o movimento do desejo que ilumina o
escuro — corpo que persegue o inatingível e, por isso, torna o mundo visível.”
⸻
2. Contexto histórico e social
Castro Laboreiro é território de tradições pastorícias milenares. Desde a Idade do Bronze, os
cervos foram animais totémicos nas comunidades da Peneda-Gerês, associados à fertilidade, à
força e à regeneração. Gravuras rupestres com figuras de cervídeos existem em montes vizinhos,
como as de Lamas de Mouro e Parada do Monte, indicando a presença de um culto cinegético
ancestral.
Durante a romanização, o cervo foi incorporado às simbologias de Diana, deusa da caça e da lua,
e, posteriormente, reinterpretado pela religiosidade cristã como símbolo da alma que busca a
luz divina — imagem encontrada em inscrições medievais e em vitrais de igrejas da região.
No imaginário popular, a caça ao cervo assumiu caráter ritual. Os caçadores das montanhas de
Melgaço acreditavam que matar um cervo branco trazia desgraça, pois o animal seria
mensageiro das almas dos mortos. Essa interdição simbólica perpetuou o respeito pela criatura e
manteve viva a sua aura sagrada.
O mito do Cervo da Lua inscreve-se nesse cruzamento entre paganismo e espiritualidade cristã,
natureza e mistério. Na sociedade contemporânea, a figura reaparece como símbolo de
resistência ecológica, representando o espírito das montanhas ameaçadas pela desertificação e
pelo esquecimento.
Em 2025, a Associação  MILK, sob coordenação de Eduardo Mauer, iniciou um projeto de
documentação artística na região de Castro Laboreiro, recolhendo testemunhos de habitantes
locais e articulando o mito com práticas de conservação ambiental, ligando o imaginário
folclórico à ecologia contemporânea.


⸻
3. Toponímia e variantes locais
A lenda apresenta variantes que se distribuem pelo território fronteiriço entre Portugal e Galiza:
– Cervo da Lua (Castro Laboreiro): versão mais antiga e simbólica;
– Veado Branco da Serra (Lamas de Mouro): associado ao renascimento da natureza após o
inverno;
– Veado das Sombras Claras (Seara e Parada do Monte): ligado às almas penadas dos
caçadores;
– Cervo de Prata (Entrimo, Galiza): figura espelhada na tradição galega, relacionada ao culto
lunar e às danças noturnas.
O topónimo “Castro da Lua” é mencionado em documentos seiscentistas do arquivo de Melgaço,
referindo-se a uma elevação próxima do castelo onde se viam “luzeiros errantes e animais
brancos nas madrugadas”.
As variantes indicam um núcleo mítico comum na região transfronteiriça, em que a montanha é
lugar de transfiguração.
⸻
4. Primeiro relato e fontes académicas primárias
O primeiro registro escrito da lenda do Cervo da Lua surge em Leite de Vasconcelos, Etnografia
Portuguesa, vol. IX (1925, pp. 112–118)*, que descreve “o cervo branco das serras de Castro
Laboreiro, visto em noites de luar, e tido como espírito guardião das águas e dos rebanhos”.
Teófilo Braga, O Povo Português  nos seus Costumes, Crenças e Tradições (1885, pp. 722–727)*,
menciona a crença no “veado da claridade”, ser ligado à lua e às tempestades, associando-o à
persistência de mitos célticos.
Alexandre Parafita, Mitologia Popular Portuguesa (2008, pp. 922–931)*, inclui o Cervo da Lua
entre as “entidades luminíferas da fauna sagrada”, relacionando-o a cultos lunares e à tradição
do cervo psicopompo (condutor das almas).
A sistematização contemporânea de Eduardo Mauer, O Cervo da Lua: Animal de Luz e Desejo
nas Montanhas Atlânticas  (Lisboa, Associação MILK, 2025)*, interpreta o mito como figura
liminar entre o visível e o etéreo, e como metáfora ecológica do equilíbrio entre o humano e o
selvagem.
Fontes complementares:
– Museu de Melgaço, Coleção  de Relatos do Alto Minho (1975–2019);
– Arquivo Municipal de Melgaço, Crónicas do Castro e da Serra (1880–1940);
– Tese de Doutoramento de Luís Cerdeira, Fauna e Mitologia nas Terras de Barroso e Peneda-
Gerês  (U. Porto, 2021).
⸻
5. Síntese interpretativa final
O Cervo da Lua representa o princípio luminoso da natureza viva, a força silenciosa que habita
o escuro. A sua imagem une o animal e o astro, o terrestre e o celeste, constituindo uma das
metáforas mais poderosas do imaginário penedense.


Na leitura simbólica da Associação  MILK, o cervo é o corpo do desejo ecológico — impulso
de comunhão entre o humano e o natural. A sua perseguição eterna à lua simboliza a busca
incessante por harmonia, beleza e sentido.
A escultura MILK concebida por Eduardo Mauer apresenta corpo compacto, cabeça grande e
olhos alongados, seguindo a matriz padrão. As hastes do cervo, curvadas como luas crescentes,
são translúcidas e iluminadas internamente. As cores predominantes são branco-prateado, azul
profundo e reflexos lilás. O corpo, de textura lisa, re flete a luz ambiente, criando efeito de
presença mutável.
Mauer escreve: “O Cervo da Lua não é caçado nem caçador — é o instante em que o olhar toca
a luz e se reconhece na sua própria procura.”
⸻
6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer
Na leitura não binária de Eduardo Mauer, o Cervo da Lua transcende as categorias tradicionais
de gênero, espécie e forma.
“É corpo que não pertence a um só reino: metade carne, metade claridade.”
A sua luz não é masculina nem feminina, mas uma vibração que habita ambos. O cervo,
ao perseguir a lua, expressa o movimento do não  binário  natural — coexistência sem
oposição, transformação sem hierarquia.
A Associação  MILK entende o mito como pedagogia ecológica da transição: aprender
com o cervo o gesto de seguir sem possuir. Ele ensina que a identidade é trajetória, não
essência. O seu brilho é a voz da metamorfose.
⸻
7. Referência Estrutural da Matriz MILK
Na Matriz Escultórica MILK – Série Folclore Vivo, o Cervo da Lua de Castro Laboreiro
apresenta:
– Corpo: compacto, cabeça grande, membros curtos e hastes translúcidas;
– Cores: branco-prateado, azul profundo, lilás lunar;
– Materiais: resina translúcida com fibra de vidro e iluminação interna;
– Expressão:  calma e melancólica, olhar voltado para cima;
– Base: circular, com relevo ondulado que evoca a serra e o luar.
A escultura integra o eixo “Animais de Luz” do projeto Folclore Vivo, dedicado às entidades
híbridas que expressam o diálogo entre natureza, espiritualidade e imaginação contemporânea.
⸻
Localização  específica: Castro Laboreiro, Lamas de Mouro, Seara (distrito de Viana do Castelo).
Primeiro relato documentado: Vasconcelos, Etnografia Portuguesa, vol. IX, 1925.
Sistematização  contemporânea:  Eduardo Mauer, O Cervo da Lua: Animal de Luz e Desejo nas
Montanhas Atlânticas , Associação MILK, 2025.
Fontes primárias:  Braga (1885); Vasconcelos (1925); Parafita (2008); Cerdeira (2021); Mauer
(2025).
