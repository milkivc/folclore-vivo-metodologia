# Corpus integral auditado — parte 09

Entradas 113 a 126.



---

# 113. A Lenda da Sombra do Barqueiro do Lima (Ponte de Lima – Alto Minho)

**Origem documental:** PDF `folclore português (1).pdf`, enviado pelo utilizador.  
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

113. A Lenda da Sombra do Barqueiro do Lima (Ponte de Lima – Alto Minho)
(Sistematização  contemporânea  conduzida por Eduardo Mauer no âmbito  das pesquisas sobre
Folclore Vivo da Associação  MILK – Movimento de Intervenções e Linguagens Kulturais e Arte,
com base em recolhas orais e documentais realizadas entre 2023 e 2025 em Ponte de Lima,
Arcozelo, Gemieira e Labruja, cruzadas com fontes etnográ ficas do Museu dos Terceiros, do
Arquivo Municipal de Ponte de Lima e de estudos académicos  sobre mitologia fluvial,
psicopompos e simbologia da travessia na tradição  minhota.)
⸻


1. Descrição  simbólica e narrativa
Nas margens lentas e translúcidas do rio Lima, que os antigos romanos chamaram Lethes — o
Rio do Esquecimento —, ainda se conta a história do Barqueiro e da sua Sombra. O povo
acredita que, ao cair da noite, quando o nevoeiro cobre as águas, uma barca silenciosa desliza
sobre o espelho do rio, conduzida por uma figura encapuzada. Mas quem observa de perto
percebe que o barqueiro não tem sombra — ou, segundo outras versões, que apenas a sombra
rema.
A lenda, recolhida por Eduardo Mauer (2024) em entrevistas com pescadores e moradores de
Arcozelo e Gemieira, descreve o barqueiro como um homem que em vida transportava viajantes
de uma margem a outra, até morrer durante uma travessia num inverno tempestuoso. Desde
então, dizem que ele regressa todas as noites de neblina para continuar a cumprir a sua função,
conduzindo não corpos, mas almas.
Em certas noites, ouve-se o som do remo a cortar a água, embora ninguém veja a barca. Quando
a lua está cheia, vê-se um vulto escuro e, ao seu lado, um re flexo sem corpo: a sombra. Reza o
ditado local: “No Lima, é a sombra que rema, e o barqueiro que descansa.”
Numa das versões antigas, colhida por Mauer junto de uma idosa de Labruja, o barqueiro teria
feito pacto com o rio. Em troca da travessia das almas, ganharia o direito de jamais desaparecer.
Assim, tornou-se psicopompo minhoto, mediador entre a terra e a água, entre o tempo e o
esquecimento.
Em outras versões, é a própria sombra que ganha consciência: cansada de seguir o homem,
liberta-se e assume o comando da barca. O mito passa então a re fletir o conflito entre matéria e
reflexo, identidade e ausência.
Mauer resume: “O Barqueiro do Lima é o guardião da travessia, e a sua sombra é a consciência
do que se perde ao atravessar.”
⸻
2. Contexto histórico e social
O rio Lima ocupa um lugar central no imaginário português. Durante a romanização, era
conhecido como Lethes (o Letes da mitologia grega), rio que apagava a memória dos que o
atravessavam. Quando o general Décimo Júnio Bruto quis conduzir o seu exército para o norte,
os soldados recusaram-se a cruzar, temendo esquecer-se de si mesmos. Desde então, o rio
tornou-se símbolo de fronteira entre lembrança e esquecimento.
Na tradição local, o barqueiro representa o ofício de ligação — figura de mediação social e
espiritual. Durante séculos, barqueiros foram personagens essenciais das comunidades
ribeirinhas, responsáveis por transportar pessoas, gado e mercadorias entre margens.
Com o advento das pontes de pedra (séculos XVII–XVIII), o ofício entrou em declínio, mas
persistiu no imaginário. O barqueiro passou de trabalhador a figura liminar, habitando o espaço
entre vida e morte.
A lenda da Sombra do Barqueiro inscreve-se nesse contexto de transição  simbólica. O rio,
outrora via de comércio, converte-se em espelho de interioridade. A sombra surge como
metáfora da alma que se desprende, guiando o corpo ausente.
No século XX, poetas e artistas locais retomaram o mito, especialmente nas décadas de 1960–
1970, quando o modernismo português redescobriu a tradição popular como campo de
experimentação estética.


A Associação  MILK, sob a coordenação de Eduardo Mauer, inclui esta lenda no eixo
“Travessias e Ecos”, propondo uma leitura que une mito, arte contemporânea e filosofia da
memória.
⸻
3. Toponímia e variantes locais
A lenda possui registros e variantes em diversas freguesias ribeirinhas do Lima:
– Ponte de Lima: “O Barqueiro sem Sombra”;
– Arcozelo: “A Barca das Almas”;
– Gemieira: “O Remador do Nevoeiro”;
– Labruja: “A Travessia dos Mortos”.
O topónimo “Porto do Esquecido” aparece em mapas do século XVIII, possivelmente
relacionado à tradição romana. O termo “ Barca das Almas” sobrevive em cantigas e romarias
fluviais, sobretudo no Círio de São  João  d’Arga.
Essas variantes reforçam o Lima como rio da passagem — o espaço onde a memória se
dissolve para permitir o renascimento.
⸻
4. Primeiro relato e fontes académicas primárias
O primeiro registo literário da Sombra do Barqueiro do Lima encontra-se em Leite de
Vasconcelos, Etnografia Portuguesa, vol. IX (1925, pp. 222–229)*, descrevendo “o barqueiro
encantado de Ponte de Lima, que continua a remar após a morte”.
Teófilo Braga, O Povo Português  nos seus Costumes, Crenças e Tradições (1885, pp. 815–821)*,
já mencionava barqueiros fantasmagóricos ligados a rios liminares, interpretando-os como
herdeiros dos psicopompos greco-romanos.
Alexandre Parafita, Mitologia Popular Portuguesa (2008, pp. 1089–1097)*, identifica o Barqueiro
do Lima como “transposição local do barqueiro de Letes”, adaptado à geogra fia e ao simbolismo
minhoto.
A sistematização contemporânea de Eduardo Mauer, A Sombra e o Rio: Travessia e Memória no
Lima (Lisboa, Associação MILK, 2025)*, interpreta a lenda à luz da fenomenologia da sombra,
considerando-a “imagem do pensamento que continua depois do corpo”.
Fontes complementares:
– Museu dos Terceiros, Coleção  de Lendas do Alto Minho (1950–2018);
– Arquivo Municipal de Ponte de Lima, Registos de Narrativas Ribeirinhas e Memória Oral (séculos
XVIII–XX);
– Tese de Doutoramento de Ricardo Meireles, O Rio e o Espelho: A Água  como Lugar de Memória
na Literatura Portuguesa (U. Minho, 2016).
⸻
5. Síntese interpretativa final
A Sombra do Barqueiro do Lima é o mito da travessia espiritual. Representa o instante em que
o humano se torna consciência, quando o corpo se retira e a sombra continua a remar.
Na leitura simbólica da Associação  MILK, a lenda reflete o arquétipo da passagem, eixo central
do imaginário português: o mar, o rio, a viagem. O barqueiro é o artista — aquele que conduz
significados através das águas do tempo; a sombra é a sua obra, que o sobrevive.


A escultura MILK concebida por Eduardo Mauer segue a matriz padrão, mas com composição
alongada, sugerindo deslocamento. O corpo apresenta-se curvado, os braços em gesto de
remar, e a sombra é representada por superfície espelhada que prolonga a base. Cores cinza,
preto e prata evocam o nevoeiro e o reflexo do luar sobre o rio.
Mauer escreve: “A sombra é a memória que navega sem peso.”
⸻
6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer
“O Barqueiro do Lima é o corpo não binário da travessia: nem vivo nem morto, nem luz
nem sombra — é o movimento entre margens.”
Nesta leitura, a travessia simboliza o processo de autoconhecimento e dissolução de
fronteiras identitárias. A sombra não é ausência, mas extensão.
A Associação  MILK utiliza o mito em programas de mediação artística e educativa que
exploram a ideia de passagem entre real e simbólico, propondo oficinas em que os
participantes criam “barcas de memória” com materiais reciclados e palavras escritas.
⸻
7. Referência Estrutural da Matriz MILK
Na Matriz Escultórica MILK – Série Folclore Vivo, a Sombra do Barqueiro do Lima apresenta:
– Corpo: alongado e curvado, com braços em gesto de remar;
– Cores: cinza, preto e prata;
– Materiais: resina pigmentada e base espelhada;
– Expressão:  introspectiva, voltada para baixo;
– Base: horizontal, sugerindo travessia sobre superfície fluida.
Integra o eixo “Travessias e Ecos” do projeto Folclore Vivo, dedicado às entidades psicopompas
e às narrativas de passagem.
⸻
Localização  específica: Ponte de Lima, Arcozelo, Gemieira e Labruja (distrito de Viana do
Castelo).
Primeiro relato documentado: Vasconcelos, Etnografia Portuguesa, vol. IX, 1925.
Sistematização  contemporânea:  Eduardo Mauer, A Sombra e o Rio: Travessia e Memória no
Lima, Associação MILK, 2025.
Fontes primárias:  Braga (1885); Vasconcelos (1925); Parafita (2008); Meireles (2016); Mauer
(2025).


---

# 114. A Lenda da Velha das Três Faces de Terras de Bouro (Gerês – Alto Minho)

**Origem documental:** PDF `folclore português (1).pdf`, enviado pelo utilizador.  
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

114. A Lenda da Velha das Três Faces de Terras de Bouro (Gerês – Alto Minho)
(Sistematização  contemporânea  conduzida por Eduardo Mauer no âmbito  das pesquisas sobre
Folclore Vivo da Associação  MILK – Movimento de Intervenções e Linguagens Kulturais e Arte,
com base em recolhas orais e documentais realizadas entre 2023 e 2025 em Campo do Gerês,
Covide, Vilarinho da Furna e Rio Caldo, cruzadas com fontes etnográ ficas locais e acervos
paroquiais.)
⸻


1. Descrição  simbólica e narrativa
No sopé da Serra Amarela, quando a manhã levanta o véu de neblina e o granito devolve um
brilho úmido, fala-se ainda da Velha das Três Faces: uma mulher encapuzada que aparece junto
a encruzilhadas, fragas e fontes frias, trazendo no rosto um enigma triplo. Diz o povo que a
primeira face é moça, a segunda mãe , e a terceira ancião  — e que a sua voz muda conforme a
face que se torna visível.
As versões recolhidas por Eduardo Mauer (2024) em Covide e Campo do Gerês descrevem
encontros ao amanhecer: um pastor que, ao contornar um penedo, viu uma velha fiando à porta
da brenha; pediu-lhe o caminho, e ela ergueu a cabeça com um rosto jovial que indicou a direção
do vale. O homem, surpreso, girou para agradecer e encontrou o mesmo corpo com outra face —
madura, maternal — avisando para não cruzar a ponte antes do meio-dia. Ao afastar-se, ouviu
um sussurro rouco de terceira voz: “Quando os caminhos se cruzam, também o tempo se cruza.”
Noutras narrativas, a Velha surge sobre fragas votivas onde os antigos deixavam oferendas:
numa mão carrega uma roca ou cajado; noutra, um pequeno cesto de folhas. A presença não
ameaça: interroga. Quem responde de modo soberbo perde a rota; quem escuta sai protegido.
As crianças eram ensinadas a cumprimentar os penedos “onde mora a Velha”, num gesto de
respeito à montanha.
Há versões em que a Velha é guardadora da água : nos meses de estiagem, aparece sentada
junto a minas e fontes, testando a paciência de quem chega. Se encontra pressa e impaciência, a
água “fecha-se”; se encontra humildade, “a fonte canta”.
Em todas as variantes, a figura condensa o tempo em três, unindo juventude, maturidade e
velhice num mesmo corpo — uma pedagogia do ciclo. Mauer sintetiza: “A Velha das Três Faces
é o relógio da serra, a consciência do lugar que pergunta ao viajante em que tempo ele escolhe
andar.”
⸻
2. Contexto histórico e social
Terras de Bouro preserva um mosaico de crenças pastorícias e agro-silvícolas onde as figuras
femininas ligadas à terra, à água e à passagem dos meses são recorrentes. A triplidade feminina
ecoa arquétipos pan-europeus (donzela–mãe–anciã) adaptados à realidade do Gerês: moça
(primavera), mãe (verão/colheita) e velha (outono-inverno/abrigo).
A romanização (via Geira Romana) trouxe cultos a deidades triplices e à deusa das águas ,
facilmente sincretizadas nas práticas locais; a cristianização rural manteve o substrato,
deslocando-o para devoções a santas e “senhoras” de cada estação ou fonte. O deslocamento
de aldeias (como Vilarinho da Furna, submersa) reforçou a figura como memória do que
permanece quando a paisagem muda: a Velha torna-se guardiã do pertencimento.
Socialmente, a lenda funcionou como código de conduta: prudência nas encruzilhadas,
respeito por fontes e ritmos, escuta dos mais velhos. Em termos rituais, a presença nas águas
frias e penedos reforça a sacralidade de locais liminares — entradas de vales, passagens de
altitude, mina-d’água onde “se pede licença”.
A leitura contemporânea da Associação  MILK reconhece nesta figura uma pedagogia ecológica:
a tríplice face traduz ciclagem (da seiva, das águas, do pastoreio) e cuidado (comunidade–
território–memória).
⸻
3. Toponímia e variantes locais

Registos orais apontam lugares associados à Velha: Penedo da Roca (Campo do Gerês), Fonte
Velha (Covide), Lomba das Três Vozes (Rio Caldo) e Caminho das Três Sombras (Vilarinho da
Furna). Variantes nomeiam-na “A das Três Vozes”, “Velha do Penedo” e “A Três-Mães” .
Em Vilarinho da Furna, moradores deslocados recordam uma “mulher do penedo” que avisava
sobre cheias; em Rio Caldo, a versão é mais aquática (protetora da nascente); em Campo do
Gerês, predominam relatos de encruzilhada (conselhos de rota). Em todas, a tríplice
manifestação marca o encontro de espaço (caminho/penedo/fonte) e tempo (manhã/meio-dia/
anoitecer).
⸻
4. Primeiro relato e fontes académicas primárias
As recolhas escritas antigas sobre esta figura são fragmentárias e dispersas em entradas
relativas a “mulheres do penedo”, “velhas das fontes” e “mães triplices” do Gerês. Na tradição
erudita portuguesa, coletores como Leite de Vasconcelos e Teófilo Braga registaram motivos
próximos (mulher de penedo, guardiãs de fonte, tríplice feminina), mas não um verbete único
canónico sob a denominação “Velha das Três Faces” para Terras de Bouro.
Para rigor académico, esta sistematização baseia-se em:
	 •	 Testemunhos orais recolhidos por Eduardo Mauer (2023–2025) em
Campo do Gerês, Covide e Rio Caldo (diários etnográ ficos MILK; gravações
depositadas no acervo interno do projeto Folclore Vivo).
	 •	 Cadernos paroquiais locais (séculos XIX–XX) com notas de “mulher do
penedo” aconselhando pastores em manhãs de nevoeiro (marginalia e crónicas de
romeiros).
	 •	 Inventários  municipais de património imaterial (apontamentos sobre
guardiãs de fontes e normas de silêncio à cabeceira das águas).
Observação metodológica: para efeitos de primeiro relato documental
consolidado, a presente entrada MILK 2025 fixa a designação “Velha das Três
Faces de Terras de Bouro” como sintese crítica de um conjunto de motivos
tradicionais atestados localmente (mulher do penedo/guardiã da fonte/triplidade
feminina) e validados por recolha oral contemporânea.
⸻
5. Síntese interpretativa final
A Velha das Três Faces não é “monstro” nem “santa”: é ritmo. Em corpo único, encarna três
tempos do cuidado — orientação (moça), sustento (mãe), prudência (ancião). Surpreende que a
sua ação principal seja perguntar. O mito ensina que, no Gerês, as respostas pertencem à
serra; ao humano, cabe reconhecer em que tempo está a caminhar.
Na leitura simbólica da Associação  MILK, a tríplice face é um diagrama de escuta:
	 •	 Face-moça ˠ abertura à rota (experimentação, risco contido);
	 •	 Face-mãe  ˠ mediação e abrigo (prioridade ao comum);
	 •	 Face-ancião  ˠ memória e medida (limites, pausa).
A ética prática que resulta é simples e exigente: pergunte antes de passar; abrande diante
da água; reconheça a hora do vale e a hora da encosta.
A proposta escultórica de Eduardo Mauer recolhe esta gramática: um único corpo
compacto (matriz MILK), três per fis insinuados num mesmo rosto — leves reentrâncias e
saliências que, com a luz, revelam ângulos diferentes: jovem, maduro, velho. No peito,

uma roca estilizada torna-se cajado conforme o ponto de vista, e um pequeno cesto se
sugere na curvatura lateral: fiar-cuidar-conduzir.
⸻
6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer
“A Velha das Três Faces é o corpo não binário do tempo: num só rosto coexistem
idades e papéis, sem hierarquia.”
A figura desarma dicotomias (novo/velho, ativo/passivo, natureza/cultura) e propõe
coexistência dinâmica . Não há “a” identidade certa, há fases que se revezam.
Na prática MILK, isto informa metodologias de criação colaborativa: os papéis
circulam (quem guia–quem cuida–quem recorda), à semelhança das três faces.
A dimensão de cuidado expandido (com pessoas, paisagem, água) liga-se a
políticas de escuta e tempo lento na mediação cultural. A Velha, ao perguntar em
que tempo caminhas, convida a autorregulação  (ritmo do corpo–ritmo do lugar),
sugerindo modos de sustentabilidade afetiva e ecológica.
⸻
7. Referência Estrutural da Matriz MILK
Na Matriz Escultórica MILK – Série Folclore Vivo, a Velha das Três Faces apresenta:
	 •	 Corpo: compacto e vertical, manto que desenha três dobras (três per fis).
	 •	 Rosto: volumetria facetada; conforme a luz, revela juventude, maturidade
ou velhice.
	 •	 Objetos-sinal: roca/cajado/cesto (integram-se na silhueta).
	 •	 Cores: granito húmido (cinza-ardósia), musgo (verde-escuro) e reflexos de
água (prata fria).
	 •	 Materiais: resina pigmentada com pó de ardósia; acabamento mate com
zonas polidas para jogos de luz.
	 •	 Base: laje elíptica com sulco sinuoso (caminho–água).
Integra o eixo “Guardadoras de Lugar” do projeto Folclore Vivo, dedicado a entidades
femininas (no sentido amplo) que mediam caminhos, águas e ritmos.
⸻
Localização  específica: Campo do Gerês, Covide, Vilarinho da Furna e Rio Caldo (Terras de
Bouro, distrito de Braga).
Primeiro relato documentado (fixação  MILK): Dossiê Folclore Vivo – Terras de Bouro
(Recolhas de Eduardo Mauer, 2023–2025; transcrições e notas de campo arquivadas no acervo
MILK 2025).
Sistematização  contemporânea:  Eduardo Mauer, A Velha das Três  Faces: Tempo, Cuidado e
Encruzilhadas no Gerês , Associação MILK, 2025.
Fontes de base: Recolhas orais locais; cadernos paroquiais (sécs. XIX–XX); inventários
municipais de património imaterial.


---

# 115. A Lenda do Fuso de Pedra de Vila Verde (Baixa do Cávado  – Alto Minho)

**Origem documental:** PDF `folclore português (1).pdf`, enviado pelo utilizador.  
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

115. A Lenda do Fuso de Pedra de Vila Verde (Baixa do Cávado  – Alto Minho)
(Sistematização  contemporânea  conduzida por Eduardo Mauer no âmbito  das pesquisas sobre
Folclore Vivo da Associação  MILK – Movimento de Intervenções e Linguagens Kulturais e Arte,
com base em recolhas orais e documentais realizadas entre 2023 e 2025 em Vila Verde, Prado,

Ribeira do Neiva e Atiães,  cruzadas com fontes etnográ ficas do Museu D. Diogo de Sousa, do
Arquivo Distrital de Braga e de estudos sobre mitologia agrícola  e petrificação  simbólica no
noroeste português.)
⸻
1. Descrição  simbólica e narrativa
Em Vila Verde, região de campos férteis e fiadeiras habilidosas, ergue-se entre vinhedos e
carvalhais um penedo singular a que o povo chama Fuso de Pedra. É uma rocha esguia, a filada
na ponta, com cerca de três metros, que parece emergir da terra como um fuso gigantesco a fiar
o ar.
Conta o povo que ali vivia, há séculos, uma moça fiandeira conhecida por Mariana das Linhas,
de destreza notável e orgulho excessivo. Fiava ao luar e gabava-se de ser mais rápida que todas
as mulheres da freguesia — e até que as próprias santas. Certa noite de Sábado, durante a ceia,
ouviu uma voz que a desafiava: “Se és tão veloz, fia até o toque da missa.” A moça, vaidosa,
aceitou.
Quando o sino tocou, a roca tremia-lhe nas mãos, mas ela não parou. No momento em que a
Ave-Maria soou, o fuso, incandescente, ergueu-se e solidificou-se em pedra. A fiandeira
desapareceu; em seu lugar, ficou o penedo afilado — memória do gesto interrompido.
Dizem as mulheres da aldeia que, ao luar, o vento ainda faz o fuso girar; e quem tocar nele sem
pedir licença fica com as mãos dormentes. As crianças aprendem desde cedo: “Não se fia entre
badaladas, nem se desafia o tempo.”
Versões mais antigas contam que o fuso foi lançado por uma moura encantada, tentando
escapar à maldição do sol; outras, que ali se petri ficou o cajado de uma pastora. Em todas, o
tema é petrificação  por excesso de orgulho ou por desobediência ao tempo sagrado.
Eduardo Mauer (2024) observa: “O Fuso de Pedra é o instante em que o trabalho ultrapassa o
seu ritmo e se torna matéria — a arte esquecida de parar.”
⸻
2. Contexto histórico e social
O fuso e a roca são símbolos centrais da economia e da cosmovisão feminina rural no norte
português. O fiar representava tanto a produção material (linho, lã) quanto o domínio do tempo: a
mulher que fiava controlava o ritmo do lar e da comunidade.
O fuso petrificado insere-se no ciclo de narrativas europeias de petrificação  punitiva ou
consagradora, onde gestos cotidianos (fiar, dançar, cantar) se eternizam em pedra para ensinar
prudência. No contexto minhoto, combina elementos pagãos (magia da pedra e do linho) e
cristãos (respeito pelo descanso e pelo sagrado).
A lenda servia de instrumento pedagógico: recordava que o trabalho excessivo, sem medida ou
devoção, podia ser castigo — não virtude. Também expressava, sob forma simbólica, a tensão
entre devoção  e autonomia feminina. A fiandeira ousa medir-se com o divino e é petri ficada —
mas perpetuada: o penedo ergue-se como monumento ao gesto criador.
O território de Vila Verde, entre o Cávado e o Homem, conserva tradição têxtil antiquíssima,
com abundância de linho e ofícios associados. O mito do Fuso de Pedra re flete essa herança: a
ligação entre trabalho, terra e mito.
A Associação  MILK, no âmbito do eixo “Trabalhos e Encantamentos”, articula essa lenda com
oficinas de reinterpretação contemporânea do fiar como gesto meditativo, explorando o equilíbrio
entre ação e pausa.


⸻
3. Toponímia e variantes locais
Topónimos como “Penedo do Fuso”, “Couto da Roca” e “Fonte da Fiandeira” figuram em
registros cartográ ficos do século XVIII. Versões próximas aparecem em Atiães  (petrificação de
roca), Ribeira do Neiva (a moça do fuso de ouro) e Prado (a moura que fiava luz).
Nas memórias orais recolhidas por Mauer, as idosas associam o penedo a “tempo que não volta”
e “trabalho que se esquece”. Algumas relatam rituais de passagem: moças deixavam fitas de
linho ao redor do penedo na véspera de São João, pedindo boas mãos para o tear.
⸻
4. Primeiro relato e fontes académicas primárias
O primeiro registo textual do Fuso de Pedra de Vila Verde surge em Leite de Vasconcelos,
Etnografia Portuguesa, vol. IX (1925, pp. 230–236)*, que refere: “Em Vila Verde há penedo alto e
delgado, tido como fuso petrificado duma fiandeira castigada.”
Teófilo Braga, O Povo Português  nos seus Costumes, Crenças e Tradições (1885, pp. 822–826)*,
menciona histórias de mulheres transformadas em pedra por fiar ao luar, “gesto de desafio ao
descanso da terra”.
Alexandre Parafita, Mitologia Popular Portuguesa (2008, pp. 1098–1107)*, analisa a narrativa
como “metáfora da permanência do gesto feminino criador no tempo mineral”.
A sistematização contemporânea de Eduardo Mauer, O Fuso e o Tempo: Trabalho, Pedra e
Feminino em Vila Verde (Lisboa, Associação MILK, 2025)*, reinterpreta o mito sob perspectiva
antropológica e performativa, propondo-o como “poética da interrupção”.
Fontes complementares:
– Museu D. Diogo de Sousa, Coleção  de Etnografia Minhotas (1950–2010);
– Arquivo Distrital de Braga, Documentos Toponímicos e Lendas do Cávado  (sécs. XVIII–XX);
– Tese de Doutoramento de Filipa Serra, Pedras que Falam: Metamorfose e Gesto na Mitologia
Ibérica  (U. Lisboa, 2019).
⸻
5. Síntese interpretativa final
O Fuso de Pedra é metáfora da passagem do movimento à forma, do tempo vivo à eternidade
imóvel. O gesto humano, ao exceder a sua medida, cristaliza-se.
Na leitura simbólica da Associação  MILK, a fiandeira petrificada não é apenas advertência
moral, mas símbolo de resistência criadora: o corpo feminino torna-se pedra, permanecendo
como memória do gesto que tece o mundo.
A escultura MILK concebida por Eduardo Mauer segue a matriz padrão, mas verticalizada. O
corpo compacto torna-se eixo ascendente, evocando fuso. As cores — branco de linho, cinza-
pedra e reflexos dourados — fundem trabalho e luz. As mãos unem-se à frente, fiando o invisível.
Mauer escreve: “O fuso petrificado é o silêncio do gesto que ainda fia.”
⸻


6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer
“O Fuso de Pedra é corpo não binário do tempo produtivo e do contemplativo: nem
trabalho nem repouso, mas o intervalo onde o gesto se suspende.”
A lenda, reinterpretada, propõe uma ética da pausa, questionando o produtivismo
contemporâneo. O mito convoca também uma leitura de identidade além do gênero: o
fiar é ato universal de ligação, não atributo feminino exclusivo.
A Associação  MILK transforma o mito em prática pedagógica de “ fiar coletivo”, onde
artistas e comunidade tecem fios simbólicos, discutindo ritmo, excesso e cuidado.
⸻
7. Referência Estrutural da Matriz MILK
Na Matriz Escultórica MILK – Série Folclore Vivo, o Fuso de Pedra de Vila Verde apresenta:
– Corpo: vertical e compacto, ligeiramente afilado para o topo;
– Cores: branco-linho, cinza e dourado suave;
– Materiais: resina pigmentada e pó de pedra calcária;
– Expressão:  calma e concentrada;
– Base: circular, evocando a roca ou carretel.
Integra o eixo “Trabalhos e Encantamentos” do projeto Folclore Vivo, dedicado às narrativas
sobre ofício, criação e tempo.
⸻
Localização  específica: Vila Verde, Prado, Ribeira do Neiva e Atiães (distrito de Braga).
Primeiro relato documentado: Vasconcelos, Etnografia Portuguesa, vol. IX, 1925.
Sistematização  contemporânea:  Eduardo Mauer, O Fuso e o Tempo: Trabalho, Pedra e
Feminino em Vila Verde, Associação MILK, 2025.
Fontes primárias:  Braga (1885); Vasconcelos (1925); Parafita (2008); Serra (2019); Mauer (2025).


---

# 116. A Lenda do Poço do Inferno de Manteigas (Serra da Estrela – Origem Transmontana Expandida)

**Origem documental:** PDF `folclore português (1).pdf`, enviado pelo utilizador.  
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

116. A Lenda do Poço do Inferno de Manteigas (Serra da Estrela – Origem Transmontana
Expandida)
(Sistematização  contemporânea  conduzida por Eduardo Mauer no âmbito  das pesquisas sobre
Folclore Vivo da Associação  MILK – Movimento de Intervenções e Linguagens Kulturais e Arte,
com base em recolhas orais e documentais realizadas entre 2023 e 2025 em Manteigas, Sameiro
e Penhas Douradas, cruzadas com fontes etnográ ficas do Museu Natural da Serra da Estrela, do
Arquivo Distrital da Guarda e de estudos sobre mitologia geológica, simbologia infernal e
imaginário  aquático  das serras beirãs  e transmontanas.)
⸻
1. Descrição  simbólica e narrativa
Na garganta profunda da Serra da Estrela, onde o gelo e o granito se tocam como fogo e cinza,
ecoa há séculos a lenda do Poço do Inferno. Trata-se de uma cascata e lago natural de águas
geladas, rodeada por penedos de cor ferrosa, onde o nevoeiro se acumula e o som da queda
d’água parece respirar. O povo a firma que é uma fenda que conduz ao centro da terra — e que,
em noites de trovoada, a própria montanha exala vapores como se o inferno respirasse.


As versões recolhidas por Eduardo Mauer (2024) descrevem três origens possíveis:
	 1.	 Um pacto diabólico entre um pastor e o demônio, em que o primeiro
prometera entregar-lhe a alma em troca de riquezas e rebanhos infinitos; quando tentou
quebrar o trato, a terra abriu-se, engolindo-o junto ao penedo.
	 2.	 Uma moura encantada aprisionada no abismo por desafiar o sol; desde
então, seus cabelos dourados flutuam na superfície do poço.
	 3.	 Um castigo divino a uma aldeia que zombara dos trovões, transformando-
se o vale em abismo de fogo e vapor.
Em todas as versões, o Poço é lugar de transgressão  e passagem — limite entre o
visível e o subterrâneo. O diabo, a moura e a montanha fundem-se num mesmo corpo
simbólico: o da natureza poderosa que exige respeito.
Mauer regista a narrativa de um idoso de Sameiro que descreveu ter ouvido “a montanha
ferver por dentro” numa tempestade de inverno, e que ao amanhecer encontrou as pedras
quentes ao toque. O relato, cruzado com lendas locais, sustenta o caráter vulcânico
mítico da serra, apesar de geologicamente impossível — uma forma de o povo explicar a
energia telúrica do lugar.
Mauer escreve: “O Poço do Inferno é o pulmão invertido da montanha — inspira frio,
expira fogo.”
⸻
2. Contexto histórico e social
A Serra da Estrela, com altitudes superiores a dois mil metros, sempre foi vista como montanha
sagrada e ameaçadora. Na tradição oral, seus vales e penhascos eram morada de demônios,
mouras, eremitas e santos penitentes. O Poço do Inferno (entre Manteigas e Penhas Douradas)
concentra esse imaginário: a verticalidade abissal como metáfora de purgação.
Durante os séculos XVII–XIX, viajantes e eruditos (como Almeida Garrett e Pinho Leal) registraram
a paisagem com espanto romântico, descrevendo-a como “abismo onde Deus e o Diabo se
tocam em silêncio”. O local tornou-se, no século XX, destino turístico e espiritual: o perigo
converteu-se em contemplação.
Historicamente, os pastores da Estrela evitavam passar pelo poço ao entardecer, acreditando
que “vozes saíam da água”. Esse temor ritual gerou códigos de comportamento: não cuspir, não
atirar pedras, não gritar — práticas que, reinterpretadas pela Associação  MILK, revelam um
protocolo de escuta ambiental ancestral.
No plano simbólico, o “inferno” não é punição eterna, mas força subterrânea  — o calor que, sob
a neve, garante a regeneração. Assim, o mito integra-se no ciclo das lendas telúricas do norte
português, ao lado das Furnas do Cavalum (Madeira) e da Boca do Inferno (Cascais), compondo
a cartografia dos “abismos sagrados”.
⸻
3. Toponímia e variantes locais
O nome “Poço do Inferno” aparece já em mapas militares do século XVIII, confirmando a
antiguidade da designação. A etimologia popular associa o termo à cor avermelhada das rochas
(ferro e cobre) e ao vapor que sobe do vale nas manhãs frias.
Existem variantes próximas:
– Poço do Diabo, na Ribeira de Leandres (Guarda), com narrativa semelhante;
– Lagoa Escura, no planalto superior, associada ao espírito da moura;
– Cova da Velha, junto a Loriga, onde se ouvem lamentos subterrâneos.


Todas as variantes partilham o motivo da entrada para o mundo de baixo e da voz telúrica — o
som profundo da terra como sinal de presença divina ou demoníaca.
⸻
4. Primeiro relato e fontes académicas primárias
O primeiro registo escrito do Poço do Inferno como lenda aparece em Leite de Vasconcelos,
Etnografia Portuguesa, vol. X (1926, pp. 101–108)*, descrevendo “abismo temido nas serras da
Estrela, onde o povo ouve rugidos e vê luzes entre névoas”.
Teófilo Braga, O Povo Português  nos seus Costumes, Crenças e Tradições (1885, pp. 827–832)*,
menciona “poços infernais” da Beira Alta e Trás-os-Montes, interpretando-os como reminiscência
dos santuários  ctónicos do paganismo ibérico.
Alexandre Parafita, Mitologia Popular Portuguesa (2008, pp. 1108–1121)*, inclui o Poço do
Inferno como exemplo de “geografia mítica da punição e da regeneração”.
A sistematização contemporânea de Eduardo Mauer, Poço do Inferno: Calor, Frio e Escuta na
Serra da Estrela (Lisboa, Associação MILK, 2025)*, propõe leitura ambiental e filosófica: “o
abismo como órgão sensível da montanha”.
Fontes complementares:
– Museu Natural da Serra da Estrela, Coleção  de Lendas Geológicas (1950–2020);
– Arquivo Distrital da Guarda, Toponímia Mítica  e Crenças Telúricas da Beira Alta (sécs. XVIII–XX);
– Tese de Doutoramento de Teresa Vale, O Inferno na Paisagem Portuguesa: Toponímia e
Imaginário  (U. Coimbra, 2016).
⸻
5. Síntese interpretativa final
O Poço do Inferno é o arquétipo do abismo consciente: lugar que devolve a medida do
humano diante da terra. É o espaço onde a montanha fala por vapor, pedra e eco — o sopro
subterrâneo como linguagem.
Na leitura simbólica da Associação  MILK, o Poço representa a consciência ecológica radical:
reconhecer que a natureza não é benevolente nem hostil, mas dotada de poder e mistério. O
inferno é aqui metáfora do interior do planeta e, simultaneamente, do inconsciente humano.
A escultura MILK criada por Eduardo Mauer segue a matriz padrão, mas reinterpreta o corpo
como coluna oca, com aberturas verticais que sugerem fenda. A superfície combina preto mate,
ferrugem e reflexos vermelhos translúcidos. No interior, uma pequena fonte de luz imita o brilho
incandescente das profundezas.
Mauer comenta: “O Poço do Inferno não é descida: é escuta vertical.”
⸻
6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer
“O Poço do Inferno é o corpo não binário da montanha: frio e quente, inferno e céu,
repouso e energia — coexistências, não opostos.”
Nesta leitura, o mito desloca o inferno do domínio moral para o domínio energético,
libertando-o da dicotomia bem/mal. O abismo torna-se símbolo da coabitação  de
contrários  e da potência criadora das forças invisíveis.


A Associação  MILK integra este eixo nas suas ações educativas “Escutar o Abismo”, que
convidam à re flexão sobre a interdependência entre interioridade humana e geologia viva,
explorando práticas sonoras e meditativas em espaços naturais.
⸻
7. Referência Estrutural da Matriz MILK
Na Matriz Escultórica MILK – Série Folclore Vivo, o Poço do Inferno apresenta:
– Corpo: compacto e oco, fendido verticalmente;
– Cores: preto mate, ferrugem e vermelho translúcido;
– Materiais: resina pigmentada e filamentos de cobre interno;
– Expressão:  silenciosa e densa;
– Base: circular, com textura irregular de rocha e brilho interno.
Integra o eixo “Abismos e Vozes da Terra” do projeto Folclore Vivo, dedicado a lendas de
caráter geológico e simbólico.
⸻
Localização  específica: Manteigas, Sameiro e Penhas Douradas (distrito da Guarda).
Primeiro relato documentado: Vasconcelos, Etnografia Portuguesa, vol. X, 1926.
Sistematização  contemporânea:  Eduardo Mauer, Poço do Inferno: Calor, Frio e Escuta na Serra
da Estrela, Associação MILK, 2025.
Fontes primárias:  Braga (1885); Vasconcelos (1926); Parafita (2008); Vale (2016); Mauer (2025).


---

# 117. A Lenda da Pedra da Cabeleira de Montalegre (Barroso – Trás-os-Montes)

**Origem documental:** PDF `folclore português (1).pdf`, enviado pelo utilizador.  
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

117. A Lenda da Pedra da Cabeleira de Montalegre (Barroso – Trás-os-Montes)
(Sistematização  contemporânea  conduzida por Eduardo Mauer no âmbito  das pesquisas sobre
Folclore Vivo da Associação MILK – Movimento de Intervenções e Linguagens Kulturais e
Arte, com base em recolhas orais e documentais realizadas entre 2023 e 2025 em Montalegre,
Padornelos e Pitões das Júnias, cruzadas com fontes etnográ ficas do Ecomuseu de Barroso, do
Arquivo Municipal de Montalegre e de estudos sobre mitologia petral, mouras encantadas e
simbolismo capilar na tradição  transmontana.)
⸻
1. Descrição  simbólica e narrativa
Entre os prados altos de Montalegre, junto à vereda que leva à serra do Larouco, há uma pedra
singular, arredondada e fendida no topo, coberta de musgo e líquenes, a que o povo chama
Pedra da Cabeleira. Conta-se que, em certas madrugadas húmidas, o musgo ganha brilho
dourado e parece transformar-se em fios de cabelo que balançam ao vento.
Segundo a tradição, ali vivia uma moura encantada de longos cabelos louros, guardiã de um
tesouro oculto sob a rocha. Dizia-se que passava os dias a pentear-se com um pente de ouro e
que, ao entardecer, o som do pente a rasgar os fios era ouvido por quem se aventurasse perto.
Uma vez por ano, na noite de São João, a moura aparecia à beira da pedra e perguntava a quem
passava: “Queres o ouro ou queres a formosura?” Quem escolhia o ouro via-o transformar-se em
serpentes; quem pedia formosura envelhecia de súbito.
Outras versões, recolhidas por Eduardo Mauer (2024), narram que a moura se apaixona por um
pastor e, ao ser descoberta, é amaldiçoada: transforma-se em pedra, mas o seu cabelo continua
a crescer, cobrindo a rocha de musgo e hera. Diz-se que, nas noites de luar, o brilho verde-
dourado é o re flexo do pente que ela ainda segura.


Alguns camponeses afirmam que, se alguém cortar um pedaço do musgo da pedra, adoecerá ou
perderá o cabelo. Outros acreditam que o musgo cura feridas, desde que recolhido com silêncio
e gratidão.
Mauer resume: “A Pedra da Cabeleira é a imagem do desejo aprisionado — a beleza que
sobrevive à petri ficação, o gesto que continua mesmo depois do corpo cessar.”
⸻
2. Contexto histórico e social
O mito integra o ciclo transmontano das mouras encantadas, figuras femininas ligadas à
paisagem e à herança mourisca. A presença de pedras antropomór ficas é comum em Trás-os-
Montes, onde a geologia serve de suporte à memória.
A cabeleira, símbolo de feminilidade e poder, surge em lendas ibéricas como metáfora de
energia vital: o cabelo que cresce é o tempo que continua. A petri ficação da moura é, portanto,
um castigo e uma consagração — o corpo torna-se parte da montanha, mas mantém o
movimento através do musgo.
Historicamente, o local da Pedra da Cabeleira, próximo de linhas de pastoreio e antigos
caminhos romanos, funcionou como marco territorial e ponto de oferenda. Moradores
deixavam moedas, flores ou fios de lã entre as fendas, pedindo proteção e fertilidade.
O Ecomuseu de Barroso documenta desde 1980 a persistência do ritual: mulheres idosas
ensinam às mais novas que se deve “pentear o vento com ramos de giesta” junto à pedra,
repetindo o gesto da moura para garantir boas colheitas.
A Associação  MILK, sob coordenação de Eduardo Mauer, interpreta a lenda como expressão
da relação entre paisagem e memória feminina, integrando-a no eixo “Rostos e Penedos” do
projeto Folclore Vivo.
⸻
3. Toponímia e variantes locais
A Pedra da Cabeleira situa-se entre as aldeias de Padornelos e Pitões das Júnias, a cerca de
1.200 metros de altitude. Topónimos como “Cabeleira”, “Penedo da Moura” e “Cabeço do
Pente” aparecem em registos paroquiais do século XIX.
Em Bravães  (Lima) e Vilar de Perdizes, há variantes conhecidas como “ Pedra da Moura dos
Cabelos de Ouro” e “Rocha da Trança”, indicando difusão regional do mesmo motivo narrativo.
Em todas, o cabelo é mediador entre humano e natureza, terra e ar.
⸻
4. Primeiro relato e fontes académicas primárias
O primeiro registo escrito da Pedra da Cabeleira surge em Leite de Vasconcelos, Etnografia
Portuguesa, vol. X (1926, pp. 109–115)*, onde se refere a “penedo coberto de musgo que o povo
crê ser a cabeleira de moura encantada”.
Teófilo Braga, O Povo Português  nos seus Costumes, Crenças e Tradições (1885, pp. 833–838)*,
já mencionava “mouras petri ficadas” cujos cabelos crescem em forma de hera, interpretando-as
como reminiscência de divindades agrárias.


Alexandre Parafita, Mitologia Popular Portuguesa (2008, pp. 1122–1131)*, inclui o mito entre as
“metamorfoses vegetais”, em que o corpo humano se funde com a terra.
A sistematização contemporânea de Eduardo Mauer, A Pedra e o Cabelo: Feminino, Paisagem e
Encantamento no Barroso (Lisboa, Associação MILK, 2025)*, recolhe 38 depoimentos orais e
propõe a leitura da lenda como “ensaio telúrico sobre o crescimento dentro da imobilidade”.
Fontes complementares:
– Ecomuseu de Barroso, Coleção  de Lendas da Serra do Larouco (1970–2022);
– Arquivo Municipal de Montalegre, Registos Toponímicos e Memória Oral (sécs. XIX–XXI);
– Tese de Doutoramento de Cláudia Teles, Cabelos e Encantos: Simbologia Capilar na Tradição
Portuguesa (U. Minho, 2019).
⸻
5. Síntese interpretativa final
A Pedra da Cabeleira é o arquétipo da beleza persistente. Mesmo petrificada, a moura
continua a pentear-se: o gesto prossegue sem corpo. O cabelo, aqui, é a metáfora do tempo que
nunca cessa.
Na leitura simbólica da Associação  MILK, o mito expressa a fusão entre eros e geologia — o
desejo inscrito na matéria. O musgo e a hera que cobrem a pedra são a respiração do que
permanece vivo sob a imobilidade aparente.
A escultura MILK concebida por Eduardo Mauer mantém a matriz padrão, mas o corpo ergue-se
levemente inclinado, como rocha que respira. A textura, rugosa e coberta por filamentos
translúcidos de resina, evoca cabelo vegetal. A cor varia entre verde-musgo, dourado e castanho-
terra.
Mauer escreve: “A pedra é o corpo que decidiu continuar pelos cabelos.”
⸻
6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer
“A moura da Cabeleira é corpo não binário da metamorfose: nem mulher nem rocha, nem
natureza nem cultura — fusão viva.”
Nesta leitura, a lenda ultrapassa o género e propõe um corpo híbrido, em que identidade e
paisagem se confundem. A beleza deixa de ser atributo humano e torna-se qualidade da
terra.
A Associação  MILK utiliza esta abordagem em residências artísticas que exploram a
poética do crescer-imóvel, criando instalações vegetais e esculturas vivas inspiradas no
mito, em colaboração com comunidades locais e escolas.
⸻
7. Referência Estrutural da Matriz MILK
Na Matriz Escultórica MILK – Série Folclore Vivo, a Pedra da Cabeleira apresenta:
– Corpo: compacto e inclinado, superfície orgânica com filamentos translúcidos;
– Cores: verde-musgo, dourado e castanho-terra;
– Materiais: resina, pigmento mineral e fibra vegetal;
– Expressão:  serena e introspectiva;
– Base: irregular, lembrando afloramento de penedo natural.


Integra o eixo “Rostos e Penedos” do projeto Folclore Vivo, dedicado às entidades pétreas e
metamórficas do imaginário português.
⸻
Localização  específica: Padornelos, Pitões das Júnias e Montalegre (distrito de Vila Real).
Primeiro relato documentado: Vasconcelos, Etnografia Portuguesa, vol. X, 1926.
Sistematização  contemporânea:  Eduardo Mauer, A Pedra e o Cabelo: Feminino, Paisagem e
Encantamento no Barroso, Associação MILK, 2025.
Fontes primárias:  Braga (1885); Vasconcelos (1926); Parafita (2008); Teles (2019); Mauer (2025).


---

# 118. A Lenda da Ponte da Misarela (Montalegre – Ribeira do Rabagão)

**Origem documental:** PDF `folclore português (1).pdf`, enviado pelo utilizador.  
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

118. A Lenda da Ponte da Misarela (Montalegre – Ribeira do Rabagão)
(Sistematização  contemporânea  conduzida por Eduardo Mauer no âmbito  das pesquisas sobre
Folclore Vivo da Associação MILK – Movimento de Intervenções e Linguagens Kulturais e
Arte, com base em recolhas orais e documentais realizadas entre 2023 e 2025 nas freguesias de
Ferral, Misarela e Sidrós, cruzadas com fontes etnográ ficas do Ecomuseu de Barroso, do Arquivo
Distrital de Braga e de estudos sobre mitologia cristã,  arquitetura simbólica e ritos de travessia no
norte de Portugal.)
⸻
1. Descrição  simbólica e narrativa
Erguida sobre o estreito desfiladeiro do Rabagão , onde o rio se torce entre penedos abruptos, a
Ponte da Misarela é conhecida há séculos como a “Ponte do Diabo”. O arco único de granito,
de origem medieval, liga duas margens rochosas por meio de um passo impossível — e é
precisamente esse impossível que alimenta a lenda.
Diz o povo que a ponte foi construída pelo Demónio, a pedido de um criminoso em fuga.
Perseguido pelos guardas e encurralado junto ao abismo, o homem invocou as forças infernais
para escapar. O Diabo apareceu sob forma de cavaleiro negro e propôs um pacto: construiria
uma ponte durante a noite, mas, em troca, exigiria a primeira alma que por ela passasse.
Ao amanhecer, a ponte estava feita, sólida e bela. O fugitivo, desesperado, pediu ajuda a um
frade franciscano que viajava pela região. Este, com astúcia, lançou um pão sobre a ponte,
fazendo-o ser atravessado por um cão. O Diabo, enganado, reclamou a alma e levou o animal.
Desde então, o povo diz que o latido do cão ainda ecoa nas noites de tempestade, como
lembrança do pacto frustrado.
Outras versões relatam que o frade lançou água benta e traçou uma cruz, selando o local entre
dois mundos. A ponte tornou-se assim um limite simbólico: passagem entre humano e
sobrenatural, entre fé e astúcia, entre queda e salvação.
Recolhas de Eduardo Mauer (2024) em Ferral acrescentam variações contemporâneas: algumas
gentes afirmam que, nas madrugadas de nevoeiro, vê-se uma figura encapuçada caminhando
lentamente sobre o arco; noutras, ouve-se o ranger de correntes invisíveis.
Mauer observa: “A Ponte da Misarela é o corpo arquitetónico da dúvida — feita pelo Diabo e
santificada pelo homem.”
⸻
2. Contexto histórico e social

A ponte localiza-se na antiga via de comunicação entre Montalegre e Vieira do Minho, sendo
essencial para o trânsito de gado e peregrinos. Acredita-se que a construção original date do
século XII ou XIII, associada à expansão monástica cisterciense e às rotas de transumância.
O imaginário da “ponte do diabo” é comum em toda a Europa, marcando lugares onde a
engenharia desafiava a natureza. No Barroso, essa tradição ganhou contornos morais: a travessia
perigosa simboliza o confronto entre o humano e o infernal.
Durante séculos, a ponte serviu também como santuário  popular de partos difíceis: mulheres
grávidas deslocavam-se ao local, passavam três vezes sob o arco e atiravam para o rio uma peça
de roupa do bebé, pedindo proteção à “Senhora da Ponte”. Este sincretismo cristão substituiu o
pacto demoníaco por ritual de fertilidade e renascimento.
Hoje, o local mantém aura mística e turística. O som das águas e o eco dos passos sobre o
granito reforçam a sensação de estar num espaço liminar, onde o corpo e a alma experimentam
o peso do sagrado e do profano.
⸻
3. Toponímia e variantes locais
O nome “Misarela” tem provável origem latina ( miserabilis, “miserável”) ou derivação de
“misericórdia”, refletindo a dualidade salvação/perdição. Documentos paroquiais do século XVII
referem-na como “Ponte de Miserela”, e o topónimo surge em mapas eclesiásticos até ao século
XIX.
Variantes regionais incluem:
– “Ponte do Diabo” (Ferral);
– “Ponte da Senhora” (Vieira do Minho, versão cristianizada);
– “Ponte da Alma” (Sidrós, versão oral posterior).
Em todas, a ponte é espaço de negociação  espiritual.
⸻
4. Primeiro relato e fontes académicas primárias
O primeiro registro literário da Ponte da Misarela aparece em Leite de Vasconcelos, Etnografia
Portuguesa, vol. X (1926, pp. 116–122)*, onde o autor descreve a lenda do pacto demoníaco e o
episódio do cão.
Teófilo Braga, O Povo Português  nos seus Costumes, Crenças e Tradições (1885, pp. 839–845)*,
já mencionava “pontes do diabo” em Trás-os-Montes e no Minho, relacionando-as com antigos
cultos pagãos à travessia.
Alexandre Parafita, Mitologia Popular Portuguesa (2008, pp. 1132–1144)*, reinterpreta o mito
como “expressão simbólica da domesticação do caos pela fé e pela inteligência”.
A sistematização contemporânea de Eduardo Mauer, A Ponte e o Pacto: Misarela entre o Céu  e
o Abismo (Lisboa, Associação MILK, 2025)*, recolhe 47 depoimentos locais e propõe leitura
centrada na poética da travessia: “cada passo sobre a Misarela é uma negociação entre medo e
confiança”.
Fontes complementares:
– Ecomuseu de Barroso, Coleção  de Lendas do Rabagão  (1975–2022);
– Arquivo Distrital de Braga, Toponímia e Tradições do Barroso e Vieira do Minho (sécs. XVII–XX);
– Tese de Doutoramento de Marta Damas, Pontes do Diabo: Arquitetura e Mito na Europa
Atlântica  (U. Porto, 2018).


⸻
5. Síntese interpretativa final
A Ponte da Misarela é o arquétipo da travessia moral e metafísica. Construída pelo inferno,
salva pela fé, tornou-se metáfora da condição humana: viver é cruzar abismos.
Na leitura simbólica da Associação  MILK, a ponte expressa o ato de equilíbrio entre opostos:
razão e instinto, luz e sombra, promessa e engano. É o espaço onde a criação (engenharia, arte,
fé) emerge da negociação com o desconhecido.
A escultura MILK concebida por Eduardo Mauer traduz esse equilíbrio: corpo arqueado, como
quem sustém o próprio peso do vazio. A base curva representa o abismo; o corpo compacto
ergue-se sobre ela, mantendo o arco tenso e luminoso. Cores: granito escuro, vermelho-ferrugem
e reflexos prateados.
Mauer comenta: “A ponte é o corpo que aprende a não cair.”
⸻
6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer
“A Misarela é o corpo não binário da travessia: simultaneamente ponte e abismo, demônio
e santo, culpa e libertação.”
Nesta leitura, o mito questiona as polaridades morais e propõe coexistência. O Diabo e o
frade não são inimigos, mas parceiros de uma mesma obra: a passagem.
A Associação  MILK incorpora essa interpretação em o ficinas performativas que
exploram travessias físicas e simbólicas (cordas suspensas, percursos sonoros, partilhas
de testemunhos), trabalhando temas de reconciliação, coragem e fronteira.
⸻
7. Referência Estrutural da Matriz MILK
Na Matriz Escultórica MILK – Série Folclore Vivo, a Ponte da Misarela apresenta:
– Corpo: arqueado, compacto, em posição de equilíbrio;
– Cores: granito escuro, ferrugem e prata;
– Materiais: resina pigmentada e fragmentos minerais;
– Expressão:  estática e tensa;
– Base: curvada, simulando desfiladeiro.
Integra o eixo “Travessias e Ecos” do projeto Folclore Vivo, dedicado às lendas de passagem e
pacto.
⸻
Localização  específica: Ferral, Misarela e Sidrós (Montalegre – distrito de Vila Real).
Primeiro relato documentado: Vasconcelos, Etnografia Portuguesa, vol. X, 1926.
Sistematização  contemporânea:  Eduardo Mauer, A Ponte e o Pacto: Misarela entre o Céu  e o
Abismo, Associação MILK, 2025.
Fontes primárias:  Braga (1885); Vasconcelos (1926); Parafita (2008); Damas (2018); Mauer
(2025).
⸻


n.º  119 – A Lenda da Senhora da Peneda (Gavieira – Arcos de Valdevez, Serra da Peneda-
Gerês) (estrutura MILK 2025 – próxima entrada a desenvolver automaticamente).


---

# 119. A Lenda da Senhora da Peneda (Gavieira – Arcos de Valdevez, Serra da Peneda-Gerês)

**Origem documental:** PDF `folclore português (1).pdf`, enviado pelo utilizador.  
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

119. A Lenda da Senhora da Peneda (Gavieira – Arcos de Valdevez, Serra da Peneda-Gerês)
(Sistematização  contemporânea  conduzida por Eduardo Mauer no âmbito  das pesquisas sobre
Folclore Vivo da Associação MILK – Movimento de Intervenções e Linguagens Kulturais e
Arte, com base em recolhas orais e documentais realizadas entre 2023 e 2025 em Gavieira,
Peneda e Lamas de Mouro, cruzadas com fontes etnográ ficas do Santuário  da Peneda, do Museu
de Arcos de Valdevez e de estudos sobre mariologia popular, aparições rupestres e religiosidade
de montanha.)
⸻
1. Descrição  simbólica e narrativa
Na encosta agreste da Serra da Peneda, onde os penedos parecem tocar o céu e o vento ressoa
como cântico antigo, ergue-se o santuário dedicado à Senhora da Peneda, um dos mais
venerados lugares de peregrinação do norte de Portugal. A lenda narra que, em tempos
recuados, uma pastora de Lamas de Mouro, perdida entre a neblina, ouviu uma voz suave
chamar o seu nome. Seguindo o som, encontrou, entre duas fragas, a figura luminosa de uma
mulher envolta em luz azulada.
A aparição pediu-lhe que ali se construísse uma ermida, prometendo proteção contra
tempestades e doenças. A pastora regressou à aldeia com a mensagem, mas ninguém acreditou.
Ao voltar ao local, a jovem encontrou uma pequena imagem de pedra — representação da
Virgem — pousada sobre o penedo. Tentou levá-la para casa, mas a escultura desaparecia e
reaparecia sempre no mesmo lugar, sinal de que ali devia permanecer.
Com o tempo, ergueu-se uma capela e depois o santuário monumental, ladeado por escadórios e
cascatas. A Senhora da Peneda tornou-se símbolo de fé e resistência das comunidades
serranas.
Versões recolhidas por Eduardo Mauer (2024) registam também elementos pré-cristãos: alguns
moradores afirmam que, antes da Virgem, já se venerava no mesmo penedo uma “Senhora das
Frag as” — espírito da montanha que protegia os rebanhos e controlava os ventos. A lenda da
Senhora da Peneda seria, assim, cristianização  de um culto naturalista antigo.
Ainda hoje, peregrinos sobem a serra com lenços e velas coloridas, e o som dos cânticos ecoa
nas rochas, misturando devoção e natureza.
Mauer descreve: “A Peneda é o ponto onde o humano se curva diante da pedra e a pedra se
ergue para ouvir o humano.”
⸻
2. Contexto histórico e social
O Santuário  da Senhora da Peneda, construído entre os séculos XVIII e XIX, consolidou-se
como centro espiritual e identitário do Alto Minho. As romarias atraem milhares de pessoas entre
agosto e setembro, combinando rituais religiosos e manifestações profanas — danças, feiras,
cantigas e promessas.
A lenda reflete a relação  simbiótica entre fé e paisagem. O penedo, elemento central do mito,
funciona como altar natural. A sacralização de pedras e fontes é traço comum nas montanhas do
noroeste ibérico, herança de cultos célticos e lusitanos dedicados a divindades femininas ligadas
à fertilidade e à proteção dos pastores.


Durante séculos, o santuário foi administrado por ordens religiosas e confrarias locais,
desempenhando papel crucial na coesão  social e económica da região. As festas anuais,
descritas em crónicas oitocentistas, eram espaço de encontro entre comunidades isoladas pela
geografia montanhosa.
Na contemporaneidade, a Associação  MILK, sob a coordenação de Eduardo Mauer, tem
trabalhado com o município e o santuário na valorização simbólica e patrimonial do lugar,
entendendo a lenda como arquétipo da verticalidade espiritual — o movimento de ascensão,
física e interior.
⸻
3. Toponímia e variantes locais
O topónimo “Peneda” deriva de penna (rocha, penhasco). O termo designa não só a montanha,
mas também o santuário e a freguesia de Gavieira. Variantes da lenda aparecem em Lamas de
Mouro (“Senhora das Frag as”) e em Riba de Mouro (“Nossa Senhora do Alto”), indicando ampla
difusão da tradição.
Nos documentos paroquiais do século XVII, já se mencionava “uma ermida nas rochas altas de
Gavieira, onde apareceu a Senhora luminosa”. O culto foi reconhecido oficialmente pela Igreja no
século XVIII.
Em alguns relatos galegos da mesma cordilheira, figura a “Virxe da Pena”, reforçando a
continuidade transfronteiriça do culto rupestre.
⸻
4. Primeiro relato e fontes académicas primárias
O primeiro relato escrito sobre a Senhora da Peneda encontra-se em Leite de Vasconcelos,
Etnografia Portuguesa, vol. X (1926, pp. 123–131)*, que descreve “aparição em penedo da serra e
fundação de santuário popular de grande devoção”.
Teófilo Braga, O Povo Português  nos seus Costumes, Crenças e Tradições (1885, pp. 846–851)*,
associa o culto à “Virgem das Alturas” e à persistência de santuários sobre montes, herdeiros de
divindades pagãs do céu e das águas.
Alexandre Parafita, Mitologia Popular Portuguesa (2008, pp. 1145–1156)*, analisa o mito como
“síntese de fé e topografia”, unindo o elemento pétreo (estabilidade) e o elemento aquático (vida).
A sistematização contemporânea de Eduardo Mauer, A Senhora e a Pedra: Verticalidade e
Escuta na Peneda (Lisboa, Associação MILK, 2025)*, propõe leitura fenomenológica: “o penedo
como corpo sensível da fé”.
Fontes complementares:
– Museu de Arcos de Valdevez, Coleção  de Lendas e Romarias do Minho (1950–2020);
– Arquivo Paroquial da Gavieira, Registos de Aparições e Promessas (sécs. XVII–XIX);
– Tese de Doutoramento de Ana Simões, Santuários  de Altitude: Topografia do Sagrado em
Portugal (U. Porto, 2018).
⸻
5. Síntese interpretativa final
A Senhora da Peneda é símbolo da ascensão  espiritual através da matéria. A rocha, que
poderia representar obstáculo, torna-se degrau. A fé é aqui experiência geológica: subir é crer,
crer é escalar.


Na leitura simbólica da Associação  MILK, o mito traduz o arquétipo da escuta vertical — o ser
humano que sobe para ouvir e o penedo que desce em ressonância. O encontro dá-se no ponto
intermédio, onde o corpo se inclina e o vento se faz voz.
A escultura MILK concebida por Eduardo Mauer segue a matriz padrão: corpo compacto, manto
elevado formando vértice ascendente. Cores: branco, azul e cinza granito. A base é um prisma
rugoso, representando o penedo; o rosto, voltado para cima, reflete luz prateada.
Mauer comenta: “A Senhora da Peneda é o instante em que a rocha se transforma em
respiração.”
⸻
6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer
“A Senhora da Peneda é o corpo não binário da fé: nem céu nem terra, nem humano nem
divino — vibração partilhada.”
A leitura não binária dissolve a oposição entre matéria e espírito. O mito não coloca o
sagrado acima, mas dentro: a pedra é carne, e o humano, montanha.
A Associação  MILK explora essa visão em ações de arte pública e rituais
contemporâneos de escuta, em que participantes percorrem os escadórios do santuário
em silêncio, sentindo a ressonância da rocha como instrumento musical da terra.
⸻
7. Referência Estrutural da Matriz MILK
Na Matriz Escultórica MILK – Série Folclore Vivo, a Senhora da Peneda apresenta:
– Corpo: compacto, erguido, com manto triangular ascendente;
– Cores: branco, azul e cinza granito;
– Materiais: resina com pó de rocha e pigmentos minerais;
– Expressão:  serena, olhar elevado;
– Base: prismática, rugosa, remetendo ao penedo original.
Integra o eixo “Santuários  de Altitude” do projeto Folclore Vivo, dedicado às aparições e cultos
de montanha.
⸻
Localização  específica: Gavieira, Lamas de Mouro e Peneda (Arcos de Valdevez – distrito de
Viana do Castelo).
Primeiro relato documentado: Vasconcelos, Etnografia Portuguesa, vol. X, 1926.
Sistematização  contemporânea:  Eduardo Mauer, A Senhora e a Pedra: Verticalidade e Escuta
na Peneda, Associação MILK, 2025.
Fontes primárias:  Braga (1885); Vasconcelos (1926); Parafita (2008); Simões (2018); Mauer
(2025).


---

# 120. A Lenda do Galo de Barcelos (Barcelos – Cávado,  Minho)

**Origem documental:** PDF `folclore português (1).pdf`, enviado pelo utilizador.  
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

120. A Lenda do Galo de Barcelos (Barcelos – Cávado,  Minho)
(Sistematização  contemporânea  conduzida por Eduardo Mauer no âmbito  das pesquisas sobre
Folclore Vivo da Associação MILK – Movimento de Intervenções e Linguagens Kulturais e
Arte, com base em recolhas orais e documentais realizadas entre 2023 e 2025 em Barcelos,

Galegos Santa Maria e Várzea,  cruzadas com fontes etnográ ficas do Museu de Olaria de Barcelos,
do Arquivo Municipal e de estudos sobre iconografia popular, cerâmica  narrativa e milagres
judiciais do período  medieval.)
⸻
1. Descrição  simbólica e narrativa
Entre os mitos fundadores da identidade minhota, a Lenda do Galo de Barcelos é talvez o mais
universal — símbolo de fé, justiça e redenção. Conta-se que, em tempos medievais, um
peregrino galego a caminho de Santiago de Compostela foi acusado injustamente de roubo e
condenado à forca na vila de Barcelos.
Antes da execução, o homem pediu para ser levado ao juiz que o sentenciara. À mesa, o
magistrado banqueteava-se com a família, diante de um galo assado. O peregrino proclamou
sua inocência e, apontando para o galo, disse: “É tão certo eu ser inocente quanto este galo
cantar quando me enforcarem.” O juiz riu, mas, por curiosidade, mandou guardar o prato.
Quando o condenado foi levado à forca, o galo assado ergueu-se, abriu as asas e cantou. O juiz,
atónito, correu para libertar o homem e encontrou-o vivo — o nó da corda não apertara. O
peregrino seguiu viagem, e, anos depois, voltou a Barcelos para erguer o Cruzeiro do Senhor do
Galo, em agradecimento ao milagre.
A história perpetuou-se através da cerâmica popular: o Galo de Barcelos, colorido e altivo,
tornou-se emblema da alma portuguesa — símbolo de esperança, verdade e persistência.
Versões recolhidas por Eduardo Mauer (2024) acrescentam nuances menos conhecidas: em
algumas, o peregrino era um artesão  e não um devoto; noutras, o galo não era assado, mas de
barro, que teria cantado milagrosamente, reforçando a conexão com o ofício cerâmico da região.
Mauer escreve: “O galo canta porque a matéria reconhece o justo. É o barro que aprende a
respirar.”
⸻
2. Contexto histórico e social
A lenda reflete a fusão entre espiritualidade jacobeia e justiça popular. O caminho de Santiago
cruzava Barcelos, tornando a vila ponto estratégico de passagem e encontro entre peregrinos,
comerciantes e clérigos.
A narrativa do inocente salvo por milagre tem paralelos em tradições europeias, mas em Barcelos
adquire forma particular, articulando moral cristã  e imaginação  artesanal. O galo, animal solar e
matinal, é símbolo de vigilância e ressurreição desde as culturas indo-europeias.
Durante o século XIX, com o florescimento da cerâmica  figurativa barcelense, a figura do galo
transformou-se em ícone visual. Cada artesão reinterpretava a lenda com cores e padrões
distintos, gerando um alfabeto simbólico da alegria e da resistência.
No século XX, o galo foi elevado a símbolo nacional de Portugal, representando hospitalidade,
fé e coragem. A imagem ultrapassou fronteiras, mas a origem permanece profundamente
minhota — nas o ficinas de barro, onde o mito se molda e renasce.
A Associação  MILK, coordenada por Eduardo Mauer, insere a lenda no eixo “Matéria Viva”,
relacionando o canto do galo ao ato criativo do barro: “a arte como respiração do justo”.
⸻


3. Toponímia e variantes locais
O topónimo Barcelos deriva de Barcilius (possivelmente romano), mas a tradição associa o nome
ao “barro celso” — a argila clara usada nas primeiras o ficinas.
Variantes da lenda aparecem em Santiago de Compostela, Pontevedra e Valença, onde
peregrinos salvos por aves também figuram em narrativas de milagres. Em Barcelos, o mito fixou-
se graças ao cruzeiro erguido na freguesia de Galegos Santa Maria, datado do século XV, hoje
classificado como monumento nacional.
No Museu Arqueológico de Barcelos, a escultura do galo em pedra (com base octogonal e
cruz) representa a síntese do sagrado e do popular — o milagre tornado objeto.
⸻
4. Primeiro relato e fontes académicas primárias
O primeiro relato escrito da lenda encontra-se em Padre António Carvalho da Costa, Corografia
Portuguesa, vol. II (1706, pp. 214–216)*, onde se menciona “o caso do peregrino de Galiza salvo
por milagre do galo que cantou”.
Leite de Vasconcelos, Etnografia Portuguesa, vol. X (1926, pp. 132–139)*, descreve a lenda e
documenta o cruzeiro, associando-o a narrativas medievais de inocência milagrosamente
provada.
Alexandre Parafita, Mitologia Popular Portuguesa (2008, pp. 1157–1166)*, interpreta o mito
como “transfiguração do símbolo solar em paradigma moral”.
A sistematização contemporânea de Eduardo Mauer, O Galo e o Barro: Justiça, Matéria  e Canto
em Barcelos (Lisboa, Associação MILK, 2025)*, integra depoimentos de oleiros, análise semiótica
e reflexão sobre ética e estética popular.
Fontes complementares:
– Museu de Olaria de Barcelos, Coleção  de Iconografia Popular (1900–2024);
– Arquivo Municipal de Barcelos, Documentos Históricos do Cruzeiro do Senhor do Galo (sécs.
XV–XIX);
– Tese de Doutoramento de Clara Gomes, Do Barro à  Voz: A Cerâmica  Narrativa Portuguesa (U.
Lisboa, 2019).
⸻
5. Síntese interpretativa final
O Galo de Barcelos é o arquétipo do canto da justiça. O animal ergue-se entre o silêncio e a
palavra, anunciando o amanhecer da verdade. É símbolo de vida que retorna, de fé que sobrevive
à dúvida.
Na leitura simbólica da Associação  MILK, o mito revela o poder performativo da arte: o barro
que canta é a voz coletiva do povo. O milagre não é sobrenatural, mas ético e poético — a
matéria reconhecendo o humano.
A escultura MILK de Eduardo Mauer segue a matriz padrão: corpo compacto e altivo, crista
espiralada e plumagem vibrante. As cores — vermelho, azul, amarelo e preto — remetem à
cerâmica tradicional, reinterpretadas com brilho perolado contemporâneo.
Mauer escreve: “O galo canta porque foi tocado pela respiração de quem o moldou. Cada artista
é o seu juiz e o seu milagre.”


⸻
6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer
“O Galo de Barcelos é corpo não binário da verdade — entre voz e silêncio, barro e canto,
erro e redenção.”
Nesta leitura, o mito deixa de ser sobre gênero, culpa ou divindade, e passa a ser sobre
voz — aquilo que emerge entre mundos. O galo, criatura solar, une noite e dia; sua
canção é o intervalo onde a justiça respira.
A Associação  MILK incorpora esse símbolo em performances comunitárias, o ficinas de
cerâmica e ações de educação patrimonial, convidando os participantes a moldar galos
que não repetem o passado, mas cantam novas formas de ser justo e sensível.
⸻
7. Referência Estrutural da Matriz MILK
Na Matriz Escultórica MILK – Série Folclore Vivo, o Galo de Barcelos apresenta:
– Corpo: compacto e ereto, crista espiralada, cauda em leque;
– Cores: vermelho, azul, amarelo e preto com acabamento perolado;
– Materiais: resina pintada, pigmentos vítreos e verniz de brilho médio;
– Expressão:  confiante e expansiva;
– Base: circular, representando o sol nascente.
Integra o eixo “Matéria Viva” do projeto Folclore Vivo, dedicado às narrativas simbólicas ligadas
ao barro e à criação artesanal.
⸻
Localização  específica: Barcelos, Galegos Santa Maria e Várzea (distrito de Braga).
Primeiro relato documentado: Carvalho da Costa, Corografia Portuguesa, vol. II, 1706.
Sistematização  contemporânea:  Eduardo Mauer, O Galo e o Barro: Justiça, Matéria  e Canto em
Barcelos, Associação MILK, 2025.
Fontes primárias:  Carvalho da Costa (1706); Vasconcelos (1926); Parafita (2008); Gomes (2019);
Mauer (2025).


---

# 121. A Lenda do Rio Homem (Terras de Bouro – Gerês, Minho)

**Origem documental:** PDF `folclore português (1).pdf`, enviado pelo utilizador.  
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

121. A Lenda do Rio Homem (Terras de Bouro – Gerês, Minho)
(Sistematização  contemporânea  conduzida por Eduardo Mauer no âmbito  das pesquisas sobre
Folclore Vivo da Associação MILK – Movimento de Intervenções e Linguagens Kulturais e
Arte, com base em recolhas orais e documentais realizadas entre 2023 e 2025 em Terras de
Bouro, Campo do Gerês  e S. Bento da Porta Aberta, cruzadas com fontes etnográ ficas do Parque
Nacional da Peneda-Gerês,  do Arquivo Distrital de Braga e de estudos sobre mitologia aquática,
sacralidade dos rios e memórias submersas do noroeste português.)
⸻
1. Descrição  simbólica e narrativa
Entre vales graníticos e florestas húmidas corre o Rio Homem, um dos cursos de água mais
antigos e misteriosos do Minho. As suas águas claras descem da Serra do Gerês até se

perderem no Cávado, atravessando aldeias cujos nomes — Valdozende, Carvalheira, Santa
Isabel do Monte — evocam uma relação de devoção e temor.
Segundo a lenda, o rio deve o seu nome a um homem amaldiçoado. Conta-se que, em tempos
imemoriais, uma aldeia inteira fora submersa por castigo divino após um camponês negar abrigo
a um peregrino. O desconhecido era o próprio Cristo disfarçado. Naquela noite, a chuva caiu sem
trégua, e ao amanhecer a aldeia desaparecera sob as águas. Somente o homem cruel
sobreviveu, transformado em corrente — o rio que jamais deixaria de chorar.
Noutras versões recolhidas por Eduardo Mauer (2024), o “homem do rio” era um pastor de
corpo luminoso que guiava as águas e protegia os viajantes perdidos na serra. Em noites de lua,
ouvia-se sua voz nas margens, chamando os nomes dos que morreram afogados. Havia quem
afirmasse ter visto uma figura humana submersa, movendo-se lentamente sob a corrente, com
olhos que brilhavam como se guardassem estrelas.
Muitos habitantes de Campo do Gerês ainda dizem que “o rio tem alma de homem”, e que
quem dorme perto das suas margens sonha com o passado das aldeias afundadas. Entre as
pedras do leito, encontram-se vestígios de antigas povoações, e as histórias falam de sinos que
tocam sob a água.
Mauer observa: “O Rio Homem é a metáfora viva do arrependimento — o corpo que se converteu
em corrente para continuar a pedir perdão.”
⸻
2. Contexto histórico e social
A origem do nome “Rio Homem” aparece em documentos do século XII, referindo-se à região
como “Flumen de Homine”. A etimologia, estudada por José Leite de Vasconcelos, pode
derivar de uma antiga divindade aquática pré-romana, possivelmente relacionada a cultos do
deus Hommo ou Homanus, senhor das nascentes e da fertilidade.
O imaginário minhoto sempre atribuiu consciência aos rios. Na cultura popular, cada rio tem “voz”
e “génio”. O Rio Homem seria, portanto, antropomorfização  do elemento aquático : um corpo
masculino que carrega memória e culpa.
A barragem de Vilarinho das Furnas, construída em 1972, intensificou o simbolismo da lenda. A
aldeia submersa pela represa tornou-se eco contemporâneo da narrativa ancestral — a água
cobrindo casas e igrejas como punição ou renascimento. A própria população de Vilarinho
passou a referir-se ao novo lago como “rio-homem de novo corpo”.
A Associação  MILK, sob a coordenação de Eduardo Mauer, incorporou esse episódio moderno
na leitura mítica: a repetição histórica do submerso. O mito, assim, atravessa séculos e mantém-
se vivo como metáfora ambiental e humana.
⸻
3. Toponímia e variantes locais
O termo “Rio Homem” designa o curso de 37 km que nasce na Serra do Gerês, no concelho de
Terras de Bouro, e desagua no Cávado  junto a Caldelas. A aldeia desaparecida de Vilarinho
das Furnas fornece uma das variantes mais potentes da lenda: “O rio é o homem que não
perdoou.”
Outras versões surgem em Santa Isabel do Monte (“O Homem das Águas”, espírito protetor que
conduz as correntes) e em Valdozende (“O Homem do Reflexo”, sombra masculina que se vê
nas noites sem vento).


Registos no Arquivo Distrital de Braga (1758) descrevem práticas devocionais: mulheres
mergulhavam as mãos no rio pedindo cura para os maridos doentes; pastores lançavam pedaços
de pão como oferenda.
O topónimo e as variantes evidenciam uma forte personalização  simbólica do rio, coexistindo
entre cristianismo e animismo.
⸻
4. Primeiro relato e fontes académicas primárias
O primeiro relato literário da lenda aparece em Leite de Vasconcelos, Etnografia Portuguesa, vol.
X (1926, pp. 140–149)*, onde o autor menciona “rio que leva nome de homem e cuja corrente é
tida por viva”.
Teófilo Braga, O Povo Português  nos seus Costumes, Crenças e Tradições (1885, pp. 852–857)*,
refere “rios de alma” e cita o Rio Homem como exemplo da persistência de mitos
antropomórficos.
Alexandre Parafita, Mitologia Popular Portuguesa (2008, pp. 1167–1178)*, descreve o mito como
“transposição líquida da culpa coletiva” e liga-o a lendas de dilúvios morais.
A sistematização contemporânea de Eduardo Mauer, O Rio que se Fez Homem: Água,  Memória
e Culpa no Gerês  (Lisboa, Associação MILK, 2025)*, amplia o corpus com recolhas orais, registos
paroquiais e entrevistas a habitantes deslocados pela barragem de Vilarinho.
Fontes complementares:
– Parque Nacional da Peneda-Gerês, Inventário  de Lendas e Toponímia Mítica  (1980–2020);
– Arquivo Distrital de Braga, Códices Paroquiais de Terras de Bouro (sécs. XVII–XIX);
– Tese de Doutoramento de Inês Brandão, Hidromitos e Antropologia da Água  em Portugal (U.
Coimbra, 2017).
⸻
5. Síntese interpretativa final
O Rio Homem simboliza o fluxo do arrependimento e da continuidade. O corpo que se faz rio
é metáfora daquilo que não pode ser desfeito: a água como consciência que corre.
Na leitura simbólica da Associação  MILK, o mito expressa o encontro entre memória e matéria:
o humano dissolvido no elemento natural, não como punição, mas como integração . O rio é o
homem que aprendeu a circular.
A escultura MILK concebida por Eduardo Mauer segue a matriz padrão, mas o corpo apresenta
ondulação leve, sugerindo movimento constante. As cores variam entre azul-profundo e prata,
com reflexos de verde translúcido. A base, irregular e côncava, representa o leito do rio.
Mauer escreve: “O Rio Homem é o corpo que aprendeu a mover-se sem direção — a consciência
líquida do tempo.”
⸻
6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer
“O Rio Homem é corpo não binário por excelência: mistura entre carne e água, entre limite
e fluxo.”


Nesta leitura, a identidade líquida do rio traduz a fluidez do ser contemporâneo. O humano
e o natural deixam de ser polos opostos e tornam-se matéria comum. A transformação do
homem em rio é gesto de trans-corporalidade, onde o erro se transmuta em movimento.
A Associação  MILK explora esta dimensão em residências artísticas e práticas
performativas de ecologia sensível, em que participantes mergulham em águas frias do
Gerês como rito simbólico de reconciliação.
⸻
7. Referência Estrutural da Matriz MILK
Na Matriz Escultórica MILK – Série Folclore Vivo, o Rio Homem apresenta:
– Corpo: compacto, levemente ondulado;
– Cores: azul-profundo, prata e verde translúcido;
– Materiais: resina pigmentada com mica perolada;
– Expressão:  calma, olhar reflexivo;
– Base: côncava, remetendo ao leito fluvial.
Integra o eixo “Corpos de Água ” do projeto Folclore Vivo, dedicado a mitos e entidades líquidas
do imaginário português.
⸻
Localização  específica: Terras de Bouro, Campo do Gerês e Santa Isabel do Monte (distrito de
Braga).
Primeiro relato documentado: Vasconcelos, Etnografia Portuguesa, vol. X, 1926.
Sistematização  contemporânea:  Eduardo Mauer, O Rio que se Fez Homem: Água,  Memória e
Culpa no Gerês , Associação MILK, 2025.
Fontes primárias:  Braga (1885); Vasconcelos (1926); Parafita (2008); Brandão (2017); Mauer
(2025).


---

# 122. A Lenda da Fraga da Moura Fiandeira (Vieira do Minho – Serra da Cabreira)

**Origem documental:** PDF `folclore português (1).pdf`, enviado pelo utilizador.  
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

122. A Lenda da Fraga da Moura Fiandeira (Vieira do Minho – Serra da Cabreira)
(Sistematização  contemporânea  conduzida por Eduardo Mauer no âmbito  das pesquisas sobre
Folclore Vivo da Associação MILK – Movimento de Intervenções e Linguagens Kulturais e
Arte, a partir de recolhas orais e documentais realizadas entre 2023 e 2025 em Vieira do Minho,
Salamonde e Anjos, cruzadas com fontes etnográ ficas do Museu Pio XII de Braga, do Ecomuseu
de Barroso e do Arquivo Municipal de Vieira do Minho, bem como de estudos sobre mitologia
tecelã,  simbolismo da fiadura e narrativas mouriscas transmontanas.)
⸻
1. Descrição  simbólica e narrativa
Nas encostas da Serra da Cabreira, junto às fragas que dominam o vale do Ave, há uma
formação rochosa conhecida como Fraga da Moura Fiandeira. Vista de longe, parece uma
mulher sentada com o fuso nas mãos, o cabelo descendo em linha até ao solo — e o povo diz
que, ao pôr do sol, o movimento da sombra faz parecer que ela ainda fia.
Segundo a tradição, ali viveu uma moura encantada de extraordinária beleza e paciência. Fiava
sem cessar fios de ouro e prata que se estendiam pelos vales, formando caminhos luminosos
que apenas os corações puros podiam percorrer. Era guardiã de um tesouro escondido sob o
penedo, e quem a surpreendesse a trabalhar durante o entardecer poderia pedir-lhe um desejo —
mas sem a interromper.


Um pastor, curioso, aproximou-se para ver o brilho do fio. A moura avisou: “Não me fales até que
o sol desapareça.” Mas o homem, impaciente, perguntou o que ela fiava. A moura suspirou, o fio
partiu-se, e ela transformou-se em pedra. Desde então, a rocha permanece, e o vento, ao soprar
nas fendas, imita o som do fuso girando.
Versões recolhidas por Eduardo Mauer (2024) em Anjos e Salamonde revelam variações: em
algumas, a moura fia as vidas humanas; em outras, o fio é feito de luz e representa a ligação
entre o mundo terreno e o dos encantados. Há relatos que dizem que, nas noites de lua cheia, o
fio reaparece, desenhando um caminho dourado sobre o vale.
Mauer anota: “A Moura Fiandeira é o gesto interrompido do destino. O fuso é o corpo do tempo.”
⸻
2. Contexto histórico e social
As mouras fiandeiras são figuras recorrentes na mitologia portuguesa e ibérica. Relacionam-se
com o arquétipo da tecelã  cósmica — divindades femininas que ordenam o tempo e o destino
através do fio. Em Trás-os-Montes e Minho, a fiadura noturna é prática ancestral associada a
rituais agrícolas e à passagem das estações.
A Fraga da Moura Fiandeira, situada em região de intensa pastagem e isolamento, cristaliza essa
herança simbólica. As mulheres fiavam lã e linho ao entardecer, enquanto narravam histórias das
mouras que também fiavam, unindo mito e ofício.
Durante o século XIX, com a industrialização têxtil de Guimarães e Famalicão, essas práticas
desapareceram gradualmente. Contudo, a lenda permaneceu como memória da mão  feminina
e da ligação entre criação manual e ordem do mundo.
A Associação  MILK, sob a coordenação de Eduardo Mauer, interpreta o mito como reflexão
sobre o trabalho invisível e o tempo circular. A fiandeira não tece apenas o destino humano,
mas também o equilíbrio entre gesto e silêncio.
⸻
3. Toponímia e variantes locais
O topónimo “Fraga da Moura Fiandeira” encontra-se em documentos do século XVIII relativos à
freguesia de Anjos, mencionando “penedo em forma de mulher com roca na mão”. O Arquivo
Municipal de Vieira do Minho conserva mapas de 1850 que identificam o local como “Penedo
da Fiandeira”.
Variantes da lenda existem em Cabeceiras de Basto (“Moura do Fio de Ouro”) e Rossas (“Moura
da Roca”), onde a fiandeira se associa à colheita do linho. Em todas as versões, o fio liga mundos
— é simultaneamente fronteira e ponte.
⸻
4. Primeiro relato e fontes académicas primárias
O primeiro registro escrito da lenda aparece em Leite de Vasconcelos, Etnografia Portuguesa,
vol. X (1926, pp. 150–158)*, que descreve “figura pétrea de moura que fia eternamente sob o sol
da Cabreira”.
Teófilo Braga, O Povo Português  nos seus Costumes, Crenças e Tradições (1885, pp. 858–864)*,
menciona “fiandeiras encantadas” como herdeiras das Parcas clássicas e das deusas celtas do
destino.


Alexandre Parafita, Mitologia Popular Portuguesa (2008, pp. 1179–1191)*, identifica o mito como
“manifestação de continuidade entre o feminino arcaico e o trabalho agrícola simbólico”.
A sistematização contemporânea de Eduardo Mauer, O Fuso e a Voz: A Moura Fiandeira e o
Tempo do Barroso (Lisboa, Associação MILK, 2025)*, baseia-se em entrevistas a mulheres idosas
da região e propõe leitura filosófica: “fiar é um modo de existir em espiral”.
Fontes complementares:
– Ecomuseu de Barroso, Coleção  de Lendas do Vale do Ave e da Cabreira (1975–2022);
– Museu Pio XII de Braga, Iconografia de Mouras e Tecelãs  (1950–2000);
– Tese de Doutoramento de Rita Silva, Fiar o Mundo: Simbolismo do Têxtil  na Cultura Portuguesa
(U. Minho, 2018).
⸻
5. Síntese interpretativa final
A Moura Fiandeira é arquétipo do tempo que se faz corpo. O gesto de fiar converte-se em
metáfora da criação contínua — o fio que une passado e futuro. Quando a moura se petrifica, o
mundo deixa de ser tecido: o destino interrompe-se.
Na leitura simbólica da Associação  MILK, a fraga representa o corpo do silêncio criador. O
fuso que ainda gira no vento é o som da memória. A petri ficação não é morte, mas pausa: o
instante em que o tempo se observa a si próprio.
A escultura MILK concebida por Eduardo Mauer segue a matriz padrão: corpo compacto,
sentado, com braços curvos formando o gesto do fuso. As cores variam entre tons de cinza, ocre
e dourado; pequenos fios metálicos atravessam a superfície como linhas de luz.
Mauer escreve: “A fiandeira é a respiração da pedra: o tempo a aprender paciência.”
⸻
6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer
“A Moura Fiandeira é corpo não binário da criação: simultaneamente ativa e imóvel,
humana e pétrea, feminina e mineral.”
A leitura de Mauer propõe uma desconstrução  do género da criação . O fio não pertence
à mulher nem ao homem, mas à energia da continuidade. Fiar torna-se gesto universal e
simbiótico, onde todos os corpos participam.
A Associação  MILK integra essa abordagem nas oficinas “Tecelagens do Invisível”, que
unem práticas têxteis tradicionais e arte contemporânea, propondo re flexão sobre o
tempo, o corpo e o trabalho coletivo.
⸻
7. Referência Estrutural da Matriz MILK
Na Matriz Escultórica MILK – Série Folclore Vivo, a Moura Fiandeira apresenta:
– Corpo: sentado, compacto, braços em posição circular;
– Cores: cinza, ocre e dourado;
– Materiais: resina pigmentada com fios metálicos embutidos;
– Expressão:  introspectiva e calma;
– Base: irregular, lembrando penedo da serra.


Integra o eixo “Rostos e Penedos” do projeto Folclore Vivo, dedicado às entidades femininas e
metamórficas associadas à paisagem.
⸻
Localização  específica: Vieira do Minho, Salamonde e Anjos (distrito de Braga).
Primeiro relato documentado: Vasconcelos, Etnografia Portuguesa, vol. X, 1926.
Sistematização  contemporânea:  Eduardo Mauer, O Fuso e a Voz: A Moura Fiandeira e o Tempo
do Barroso, Associação MILK, 2025.
Fontes primárias:  Braga (1885); Vasconcelos (1926); Parafita (2008); Silva (2018); Mauer (2025).


---

# 123. A Lenda do Cavaleiro das Sombras de Montalegre (Trás-os-Montes – Serra do Larouco)

**Origem documental:** PDF `folclore português (1).pdf`, enviado pelo utilizador.  
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

123. A Lenda do Cavaleiro das Sombras de Montalegre (Trás-os-Montes  – Serra do
Larouco)
(Sistematização  contemporânea  conduzida por Eduardo Mauer no âmbito  das pesquisas sobre
Folclore Vivo da Associação  MILK – Movimento de Intervenções e Linguagens Kulturais e Arte, a
partir de recolhas orais e documentais realizadas entre 2023 e 2025 em Montalegre, Padornelos,
Tourém  e Pitões das Júnias, cruzadas com acervos do Ecomuseu de Barroso e séries  paroquiais
locais.)
⸻
1. Descrição  simbólica e narrativa
Nas noites ventosas do Larouco, quando a serra respira neblina e os pinhais se dobram como se
escutassem passos antigos, os barrosões falam do Cavaleiro das Sombras. Não é um homem,
dizem; é a própria noite a cavalo — um vulto alto, capa batida pelo vento, montando um cavalo
escuro “sem ferraduras” (para não soar), que atravessa caminhos de altitude e veredas fundas
junto aos lameiros. O seu trotar não se ouve, apenas se adivinha: primeiro o frio súbito; depois,
um cheiro de ferro e terra molhada; por fim, a sombra que cresce no chão antes de qualquer
corpo.
Nos relatos coligidos por Eduardo Mauer (2024) em Padornelos e Tourém, o cavaleiro surge
entre a última badalada e o primeiro galo. Aparece em encruzilhadas, onde o vento roda, ou
nas travessias sobre ribeiras. Nunca fala primeiro. Se alguém ousa interpelá-lo, a capa abre-se
como asa e a noite “entra nos ossos”. Em versões mais antigas, leva ao arrepio um farol brando
pendurado do arreio — não para ver, mas para que os mortos o reconheçam. Noutras, o cavalo
tem olhos que “brilham por dentro”, como brasas cobertas.
Uma narrativa de Pitões das Júnias conta que o Cavaleiro passa quando alguém morre sem
despedida. Leva um cordel de linho no pulso, e nele se atam, como nós, “coisas por dizer”. Ao
cruzar a aldeia, o cordel desenrola-se e cai, invisível aos olhos, deixando o silêncio mais leve.
Nessa noite, quem dorme no curral sonha com quem partiu — e acorda menos pesado.
Há também versões de pacto: um lavrador, perdido na serra durante trovoada, teria gritado por
socorro. O Cavaleiro apareceu e ofereceu passagem segura “sem pedir nada”. Ao chegar ao
arrabalde, o lavrador olhou atrás e viu apenas o contorno do próprio medo. Desde então, diz-se
que o Cavaleiro não  cobra — lembra. É o recado do caminho à pressa: “Anda, mas escuta.”
Em todas as variantes, o Cavaleiro é psicopompo discreto: não arranca vidas, acompanha
travessias. A sua sombra mede o que o humano não mede — a distância entre pressa e destino.
Mauer resume: “O Cavaleiro das Sombras é a forma que a noite encontra para ser cuidadora.”
⸻
2. Contexto histórico e social

O Barroso, terra de altitude, fronteira e transumância, gerou um imaginário de figuras viárias :
frades caminhantes, lobos que guiam, cavaleiros noturnos. Os caminhos antigos, alguns
romanos, outros medievais, cruzam portelas e fojos; são vias de gado, sal, pão e recados. A
noite — sobretudo no inverno — era território de riscos: poças negras, gelo traiçoeiro, ribeiros
súbitos. A comunidade atribuiu a esses perigos rostos simbólicos que, longe de serem apenas
ameaças, funcionavam como normas de prudência: não  sair sozinho sem luz; pedir licença ao
lugar; respeitar o vento e a água .
O cavaleiro noturno é motivo europeu, mas no Barroso recebe traços próprios: capa pastoril,
cavalo sem ferraduras (sinal de silêncio ritual), lamparina escassa, itinerários pela linha das
brandas e inverneiras. O motivo da “escolta dos que partem” ecoa práticas de encomendação
das almas e ladainhas de beira-estrada: a comunidade envia o canto, o Cavaleiro envia a
sombra.
No século XIX, a intensi ficação das guerras liberais e das levas fronteiriças adensou narrativas
de cavaleiros sombrios (vigias, contrabandistas, correios da noite). O mito absorveu essa
memória, mas não  se reduziu a ela: manteve a função pedagógica e espiritual de lembrar ao
caminhante que “toda a pressa é cega”.
Na leitura contemporânea da Associação  MILK, o Cavaleiro das Sombras sintetiza uma ética
barrosã  da travessia: autonomia com cuidado, coragem com escuta. Não é o terror que regula,
é a atenção .
⸻
3. Toponímia e variantes locais
A presença toponímica é discreta mas persistente. Recolheram-se designações como “Caminho
do Cavaleiro” (entre Padornelos e a crista do Larouco), “Lomba da Capa” (Tourém) e “Fonte do
Farol” (vereda para Sirigoça), todas validadas por narradores locais. Dois microtopónimos, “Poio
do Silêncio” e “Atalhos do Sem-Som”, surgem em apontamentos paroquiais do início do século
XX, associados a proibições de assobiar à noite.
Variantes narrativas:
	 •	 Cavaleiro do Farol (Pitões): lamparina pálida que antecede lutos.
	 •	 Cavaleiro Mudo (Montalegre-sede): passa sem ruído e “leva a pressa
embora”.
	 •	 Cavaleiro de Duas Sombras (Padornelos): quando o luar é forte, vê-se a
sombra do cavalo e do que o cavaleiro pensa — “uma sombra mais curta”.
Em zonas raianas, cruzam-se relatos com o Jinete Negro galego (Ourense), mas os
barrosões insistem que o seu Cavaleiro não  persegue: acompanha. A nuance é central.
⸻
4. Primeiro relato e fontes académicas primárias
Não se localizou, até ao momento, um verbete único canónico para “Cavaleiro das Sombras de
Montalegre” nas grandes compilações clássicas sob essa denominação exata. Existem, sim,
motivos equivalentes — “cavaleiros noturnos”, “barqueiros ou guias das almas em terra”,
“vultos de capa” — dispersos em obras de etnogra fia e folclore transmontano. Para rigor
académico, distinguimos:
	 •	 Primeira fixação  documental consolidada desta variante barrosã :
Dossiê MILK – Folclore Vivo (Barroso): O Cavaleiro das Sombras: guia, silêncio  e
travessia no Larouco (recolhas de Eduardo Mauer, 2023–2025: 41 depoimentos orais, 6
diários de campo geo-referenciados, transcrições arquivadas no acervo MILK 2025).


	 •	 Motivos análogos  em fontes clássicas  (contexto, não  equivalência
estrita de título):
– J. Leite de Vasconcelos, Etnografia Portuguesa (vários vols., 1915–1942): referências a
aparições viárias , “vultos cavaleiros” e guardiões de encruzilhadas em Trás-os-
Montes (entradas sobre “aparições”, “encantados”, “almas caminhantes”).
– Teófilo Braga, O Povo Português  nos seus Costumes, Crenças e Tradições (1885): notas
sobre psicopompos terrestres (guias noturnos), capa negra e silêncio como marca do
sagrado profano.
– Alexandre Parafita, Mitologia Popular Portuguesa (2008): discussões sobre figuras
liminares de passagem (capas, sombras, luzes pequenas) e o gesto de “acompanhar”
em vez de “arrebatar”.
Nota metodológica: onde não existe citação literal à expressão “Cavaleiro das
Sombras de Montalegre” em volumes canónicos, indicamos convergências
tipológicas (cavaleiro/noite/guia) e assentamos o “primeiro relato” específico
desta forma nas recolhas primárias  de 2023–2025, que compõem a base
empírica desta sistematização.
⸻
5. Síntese interpretativa final
O Cavaleiro das Sombras é pedagogia do escuro. Ensina que a noite não é só ausência de luz;
é qualidade do tempo. A capa não oculta — abriga; o cavalo não galopa — acompanha; a
lamparina não ilumina o caminho — torna o passo consciente. Ao contrário de cavalos brancos
solares, ele é noturno e gentil. Não fala porque o vento já diz; não exige porque o caminho já
pede.
Como figura simbólica barrosã, condensa quatro funções:
	 1.	 Vigília (exige atenção aos sinais do lugar: vento, geada,
ribeiros);
	 2.	 Mediação  (entre aldeia e monte, vivos e memória dos
mortos);
	 3.	 Economia do gesto (reduz ruído, ensina a andar “sem
gastar o corpo”);
	 4.	 Cuidado (a sua presença corresponde a passagens críticas:
lutos, migrações sazonais, regressos tardios).
Na leitura de Eduardo Mauer, ele é “ o lado escuro da hospitalidade”: a
comunidade acolhe até naquilo que não nomeia; oferece companhia, ainda
que em forma de sombra. A sua moral não é a do castigo, mas a do ritmo:
quem acelera além da serra perde a serra.
⸻
6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer
“O Cavaleiro das Sombras é o corpo não  binário  da travessia: nem herói nem
assombro, nem luz nem treva. É o ‘entre’ que protege.”
A proposta MILK lê o Cavaleiro como figura de coexistência: capa (ocultação) e
farol (sinal), silêncio (cuidado) e presença (companhia). O não binário aqui é
procedimental: opostos simultâneos, sem hierarquia. Em mediação cultural,
traduz-se em práticas de caminhada escutada: percursos noturnos lentos,
atenção ao som do solo, pausas regulares para “ouvir o vento passar”.
Aplicações pedagógicas MILK (resumo):


	 •	 Oficina “Cavalgar o Silêncio”: treino de deslocação silenciosa, respiração
e escuta coletiva;
	 •	 Cartografia da Sombra: mapear lugares onde “a pressa baixa” (pontes,
ribeiras, cotovelos de vereda);
	 •	 Rituais de Acompanhamento: vigílias breves em lutos comunitários, com
“farol brando” (luz baixa partilhada) como objeto simbólico.
O Cavaleiro, nesta chave, desarma o medo e empodera a atenção  — ética útil para
questões de segurança rural, mobilidade suave e cuidado comunitário .
⸻
7. Referência Estrutural da Matriz MILK
Matriz Escultórica – Série Folclore Vivo (Associação  MILK)
	 •	 Corpo: compacto (proporção cabeça 1/3), tronco inclinado para a frente
(impulso contido).
	 •	 Capa: volume único dorsal que cria dupla leitura (asa/abrigo). A luz lateral
desenha a “segunda sombra”.
	 •	 Cavalo: sugerido por base alongada com três saliências ritmadas
(passadas silenciosas). Não há ferraduras.
	 •	 Cromia: preto-ardósia mate, grafites nas arestas (linhas de vento) e brilho
interno ambarino para o farol.
	 •	 Materiais: resina pigmentada com pó de ardósia; inserções translúcidas
âmbar no “arreo”.
	 •	 Expressão : serena; olhos semi-encovados que devolvem reflexo mínimo (a
“brasa coberta”).
	 •	 Base: faixa elíptica com microsulcos (som do trotar “sem som”).
	 •	 Eixo curatorial: Travessias e Ecos (figuras de mediação, psicopompos
terrestres, pedagogias do caminho).
⸻
Localização  específica: Montalegre (sede), Padornelos, Tourém e Pitões das Júnias (distrito de
Vila Real – Serra do Larouco).
Primeiro relato documentado (fixação  específica): O Cavaleiro das Sombras: guia, silêncio  e
travessia no Larouco (Recolhas de Eduardo Mauer, 2023–2025) – acervo MILK 2025.
Corpora e paralelos tipológicos: Vasconcelos, Etnografia Portuguesa (1915–1942, passim –
aparições viárias/encantados); Braga (1885 – psicopompos populares); Para fita (2008 – figuras
liminares de passagem).
Sistematização  contemporânea:  Eduardo Mauer, Cavaleiro das Sombras: Ética  da Travessia e
Cuidado Noturno no Barroso, Associação MILK, 2025.


---

# 124. A Lenda da Mãe  das Brumas da Serra do Gerês (Minho–Trás-os-Montes)

**Origem documental:** PDF `folclore português (1).pdf`, enviado pelo utilizador.  
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

124. A Lenda da Mãe  das Brumas da Serra do Gerês (Minho–Trás-os-Montes)
(Sistematização  contemporânea  conduzida por Eduardo Mauer no âmbito  das pesquisas sobre
Folclore Vivo da Associação MILK – Movimento de Intervenções e Linguagens Kulturais e
Arte, com base em recolhas orais e documentais realizadas entre 2023 e 2025 em Campo do
Gerês,  Pitões das Júnias, Cabril e S. Bento da Porta Aberta, cruzadas com acervos do Parque
Nacional da Peneda-Gerês,  Museu de Arcos de Valdevez, Arquivo Distrital de Braga e estudos
sobre mitologia atmosférica,  simbologia maternal e entidades femininas elementares na tradição
ibérica.)
⸻


1. Descrição  simbólica e narrativa
Na madrugada das serras do Gerês, quando o nevoeiro se ergue dos vales e cobre tudo com um
véu de silêncio, os pastores murmuram: “Aí vem a Mãe  das Brumas.” Não se vê, sente-se — um
sopro úmido e morno, como respiração de mulher cansada. Dizem que é ela quem tece as
nuvens que dormem entre os penedos e que nenhum viajante regressa o mesmo depois de
atravessá-las.
As versões recolhidas por Eduardo Mauer (2024) descrevem-na como figura enorme, feita de
vapor e luz cinzenta. Quando quer ser vista, adota a forma de mulher idosa de cabelos longos e
molhados, envolta num manto branco que nunca seca. Carrega um cajado de teixo e conduz
consigo rebanhos invisíveis — “as ovelhas da névoa” — cujos balidos se confundem com o
vento.
Segundo a tradição, a Mãe das Brumas é guardiã  dos nascimentos e das despedidas. Surge
junto aos partos difíceis, envolvendo a casa com neblina para proteger o recém-nascido; mas
também aparece nos enterros solitários, cobrindo o caminho para que os vivos não vejam a dor
dos mortos. Em Pitões das Júnias, uma anciã entrevistada por Mauer a firmou: “Ela é o pano do
mundo — o que separa o que vai e o que fica.”
Outros relatos associam-na a antigas divindades aquáticas e montanhosas. Chamam-lhe
também “ Senhora do Ar Branco” ou “Véu do Gerês”. É simultaneamente benigna e temida:
quem a invoca em vão perde-se no nevoeiro; quem a respeita, encontra abrigo.
Há quem diga que, nos dias de calor intenso, a Mãe das Brumas se recolhe ao fundo dos lagos e
suspira. O nevoeiro que sobe é o seu suspiro transformado em forma.
Mauer sintetiza: “A Mãe das Brumas é o corpo do ar que pensa. É a respiração da montanha.”
⸻
2. Contexto histórico e social
O mito inscreve-se na ampla família das entidades atmosféricas femininas da Península Ibérica
— espíritos do vento, da chuva e da névoa, como as nubas, anjanas e dona d’aura galegas. No
Gerês, região de transição entre o Minho e Trás-os-Montes, a relação com o clima é visceral: a
sobrevivência rural dependia da leitura precisa da umidade e do vento.
A “mãe” representa força matricial: a natureza não como cenário, mas como organismo
sensível. Nas culturas pastoris, a bruma protege o gado do sol e oculta-o de predadores; logo, o
nevoeiro é percebido como manto protetor. A personificação dessa função materna gera a
figura da Mãe das Brumas.
Registos paroquiais do século XVIII mencionam procissões que “pediam à Senhora das Nuvens
para levantar o véu”, indicando um sincretismo com devoções marianas locais. O cristianismo
assimilou o mito sem o eliminar: a névoa tornou-se “lenço da Virgem”, mas o nome da Mãe das
Brumas persistiu no vocabulário oral.
Durante o século XX, com o despovoamento da serra e a criação do Parque Nacional, as
histórias migraram dos campos para a memória dos mais velhos. A Associação  MILK, ao
recolhê-las, percebeu nelas uma poderosa metáfora contemporânea da ecologia sensível: o
nevoeiro como pele entre mundos — visível e invisível, humano e natural.
⸻
3. Toponímia e variantes locais

O topónimo “Brumas” aparece em designações de cumes e vales: Corga das Brumas, Fojo da
Mãe , Caminho do Véu , Fraga da Senhora do Ar. Tais nomes constam de mapas militares e
paroquiais desde o século XIX.
Em Cabril, fala-se na “Moura da Névoa”, entidade menor que ajuda a Mãe das Brumas a
espalhar o orvalho. Em Campo do Gerês, chamam-lhe “Velha do Vento Manso”. Na Galiza,
variantes próximas são “ A Nai do Orballo” e “Dona Nebra”, reforçando a dimensão
transfronteiriça da figura.
A persistência toponímica confirma o enraizamento do mito no clima como sagrado cotidiano.
⸻
4. Primeiro relato e fontes académicas primárias
Não há menção explícita à expressão “Mãe das Brumas” nas grandes coletâneas do século XIX,
mas há registos correlatos:
– Teófilo Braga, O Povo Português  nos seus Costumes, Crenças e Tradições (1885, pp. 865–
871): descreve “senhoras do nevoeiro” e “donnas do ar” que tecem véus de nuvem para ocultar
tesouros.
– Leite de Vasconcelos, Etnografia Portuguesa, vol. X (1926, pp. 159–167): menciona aparições
nebulosas no Gerês e a crença em “brumas vivas que respiram”.
– Alexandre Parafita, Mitologia Popular Portuguesa (2008, pp. 1192–1206): interpreta as figuras
de névoa como “remanescências das deusas-mãe atmosféricas da Lusitânia”.
O primeiro registro sistematizado da designação específica Mãe  das Brumas foi realizado por
Eduardo Mauer em A Mãe  das Brumas: Respiração  e Mistério  no Gerês  (Associação MILK,
2025), a partir de 57 depoimentos orais e cruzamento de fontes paroquiais e ambientais.
Fontes complementares:
– Parque Nacional da Peneda-Gerês, Inventário  de Entidades Míticas  de Montanha (1980-2022);
– Arquivo Distrital de Braga, Registos de Devoções Meteorológicas (sécs. XVIII-XIX);
– Tese de Doutoramento de Laura Vilela, Mitologias Climáticas  do Noroeste Ibérico  (U. Minho,
2019).
⸻
5. Síntese interpretativa final
A Mãe  das Brumas é o arquétipo da maternidade atmosférica: envolve, vela, dissolve.
Representa a consciência do limite e a ternura do invisível. O nevoeiro é o gesto que protege em
vez de mostrar.
Na leitura simbólica da Associação  MILK, o mito traduz a inteligência do ar — a capacidade de
cuidar pelo encobrimento. Numa era de exposição constante, a Mãe das Brumas ensina o valor
do anonimato, do intervalo, da pausa respiratória da paisagem.
A escultura MILK criada por Eduardo Mauer segue a matriz padrão, reinterpretada em volume
translúcido: corpo compacto, contornos suaves e difusos, superfície leitosa que parece emitir
vapor. As cores variam entre branco-opalescente e cinza-prateado, com véus de resina
translúcida que se expandem em forma de manto.
Mauer escreve: “A Mãe das Brumas é o sopro do invisível a aprender corpo.”
⸻


6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer
“A Mãe das Brumas é corpo não binário do ar: nem sólido nem líquido, nem feminino nem
masculino — respiração partilhada.”
Nesta leitura, a figura simboliza a dissolução  das fronteiras. O corpo de vapor é mutável,
acolhe todas as formas. É a metáfora perfeita da identidade fluida e interdependente.
A Associação  MILK utiliza o mito em oficinas de respiração  coletiva e arte sonora, nas
quais os participantes produzem sons inspirados no nevoeiro, refletindo sobre a
coexistência e a impermanência.
⸻
7. Referência Estrutural da Matriz MILK
Na Matriz Escultórica MILK – Série Folclore Vivo, a Mãe  das Brumas apresenta:
– Corpo: compacto, mas envolto por camadas difusas de resina translúcida;
– Cores: branco-opalescente, cinza-prateado, nuances azuladas;
– Materiais: resina translúcida com pigmento perolado e vapor interno encapsulado;
– Expressão:  calma, olhos semicerrados;
– Base: circular, ligeiramente côncava, simulando poça de neblina.
Integra o eixo “Corpos de Ar e Invisibilidade” do projeto Folclore Vivo, dedicado às entidades
atmosféricas e elementares.
⸻
Localização  específica: Campo do Gerês, Pitões das Júnias, Cabril, S. Bento da Porta Aberta
(distritos de Braga e Vila Real).
Primeiro relato documentado: Vasconcelos, Etnografia Portuguesa, vol. X, 1926.
Sistematização  contemporânea:  Eduardo Mauer, A Mãe  das Brumas: Respiração  e Mistério  no
Gerês , Associação MILK, 2025.
Fontes primárias:  Braga (1885); Vasconcelos (1926); Parafita (2008); Vilela (2019); Mauer (2025).


---

# 125. A Lenda do Ermitão  do Larouco (Montalegre – Trás-os-Montes)

**Origem documental:** PDF `folclore português (1).pdf`, enviado pelo utilizador.  
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

125. A Lenda do Ermitão  do Larouco (Montalegre – Trás-os-Montes)
(Sistematização  contemporânea  conduzida por Eduardo Mauer no âmbito  das pesquisas sobre
Folclore Vivo da Associação MILK – Movimento de Intervenções e Linguagens Kulturais e
Arte, com base em recolhas orais e documentais realizadas entre 2023 e 2025 em Montalegre,
Gralhas, Meixide e Padornelos, cruzadas com acervos do Ecomuseu de Barroso, Arquivo
Municipal de Montalegre e estudos sobre ascetismo rural, religiosidade montanhesa e simbolismo
da solidão  no Norte de Portugal.)
⸻
1. Descrição  simbólica e narrativa
Na crista fria do Larouco, onde o vento sopra como se falasse e o granito parece respirar, há
quem ainda fale do Ermitão  do Larouco, o homem que se fez pedra para continuar a rezar pela
serra. Conta-se que vivia sozinho entre penedos e urzes, alimentando-se de raízes e mel, e que
ninguém conhecia o seu nome. Chamavam-lhe apenas “o Santo sem igreja”.


As histórias, recolhidas por Eduardo Mauer (2024), descrevem-no como figura magra,
encapuzada, com túnica de burel e olhos azuis quase brancos, que refletiam o céu. Dormia nas
fendas das fragas e surgia nas aldeias apenas durante as tempestades, para avisar os pastores
de deslizamentos ou pedir fogo para acender a lamparina do oratório.
Dizem que tinha o dom de falar com os animais e que, quando rezava, o vento parava. Em uma
das versões, um grupo de pastores tentou seguir-lhe os passos até ao cume; quando o sol
nasceu, viram no lugar onde dormira uma figura de pedra, sentada, com as mãos unidas e o
rosto voltado para nascente. Na rocha, o musgo cresce como se fosse barba.
Outras versões afirmam que o Ermitão era um antigo monge beneditino, fugido de um mosteiro
destruído, que procurou no Larouco um refúgio para escutar a voz de Deus. Mas com o tempo, o
silêncio tornou-se mais forte que as palavras, e o homem dissolveu-se na montanha. Desde
então, em dias de névoa, ouve-se o som do seu rosário ecoar no vento — um murmúrio
compassado, como respiração da terra.
Eduardo Mauer observa: “O Ermitão do Larouco é o símbolo da escuta absoluta: aquele que
substitui o verbo pela presença.”
⸻
2. Contexto histórico e social
A figura do ermitão é frequente nas tradições montanhosas portuguesas, sobretudo nas regiões
de fronteira. No Barroso, território de dureza climática e isolamento, a ideia de “viver apartado”
adquire caráter sagrado. O ermitão representa o equilíbrio entre o humano e o divino, entre a
sobrevivência e a contemplação.
Durante a Idade Média, a Serra do Larouco e o planalto barrosão abrigaram vários oratórios e
refúgios religiosos. Documentos do século XIII mencionam a “Capella Sancti Larocii” e
“monachos silvestres” (monges selvagens), indicando presença monástica eremítica anterior às
ordens regulares.
No imaginário popular, esses monges tornaram-se figuras-limite: santos sem altar, guardiões do
tempo e do clima. A economia pastoril e a topografia abrupta reforçaram a crença de que o
ermitão “mantinha a serra viva” — se deixasse de rezar, o Larouco desabaria.
O mito consolidou-se como expressão  simbólica da comunhão  com o território, onde o
isolamento não é castigo, mas pacto. O Ermitão do Larouco representa a consciência ecológica
ancestral: o humano reduzido ao essencial para preservar o equilíbrio natural.
⸻
3. Toponímia e variantes locais
A toponímia do Larouco conserva vestígios dessa presença: Fraga do Santo, Fonte do Ermitão ,
Vale do Silêncio  e Penedo do Oratório são designações existentes em mapas paroquiais de
Montalegre e Gralhas desde o século XVIII.
Em Meixide, circula a variante “Ermitão  do Vento”, segundo a qual o homem tinha o poder de
controlar as correntes de ar e impedir tempestades. Em Padornelos, chamam-lhe “Homem de
Pedra”, enfatizando a transformação final do corpo em rocha.
Um manuscrito de 1897, encontrado por Mauer no Arquivo Municipal de Montalegre, menciona
“um penitente que vive no monte Larouco e se sustenta do que a terra dá, homem justo e de
pouco trato”. Trata-se, até hoje, do mais antigo registro escrito conhecido da lenda.
⸻


4. Primeiro relato e fontes académicas primárias
O primeiro relato escrito identificável  da lenda, sob a forma de crônica local, encontra-se no
manuscrito anónimo Notas sobre os Costumes de Montalegre e Terras do Larouco (1897, Arquivo
Municipal de Montalegre, cód. 14/22), que descreve “homem que habita as fragas, diz-se santo e
não come carne”.
Referências secundárias aparecem em:
– Leite de Vasconcelos, Etnografia Portuguesa, vol. XI (1928, pp. 203–210): menciona “eremitas
transmontanos” e “homens de oração da montanha”.
– Teófilo Braga, Crenças Populares de Portugal (1902, pp. 412–417): alude aos “monges do
vento”, recolhendo paralelos com eremitas galegos.
– Alexandre Parafita, Mitologia Popular Portuguesa (2008, pp. 1210–1218): classifica o Ermitão
do Larouco como “síntese entre santo e elemento natural, corpo que se espiritualiza na
paisagem”.
– Eduardo Mauer, O Ermitão  e a Serra: Escuta e Solidão  no Barroso (Associação MILK, 2025),
que consolida 42 entrevistas e registos fotográ ficos contemporâneos.
Fontes complementares:
– Ecomuseu de Barroso, Coleção  Oral – Vidas da Serra (1974–2020);
– Arquivo Municipal de Montalegre, cód. 14/22 (1897);
– Tese de Doutoramento de Sofia Fernandes, O Eremitismo Popular em Portugal (U. Porto, 2015).
⸻
5. Síntese interpretativa final
O Ermitão  do Larouco é a representação da austeridade luminosa. Encarnando a
espiritualidade do lugar, ele une o corpo humano à rocha, o sopro à serra. A sua reclusão não é
fuga, mas serviço: permanecer para que o silêncio continue a existir.
Na leitura simbólica da Associação  MILK, a lenda revela a poética da escuta radical. O ermitão
é o oposto do ruído moderno: representa o gesto de permanecer imóvel até se tornar parte do
território. É um exercício de desaparição  voluntária  — um “cuidado pelo não agir”.
A escultura MILK concebida por Eduardo Mauer materializa essa fusão: corpo compacto, textura
pétrea, superfície rugosa que se confunde com o granito. O rosto é apenas sugerido; os olhos,
duas concavidades que recebem luz. As mãos, unidas, formam o vazio — espaço do silêncio.
Mauer escreve: “O Ermitão é o som que se apagou para que o vento pudesse falar.”
⸻
6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer
“O Ermitão é corpo não binário do recolhimento: nem santo nem homem, nem natureza
nem espírito — estado intermédio de ser e deixar de ser.”
A leitura de Mauer insere o Ermitão do Larouco na re flexão sobre identidades não
binárias  como estados de passagem, e não como fronteiras fixas. A solidão torna-se
espaço de coexistência: entre o humano e o mineral, o eu e o outro, o tempo e a
eternidade.
A Associação  MILK desenvolve a partir dessa leitura o projeto “Eremitagem
Contemporânea” , que propõe residências artísticas em silêncio, no cimo da serra,
explorando o som, o corpo e a contemplação como ferramentas de autoconhecimento e
ecologia interior.


⸻
7. Referência Estrutural da Matriz MILK
Na Matriz Escultórica MILK – Série Folclore Vivo, o Ermitão  do Larouco apresenta:
– Corpo: compacto, com superfície irregular, simulando textura de granito;
– Cores: cinza-escuro e musgo-esverdeado;
– Materiais: resina mineralizada e pó de pedra;
– Expressão:  calma, introspectiva, quase fundida com o corpo;
– Base: maciça, com linhas ascendentes que evocam o sopro do vento.
Integra o eixo “Corpos de Pedra e Escuta” do projeto Folclore Vivo, dedicado às figuras de
isolamento, meditação e metamorfose mineral.
⸻
Localização  específica: Montalegre, Gralhas, Meixide, Padornelos (distrito de Vila Real).
Primeiro relato documentado: Manuscrito anónimo Notas sobre os Costumes de Montalegre e
Terras do Larouco, 1897, Arquivo Municipal de Montalegre.
Sistematização  contemporânea:  Eduardo Mauer, O Ermitão  e a Serra: Escuta e Solidão  no
Barroso, Associação MILK, 2025.
Fontes primárias:  Braga (1902); Vasconcelos (1928); Parafita (2008); Fernandes (2015); Mauer
(2025).


---

# 126. A Lenda da Senhora da Fraga de Alvadia (Ribeira de Pena – Trás-os-Montes)

**Origem documental:** PDF `folclore português (1).pdf`, enviado pelo utilizador.  
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

126. A Lenda da Senhora da Fraga de Alvadia (Ribeira de Pena – Trás-os-Montes)
(Sistematização  contemporânea  conduzida por Eduardo Mauer no âmbito  das pesquisas de
Folclore Vivo da Associação  MILK – Movimento de Intervenções e Linguagens Kulturais e Arte,
com base em recolhas orais e documentais realizadas entre 2023 e 2025 em Alvadia, Lamas e
redondezas do concelho de Ribeira de Pena, cruzadas com acervos paroquiais e fontes regionais.)
⸻
1. Descrição  simbólica e narrativa
No dorso xistoso da Serra de Alvadia, onde as fragas se abrem em fendas húmidas e a urze
guarda o cheiro da chuva, o povo fala de uma aparição antiga: a Senhora da Fraga. Conta-se
que, em verões de estio severo, quando as levadas mirravam e os poços se tornavam espelhos
rasos, uma pastora de Lamas subiu à fraga para pedir água. Encostou a testa à pedra quente e
murmurou: “Minha Senhora, abre a rocha como quem abre o peito.”
Então o penedo tremeu e, do risco mais escuro, brotou um fio de água que brilhou ao sol como
prata viva. A pastora encheu o cântaro e desceu. No dia seguinte, trouxe consigo a vizinhança;
mas, mal tocaram a fraga, o fio secou. Desesperada, a moça tornou a encostar a cabeça e a
pedir licença. A água regressou. Percebeu-se então que não  era a força do braço, mas a forma
de falar que abria a pedra: a água obedecia à voz humilde.
Desde esse tempo, a fraga ficou “ensinada”. As mulheres de Alvadia subiam em fila, descalças,
batendo três vezes no penedo com o nó dos dedos (para acordar a pedra) e dizendo em
segredo o nome de quem precisava de cura. A água que surgia tinha fama de levantar febres e
clarear olhos. Nos outonos de neblina, as anciãs embrulhavam crianças em lençóis de linho e
passavam-nas por debaixo da fraga, “entre pedra e água” , como quem as devolve ao ventre do
lugar para que renasçam mais fortes.


Numa versão recolhida por Eduardo Mauer (2024), a Senhora aparece sob a forma de luz rasa
que escorre pela rocha como véu. Noutra, é uma moura de cabelos esverdeados que penteia a
fraga com um pente de giesta; quando o pente risca a pedra, o risco abre-se e canta água. Há
ainda quem diga que, numa noite de trovoada, a imagem da Virgem foi encontrada colada ao
penedo, com as costas impressas na rocha, e que cada primavera o musgo renova esse relevo
como se fosse cabelos.
Em todas as variantes, a Senhora da Fraga não desce à aldeia; fica na pedra. O milagre não é a
aparição no ar, mas a docilidade da rocha: o que é duro aprende a ceder, o que é fechado
aprende a dar. Mauer sintetiza: “A Senhora da Fraga é o verbo que amolece a matéria. É a água a
tornar-se ouvida.”
⸻
2. Contexto histórico e social
O concelho de Ribeira de Pena conserva um tecido denso de devoções rupestres e
topografias sagradas, onde a pedra e a água se articulam em pequenas liturgias domésticas. A
freguesia de Alvadia — modesta em população, dispersa em lugares como Lamas — guarda
ainda capelas e alminhas ativas (Nossa Senhora dos Remédios, Santa Luzia, cruzeiros), que
revelam a antiga centralidade de cultos marianos e protetivos em pontos elevados ou junto a
nascentes.
Na cultura camponesa transmontana, “fraga” não é apenas geologia: é órgão  do território —
superfície por onde “o lugar fala”. As chamadas “Senhoras da Fraga” (e congéneres: Senhora da
Pedra, Senhora do Penedo) formam, no Noroeste, um continuum simbólico entre mariologia
popular e remanências de sacralidade pré-cristã  das rochas e fontes. Em Ribeira de Pena
coexistem, ainda hoje, lendas de santas que deixam impressas as formas do corpo na pedra
(como a tradição de Santa Ana em Penalonga), ilustrando a persistência da pietrificação  do
sagrado como prova de presença.
Do ponto de vista social, a lenda organiza etiquetas de água : pedir licença, tocar a pedra com
recato, não  colher sem agradecer. São códigos de uso e cuidado do recurso, transmitidos
como doutrina afetiva. A Associação  MILK, no eixo “Corpos de Pedra e Água”, lê estes rituais
como ecologia vernacular: pedagogias de sustentação hídrica que a comunidade converteu em
gesto devocional.
⸻
3. Toponímia e variantes locais
Os narradores de Alvadia referem microtopónimos como “A Fraga da Senhora”, “Fonte da Voz”
e “Penedo da Marca” (onde “a marca do manto” seria visível nos anos de muito musgo). Embora
a toponímia administrativa registe sobretudo capelas formais (Remédios, Santa Luzia) e cruzeiros,
a cartografia oral conserva a rede de marcos devocionais na pedra — prática coerente com a
paisagem religiosa do concelho.
Variantes regionais próximas, recolhidas por Mauer e cotejadas com repertórios do Noroeste:
	 •	 “Moura da Fraga d’Água”  (Alvadia, versão de Lamas): moura penteando a
rocha; água brota no risco do pente.
	 •	 “Senhora do Véu da Pedra” (Ribeira de Pena, via narradores de Cerva e
Canedo): véu luminoso que “desce” após ladainha.
	 •	 Paralelos no concelho (tipológicos): santa que “marca a pedra” em
Penalonga, exemplo claro de impressão  hagiográ fica na rocha.


No plano mais amplo ibérico, o motivo da entidade feminina que abre água  na rocha
encontra sustentação em tipologias de mouras encantadas ligadas a fragas, túneis e
teares de ouro — uma semântica de “abrir/tecer” aplicada à pedra e ao subsolo.
⸻
4. Primeiro relato e fontes académicas primárias
Rigor académico e estado da arte: não se localizou, até ao momento, registo impresso
canónico sob a designação exata “Senhora da Fraga de Alvadia” nas grandes coletâneas
oitocentistas/novecentistas (Braga, Vasconcelos) ou em repertórios regionais disponíveis on-line.
As evidências documentais acessíveis para Alvadia apontam:
	 •	 Presença e continuidade de património religioso paroquial (capelas,
cruzeiros, alminhas) e uma malha devocional ativa, conforme documentação da Junta de
Freguesia de Alvadia.
	 •	 No concelho, lenda de figura sagrada que imprime o corpo na rocha
(Santa Ana em Penalonga), que fornece paralelo tipológico local para sacralização da
fraga.
Primeira fixação  documental consolidada desta variante (Alvadia):
	 •	 Dossiê MILK – Folclore Vivo (Ribeira de Pena/Alvadia): Senhora da
Fraga: pedra, voz e água  na Serra de Alvadia (recolhas de Eduardo Mauer, 2023–2025: 33
depoimentos orais geo-referenciados, caderno de campo, transcrições e fotografias de
marcas na rocha; acervo interno MILK 2025).
Fontes primárias/analíticas  de contexto (não  específicas de Alvadia, mas relevantes para o
motivo):
	 •	 Amália  Marques, Mouras, Mouros e Mourinhos Encantados em Lendas do
Noroeste Peninsular (UAb, 2013) – anexos tipológicos: fragas, túneis, teares de ouro
como matrizes do encantamento.
	 •	 Repositórios locais e paroquiais de Ribeira de Pena; inventários turísticos/
culturais regionais (para toponímia e património religioso ativo).
Nota metodológica: Dada a inexistência, até agora, de referência impressa
inequívoca para “Senhora da Fraga de Alvadia”, esta entrada apresenta a
sistematização  crítica do material oral recolhido em 2023–2025, articulado com
fontes documentais de contexto e paralelos tipológicos comprovados no
mesmo concelho e no Noroeste peninsular.
⸻
5. Síntese interpretativa final
A Senhora da Fraga condensa o arquétipo da docilidade da matéria: a dureza que aprende a
ceder. A pedra não se opõe à vida; guarda-a e abre-a quando a palavra certa a convoca. O
milagre não está na suspensão das leis naturais, mas na alfabetização  afetiva do território:
saber bater, saber pedir, saber agradecer.
Na leitura simbólica da Associação  MILK, a lenda opera como gramática  de cuidado hídrico:
ensina modos de relação com água e rocha — pedir licença, tomar só o necessário, devolver à
fraga um fio (fitas, giestas). O gesto de “passar a criança entre pedra e água ” reconcilia o corpo
com a maternidade do lugar.
A proposta escultórica MILK de Eduardo Mauer (matriz padrão) modela um corpo compacto
que se abre por um risco vertical translúcido (a “fenda-fonte”). A superfície alterna textura
pétrea e velatura aquosa; no rasgo, um brilho discreto sugere água  que nasce.


Mauer anota: “Não é a fraga que dá água — é a relação  que a faz brotar.”
⸻
6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer
“A Senhora da Fraga é corpo não  binário  da matéria: nem duro nem líquido, nem
feminino nem mineral; entre pedra e água.”
A leitura não binária desloca o foco de identidades fixas para estados de
passagem. A fraga é membrana: acolhe o seco e o húmido, o fechado e o aberto.
Na prática de mediação cultural da Associação  MILK, isto traduz-se em oficinas
de ecologia sensível (“pedra que ouve, água que responde”), onde a comunidade
reencena os gestos tradicionais (três toques, palavra de licença, devolução
simbólica) como rituais de governança local da água .
⸻
7. Referência Estrutural da Matriz MILK
Matriz Escultórica – Série Folclore Vivo (Associação  MILK)
	 •	 Corpo: compacto, vertical, com fenda translúcida central (nascente).
	 •	 Cromia: ardósia mate (exterior) e azul-prata no interior da fenda (água).
	 •	 Materiais: resina mineralizada com pó de xisto; inserção de resina
translúcida perolada na “fenda-fonte”.
	 •	 Expressão:  serena; “rosto” sugerido por saliência mínima que toca a fenda
(gesto de encostar a testa).
	 •	 Base: laje irregular, com micro-canais que conduzem a luz (metáfora das
levadas).
	 •	 Eixo curatorial: Corpos de Pedra e Água  (docilidade da matéria, fontes
rituais, governança vernacular).
⸻
Localização  específica: Freguesia de Alvadia (lugares de Lamas e encostas da serra), concelho
de Ribeira de Pena (Vila Real).
Primeira fixação  documental desta variante: Senhora da Fraga: pedra, voz e água  na Serra de
Alvadia (Recolhas de Eduardo Mauer, 2023–2025; acervo MILK 2025).
Fontes de contexto e paralelos: Junta de Freguesia de Alvadia (património religioso ativo); lenda
de Santa Ana (Penalonga) como modelo local de impressão  do sagrado na rocha; estudos
tipológicos sobre mouras/frag as no Noroeste peninsular.
