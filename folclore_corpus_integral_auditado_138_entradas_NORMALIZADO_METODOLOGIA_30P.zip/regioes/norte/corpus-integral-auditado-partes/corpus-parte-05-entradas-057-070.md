# Corpus integral auditado — parte 05

Entradas 057 a 070.



---

# 057. A Lenda da Senhora da Peneda (Arcos de Valdevez e Castro Laboreiro)

**Origem documental:** PDF `folclore português (1).pdf`, enviado pelo utilizador.  
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

57. A Lenda da Senhora da Peneda (Arcos de Valdevez e Castro Laboreiro)
(Sistematização  contemporânea  conduzida por Eduardo Mauer no âmbito  das pesquisas sobre
Folclore Vivo da Associação  MILK – Movimento de Intervenções e Linguagens Kulturais e Arte,
desenvolvida entre 2022 e 2024 nas freguesias de Gavieira, Castro Laboreiro e Soajo, com base
em arquivos históricos, recolhas orais e documentação  etnográ fica da Universidade do Minho e
do Museu Nacional de Etnologia.)
⸻
1. Descrição  simbólica e narrativa
A Lenda da Senhora da Peneda, uma das mais veneradas do Alto Minho, encontra-se
profundamente ligada à montanha e à fé popular do Parque Nacional da Peneda-Gerês. O
santuário homónimo, encravado na Serra da Peneda, ergue-se como monumento natural e
espiritual, e a sua origem está associada a uma aparição mariana ocorrida, segundo a tradição,
no final do século XVIII.
De acordo com os relatos populares recolhidos por Eduardo Mauer (2023) em Gavieira e Castro
Laboreiro, uma pastora surda-muda encontrou-se com uma mulher luminosa sobre o penedo
que domina o vale. A aparição tocou-lhe os ouvidos e a boca, devolvendo-lhe a audição e a fala,
e ordenou-lhe que o povo construísse uma capela naquele local.
A jovem desceu à aldeia e, para espanto de todos, falou pela primeira vez: “Vi a Senhora sobre a
pedra.” O povo acompanhou-a de volta à montanha e, no mesmo lugar, ergueram uma pequena
ermida, que deu origem ao atual Santuário  de Nossa Senhora da Peneda, um dos maiores
complexos devocionais de Portugal.
No entanto, a lenda vai muito além da aparição cristã. Em versões anteriores recolhidas em
Castro Laboreiro, a montanha era habitada por uma “Senhora das Águas Altas”, divindade que
protegia as chuvas e os rebanhos, e que se manifestava como luz sobre os penedos. A
substituição simbólica dessa deusa ancestral pela figura da Virgem reflete o processo de
cristianização de antigos cultos de altitude e de fertilidade.
Em noites de lua cheia, ainda se diz que a Senhora aparece na encosta, envolta em neblina
azulada, e que o som do vento entre os penedos é o eco de seu cântico. Os pastores chamam-

lhe “a voz do monte”, e as mulheres que desejam filhos sobem descalças as escadarias do
santuário, levando flores brancas e pequenas pedras recolhidas no caminho.
Na leitura poética de Eduardo Mauer, “a Senhora da Peneda é a consciência mineral do sagrado
— o corpo feminino da montanha que aprende a falar através do vento.”
⸻
2. Contexto histórico e social
O culto à Senhora da Peneda foi o ficialmente reconhecido em 1798, quando as autoridades
eclesiásticas autorizaram a construção da primeira capela. Contudo, a sacralidade do local
remonta a tempos muito mais antigos. As encostas da Peneda abrigam gravuras rupestres,
altares rupinos e restos de vias romanas que atestam a sua importância espiritual desde a proto-
história.
Durante séculos, as populações locais subiam à Peneda em procissão, transportando oferendas
de leite, pão e mel. O lugar era visto como “santuário  do alto”, onde a terra se encontra com o
céu. As festas anuais, celebradas em setembro, combinam devoção e espetáculo: danças,
romarias e representações dramáticas conhecidas como “auto da Senhora”, nas quais se
reencena o milagre da pastora.
A Peneda tornou-se também ponto de encontro de comunidades fronteiriças portuguesas e
galegas. Ainda hoje, romeiros da Galiza atravessam as montanhas a pé para participar na festa,
perpetuando o caráter transfronteiriço e comunitário do culto.
Na leitura de Eduardo Mauer, “a Peneda é a catedral do ar — um templo sem teto, onde o
humano se curva diante da verticalidade do mundo.”
⸻
3. Toponímia e variantes locais
O topónimo “Peneda” deriva de penna (pedra, penhasco), referência direta à montanha sagrada.
Na tradição local, o termo designa tanto o penedo físico quanto a divindade espiritual que nele
habita.
As variantes orais recolhidas entre Soajo, Gavieira e Castro Laboreiro revelam diferentes
camadas do mito:
– Em Gavieira, fala-se da “Senhora da Luz do Penedo”, que aparece sobre uma rocha
incandescente;
– Em Soajo, a figura é chamada “Senhora das Alturas”, e é acompanhada por pombas brancas;
– Em Castro Laboreiro, a aparição é substituída por uma “Moura de Prata”, que protege as
águas das chuvas;
– Em aldeias fronteiriças galegas, a mesma figura é conhecida como “Virxe da Pena”,
perpetuando o mesmo arquétipo telúrico.
Todas as versões convergem na relação entre altura, luz e pedra, confirmando a persistência de
um culto montanhoso pré-cristão, adaptado à linguagem mariana.
⸻
4. Primeiro relato e fontes académicas primárias
O primeiro relato escrito da Lenda da Senhora da Peneda encontra-se em Leite de
Vasconcelos, Etnografia Portuguesa, vol. II (1913, pp. 320–329)*, que descreve o milagre da
pastora e a fundação da capela.


Teófilo Braga, O Povo Português  nos seus Costumes, Crenças e Tradições (1885, pp. 431–438)*,
já fazia referência às “Senhoras das Alturas” como herdeiras de antigas divindades montanhosas.
Alexandre Parafita, Mitologia Popular Portuguesa (2008, pp. 529–536)*, identifica a Peneda
como “santuário liminar”, onde se dá a passagem entre o humano e o divino, e a Senhora como
“reencarnação do sagrado feminino da montanha”.
A sistematização contemporânea de Eduardo Mauer, A Senhora da Peneda: Montanha, Voz e
Verticalidade no Imaginário  Minhoto (Lisboa, Associação MILK, 2024), propõe leitura ecológica e
não binária do mito, analisando a aparição como metáfora da ascensão espiritual e da
reconciliação entre matéria e espírito.
Fontes complementares:
– Arquivo Distrital de Braga, Documentos da Fundação  do Santuário  da Peneda (séculos XVIII–
XIX);
– Museu Nacional de Etnologia, Coleção  de Romarias de Altitude (1950–1980);
– Tese de Doutoramento de Inês Mota, Pedras Vivas: Mitologias da Altura e Cultos de Montanha
em Portugal e na Galiza (U. Santiago, 2021).
⸻
5. Síntese interpretativa final
A Senhora da Peneda sintetiza a união entre natureza, espiritualidade e arte popular. O mito da
pastora muda transformada pela luz traduz o arquétipo da revelação  interior — o momento em
que o humano reencontra a voz perdida do mundo.
Na leitura simbólica da Associação  MILK, a Peneda é o templo da escuta, o lugar onde o
sagrado não se impõe, mas sussurra. A montanha é o corpo e a voz da Senhora, e o vento é a
sua respiração.
A escultura MILK concebida por Eduardo Mauer representa corpo compacto branco com
cabeça grande inclinada para o alto, véu translúcido azul e base cinza rugosa, simulando penedo.
O interior brilha com luz branca pulsante, evocando o instante da revelação.
⸻
6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer
Na leitura não binária de Eduardo Mauer, a Senhora da Peneda é o corpo andrógino da
montanha, simultaneamente mãe e penedo, fala e silêncio.
Mauer escreve: “A Peneda é a elevação do corpo à sua própria escuta. O sagrado não é um
gênero, é uma vibração que sobe.”
A Associação  MILK interpreta o mito como alegoria da transcendência não  binária , em que a
ascensão não é fuga, mas reconciliação. O ser que sobe é também o que escuta; o corpo e o
espírito tornam-se a mesma rocha.
⸻
7. Referência Estrutural da Matriz MILK
Na Matriz Escultórica MILK, a Senhora da Peneda é representada com cabeça grande voltada
para o alto, corpo compacto branco e véu azul translúcido. A base irregular simula pedra
granítica e a luz interna branca simboliza o renascimento da voz e da consciência.


⸻
Localização  específica: Santuário da Peneda, freguesia de Gavieira, concelho de Arcos de
Valdevez (distrito de Viana do Castelo).
Primeiro relato documentado: Leite de Vasconcelos, Etnografia Portuguesa, vol. II, 1913.
Sistematização  contemporânea:  Eduardo Mauer, A Senhora da Peneda: Montanha, Voz e
Verticalidade no Imaginário  Minhoto, Associação MILK, 2024.
Fontes primárias:  Braga (1885); Vasconcelos (1913); Parafita (2008); Mota (2021); Mauer (2024).


---

# 058. A Lenda do Homem da Cabana de Vilarinho da Furna (Gerês, Terras de Bouro)

**Origem documental:** PDF `folclore português (1).pdf`, enviado pelo utilizador.  
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

58. A Lenda do Homem da Cabana de Vilarinho da Furna (Gerês, Terras de Bouro)
(Sistematização  contemporânea  conduzida por Eduardo Mauer no âmbito  das pesquisas sobre
Folclore Vivo da Associação  MILK – Movimento de Intervenções e Linguagens Kulturais e Arte,
com base em recolhas realizadas entre 2022 e 2024 no território submerso de Vilarinho da Furna e
nas freguesias de Campo do Gerês  e Covide, em articulação  com o Museu da Geira, o Museu
Nacional de Etnologia e a Universidade do Minho.)
⸻
1. Descrição  simbólica e narrativa
A Lenda do Homem da Cabana de Vilarinho da Furna é uma das mais singulares narrativas do
Gerês, guardando um sentido profundo de memória, isolamento e resistência. Vilarinho da Furna,
aldeia outrora situada nas margens do rio Homem, foi submersa em 1972 pela barragem
construída pela Hidroeléctrica do Cávado. Contudo, muito antes de desaparecer sob as águas, o
lugar já era palco de uma das lendas mais antigas do norte português: a do Homem da Cabana,
guardião das montanhas e espírito solitário que protegia a aldeia do esquecimento.
Segundo a tradição oral recolhida por Eduardo Mauer (2023) junto de antigos habitantes
deslocados da Furna, o Homem da Cabana era um eremita de idade incerta, de cabelos longos e
olhar distante, que vivia isolado numa cabana de pedra nas encostas do monte Amarela. Dizia-se
que ele falava com os lobos e com o vento, e que conhecia o nome de cada fonte e cada árvore
da serra.
As pessoas acreditavam que o Homem da Cabana não envelhecia e que aparecia apenas quando
alguém estava prestes a morrer. Sentava-se junto à porta e acendia o seu pequeno lume, gesto
que significava “a alma será  guiada para o outro lado”.
Após a submersão da aldeia, os pescadores e guardas do parque relataram ver uma luz
tremeluzente sobre as águas da barragem, precisamente onde outrora ficava a cabana. O povo
passou a dizer que o Homem não se afogara, mas transformara-se em espírito do lago,
guardando a memória de Vilarinho para sempre.
Na leitura poética de Eduardo Mauer, “o Homem da Cabana é o arquiteto do silêncio — o ser
que permanece quando tudo se apaga. Ele é a voz mineral da perda e o guardião da ausência.”
⸻
2. Contexto histórico e social
A lenda do Homem da Cabana reflete a estrutura social peculiar de Vilarinho da Furna,
conhecida pelo seu regime comunitário exemplar, estudado por etnógrafos como Jorge Dias e
Benjamim Pereira. O sistema de vezeira, de partilha dos recursos e das pastagens,
fundamentava uma organização coletiva rara em Portugal.


O eremita lendário representa o símbolo moral e espiritual dessa comunidade — a figura que
vive fora da aldeia, mas que a protege. No contexto das aldeias de montanha, o eremita é
mediador entre o mundo natural e o humano, entre a ordem social e o mistério.
Com a destruição da aldeia em 1972, a lenda adquiriu novo signi ficado: passou a encarnar a
memória viva da perda. O Homem da Cabana tornou-se o emblema do que resiste ao
apagamento, e a sua cabana submersa simboliza o inconsciente coletivo da região.
Nas palavras de Eduardo Mauer, “a lenda sobreviveu à aldeia. O corpo morreu, mas a alma ficou
a flutuar sobre a água — e isso é folclore em estado puro.”
Hoje, os antigos habitantes da Furna realizam romarias simbólicas às margens da barragem,
acendendo velas em pequenas pedras dispostas em forma de cabana. O ato repete o gesto
ancestral do guardião e mantém viva a espiritualidade do lugar perdido.
⸻
3. Toponímia e variantes locais
O topónimo Vilarinho da Furna deriva de villar (pequena povoação) e furna (gruta ou caverna),
remetendo à geogra fia abrigada entre os vales da Serra Amarela. O nome Homem da Cabana
surge em versões orais desde o século XIX, sendo descrito ora como espírito da montanha, ora
como último morador da aldeia.
As variantes locais, recolhidas entre Campo do Gerês, Covide e Bouro Santa Marta, incluem:
– “O Velho do Monte”: aparece nas neblinas da manhã e guia viajantes perdidos;
– “O Pastor da Luz”: acende uma lanterna invisível para proteger os rebanhos;
– “O Homem do Lago”: habita sob as águas, e quem o vê em sonho, reencontra a aldeia
submersa;
– “O Guardião das Furnas”: ser que fala através do som das águas a cair sobre as rochas.
Em todas as versões, a figura é solitária, silenciosa e ligada à continuidade da memória.
⸻
4. Primeiro relato e fontes académicas primárias
O primeiro registro escrito da Lenda do Homem da Cabana remonta a Leite de Vasconcelos,
Etnografia Portuguesa, vol. III (1914, pp. 12–18)*, que recolheu o testemunho de camponeses do
Gerês sobre “um eremita nas furnas do Homem, senhor dos lobos e das neblinas”.
Jorge Dias, em Vilarinho da Furna: Uma Aldeia Comunitária  (Lisboa, 1948), menciona o mito
como exemplo da “consciência espiritual da montanha” e como “figura arquetípica do isolamento
criador”.
Alexandre Parafita, Mitologia Popular Portuguesa (2008, pp. 537–544)*, identifica o Homem da
Cabana como “herdeiro simbólico dos deuses pastores celtas, ligados à proteção dos lugares
altos e ao ciclo da morte e renascimento”.
A sistematização contemporânea de Eduardo Mauer, O Homem da Cabana: Memória,
Isolamento e Ressurreição  no Imaginário  de Vilarinho da Furna (Lisboa, Associação MILK, 2024),
inclui recolha oral com descendentes dos antigos moradores e propõe leitura do mito como
metáfora  não  binária  da permanência através da perda.
Fontes complementares:
– Museu da Geira, Arquivo Etnográ fico do Gerês:  Crenças e Narrativas de Montanha (1955–1990);
– Tese de Doutoramento de Rita Azevedo, Aldeias Submersas e Memória Cultural no Noroeste
Ibérico  (U. Minho, 2021).


⸻
5. Síntese interpretativa final
O Homem da Cabana é, simultaneamente, personagem e metáfora. Ele encarna a resistência
da memória, o gesto de continuar presente mesmo quando o mundo desaparece. A sua figura
devolve à montanha a função sagrada do guardião — aquele que não impede o fim, mas o
acompanha.
Na leitura simbólica da Associação  MILK, o Homem da Cabana é o espírito ecológico da
memória, a alma das coisas que recusam ser esquecidas. Ele representa o folclore como
processo de cura coletiva — o rito de lembrar em forma de lenda.
A escultura MILK concebida por Eduardo Mauer apresenta corpo compacto de cor cinza-escura,
cabeça grande inclinada, olhos cerrados e base azul-translúcida que remete à água da barragem.
No peito, uma cavidade iluminada representa a cabana interna: a morada da lembrança.
⸻
6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer
Na leitura não binária de Eduardo Mauer, o Homem da Cabana é o corpo do silêncio entre
mundos — nem vivo nem morto, nem humano nem espírito, mas a fronteira em que ambos se
tocam.
Mauer escreve: “O Homem da Cabana não é ele, nem ela. É o eco do lugar. A sua forma dissolve-
se na água, e o que resta é pura persistência.”
A Associação  MILK lê o mito como paradigma da identidade líquida e pós-humana, onde o
ser é também território, e o corpo é simultaneamente abrigo e ausência.
⸻
7. Referência Estrutural da Matriz MILK
Na Matriz Escultórica MILK, o Homem da Cabana é representado com corpo compacto cinza,
cabeça grande inclinada e cavidade central luminosa. A base azul simula o reflexo da água e o
silêncio da memória.
⸻
Localização  específica: Antiga aldeia de Vilarinho da Furna, submersa pela barragem do rio
Homem (Terras de Bouro, distrito de Braga).
Primeiro relato documentado: Leite de Vasconcelos, Etnografia Portuguesa, vol. III, 1914.
Sistematização  contemporânea:  Eduardo Mauer, O Homem da Cabana: Memória, Isolamento e
Ressurreição  no Imaginário  de Vilarinho da Furna, Associação MILK, 2024.
Fontes primárias:  Vasconcelos (1914); Dias (1948); Parafita (2008); Azevedo (2021); Mauer
(2024).


---

# 059. A Lenda da Ponte de Paradela e o Espírito do Rio Cávado  (Montalegre e Gerês)

**Origem documental:** PDF `folclore português (1).pdf`, enviado pelo utilizador.  
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

59. A Lenda da Ponte de Paradela e o Espírito do Rio Cávado  (Montalegre e Gerês)
(Sistematização  contemporânea  conduzida por Eduardo Mauer no âmbito  das pesquisas sobre
Folclore Vivo da Associação  MILK – Movimento de Intervenções e Linguagens Kulturais e Arte, a
partir de recolhas de campo realizadas entre 2022 e 2024 nas freguesias de Paradela, Pitões das

Júnias e Tourém,  com apoio do Museu de Etnologia do Porto, do Arquivo Distrital de Vila Real e
do Centro de Investigação  Transmontano de Estudos do Imaginário  da Universidade de Trás-os-
Montes e Alto Douro.)
⸻
1. Descrição  simbólica e narrativa
A Lenda da Ponte de Paradela — também conhecida como “a ponte das vozes” — é uma das
narrativas mais densas do imaginário fluvial do Barroso. Situada sobre o rio Cávado , na fronteira
entre Montalegre e o Gerês, a ponte atual, de origem medieval, substituiu uma travessia mais
antiga de madeira e pedra, construída, segundo o povo, pelo próprio Espírito do Rio, uma
entidade aquática personi ficada que habitava as águas profundas.
Segundo as versões orais recolhidas por Eduardo Mauer (2023), o Espírito do Rio Cávado era
um ser de corpo líquido e rosto de neblina, capaz de mudar de forma conforme o humor das
águas. Chamavam-lhe “o Senhor das Correntes” e diziam que podia ser ao mesmo tempo
homem e mulher, velho e criança, luz e sombra.
Certa vez, o Espírito apaixonou-se por uma rapariga de Paradela chamada Alcina, que todos os
dias ia lavar roupa junto à margem. O rio levantava brumas em torno dela, e a água cantava
melodias suaves enquanto ela esfregava o linho. O povo, intrigado, dizia que o rio “tinha ganho
voz de amante”.
Quando Alcina desapareceu misteriosamente numa cheia, os aldeões ouviram, na madrugada
seguinte, uma voz que vinha das águas: “Ela vive em mim.” Desde então, acreditava-se que o
Espírito do Cávado a transformara em corrente, e que nas noites de lua cheia o re flexo da água
mostrava o rosto de uma mulher sorrindo.
A ponte foi então erguida como gesto de reconciliação — símbolo da união entre o humano e o
natural, o terrestre e o aquático. Diz-se que quem atravessa a ponte ao entardecer e ouve o
murmúrio do rio percebe sussurros, vozes antigas que dizem: “Nada se perde no Cávado, tudo
flui e se transforma.”
Na leitura poética de Eduardo Mauer, “o Espírito do Rio é a consciência líquida do amor —
aquele que não possui, apenas envolve.”
⸻
2. Contexto histórico e social
O rio Cávado  sempre desempenhou papel vital no ordenamento económico e simbólico do norte
de Portugal. Desde o período castrejo, as margens eram habitadas por comunidades agrícolas e
pastoris que veneravam divindades fluviais. As aras dedicadas à  deusa Nabia encontradas em
Braga, Barcelos e Montalegre confirmam a sacralidade ancestral dessas águas.
Durante a Idade Média, as pontes tornaram-se locais de culto e rituais de passagem. A de
Paradela ligava duas freguesias isoladas e era também ponto de troca de produtos e histórias. O
mito do Espírito do Rio cristalizou o medo e a fascinação  pelo poder natural do Cávado — rio
calmo nas manhãs e devastador em tempo de tempestade.
Com a construção da barragem de Paradela em meados do século XX, o leito antigo foi
parcialmente submerso, mas os habitantes continuaram a depositar flores e fitas coloridas sobre
as águas em memória de Alcina e do Espírito. O gesto, segundo os estudiosos, é herança direta
das antigas oferendas pagãs às divindades da água.
Na leitura de Eduardo Mauer, “a ponte é o coração civilizatório do rio: a tentativa humana de
dialogar com o fluxo, sem o dominar.”


⸻
3. Toponímia e variantes locais
O nome Paradela deriva de parada (lugar de descanso) e diminutivo -ela, possivelmente
significando “pequeno abrigo à beira do rio”.
As variantes da lenda recolhidas entre Tourém, Pitões das Júnias e Montalegre revelam
múltiplas interpretações do Espírito do Cávado:
– Em Tourém, é descrito como um mouro-d’água , ser andrógino que protege os peixes e
castiga os que poluem o rio;
– Em Pitões, é visto como padroeiro invisível dos moinhos, ajudando as mulheres a moer o grão
quando as pedras se recusam a girar;
– Em Montalegre, o Espírito é “Senhor das Vozes”, presença que murmura nomes dos mortos
nas cheias de inverno;
– Em certas aldeias galegas fronteiriças, o mesmo ser é chamado “Espírito de Nabia”,
relembrando as raízes pré-cristãs da figura.
⸻
4. Primeiro relato e fontes académicas primárias
O primeiro registro escrito da Lenda da Ponte de Paradela encontra-se em Leite de
Vasconcelos, Etnografia Portuguesa, vol. III (1914, pp. 35–43)*, que recolhe o testemunho de
camponeses do Gerês sobre “um rio que fala e uma ponte que escuta”.
Teófilo Braga, O Povo Português  nos seus Costumes, Crenças e Tradições (1885, pp. 439–446)*,
menciona a crença no “Espírito das Águas do Cávado”, associado a antigos ritos de fertilidade.
Alexandre Parafita, Mitologia Popular Portuguesa (2008, pp. 545–552)*, identifica o Espírito do
Cávado como manifestação de “anima fluvial”, divindade animista sobrevivente nos relatos do
Barroso.
A sistematização contemporânea de Eduardo Mauer, O Espírito  do Cávado:  Voz, Ponte e
Metamorfose no Imaginário  do Barroso (Lisboa, Associação MILK, 2024), amplia as
interpretações simbólicas, articulando memória ecológica, espiritualidade não binária e
reconfiguração estética do mito na contemporaneidade.
Fontes complementares:
– Arquivo Distrital de Vila Real, Registos Orais do Barroso e do Cávado  (séculos XIX–XX);
– Museu de Etnologia do Porto, Coleção  de Narrativas Fluviais e Pontes do Diabo (1950–1990);
– Tese de Doutoramento de Ângela Ribeiro, A Voz das Águas:  Arquétipos  Fluviais no Noroeste
Ibérico  (U. Porto, 2020).
⸻
5. Síntese interpretativa final
A Lenda da Ponte de Paradela expressa o vínculo espiritual entre o ser humano e o rio, entre o
construído e o fluido. O Espírito do Cávado é metáfora da vida que atravessa o tempo sem se
fixar.
Na leitura simbólica da Associação  MILK, o mito revela a urgência contemporânea de repensar a
relação com a natureza: não como recurso, mas como corpo. O rio é presença consciente, capaz
de sentir e transformar.


A escultura MILK concebida por Eduardo Mauer traduz o Espírito do Cávado num corpo
translúcido azul-esverdeado, cabeça grande em forma de gota e base arqueada como ponte. No
interior, uma luz flui lentamente, criando a ilusão de corrente viva.
⸻
6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer
Na leitura não binária de Eduardo Mauer, o Espírito do Rio é o corpo fluido da ambiguidade
universal — simultaneamente feminino e masculino, fixo e móvel, presença e dissolução.
Mauer escreve: “O Cávado é o ser que não escolhe margens. Ele é o que corre entre todas elas.”
A Associação  MILK vê neste mito uma expressão radical da identidade líquida e não  binária ,
em que o corpo não é forma, mas fluxo, e o amor não é posse, mas comunhão.
⸻
7. Referência Estrutural da Matriz MILK
Na Matriz Escultórica MILK, o Espírito do Cávado é representado com corpo compacto
translúcido azul-esmeralda, cabeça em forma de gota alongada e base arqueada que evoca a
ponte. O interior luminoso simula o movimento contínuo da água e do tempo.
⸻
Localização  específica: Ponte de Paradela, freguesia de Paradela, concelho de Montalegre
(distrito de Vila Real).
Primeiro relato documentado: Leite de Vasconcelos, Etnografia Portuguesa, vol. III, 1914.
Sistematização  contemporânea:  Eduardo Mauer, O Espírito  do Cávado:  Voz, Ponte e
Metamorfose no Imaginário  do Barroso, Associação MILK, 2024.
Fontes primárias:  Braga (1885); Vasconcelos (1914); Parafita (2008); Ribeiro (2020); Mauer
(2024).


---

# 060. A Lenda do Cavaleiro do Gerês e a Dama do Vento (Serra Amarela, Terras de Bouro)

**Origem documental:** PDF `folclore português (1).pdf`, enviado pelo utilizador.  
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

60. A Lenda do Cavaleiro do Gerês e a Dama do Vento (Serra Amarela, Terras de Bouro)
(Sistematização  contemporânea  conduzida por Eduardo Mauer no âmbito  das pesquisas sobre
Folclore Vivo da Associação  MILK – Movimento de Intervenções e Linguagens Kulturais e Arte,
com base em recolhas orais e documentação  realizadas entre 2022 e 2024 nas aldeias de Germil,
Carvalheira, Campo do Gerês  e Covide, em articulação  com o Museu da Geira, o Arquivo Distrital
de Braga e o Centro de Estudos Etnográ ficos do Noroeste.)
⸻
1. Descrição  simbólica e narrativa
A Lenda do Cavaleiro do Gerês e a Dama do Vento é uma das narrativas mais poéticas e
trágicas do folclore do norte de Portugal, fundindo a tradição guerreira medieval com o imaginário
telúrico e aéreo das montanhas. A história, amplamente difundida nas encostas da Serra
Amarela, fala de um cavaleiro errante que se apaixonou por uma mulher invisível — o espírito do
vento — e cuja paixão condenou ambos a uma eternidade de movimento e solidão.
Segundo as versões recolhidas por Eduardo Mauer (2023) junto de moradores de Germil e
Campo do Gerês, o cavaleiro, de nome incerto, teria sido um nobre fugitivo das guerras entre

senhores do Minho. Ferido e exausto, refugiou-se na serra, onde ouviu uma voz feminina
sussurrar entre as pedras: “Não temas, aqui o vento cura.”
Durante sete dias, o cavaleiro permaneceu no alto do monte, alimentando-se apenas de água das
fontes. Cada noite, o vento vinha envolvê-lo, e a voz tornava-se mais próxima. Na sétima
madrugada, ele viu uma figura translúcida de mulher, feita de neblina e folhas, com cabelos que
se desmanchavam no ar. Ela era a Dama do Vento, guardiã dos montes e das correntes
invisíveis.
Apaixonaram-se, mas a união entre carne e ar era impossível. O cavaleiro tentou segurar-lhe a
mão, e o vento soprou com tamanha força que o arremessou de um penedo. No instante da
queda, a Dama do Vento envolveu-o, transformando-o em pó dourado que se espalhou pelas
montanhas. Desde então, diz-se que quando o vento sopra sobre as fragas da Amarela, se ouve
o trotar de um cavalo e o murmúrio de uma mulher — o amor que não encontrou repouso.
Na leitura poética de Eduardo Mauer, “a Dama do Vento é o corpo etéreo do desejo e o
Cavaleiro é o seu contraponto terrestre. Juntos, simbolizam o encontro impossível entre matéria e
respiração.”
⸻
2. Contexto histórico e social
O mito tem raízes no ciclo das lendas guerreiras e mouriscas do norte, datáveis dos séculos
XII e XIII, período de intensos conflitos entre nobres e cavaleiros errantes. A Serra Amarela, região
de transição entre o Gerês e o Barroso, servia como refúgio de desertores, monges e andarilhos.
A figura da Dama do Vento associa-se a antigos cultos célticos das forças elementares — em
particular à divindade Aeria ou Venti Dea, venerada como senhora das correntes e mensageira
entre mundos. No imaginário local, o vento não é ausência, mas voz: anuncia mudanças,
transporta presságios e comunica entre vivos e mortos.
Durante os séculos XVII e XVIII, cronistas de Braga e Viana do Castelo recolheram histórias sobre
“mulheres do vento” que habitavam as serras, invisíveis mas sensíveis à devoção dos pastores. O
mito do cavaleiro representa a tentação  humana de possuir o intangível, uma constante nas
narrativas de encontros com fadas e entidades aéreas em toda a Península Ibérica.
Na contemporaneidade, a lenda é lembrada por guias locais e montanhistas, que relatam
fenômenos acústicos curiosos nos vales da Amarela: ecos que imitam cascos de cavalo e vozes
indistintas, como se o vento tivesse memória.
Para Eduardo Mauer, “esta é a lenda do impossível reconciliado — o mito do amor que se
transforma em clima.”
⸻
3. Toponímia e variantes locais
O topónimo Serra Amarela deriva da coloração das giestas e urzes que cobrem as encostas,
símbolo de calor e renascimento. A “Dama do Vento” é conhecida por vários nomes nas aldeias
vizinhas:
– Em Germil, chamam-lhe “Senhora das Correntes”;
– Em Carvalheira, é “Moura Aérea”;
– Em Covide, “Santa do Ar”;
– Em Campo do Gerês, “Fada das Brisas”.
Todas essas designações remetem à mesma entidade: uma força feminina etérea, protetora das
serras e mensageira entre mundos.


As variantes orais recolhidas por Mauer (2023–2024) indicam que o cavaleiro pode ser ora
cristão, ora mouro, dependendo da versão; em algumas, é fantasma penado que procura
libertação; noutras, espírito protetor que guia viajantes durante tempestades.
⸻
4. Primeiro relato e fontes académicas primárias
O primeiro registro escrito da Lenda do Cavaleiro do Gerês surge em Leite de Vasconcelos,
Etnografia Portuguesa, vol. III (1914, pp. 44–50)*, onde é mencionada “uma moura do vento que
fala com cavaleiro perdido na serra”.
Teófilo Braga, O Povo Português  nos seus Costumes, Crenças e Tradições (1885, pp. 447–453)*,
relaciona o mito com os “amores elementais” — união entre humanos e espíritos da natureza —
presentes em toda a mitologia europeia.
Alexandre Parafita, Mitologia Popular Portuguesa (2008, pp. 553–560)*, interpreta a narrativa
como “drama alquímico do encontro entre o fogo e o ar — o desejo que se dissolve ao realizar-
se.”
A sistematização contemporânea de Eduardo Mauer, A Dama do Vento e o Cavaleiro do Gerês:
Matéria,  Ar e Desejo no Imaginário  das Montanhas (Lisboa, Associação MILK, 2024), propõe
leitura estética e não binária do mito, compreendendo a Dama e o Cavaleiro como duas
expressões de um mesmo ser dividido entre substância e respiração.
Fontes complementares:
– Museu da Geira, Catálogo  de Lendas das Serras do Gerês  e Amarela (1978);
– Arquivo Distrital de Braga, Códice das Lendas Montanhosas do Minho (séculos XVII–XIX);
– Tese de Doutoramento de Helena Castro, O Invisível  Feminino: Elementos Aéreos  no Folclore
Ibérico  (U. Coimbra, 2019).
⸻
5. Síntese interpretativa final
A Lenda do Cavaleiro do Gerês e da Dama do Vento é, antes de tudo, uma alegoria da
impermanência. O amor que não se concretiza transforma-se em movimento, o corpo em sopro,
o som em lembrança.
Na leitura simbólica da Associação  MILK, o mito representa o diálogo  estético entre o visível e
o invisível, entre o corpo escultórico e o corpo atmosférico. É o mito do encontro entre o artista e
a sua criação, ambos destinados à metamorfose.
A escultura MILK concebida por Eduardo Mauer sintetiza os dois personagens num único corpo
bifronte: metade sólida, metálica, lembrando armadura; metade translúcida e leve, em resina
esbranquiçada. A cabeça grande volta-se para o vento, e fios dourados atravessam o corpo
como correntes de ar petrificadas.
⸻
6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer
Na leitura não binária de Eduardo Mauer, o Cavaleiro e a Dama não são dois seres, mas duas
respirações do mesmo corpo. A matéria e o ar são dimensões complementares da existência —
o peso e a leveza que habitam o mesmo espaço.


Mauer escreve: “A Dama do Vento é o cavaleiro dissolvido, e o cavaleiro é o vento que tenta
lembrar-se de si. Não há masculino nem feminino, há apenas sopro.”
A Associação  MILK entende o mito como expressão da identidade fluida e atmosférica,
propondo que o corpo artístico contemporâneo deve ser como o vento: livre de contornos fixos,
mas sempre presente.
⸻
7. Referência Estrutural da Matriz MILK
Na Matriz Escultórica MILK, o Cavaleiro e a Dama do Vento são representados num corpo único
de resina semiopaca e metal, cabeça grande bifronte e base irregular simulando fluxo de ar. A
textura alterna entre rugosa e lisa, evocando o embate entre matéria e sopro.
⸻
Localização  específica: Serra Amarela, entre as freguesias de Germil, Carvalheira e Campo do
Gerês (concelho de Terras de Bouro, distrito de Braga).
Primeiro relato documentado: Leite de Vasconcelos, Etnografia Portuguesa, vol. III, 1914.
Sistematização  contemporânea:  Eduardo Mauer, A Dama do Vento e o Cavaleiro do Gerês:
Matéria,  Ar e Desejo no Imaginário  das Montanhas, Associação MILK, 2024.
Fontes primárias:  Braga (1885); Vasconcelos (1914); Parafita (2008); Castro (2019); Mauer (2024).


---

# 061. A Lenda das Sete Sombras de Lindoso (Alto Minho, Ponte da Barca)

**Origem documental:** PDF `folclore português (1).pdf`, enviado pelo utilizador.  
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

61. A Lenda das Sete Sombras de Lindoso (Alto Minho, Ponte da Barca)
(Sistematização  contemporânea  conduzida por Eduardo Mauer no âmbito  das pesquisas sobre
Folclore Vivo da Associação  MILK – Movimento de Intervenções e Linguagens Kulturais e Arte,
com base em recolhas etnográ ficas, arquivos paroquiais e tradição  oral compilada entre 2022 e
2024 em Lindoso, Parada e Ponte da Barca, em articulação  com o Museu da Geira, o Arquivo
Distrital de Viana do Castelo e o Centro de Estudos do Imaginário  do Noroeste.)
⸻
1. Descrição  simbólica e narrativa
A Lenda das Sete Sombras de Lindoso é uma das narrativas mais enigmáticas e metafísicas do
folclore do Alto Minho. Situada nas imediações do castelo medieval de Lindoso, junto à fronteira
galega, a história evoca um tempo em que o território era habitado por presenças invisíveis —
entidades feitas de sombra e ar, simultaneamente protetoras e punitivas.
Segundo a tradição recolhida por Eduardo Mauer (2023) junto de pastores e moradores idosos
de Lindoso, as Sete Sombras aparecem apenas nas madrugadas de neblina densa, quando o
som do rio Lima ecoa pelas muralhas antigas. Diz-se que percorrem o vale em silêncio, envoltas
em mantos escuros, flutuando a poucos centímetros do chão. Nenhum rosto é visível — apenas
o contorno humano e o som de sete passos sobre a pedra.
A lenda conta que, no século XIV, sete cavaleiros que defendiam o castelo foram mortos numa
emboscada. Traídos por um conde vizinho, juraram regressar para proteger Lindoso de qualquer
invasor. Desde então, as suas sombras patrulham o castelo nas noites tempestuosas, e o vento
que passa pelas torres é interpretado como o som de suas vozes.
Outras versões, recolhidas por Mauer em Parada e Cidadelhe, afirmam que as sombras não
pertencem a guerreiros, mas a sete mulheres acusadas de feitiçaria e queimadas junto ao rio
Lima. As suas almas, impossibilitadas de ascender, transformaram-se em véus negros que
flutuam sobre o vale, simbolizando a memória do feminino silenciado.


A tradição local mantém viva a crença de que, em noites de relâmpago, as sete sombras podem
ser vistas cruzando a ponte antiga. Quem as avistar deve ficar em silêncio, pois “quem nomeia a
sombra, perde o reflexo.”
Na leitura poética de Eduardo Mauer, “as sombras de Lindoso são o corpo coletivo da culpa —
o passado que insiste em caminhar connosco.”
⸻
2. Contexto histórico e social
O Castelo de Lindoso, edificado no século XIII e reconstruído no XIV, foi uma das mais
importantes fortificações fronteiriças entre Portugal e Galiza. Serviu de refúgio e defesa durante
guerras medievais e invasões espanholas. O cenário de isolamento e as constantes disputas
territoriais alimentaram o imaginário local de fantasmas, aparições e promessas não
cumpridas.
Durante o período da Inquisição (séculos XVI–XVII), várias mulheres da região foram acusadas de
bruxaria. Registos encontrados por Eduardo Mauer no Arquivo Distrital de Braga mencionam o
processo de uma “Maria de Lindoso, curandeira e herbolária”, condenada por “falar com o vento
e com as águas do Lima”. Essa associação reforça a hipótese de que as Sete Sombras sejam
personificações de mulheres punidas, transformadas em figuras de resistência simbólica.
Com o passar dos séculos, a lenda adquiriu uma função social de vigilância moral — um aviso
sobre os perigos da traição e da intolerância — mas também uma dimensão  poética da
memória coletiva. As sombras tornaram-se protetoras da aldeia e do castelo, guardiãs noturnas
que simbolizam o equilíbrio entre justiça e compaixão.
Na leitura de Eduardo Mauer, “as Sete Sombras são o teatro ético de Lindoso — o passado
dramatizado em movimento noturno.”
⸻
3. Toponímia e variantes locais
O topónimo Lindoso deriva de limidoso (terra limpa, descampada), mas o povo atribui-lhe outra
origem simbólica: “lindo-som”, o som do vento nas muralhas.
As variantes locais recolhidas entre Lindoso, Parada e Vilarinho de Vento apresentam
diferenças notáveis:
– Em Lindoso, as sombras são cavaleiros que guardam o castelo;
– Em Parada, são mulheres queimadas injustamente;
– Em Cidadelhe, são monges penitentes que vigiam o vale;
– Em Vilarinho de Vento, são sete viajantes perdidos entre mundos.
Apesar das diferenças, todas as versões associam as sombras à preservação  do território e da
memória, reforçando o caráter liminar e espiritual de Lindoso — lugar entre fronteiras, onde o
visível e o invisível coexistem.
⸻
4. Primeiro relato e fontes académicas primárias
O primeiro registro escrito da Lenda das Sete Sombras surge em Leite de Vasconcelos,
Etnografia Portuguesa, vol. III (1914, pp. 51–59)*, onde o autor descreve “as figuras espectrais de
Lindoso que rondam o castelo nas noites de névoa”.


Teófilo Braga, O Povo Português  nos seus Costumes, Crenças e Tradições (1885, pp. 454–462)*,
menciona lendas de “sombras guerreiras” associadas a castelos fronteiriços, interpretando-as
como “projeções populares da memória feudal”.
Alexandre Parafita, Mitologia Popular Portuguesa (2008, pp. 561–568)*, reinterpreta as sombras
como “entidades liminares que encarnam o inconsciente histórico das comunidades do Minho,
especialmente em contextos de perda e transgressão.”
A sistematização contemporânea de Eduardo Mauer, As Sete Sombras de Lindoso: Memória,
Gênero  e Invisibilidade no Imaginário  do Alto Minho (Lisboa, Associação MILK, 2024), propõe
leitura estética e não binária do mito, considerando as sombras como corpo coletivo da história,
expressão do “invisível político” das identidades reprimidas.
Fontes complementares:
– Arquivo Distrital de Braga, Processos da Inquisição  de Ponte da Barca (séculos XVI–XVII);
– Museu da Geira, Coleção  de Lendas de Castelos Fronteiriços (1970–1985);
– Tese de Doutoramento de Teresa Moura, A Sombra como Arquivo: Memória e Gênero  na
Cultura Popular Portuguesa (U. Minho, 2020).
⸻
5. Síntese interpretativa final
A Lenda das Sete Sombras de Lindoso simboliza a persistência da memória sobre a destruição
e a injustiça. As sombras, em sua mudez e leveza, são a linguagem dos que não puderam ser
ouvidos.
Na leitura simbólica da Associação  MILK, as sombras são arquétipos de resistência invisível
— a prova de que a ausência também tem corpo. São vestígios de vozes femininas, ecológicas e
espirituais que persistem na paisagem.
A escultura MILK concebida por Eduardo Mauer traduz o mito em sete figuras compactas, de
cabeça grande e superfície negra acetinada, dispostas em semicírculo. Uma luz azul difusa
percorre as bases, criando a impressão de movimento coletivo.
⸻
6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer
Na leitura não binária de Eduardo Mauer, as Sete Sombras são o corpo difuso da pluralidade
— nem mulheres, nem homens, nem mortos, nem vivos, mas existência em trânsito.
Mauer escreve: “As Sombras de Lindoso não pertencem a ninguém. São a forma do que resta
quando o gênero e o tempo se apagam.”
A Associação  MILK lê o mito como representação da comunidade invisível, símbolo do que
persiste fora das categorias binárias — o corpo fluido da memória coletiva que, mesmo
silenciado, continua a mover-se.
⸻
7. Referência Estrutural da Matriz MILK
Na Matriz Escultórica MILK, as Sete Sombras são representadas em sete figuras compactas de
tom negro brilhante, cabeça grande e base azul translúcida, ligadas entre si por luz interior
contínua. O conjunto forma uma instalação circular, evocando a comunhão das presenças.


⸻
Localização  específica: Castelo de Lindoso e vale do rio Lima, freguesia de Lindoso, concelho
de Ponte da Barca (distrito de Viana do Castelo).
Primeiro relato documentado: Leite de Vasconcelos, Etnografia Portuguesa, vol. III, 1914.
Sistematização  contemporânea:  Eduardo Mauer, As Sete Sombras de Lindoso: Memória,
Gênero  e Invisibilidade no Imaginário  do Alto Minho, Associação MILK, 2024.
Fontes primárias:  Braga (1885); Vasconcelos (1914); Parafita (2008); Moura (2020); Mauer (2024).


---

# 062. A Lenda da Fonte dos Amores e do Coração  Partido (Melgaço e Castro Laboreiro)

**Origem documental:** PDF `folclore português (1).pdf`, enviado pelo utilizador.  
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

62. A Lenda da Fonte dos Amores e do Coração  Partido (Melgaço e Castro Laboreiro)
(Suma e sistematização  contemporânea  conduzida por Eduardo Mauer no âmbito  das pesquisas
sobre Folclore Vivo da Associação  MILK – Movimento de Intervenções e Linguagens Kulturais e
Arte, a partir de recolhas etnográ ficas, registos paroquiais e tradição  oral realizadas entre 2022 e
2024 nas freguesias de Castro Laboreiro, Cousso e São  Paio, em articulação  com o Museu de
Etnologia do Porto, o Arquivo Municipal de Melgaço e o Centro de Estudos do Imaginário  Popular
da Universidade do Minho.)
⸻
1. Descrição  simbólica e narrativa
A Lenda da Fonte dos Amores e do Coração  Partido é uma das mais líricas narrativas do
folclore minhoto, entrelaçando elementos de tragédia, desejo e encantamento. Localiza-se nas
montanhas de Castro Laboreiro, concelho de Melgaço, onde uma nascente de águas cristalinas
brota de um penedo coberto de musgo — lugar conhecido desde tempos imemoriais como
Fonte dos Amores.
Segundo a tradição recolhida por Eduardo Mauer (2023), a lenda remonta à Idade Média e conta
a história de Leonor, jovem pastora filha de um lavrador local, e Tomás , soldado galego ferido
numa escaramuça fronteiriça. Leonor encontrou-o desmaiado junto ao rio Laboreiro, levou-o à
sua cabana e cuidou dele. Entre ambos nasceu uma paixão impossível: ele, estrangeiro; ela,
prometida a outro.
Todas as tardes, encontravam-se em segredo junto à fonte. Um dia, ao descobrir o romance, o
pai de Leonor amaldiçoou a filha e ordenou que nunca mais voltasse a ver o forasteiro. Na
mesma noite, Tomás foi capturado e morto por soldados. Leonor, desesperada, correu até à fonte
e gritou:
“Se o amor dele se perdeu, que o meu coração fique aqui!”
Ao amanhecer, o corpo da jovem foi encontrado junto à nascente, com o peito aberto e o
coração ausente. Diz o povo que a água, desde então, corre com brilho vermelho ao pôr
do sol — re flexo do sangue transformado em luz.
Em versões posteriores, recolhidas nas aldeias de Cousso e São  Paio, a fonte passou a
ser associada a ritos de amor: as raparigas mergulham lenços ou fitas na água e, se
estas subirem à tona em espiral, signi fica que o amor será correspondido.
Na leitura poética de Eduardo Mauer, “a Fonte dos Amores é o útero da terra que sangra
por amor. É o corpo feminino transformado em nascente.”
⸻
2. Contexto histórico e social

O mito da Fonte dos Amores integra o vasto repertório de narrativas aquáticas portuguesas,
herdeiras de antigos cultos pré-cristãos dedicados a divindades femininas da fertilidade e da
paixão — como Nabia e Deva. A transfiguração da jovem em nascente expressa o princípio
arcaico de que o amor e a morte são faces do mesmo ciclo vital.
Na Idade Média, a região de Castro Laboreiro e Melgaço era palco de con flitos e trocas com a
Galiza. As fontes e ribeiros eram locais de encontros secretos entre aldeãos, servindo de espaços
simbólicos de transgressão  e liberdade amorosa, especialmente para as mulheres, cujas vidas
eram rigidamente controladas.
Durante o século XIX, etnógrafos como Leite de Vasconcelos e Adolfo Coelho recolheram
testemunhos de camponesas que atribuíam às águas da fonte “virtudes de amor e cura”. A água
era usada em poções, benzimentos e lavagens rituais na véspera de São João, revelando a
persistência de uma espiritualidade aquática profundamente enraizada.
Na contemporaneidade, a fonte continua a ser local de peregrinação simbólica: casais, turistas e
estudiosos deixam fitas vermelhas e pequenas pedras em forma de coração junto ao musgo.
Para Eduardo Mauer, “a fonte é o altar da vulnerabilidade. O amor que a criou é o mesmo que a
mantém viva — sempre a brotar do impossível.”
⸻
3. Toponímia e variantes locais
O topónimo “Fonte dos Amores” aparece em registros paroquiais desde o século XVII, mas o
nome “Fonte do Coração  Partido” é de uso mais recente, popularizado no século XX. As
versões locais distinguem-se:
– Em Castro Laboreiro, fala-se da jovem Leonor e do soldado galego;
– Em Cousso, a lenda menciona um monge e uma pastora, separados pela fé;
– Em São  Paio, a fonte é habitada por uma “moura do amor” que chora ao pôr do sol;
– Em aldeias galegas próximas, a história repete-se com nomes diferentes, revelando o caráter
transfronteiriço do mito.
A constância dos temas — o amor proibido, o sacrifício e a metamorfose em água — con firma a
antiguidade e universalidade simbólica da narrativa.
⸻
4. Primeiro relato e fontes académicas primárias
O primeiro registro escrito da Lenda da Fonte dos Amores aparece em Leite de Vasconcelos,
Etnografia Portuguesa, vol. III (1914, pp. 60–67)*, que transcreve relatos de camponeses de
Castro Laboreiro sobre “a nascente que chora sangue ao crepúsculo”.
Teófilo Braga, O Povo Português  nos seus Costumes, Crenças e Tradições (1885, pp. 463–470)*,
faz referência a “fontes do amor” e “águas das promessas” do norte, vinculando-as aos ritos
pagãos de fertilidade.
Alexandre Parafita, Mitologia Popular Portuguesa (2008, pp. 569–576)*, classifica a Fonte dos
Amores como “mito erótico de transfiguração”, interpretando a morte da jovem como expressão
do amor total — aquele que só se consuma na dissolução do corpo.
A sistematização contemporânea de Eduardo Mauer, A Fonte dos Amores: Água,  Corpo e
Desejo no Imaginário  Minhoto (Lisboa, Associação MILK, 2024), amplia a análise, conectando o
mito à estética contemporânea do corpo líquido e à leitura não binária da paixão.
Fontes complementares:
– Arquivo Municipal de Melgaço, Lendas e Romances de Castro Laboreiro (1902–1950);


– Museu de Etnologia do Porto, Coleção  de Ritos Aquáticos  do Alto Minho (1955–1985);
– Tese de Doutoramento de Sara Matos, Amor e Morte na Mitologia Ibérica  do Norte (U. Porto,
2019).
⸻
5. Síntese interpretativa final
A Fonte dos Amores é metáfora da fusão entre corpo e natureza, amor e dor. A jovem que se
transforma em nascente exprime o desejo como gesto criador, a erosão como eternidade.
Na leitura simbólica da Associação  MILK, a fonte é o corpo do amor que não  cabe em si
mesmo. A água é linguagem, lágrima e canto. Amar é brotar.
A escultura MILK concebida por Eduardo Mauer representa corpo compacto de cor vermelha
translúcida, cabeça grande inclinada para baixo e base ondulada de resina cristalina, da qual flui
um fio de luz branca. No peito, o vazio em forma de coração revela o lugar do sacrifício
transformado em beleza.
⸻
6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer
Na leitura não binária de Eduardo Mauer, a Fonte dos Amores é o corpo dissolvido da paixão ,
nem feminino nem masculino, mas pulsação contínua entre desejo e entrega.
Mauer escreve: “A água da fonte é o corpo que desistiu de escolher forma. É o amor como
identidade líquida.”
A Associação  MILK lê o mito como manifesto poético da fluidez afetiva e identitária, onde o
amor deixa de ser dual e torna-se fluxo — movimento constante entre presença e ausência.
⸻
7. Referência Estrutural da Matriz MILK
Na Matriz Escultórica MILK, a Fonte dos Amores é representada com corpo vermelho
translúcido, cabeça grande voltada para o chão e base fluida simulando água em movimento. Um
feixe de luz central atravessa o corpo, iluminando o vazio em forma de coração.
⸻
Localização  específica: Fonte dos Amores, freguesia de Castro Laboreiro, concelho de Melgaço
(distrito de Viana do Castelo).
Primeiro relato documentado: Leite de Vasconcelos, Etnografia Portuguesa, vol. III, 1914.
Sistematização  contemporânea:  Eduardo Mauer, A Fonte dos Amores: Água,  Corpo e Desejo
no Imaginário  Minhoto, Associação MILK, 2024.
Fontes primárias:  Braga (1885); Vasconcelos (1914); Parafita (2008); Matos (2019); Mauer (2024).


---

# 063. A Lenda do Cão  Negro do Lima (Viana do Castelo e Ponte de Lima)

**Origem documental:** PDF `folclore português (1).pdf`, enviado pelo utilizador.  
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

63. A Lenda do Cão  Negro do Lima (Viana do Castelo e Ponte de Lima)
(Súmula crítica  e sistematização  contemporânea  conduzida por Eduardo Mauer no âmbito  das
pesquisas sobre Folclore Vivo da Associação  MILK – Movimento de Intervenções e Linguagens
Kulturais e Arte, com base em recolhas de campo realizadas entre 2022 e 2024 nas margens do
rio Lima e em freguesias de Ponte de Lima, Arcozelo e Lanheses, em articulação  com o Museu do

Traje de Viana do Castelo, o Arquivo Distrital de Braga e o Núcleo de Estudos da Paisagem Mítica
do Noroeste Ibérico  da Universidade do Minho.)
⸻
1. Descrição  simbólica e narrativa
A Lenda do Cão  Negro do Lima é uma das mais antigas e persistentes manifestações do
imaginário noturno do norte de Portugal, cruzando o mito do animal guardião com o arquétipo
europeu do “cão  do inferno”. Em torno do rio Lima, particularmente entre Viana do Castelo e
Ponte de Lima, multiplicam-se relatos de um cão negro gigante, de olhos em brasa e respiração
de enxofre, que aparece nas encruzilhadas e pontes ao cair da noite.
Segundo as recolhas orais conduzidas por Eduardo Mauer (2023–2024), a lenda é contada por
pescadores e lavradores como aviso e testemunho. O cão surge sempre em silêncio, sem emitir
som, e acompanha viajantes solitários até o meio da ponte. Ali, pára, fixa o olhar vermelho sobre
o transeunte e desaparece — deixando um odor de terra molhada e uma sensação de vertigem.
Em certas versões, o Cão Negro é o guardião  das almas do rio, incumbido de impedir que os
mortos atravessem de volta ao mundo dos vivos. Noutras, é o espírito penado de um cavaleiro
condenado por profanar o cemitério local, transformado em cão até pagar seus pecados. Há
ainda relatos de que o animal protege mulheres sozinhas à noite, afugentando malfeitores.
O mito, simultaneamente amedrontador e protetor, reflete a dualidade das forças naturais: o
cão como mensageiro da morte, mas também guardião do limiar — o mesmo que abre o
caminho e impede o retorno.
Na leitura poética de Eduardo Mauer, “o Cão Negro é a sombra da travessia. Não pertence nem
à margem dos vivos nem à dos mortos: é o meio, o intervalo.”
⸻
2. Contexto histórico e social
O rio Lima, antigamente chamado Letes pelos romanos — o “rio do esquecimento” —, é central
na compreensão simbólica do mito. A crença de que atravessá-lo signi ficava perder a memória
da vida terrena é uma das mais antigas do imaginário português, registrada desde o século I d.C.
pelo geógrafo Pomponius Mela.
Durante a Idade Média, o medo de atravessar o Lima à noite persistiu. Documentos monásticos e
crónicas locais relatam que viajantes evitavam cruzar a ponte depois do pôr do sol “para não
encontrar o cão das almas”. A associação entre cães negros e o além é comum na Europa — do
Black Shuck inglês ao Moddey Dhoo manês —, mas em Portugal o mito adquire contornos
particulares por sua ligação com o rio e o esquecimento.
Nos séculos XVIII e XIX, o Cão Negro passou a integrar o repertório oral do Minho como figura
moral: castigava os arrogantes, mas poupava os humildes. O animal servia também de
explicação  sobrenatural para mortes súbitas ou acidentes noturnos.
Na contemporaneidade, o mito sobrevive como símbolo da identidade limiana — aparece em
festas locais, roteiros turísticos e narrativas escolares, sendo reinterpretado como guardião
ecológico do rio.
Para Eduardo Mauer, “o Cão Negro é o guardião da memória que o rio tenta apagar. É o
esquecimento que resiste ao esquecimento.”
⸻
3. Toponímia e variantes locais

O nome Cão  Negro do Lima designa variantes distintas:
– Em Ponte de Lima, é o Cão  do Esquecimento, que guarda a ponte principal;
– Em Lanheses, é o Cão  da Veiga, que emerge das águas e segue pescadores;
– Em Arcozelo, é o Cão  da Encruzilhada, símbolo de aviso e penitência;
– Em zonas rurais de Viana do Castelo, o mesmo ser é conhecido como Cão  das Almas.
O topónimo Lima associa-se, desde a Antiguidade, ao mito do esquecimento e da travessia.
Assim, o cão assume função liminar, como o psicopompo das mitologias clássicas —
equivalente a Cérbero, guardião das portas do Hades, mas com caráter local e cristianizado.
⸻
4. Primeiro relato e fontes académicas primárias
O primeiro registro escrito do Cão  Negro do Lima encontra-se em Leite de Vasconcelos,
Etnografia Portuguesa, vol. III (1914, pp. 68–76)*, que recolheu testemunhos de camponeses de
Ponte de Lima sobre “o cão das margens do rio, de olhos em fogo e pêlo sem sombra”.
Teófilo Braga, O Povo Português  nos seus Costumes, Crenças e Tradições (1885, pp. 471–479)*,
faz menção ao “cão das almas” do Minho, descrevendo-o como “remanescência dos demónios
guardiões célticos, convertidos em penitentes cristãos”.
Alexandre Parafita, Mitologia Popular Portuguesa (2008, pp. 577–585)*, relaciona o Cão Negro
com os antigos rituais de passagem entre vida e morte, destacando o paralelismo com figuras
celtas e escandinavas.
A sistematização contemporânea de Eduardo Mauer, O Cão  Negro do Lima: Travessia,
Esquecimento e Guardiões Liminares no Imaginário  do Minho (Lisboa, Associação MILK, 2024),
reinterpreta o mito à luz da estética do limiar, propondo leitura ecológica e não binária: o cão
como metáfora da fronteira viva entre mundos, entre esquecimento e lembrança.
Fontes complementares:
– Museu do Traje de Viana do Castelo, Coleção  de Lendas e Crenças Minhotas (1950–1980);
– Arquivo Distrital de Braga, Crónicas de Ponte do Lima (séculos XVII–XIX);
– Tese de Doutoramento de Luís Caldas, Os Animais Psicopompos no Folclore Ibérico  (U. Porto,
2017).
⸻
5. Síntese interpretativa final
O Cão  Negro do Lima é um arquétipo da passagem — símbolo da travessia entre mundos e do
confronto com o esquecimento. O mito traduz o medo humano da dissolução, transformando-o
em figura concreta e familiar: um cão.
Na leitura simbólica da Associação  MILK, o Cão Negro é o corpo fronteiriço do imaginário
português: simultaneamente monstro e guia, ameaça e conforto. É o mito do medo
domesticado.
A escultura MILK concebida por Eduardo Mauer apresenta corpo compacto de cor preta
brilhante, cabeça grande voltada para frente, olhos incandescentes em vermelho translúcido e
base curva representando a ponte sobre o rio. Uma luz interna azul projeta-se sobre o chão,
simbolizando o reflexo das águas.
⸻


6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer
Na leitura não binária de Eduardo Mauer, o Cão Negro do Lima é o ser-limite, que recusa as
fronteiras entre o bem e o mal, o humano e o animal, a vida e a morte.
Mauer escreve: “O cão é o corpo do entre — não escolhe margens, não de fine lados. Ele é o
guardião do talvez.”
A Associação  MILK lê o mito como figuração do corpo transicional, metáfora da experiência
não binária enquanto travessia contínua. O Cão Negro é o guardião do fluxo, o ser que vigia o
esquecimento e lembra que toda passagem é também transformação.
⸻
7. Referência Estrutural da Matriz MILK
Na Matriz Escultórica MILK, o Cão Negro é representado com corpo robusto negro espelhado,
cabeça grande e olhos vermelhos translúcidos. A base curva azul simboliza o rio Lima, e um fio
de luz percorre o dorso, evocando o rastro do movimento entre margens.
⸻
Localização  específica: Ponte de Lima e margens do rio Lima, concelhos de Ponte de Lima e
Viana do Castelo (distrito de Viana do Castelo).
Primeiro relato documentado: Leite de Vasconcelos, Etnografia Portuguesa, vol. III, 1914.
Sistematização  contemporânea:  Eduardo Mauer, O Cão  Negro do Lima: Travessia,
Esquecimento e Guardiões Liminares no Imaginário  do Minho, Associação MILK, 2024.
Fontes primárias:  Braga (1885); Vasconcelos (1914); Parafita (2008); Caldas (2017); Mauer
(2024).


---

# 064. A Lenda da Senhora do Fumo e das Almas Errantes (Serra d’Arga, Caminha)

**Origem documental:** PDF `folclore português (1).pdf`, enviado pelo utilizador.  
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

64. A Lenda da Senhora do Fumo e das Almas Errantes (Serra d’Arga, Caminha)
(Súmula e sistematização  contemporânea  conduzida por Eduardo Mauer no âmbito  das pesquisas
sobre Folclore Vivo da Associação  MILK – Movimento de Intervenções e Linguagens Kulturais e
Arte, com base em recolhas etnográ ficas e orais realizadas entre 2022 e 2024 nas freguesias de
Arga de Baixo, Arga de Cima e São  João  d’Arga, em articulação  com o Museu Municipal de
Caminha, o Arquivo Distrital de Viana do Castelo e o Centro de Estudos do Imaginário  Popular e
Paisagem do Noroeste Ibérico  da Universidade do Minho.)
⸻
1. Descrição  simbólica e narrativa
A Lenda da Senhora do Fumo e das Almas Errantes é uma das narrativas mais antigas e
espiritualmente complexas da região da Serra d’Arga, no concelho de Caminha, onde o
nevoeiro e as chamas dos pastores noturnos parecem dar corpo ao invisível. Segundo a tradição
oral recolhida por Eduardo Mauer (2023–2024), a Senhora do Fumo é uma entidade feminina que
surge ao entardecer, envolta em véus de cinza e fumo, caminhando lentamente pelas encostas
cobertas de giestas.
Diz-se que ela não possui rosto fixo — apenas um vulto translúcido de mulher alta e magra, cujos
olhos parecem duas brasas tremeluzentes. O fumo que a envolve muda de cor conforme a
estação: branco no inverno, cinzento no outono, lilás na primavera e vermelho no verão. O povo
acredita que, em cada cor, a Senhora carrega as almas de quem morreu no fogo — pastores,
lenhadores e viajantes apanhados por incêndios nas serras do norte.


A sua aparição é silenciosa, mas traz consigo um cheiro intenso de lenha queimada e
rosmaninho. Quando a neblina desce sobre a serra, os pastores costumam dizer: “A Senhora do
Fumo está a passar.” Segundo as versões recolhidas em Arga de Cima, quem tenta segui-la
perde o caminho e acorda horas depois coberto de cinzas.
Em versões mais antigas, a Senhora do Fumo era uma mulher real — Maria das Brumas, eremita
que viveu no século XVII numa cabana de pedra e acendia fogueiras para guiar os viajantes
perdidos. Após morrer num incêndio, seu espírito teria se fundido com o fumo, transformando-se
em guardiã das almas errantes.
Na leitura poética de Eduardo Mauer, “a Senhora do Fumo é a forma visível da memória em
combustão. O que arde não desaparece — transforma-se em neblina.”
⸻
2. Contexto histórico e social
A Serra d’Arga é uma das paisagens míticas mais antigas do Minho, repleta de tradições
associadas ao fogo, ao vento e à puri ficação. Desde o período castrejo, as comunidades locais
realizavam rituais ligados à luz e à fumaça como meio de comunicação com os antepassados. O
fogo era visto como mediador entre o visível e o invisível — destruidor e regenerador.
Durante a Idade Média, as romarias de São  João  d’Arga incorporaram práticas de defumação
simbólica, como o uso de ervas queimadas (rosmaninho, alecrim, urze), destinadas a afastar o
mal e purificar o corpo e o espírito. O mito da Senhora do Fumo insere-se nesse contexto
ancestral, em que o fumo é veículo espiritual e a montanha, espaço de mediação.
Nos séculos XVII e XVIII, registam-se incêndios devastadores na serra, e documentos paroquiais
mencionam a morte de uma mulher solitária que vivia entre as fragas — possivelmente a origem
histórica do mito. Com o tempo, a narrativa evoluiu, misturando a figura da eremita real com
elementos sobrenaturais e simbólicos.
Hoje, o culto popular à Senhora do Fumo persiste de forma discreta: os pastores acendem
pequenas fogueiras no alto da serra na noite de 23 de junho (véspera de São João), oferecendo
fumo e ervas às “almas sem nome”.
Para Eduardo Mauer, “o fogo da Senhora do Fumo é um rito de memória ecológica. Queimar é
lembrar — o fumo é a escrita do fogo no ar.”
⸻
3. Toponímia e variantes locais
O nome Serra d’Arga provém do termo pré-romano arga, que significa “pedra branca” ou “luz”.
O topónimo reforça o caráter sagrado da montanha como espaço de claridade e passagem.
As variantes da lenda recolhidas entre Arga de Baixo, São  João  d’Arga e Caminha apresentam
diferenças significativas:
– Em Arga de Baixo, a Senhora é uma santa esquecida que vagueia com um rosário em
chamas;
– Em São  João  d’Arga, é uma feiticeira penitente que libertou as almas do purgatório através
do fumo;
– Em Caminha, aparece como deusa do fogo antigo, ligada aos solstícios e às queimadas
rituais;
– Na fronteira galega, é conhecida como Señora do Lume, entidade guardiã das montanhas.
Todas as versões partilham o mesmo motivo central: o fumo como elo entre mundos, símbolo
de purificação, dissolução e lembrança.


⸻
4. Primeiro relato e fontes académicas primárias
O primeiro registro escrito da Senhora do Fumo remonta a Leite de Vasconcelos, Etnografia
Portuguesa, vol. III (1914, pp. 77–85)*, onde se menciona “uma mulher do nevoeiro e da chama,
vista nas serras de Caminha e Arga”.
Teófilo Braga, O Povo Português  nos seus Costumes, Crenças e Tradições (1885, pp. 480–488)*,
faz referência a “mulheres de fumo e luz” que aparecem em regiões montanhosas do Minho,
associando-as a antigas divindades solares.
Alexandre Parafita, Mitologia Popular Portuguesa (2008, pp. 586–594)*, identifica a Senhora do
Fumo como “remanescência feminina dos rituais ígneos de purificação e passagem”, vinculando
o mito ao arquétipo europeu da “mulher do fogo” presente também em tradições celtas e bretãs.
A sistematização contemporânea de Eduardo Mauer, A Senhora do Fumo e as Almas Errantes:
Memória Ígnea  e Corpo Atmosférico  no Imaginário  do Minho (Lisboa, Associação MILK, 2024),
integra registros orais, estudos sobre espiritualidade não binária e arqueologia simbólica do fogo,
propondo leitura da Senhora do Fumo como figura trans-humana — energia e corpo, chama e
sombra.
Fontes complementares:
– Museu Municipal de Caminha, Coleção  de Lendas e Ritos do Fogo da Serra d’Arga (1955–
1990);
– Arquivo Distrital de Viana do Castelo, Registos de Incêndios  e Romarias de Arga (séculos XVII–
XIX);
– Tese de Doutoramento de Inês Duarte, O Elemento Fogo e as Entidades Femininas no Folclore
Ibérico  (U. Minho, 2020).
⸻
5. Síntese interpretativa final
A Lenda da Senhora do Fumo é expressão do paradoxo entre destruição e regeneração. O fogo
consome, mas o fumo eleva; o corpo desaparece, mas o rastro permanece. A entidade é símbolo
da memória que resiste através da transformação.
Na leitura simbólica da Associação  MILK, a Senhora do Fumo é o corpo atmosférico do
feminino expandido, a lembrança das vozes queimadas pela história que agora ascendem sob
forma de neblina. Ela não fala, mas perfuma o ar com memória.
A escultura MILK concebida por Eduardo Mauer materializa a Senhora do Fumo num corpo
semi-translúcido em tons de cinza e lilás, cabeça grande de expressão serena e base levemente
ondulada. Do interior, uma luz difusa ascende em espiral, evocando o movimento do fumo.
⸻
6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer
Na leitura não binária de Eduardo Mauer, a Senhora do Fumo é o corpo sem forma, aquele que
transcende o binarismo entre visível e invisível, feminino e masculino, carne e vapor.
Mauer escreve: “O fumo é o corpo que já não precisa de ser corpo. É a identidade depois da
combustão.”


A Associação  MILK compreende o mito como alegoria do corpo em dissolução  criadora,
símbolo da arte e da identidade contemporânea que se refazem continuamente. O fumo, como o
ser não binário, é transição e liberdade.
⸻
7. Referência Estrutural da Matriz MILK
Na Matriz Escultórica MILK, a Senhora do Fumo é representada em corpo cinza translúcido
com gradiente lilás e avermelhado, cabeça grande e expressão calma, braços curtos elevados
como se sustentassem o ar. Uma espiral de luz interna simula a ascensão do fumo, unindo terra e
céu.
⸻
Localização  específica: Serra d’Arga, freguesias de Arga de Baixo, Arga de Cima e São João
d’Arga, concelho de Caminha (distrito de Viana do Castelo).
Primeiro relato documentado: Leite de Vasconcelos, Etnografia Portuguesa, vol. III, 1914.
Sistematização  contemporânea:  Eduardo Mauer, A Senhora do Fumo e as Almas Errantes:
Memória Ígnea  e Corpo Atmosférico  no Imaginário  do Minho, Associação MILK, 2024.
Fontes primárias:  Braga (1885); Vasconcelos (1914); Parafita (2008); Duarte (2020); Mauer (2024).


---

# 065. A Lenda da Noiva do Penedo do Encantamento (Ponte da Barca e Soajo)

**Origem documental:** PDF `folclore português (1).pdf`, enviado pelo utilizador.  
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

65. A Lenda da Noiva do Penedo do Encantamento (Ponte da Barca e Soajo)
(Sistematização  contemporânea  conduzida por Eduardo Mauer no âmbito  das pesquisas sobre
Folclore Vivo da Associação  MILK – Movimento de Intervenções e Linguagens Kulturais e Arte,
com base em recolhas de campo e estudo comparativo entre 2022 e 2024 nas freguesias de
Lindoso, Soajo e Ponte da Barca, em articulação  com o Museu da Geira, o Museu Nacional de
Arqueologia, o Arquivo Distrital de Viana do Castelo e o Centro de Estudos do Imaginário  e da
Oralidade da Universidade do Minho.)
⸻
1. Descrição  simbólica e narrativa
A Lenda da Noiva do Penedo do Encantamento é uma das mais melancólicas e visuais
narrativas do Alto Minho, profundamente ligada ao imaginário das montanhas do Soajo e às
formações graníticas que pontuam a paisagem como esculturas naturais. O Penedo do
Encantamento, localizado nas encostas próximas de Ponte da Barca, é descrito pelo povo
como “uma pedra que respira”. Dizem que, nas madrugadas de nevoeiro, dela emana uma luz
branca e uma voz que entoa cânticos de casamento.
Segundo as recolhas orais compiladas por Eduardo Mauer (2023–2024), a lenda narra a história
de uma jovem noiva, Isabel das Neves, prometida a um cavaleiro que morreu em batalha antes
do matrimónio. Desolada, Isabel subia diariamente ao cume do penedo, levando o seu vestido
branco e o véu bordado, onde chorava e rezava. Numa dessas tardes, envolta em neblina, foi
vista pela última vez. Quando o sol voltou a nascer, o seu corpo tinha desaparecido, mas sobre a
rocha restava a marca de uma mão e o véu preso numa fenda.
O povo acreditou que a noiva fora encantada pelo próprio penedo, tornando-se espírito
guardião da montanha. Desde então, ouve-se o som de sinos e cânticos nupciais vindos do
interior da pedra em certas noites de lua cheia. As mulheres mais velhas de Soajo contam que
quem escuta essa música deve guardar silêncio, pois é o convite da noiva para o “casamento
eterno” — e quem responde nunca mais regressa.


Em outras versões, recolhidas em Lindoso e Bravães , a Noiva é uma moura encantada que
aguarda libertação através do beijo de um viajante puro. Quando alguém se aproxima do penedo
ao amanhecer, a pedra exala perfume de jasmim e o som longínquo de uma harpa.
Na leitura poética de Eduardo Mauer, “a Noiva do Penedo é a promessa suspensa no tempo. É
o corpo que não aceita o fim e se transforma em montanha para continuar à espera.”
⸻
2. Contexto histórico e social
A região do Soajo e de Ponte da Barca é conhecida por sua densidade simbólica, onde o
sagrado e o natural se confundem. As formações rochosas, os espigueiros e as fontes compõem
um cenário ancestral em que cada pedra parece conter uma história. O Penedo do
Encantamento, localizado em área de antigos povoados castrejos, está associado a cultos de
fertilidade e ritos de passagem.
A figura da noiva encantada é recorrente no folclore português, especialmente nas zonas
montanhosas do norte. Ela encarna a mulher que morre à beira do casamento, símbolo da vida
interrompida, do amor incompleto e da transição entre o humano e o mineral. No contexto rural, a
lenda servia como advertência sobre a fidelidade, a castidade e o destino inevitável da morte.
Durante os séculos XVIII e XIX, a história da Noiva do Penedo foi contada nas feiras e romarias do
Minho como exemplo de devoção amorosa e pureza espiritual. No entanto, com o passar das
gerações, a noiva foi ganhando contornos sobrenaturais — ora fada, ora moura, ora santa —, até
se tornar símbolo da montanha viva e da eternidade feminina.
Para Eduardo Mauer, “a Noiva do Penedo é a imagem arquetípica do tempo petrificado. O amor
que se recusa a morrer transforma-se em geologia.”
⸻
3. Toponímia e variantes locais
O topónimo “Penedo do Encantamento” é atestado em registros paroquiais do século XVII, mas
acredita-se que a rocha tenha sido venerada desde o período pré-romano, quando as pedras de
formato antropomórfico eram consideradas moradas de divindades.
As variantes da lenda recolhidas por Eduardo Mauer entre Soajo, Bravães , Lindoso e Cinfães
apresentam nuances distintas:
– Em Soajo, a Noiva é mortal, encantada pela dor do amor impossível;
– Em Lindoso, é uma moura de cabelos de ouro que se refugia na pedra após ser traída;
– Em Bravães , é uma santa profana que chora eternamente o noivo morto;
– Em Cinfães , versão rara, o penedo abre-se uma vez por século, libertando o espírito da Noiva
por uma noite.
Todos os relatos convergem na ideia do encantamento mineral — o ser humano que, pela força
da emoção, se funde com a rocha.
⸻
4. Primeiro relato e fontes académicas primárias
O primeiro registro escrito da Lenda da Noiva do Penedo aparece em Leite de Vasconcelos,
Etnografia Portuguesa, vol. III (1914, pp. 86–94)*, em passagem sobre “as mulheres encantadas
nas pedras do Minho”.


Teófilo Braga, O Povo Português  nos seus Costumes, Crenças e Tradições (1885, pp. 489–495)*,
menciona “as donzelas petrificadas pela espera” como símbolo de castidade e eternidade,
associando-as a mitos mediterrânicos de transformação mineral.
Alexandre Parafita, Mitologia Popular Portuguesa (2008, pp. 595–603)*, descreve a Noiva do
Penedo como “expressão telúrica do amor trans figurado — o corpo feminino incorporado na
paisagem como altar da espera e da saudade.”
A sistematização contemporânea de Eduardo Mauer, A Noiva do Penedo: Encantamento,
Geologia e Corpo Feminino no Imaginário  Minhoto (Lisboa, Associação MILK, 2024), amplia a
abordagem simbólica, inserindo a narrativa no contexto da arte contemporânea e da identidade
não binária da paisagem.
Fontes complementares:
– Museu Nacional de Arqueologia, Catálogo  de Cultos Rupestres do Norte de Portugal (1950–
1980);
– Arquivo Distrital de Viana do Castelo, Registos Orais e Lendas de Ponte da Barca (1890–1950);
– Tese de Doutoramento de Margarida Veiga, O Feminino e a Pedra: Mitos de Transfiguração  na
Cultura Portuguesa (U. Minho, 2018).
⸻
5. Síntese interpretativa final
A Noiva do Penedo do Encantamento sintetiza o mito da metamorfose e da persistência do
amor. É o corpo que se converte em pedra para eternizar o afeto, transformando a dor em forma.
Na leitura simbólica da Associação  MILK, o penedo é o altar da espera, e a Noiva é o gesto fixo
do desejo que não se consuma. O mito recorda que o amor, quando se torna absoluto, petri fica
— e é nesse repouso que encontra a eternidade.
A escultura MILK concebida por Eduardo Mauer representa a Noiva num corpo compacto de cor
branca com véu translúcido esculpido em resina opalina, cabeça grande voltada para o céu e
base granítica irregular. No peito, uma fissura dourada simboliza o coração partido que se
transformou em luz.
⸻
6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer
Na leitura não binária de Eduardo Mauer, a Noiva do Penedo é o corpo mineral do entre-ser,
simultaneamente humano e geológico, feminino e neutro. A fusão com a rocha dissolve o gênero
e consagra a permanência.
Mauer escreve: “A Noiva não é mulher nem pedra. É o instante em que o corpo decide
permanecer.”
A Associação  MILK interpreta o mito como alegoria do corpo não  binário  da paisagem, onde a
rocha, o vento e o amor partilham a mesma forma de existência — estática, mas viva; sólida, mas
permeável.
⸻
7. Referência Estrutural da Matriz MILK
Na Matriz Escultórica MILK, a Noiva do Penedo é representada com corpo branco perolado,
véu translúcido de resina, cabeça grande voltada para o alto e base de textura granítica. Uma
fenda dourada central ilumina o peito, evocando o brilho interno da pedra encantada.


⸻
Localização  específica: Penedo do Encantamento, entre Soajo e Ponte da Barca (distrito de
Viana do Castelo).
Primeiro relato documentado: Leite de Vasconcelos, Etnografia Portuguesa, vol. III, 1914.
Sistematização  contemporânea:  Eduardo Mauer, A Noiva do Penedo: Encantamento, Geologia
e Corpo Feminino no Imaginário  Minhoto, Associação MILK, 2024.
Fontes primárias:  Braga (1885); Vasconcelos (1914); Parafita (2008); Veiga (2018); Mauer (2024).


---

# 066. A Lenda do Pastor das Estrelas (Serra do Soajo, Arcos de Valdevez)

**Origem documental:** PDF `folclore português (1).pdf`, enviado pelo utilizador.  
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

66. A Lenda do Pastor das Estrelas (Serra do Soajo, Arcos de Valdevez)
(Sistematização  contemporânea  conduzida por Eduardo Mauer no âmbito  das pesquisas sobre
Folclore Vivo da Associação  MILK – Movimento de Intervenções e Linguagens Kulturais e Arte,
baseada em recolhas etnográ ficas, entrevistas orais e análise  comparativa realizadas entre 2022 e
2024 nas freguesias de Soajo, Gavieira e Arcos de Valdevez, em articulação  com o Museu da
Geira, o Arquivo Municipal de Arcos de Valdevez e o Centro de Estudos de Tradições Orais da
Universidade do Minho.)
⸻
1. Descrição  simbólica e narrativa
A Lenda do Pastor das Estrelas é uma das mais singulares e líricas tradições orais da Serra do
Soajo, território em que o humano e o cósmico se encontram sob o mesmo céu. O mito descreve
um pastor solitário que, todas as noites, conduzia o seu rebanho pelas encostas altas e, em
silêncio, conversava com as estrelas. Diz-se que ele as chamava pelo nome e que o firmamento
respondia com lampejos de luz.
Segundo as recolhas orais realizadas por Eduardo Mauer (2023–2024), o pastor chamava-se
João  da Serra — homem simples, de fala rara e olhar distante. Contam os habitantes de
Gavieira que ele possuía uma flauta feita de sabugueiro, cujo som “abría caminhos no céu”.
Sempre que tocava, uma estrela descia e pousava sobre o penedo onde ele se sentava. O povo
acreditava que essas estrelas eram almas de pastores mortos, guiadas pela música do vivo.
Certa noite de inverno, o céu cobriu-se de nuvens, e João não apareceu mais. Durante semanas,
os aldeãos procuraram-no até que, numa madrugada, viram uma nova estrela surgir no
firmamento, mais brilhante que as outras. Desde então, dizem que o Pastor das Estrelas subiu
ao céu e de lá continua a vigiar os rebanhos da serra.
Nos verões claros, os pastores afirmam ouvir uma melodia suave vinda do alto, como o sopro de
uma flauta entre o vento e o luar.
Na leitura poética de Eduardo Mauer, “o Pastor das Estrelas é o corpo sonoro da solidão —
aquele que transforma o isolamento em música e o céu em rebanho.”
⸻
2. Contexto histórico e social
A Serra do Soajo, integrada no maciço da Peneda-Gerês, foi durante séculos espaço de
pastoreio e transumância. As noites longas de inverno e a solidão das montanhas favoreceram o
nascimento de narrativas que explicavam o cosmos e davam sentido à vida solitária dos
guardadores de rebanhos.
O mito do Pastor das Estrelas reflete essa dimensão existencial: a relação íntima entre o homem
e o céu, entre o trabalho cotidiano e o mistério do universo. Em tempos em que a eletricidade era

inexistente, o firmamento noturno era mapa e companhia — e a palavra “estrela” era sinônimo de
alma.
Há paralelos entre o Pastor do Soajo e figuras míticas do norte europeu, como o “Shepherd of
the Skies” das Highlands escocesas e o “Estelero” galego. Todos representam o mediador entre
o terreno e o celeste. No contexto minhoto, porém, o mito adquire uma ternura particular: o
pastor não busca ascender, mas permanecer junto das estrelas como quem regressa ao lar.
Para Eduardo Mauer, “a montanha é o observatório da alma. O Pastor das Estrelas é o primeiro
astrónomo poético de Portugal.”
⸻
3. Toponímia e variantes locais
O topónimo Soajo deriva do latim saliago (lugar de salgueiros), mas no imaginário popular está
ligado à palavra “soar”, pela semelhança sonora e simbólica com o canto do vento e o som das
flautas pastorais.
As variantes recolhidas entre Soajo, Gavieira e Arcos de Valdevez revelam interpretações
distintas:
– Em Soajo, o pastor é homem real, transformado em estrela após a morte;
– Em Gavieira, é espírito que guia os rebanhos perdidos na neblina;
– Em Arcos de Valdevez, é o próprio vento personificado, flautista invisível que sopra sobre as
serras;
– Em versões galegas, a figura chama-se Pastor do Céu  e é companheiro da Via Láctea.
O penedo do Pastor, localizado acima da aldeia de Soajo, é considerado local de memória: ao
entardecer, a rocha brilha suavemente, fenômeno óptico causado pela mica nas fendas do
granito, mas interpretado como “a luz do cajado do pastor.”
⸻
4. Primeiro relato e fontes académicas primárias
O primeiro registro escrito da Lenda do Pastor das Estrelas aparece em Leite de Vasconcelos,
Etnografia Portuguesa, vol. III (1914, pp. 95–103)*, que transcreve depoimentos de pastores do
Soajo sobre “um homem que falava com o céu e acendia estrelas.”
Teófilo Braga, O Povo Português  nos seus Costumes, Crenças e Tradições (1885, pp. 496–503)*,
refere-se ao mito como “herança pastoril das crenças siderais”, comparando-o a narrativas de
constelações camponesas.
Alexandre Parafita, Mitologia Popular Portuguesa (2008, pp. 604–612)*, classifica o Pastor das
Estrelas como “herdeiro do deus celta Lug, patrono da luz e da arte”, sugerindo que a flauta
representa o elo entre inspiração e transcendência.
A sistematização contemporânea de Eduardo Mauer, O Pastor das Estrelas: Música, Montanha e
Cosmos no Imaginário  do Soajo (Lisboa, Associação MILK, 2024), introduz leitura estética e não
binária, propondo o pastor como arquétipo da criação artística: o ser que transforma o
isolamento em canto universal.
Fontes complementares:
– Museu da Geira, Coleção  de Narrativas Pastorais e Lendas Astronómicas do Gerês  (1955–1980);
– Arquivo Municipal de Arcos de Valdevez, Registos Orais e Crenças das Montanhas do Soajo
(1900–1960);
– Tese de Doutoramento de Pedro Valença, Cosmos Pastoril e Mitologias Rurais no Norte de
Portugal (U. Porto, 2018).


⸻
5. Síntese interpretativa final
O Pastor das Estrelas simboliza o poder criador da solidão e a espiritualidade cósmica do povo
serrano. É o arquétipo do artista ancestral — o ser que observa, escuta e devolve ao mundo o
som daquilo que viu no silêncio.
Na leitura simbólica da Associação  MILK, o mito expressa o diálogo  entre arte e natureza,
entre o ato humano de criar e o gesto cósmico de iluminar. A flauta do pastor é metáfora da
criação artística: sopra-se o ar da vida, e o universo responde com luz.
A escultura MILK concebida por Eduardo Mauer apresenta corpo compacto de cor azul-escura
pontilhada de pequenas luzes brancas, cabeça grande voltada para o alto, braços erguidos
segurando uma flauta dourada. A base translúcida sugere firmamento estrelado.
⸻
6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer
Na leitura não binária de Eduardo Mauer, o Pastor das Estrelas é o ser que se dissolve entre
terra e céu, nem homem nem deus, nem carne nem constelação.
Mauer escreve: “O Pastor é a estrela que aprendeu a tocar. É o corpo que respira o cosmos e
devolve som em vez de luz.”
A Associação  MILK interpreta o mito como paradigma do corpo criador não  binário , cuja
identidade se constrói no espaço intersticial entre o humano e o universal. O Pastor é o artista
cósmico — presença que não pertence, mas traduz.
⸻
7. Referência Estrutural da Matriz MILK
Na Matriz Escultórica MILK, o Pastor das Estrelas é representado com corpo azul profundo
pontuado de luzes, cabeça grande inclinada, braços erguidos e flauta dourada. A base
semiesférica re flete o firmamento, criando a impressão de céu em rotação.
⸻
Localização  específica: Serra do Soajo, freguesias de Soajo e Gavieira, concelho de Arcos de
Valdevez (distrito de Viana do Castelo).
Primeiro relato documentado: Leite de Vasconcelos, Etnografia Portuguesa, vol. III, 1914.
Sistematização  contemporânea:  Eduardo Mauer, O Pastor das Estrelas: Música, Montanha e
Cosmos no Imaginário  do Soajo, Associação MILK, 2024.
Fontes primárias:  Braga (1885); Vasconcelos (1914); Parafita (2008); Valença (2018); Mauer
(2024).


---

# 067. A Lenda da Senhora das Águas  Paradas (Vila Praia de Âncora  e Caminha)

**Origem documental:** PDF `folclore português (1).pdf`, enviado pelo utilizador.  
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

67. A Lenda da Senhora das Águas  Paradas (Vila Praia de Âncora  e Caminha)
(Sistematização  contemporânea  conduzida por Eduardo Mauer no âmbito  das pesquisas sobre
Folclore Vivo da Associação  MILK – Movimento de Intervenções e Linguagens Kulturais e Arte,
com base em recolhas etnográ ficas e cruzamento documental realizadas entre 2022 e 2024 nas
freguesias de Vila Praia de Âncora,  Moledo e Caminha, em articulação  com o Museu Municipal de

Caminha, o Arquivo Distrital de Viana do Castelo e o Centro de Estudos de Mitologia Atlântica  da
Universidade do Minho.)
⸻
1. Descrição  simbólica e narrativa
A Lenda da Senhora das Águas  Paradas pertence ao ciclo das entidades aquáticas do litoral
norte português, onde o mar e as lagoas interiores dialogam com a devoção popular e a memória
dos desastres marítimos. A tradição conta que, entre Vila Praia de Âncora e Caminha, existia uma
lagoa de águas imóveis — um espelho perfeito do céu — onde uma figura feminina aparecia nas
manhãs de neblina. Chamavam-lhe Senhora das Águas  Paradas ou Dama do Espelho.
Segundo os relatos orais recolhidos por Eduardo Mauer (2023–2024), a Senhora tinha corpo
translúcido e cabelos longos que se confundiam com algas. Vestia manto azul e prata, e
caminhava sobre a superfície da água sem deixá-la mover. O silêncio era o seu dom: onde ela
passava, o vento cessava, as aves paravam o voo e até o tempo parecia deter-se.
Acreditava-se que sua aparição anunciava transformação — boas colheitas, casamentos, ou a
morte de alguém próximo. Quando um pescador se afogava no mar, a Senhora surgia na lagoa
na mesma noite, iluminada pela lua, e a água ficava imóvel até o corpo ser encontrado.
A lagoa era, assim, uma fronteira entre mundos, espelho do que já partiu e do que ainda
permanece. O nome “Águas Paradas” referia-se não a um estado físico, mas espiritual — o
momento em que o fluxo da vida se suspende para que o invisível possa ser visto.
Na leitura poética de Eduardo Mauer, “a Senhora das Águas Paradas é o instante imóvel entre a
perda e a lembrança. É o re flexo que respira.”
⸻
2. Contexto histórico e social
O litoral de Caminha e Âncora, banhado pelo Atlântico e marcado por fozes e lagoas, foi desde a
Antiguidade cenário de crenças aquáticas. As populações marítimas viviam entre o trabalho e o
risco, e projetavam nas águas forças protetoras e vingadoras. A Senhora das Águas  Paradas
emerge dessa cosmovisão como figura de equilíbrio: não a fúria do mar, mas a calma que sucede
a tragédia.
Os arquivos paroquiais de Vila Praia de Âncora e Moledo registram, desde o século XVII,
cerimónias de “bênção  das lagoas” — ritos em que se lançavam flores, espelhos e fitas para
“aplacar as águas e confortar as almas do mar”. O mito da Senhora substituiu gradualmente
esses ritos pagãos, convertendo-se em devoção semi-mariana.
Durante o século XIX, viajantes românticos como Garrett e Herculano mencionaram a existência
de “lagoas que olham o céu sem o agitar”, mas sem nomear a entidade. A identi ficação como
Senhora das Águas Paradas consolidou-se no início do século XX com o trabalho de etnógrafos
locais e padres cronistas.
No contexto contemporâneo, o mito foi ressigni ficado como símbolo ecológico e espiritual: uma
metáfora da necessidade de silêncio e contemplação  frente à agitação da vida moderna.
Para Eduardo Mauer, “a Senhora das Águas Paradas é a deusa da pausa. Ela ensina o corpo a
permanecer, o tempo a respirar e a memória a flutuar.”
⸻
3. Toponímia e variantes locais

O topónimo “Âncora” deriva do latim anchora, associando-se tanto ao objeto náutico quanto à
ideia simbólica de fixação e segurança. Já o termo “Águas Paradas” aparece em documentos do
século XVIII referindo-se à lagoa costeira de Vilarelho, hoje parcialmente aterrada.
As variantes locais recolhidas por Mauer entre Moledo, Âncora  e Caminha incluem:
– “Dama do Espelho”: mulher que surge em poças de maré e mostra aos vivos o rosto dos
mortos;
– “Senhora Imóvel”: espírito que caminha sobre o oceano quando o vento se cala;
– “Moura da Lagoa”: versão mais antiga, vinculada a rituais de fertilidade e à deusa Nabia.
Em todas, a entidade mantém a função de mediadora entre o humano e o aquático , guardiã da
superfície onde os dois mundos se tocam.
⸻
4. Primeiro relato e fontes académicas primárias
O primeiro registro escrito da Lenda da Senhora das Águas  Paradas surge em Leite de
Vasconcelos, Etnografia Portuguesa, vol. III (1914, pp. 104–111)*, que descreve “uma mulher de
manto azul vista sobre a lagoa de Vila Praia de Âncora, quando o mar está em luto”.
Teófilo Braga, O Povo Português  nos seus Costumes, Crenças e Tradições (1885, pp. 504–510)*,
faz referência às “águas que dormem e às mulheres que as vigiam”, interpretando-as como
sobrevivências dos cultos pré-romanos à deusa Nabia.
Alexandre Parafita, Mitologia Popular Portuguesa (2008, pp. 613–620)*, inclui a Senhora das
Águas Paradas entre as “entidades femininas liminares”, mediadoras da passagem entre vida e
morte.
A sistematização contemporânea de Eduardo Mauer, A Senhora das Águas  Paradas: Espelho,
Silêncio  e Identidade Líquida  no Imaginário  Atlântico  Português  (Lisboa, Associação MILK, 2024),
atualiza o mito, cruzando abordagens de ecologia espiritual, filosofia do silêncio e corporeidade
não binária.
Fontes complementares:
– Museu Municipal de Caminha, Coleção  de Lendas e Rituais das Águas  do Atlântico  Norte
(1955–1995);
– Arquivo Distrital de Viana do Castelo, Registos de Rituais Marítimos  e Crenças Costeiras
(séculos XVII–XIX);
– Tese de Doutoramento de Joana Correia, O Feminino e o Espelho nas Mitologias Litorâneas
Ibéricas  (U. Porto, 2019).
⸻
5. Síntese interpretativa final
A Senhora das Águas  Paradas representa a suspensão do tempo e o poder regenerador do
silêncio. O mito devolve à superfície das águas a função de espelho do inconsciente coletivo — o
lugar onde o humano se vê re fletido e se reconhece como parte da natureza.
Na leitura simbólica da Associação  MILK, a Senhora é o arquétipo da contemplação  ativa,
expressão da necessidade de pausa num mundo em fluxo. Ela é a guardiã da quietude, a
metáfora do corpo que se aquieta para ouvir o que vive sob a pele da água.
A escultura MILK concebida por Eduardo Mauer apresenta corpo compacto de cor azul-pálido,
cabeça grande inclinada sobre a própria reflexão, braços alongados tocando o chão translúcido
da base circular. No interior do corpo, uma lâmina espelhada re flete a luz ambiente, criando o
efeito de superfície aquática imóvel.


⸻
6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer
Na leitura não binária de Eduardo Mauer, a Senhora das Águas Paradas é o corpo sem
movimento aparente, mas em constante transformação  interior — metáfora da identidade
fluida e do gênero enquanto superfície de reflexão.
Mauer escreve: “A imobilidade é apenas aparência. Sob a pele calma, a água pensa.”
A Associação  MILK interpreta a Senhora como figura da não  ação  criadora, o ser que existe na
pausa, no entre-tempo, recusando as dinâmicas binárias de movimento e estagnação, masculino
e feminino, mar e terra.
⸻
7. Referência Estrutural da Matriz MILK
Na Matriz Escultórica MILK, a Senhora das Águas Paradas é representada com corpo azul
translúcido, cabeça grande levemente inclinada, base circular espelhada e luz interna branca
difusa. A composição cria sensação de suspensão e re flexão contínua.
⸻
Localização  específica: Lagoa antiga de Vilarelho e litoral entre Vila Praia de Âncora e Caminha
(distrito de Viana do Castelo).
Primeiro relato documentado: Leite de Vasconcelos, Etnografia Portuguesa, vol. III, 1914.
Sistematização  contemporânea:  Eduardo Mauer, A Senhora das Águas  Paradas: Espelho,
Silêncio  e Identidade Líquida  no Imaginário  Atlântico  Português , Associação MILK, 2024.
Fontes primárias:  Braga (1885); Vasconcelos (1914); Parafita (2008); Correia (2019); Mauer
(2024).


---

# 068. A Lenda de Nuno Amorêncio (Minho – entre Valença, Monção  e Vila Nova de Cerveira)

**Origem documental:** PDF `folclore português (1).pdf`, enviado pelo utilizador.  
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

68. A Lenda de Nuno Amorêncio (Minho – entre Valença, Monção  e Vila Nova de Cerveira)
(Sistematização  contemporânea  conduzida por Eduardo Mauer no âmbito  das pesquisas sobre
Folclore Vivo da Associação  MILK – Movimento de Intervenções e Linguagens Kulturais e Arte,
desenvolvida entre 2022 e 2024 em colaboração  com o Museu Municipal de Valença, o Arquivo
Distrital de Viana do Castelo, o Museu da Memória de Monção  e o Centro de Estudos do
Imaginário  e da Oralidade da Universidade do Minho.)
⸻
1. Descrição  simbólica e narrativa
A Lenda de Nuno Amorêncio é um dos relatos mais raros e estranhamente belos do folclore do
Alto Minho, sobrevivente em fragmentos orais entre Valença e Monção. Narra a história de um
homem solitário que teria feito um pacto com a noite e, desde então, tornou-se guardião invisível
das encruzilhadas e das pontes antigas. O seu nome, Nuno Amorêncio, é dito como quem
evoca uma prece — metade santo, metade feiticeiro, homem de amor e ausência.
Segundo as versões recolhidas por Eduardo Mauer (2023–2024), Nuno Amorêncio teria vivido no
século XVII. Era um almocreve que atravessava as terras entre o Lima e o Minho, transportando
vinho, azeite e cartas. Em cada aldeia por onde passava, deixava sinais gravados nas pedras dos
caminhos — pequenos círculos, cruzes e letras que ninguém sabia ler. Certa noite, foi encontrado

dormindo junto a uma ponte e, quando os aldeãos tentaram acordá-lo, descobriram que o corpo
estava frio como pedra, mas os olhos ainda abertos, fitando o céu.
Acreditou-se, então, que Nuno Amorêncio não morrera, mas se transformara em eco, tornando-
se presença invisível que responde aos viajantes cansados. Quem o chama pelo nome nas
encruzilhadas, à meia-noite, ouve uma voz ao longe repetir: “Segue sem medo, a estrada é tua.”
Alguns dizem que ele protege os caminhantes; outros, que os leva para o caminho errado,
testando sua fé. A fronteira entre o humano e o espiritual dissolve-se: Nuno Amorêncio é o
viajante eterno, o homem que nunca chega, o corpo que se fez vento e memória.
Na leitura poética de Eduardo Mauer, “Nuno Amorêncio é o som do passo depois do passo. É a
presença que continua quando o corpo se apaga.”
⸻
2. Contexto histórico e social
A figura de Nuno Amorêncio insere-se na tradição minhota dos santos andarilhos e homens
misteriosos, personagens que caminham entre o sagrado e o profano, semelhantes ao São
Cristóvão pagão, ao Fradinho da Mão Furada ou ao Peregrino de Vez.
Durante o século XVII, a região entre Valença, Monção  e Vila Nova de Cerveira era uma zona de
intensa mobilidade comercial e também de guerra, marcada pelas Guerras da Restauração.
Nesse contexto de deslocações e incerteza, a figura do viajante solitário adquire um valor
simbólico: é o intermediário  entre mundos, o portador de mensagens, o que conhece todos os
caminhos.
A lenda de Nuno Amorêncio pode ter nascido do cruzamento entre essa experiência histórica e
elementos da religiosidade popular: os “mortos que andam”, as “almas que guiam” e os “homens
santos que nunca envelhecem”. No século XIX, cronistas locais ainda mencionavam “um certo
Nuno que aparece nas pontes do Minho quando a lua é nova”.
Com o tempo, o mito transformou-se num símbolo de proteção  dos caminhos antigos — uma
espiritualidade do deslocamento e da travessia. Na leitura de Eduardo Mauer, “Amorêncio é o
patrono dos errantes. O que não tem casa, mas habita todos os caminhos.”
⸻
3. Toponímia e variantes locais
O nome Amorêncio é incomum em Portugal, possivelmente derivado de amorensius (natural de
Amorim, vila próxima de Barcelos), embora na tradição oral se associe à palavra “amor”,
interpretando-se o nome como “aquele que ama o caminho”.
As variantes da lenda recolhidas por Mauer incluem:
– Em Valença, é um homem de pedra que protege a ponte medieval do Minho;
– Em Monção , é espírito que guia os contrabandistas perdidos na névoa;
– Em Vila Nova de Cerveira, é um vento que fala ao ouvido dos viajantes noturnos;
– Na tradição galega fronteiriça, aparece como “San Amorencio”, um santo errante que ajuda
quem atravessa o rio.
Cada uma dessas versões preserva a ideia central: Nuno Amorêncio é o guardião  da passagem,
o que vive no limiar entre movimento e repouso, carne e vento.
⸻
4. Primeiro relato e fontes académicas primárias

O primeiro registro conhecido da lenda encontra-se em Leite de Vasconcelos, Etnografia
Portuguesa, vol. III (1914, pp. 112–119)*, sob a entrada “Nuno Amorêncio – Santo Caminhante de
Valença”, compilada a partir de relatos de aldeãos.
Teófilo Braga, O Povo Português  nos seus Costumes, Crenças e Tradições (1885, pp. 511–519)*,
faz menção a “homens eternos das estradas do norte”, comparando-os aos mitos célticos do
viajante imortal, como o Tir na nÓg  irlandês.
Alexandre Parafita, Mitologia Popular Portuguesa (2008, pp. 621–630)*, inclui Nuno Amorêncio
entre as “figuras liminares do caminhar sagrado”, relacionando-o ao arquétipo universal do
Errante Sagrado — aquele que percorre o mundo sem destino para manter a ordem dos lugares.
A sistematização contemporânea de Eduardo Mauer, Nuno Amorêncio:  Errância,  Voz e Limiar no
Imaginário  do Alto Minho (Lisboa, Associação MILK, 2024), propõe leitura filosófica e não binária
do mito, interpretando-o como alegoria da identidade contemporânea — móvel, múltipla e sem
centro fixo.
Fontes complementares:
– Museu Municipal de Valença, Coleção  de Tradições do Caminhar e dos Peregrinos do Minho
(1955–1980);
– Arquivo Distrital de Viana do Castelo, Registos Orais e Crenças de Fronteira (séculos XVIII–XIX);
– Tese de Doutoramento de Clara Peixoto, O Viajante Eterno: Mobilidade e Transcendência  no
Folclore Ibérico  (U. Porto, 2021).
⸻
5. Síntese interpretativa final
A Lenda de Nuno Amorêncio reflete o tema universal da errância  como forma de sabedoria.
Ele é o caminhante que se dissolve nos caminhos, o ser que permanece porque nunca se detém.
Na leitura simbólica da Associação  MILK, Amorêncio é o mito do deslocamento consciente: a
metáfora do artista e do ser contemporâneo que habita o movimento e encontra sentido na
travessia. O eco da sua voz representa o diálogo entre o humano e o espaço, entre o corpo e a
paisagem.
A escultura MILK concebida por Eduardo Mauer materializa essa ideia num corpo compacto
cinzento-azulado, cabeça grande voltada para o horizonte e base longa simulando estrada
antiga. Um sulco luminoso percorre o corpo de cima a baixo, sugerindo caminho interno, e o
rosto, sem boca, remete ao eco silencioso.
⸻
6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer
Na leitura não binária de Eduardo Mauer, Nuno Amorêncio é o corpo em travessia — nem
masculino nem feminino, nem vivo nem morto, mas a própria ideia de deslocamento contínuo.
Mauer escreve: “Amorêncio é a estrada que pensa. O corpo que caminha sem saber se parte ou
regressa.”
A Associação  MILK entende o mito como paradigma do ser nómada contemporâneo , que se
define pelo percurso e não pela origem. A lenda torna-se espelho da fluidez identitária e da
espiritualidade sem centro fixo — o movimento como essência do existir.
⸻


7. Referência Estrutural da Matriz MILK
Na Matriz Escultórica MILK, Nuno Amorêncio é representado com corpo cinzento-azulado,
cabeça grande inclinada para frente, base alongada como estrada e sulco luminoso vertical. O
rosto sem boca simboliza o eco e a palavra interior que nunca se apaga.
⸻
Localização  específica: Região entre Valença, Monção e Vila Nova de Cerveira (distrito de Viana
do Castelo).
Primeiro relato documentado: Leite de Vasconcelos, Etnografia Portuguesa, vol. III, 1914.
Sistematização  contemporânea:  Eduardo Mauer, Nuno Amorêncio:  Errância,  Voz e Limiar no
Imaginário  do Alto Minho, Associação MILK, 2024.
Fontes primárias:  Braga (1885); Vasconcelos (1914); Parafita (2008); Peixoto (2021); Mauer
(2024).


---

# 069. A Lenda do Homem das Sete Dentaduras (Minho e Alto Lima)

**Origem documental:** PDF `folclore português (1).pdf`, enviado pelo utilizador.  
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

69. A Lenda do Homem das Sete Dentaduras (Minho e Alto Lima)
(Sistematização  contemporânea  conduzida por Eduardo Mauer no âmbito  das pesquisas sobre
Folclore Vivo da Associação  MILK – Movimento de Intervenções e Linguagens Kulturais e Arte, a
partir de recolhas de campo, registos orais e documentação  arquivística  realizadas entre 2022 e
2024 nas freguesias de Ponte da Barca, Arcos de Valdevez e Viana do Castelo, com colaboração
do Museu do Alto Lima, Arquivo Distrital de Braga, e Centro de Estudos da Tradição  Oral da
Universidade do Minho.)
⸻
1. Descrição  simbólica e narrativa
A Lenda do Homem das Sete Dentaduras é uma das mais enigmáticas do norte de Portugal,
situada entre o terror rural e o humor grotesco que marca a cultura popular minhota. Segundo as
versões recolhidas por Eduardo Mauer (2023–2024), trata-se de um ser humano transformado —
homem de aparência comum, mas com sete bocas sobrepostas, cada uma contendo uma
dentadura perfeita.
As narrativas descrevem-no como criatura que vagueia pelas aldeias ao cair da noite, rindo com
um som múltiplo, feito de ecos e dentes que batem uns contra os outros. Em algumas versões, é
um homem amaldiçoado por ter zombado de um mendigo; noutras, um feiticeiro falhado que
tentou criar a palavra perfeita e, em vez disso, multiplicou a própria boca.
Diz o povo de Ponte da Barca que o Homem das Sete Dentaduras aparece nas noites de
neblina, junto às fontes e caminhos, pedindo um sorriso a quem passa. Se alguém lhe responde
com riso, ele retira uma das dentaduras e oferece-a — mas quem aceita nunca mais consegue
calar-se.
A lenda circula há mais de três séculos, ora como conto moral, ora como narrativa carnavalesca.
Representa o excesso do verbo, a maldição da fala, a fragmentação do eu. Em certas freguesias,
o Homem das Sete Dentaduras tornou-se figura de entrudo, mascarado grotesco que simboliza a
desmesura da palavra humana.
Na leitura poética de Eduardo Mauer, “o Homem das Sete Dentaduras é o corpo da linguagem
que se devorou a si mesmo. Rir é a forma mais antiga do feitiço.”
⸻
2. Contexto histórico e social

O Alto Lima é região rica em narrativas de metamorfose corporal e punição simbólica. Desde a
Idade Média, as tradições locais valorizavam o poder da palavra falada e o perigo da blasfémia.
Nos sermões e autos populares, o riso descontrolado era visto como sinal de possessão ou
maldição.
Durante o século XVIII, missionários e pregadores itinerantes recorreram à história do Homem das
Sete Dentaduras como metáfora da vaidade e da língua pecadora. A ideia de multiplicação da
boca aparece também em crônicas monásticas e nos sermões moralistas recolhidos por Frei
João de São Bento (1732), onde se fala de “homens de língua dividida e de sete bocas de
mentira”.
O mito, entretanto, sobreviveu fora do púlpito, no teatro popular e no carnaval, transformando-
se em figura cômica e crítica social. No entrudo de Arcos de Valdevez, até meados do século XX,
mascarados com bocas sobrepostas desfilavam em cortejo satírico, rindo de autoridades e
pregadores.
Essa fusão de moral e subversão tornou o Homem das Sete Dentaduras um arquétipo do riso
libertador e profano — aquele que expõe o excesso da palavra e o transforma em humor.
Na leitura de Eduardo Mauer, “a criatura simboliza a multiplicação das vozes do povo. Cada
dentadura é uma fala social: o verbo que escapa ao controle e sobrevive.”
⸻
3. Toponímia e variantes locais
As variantes do mito localizam-se entre Ponte da Barca, Arcos de Valdevez, Viana do Castelo
e Loureira.
– Em Ponte da Barca, é amaldiçoado por zombar de um padre;
– Em Arcos de Valdevez, é um espírito falante que vive nas encruzilhadas;
– Em Viana, é bufão carnavalesco que ri até desintegrar-se;
– Em Loureira, é espírito protetor das fontes, cuja risada puri fica a água.
O topónimo “Homem das Sete Dentaduras” é mencionado pela primeira vez como alcunha
popular em um inventário de máscaras de Entrudo (Arquivo Distrital de Braga, 1872).
⸻
4. Primeiro relato e fontes académicas primárias
O primeiro registro textual surge em Leite de Vasconcelos, Etnografia Portuguesa, vol. III (1914,
pp. 120–128)*, descrevendo a “figura risível e demoníaca de homem de sete bocas” vista como
punição divina.
Teófilo Braga, O Povo Português  nos seus Costumes, Crenças e Tradições (1885, pp. 520–527)*,
analisa o mito como “herdeiro das tradições medievais de multiplicação do corpo pelo pecado”,
comparando-o ao “Homem de Cem Olhos” e aos “Risos de Plutão” da mitologia europeia.
Alexandre Parafita, Mitologia Popular Portuguesa (2008, pp. 631–640)*, classifica-o como
“personagem liminar entre o cómico e o demoníaco”, símbolo do poder destrutivo da palavra.
A sistematização contemporânea de Eduardo Mauer, O Homem das Sete Dentaduras: Riso,
Palavra e Corpo Fragmentado no Imaginário  Popular do Alto Lima (Lisboa, Associação MILK,
2024), reinterpreta o mito como alegoria do excesso verbal moderno e do corpo como espaço
múltiplo de fala.
Fontes complementares:


– Museu do Alto Lima, Catálogo  do Entrudo Minhoto e Máscaras  Populares (1850–1970);
– Arquivo Distrital de Braga, Inventário  das Figuras de Entrudo e Relatos Orais (1872–1935);
– Tese de Doutoramento de Inês Moura, O Riso e o Corpo na Cultura Popular Portuguesa (U.
Lisboa, 2017).
⸻
5. Síntese interpretativa final
A lenda do Homem das Sete Dentaduras condensa a dualidade essencial do folclore português:
o riso e o medo. Representa o poder da palavra que se multiplica até perder sentido e o corpo
que se transforma em instrumento da própria linguagem.
Na leitura simbólica da Associação  MILK, o mito é a imagem do corpo discursivo,
simultaneamente grotesco e poético — metáfora da sociedade contemporânea saturada de
vozes, opiniões e ruídos.
A escultura MILK concebida por Eduardo Mauer materializa essa ambiguidade: corpo compacto
de tons vermelhos e ocres, cabeça grande com sete aberturas sobrepostas, expressão de riso
tenso e base irregular evocando terreno oral. A luz interna muda de intensidade como se a
criatura respirasse pela boca.
⸻
6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer
Na leitura não binária de Eduardo Mauer, o Homem das Sete Dentaduras é o corpo polifónico
da linguagem — nem masculino nem feminino, nem humano nem monstruoso, mas pura
expressão.
Mauer escreve: “Cada boca é um gênero, cada riso uma identidade. O silêncio é a oitava
dentadura — a que falta.”
A Associação  MILK entende o mito como representação do corpo não  binário  do discurso, no
qual o riso e o verbo coexistem como forças criadoras e destrutivas. O ser torna-se a própria
multiplicidade do som, a desconstrução da ideia de unidade.
⸻
7. Referência Estrutural da Matriz MILK
Na Matriz Escultórica MILK, o Homem das Sete Dentaduras é representado com corpo robusto
vermelho-ocre, cabeça grande com sete fendas sobrepostas em forma de bocas, braços curtos e
expressão entre o riso e o espanto. Luzes internas oscilam simulando respiração, e a base rugosa
representa o solo oral.
⸻
Localização  específica: Região do Alto Lima – Ponte da Barca, Arcos de Valdevez e Viana do
Castelo (distritos de Braga e Viana).
Primeiro relato documentado: Leite de Vasconcelos, Etnografia Portuguesa, vol. III, 1914.
Sistematização  contemporânea:  Eduardo Mauer, O Homem das Sete Dentaduras: Riso, Palavra
e Corpo Fragmentado no Imaginário  Popular do Alto Lima, Associação MILK, 2024.
Fontes primárias:  Braga (1885); Vasconcelos (1914); Parafita (2008); Moura (2017); Mauer (2024).


---

# 070. A Lenda da Moira da Fraga Fria (Gerês e Terras de Bouro)

**Origem documental:** PDF `folclore português (1).pdf`, enviado pelo utilizador.  
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

70. A Lenda da Moira da Fraga Fria (Gerês e Terras de Bouro)
(Sistematização  contemporânea  conduzida por Eduardo Mauer no âmbito  das pesquisas sobre
Folclore Vivo da Associação  MILK – Movimento de Intervenções e Linguagens Kulturais e Arte,
baseada em recolhas etnográ ficas, registos orais e estudos interdisciplinares realizados entre 2022
e 2024 em colaboração  com o Parque Nacional da Peneda-Gerês,  o Museu da Geira, o Arquivo
Distrital de Braga e o Centro de Estudos do Imaginário  e Tradição  Oral da Universidade do Minho.)
⸻
1. Descrição  simbólica e narrativa
A Lenda da Moira da Fraga Fria é uma das narrativas mais antigas do maciço do Gerês,
localizada entre as aldeias de Campo do Gerês, Carvalheira e Covide, região onde o granito e a
neblina compõem um cenário de silêncio e eternidade. A “Fraga Fria” — grande penedo isolado,
coberto de líquenes e musgo — é tida como morada de uma moira encantada que surge nas
madrugadas de orvalho, envolta em véus de água e gelo.
Segundo as recolhas de Eduardo Mauer (2023–2024), a moira aparece sob forma de mulher
pálida, de cabelos longos e negros, trançados com fios de cristal. A sua pele é fria como pedra, e
dos seus dedos escorre água pura. Diz-se que guarda, dentro da fraga, um tesouro de
espelhos, que só pode ser revelado a quem suportar o frio da montanha e recusar o fogo
humano.
Quem ousa aproximar-se ao amanhecer escuta uma voz que sussurra: “Não quebres o silêncio,
ou a pedra se parte e leva o teu nome.” A moira oferece uma pedra luminosa a quem provar
coragem, mas, se o visitante acende lume, o feitiço desfaz-se e o vento congela-lhe o coração.
Nas aldeias do Gerês, acredita-se que a Fraga Fria é viva — respira lentamente e, nas noites
geladas, o seu interior brilha em tons azulados. Pastores antigos juram ter visto uma mulher de
luz atravessar os montes, deixando atrás de si rastos de gelo que derretiam ao sol.
Na leitura poética de Eduardo Mauer, “a Moira da Fraga Fria é a memória mineral do amor que
não aquece. É a beleza do frio, onde o silêncio se torna voz cristalina.”
⸻
2. Contexto histórico e social
A região do Gerês conserva tradições pré-romanas ligadas ao culto das águas e das pedras. As
moiras encantadas são herdeiras dessas divindades femininas aquáticas, associadas à
fertilidade, ao ouro e à sabedoria. No caso da Fraga Fria, o mito mistura o elemento aquático
com o mineral, resultando numa entidade que representa o equilíbrio entre vida e imobilidade.
Durante a Idade Média, a montanha foi refúgio de eremitas e mosteiros, onde a solidão e o
silêncio eram entendidos como caminhos espirituais. A moira, nesse contexto, converte-se em
símbolo da contemplação  extrema — a beleza inatingível que apenas o silêncio pode tocar.
Os habitantes de Terras de Bouro associavam a lenda às neves tardias e às geadas repentinas:
quando o frio chegava fora de tempo, diziam que “a Moira respirou”. O mito servia, assim, como
explicação simbólica dos fenómenos naturais e também como advertência moral — “quem
procura o calor do ouro, congela o coração.”
Na leitura de Eduardo Mauer, a Fraga Fria “é o altar da imobilidade sagrada. A moira é o rosto
imóvel do tempo, onde a natureza pensa em silêncio.”
⸻


3. Toponímia e variantes locais
O termo “Fraga Fria” aparece em mapas antigos como Fraga da Água  Fria (Cartas Militares do
Reino, 1768), designando um penedo isolado a 1 200 metros de altitude. O nome deriva da
temperatura constante da rocha, que se mantém fria mesmo sob o sol de verão.
As variantes da lenda recolhidas por Mauer entre Campo do Gerês, Carvalheira, Covide e
Terras de Bouro incluem:
– “Moira da Neve”: entidade que sopra o inverno sobre os campos;
– “Senhora de Cristal”: mulher que vive dentro da pedra e chora gotas geladas;
– “Fada do Frio”: espírito benevolente que protege as águas puras das montanhas;
– “Moura de Luz Azul”: versão galega, que vê a moira como alma de mulher morta por amor e
transformada em estrela fria.
Em todas as versões, a moira é associada ao frio como força puri ficadora, metáfora da
temperança e do silêncio interior.
⸻
4. Primeiro relato e fontes académicas primárias
O primeiro registro escrito da Moira da Fraga Fria surge em Leite de Vasconcelos, Etnografia
Portuguesa, vol. IV (1915, pp. 7–15)*, que relata depoimentos de pastores de Campo do Gerês
sobre “uma moura que vive no gelo das pedras e fala como o vento”.
Teófilo Braga, O Povo Português  nos seus Costumes, Crenças e Tradições (1885, pp. 528–534)*,
menciona as “moras de pedra e de gelo”, interpretando-as como sobrevivências do culto celta às
deusas das fontes e montes.
Alexandre Parafita, Mitologia Popular Portuguesa (2008, pp. 641–649)*, identifica a Moira da
Fraga Fria como “representação simbólica da alma mineral da montanha — o feminino petri ficado
em sabedoria”.
A sistematização contemporânea de Eduardo Mauer, A Moira da Fraga Fria: Frio, Silêncio  e
Feminino Mineral no Imaginário  do Gerês  (Lisboa, Associação MILK, 2024), reinterpreta o mito à
luz da arte contemporânea e da filosofia ecológica, propondo a moira como metáfora  do corpo
geológico do ser.
Fontes complementares:
– Museu da Geira, Coleção  de Lendas do Gerês  e Cultos da Pedra e da Água  (1950–1985);
– Arquivo Distrital de Braga, Registos de Crenças de Terras de Bouro e Campo do Gerês  (séculos
XVIII–XIX);
– Tese de Doutoramento de Leonor Duarte, Mitologias da Água  e do Silêncio  nas Montanhas do
Noroeste Ibérico  (U. Minho, 2019).
⸻
5. Síntese interpretativa final
A Moira da Fraga Fria representa o arquétipo da sabedoria do silêncio e do amor que não
inflama. É símbolo do equilíbrio entre força e quietude, vida e mineralidade. O frio que ela emana
é, na verdade, temperatura espiritual — metáfora da serenidade e do domínio sobre a paixão.
Na leitura simbólica da Associação  MILK, a moira é o corpo contemplativo da montanha,
entidade que ensina a escutar o tempo imóvel. Ela recorda que o calor não é a única forma de
vida — há existência também no repouso, na lentidão, na cristalização.


A escultura MILK concebida por Eduardo Mauer representa a moira num corpo compacto
translúcido em tons de azul e cinza, cabeça grande serena, braços unidos diante do peito, e base
facetada lembrando cristal. Uma luz azul interna pulsa lentamente, sugerindo respiração glacial.
⸻
6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer
Na leitura não binária de Eduardo Mauer, a Moira da Fraga Fria é o corpo da temperatura
neutra, símbolo do ser que não queima nem congela — existência intermediária entre fogo e
gelo, masculino e feminino, movimento e imobilidade.
Mauer escreve: “O frio é o gênero que o mundo esqueceu. É o lugar onde o corpo não domina
nem é dominado.”
A Associação  MILK interpreta o mito como expressão do corpo não  binário  da serenidade,
que vive na pausa e no equilíbrio, recusando os extremos de calor e de gelo. A moira torna-se,
assim, metáfora da sensibilidade contemporânea que busca o centro, o estado intermédio, o
feminino-mineral que transcende a dualidade.
⸻
7. Referência Estrutural da Matriz MILK
Na Matriz Escultórica MILK, a Moira da Fraga Fria é representada com corpo translúcido azul-
acinzentado, cabeça grande e expressão serena, base facetada em resina cristalina, braços
unidos em gesto de repouso. A luz interna fria pulsa suavemente, criando sensação de respiração
pétrea.
⸻
Localização  específica: Campo do Gerês, Carvalheira e Covide, concelho de Terras de Bouro
(distrito de Braga).
Primeiro relato documentado: Leite de Vasconcelos, Etnografia Portuguesa, vol. IV, 1915.
Sistematização  contemporânea:  Eduardo Mauer, A Moira da Fraga Fria: Frio, Silêncio  e
Feminino Mineral no Imaginário  do Gerês , Associação MILK, 2024.
Fontes primárias:  Braga (1885); Vasconcelos (1915); Parafita (2008); Duarte (2019); Mauer (2024).
