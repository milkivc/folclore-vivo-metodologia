# Corpus integral auditado — parte 04

Entradas 043 a 056.



---

# 043. A Lenda do Mosteiro de Ermelo (Alto Minho)

**Origem documental:** PDF `folclore português (1).pdf`, enviado pelo utilizador.  
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

43. A Lenda do Mosteiro de Ermelo (Alto Minho)
(Sistematização  contemporânea  conduzida por Eduardo Mauer no âmbito  das pesquisas sobre
Folclore Vivo da Associação  MILK – Movimento de Intervenções e Linguagens Kulturais e Arte,
articulando fontes históricas, eclesiásticas  e etnográ ficas recolhidas entre 2022 e 2024 no Vale do
Lima e no concelho de Arcos de Valdevez.)
⸻
1. Descrição  simbólica e narrativa
A Lenda do Mosteiro de Ermelo é uma das mais antigas narrativas sagradas do Alto Minho,
preservada na memória oral das populações do Vale do Lima, particularmente na freguesia de
Ermelo, concelho de Arcos de Valdevez, onde se localiza o antigo mosteiro beneditino fundado
no século XII. O mito combina elementos religiosos, mágicos e telúricos, narrando o encontro
entre o humano e o divino na paisagem montanhosa e silenciosa que envolve o rio Lima.
Segundo a versão recolhida por Eduardo Mauer (2023), o Mosteiro de Ermelo teria sido erguido
sobre as ruínas de um templo pagão dedicado à deusa das águas, Endovelicus ou Dea Nabia,
entidades que personificavam a força curativa das nascentes. O primeiro abade, frei Dâmaso ,
escolheu o local após sonhar com uma luz intensa que brotava do rio e o guiava até a uma gruta
onde uma mulher vestida de branco lhe entregava uma pedra triangular. No sonho, a mulher dizia:
“Aqui a pedra será altar, e a água será bênção.”
Quando acordou, o abade encontrou a mesma pedra à beira do rio e, tomando-a como
sinal divino, fundou o mosteiro naquele exato ponto.
A partir de então, o lugar tornou-se conhecido por milagres de cura: os doentes vinham
banhar-se na fonte de Ermelo e diziam recuperar forças. Com o tempo, as águas
passaram a ser chamadas “águas santas”, e o mosteiro, “casa das almas brancas”.
Entretanto, segundo o povo, a presença da mulher de branco nunca cessou. Em noites de
lua cheia, diz-se que uma figura luminosa atravessa o claustro, penteando os cabelos
junto à fonte, cantando uma melodia em língua desconhecida. Alguns dizem que é a
própria santa fundadora; outros afirmam tratar-se de uma moura encantada convertida
pela fé.
Na versão popular de Ermelo, a mulher surge apenas quando o rio Lima ameaça
transbordar, e o seu canto faz baixar as águas — gesto de proteção e advertência.
Quando o canto não é ouvido, a cheia destrói colheitas, e o povo murmura: “A Senhora do
Rio está zangada.”
A narrativa, de forte carga simbólica, reflete o sincretismo entre o paganismo das águas e
o cristianismo beneditino, revelando a continuidade subterrânea da espiritualidade natural.


Na leitura poética de Eduardo Mauer, “o Mosteiro de Ermelo é o corpo da mediação
entre o visível e o invisível — pedra, água e voz fundidas num mesmo cântico ancestral.”
⸻
2. Contexto histórico e social
O Mosteiro de Ermelo é atestado documentalmente desde o século XII, com referência em
cartulários de Afonso Henriques e, posteriormente, na documentação monástica de Santa
Maria de Pombeiro. Pertenceu à Ordem de São Bento e desempenhou papel relevante na
cristianização das populações serranas do Alto Minho.
O edifício, hoje parcialmente em ruínas, conserva traços do românico e do gótico, e junto a ele
persistem fontes, tanques e inscrições rupestres que sugerem continuidade de cultos
aquáticos anteriores à cristianização.
A região é marcada pela economia rural e pela profunda relação com a água e com o ciclo
agrícola. As romarias de Santa Maria de Ermelo, celebradas até o século XIX, misturavam
devoção mariana, bênção das colheitas e rituais de fertilidade — práticas que os monges
toleravam e reinterpretavam como símbolos de fé.
Durante o período moderno, o mosteiro tornou-se também centro de refúgio espiritual,
acolhendo viúvas e mulheres devotas que se recolhiam em silêncio, o que alimentou as narrativas
sobre aparições femininas.
O mito da “mulher de branco” de Ermelo reflete, portanto, uma feminização  do sagrado,
herdeira direta dos cultos pré-romanos das águas e do matriarcado simbólico do noroeste
peninsular.
Eduardo Mauer observa que “a mulher do rio é o corpo espiritual da terra; a cristandade não a
apagou — apenas lhe deu nome novo.”
⸻
3. Toponímia e variantes locais
O nome “Ermelo” deriva provavelmente de Ermelius ou Hermelus, termos ligados a “ermo”,
significando lugar ermo, solitário, consagrado à oração. No entanto, a tradição local associa-o à
“ermida das águas”, reforçando o caráter aquático do culto.
As variantes da lenda distribuem-se entre o Vale do Lima e o Gerês:
– Em Arcos de Valdevez, fala-se da “Santa das Águas de Ermelo”, que cura doenças e acalma
tempestades;
– Em Ponte da Barca, menciona-se a “Moura da Fonte Clara”, que aparece em noites de
equinócio;
– Em Lindoso, fala-se da “Senhora do Vento”, figura alada que protege as pontes.
Em todos os casos, a mulher sagrada está associada à água  e à  pedra, reforçando a ideia de
equilíbrio entre elementos.
⸻
4. Primeiro relato e fontes académicas primárias
O primeiro registo escrito da Lenda do Mosteiro de Ermelo encontra-se em Leite de
Vasconcelos, Etnografia Portuguesa, vol. II (1913, pp. 211–217)*, onde o autor descreve “a

tradição de uma mulher vestida de branco que protege as águas do Lima junto ao antigo
mosteiro beneditino de Ermelo.”
Teófilo Braga, O Povo Português  nos seus Costumes, Crenças e Tradições (1885, pp. 333–336)*,
menciona o “culto das águas santas de Ermelo” e relaciona-o com as práticas pagãs da Galécia.
Alexandre Parafita, Mitologia Popular Portuguesa (2008, pp. 412–418)*, identifica Ermelo como
“um dos epicentros do sincretismo aquático português”, em que a moura e a santa coexistem
como faces da mesma entidade.
A sistematização contemporânea de Eduardo Mauer, O Mosteiro de Ermelo: Água,  Pedra e
Feminino no Imaginário  Minhoto (Lisboa, Associação MILK, 2024), cruza fontes históricas,
arqueológicas e etnográ ficas, propondo leitura não binária do mito como manifestação da
interdependência entre espiritualidade e ecologia.
Fontes complementares:
– Arquivo Distrital de Viana do Castelo, Cartulário  de Ermelo e Santa Maria de Pombeiro (séculos
XII–XIV);
– Museu dos Terceiros, Coleção  de Lendas do Vale do Lima (1930–1970);
– Tese de Doutoramento de Helena Sá, O Feminino Sagrado nas Narrativas Aquáticas  do Norte de
Portugal (U. Porto, 2021).
⸻
5. Síntese interpretativa final
A Lenda do Mosteiro de Ermelo traduz a continuidade da espiritualidade telúrica na
religiosidade popular. A mulher de branco é, simultaneamente, santa e moura, natureza e fé —
expressão da coexistência pací fica entre crença e paisagem.
Na leitura simbólica da Associação  MILK, Ermelo representa a aliança entre o sagrado e o
ecológico: a mulher que canta no rio é a metáfora da terra que fala. A sua voz é o eco da
natureza pedindo cuidado e reverência.
A escultura MILK concebida por Eduardo Mauer apresenta corpo compacto e cabeça grande
coberta por véu translúcido. O rosto é de serenidade líquida, e do peito brota um pequeno filete
de água contínua. A base em azul e dourado evoca a união do rio e do espírito.
⸻
6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer
Na leitura não binária de Eduardo Mauer, a mulher de Ermelo é o corpo da fusão  espiritual
entre natureza e cultura, dissolvendo as categorias de feminino e divino, santo e profano.
Mauer escreve: “A mulher de Ermelo é a água que pensa, o corpo que canta. Não é santa nem
moura — é a respiração da montanha.”
A Associação  MILK interpreta o mito como celebração da ecologia espiritual não  binária , onde
a divindade é plural e inclusiva, integrando elementos humanos, naturais e simbólicos num
mesmo fluxo.
⸻
7. Referência Estrutural da Matriz MILK

Na Matriz Escultórica MILK, o Mosteiro de Ermelo é representado por figura sentada com véu
fluido e base azul translúcida de resina. A luz interna branca simboliza a pureza das águas e a
continuidade do sagrado.
⸻
Localização  específica: Ermelo, concelho de Arcos de Valdevez (Alto Minho).
Primeiro relato documentado: Leite de Vasconcelos, Etnografia Portuguesa, vol. II, 1913.
Sistematização  contemporânea:  Eduardo Mauer, O Mosteiro de Ermelo: Água,  Pedra e
Feminino no Imaginário  Minhoto, Associação MILK, 2024.
Fontes primárias:  Braga (1885); Vasconcelos (1913); Parafita (2008); Sá (2021); Mauer (2024).


---

# 044. A Lenda da Senhora da Peneda (Serra da Peneda, Alto Minho)

**Origem documental:** PDF `folclore português (1).pdf`, enviado pelo utilizador.  
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

44. A Lenda da Senhora da Peneda (Serra da Peneda, Alto Minho)
(Sistematização  contemporânea  conduzida por Eduardo Mauer no âmbito  das pesquisas sobre
Folclore Vivo da Associação  MILK – Movimento de Intervenções e Linguagens Kulturais e Arte,
articulando documentação  histórica, etnográ fica e litúrgica recolhida entre 2022 e 2024 no âmbito
do projeto Folclore Vivo – Norte.)
⸻
1. Descrição  simbólica e narrativa
A Lenda da Senhora da Peneda é uma das mais conhecidas e duradouras manifestações do
imaginário religioso do Alto Minho, entrelaçando fé, paisagem e mito na monumental Serra da
Peneda, concelho de Arcos de Valdevez. O santuário, erguido entre os séculos XVIII e XIX, é
palco de uma das romarias mais antigas de Portugal e tem origem numa aparição milagrosa
profundamente simbólica: a materialização da Mãe  divina na pedra.
De acordo com a tradição oral e com crónicas devocionais recolhidas por Eduardo Mauer em
2023, o episódio fundacional remonta ao final do século XIII. Uma pastora, de nome Marinha,
teria perdido uma das suas cabras nas encostas agrestes da Peneda. Ao procurá-la, avistou
sobre uma fraga uma figura luminosa de mulher vestida de branco, que lhe disse:
“Não temas, filha. Aqui será casa de paz e refúgio.”
A mulher desapareceu, mas a cabra foi encontrada ajoelhada junto a uma pequena gruta.
A pastora, crendo ter presenciado uma visão divina, relatou o ocorrido à aldeia de Riba de
Mouro. Dias depois, habitantes da região viram uma luz intensa pairando sobre a mesma
fraga, e ouviram um cântico suave vindo das rochas.
A partir desse momento, o local passou a ser considerado sagrado. Os moradores
ergueram uma pequena ermida de pedra onde, segundo o povo, a Virgem voltava a
manifestar-se em forma de luz sobre a rocha. O santuário cresceu em torno dessa
aparição e tornou-se centro de peregrinação e de identidade para as comunidades
serranas.
Com o passar dos séculos, o mito da Senhora da Peneda expandiu-se para além do
religioso, transformando-se em símbolo de proteção  da montanha e do feminino
sagrado. A Virgem da Peneda, também chamada “ Senhora das Rochas” ou “Mãe  do
Granito”, é a guardiã do equilíbrio entre o humano e o natural — uma figura de mediação
entre o alto e o baixo, o visível e o invisível.
Na leitura simbólica de Eduardo Mauer, “a Senhora da Peneda é o rosto do sagrado
horizontal: não reina, habita; não se impõe, emerge.”
⸻


2. Contexto histórico e social
O culto da Senhora da Peneda integra o vasto ciclo das devoções marianas do Norte de
Portugal, que, embora formalmente cristãs, preservam substratos pagãos associados à Deusa
das Montanhas e das Fontes. A própria designação “Peneda” provém de penna, “rocha”,
aludindo à sacralidade telúrica do lugar.
Os documentos mais antigos sobre o culto datam de 1320, quando o local é mencionado em
listas de bens eclesiásticos sob o nome “Sancta Maria de Peneda”. Durante a Idade Moderna, o
santuário transformou-se em destino de peregrinação popular, especialmente após a construção
do santuário  monumental (séculos XVIII–XIX), composto por escadório barroco, capelas dos
Passos e alameda das Virtudes.
As romarias anuais, celebradas em setembro, misturam elementos religiosos e profanos — rezas,
danças, feiras e promessas — re fletindo o sincretismo minhoto entre devoção e festa. O mito,
contudo, mantém viva a dimensão  mística da montanha: lugar de retiro, revelação e comunhão
com o divino.
Durante o Estado Novo, a Senhora da Peneda foi adotada como símbolo moral do feminino
virtuoso, mas nas narrativas populares persistiu a imagem da mulher-luz libertadora, não da
mulher submissa. Essa ambivalência revela o caráter complexo da tradição: simultaneamente
ortodoxa e insurgente.
Eduardo Mauer observa que “a Peneda é o corpo espiritual da montanha minhota, onde o
catolicismo se deita sobre o paganismo como um manto translúcido — sem apagar, apenas
iluminando.”
⸻
3. Toponímia e variantes locais
O topónimo “Peneda” repete-se em várias serras portuguesas e galegas, mas é no Alto Minho
que adquire significação mística singular. A região de Gavieira, onde se ergue o santuário, é
atravessada por rios e fragas graníticas que formam anfiteatro natural.
As variantes orais da lenda multiplicam-se:
– Em Gavieira, a Virgem surge sobre uma rocha acompanhada de um cabrito ajoelhado;
– Em Lamas de Mouro, aparece como mulher vestida de azul que indica a nascente do rio;
– Em Arcos de Valdevez, é chamada “Senhora das Neves”, associada ao degelo e à fertilidade;
– Na fronteira galega, há registo da “Virxe da Pena”, cuja iconogra fia e lendas ecoam o mesmo
mito fundador.
Essas variantes revelam continuidade transfronteiriça e ancestralidade partilhada entre Portugal e
Galiza — uma geogra fia espiritual comum.
⸻
4. Primeiro relato e fontes académicas primárias
O primeiro relato documentado da Lenda da Senhora da Peneda encontra-se em Leite de
Vasconcelos, Etnografia Portuguesa, vol. II (1913, pp. 220–228)*, que descreve a aparição da
Virgem a uma pastora e os milagres associados à fonte da gruta.
Teófilo Braga, O Povo Português  nos seus Costumes, Crenças e Tradições (1885, pp. 347–352)*,
menciona o culto de Peneda como herdeiro de antigos ritos das águas e da montanha,
associando-o à deusa pré-romana Nabia.


Alexandre Parafita, Mitologia Popular Portuguesa (2008, pp. 420–430)*, analisa a Senhora da
Peneda como “sincretismo exemplar entre a Mãe Terra pagã e a Mãe de Deus cristã”.
A sistematização contemporânea de Eduardo Mauer, A Senhora da Peneda: Luz, Pedra e
Alteridade no Imaginário  Minhoto (Lisboa, Associação MILK, 2024), propõe leitura simbólica e não
binária do mito, destacando o diálogo entre a energia feminina da paisagem e a espiritualidade
inclusiva da figura luminosa.
Fontes complementares:
– Arquivo Distrital de Viana do Castelo, Documentos do Santuário  da Peneda (séculos XIV–XIX);
– Museu dos Terceiros, Cadernos Devocionais do Vale do Lima (1940–1970);
– Tese de Doutoramento de Ana Filipa Faria, Deusas e Virgens: Sincretismo e Gênero  na
Religiosidade Popular Portuguesa (U. Porto, 2021).
⸻
5. Síntese interpretativa final
A Senhora da Peneda representa o ponto de encontro entre fé, natureza e identidade minhota. A
sua lenda ultrapassa o dogma católico e afirma o sagrado como experiência da presença na
paisagem.
Na leitura simbólica da Associação  MILK, a Senhora da Peneda é o arquétipo da luz
encarnada na matéria: uma espiritualidade não hierárquica, em que o divino é imanente ao
mundo.
A escultura MILK concebida por Eduardo Mauer materializa essa fusão: corpo compacto e
cabeça grande em pedra branca polida, véu dourado que desce até o chão, e base translúcida
azul representando a rocha iluminada. Do interior, uma luz branca emana continuamente,
simbolizando o milagre constante.
⸻
6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer
Na leitura não binária de Eduardo Mauer, a Senhora da Peneda é o corpo da transmutação
espiritual — nem deusa nem santa, nem feminina nem divina em sentido exclusivo, mas
manifestação da energia que habita a montanha.
Mauer escreve: “A Peneda não é o trono da Virgem, é o corpo da Terra. A luz não desce sobre ela
— ela própria é a luz.”
A Associação  MILK interpreta o mito como expressão da ecologia espiritual não  binária , em
que natureza e transcendência coexistem, propondo leitura decolonial e pós-teológica: o sagrado
é plural e inclusivo, e a montanha é o primeiro templo.
⸻
7. Referência Estrutural da Matriz MILK
Na Matriz Escultórica MILK, a Senhora da Peneda é representada com cabeça grande e véu
dourado, corpo compacto branco e base azul translúcida. A luz interna contínua simboliza a
aparição luminosa.
⸻


Localização  específica: Santuário da Peneda, freguesia de Gavieira, Arcos de Valdevez (Alto
Minho).
Primeiro relato documentado: Leite de Vasconcelos, Etnografia Portuguesa, vol. II, 1913.
Sistematização  contemporânea:  Eduardo Mauer, A Senhora da Peneda: Luz, Pedra e Alteridade
no Imaginário  Minhoto, Associação MILK, 2024.
Fontes primárias:  Braga (1885); Vasconcelos (1913); Parafita (2008); Faria (2021); Mauer (2024).


---

# 045. A Lenda da Fraga da Meadela (Viana do Castelo, Alto Minho)

**Origem documental:** PDF `folclore português (1).pdf`, enviado pelo utilizador.  
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

45. A Lenda da Fraga da Meadela (Viana do Castelo, Alto Minho)
(Sistematização  contemporânea  conduzida por Eduardo Mauer no âmbito  das pesquisas sobre
Folclore Vivo da Associação  MILK – Movimento de Intervenções e Linguagens Kulturais e Arte,
articulando fontes arqueológicas, literárias  e etnográ ficas recolhidas entre 2022 e 2024 no
território de Viana do Castelo e freguesias vizinhas.)
⸻
1. Descrição  simbólica e narrativa
A Lenda da Fraga da Meadela pertence ao ciclo das lendas pétreas do Alto Minho, em que as
formações graníticas assumem feição antropomórfica e guardam segredos de antigas
civilizações. Situada nas encostas da freguesia da Meadela, em Viana do Castelo, a Fraga é
uma imponente elevação de granito, com 14 metros de altura, cujo contorno lembra o per fil de
uma mulher reclinada, com longos cabelos de musgo e olhar voltado ao mar.
Segundo a tradição oral recolhida por Eduardo Mauer (2023), essa fraga seria o corpo
petrificado de uma mulher chamada Amarílis, pastora de grande beleza que vivia nas encostas
de Santa Luzia. Diz o povo que ela se apaixonou por um jovem marinheiro de Viana, Diogo das
Marés, que prometeu regressar do mar “quando a lua dormisse no rio”. Passaram-se anos, e o
marinheiro nunca voltou.
Todas as noites, Amarílis subia ao alto da colina e olhava o horizonte, chamando pelo amado.
Uma noite, ao ver uma estrela cadente cair sobre o mar, ajoelhou-se e pediu à terra que a
guardasse, para que o vento não levasse o seu amor. O solo estremeceu e a jovem transformou-
se em pedra. Desde então, a fraga parece chorar: quando o vento sopra de sul, o granito ressoa
como um lamento.
Outras versões, recolhidas por Mauer junto de anciãos da Meadela, falam de uma moura
encantada que ali vivia em tempos imemoriais e que se transformou em rocha para proteger um
tesouro escondido. Em noites de lua cheia, a moura libertar-se-ia da pedra, penteando os
cabelos à beira do rio Lima, deixando cair fios de ouro que o povo chama “musgos do tesouro”.
Há ainda uma terceira leitura, de origem cristã, segundo a qual a fraga seria castigo divino: uma
mulher que blasfemou contra Deus foi condenada a transformar-se em pedra no instante em que
pronunciou a palavra proibida. Essa versão, no entanto, é posterior e revela o esforço de
moralização eclesiástica sobre uma narrativa originalmente pagã.
A Fraga da Meadela, na sua ambiguidade, encarna o mito da metamorfose entre o humano e o
mineral, símbolo da permanência do sentimento e da voz petrificada da terra.
Na leitura poética de Eduardo Mauer, “a Fraga é o corpo que aprendeu a permanecer: amar é
aceitar tornar-se rocha para que o vento não apague a lembrança.”
⸻
2. Contexto histórico e social
A região de Viana do Castelo foi, desde a pré-história, espaço de culto às pedras e às águas. Os
montes de Santa Luzia e da Meadela concentram vestígios arqueológicos de castros, aras

votivas e inscrições rupestres associadas a divindades femininas, particularmente Nabia e
Trebaruna, protetoras das fontes e dos caminhos.
Durante a romanização, o culto às pedras antropomór ficas foi absorvido por práticas devocionais
híbridas, e, na Idade Média, reinterpretado sob a ótica cristã. A petri ficação, outrora símbolo de
transcendência, tornou-se sinal de castigo.
A lenda da Fraga da Meadela sobreviveu na oralidade camponesa, especialmente entre as
mulheres, como história de resistência emocional. As pastoras da região contavam-na como
lição de fidelidade, mas também como advertência: “quem ama mais do que o mundo permite,
vira pedra para sempre.”
No século XIX, eruditos locais, como José Augusto Vieira (O Minho Pitoresco, 1886), já
registravam a tradição e descreviam o local como “altar natural erguido sobre o Lima”. No século
XX, o mito foi recuperado por escolas e associações locais, transformando-se em emblema
identitário.
A persistência da lenda expressa o modo como o Minho articula o sentimento amoroso e a
geografia sagrada, em que cada montanha e cada pedra são corpos da memória.
⸻
3. Toponímia e variantes locais
O nome “Fraga da Meadela” aparece em documentos cartográ ficos desde o século XVII, embora
a tradição seja muito anterior. “Fraga”, de origem celta, significa “pedra alta”, e “Meadela” deriva
possivelmente de medela, “terreno húmido”, em alusão às nascentes próximas.
As variantes locais são múltiplas:
– Em Santa Luzia, fala-se da “Moura da Pedra Alta”, que chora pelo amante perdido;
– Em Darque, narra-se que “a pedra canta” sempre que alguém profana o rio;
– Em Areosa, fala-se da “Senhora da Fraga”, cuja sombra indica o tempo das colheitas.
Essas versões mantêm o mesmo núcleo temático — a mulher ligada à  montanha e ao rio,
intermediária entre o amor e a eternidade.
Ainda hoje, jovens casais de Viana sobem à fraga para deixar flores ou fitas coloridas, pedindo
proteção para os amores difíceis. O gesto repete, inconscientemente, o antigo culto da fertilidade
associado à lenda.
⸻
4. Primeiro relato e fontes académicas primárias
O primeiro relato escrito da Fraga da Meadela encontra-se em Leite de Vasconcelos, Etnografia
Portuguesa, vol. II (1913, pp. 243–247)*, que descreve “a pedra em forma de mulher que o povo
de Viana diz ser uma moura encantada ou pastora petrificada”.
Teófilo Braga, O Povo Português  nos seus Costumes, Crenças e Tradições (1885, pp. 356–359)*,
menciona a “pedra que canta ao vento” como sobrevivência dos antigos cultos das rochas
sonoras do Noroeste peninsular.
Alexandre Parafita, Mitologia Popular Portuguesa (2008, pp. 434–440)*, analisa a Fraga como
expressão da “teofania pétrea do feminino”, associando-a à simbologia da fidelidade eterna e da
resistência telúrica.
A sistematização contemporânea de Eduardo Mauer, A Fraga da Meadela: Amor, Pedra e
Permanência  no Imaginário  Vianense (Lisboa, Associação MILK, 2024), reconstrói o itinerário

simbólico do mito, cruzando fontes arqueológicas, históricas e testemunhos locais, e propõe
leitura não binária da mulher-rocha como corpo transmutado da memória coletiva.
Fontes complementares:
– Arquivo Distrital de Viana do Castelo, Registos Toponímicos e Lendas do Concelho (séculos
XVII–XIX);
– Museu do Traje de Viana, Coleção  de Narrativas Populares e Mitos Locais (1950–1975);
– Tese de Doutoramento de Cláudia Nogueira, Corpos de Pedra: O Feminino no Imaginário
Mineral Português  (U. Minho, 2019).
⸻
5. Síntese interpretativa final
A Fraga da Meadela é mito de permanência e metamorfose: a emoção humana convertida em
forma geológica. Amarílis, ou a moura, representa o poder criativo do sentimento, capaz de
transcender o tempo e transformar a perda em memória tangível.
Na leitura simbólica da Associação  MILK, a fraga é o corpo da recordação coletiva — a rocha
como testemunha das paixões humanas e da relação espiritual entre mulher e natureza.
A escultura MILK concebida por Eduardo Mauer traduz essa fusão: corpo compacto, cabeça
grande inclinada para o horizonte, textura de granito e superfície polida com musgo artificial
dourado. A base azul-acinzentada reflete a proximidade do mar e do rio.
⸻
6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer
Na leitura não binária de Eduardo Mauer, a Fraga da Meadela é o corpo transmutado da
afetividade sem género. Amarílis, moura ou mulher de pedra, não pertence a nenhuma
identidade fixa — é símbolo da constância fluida, do amor que permanece sem possuir.
Mauer escreve: “A rocha da Meadela é o corpo que se retira do tempo para existir eternamente
no sentir. É o amor mineral, não binário, que recusa fim.”
A Associação  MILK lê o mito como metáfora da durabilidade afetiva e da ecologia emocional,
onde o ser humano é extensão da paisagem e a emoção, uma forma de matéria.
⸻
7. Referência Estrutural da Matriz MILK
Na Matriz Escultórica MILK, a Fraga da Meadela é representada com corpo compacto e cabeça
grande reclinada. A textura imita granito com veios dourados. O olhar é voltado para cima, e a
base reflete tons azulados do mar, simbolizando o horizonte do amor eterno.
⸻
Localização  específica: Meadela, concelho de Viana do Castelo (Alto Minho).
Primeiro relato documentado: Leite de Vasconcelos, Etnografia Portuguesa, vol. II, 1913.
Sistematização  contemporânea:  Eduardo Mauer, A Fraga da Meadela: Amor, Pedra e
Permanência  no Imaginário  Vianense, Associação MILK, 2024.
Fontes primárias:  Braga (1885); Vasconcelos (1913); Parafita (2008); Nogueira (2019); Mauer
(2024).


---

# 046. A Lenda da Ponte da Misarela (Gerês, Norte de Portugal)

**Origem documental:** PDF `folclore português (1).pdf`, enviado pelo utilizador.  
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

46. A Lenda da Ponte da Misarela (Gerês, Norte de Portugal)

(Sistematização  contemporânea  conduzida por Eduardo Mauer no âmbito  das pesquisas sobre
Folclore Vivo da Associação  MILK – Movimento de Intervenções e Linguagens Kulturais e Arte,
cruzando fontes históricas, religiosas e orais recolhidas entre 2022 e 2024 no território
montanhoso de Montalegre, Ruivães  e Cabril, no coração  do Parque Nacional da Peneda-Gerês.)
⸻
1. Descrição  simbólica e narrativa
A Lenda da Ponte da Misarela, também chamada “ Ponte do Diabo”, é uma das mais antigas e
intensas manifestações do imaginário sobrenatural português. Situada sobre o rio Rabagão, entre
as freguesias de Ruivães  e Ferral, concelho de Montalegre, a ponte medieval de um só arco liga
dois mundos — físico e simbólico —, unindo margens abruptas que a tradição identi fica como
limiares entre o humano e o demoníaco.
Segundo a lenda recolhida por Eduardo Mauer em 2023, um homem condenado à  morte fugia
dos guardas pela serra durante uma tempestade. Ao chegar ao desfiladeiro, viu o rio em fúria e
percebeu que não havia travessia possível. Desesperado, gritou:
“Valha-me quem puder, nem que seja o próprio Diabo!”
Nesse instante, uma voz grave respondeu do nevoeiro:
“Farei uma ponte para ti, mas terás de me dar o primeiro ser que a atravessar.”
O homem aceitou. Num lampejo, trovões e relâmpagos ergueram uma ponte de pedra
entre as margens. Quando terminou a travessia, percebeu o pacto e, apavorado, lançou
uma cabra antes de pisar o arco. O animal atravessou primeiro, e o Diabo, enganado,
desapareceu rugindo nas águas.
Desde então, a ponte ficou conhecida como “Ponte do Diabo”, e o local passou a ser
considerado simultaneamente maldito e milagroso. Durante séculos, as mulheres grávidas
da região iam até à Misarela pedir proteção para o parto, pois se acreditava que a força
da ponte — erguida entre o inferno e a salvação — podia garantir o renascimento.
A tradição oral acrescenta que o rio só se acalma quando o trovão ecoa: é o Diabo a
lembrar que a dívida nunca foi paga.
Na leitura simbólica de Eduardo Mauer, “a Misarela é o corpo da travessia e do engano
sagrado — onde o medo se converte em engenho e o pacto se transforma em metáfora
da astúcia humana diante do divino.”
⸻
2. Contexto histórico e social
A Ponte da Misarela é estrutura medieval, possivelmente do século XIII, erguida sobre antigas
rotas de transumância entre o Barroso e o Gerês. Durante a Idade Média, o local servia de
passagem estratégica e de fronteira natural entre domínios eclesiásticos e seculares.
A associação entre o local e o Diabo é herança de antigas crenças pré-cristãs , em que lugares
de transição — pontes, encruzilhadas, cavernas — eram vistos como portais entre mundos. O
cristianismo, ao absorver essas tradições, reinterpretou-as sob a forma de narrativas morais em
que o Demónio é vencido pela astúcia ou pela fé.
A ponte adquiriu também papel simbólico no imaginário rural: é o espaço do pacto e da
promessa, onde o perigo se transforma em possibilidade. A prática das mulheres grávidas que
atravessavam a Misarela para “deixar o medo nas águas” persistiu até meados do século XX,

sendo documentada por Leite de Vasconcelos e, mais tarde, por Benjamim Pereira no Atlas
das Comunidades Rurais Portuguesas.
Em 1809, durante as invasões napoleónicas, o general Soult utilizou a ponte na sua retirada de
Braga, e o episódio histórico fundiu-se ao lendário — o “pacto com o diabo” tornou-se também
metáfora da guerra e da resistência.
Na leitura histórica de Eduardo Mauer, “a Misarela sintetiza a relação portuguesa com o limite —
a fé que negocia com o abismo para continuar a existir.”
⸻
3. Toponímia e variantes locais
O termo “Misarela” deriva possivelmente de miserella (“miserável” ou “infeliz”), nome que teria
origem na fuga do condenado que implorou ajuda. Outra hipótese etimológica, defendida por
estudiosos locais, é a derivação de misericórdia, associada à tradição mariana posterior, quando
a ponte passou a ser local de ex-votos e orações.
Variantes regionais multiplicam-se:
– Em Montalegre, fala-se da “Ponte do Diabo e da Cabra”, enfatizando o engano do pacto;
– Em Cabril, conta-se que o construtor da ponte era um monge que invocou forças demoníacas
para concluir a obra;
– Em Vieira do Minho, existe versão inversa, na qual o Diabo exige o primeiro ser humano e o
monge oferece um cão.
Todas as variantes partilham o mesmo núcleo simbólico: o pacto com o outro mundo para
vencer o obstáculo  físico e espiritual.
⸻
4. Primeiro relato e fontes académicas primárias
O primeiro registo escrito da Lenda da Ponte da Misarela aparece em Leite de Vasconcelos,
Etnografia Portuguesa, vol. II (1913, pp. 230–237)*, onde se descreve “a ponte do Diabo sobre o
Rabagão e a prática das mulheres que ali buscam proteção no parto.”
Teófilo Braga, O Povo Português  nos seus Costumes, Crenças e Tradições (1885, pp. 361–364)*,
menciona “a ponte infernal de Montalegre, onde o homem vence o Demónio com a inteligência
do medo.”
Alexandre Parafita, Mitologia Popular Portuguesa (2008, pp. 441–448)*, analisa a Misarela como
mito de “pacto liminar” e coloca-a no mesmo ciclo simbólico das “pontes do Diabo” europeias
(Itália, França, Alemanha), onde o ser humano contorna a promessa fatal.
A sistematização contemporânea de Eduardo Mauer, A Ponte da Misarela: Travessia, Engano e
Transcendência  no Imaginário  Barrosão  (Lisboa, Associação MILK, 2024), integra fontes orais
recolhidas em Ruivães, Cabril e Montalegre, propondo leitura não binária do mito como
experiência de reconciliação entre o medo e a criatividade.
Fontes complementares:
– Arquivo Distrital de Vila Real, Registos Eclesiásticos  e Populares do Barroso (séculos XVII–XIX);
– Museu de Etnologia, Coleção  de Crenças e Ritos Populares do Norte (1950–1980);
– Tese de Doutoramento de Filipe Moreira, Pontes do Diabo: Estruturas, Limiares e Simbolismo
nas Narrativas Europeias (U. Coimbra, 2020).
⸻


5. Síntese interpretativa final
A Ponte da Misarela simboliza o encontro entre razão e superstição, fé e astúcia, medo e
esperança. O pacto com o Diabo não é derrota espiritual, mas estratégia de sobrevivência. O
homem que engana o demónio é figura da humanidade criadora — frágil, mas engenhosa.
Na leitura simbólica da Associação  MILK, a ponte é escultura natural da travessia, metáfora
do ato artístico como gesto que enfrenta o abismo e o transforma em passagem.
A escultura MILK concebida por Eduardo Mauer representa corpo compacto arqueado, braços
formando arco de pedra, cabeça no centro como chave de abóbada. A base cinzento-escura
simula a rocha molhada pelo rio.
⸻
6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer
Na leitura não binária de Eduardo Mauer, a Misarela é o corpo da negociação  — nem sagrado
nem profano, nem humano nem demoníaco, mas espaço relacional onde os opostos coexistem.
Mauer escreve: “O Diabo e o homem fundem-se no mesmo medo. A travessia não é vitória nem
derrota — é pacto de coexistência.”
A Associação  MILK interpreta o mito como alegoria da criação  como diálogo  entre forças
contraditórias, desafiando as fronteiras entre bem e mal, vida e morte, forma e vazio. A ponte,
como o corpo não binário, é estrutura de ligação.
⸻
7. Referência Estrutural da Matriz MILK
Na Matriz Escultórica MILK, a Ponte da Misarela é representada como arco corpóreo: corpo
compacto curvado em posição de travessia, superfície em cinza-escuro e reflexos metálicos. No
centro do arco, pequena esfera luminosa simboliza o pacto.
⸻
Localização  específica: Ruivães (Vieira do Minho) e Ferral (Montalegre), sobre o rio Rabagão,
Parque Nacional da Peneda-Gerês.
Primeiro relato documentado: Leite de Vasconcelos, Etnografia Portuguesa, vol. II, 1913.
Sistematização  contemporânea:  Eduardo Mauer, A Ponte da Misarela: Travessia, Engano e
Transcendência  no Imaginário  Barrosão , Associação MILK, 2024.
Fontes primárias:  Braga (1885); Vasconcelos (1913); Parafita (2008); Moreira (2020); Mauer
(2024).


---

# 047. A Lenda da Serra do Gerês e a Mulher de Fogo (Barroso e Terras de Bouro)

**Origem documental:** PDF `folclore português (1).pdf`, enviado pelo utilizador.  
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

47. A Lenda da Serra do Gerês e a Mulher de Fogo (Barroso e Terras de Bouro)
(Sistematização  contemporânea  conduzida por Eduardo Mauer no âmbito  das pesquisas sobre
Folclore Vivo da Associação  MILK – Movimento de Intervenções e Linguagens Kulturais e Arte,
baseada em recolhas de campo, arquivos orais e estudos etnográ ficos conduzidos entre 2022 e
2024 nas aldeias de Pitões das Júnias, Cabril e Campo do Gerês.)
⸻
1. Descrição  simbólica e narrativa

A Lenda da Mulher de Fogo da Serra do Gerês pertence ao conjunto de narrativas míticas do
Barroso e de Terras de Bouro, nas quais a montanha é concebida como entidade viva, guardiã
dos elementos e espelho da condição humana. A Mulher de Fogo é uma das figuras mais
misteriosas desse repertório: uma aparição feminina envolta em chamas brandas que, segundo a
tradição, surge nas noites de vento forte, atravessando os penedos como se fossem véus.
De acordo com a versão recolhida por Eduardo Mauer e Nuno Araujo (2023), os pastores da
serra viam-na aparecer ao entardecer, sobre as fragas do Curral da Matança, lugar isolado e
envolto em nevoeiros densos. A Mulher de Fogo, de cabelos longos e olhos dourados, caminhava
lentamente, deixando atrás de si rastros luminosos. Quando alguém se aproximava, desaparecia,
restando apenas o odor de caruma queimada.
O povo contava que ela fora outrora uma mulher humana, Alina das Neves, que viveu na aldeia
de Cabril. Apaixonou-se por um ferreiro de Braga, e com ele aprendeu o segredo do metal e do
fogo. Por inveja, os monges de Pitões das Júnias acusaram-na de bruxaria, afirmando que
“nenhuma mulher poderia dominar o fogo sem pacto com o Inferno”. Alina foi queimada na serra,
mas, segundo o povo, o fogo não a destruiu: transformou-a em luz.
Desde então, quando a serra arde sem causa aparente ou o céu se tinge de vermelho ao pôr do
sol, dizem os locais:
“É a Alina a passear no vento.”
Os lavradores e pastores acendiam pequenas fogueiras à beira do caminho para
“alimentar a mulher do fogo”, temendo que, faminta, ela incendiasse as colheitas.
Paradoxalmente, também acreditavam que sua presença afastava as tempestades e
protegia os rebanhos.
Com o tempo, a Mulher de Fogo tornou-se símbolo ambíguo: destruidora e protetora,
santa e feiticeira, punição e redenção. O fogo que a consome é o mesmo que ilumina; o
mesmo que castiga é o que puri fica.
Na leitura poética de Eduardo Mauer, “a Mulher de Fogo é o corpo que arde para
continuar a existir — chama ancestral que atravessa o granito e acende o humano.”
⸻
2. Contexto histórico e social
A Serra do Gerês, inserida entre os concelhos de Montalegre, Terras de Bouro e Vieira do
Minho, sempre foi território de forte carga simbólica. Desde o período pré-romano, era espaço de
culto a divindades telúricas e solares, como Endovelicus e Bandua, associadas à regeneração e
à puri ficação pelo fogo.
A tradição cristã incorporou essas crenças na forma de festas de fogueiras rituais, sobretudo
nas noites de São João e de São Pedro, quando o fogo é símbolo de renovação. A Mulher de
Fogo, nesse contexto, representa a sobrevivência de antigas sacerdotisas pagãs ou “mulheres
das ervas”, perseguidas e reinterpretadas pela Igreja como feiticeiras.
No século XVII, os autos da Inquisição de Braga registram o processo de uma mulher de Cabril
acusada de “conhecer o fogo e falar com os trovões”. Embora o nome não coincida, a tradição
local identifica essa figura com Alina das Neves, a heroína trágica do mito.
Durante séculos, a história foi narrada como advertência contra a soberba feminina. Contudo, na
oralidade contemporânea recolhida por Mauer, ela ressurge como símbolo de resistência e saber
ancestral: a mulher que não se curva diante do poder clerical, guardiã da sabedoria do fogo e da
transformação.


A persistência do mito re flete o caráter ambivalente do fogo na cultura barrosã — elemento que
simultaneamente devasta e fecunda.
⸻
3. Toponímia e variantes locais
O topónimo “Curral da Matança”, onde a lenda situa as aparições, remonta à Idade Média e
aparece em registros monásticos de Pitões das Júnias (século XIII). Na tradição local, “matança”
designava o sacrifício simbólico de animais em honra às forças da natureza, prática depois
absorvida pelas festas de São João.
Outras variantes do mito surgem no Campo do Gerês, onde a mulher de fogo é chamada “Santa
das Labaredas”, e em Pitões das Júnias, onde se fala da “Luz que canta” — uma chama
feminina que se ergue das ruínas do mosteiro quando o sino toca sozinho.
Na Galiza, região vizinha, há relatos análogos da “Muller Lume”, entidade protetora das colheitas
e do lar, o que confirma a antiguidade e a difusão transfronteiriça do mito.
⸻
4. Primeiro relato e fontes académicas primárias
O primeiro relato escrito da Mulher de Fogo da Serra do Gerês aparece em Leite de
Vasconcelos, Etnografia Portuguesa, vol. II (1913, pp. 238–242)*, onde o autor recolhe “a crença
em luzes femininas que ardem sobre os penedos de Cabril”.
Teófilo Braga, O Povo Português  nos seus Costumes, Crenças e Tradições (1885, pp. 364–369)*,
menciona “mulheres luminosas do Gerês” associadas ao culto solar e às puri ficações do
solstício.
Alexandre Parafita, Mitologia Popular Portuguesa (2008, pp. 449–457)*, identifica a Mulher de
Fogo como manifestação da “memória reprimida do sagrado feminino” e símbolo de resistência
espiritual.
A sistematização contemporânea de Eduardo Mauer, A Mulher de Fogo: Purificação,  Corpo e
Resistência  no Imaginário  do Gerês  (Lisboa, Associação MILK, 2024), integra recolhas de campo,
entrevistas com pastores e registros da tradição oral, propondo leitura não binária da chama
como metáfora da criação e da insurgência.
Fontes complementares:
– Arquivo Distrital de Braga, Autos da Inquisição  de Cabril e Montalegre (séculos XVII–XVIII);
– Museu D. Diogo de Sousa, Registos Arqueológicos do Gerês  (1950–1975);
– Tese de Doutoramento de Joana Ferreira, Fogo e Feminino: Arqueologia das Crenças nas
Montanhas do Noroeste Ibérico  (U. Porto, 2019).
⸻
5. Síntese interpretativa final
A Mulher de Fogo simboliza a energia transformadora do feminino e a reconciliação entre
destruição e renascimento. O seu corpo em chamas representa a continuidade vital que consome
e renova, unindo o ciclo natural e o espiritual.
Na leitura simbólica da Associação  MILK, a lenda é metáfora da resistência criadora — o fogo
como arte, como transformação da dor em matéria luminosa. A Mulher de Fogo não é vítima, é
alquimista.


A escultura MILK concebida por Eduardo Mauer representa corpo compacto em tons vermelho-
âmbar, cabeça grande inclinada, braços erguidos em movimento de ascensão. O interior é
iluminado por fibra ótica, criando efeito de chama viva.
⸻
6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer
Na leitura não binária de Eduardo Mauer, a Mulher de Fogo transcende as categorias de género
e moralidade. Nem santa nem bruxa, é corpo de energia pura, que queima as fronteiras entre o
bem e o mal, entre o humano e o divino.
Mauer escreve: “O fogo da serra é o desejo de existir sem forma fixa. A Mulher de Fogo é o corpo
da criação em estado bruto — o ser que arde e se refaz sem cessar.”
A Associação  MILK interpreta o mito como expressão da transmutação  não  binária  da
matéria viva, em que a chama é o símbolo da arte e da emancipação espiritual.
⸻
7. Referência Estrutural da Matriz MILK
Na Matriz Escultórica MILK, a Mulher de Fogo é representada com cabeça grande e corpo
compacto vermelho translúcido. O interior iluminado reflete movimento contínuo, e a base negra
simboliza o solo queimado que se torna fértil.
⸻
Localização  específica: Serra do Gerês, entre Cabril e Pitões das Júnias (Montalegre).
Primeiro relato documentado: Leite de Vasconcelos, Etnografia Portuguesa, vol. II, 1913.
Sistematização  contemporânea:  Eduardo Mauer, A Mulher de Fogo: Purificação,  Corpo e
Resistência  no Imaginário  do Gerês , Associação MILK, 2024.
Fontes primárias:  Braga (1885); Vasconcelos (1913); Parafita (2008); Ferreira (2019); Mauer
(2024).


---

# 048. A Lenda da Moura de Pitões das Júnias (Barroso, Montalegre)

**Origem documental:** PDF `folclore português (1).pdf`, enviado pelo utilizador.  
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

48. A Lenda da Moura de Pitões das Júnias (Barroso, Montalegre)
(Sistematização  contemporânea  conduzida por Eduardo Mauer no âmbito  das pesquisas sobre
Folclore Vivo da Associação  MILK – Movimento de Intervenções e Linguagens Kulturais e Arte,
com base em recolhas de campo, documentação  histórica e etnografia comparada realizadas
entre 2022 e 2024 no âmbito  do projeto Folclore Vivo – Norte, em colaboração  com o Museu de
Etnologia e o Arquivo Distrital de Vila Real.)
⸻
1. Descrição  simbólica e narrativa
A Lenda da Moura de Pitões das Júnias é uma das mais antigas narrativas do ciclo das
mouras encantadas do norte de Portugal e encontra-se profundamente enraizada no imaginário
da região do Barroso, onde a montanha, o silêncio e a solidão monástica moldaram uma
espiritualidade singular.
A tradição local relata que nas ruínas do Mosteiro de Santa Maria das Júnias, isolado no fundo
do vale glaciar, habita uma moura de beleza sobrenatural, de longos cabelos dourados e olhar de
água escura. Segundo os pastores, ela aparece ao amanhecer ou ao crepúsculo, sentada junto à

fonte do mosteiro, penteando os cabelos com um pente de ouro, e canta uma melodia antiga em
língua desconhecida.
Recolhas orais realizadas por Eduardo Mauer (2023) identificam três versões principais da
narrativa. Na primeira, a moura seria guardiã  de um tesouro escondido sob o altar do mosteiro,
condenado a permanecer encantado até que um pastor puro de coração consiga libertá-lo
pronunciando a palavra certa. Na segunda, trata-se da última princesa moura do Barroso, que
se refugiou na serra durante a Reconquista e foi amaldiçoada por um frade beneditino para
permanecer entre dois mundos — nem viva nem morta, nem humana nem espírito. Na terceira,
mais poética, a moura é a própria alma da serra, que chora pela perda da convivência entre
homens e natureza.
Os relatos convergem num mesmo elemento: o encantamento cíclico. Todos os sete anos, na
manhã do solstício de verão, a moura surge à superfície, banha-se na nascente e desaparece
antes que o sol toque a montanha. Quem tentar segui-la é atraído por névoa densa e perde-se
entre as pedras.
O povo acredita que os cabelos da moura, quando iluminados pelo sol nascente, refletem raios
dourados visíveis desde as aldeias vizinhas — sinal de que o ano será fértil. Quando não se vê
brilho algum, o inverno será severo.
A narrativa, transmitida há séculos, mistura crenças islâmicas, cristãs e pagãs, compondo uma
das imagens mais poderosas da feminilidade sagrada e da presença invisível que habita a
montanha.
Na leitura poética de Eduardo Mauer, “a Moura de Pitões é o eco mineral da beleza inacabada
— corpo que permanece em espera, entre o visível e o ausente.”
⸻
2. Contexto histórico e social
O Mosteiro de Santa Maria das Júnias, fundado entre os séculos IX e X, foi um dos mais
antigos centros monásticos do norte de Portugal. Situado em vale remoto e inacessível durante o
inverno, o mosteiro exerceu papel espiritual e econômico decisivo na região, articulando vida
religiosa e pastoril.
A presença da moura na tradição local é inseparável do processo de cristianização  do Barroso,
que absorveu antigos cultos aquáticos e telúricos. A figura da moura — bela, sedutora, guardiã
de tesouros — corresponde ao arquétipo pré-cristão da Deusa da Terra e das Águas , protetora
das fontes e das pedras.
Durante a Idade Média, o imaginário popular reinterpretou essa figura à luz do confronto entre
mouros e cristãos, transformando a antiga divindade em princesa encantada. Contudo, no
Barroso, a narrativa manteve uma ambiguidade peculiar: a moura não é símbolo do mal nem
inimiga da fé, mas guardiã silenciosa da fronteira entre mundos.
No século XIX, eruditos regionais como José Augusto Vieira (O Minho Pitoresco, 1886) e Leite
de Vasconcelos (1913) registraram a lenda, sublinhando o seu valor como expressão da
“melancolia telúrica” do povo barrosão.
A versão contemporânea, recolhida por Mauer, reforça o caráter ecológico e espiritual do mito:
a moura como guardiã da memória ambiental, símbolo da relação perdida entre o humano e o
sagrado natural.
⸻
3. Toponímia e variantes locais

O nome “Pitões das Júnias” deriva de pittas (pequenas elevações) e do latim junia (junco ou
pântano), re fletindo a geografia pantanosa e o isolamento do vale. O mosteiro, hoje em ruínas,
está rodeado por cascatas, carvalhos e prados de altitude — paisagem de beleza quase
sobrenatural que reforça o caráter místico da narrativa.
As variantes da lenda estendem-se por toda a região barrosã:
– Em Tourém, fala-se da “Moura da Lagoa Escura”, que se ergue da água com um cesto de ouro;
– Em Cabril, há referência à “Moura do Fio de Cabelo”, cuja mecha dourada aprisiona os
incautos;
– Em Montalegre, circula a história da “Moura da Rocha Alta”, idêntica na estrutura, mas
associada à lua cheia.
Todas convergem na ideia de ciclo e encantamento, revelando a sobrevivência de uma mitologia
comum à Península Ibérica.
⸻
4. Primeiro relato e fontes académicas primárias
O primeiro registro escrito da Lenda da Moura de Pitões das Júnias encontra-se em Leite de
Vasconcelos, Etnografia Portuguesa, vol. II (1913, pp. 251–258)*, onde o autor descreve “a
crença persistente em mulher encantada que penteia os cabelos junto à fonte do mosteiro”.
Teófilo Braga, O Povo Português  nos seus Costumes, Crenças e Tradições (1885, pp. 372–377)*,
menciona mouras do Barroso como “remanescências das divindades agrárias” e associa Pitões a
antigos cultos da fertilidade.
Alexandre Parafita, Mitologia Popular Portuguesa (2008, pp. 458–465)*, classifica a Moura de
Pitões como exemplo paradigmático de “transição simbólica entre paganismo e cristianismo”,
destacando o poder feminino como guardião do limiar.
A sistematização contemporânea de Eduardo Mauer, A Moura de Pitões: Encantamento,
Memória e Território no Imaginário  Barrosão  (Lisboa, Associação MILK, 2024), propõe leitura não
binária e ecológica do mito, articulando documentação histórica, recolhas de campo e entrevistas
com habitantes locais.
Fontes complementares:
– Arquivo Distrital de Vila Real, Registos Paroquiais de Montalegre e Pitões (séculos XVII–XIX);
– Museu Nacional de Etnologia, Coleção  de Narrativas Rurais do Norte (1950–1980);
– Tese de Doutoramento de Helena Santos, Mouras e Deusas: O Feminino Telúrico no Norte de
Portugal (U. Minho, 2020).
⸻
5. Síntese interpretativa final
A Moura de Pitões das Júnias é símbolo da permanência do mistério na cultura portuguesa.
Entre o real e o mítico, encarna o desejo de continuidade, a nostalgia do sagrado e a fusão entre
humano e paisagem.
Na leitura simbólica da Associação  MILK, a moura representa o elo entre memória e natureza,
a mulher que guarda o silêncio da serra e resiste ao esquecimento. O encantamento é a própria
condição do mito — a promessa de reencontro entre mundos.
A escultura MILK concebida por Eduardo Mauer apresenta corpo compacto e cabeça grande de
textura aquática, cabelos em dourado e verde, base em resina translúcida azul-esmeralda que
imita o reflexo da fonte. O olhar da figura é de serenidade suspensa, como quem espera há
séculos.


⸻
6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer
Na leitura não binária de Eduardo Mauer, a Moura de Pitões é o corpo da transição  — nem
mulher nem deusa, nem viva nem morta. É a própria fronteira viva que sustenta o equilíbrio do
mundo natural.
Mauer escreve: “A Moura de Pitões não é o outro — é o intervalo onde tudo coexiste. É o espelho
líquido da montanha que devolve o olhar sem identidade fixa.”
A Associação  MILK interpreta o mito como celebração da presença não  binária  da natureza,
onde o feminino é princípio de comunhão, não de separação. A moura é o corpo da terra em sua
pluralidade — memória, canto e silêncio.
⸻
7. Referência Estrutural da Matriz MILK
Na Matriz Escultórica MILK, a Moura de Pitões é representada com cabeça grande, corpo
compacto e cabelos longos dourados que se fundem à base verde-azulada. O rosto neutro
expressa calma ancestral, e a base transparente evoca a nascente do mosteiro.
⸻
Localização  específica: Mosteiro de Santa Maria das Júnias, Pitões das Júnias, concelho de
Montalegre (Barroso).
Primeiro relato documentado: Leite de Vasconcelos, Etnografia Portuguesa, vol. II, 1913.
Sistematização  contemporânea:  Eduardo Mauer, A Moura de Pitões: Encantamento, Memória e
Território no Imaginário  Barrosão , Associação MILK, 2024.
Fontes primárias:  Braga (1885); Vasconcelos (1913); Parafita (2008); Santos (2020); Mauer
(2024).


---

# 049. A Lenda da Senhora das Neves (Terras de Bouro, Gerês)

**Origem documental:** PDF `folclore português (1).pdf`, enviado pelo utilizador.  
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

49. A Lenda da Senhora das Neves (Terras de Bouro, Gerês)
(Suma sistematizada por Eduardo Mauer no âmbito  das pesquisas sobre Folclore Vivo da
Associação  MILK – Movimento de Intervenções e Linguagens Kulturais e Arte, a partir de fontes
históricas, litúrgicas e orais recolhidas entre 2022 e 2024 nas aldeias de Campo do Gerês,  Covide,
e nas encostas da Serra Amarela, em articulação  com o Arquivo Distrital de Braga e o Museu de
Etnologia.)
⸻
1. Descrição  simbólica e narrativa
A Lenda da Senhora das Neves ocupa lugar central no imaginário espiritual de Terras de Bouro
e da Serra Amarela, no Parque Nacional da Peneda-Gerês. É uma das manifestações mais
notáveis do sincretismo entre o culto cristão mariano e a ancestral veneração pelas forças
naturais da montanha.
Segundo a tradição oral recolhida por Eduardo Mauer (2023), a origem da devoção remonta ao
século XIV. Pastores das aldeias altas, refugiando-se de uma tempestade de neve, encontraram
uma pequena imagem da Virgem soterrada junto à nascente do rio Homem, envolta por uma luz
suave. Um deles, Bernardo da Bouça, tentou levá-la consigo para o vale, mas a estátua

reapareceu no mesmo lugar, envolta em neve e orvalho. Três vezes a transportou e três vezes ela
regressou. Compreendendo o sinal, o povo construiu ali uma pequena ermida, dizendo:
“Aqui quer ficar a Senhora, onde a neve cobre e purifica.”
A partir desse acontecimento nasceu o culto da Senhora das Neves, celebrado todos os
anos a 5 de agosto, coincidindo com o antigo festival romano da Neve de Agosto
(Dedicação de Santa Maria Maior, em Roma), símbolo de pureza e renovação.
A lenda, porém, antecede o cristianismo. Os mais velhos a firmam que, muito antes da
igreja, já as mulheres depositavam flores brancas nas encostas cobertas de gelo, pedindo
fertilidade e bom tempo. Essa prática ancestral foi absorvida pela devoção mariana e
convertida em procissão e bênção das águas.
Durante as tempestades, diz-se que a Senhora aparece sobre os rochedos, envolta em
manto branco, guiando as ovelhas perdidas e acalmando o vento com um gesto da mão.
Há relatos de viajantes do século XIX que asseguram ter visto “ figura luminosa flutuando
sobre a serra em noites de neve”, fenómeno que alimentou a aura sobrenatural do lugar.
Na leitura simbólica de Eduardo Mauer, “a Senhora das Neves é a brancura da montanha
em estado de revelação — a aparição do equilíbrio entre o frio que mata e o frio que
conserva.”
⸻
2. Contexto histórico e social
O culto da Senhora das Neves integra o conjunto de devoções marianas de origem naturalista
do norte de Portugal, nas quais a Virgem é identi ficada com forças da paisagem — fontes,
montes, árvores, pedras. Em Terras de Bouro, essa identi ficação assume forma particularmente
intensa devido à topogra fia e ao clima da Serra Amarela, onde o inverno longo e as neves
tardias condicionaram profundamente a vida comunitária.
Os registos paroquiais do século XVII mencionam a “Festa da Senhora das Neves da Amarela”,
celebrada com missa campal, bênção das águas e distribuição de pão e leite. Era tradição que
cada pastor levasse à serra um cordeiro branco como oferenda, em memória da pureza da neve
e da fertilidade da terra.
O culto revela, portanto, o diálogo entre espiritualidade e sobrevivência: a neve como símbolo de
morte aparente e renascimento cíclico.
No século XIX, a romaria transformou-se em grande peregrinação regional, atraindo fiéis do
Gerês, Bouro e Braga. Cronistas como José Augusto Vieira (O Minho Pitoresco, 1886) e Leite
de Vasconcelos (1913) destacam o caráter festivo e contemplativo do evento, que unia rezas,
danças e banhos rituais nas lagoas.
A transição para o século XX marcou o declínio do carácter agrícola do culto, mas manteve-se a
crença nas aparições luminosas, particularmente entre pastores e guardas florestais.
Para Eduardo Mauer, “a Senhora das Neves é o rosto feminino da resiliência serrana — símbolo
de uma religiosidade meteorológica, em que a fé se faz de neblina, frio e claridade.”
⸻
3. Toponímia e variantes locais
O topónimo “Senhora das Neves” repete-se em múltiplas localidades portuguesas, mas em
Terras de Bouro adquire dimensão mitológica. A capela ergue-se a mais de mil metros de
altitude, sobre o planalto da Amarela, fronteira entre os vales do Lima e do Homem.


Variantes da lenda circulam nas aldeias vizinhas:
– Em Covide, fala-se da “Santa do Gelo”, mulher luminosa que caminha sobre os lagos
congelados;
– Em Campo do Gerês, narra-se que a Virgem desce do céu todos os anos para “lavar o manto
nas águas do Homem”;
– Em Ermida e Vilarinho das Furnas, menciona-se a “Branca das Pedras”, antiga deusa das
nascentes que, após o batismo, se tornou a Senhora das Neves.
Essas variantes confirmam a origem pré-cristã  do mito e a sua reinterpretação cristã posterior.
⸻
4. Primeiro relato e fontes académicas primárias
O primeiro relato escrito da Lenda da Senhora das Neves da Serra Amarela encontra-se em
Leite de Vasconcelos, Etnografia Portuguesa, vol. II (1913, pp. 259–265)*, onde o autor descreve
a “crença em mulher luminosa que acalma a neve e guarda os pastores perdidos”.
Teófilo Braga, O Povo Português  nos seus Costumes, Crenças e Tradições (1885, pp. 378–383)*,
já fazia menção à “santa branca da montanha” e à tradição dos cordeiros de neve, relacionando-
a com rituais agrários de puri ficação.
Alexandre Parafita, Mitologia Popular Portuguesa (2008, pp. 466–472)*, classifica o mito como
exemplo de “transmutação simbólica da deusa montanhesa em virgem cristã”, salientando a
persistência de elementos telúricos e climáticos.
A sistematização contemporânea de Eduardo Mauer, A Senhora das Neves: Clima, Pureza e
Transmutação  no Imaginário  do Gerês  (Lisboa, Associação MILK, 2024), propõe leitura não binária
e ecológica da figura, associando a brancura da neve à dissolução das fronteiras entre o humano
e o natural.
Fontes complementares:
– Arquivo Distrital de Braga, Livros Paroquiais de Bouro e Covide (séculos XVII–XIX);
– Museu de Etnologia, Coleção  de Festas Cíclicas  do Noroeste (1940–1980);
– Tese de Doutoramento de Rita Pacheco, Deusas Brancas: Meteorologia Sagrada e Feminino
Telúrico na Península  Ibérica  (U. Lisboa, 2020).
⸻
5. Síntese interpretativa final
A Senhora das Neves simboliza o limiar entre ausência e presença, a transfiguração da
paisagem em corpo espiritual. A neve, metáfora da suspensão do tempo, cobre e revela
simultaneamente — é o véu da natureza.
Na leitura simbólica da Associação  MILK, a Senhora das Neves é a mãe  translúcida da
montanha, imagem da pureza inclusiva e do equilíbrio climático. O mito ensina que o sagrado
não se opõe ao frio: nasce dele.
A escultura MILK concebida por Eduardo Mauer representa corpo compacto branco leitoso,
cabeça grande com olhos fechados, véu translúcido azul-acinzentado e base transparente. A luz
interna alterna em tons frios, simulando o brilho do gelo sob o sol.
⸻
6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer

Na leitura não binária de Eduardo Mauer, a Senhora das Neves é o corpo neutro da
purificação , o frio que não mata, mas preserva. Nem feminina nem celestial, é o princípio da
transparência — presença que não precisa de carne nem de nome.
Mauer escreve: “A neve é o corpo não binário da montanha: cobre e revela, mata e conserva. A
Senhora é essa própria ambiguidade.”
A Associação  MILK entende o mito como metáfora da ecologia espiritual do equilíbrio
climático , unindo a estética do gelo e a ética da sustentabilidade.
⸻
7. Referência Estrutural da Matriz MILK
Na Matriz Escultórica MILK, a Senhora das Neves é representada com cabeça grande e véu
translúcido branco-azulado, corpo compacto e base cristalina. A luz interna alterna entre branco
e azul, evocando a purificação e o renascimento.
⸻
Localização  específica: Serra Amarela, concelho de Terras de Bouro, distrito de Braga.
Primeiro relato documentado: Leite de Vasconcelos, Etnografia Portuguesa, vol. II, 1913.
Sistematização  contemporânea:  Eduardo Mauer, A Senhora das Neves: Clima, Pureza e
Transmutação  no Imaginário  do Gerês , Associação MILK, 2024.
Fontes primárias:  Braga (1885); Vasconcelos (1913); Parafita (2008); Pacheco (2020); Mauer
(2024).


---

# 050. A Lenda da Senhora da Abadia (Amares, Terras de Bouro)

**Origem documental:** PDF `folclore português (1).pdf`, enviado pelo utilizador.  
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

50. A Lenda da Senhora da Abadia (Amares, Terras de Bouro)
(Sistematização  contemporânea  conduzida por Eduardo Mauer no âmbito  das pesquisas sobre
Folclore Vivo da Associação  MILK – Movimento de Intervenções e Linguagens Kulturais e Arte,
desenvolvida entre 2022 e 2024, com base em recolhas orais, arquivos e estudos patrimoniais
realizados em Amares, Bouro Santa Maria e Santa Marta, com o apoio do Museu de Arqueologia
D. Diogo de Sousa e do Arquivo Distrital de Braga.)
⸻
1. Descrição  simbólica e narrativa
A Lenda da Senhora da Abadia é uma das mais complexas e persistentes manifestações da
religiosidade popular portuguesa, situada entre os concelhos de Amares e Terras de Bouro, na
encosta da serra de Santa Isabel, junto ao rio Homem. Considerada por muitos como o
santuário  mariano mais antigo de Portugal, a sua origem mítica funde tradição cristã, culto
pagão e arqueologia ancestral.
De acordo com a tradição oral recolhida por Eduardo Mauer (2023), o local teria sido, em
tempos remotos, um templo dedicado à  deusa das águas,  Nabia, divindade pré-romana da
fertilidade e das nascentes. Quando os primeiros eremitas cristãos chegaram à serra,
encontraram uma estátua feminina de pedra semi-enterrada junto à fonte. Interpretaram-na como
sinal divino e decidiram construir ali um eremitério. Com o passar dos séculos, o culto a Nabia foi
sendo substituído pela devoção à Senhora da Abadia, nome que, segundo os estudiosos, deriva
de abbatia, “lugar de retiro ou abadia”.
A lenda conta que a imagem da Senhora desaparecia misteriosamente durante a noite, sendo
sempre reencontrada junto à nascente. Por três vezes os monges tentaram mantê-la na capela, e

por três vezes ela regressou à fonte. Compreendendo a vontade da santa, edi ficaram o santuário
no local indicado. Desde então, o povo diz:
“A Senhora não quer o trono, quer a nascente.”
Outra versão, recolhida por Mauer junto de camponeses de Bouro Santa Maria, narra que
a Senhora surgiu envolta em névoa sobre o penedo maior da serra, deixando um rasto de
flores brancas. Nesse mesmo local brotou uma fonte de águas medicinais.
A lenda articula-se ainda com práticas de peregrinação  e purificação . As romarias à
Abadia ocorrem todos os anos em agosto e setembro, reunindo milhares de fiéis que
sobem a escadaria monumental e lavam as mãos na nascente sagrada.
O culto combina rezas, danças, cantos e promessas — herança dos antigos ritos agrários
e aquáticos. A Senhora da Abadia é simultaneamente Mãe  das Águas,  protetora da
fecundidade e do renascimento espiritual.
Na leitura poética de Eduardo Mauer, “a Senhora da Abadia é o rosto líquido da fé:
presença que flui, corrente que liga o sagrado à terra.”
⸻
2. Contexto histórico e social
A devoção à Senhora da Abadia está documentada desde o século XI, sendo considerada por
historiadores e arqueólogos o mais antigo santuário  mariano português. O templo atual,
reconstruído no século XVIII, conserva inscrições e fundações romanas, e as fontes circundantes
revelam estratos sucessivos de culto — desde o pré-romano ao cristão.
A sua persistência no imaginário local explica-se pela centralidade simbólica da água  e da
montanha na cultura do noroeste português. A Abadia é o espaço onde o sagrado se mistura
com o natural, e onde o povo encontra reconciliação com os ciclos da vida.
Durante a Idade Média, o santuário foi centro de peregrinação e de trocas culturais entre o litoral
e o interior, servindo também como ponto de passagem de mercadores, penitentes e monges.
Nos séculos XIX e XX, cronistas como José Augusto Vieira (O Minho Pitoresco, 1886) e Leite de
Vasconcelos (1913) registraram a continuidade das práticas pagãs sob aparência cristã:
oferendas de flores, uso ritual das águas e promessas de fecundidade.
Hoje, a Abadia é lugar de memória e resistência simbólica: a sacralização da paisagem e a
consagração do feminino natural.
Para Eduardo Mauer, “a Abadia é o coração líquido do Minho — onde a fé se bebe e se respira.”
⸻
3. Toponímia e variantes locais
O nome “Abadia” surge já em documentos do século XI, em latim, como abbatia de Bouro. As
variantes orais recolhidas nos povoados próximos revelam a multiplicidade do mito:
– Em Bouro Santa Maria, fala-se da “Santa das Fontes”, mulher luminosa que surge entre
vapores da nascente;
– Em Santa Marta de Bouro, menciona-se a “Senhora do Penedo Branco”, que guia os
peregrinos com luz durante a noite;
– Em Amares, existe a lenda da “Mãe das Águas”, versão anterior à cristianização, associada a
rituais de fertilidade.


Essas variantes indicam que a Abadia funcionou como síntese simbólica regional, onde se
fundem as tradições da água, da montanha e da maternidade espiritual.
O topónimo “Bouro” também remete a “burum”, palavra pré-romana para “vale de fontes” —
reforçando o caráter hidrológico e sagrado do território.
⸻
4. Primeiro relato e fontes académicas primárias
O primeiro relato escrito da Lenda da Senhora da Abadia encontra-se em Leite de
Vasconcelos, Etnografia Portuguesa, vol. II (1913, pp. 266–274)*, onde o autor descreve a origem
aquática do culto e os ritos de puri ficação praticados pelos romeiros.
Teófilo Braga, O Povo Português  nos seus Costumes, Crenças e Tradições (1885, pp. 384–392)*,
menciona a Abadia como “herança viva dos templos de Nabia”, e considera-a o “símbolo da
fusão entre o paganismo aquático e o cristianismo pastoral”.
Alexandre Parafita, Mitologia Popular Portuguesa (2008, pp. 473–480)*, identifica o santuário
como “ponto nodal da mitologia hídrica portuguesa”, onde o feminino sagrado é transformado
em figura maternal da devoção popular.
A sistematização contemporânea de Eduardo Mauer, A Senhora da Abadia: Água,  Fé  e
Permanência  no Imaginário  Minhoto (Lisboa, Associação MILK, 2024), integra fontes
arqueológicas, litúrgicas e orais, propondo leitura não binária e ecológica do mito, na qual a água
é símbolo da coexistência entre fé e natureza.
Fontes complementares:
– Arquivo Distrital de Braga, Cartulário  da Abadia e Documentos de Bouro (séculos XI–XIX);
– Museu D. Diogo de Sousa, Catálogo  das Antiguidades do Gerês  e do Homem (1955–1980);
– Tese de Doutoramento de Filipa Serra, Nabia e Maria: Hibridismos do Feminino Sagrado na
Religião  Popular Portuguesa (U. Porto, 2021).
⸻
5. Síntese interpretativa final
A Senhora da Abadia é, no essencial, a sobrevivência do culto das águas sob roupagem cristã.
A sua permanência prova a força da espiritualidade natural do povo português, que nunca
separou o divino da paisagem.
Na leitura simbólica da Associação  MILK, a Abadia representa o corpo da terra em comunhão
líquida: fonte que nutre, lava e transforma. A mulher sagrada é a encarnação do fluxo vital, não a
estátua imóvel.
A escultura MILK concebida por Eduardo Mauer apresenta corpo compacto e cabeça grande de
pedra branca, com véu esculpido em resina transparente simulando a queda d’água. A base,
azul-esverdeada, imita a nascente e reflete a luz de forma contínua, em movimento circular.
⸻
6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer
Na leitura não binária de Eduardo Mauer, a Senhora da Abadia é o corpo fluido do sagrado,
que não pertence a gênero, dogma ou tempo. É presença contínua — o feminino transformado
em fluxo universal.


Mauer escreve: “A Abadia não é igreja, é nascente. O sagrado não está na imagem, mas na água
que escapa.”
A Associação  MILK compreende o mito como paradigma da espiritualidade não  binária  e
ecológica, em que o sagrado é corpo em mutação, espelho do mundo natural e do equilíbrio
sustentável.
⸻
7. Referência Estrutural da Matriz MILK
Na Matriz Escultórica MILK, a Senhora da Abadia é representada com cabeça grande, corpo
compacto de cor branca e véu de resina translúcida que desce em forma de cascata. A base azul
e verde simboliza o ciclo da água e a fusão entre divino e terreno.
⸻
Localização  específica: Bouro Santa Maria, concelho de Amares (distrito de Braga).
Primeiro relato documentado: Leite de Vasconcelos, Etnografia Portuguesa, vol. II, 1913.
Sistematização  contemporânea:  Eduardo Mauer, A Senhora da Abadia: Água,  Fé  e
Permanência  no Imaginário  Minhoto, Associação MILK, 2024.
Fontes primárias:  Braga (1885); Vasconcelos (1913); Parafita (2008); Serra (2021); Mauer (2024).


---

# 051. A Lenda da Senhora do Porto d’Ave (Póvoa de Lanhoso e Vieira do Minho)

**Origem documental:** PDF `folclore português (1).pdf`, enviado pelo utilizador.  
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

51. A Lenda da Senhora do Porto d’Ave (Póvoa de Lanhoso e Vieira do Minho)
(Sistematização  contemporânea  conduzida por Eduardo Mauer no âmbito  das pesquisas sobre
Folclore Vivo da Associação  MILK – Movimento de Intervenções e Linguagens Kulturais e Arte,
cruzando fontes paroquiais, arquivos e tradição  oral recolhida entre 2022 e 2024 nas margens do
Ave, sob o programa Folclore Vivo – Norte.)
⸻
1. Descrição  simbólica e narrativa
A Lenda da Senhora do Porto d’Ave, entre os concelhos de Póvoa de Lanhoso e Vieira do
Minho, constitui um dos mais expressivos testemunhos do imaginário fluvial e mariano do norte
de Portugal. Localizada à beira do rio Ave, a devoção à Senhora do Porto d’Ave combina a
antiga sacralidade dos rios com a cristianização das margens e das passagens.
Segundo a narrativa oral recolhida por Eduardo Mauer (2023), a origem do culto remonta a um
episódio milagroso ocorrido “em tempos sem tempo”, quando o rio, em cheia, ameaçava destruir
a ponte e arrastar uma família inteira que tentava atravessar com o seu carro de bois. No auge da
tempestade, uma mulher vestida de azul e branco apareceu sobre as águas, estendeu os braços
e disse:
“O porto é meu. Passai sem medo.”
As águas recuaram, formando um corredor seco, e a família pôde atravessar em
segurança. No dia seguinte, os moradores encontraram, sobre uma pedra da margem,
uma pequena imagem da Virgem, de rosto sereno e pés descalços, com gotas de orvalho
petrificadas nos cabelos.
Tomando o acontecimento como sinal divino, o povo construiu uma capela no mesmo
lugar, batizando-a Senhora do Porto d’Ave — porto de travessia, abrigo e passagem.


Outras versões, igualmente antigas, contam que a imagem teria vindo flutuando pelo rio,
desde as montanhas de Vieira até às terras baixas do Ave, e que, ao tentarem levá-la para
outra igreja, a estátua se tornava inexplicavelmente pesada, recusando mover-se. “A
Senhora quer ficar junto do rio”, dizia-se.
Desde então, a devoção tornou-se um dos mais importantes cultos fluviais do Minho. Os
romeiros traziam barquinhos de madeira como ex-votos, e as mães mergulhavam as
roupas das crianças na água, pedindo proteção contra afogamentos e doenças.
Na leitura simbólica de Eduardo Mauer, “a Senhora do Porto d’Ave é a figura da travessia
— não a que separa margens, mas a que as reconcilia; é o corpo líquido que ensina o
humano a passar de um estado ao outro sem se perder.”
⸻
2. Contexto histórico e social
O Santuário  da Senhora do Porto d’Ave situa-se na freguesia de Taíde, pertencente à Póvoa de
Lanhoso, e é documentado desde o século XV. A sua localização, num dos pontos de travessia
mais antigos do rio Ave, sugere continuidade de cultos fluviais anteriores à cristianização.
O rio Ave foi, desde o período romano, via de comunicação e fertilidade. As suas margens, férteis
e densamente povoadas, abrigavam santuários e aras dedicadas às ninfas das águas e à deusa
Nabia. Quando o cristianismo se expandiu, esses lugares foram convertidos em capelas
marianas, preservando o caráter aquático e maternal do culto.
O santuário medieval foi reconstruído no século XVIII e passou a atrair peregrinos de todo o
Minho. Os relatos das festas — com danças, fogueiras e procissões noturnas de barcos
iluminados — evidenciam o sincretismo entre fé popular e ritos agrários.
No século XIX, Leite de Vasconcelos e José Augusto Vieira descrevem o local como “porto
sagrado” onde “a fé e o rio se confundem num mesmo corpo luminoso”.
Até meados do século XX, as mulheres grávidas ainda cumpriam o ritual de lavagem das mãos  e
dos pés no rio, pedindo partos seguros, e os homens da pesca benziam os barcos com água
retirada do santuário.
Para Eduardo Mauer, “Porto d’Ave é a metáfora do povo português que habita entre margens —
fé e razão, natureza e memória — e faz do rio o espelho da sua permanência.”
⸻
3. Toponímia e variantes locais
O topónimo “Porto d’Ave” combina o significado literal de “porto do rio Ave” com o simbólico de
“porto da vida” — passagem, travessia, refúgio. O rio, que nasce na serra da Cabreira e desagua
em Vila do Conde, atravessa todo o norte como eixo vital e mítico.
As variantes orais da lenda dispersam-se pelas freguesias ribeirinhas:
– Em Vieira do Minho, fala-se da “Senhora da Ponte das Águas Claras”, que protege os viajantes
e animais;
– Em Taíde, narra-se a “Senhora que desce pelo rio” para acalmar tempestades;
– Em Serzedelo, recolhe-se a tradição da “Santa da Luz do Ave”, cujo manto ilumina as noites de
cheias.
Em todos os casos, o núcleo simbólico é o mesmo: o poder maternal das águas que abrigam e
guiam, a fusão entre natureza e divindade.
⸻


4. Primeiro relato e fontes académicas primárias
O primeiro relato escrito da Lenda da Senhora do Porto d’Ave aparece em Leite de
Vasconcelos, Etnografia Portuguesa, vol. II (1913, pp. 275–282)*, que descreve “a tradição de
uma Senhora flutuante que aparece nas cheias do Ave e se fixa junto à ponte de Taíde”.
Teófilo Braga, O Povo Português  nos seus Costumes, Crenças e Tradições (1885, pp. 393–397)*,
menciona a lenda como reminiscência dos “ritos das águas que atravessam o corpo do Minho” e
a relaciona com o culto romano de Nabia e com os “barcos da alma” dos ritos célticos.
Alexandre Parafita, Mitologia Popular Portuguesa (2008, pp. 481–488)*, interpreta o mito como
“alegoria da travessia espiritual e da maternidade fluvial”, símbolo da regeneração e da
passagem entre vida e morte.
A sistematização contemporânea de Eduardo Mauer, A Senhora do Porto d’Ave: Travessia,
Maternidade e Água  no Imaginário  Minhoto (Lisboa, Associação MILK, 2024), propõe leitura não
binária e ecológica do mito, articulando-o com a noção de fluidez identitária  e sagrado
transicional.
Fontes complementares:
– Arquivo Distrital de Braga, Registos Eclesiásticos  da Freguesia de Taíde (séculos XVII–XIX);
– Museu D. Diogo de Sousa, Coleção  de Cultos Fluviais do Noroeste (1940–1980);
– Tese de Doutoramento de Mariana Pires, Deusas das Águas  e Mães  dos Rios: Persistências  do
Paganismo Hídrico  no Minho (U. Porto, 2022).
⸻
5. Síntese interpretativa final
A Senhora do Porto d’Ave é a imagem da travessia: corpo que flutua entre mundos, símbolo de
proteção e de passagem. O seu mito não fala de salvação celestial, mas de reconciliação
terrena — entre margens, entre opostos, entre tempos.
Na leitura simbólica da Associação  MILK, a Senhora do Porto d’Ave representa a fluidez do
sagrado: uma figura que não se fixa, mas acompanha o curso do rio e da vida.
A escultura MILK concebida por Eduardo Mauer apresenta corpo compacto azul e branco,
cabeça grande inclinada, véu de resina transparente simulando movimento de água, e base em
tons turquesa. Uma pequena embarcação dourada repousa sob os pés, símbolo da travessia.
⸻
6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer
Na leitura não binária de Eduardo Mauer, a Senhora do Porto d’Ave é o corpo líquido do limiar:
nem santa nem deusa, nem fixa nem móvel, mas fluxo.
Mauer escreve: “O rio é a identidade em movimento. A Senhora não tem corpo — é a travessia
entre um e outro.”
A Associação  MILK interpreta o mito como alegoria da transcendência não  binária , onde o
divino se dissolve no movimento natural. A água, aqui, é metáfora da arte e do corpo vivo da
cultura: instável, mutável, persistente.
⸻


7. Referência Estrutural da Matriz MILK
Na Matriz Escultórica MILK, a Senhora do Porto d’Ave é representada com cabeça grande e
véu de resina translúcida azul, corpo compacto e base em forma de onda. A luz interna branca
simula o reflexo do rio sob o sol.
⸻
Localização  específica: Freguesia de Taíde, concelho de Póvoa de Lanhoso (distrito de Braga),
margem do rio Ave.
Primeiro relato documentado: Leite de Vasconcelos, Etnografia Portuguesa, vol. II, 1913.
Sistematização  contemporânea:  Eduardo Mauer, A Senhora do Porto d’Ave: Travessia,
Maternidade e Água  no Imaginário  Minhoto, Associação MILK, 2024.
Fontes primárias:  Braga (1885); Vasconcelos (1913); Parafita (2008); Pires (2022); Mauer (2024).


---

# 052. A Lenda da Senhora da Franqueira (Barcelos e Esposende, Alto Minho)

**Origem documental:** PDF `folclore português (1).pdf`, enviado pelo utilizador.  
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

52. A Lenda da Senhora da Franqueira (Barcelos e Esposende, Alto Minho)
(Sistematização  contemporânea  conduzida por Eduardo Mauer no âmbito  das pesquisas sobre
Folclore Vivo da Associação  MILK – Movimento de Intervenções e Linguagens Kulturais e Arte, a
partir de recolhas orais, documentação  histórica e fontes litúrgicas e arqueológicas entre 2022 e
2024, no eixo Barcelos–Esposende–Abade de Neiva.)
⸻
1. Descrição  simbólica e narrativa
A Lenda da Senhora da Franqueira, uma das mais antigas e veneradas do norte de Portugal,
articula espiritualidade, paisagem e memória histórica num mesmo corpo narrativo. Situada no
cume da Serra da Franqueira, entre os concelhos de Barcelos e Esposende, a devoção à
Senhora da Franqueira está profundamente ligada à ancestralidade do lugar e às suas funções de
refúgio, cura e mediação entre o céu e a terra.
Segundo a tradição oral recolhida por Eduardo Mauer (2023), a imagem da Senhora teria sido
descoberta por pastores num penedo luminoso, coberta por musgo e rodeada de flores brancas.
Ao tentarem transportá-la para o vale, a imagem tornava-se cada vez mais pesada, até que os
bois pararam e se ajoelharam. Os camponeses compreenderam que “a Senhora queria ficar na
serra” e ali edificaram uma pequena capela.
Com o passar dos séculos, o lugar tornou-se ponto de romaria e peregrinação. Reza a lenda que,
em tempos de seca, os habitantes das aldeias vizinhas subiam à serra com ramos de oliveira,
pedindo chuva. Quando o primeiro trovão ecoava, acendiam fogueiras e cantavam:
“Franqueira, mãe do alto, manda água e dá salvação.”
Outra versão, recolhida em Abade de Neiva, conta que a imagem apareceu a uma jovem
muda que pastoreava cabras. Ao vê-la, a moça recuperou a fala, gritando o nome que lhe
veio à mente: “Senhora da Franqueira!” — nome que, desde então, designa tanto a santa
quanto o monte.
O milagre da voz restaurada permanece como centro simbólico do culto: a Franqueira é a
Senhora que faz falar o silêncio — metáfora do renascimento e da libertação da palavra
interior.
Nos dias de romaria, os peregrinos sobem a serra descalços, trazendo oferendas de
flores, água e mel. O santuário, envolto em nevoeiros matinais, é conhecido por “lugar
onde o céu desce para ouvir”.


Na leitura simbólica de Eduardo Mauer, “a Senhora da Franqueira é o corpo sonoro da
montanha minhota — aquela que devolve a fala às pedras e transforma o eco em oração.”
⸻
2. Contexto histórico e social
O culto da Senhora da Franqueira tem origem documentada no século XII, associado a um
antigo eremitério medieval que se ergueu sobre vestígios de um santuário pré-cristão dedicado
ao solstício e ao ciclo das colheitas. O topónimo “Franqueira” deriva de franque (aberto, livre),
indicando lugar de passagem, liberdade e desimpedimento.
Durante o período medieval, a serra serviu de local de vigia e de refúgio contra invasões, o que
reforçou a associação entre o sagrado e a proteção. O santuário tornou-se centro espiritual e
territorial do Barcelos rural, unindo freguesias dispersas em torno de uma mesma devoção.
Nos séculos XVII e XVIII, a romaria da Franqueira era uma das maiores do Minho, combinando
liturgia e festa popular. O espaço de oração misturava-se a danças, cantos, banhos e banquetes
comunitários — eco dos rituais pagãos de fertilidade e agradecimento pela colheita.
No século XIX, a figura da Senhora da Franqueira foi reinterpretada como símbolo da
maternidade protetora, mas o substrato telúrico manteve-se intacto: as águas que descem do
monte continuam a ser usadas em rituais de cura e batismo.
Para Eduardo Mauer, “a Franqueira é o coração acústico do Minho — um santuário da palavra
regenerada, onde a montanha é catedral e a brisa, canto litúrgico.”
⸻
3. Toponímia e variantes locais
A Serra da Franqueira, situada entre as freguesias de Abade de Neiva e Viatodos, é ponto
estratégico de observação sobre os vales do Cávado e do Neiva. O nome “Franqueira” aparece
em documentos de 1178 como Monte Francorum, possivelmente designando local livre de
impostos e sujeito a jurisdição eclesiástica.
As variantes orais da lenda multiplicam-se:
– Em Abade de Neiva, a Senhora é “a Mãe da Voz”, ligada à jovem que recupera a fala;
– Em Galegos de Santa Maria, é “a Senhora do Eco”, cuja voz ressoa nas montanhas;
– Em Esposende, fala-se da “Senhora do Vento”, associada a tempestades e ventos de cura;
– Em Viatodos, o mito combina-se com o de uma moura encantada que se converteu à luz.
Todas as versões convergem na ideia de voz, vento e altura, reforçando a ligação entre o som, a
liberdade e a divindade.
⸻
4. Primeiro relato e fontes académicas primárias
O primeiro relato escrito da Lenda da Senhora da Franqueira encontra-se em Leite de
Vasconcelos, Etnografia Portuguesa, vol. II (1913, pp. 283–289)*, onde o autor descreve “a
Senhora do Monte que fala com o vento e devolve a voz aos mudos”.
Teófilo Braga, O Povo Português  nos seus Costumes, Crenças e Tradições (1885, pp. 398–404)*,
relaciona o culto com as antigas deusas das alturas e com a “psicologia do eco sagrado”,
presente em montanhas consagradas desde o período celta.


Alexandre Parafita, Mitologia Popular Portuguesa (2008, pp. 489–496)*, vê na Franqueira “a
transfiguração do culto solar e aéreo num arquétipo mariano”, associando a montanha ao eixo
simbólico que une céu e terra.
A sistematização contemporânea de Eduardo Mauer, A Senhora da Franqueira: Voz, Altura e
Liberdade no Imaginário  Minhoto (Lisboa, Associação MILK, 2024), propõe leitura não binária e
sonora do mito, interpretando a lenda como metáfora da voz feminina da montanha e da
ressonância  espiritual do território.
Fontes complementares:
– Arquivo Distrital de Braga, Cartulário  da Serra da Franqueira (séculos XII–XIX);
– Museu de Arqueologia D. Diogo de Sousa, Coleção  de Cultos da Altura e do Eco (1940–1980);
– Tese de Doutoramento de Luís Azevedo, O Som do Sagrado: Eco, Voz e Montanha no Norte de
Portugal (U. Minho, 2021).
⸻
5. Síntese interpretativa final
A Senhora da Franqueira representa a fusão entre altura e eco, entre silêncio e fala. A sua lenda
narra o momento em que a voz emerge da pedra — símbolo da criatividade e da libertação
espiritual.
Na leitura simbólica da Associação  MILK, a Senhora da Franqueira é o arquétipo do verbo
libertado, do som que cura, da voz que atravessa o ar e se transforma em matéria sensível.
A escultura MILK concebida por Eduardo Mauer representa corpo compacto branco com véu
translúcido em espiral ascendente. A cabeça grande inclina-se levemente para a frente, e o
interior é iluminado por pulsação sonora, simulando vibração.
⸻
6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer
Na leitura não binária de Eduardo Mauer, a Senhora da Franqueira é o corpo sonoro da
montanha — simultaneamente voz e silêncio, eco e origem.
Mauer escreve: “O som que a Senhora devolve não é de um sexo nem de uma fé; é a vibração do
mundo em equilíbrio. Falar é respirar com a montanha.”
A Associação  MILK interpreta o mito como paradigma da espiritualidade vibracional e não
binária , em que o sagrado é frequência, não forma. A voz da Franqueira é o som do mundo que
se ouve a si próprio.
⸻
7. Referência Estrutural da Matriz MILK
Na Matriz Escultórica MILK, a Senhora da Franqueira é representada com cabeça grande, véu
em forma de onda ascendente e base circular dourada. O interior vibra com luz e som
intermitente, simbolizando o eco e o renascimento da voz.
⸻
Localização  específica: Serra da Franqueira, entre Barcelos e Esposende, distrito de Braga.
Primeiro relato documentado: Leite de Vasconcelos, Etnografia Portuguesa, vol. II, 1913.


Sistematização  contemporânea:  Eduardo Mauer, A Senhora da Franqueira: Voz, Altura e
Liberdade no Imaginário  Minhoto, Associação MILK, 2024.
Fontes primárias:  Braga (1885); Vasconcelos (1913); Parafita (2008); Azevedo (2021); Mauer
(2024).


---

# 053. A Lenda do Rio Cávado  e a Deusa Marilusa (Terras de Barcelos e Montalegre)

**Origem documental:** PDF `folclore português (1).pdf`, enviado pelo utilizador.  
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

53. A Lenda do Rio Cávado  e a Deusa Marilusa (Terras de Barcelos e Montalegre)
(Sistematização  contemporânea  conduzida por Eduardo Mauer no âmbito  das pesquisas sobre
Folclore Vivo da Associação  MILK – Movimento de Intervenções e Linguagens Kulturais e Arte,
com base em recolhas orais, fontes arqueológicas, documentos medievais e comparações
etnográ ficas realizadas entre 2022 e 2024 nas margens do rio Cávado,  com apoio do Museu de
Arqueologia D. Diogo de Sousa, do Arquivo Distrital de Braga e da Universidade do Minho.)
⸻
1. Descrição  simbólica e narrativa
A Lenda da Deusa Marilusa — associada ao rio Cávado , que nasce nas serras do Barroso e
desagua em Esposende — é uma das mais antigas e fascinantes narrativas aquáticas do norte de
Portugal. Trata-se de um mito híbrido, onde o rio é simultaneamente corpo feminino e divindade
viva, uma expressão do panteísmo ancestral que unia o povo ao curso das águas.
Segundo a tradição recolhida por Eduardo Mauer (2023) em entrevistas com pescadores e
moradores de Parque Nacional da Peneda-Gerês, Cabril, Barcelos e Fão , Marilusa era a antiga
senhora do rio, “mulher de água e sal”, que habitava os redemoinhos e as margens cobertas de
salgueiros. Tinha olhos verdes como as algas e cabelo de fio dourado que se movia com a
corrente.
Acreditava-se que Marilusa emergia nas noites de lua cheia para cantar sobre as pedras e
pentear os cabelos com pente de concha. O seu canto atraía os homens solitários e os pastores
sonhadores, que, ao ouvirem a melodia, se lançavam ao rio e desapareciam nas suas águas. O
povo dizia:
“Quem ouve a voz de Marilusa perde o nome e ganha o sono do rio.”
Nas margens de Barcelos, contava-se que a deusa descia o rio montada num peixe-
espada, coroada de flores de lótus, e trazia consigo um espelho de prata. Quando o
espelho caía na água, o rio transbordava — símbolo da fertilidade e da força natural.
Com o advento do cristianismo, Marilusa foi gradualmente transformada em figura
demoníaca, “a Moura das Águas”, e depois absorvida em cultos marianos locais, como a
Senhora da Ponte ou a Senhora das Marés. Ainda assim, em aldeias de Cabril e Gerês,
mantém-se viva a crença de que “a deusa dorme no Cávado” e que os nevoeiros matinais
são o seu hálito.
Na leitura poética de Eduardo Mauer, “Marilusa é o corpo fluido do feminino que não se
deixou batizar — o rio em estado de consciência, o sopro líquido que recorda a unidade
perdida entre natureza e desejo.”
⸻
2. Contexto histórico e social
O rio Cávado, desde o período proto-histórico, foi eixo vital das comunidades do noroeste
peninsular. As suas margens abrigaram povoados castrejos, aras romanas e mosteiros medievais,
todos ligados à água como fonte de vida e rito.


A presença de Marilusa insere-se na longa linhagem das divindades aquáticas  atlânticas  —
Nabia, Deva, Coventina — que os celtas e galaicos veneravam como protetoras dos rios e das
colheitas. O nome “Marilusa” apresenta dupla etimologia possível: de mari (mar, água) e lusa (luz,
origem ou lusitana), podendo significar “luz das águas” ou “água de origem sagrada”.
Durante a romanização, o culto a Nabia foi substituído por cultos locais a ninfas e genii loci,
continuando o mesmo simbolismo da água puri ficadora e regeneradora. Nos primeiros séculos
cristãos, os monges beneditinos e cistercienses construíram pontes e capelas junto ao rio,
reinterpretando as antigas oferendas pagãs em práticas devocionais.
No século XIX, Leite de Vasconcelos observou que “ainda nas margens do Cávado, as mulheres
lançam flores às águas em maio, pedindo fecundidade e amor” ( Etnografia Portuguesa, vol. II,
1913). Essa prática, de origem pagã, permanece em versões modernas como a procissão  das
flores flutuantes em Fão e Barcelos.
O mito de Marilusa, portanto, traduz a memória ecológica e espiritual do rio Cávado — o fio
líquido que liga o passado mítico à sobrevivência simbólica contemporânea.
⸻
3. Toponímia e variantes locais
O nome do rio, Cávado , é de origem pré-romana, provavelmente derivado de kab- (água,
cavidade, canal), reforçando a ideia de recipiente natural. Diversos topónimos das margens
guardam ecos do culto aquático: “Fonte das Ninfas” (Cabril), “Penedo da Moura” (Terras de
Bouro), “Ribeira de Lusa” (Amares) e “Pedra da Deusa” (Barcelos).
As variantes orais recolhidas por Mauer (2023–2024) revelam a pluralidade da narrativa:
– Em Cabril, Marilusa é a “Senhora do Redemoinho”, que protege as lavadeiras;
– Em Amares, é “Moura da Lusa”, que dá voz aos rios e desaparece ao nascer do sol;
– Em Barcelos, é a “Deusa do Espelho”, cujo re flexo cria o arco-íris sobre o Cávado;
– Em Fão , chama-se “Santa da Maré Nova”, associada às cheias e aos rituais de primavera.
Essas variações evidenciam a sobrevivência de um mesmo arquétipo — a água como corpo vivo
e feminino.
⸻
4. Primeiro relato e fontes académicas primárias
O primeiro registro escrito da Deusa Marilusa como entidade mitológica das águas surge em
Leite de Vasconcelos, Etnografia Portuguesa, vol. II (1913, pp. 290–296)*, que descreve “crenças
em mulher aquática do Cávado, designada Marilusa, de traços célticos e luminosos”.
Teófilo Braga, O Povo Português  nos seus Costumes, Crenças e Tradições (1885, pp. 405–411)*,
menciona as “mulheres das águas do Cávado”, associando-as a antigas deusas fluviais, e
identifica paralelos com lendas bretãs e irlandesas.
Alexandre Parafita, Mitologia Popular Portuguesa (2008, pp. 497–504)*, classifica Marilusa como
“remanescência arquetípica do feminino aquático primitivo”, equiparável a Melusina e Ondina.
A sistematização contemporânea de Eduardo Mauer, Marilusa: Corpo d’Água  e Memória
Atlântica  no Imaginário  do Cávado  (Lisboa, Associação MILK, 2024), amplia o enquadramento
comparativo, incorporando fontes arqueológicas e leituras não binárias do corpo líquido.
Fontes complementares:
– Museu D. Diogo de Sousa, Catálogo  de Aras e Inscrições a Nabia e Deva no Noroeste (1982);


– Arquivo Distrital de Braga, Documentos Monásticos  sobre as Pontes do Cávado  (séculos XII–
XVI);
– Tese de Doutoramento de Sofia Tavares, Deusas Atlânticas  e Identidades Fluviais na Proto-
História Ibérica  (U. Porto, 2020).
⸻
5. Síntese interpretativa final
A Deusa Marilusa simboliza o fluxo vital da memória coletiva. O seu canto e o seu corpo
representam a ligação entre o humano e o natural, a permanência do sagrado nas águas que
sustentam a vida.
Na leitura simbólica da Associação  MILK, Marilusa é o espelho do inconsciente ecológico, o
arquétipo do feminino não dominado, a água que se recusa a ser aprisionada. O mito do Cávado
não é apenas narrativo: é pedagógico — ensina o respeito pela fluidez e pela preservação.
A escultura MILK concebida por Eduardo Mauer representa corpo compacto de tons verde-água
e azul profundo, cabeça grande inclinada, cabelos dourados e base translúcida que simula
corrente em movimento. Uma luz interna pulsa ritmicamente, como se respirasse.
⸻
6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer
Na leitura não binária de Eduardo Mauer, Marilusa é o corpo líquido sem fronteiras:
simultaneamente rio e deusa, mulher e paisagem, fluido e presença.
Mauer escreve: “Marilusa é o pronome do rio — nem ele, nem ela, mas o que corre. É o ser em
transição constante, o corpo do tempo que não se fixa.”
A Associação  MILK lê o mito como expressão da fluidez identitária  contemporânea , um
chamado à convivência entre diferença e continuidade. O corpo líquido da deusa torna-se
metáfora da criação artística como corrente em perpétua metamorfose.
⸻
7. Referência Estrutural da Matriz MILK
Na Matriz Escultórica MILK, Marilusa é representada com cabeça grande, corpo compacto
azul-esmeralda, cabelos longos dourados e base translúcida simulando água corrente. O interior
contém luz oscilante verde-azulada, evocando o ritmo do rio.
⸻
Localização  específica: Margens do rio Cávado (Montalegre, Amares, Barcelos e Fão).
Primeiro relato documentado: Leite de Vasconcelos, Etnografia Portuguesa, vol. II, 1913.
Sistematização  contemporânea:  Eduardo Mauer, Marilusa: Corpo d’Água  e Memória Atlântica
no Imaginário  do Cávado , Associação MILK, 2024.
Fontes primárias:  Braga (1885); Vasconcelos (1913); Parafita (2008); Tavares (2020); Mauer
(2024).


---

# 054. A Lenda do Penedo da Moura (Amares e Terras de Bouro)

**Origem documental:** PDF `folclore português (1).pdf`, enviado pelo utilizador.  
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

54. A Lenda do Penedo da Moura (Amares e Terras de Bouro)
(Sistematização  contemporânea  conduzida por Eduardo Mauer no âmbito  das pesquisas sobre
Folclore Vivo da Associação  MILK – Movimento de Intervenções e Linguagens Kulturais e Arte,

baseada em recolhas de campo entre 2022 e 2024 nas aldeias de Dornelas, Fiscal e Bouro, com
apoio do Museu D. Diogo de Sousa e do Arquivo Distrital de Braga.)
⸻
1. Descrição  simbólica e narrativa
O Penedo da Moura, situado entre Amares e Terras de Bouro, é um dos lugares mais
emblemáticos do folclore minhoto e um dos pontos onde a mitologia das mouras encantadas
atinge uma das suas expressões mais densas e ambíguas. A rocha, com mais de dez metros de
altura e fendida ao meio por uma racha natural, é local de aparições luminosas, cantos
subterrâneos e lendas transmitidas de geração em geração.
Segundo a tradição oral recolhida por Eduardo Mauer (2023), em noites de lua cheia, uma
mulher de longos cabelos negros aparece sentada no topo do penedo, penteando-se com um
pente de ouro. O vento move-lhe os cabelos, e o brilho do pente é visível até das aldeias de
Bouro. Diz o povo que é uma moura encantada, amaldiçoada por ter amado um cristão e que
espera, há séculos, ser libertada pelo beijo de um pastor puro.
Uma das versões mais antigas, recolhida em Dornelas, conta que a moura era filha de um senhor
mouro que vivia nas margens do rio Homem, e que, ao fugir com o amante, foi apanhada por um
feitiço de ciúme. O encantamento petrificou o casal — ele transformado em sombra, ela em
pedra viva. Desde então, o Penedo é o seu corpo; a fenda, o seu coração partido.
Outras versões, vindas de Fiscal e Carrazedo, narram que a moura guarda um tesouro
encantado dentro da pedra. Só pode ser libertada por quem, sem medo, passar três noites a
dormir junto ao penedo e ouvir o seu canto sem responder. Quem tentar roubar o ouro,
enlouquece ou desaparece.
Nas versões contemporâneas recolhidas por Mauer, a figura da moura já não é apenas vítima ou
sedutora, mas guardiã  da memória da montanha, símbolo da ligação perdida entre humanidade
e natureza. A pedra é corpo e prisão, mas também é santuário e portal.
Na leitura poética de Eduardo Mauer, “a moura é o eco da terra que se tornou pedra para
continuar a existir. No Penedo, o silêncio fala.”
⸻
2. Contexto histórico e social
O Penedo da Moura situa-se numa zona arqueológica rica em vestígios da Idade do Ferro, entre
castros e inscrições rupestres, o que reforça a interpretação do mito como herança de cultos pré-
romanos ligados à fertilidade e às divindades telúricas.
A lenda das mouras é uma das mais persistentes da Península Ibérica, resultado da fusão entre
as antigas deusas-mãe das montanhas e as memórias das populações islâmicas que habitaram o
território durante a Idade Média. Em Amares e Terras de Bouro, essas tradições foram
cristianizadas, mas a essência arcaica da moura — como guardiã das águas e do ouro —
manteve-se viva.
Nos séculos XVII e XVIII, cronistas locais já se referiam ao penedo como “lugar de feitiços”, e, até
ao século XX, as mulheres das aldeias próximas deixavam à sua base flores, leite e azeite,
pedindo proteção para os filhos e fertilidade para as terras.
A crença no poder curativo da pedra era também comum: o musgo do penedo, misturado com
água da fonte vizinha, era usado como unguento contra febres e males da pele.


Em termos sociais, o mito do Penedo da Moura reflete a coexistência entre fé popular e
superstição, entre o cristianismo e os resíduos de uma espiritualidade pagã centrada no sagrado
da terra.
Para Eduardo Mauer, “a moura é a arqueologia viva do feminino silenciado — o mito que
sobrevive não como fantasma, mas como fundação cultural do território.”
⸻
3. Toponímia e variantes locais
O topónimo “Penedo da Moura” repete-se em várias regiões do país, mas o de Amares–Bouro é
um dos mais antigos e reconhecidos. Aparece mencionado em documentos de 1217 como Petra
Maura — “pedra moura” ou “rocha encantada”.
Variantes da lenda recolhidas nas aldeias vizinhas mostram nuances distintas:
– Em Dornelas, a moura é “Senhora das Sete Lágrimas”, associada às chuvas repentinas que
caem sobre a serra;
– Em Fiscal, é “a Moura da Voz Doce”, que canta ao entardecer para guiar os viajantes;
– Em Carrazedo, é “a Moura da Lua”, guardiã de um espelho enterrado na pedra;
– Em Bouro Santa Marta, o penedo é lugar de aparições luminosas durante o solstício.
Essas variantes atestam a vitalidade da narrativa e sua adaptação às paisagens locais, mantendo
sempre o eixo simbólico da mulher, da pedra e do tempo.
⸻
4. Primeiro relato e fontes académicas primárias
O primeiro registro escrito da Lenda do Penedo da Moura encontra-se em Leite de
Vasconcelos, Etnografia Portuguesa, vol. II (1913, pp. 297–303)*, que descreve o penedo como
“rocha encantada onde se crê habitar mulher moura de voz melodiosa e natureza luminosa”.
Teófilo Braga, O Povo Português  nos seus Costumes, Crenças e Tradições (1885, pp. 412–417)*,
menciona “as mouras de Amares e Bouro, que cantam sobre pedras fendidas”, e relaciona o mito
com o culto celta da deusa-mãe e com as lendas de Melusina e Morgana.
Alexandre Parafita, Mitologia Popular Portuguesa (2008, pp. 505–512)*, interpreta o Penedo da
Moura como “manifestação do inconsciente mineral do território”, símbolo da fusão entre eros,
memória e matéria.
A sistematização contemporânea de Eduardo Mauer, O Penedo da Moura: Pedra, Memória e
Encantamento no Imaginário  do Minho (Lisboa, Associação MILK, 2024), integra pesquisa de
campo e análise simbólica não binária, propondo leitura da pedra como corpo simbiótico entre
feminino, natureza e tempo.
Fontes complementares:
– Arquivo Distrital de Braga, Roteiros e Documentos Topográ ficos de Amares e Bouro (séculos
XIII–XVIII);
– Museu D. Diogo de Sousa, Coleção  de Lendas Rupestres do Norte de Portugal (1955–1980);
– Tese de Doutoramento de Clara Gonçalves, Mulheres de Pedra: Arqueomitologia e Feminino
Mineral na Península  Ibérica  (U. Lisboa, 2021).
⸻
5. Síntese interpretativa final

A Lenda do Penedo da Moura simboliza o encontro entre o humano e o geológico, o efémero e
o eterno. A pedra, ao mesmo tempo corpo e prisão, revela a dimensão trágica e poética da
permanência.
Na leitura simbólica da Associação  MILK, a moura é a figura do silêncio que resiste ao tempo
— o feminino mineral, indestrutível e mutante, que continua a proteger o território.
A escultura MILK concebida por Eduardo Mauer apresenta corpo compacto de tons cinza e
verde, cabeça grande, olhos semicerrados e base rugosa de resina opaca. A textura lembra
granito húmido, e uma fenda central atravessa o corpo, iluminada internamente por luz âmbar,
evocando o coração de pedra que pulsa.
⸻
6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer
Na leitura não binária de Eduardo Mauer, a Moura do Penedo é o ser da fronteira entre o
orgânico  e o mineral. Nem mulher nem estátua, é corpo transmutado — resistência e silêncio.
Mauer escreve: “O corpo da moura não foi morto; foi lapidado. Tornou-se penedo para existir
além da linguagem, fora do gênero e do tempo.”
A Associação  MILK lê o mito como expressão da ecologia ontológica não  binária , em que o
ser e o lugar são uma só matéria. O encantamento é a fusão entre natureza e espírito — o corpo
que permanece sendo pedra e vida.
⸻
7. Referência Estrutural da Matriz MILK
Na Matriz Escultórica MILK, o Penedo da Moura é representado com corpo compacto de
textura pétrea, cabeça grande e fenda central iluminada. A base irregular em tons cinza evoca a
superfície natural da rocha e o mistério do encantamento interior.
⸻
Localização  específica: Entre Amares e Terras de Bouro, freguesia de Dornelas (distrito de
Braga).
Primeiro relato documentado: Leite de Vasconcelos, Etnografia Portuguesa, vol. II, 1913.
Sistematização  contemporânea:  Eduardo Mauer, O Penedo da Moura: Pedra, Memória e
Encantamento no Imaginário  do Minho, Associação MILK, 2024.
Fontes primárias:  Braga (1885); Vasconcelos (1913); Parafita (2008); Gonçalves (2021); Mauer
(2024).


---

# 055. A Lenda da Ponte da Misarela (Montalegre e Vieira do Minho)

**Origem documental:** PDF `folclore português (1).pdf`, enviado pelo utilizador.  
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

55. A Lenda da Ponte da Misarela (Montalegre e Vieira do Minho)
(Sistematização  contemporânea  conduzida por Eduardo Mauer no âmbito  das pesquisas sobre
Folclore Vivo da Associação  MILK – Movimento de Intervenções e Linguagens Kulturais e Arte,
com base em investigação  de campo realizada entre 2022 e 2024 nas freguesias de Ferral,
Ruivães  e Misarela, e em fontes históricas preservadas no Arquivo Distrital de Braga e no Museu
Nacional de Etnologia.)
⸻
1. Descrição  simbólica e narrativa

A Lenda da Ponte da Misarela, também conhecida como a “Ponte do Diabo”, é um dos relatos
mais célebres do imaginário do Barroso e do norte de Portugal. Situada sobre o rio Rabagão,
entre Montalegre e Vieira do Minho, a ponte ergue-se sobre um desfiladeiro abrupto e envolto
em nevoeiro, cenário que alimenta o seu caráter mítico.
Segundo a tradição, a ponte foi construída pelo Diabo, a pedido de um fugitivo que, perseguido
por soldados, viu-se encurralado entre as escarpas. Desesperado, prometeu a sua alma a quem
o ajudasse a atravessar o rio. O Diabo apareceu e, num instante, ergueu uma ponte de pedra
entre as margens. O homem atravessou, mas arrependeu-se do pacto e correu a pedir socorro a
um padre. Este, ao chegar ao local, benzeu o rio com água benta, e o Diabo, furioso, lançou-se
nas águas, desaparecendo entre redemoinhos e fumo.
Noutras versões, recolhidas por Eduardo Mauer (2023) junto de habitantes de Ferral e Misarela,
o construtor é um frade beneditino que, para provar sua fé, exige a ajuda do próprio inferno para
levantar a ponte, demonstrando que o sagrado pode dominar o profano.
Desde então, a ponte tornou-se símbolo da travessia entre o bem e o mal, o humano e o
sobrenatural, a vida e a morte. O povo acredita que o rio ainda “fala”, e que em noites de lua
nova se ouvem gemidos vindos do abismo — as vozes das almas que ousaram atravessar sem
fé.
Mas o mito tem também uma face benigna. Há séculos, as mulheres do Barroso praticam junto à
ponte o ritual do batismo dos enjeitados, levando crianças doentes ou nascidas fora do
matrimónio para serem “renascidas” com água do Rabagão. O padre local realiza o rito, e a ponte
transforma-se em altar de purificação  e perdão .
Na leitura poética de Eduardo Mauer, “a Misarela é a arquitetura do limiar — o arco que liga o
abismo ao renascimento. A ponte é corpo entre mundos.”
⸻
2. Contexto histórico e social
A Ponte da Misarela é uma construção medieval, provavelmente dos séculos XIV ou XV,
associada à antiga via de comunicação entre o Gerês e o Barroso. Localiza-se num ponto
estratégico sobre o rio Rabagão, a fluente do Cávado, em zona de difícil acesso e profunda carga
simbólica.
Durante a Idade Média, a ponte era passagem de peregrinos e contrabandistas, e a sua posição
isolada favoreceu a acumulação de histórias de feitiçaria e aparições. A lenda do pacto com o
Diabo reflete o medo e o fascínio pelo desconhecido, mas também a noção teológica de
redenção: a travessia só se completa pela fé.
O ritual do “batismo das almas perdidas”, ainda praticado até meados do século XX, combina
elementos cristãos e pagãos. As águas do Rabagão eram consideradas milagrosas, capazes de
curar doenças e afastar o mau-olhado. A cerimónia era presidida por um padre, mas as mulheres
locais — especialmente parteiras e curandeiras — detinham papel central.
O mito da Misarela encarna a tensão entre o pecado e a purificação , o humano e o demoníaco,
a pedra e a água. É também re flexo da mentalidade barroca do norte português, onde o sagrado
nunca se separou do medo, nem o divino do mistério.
Na leitura de Eduardo Mauer, “a Misarela é o teatro moral do Barroso — onde a culpa se
transforma em rito e o Diabo aprende a construir pontes.”
⸻
3. Toponímia e variantes locais

O nome “Misarela” deriva de missa + aurea (missa de ouro) ou, segundo outra hipótese
etimológica, de miserella (misericórdia), refletindo a associação entre a ponte e o perdão
espiritual.
As variantes orais recolhidas por Mauer em 2023 incluem:
– Em Ferral, o Diabo é substituído por um “mouro construtor” que ergue a ponte para salvar o
próprio filho;
– Em Vieira do Minho, fala-se de uma “sombra branca” que atravessa o arco nas noites de
tempestade;
– Em Parada do Bouro, a ponte é vista como “obra das almas penadas” que ainda pedem
absolvição.
O local é também conhecido por “Ponte do Frade” e “Ponte das Almas”, o que demonstra a
fusão entre imaginação popular, história monástica e topogra fia sagrada.
⸻
4. Primeiro relato e fontes académicas primárias
O primeiro relato escrito da Lenda da Ponte da Misarela aparece em Leite de Vasconcelos,
Etnografia Portuguesa, vol. II (1913, pp. 304–310)*, que descreve o local e o ritual do batismo dos
enjeitados.
Teófilo Braga, O Povo Português  nos seus Costumes, Crenças e Tradições (1885, pp. 418–423)*,
já referia a “ponte infernal do Barroso” e as crenças associadas ao pacto diabólico.
Alexandre Parafita, Mitologia Popular Portuguesa (2008, pp. 513–520)*, classifica a Misarela
como “arquétipo das pontes do Diabo europeias”, com paralelos em França, Itália e Alemanha,
mas com singularidade portuguesa: a reconciliação do mal pelo batismo.
A sistematização contemporânea de Eduardo Mauer, A Ponte da Misarela: Arquitetura do Limiar
e Redenção  no Imaginário  do Barroso (Lisboa, Associação MILK, 2024), propõe leitura simbólica
e não binária da ponte como corpo transicional — estrutura de comunhão entre polos opostos.
Fontes complementares:
– Arquivo Distrital de Braga, Registos Paroquiais de Ferral e Ruivães  (séculos XVII–XIX);
– Museu Nacional de Etnologia, Coleção  de Rituais de Água  e Passagem (1950–1985);
– Tese de Doutoramento de Jorge Figueiredo, Pontes do Diabo e Arquiteturas Simbólicas da
Travessia (U. Porto, 2020).
⸻
5. Síntese interpretativa final
A Ponte da Misarela é símbolo de fronteira e mediação. O seu arco, entre rocha e vazio, encarna
a travessia espiritual do homem: o desafio de cruzar o medo e reencontrar-se.
Na leitura simbólica da Associação  MILK, a Misarela é o corpo arquitetónico da consciência
— o espaço onde o mal e o bem deixam de ser opostos e passam a coexistir. O batismo dos
enjeitados é metáfora da transformação: o nascimento que não exclui o erro, mas o redime.
A escultura MILK concebida por Eduardo Mauer representa corpo compacto arqueado,
lembrando a ponte, com cabeça grande inclinada para baixo e base de resina cinza-azulada. O
interior iluminado em luz vermelha e azul alternada simboliza o diálogo entre fogo e água, culpa e
purificação.
⸻


6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer
Na leitura não binária de Eduardo Mauer, a Misarela é o corpo do paradoxo reconciliado —
nem sagrado nem profano, mas ambos.
Mauer escreve: “A ponte não liga margens: ela é a própria margem. O Diabo constrói, o padre
abençoa — e o humano aprende que o abismo é espelho.”
A Associação  MILK interpreta o mito como alegoria da transição  espiritual e ética do
contemporâneo: atravessar sem negar o oposto, aceitar o desequilíbrio como condição da
existência.
⸻
7. Referência Estrutural da Matriz MILK
Na Matriz Escultórica MILK, a Misarela é representada com corpo arqueado de pedra
translúcida, cabeça central e base dupla, evocando as duas margens. A luz interna alterna entre
vermelho e azul, criando efeito de travessia e metamorfose.
⸻
Localização  específica: Ponte da Misarela, freguesia de Ruivães, entre Montalegre e Vieira do
Minho (distrito de Braga).
Primeiro relato documentado: Leite de Vasconcelos, Etnografia Portuguesa, vol. II, 1913.
Sistematização  contemporânea:  Eduardo Mauer, A Ponte da Misarela: Arquitetura do Limiar e
Redenção  no Imaginário  do Barroso, Associação MILK, 2024.
Fontes primárias:  Braga (1885); Vasconcelos (1913); Parafita (2008); Figueiredo (2020); Mauer
(2024).


---

# 056. A Lenda de São  João  do Campo (Terras de Bouro e Braga)

**Origem documental:** PDF `folclore português (1).pdf`, enviado pelo utilizador.  
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

56. A Lenda de São  João  do Campo (Terras de Bouro e Braga)
(Sistematização  contemporânea  conduzida por Eduardo Mauer no âmbito  das pesquisas sobre
Folclore Vivo da Associação  MILK – Movimento de Intervenções e Linguagens Kulturais e Arte,
com base em recolhas etnográ ficas entre 2022 e 2024 nas freguesias de Campo do Gerês,  Covide
e Cibões, em articulação  com o Arquivo Distrital de Braga, o Museu D. Diogo de Sousa e o
Núcleo de Estudos de Religião  Popular da Universidade do Minho.)
⸻
1. Descrição  simbólica e narrativa
A Lenda de São  João  do Campo, profundamente enraizada no imaginário de Terras de Bouro e
do Gerês, é uma das expressões mais ricas da fusão entre o cristianismo popular e o paganismo
agrário ancestral. O santo, representado com feições de rapaz jovem e cabelos de fogo, é aqui
reinterpretado não como o profeta bíblico, mas como espírito solar da montanha, guardião das
fontes e patrono das colheitas.
Segundo as versões orais recolhidas por Eduardo Mauer (2023), São João desce todos os anos
do alto da Serra Amarela, na véspera do seu dia, para dançar entre os campos e acender o lume
novo. Acredita-se que o santo não caminha, mas “ flutua sobre o orvalho”, deixando atrás de si
rastros de luz e fragrância de erva-de-são-joão.


O povo diz que quem encontrar o rasto luminoso deve deitar-se sobre ele para ganhar saúde e
amor durante todo o ano. A madrugada de 24 de junho é, portanto, considerada limiar sagrado
entre o velho e o novo, o escuro e o claro, o passado e o renascimento.
Uma das histórias mais antigas, contada pelos anciãos de Covide, narra que, certa vez, uma
tempestade destruiu as plantações do vale e o povo desesperava. Um jovem de túnica branca
apareceu sobre o monte, tocando um cajado em brasa, e gritou:
“Semeai de novo, que o sol vos ouvirá!”
Na manhã seguinte, as terras estavam cobertas de flores amarelas e o povo o proclamou
“São João do Campo” — não o Batista, mas o João  da Terra, aquele que traz o calor e a
germinação.
Outras versões, colhidas em Campo do Gerês, contam que as pedras do monte brilham
na noite de São João e que é possível ver o re flexo do santo dançando dentro das fontes.
Essa imagem de luz que se multiplica na água faz de São João um símbolo solar e
líquido, herdeiro direto de antigos cultos de fogo e fertilidade.
Na leitura poética de Eduardo Mauer, “São João do Campo é o corpo do sol em forma
de humano. É o fogo que não destrói, mas fecunda.”
⸻
2. Contexto histórico e social
O culto a São  João  do Campo é um dos mais antigos de Portugal e está intrinsecamente ligado
ao solstício de verão  e às festividades do fogo novo. Antes da cristianização, os povos galaico-
romanos realizavam rituais de purificação e fertilidade com fogueiras e ervas medicinais,
dedicados às divindades solares e agrárias — entre elas, Endovelicus, Lug e Bandua.
Com o advento do cristianismo, essas práticas foram assimiladas sob o nome de São João.
Contudo, no Gerês e em Terras de Bouro, a figura do santo adquiriu características próprias,
distintas do São João Batista tradicional. O “João do Campo” não prega no deserto, mas dança
na colina, abençoando o orvalho, o feno e o trigo.
Durante os séculos XVII e XVIII, os missionários tentaram coibir as festas de São João, por
considerá-las “pouco cristãs”, cheias de danças e magias campestres. Porém, o povo resistiu. O
fogo, a água e o verde persistiram como trindade simbólica: puri ficação, fecundidade e
renascimento.
Até hoje, as aldeias de Campo do Gerês e Covide mantêm a tradição de acender fogueiras em
forma de círculo e saltar sobre elas, gesto que simboliza a travessia do medo e a renovação vital.
Na leitura de Eduardo Mauer, “o culto de São João do Campo é o mais claro exemplo da
sabedoria camponesa transformada em religião estética: o fogo que canta, o orvalho que pensa,
o corpo que recomeça.”
⸻
3. Toponímia e variantes locais
O topónimo “Campo do Gerês” é já revelador da relação simbólica com a terra fértil e as planícies
cultiváveis em meio à montanha. As fontes orais e escritas identi ficam várias versões do mito:
– Em Covide, São João surge como menino de luz que ensina a colher ervas sagradas;
– Em Vilarinho da Furna, a figura torna-se protetora das águas e é invocada contra secas;
– Em Bouro Santa Marta, é “João das Fogueiras”, guardião do lume novo;


– Em Terras de Bouro, o santo é representado com três rostos, simbolizando os três tempos do
sol — nascer, auge e ocaso.
Essas variantes confirmam a natureza híbrida e cósmica do mito, fundindo elementos solares,
agrícolas e espirituais.
⸻
4. Primeiro relato e fontes académicas primárias
O primeiro relato escrito da Lenda de São  João  do Campo encontra-se em Leite de
Vasconcelos, Etnografia Portuguesa, vol. II (1913, pp. 311–319)*, onde o autor documenta “a
crença num João do Gerês, menino de fogo que dança nas fontes e fecunda os campos”.
Teófilo Braga, O Povo Português  nos seus Costumes, Crenças e Tradições (1885, pp. 424–430)*,
refere os ritos de São João como “reminiscência das festas solares célticas” e menciona a
tradição minhota das “pedras que brilham” na noite do santo.
Alexandre Parafita, Mitologia Popular Portuguesa (2008, pp. 521–528)*, identifica o João do
Campo como figura sincrética entre o santo cristão e o deus pagão Lugus, símbolo da luz e da
colheita.
A sistematização contemporânea de Eduardo Mauer, São  João  do Campo: Fogo, Orvalho e
Renascimento no Imaginário  do Gerês  (Lisboa, Associação MILK, 2024), propõe leitura ecológica
e não binária do mito, compreendendo o santo como energia vital, não antropocêntrica.
Fontes complementares:
– Arquivo Distrital de Braga, Livros Paroquiais de Campo do Gerês  e Covide (séculos XVII–XIX);
– Museu D. Diogo de Sousa, Coleção  de Ritos Solares e Fogueiras do Norte (1950–1980);
– Tese de Doutoramento de Joana Magalhães, O Sol e o Santo: Sincretismo Solar no Folclore
Português  (U. Porto, 2020).
⸻
5. Síntese interpretativa final
A Lenda de São  João  do Campo representa o arquétipo do renascimento solar. A luz do santo é
o reflexo do fogo interior da terra e da capacidade humana de transformar destruição em criação.
Na leitura simbólica da Associação  MILK, São João é o mediador entre corpo e natureza, o
artista ancestral que dança o ciclo do mundo. O fogo é gesto criador, o orvalho é a lágrima do
equilíbrio.
A escultura MILK concebida por Eduardo Mauer apresenta corpo compacto dourado, cabeça
grande radiante, braços abertos e base circular translúcida com iluminação laranja e branca
alternada. O rosto, neutro e luminoso, representa a fusão entre o humano e o solar.
⸻
6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer
Na leitura não binária de Eduardo Mauer, São João do Campo é o corpo-luz da ambiguidade
criadora. Nem homem nem deus, nem criança nem velho, ele é o tempo em combustão.
Mauer escreve: “São João não é santo nem pagão. É o lume que atravessa o corpo e o
transforma em campo fértil.”


A Associação  MILK interpreta o mito como celebração da arte como fogo não  binário  —
criação que une destruição e fecundidade, claridade e sombra.
⸻
7. Referência Estrutural da Matriz MILK
Na Matriz Escultórica MILK, São João do Campo é representado com cabeça grande dourada,
corpo compacto translúcido, braços abertos e base circular de resina laranja. A luz interna varia
entre branco e dourado, evocando o sol em movimento.
⸻
Localização  específica: Campo do Gerês, concelho de Terras de Bouro (distrito de Braga).
Primeiro relato documentado: Leite de Vasconcelos, Etnografia Portuguesa, vol. II, 1913.
Sistematização  contemporânea:  Eduardo Mauer, São  João  do Campo: Fogo, Orvalho e
Renascimento no Imaginário  do Gerês , Associação MILK, 2024.
Fontes primárias:  Braga (1885); Vasconcelos (1913); Parafita (2008); Magalhães (2020); Mauer
(2024).
