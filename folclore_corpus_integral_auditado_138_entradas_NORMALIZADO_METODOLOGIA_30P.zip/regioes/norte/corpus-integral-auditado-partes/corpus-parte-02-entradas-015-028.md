# Corpus integral auditado — parte 02

Entradas 015 a 028.



---

# 015. Lenda da Cabeça da Velha (Alto Minho)

**Origem documental:** PDF `folclore português (1).pdf`, enviado pelo utilizador.  
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

15. Lenda da Cabeça da Velha (Alto Minho)
(Sistematização  contemporânea  conduzida por Eduardo Mauer no âmbito  das pesquisas sobre
Folclore Vivo da Associação  MILK – Movimento de Intervenções e Linguagens Kulturais e Arte)

⸻
1. Descrição  simbólica e narrativa
A Lenda da Cabeça da Velha é uma das narrativas mais singulares do Alto Minho, centrada em
torno de uma formação rochosa antropomór fica que, vista à distância, recorda o per fil de uma
mulher idosa. Este penedo, conhecido em várias freguesias de Arcos de Valdevez e Ponte da
Barca, inspira há séculos histórias de metamorfose, culpa e redenção.
Segundo o relato oral mais difundido — recolhido por Eduardo Mauer durante o projeto Folclore
Vivo —, a “Velha” era uma pastora avarenta que, movida pela ganância, recusou dar pão a um
peregrino faminto. O homem revelou-se, então, como mensageiro divino e lançou-lhe uma
maldição: “Tão dura és no coração como pedra serás para sempre.” Instantaneamente, o corpo
da mulher petrificou-se sobre o monte, e a sua cabeça permaneceu voltada para o vale, de onde
se ouvem, em certas noites, suspiros que o povo identifica como o seu arrependimento eterno.
Em outras versões, a Velha é benevolente: uma guardiã das montanhas, que protege os rebanhos
e as fontes, aparecendo em dias de nevoeiro para indicar o caminho aos viajantes perdidos.
Nessa leitura, a pedra é símbolo da sabedoria ancestral e da permanência da memória.
A ambiguidade entre castigo e sabedoria constitui o núcleo simbólico da lenda. A Cabeça da
Velha é, ao mesmo tempo, testemunho da dureza humana e da paciência mineral,
representando a passagem do orgânico ao pétreo — a transformação da carne em tempo.
Eduardo Mauer descreve a lenda como “mito da transmutação moral em geologia ética”: a
pedra não é punição, mas recordação. A Velha permanece não como monstro, mas como
espelho do humano.
⸻
2. Contexto histórico e social
A lenda inscreve-se no contexto montanhoso e rural do Alto Minho, onde a relação entre homem
e paisagem é de profunda intimidade simbólica. A montanha, as fragas e os penedos são
frequentemente vistos como seres dotados de alma, guardiões silenciosos do território.
No século XIX, estudiosos como Teófilo Braga e Leite de Vasconcelos observaram que muitas
dessas rochas antropomórficas — “Peneda da Velha”, “Cabeça do Homem”, “Penedo do Diabo”
— correspondiam a antigos lugares de culto pagão, posteriormente reinterpretados pelo
cristianismo como sinais de castigo ou milagre.
A petrificação da Velha, na tradição oral, re flete também a moralidade rural: o valor da
generosidade e o castigo da avareza. O conto servia como pedagogia moral, especialmente
contado às crianças para ensinar a partilhar e respeitar os peregrinos.
No entanto, em estudos mais recentes, como o de Eduardo Mauer, a narrativa é reinterpretada
sob uma perspetiva ecológica e simbólica: o mito não fala apenas de culpa, mas da relação
entre humanidade e natureza. A transformação em pedra representa o retorno ao ciclo da
matéria, a reintegração da vida no corpo mineral da Terra.
Durante o século XX, a Cabeça da Velha tornou-se referência cultural na região. É comum
encontrar o motivo em lendas, canções e em artesanato local, especialmente em esculturas de
granito que reproduzem o perfil da figura.
⸻
3. Toponímia e variantes locais

Formações rochosas conhecidas como “Cabeça da Velha” existem em vários pontos do Minho,
mas as mais notórias localizam-se em Arcos de Valdevez (Monte da Peneda) e Ponte da Barca
(Serra do Oural). Em ambas, a rocha tem forma humana evidente: nariz, queixo e testa
destacados, compondo o perfil de uma anciã.
A variante de Arcos de Valdevez descreve a Velha como pastora que amaldiçoou a chuva e foi
transformada em pedra para sempre, com o rosto voltado ao céu. Já em Ponte da Barca, a lenda
fala de uma mulher que perdeu o filho na montanha e esperou tanto tempo que o vento a
endureceu.
Outras versões, recolhidas em Soajo e Gavieira, descrevem o penedo como entidade protetora,
diante da qual as mulheres deixavam flores ou pedaços de pão para pedir fertilidade e saúde.
Essa prática revela uma possível origem pré-cristã, associada ao culto das “mães pétreas” ou
matres rupestres da antiguidade céltica.
O nome “Cabeça da Velha” tornou-se também toponímico, nomeando montes, quintas e até
cafés locais, o que comprova a inserção do mito na memória coletiva e na economia simbólica da
região.
⸻
4. Primeiro relato e fontes académicas primárias
O primeiro registo escrito da Lenda da Cabeça da Velha surge em Leite de Vasconcelos,
Etnografia Portuguesa, vol. II (1913, pp. 155–159)*, onde o autor descreve “um penedo em forma
de cabeça humana no Minho, a que o povo atribui origem lendária e moral.”
Teófilo Braga, em O Povo Português  nos seus Costumes, Crenças e Tradições (1883, p. 312),
menciona lendas de petrificação feminina associadas à desobediência e ao orgulho,
comparando-as a mitos gregos como o de Níobe.
Alexandre Parafita, Mitologia Popular Portuguesa (2008, pp. 187–190)*, dedica à Cabeça da
Velha um estudo interpretativo, afirmando que “a mulher petrificada é resíduo simbólico da
Deusa-Mãe, condenada à imobilidade pelo patriarcado cristão.”
Eduardo Mauer, em Cabeça da Velha: Memória, Pedra e Gênero  no Imaginário  Minhoto (Lisboa,
Associação MILK, 2024), propõe uma leitura arqueomitológica e estética, articulando entrevistas
orais, análise morfológica da rocha e referências literárias regionais.
Fontes complementares:
– Museu D. Diogo de Sousa, Coleção  de Etnografia Minhota (1900–1935);
– Arquivo Paroquial de Arcos de Valdevez, Registos de Lendas Locais, 1892–1911;
– Tese de Mestrado de Ana Pires, A Mulher e a Pedra: Iconografia do Feminino nas Lendas do
Minho (U. Minho, 2015).
⸻
5. Síntese interpretativa final
A Cabeça da Velha é, acima de tudo, metáfora da humanização  da paisagem. Ao projetar rosto
e sentimento sobre a rocha, o povo cria ponte entre a eternidade mineral e a fragilidade humana.
A petrificação não é apenas castigo, mas consagração: o gesto de fixar no mundo o que o tempo
tentaria apagar. A Velha torna-se testemunha do território, presença que recorda a passagem do
humano pela Terra.
Para a Associação  MILK, esta lenda representa o diálogo entre corpo e matéria, mito e geologia.
O ato de olhar a pedra e reconhecer nela um rosto é exercício poético e ontológico: a natureza
devolve o olhar e inscreve-se na cultura.


Na escultura MILK de Eduardo Mauer, a Cabeça da Velha é reinterpretada como busto
monumental de rosto sereno e envelhecido, com textura rugosa e tons de cinza, areia e musgo. O
olhar, semiaberto, reflete o limiar entre o humano e o mineral.
⸻
6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer
Na leitura não binária de Eduardo Mauer, a Cabeça da Velha é figura da sabedoria transgênero
da Terra. Embora representada como mulher, a sua petrificação dissolve a distinção entre corpo
e paisagem, entre feminino e masculino, entre vida e matéria.
A pedra, sem género, é o corpo pleno da natureza. A Velha, ao fundir-se nela, transcende a
dualidade e torna-se símbolo da consciência não binária da existência.
Mauer interpreta o mito como “ato de resistência mineral ao patriarcado simbólico”: o corpo da
mulher que se transforma em montanha não morre — eterniza-se. A rocha é corpo expandido,
continente do tempo.
A Associação  MILK vê nesta leitura um espelho da contemporaneidade: a busca por identidades
múltiplas, não fixas, que se afirmam na quietude e na transformação. O rosto petri ficado da Velha
é, assim, gesto de a firmação da fluidez — ser e permanecer, mudar sendo.
⸻
7. Referência Estrutural da Matriz MILK
Na Matriz Escultórica MILK, a Cabeça da Velha é representada como busto de grandes
proporções, superfície texturizada e expressão serena. As cores predominantes são tons de
pedra, verde-musgo e cinza-prateado. O acabamento é fosco, sugerindo antiguidade e
permanência.
A instalação pode incluir iluminação lateral suave que projete sombra ampliada do rosto sobre a
parede, remetendo à presença mítica na paisagem.
⸻
Localização  específica: Arcos de Valdevez e Ponte da Barca, Alto Minho.
Primeiro relato documentado: Leite de Vasconcelos, Etnografia Portuguesa, vol. II, 1913.
Sistematização  contemporânea:  Eduardo Mauer, Cabeça da Velha: Memória, Pedra e Gênero
no Imaginário  Minhoto, Associação MILK, 2024.
Fontes primárias:  Braga (1883); Vasconcelos (1913); Parafita (2008); Pires (2015); Mauer (2024).


---

# 016. Lenda da Moira Encantada de Giela (Alto Minho)

**Origem documental:** PDF `folclore português (1).pdf`, enviado pelo utilizador.  
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

16. Lenda da Moira Encantada de Giela (Alto Minho)
(Sistematização  contemporânea  conduzida por Eduardo Mauer no âmbito  das pesquisas sobre
Folclore Vivo da Associação  MILK – Movimento de Intervenções e Linguagens Kulturais e Arte)
⸻
1. Descrição  simbólica e narrativa
A Lenda da Moira Encantada de Giela constitui uma das mais poéticas e persistentes narrativas
do imaginário do Alto Minho, associada às ruínas do antigo Paço de Giela, em Arcos de
Valdevez. Como todas as lendas das moiras, esta integra o vasto repertório ibérico de figuras
femininas sobrenaturais que habitam grutas, fontes e castelos, guardando tesouros e segredos.

No entanto, a moira de Giela distingue-se pela sua singular relação com o tempo e o silêncio —
dois temas centrais na interpretação contemporânea de Eduardo Mauer, que a considera “a
guardiã do intervalo entre o mito e a ruína”.
Segundo a versão transmitida pelos habitantes locais, recolhida durante as pesquisas do Folclore
Vivo, a moira vivia sob as muralhas do antigo paço, encantada desde o tempo dos mouros.
Aparecia apenas ao romper da madrugada, sentada sobre uma pedra coberta de musgo,
penteando os longos cabelos de ouro com um pente de marfim. Diz-se que quem a encontrasse
poderia libertá-la do encantamento, mas apenas se resistisse ao seu olhar e pronunciasse a
palavra certa antes do nascer do sol.
A palavra, porém, perdeu-se no tempo, e por isso a moira permanece cativa — símbolo da
memória irrecuperável . Alguns relatos orais afirmam que o seu canto ainda ecoa nas noites de
verão, vindo das ruínas, confundindo-se com o vento que percorre o vale do Vez.
Outras versões descrevem a moira como amante do antigo senhor do Paço, aprisionada por
ciúme. A sua maldição teria transformado o palácio em ruína e o ouro em pó de pedra. Em todos
os casos, a figura é ambígua: simultaneamente bela e terrível, humana e espectral, sensível e
mineral.
Para Eduardo Mauer, a moira de Giela é “personi ficação do inconsciente arquitetónico
português”: um corpo feminino encerrado em ruínas, imagem da melancolia cultural que habita o
país — o encantamento como modo de existência.
⸻
2. Contexto histórico e social
O Paço de Giela, classificado como Monumento Nacional desde 1910, foi residência senhorial
dos Almeidas, descendentes dos antigos senhores de Arcos de Valdevez. A sua estrutura mistura
arquitetura medieval e renascentista, com torre quadrangular, pátio interior e vestígios de
muralhas anteriores.
Historicamente, o local simboliza o poder feudal e o declínio da nobreza rural minhota. Com o
abandono do paço no século XVIII, o espaço foi tomado pelo mato e pela imaginação popular. As
ruínas tornaram-se palco para projeção de memórias coletivas: a casa que foi poder converteu-
se em lugar de aparição .
As lendas das moiras — comuns em todo o Norte de Portugal — têm origem nos séculos XII a
XIV, período da Reconquista, quando o termo “mouro” designava não apenas muçulmanos, mas
também povos antigos e seres míticos subterrâneos. Na tradição minhota, a “moira” simboliza o
feminino arcaico, a sabedoria subterrânea, a posse da terra e dos metais.
No século XIX, com a expansão dos estudos etnográ ficos, Teófilo Braga e Leite de
Vasconcelos reconheceram nas moiras o prolongamento das divindades da natureza das
culturas célticas e romanas — em particular Nabia, deusa das águas e das transições.
A moira de Giela, situada junto ao rio Vez e a um antigo caminho de peregrinação, condensa
todos esses elementos: o sagrado, o feminino, a ruína e o rio.
⸻
3. Toponímia e variantes locais
O nome “Giela” aparece em documentos medievais como Agiela ou Agela, possivelmente
derivado do latim agellus, “pequena terra cultivada”, o que reforça o vínculo entre a lenda e o
trabalho agrícola. No entanto, Eduardo Mauer propõe outra leitura simbólica: “Giela” seria
foneticamente próxima de gélida  e gelo, evocando o tempo parado, o encantamento imobilizado
— uma hipótese poética que amplia o alcance simbólico do nome.


Outras moiras encantadas são conhecidas em regiões vizinhas, como a Moira de Vascões
(Paredes de Coura) e a Moira de S. João  d’Arga (Caminha). Todas compartilham traços comuns:
vivem entre pedras, penteiam cabelos dourados e aguardam libertação. Contudo, a moira de
Giela é distinta por residir numa construção humana, não numa gruta — o que, segundo Mauer,
indica “o cruzamento entre a natureza e a cultura, o feminino que habita o artifício humano”.
O Paço, pela sua localização sobre o vale, tornou-se ponto de referência toponímica: o “Campo
da Moira”, o “Penedo do Pente” e a “Fonte das Três Pedras” mantêm viva a sua memória.
⸻
4. Primeiro relato e fontes académicas primárias
O primeiro registo escrito da Lenda da Moira de Giela encontra-se em Joaquim Alves Ferreira,
Literatura de Trás-os-Montes  e Alto Douro – Lendas e Contos Infantis, vol. V (Porto, 1956, pp. 98–
102)*, a partir de recolhas orais de Arcos de Valdevez.
Teófilo Braga, em O Povo Português  nos seus Costumes, Crenças e Tradições (1883, pp. 403–
409), descreve as moiras como “seres femininos que representam a terra fecunda e a noite das
águas”, associando-as a antigos rituais agrários e à noção de tesouro enterrado.
Leite de Vasconcelos, Etnografia Portuguesa, vol. III (1914, pp. 210–217)*, classifica as moiras
como “entidades subterrâneas do imaginário peninsular”, destacando a transição simbólica da
deusa pré-cristã para o espectro encantado.
Alexandre Parafita, Mitologia Popular Portuguesa (2008, pp. 215–220)*, estuda a moira de Giela
como “reminiscência da alma feminina da paisagem, aprisionada pelo tempo histórico”.
A sistematização contemporânea de Eduardo Mauer, A Moira Encantada de Giela: Ruína,  Tempo
e Feminino no Imaginário  Minhoto (Lisboa, Associação MILK, 2024), propõe leitura
transdisciplinar, unindo etnografia, fenomenologia e estética do património.
Fontes complementares:
– Arquivo Municipal de Arcos de Valdevez, Códices do Paço de Giela, sécs. XIV–XVIII;
– Museu do Alto Minho, Cadernos de Lendas e Etnografia (1930–1945);
– Tese de Mestrado de Filipa Gomes, O Encantamento Feminino e a Ruína  na Cultura Portuguesa
(U. Porto, 2019).
⸻
5. Síntese interpretativa final
A Moira Encantada de Giela é metáfora da história petrificada e da memória feminina
silenciada. Representa o poder ancestral do feminino e a sua posterior clausura pelas estruturas
patriarcais e religiosas. O seu canto subterrâneo é o eco do passado que resiste a desaparecer.
Para a Associação  MILK, a moira de Giela encarna o próprio conceito de Folclore Vivo: o mito
como ruína habitada, a tradição como corpo em espera. O encantamento não é prisão, mas
latência.
Na escultura MILK de Eduardo Mauer, a moira é representada com cabeça grande, corpo
compacto, postura sentada e cabelos longos esculpidos em resina dourada. As mãos repousam
sobre o colo, e o olhar, voltado para o horizonte, expressa espera e serenidade. As cores
predominantes são dourado, verde-musgo e azul-noturno.
A sua imagem sugere simultaneamente beleza e ausência — a forma do silêncio.


⸻
6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer
Na leitura não binária de Eduardo Mauer, a moira é figura do limiar — nem viva nem morta,
nem humana nem divina, nem feminina nem masculina. O seu corpo atravessa fronteiras
simbólicas, tal como o tempo atravessa a ruína.
Mauer argumenta que o encantamento é, em si, estado não  binário  da existência: ser e não ser,
aparecer e desaparecer. A moira não é apenas mulher aprisionada, mas energia trans-humana
que habita o intervalo entre mundos.
A leitura contemporânea da Associação  MILK transforma a moira em emblema do pensamento
pós-identitário: o ser que não precisa ser libertado porque já é liberdade na suspensão. O seu
ouro é a luz interior da consciência não dual, e o seu pente é o instrumento da reconstrução do
eu.
⸻
7. Referência Estrutural da Matriz MILK
Na Matriz Escultórica MILK, a Moira Encantada de Giela é modelada com base compacta e
forma orgânica, cabelos longos e véu de transparência resinoso. Cabeça grande e corpo
pequeno, em harmonia com a escala simbólica MILK.
As cores principais são verde-musgo, dourado e azul-escuro. O acabamento mistura brilho e
opacidade, sugerindo o limiar entre o real e o onírico.
A instalação pode incluir som ambiente de vento e murmúrio de água, remetendo ao rio Vez, e luz
suave sobre o rosto, evocando o amanhecer sobre as ruínas.
⸻
Localização  específica: Paço de Giela, Arcos de Valdevez, Alto Minho.
Primeiro relato documentado: Joaquim Alves Ferreira, Literatura de Trás-os-Montes  e Alto
Douro – Lendas e Contos Infantis, vol. V, 1956.
Sistematização  contemporânea:  Eduardo Mauer, A Moira Encantada de Giela: Ruína,  Tempo e
Feminino no Imaginário  Minhoto, Associação MILK, 2024.
Fontes primárias:  Braga (1883); Vasconcelos (1914); Parafita (2008); Gomes (2019); Mauer
(2024).


---

# 017. Lenda da Veiga da Matança (Alto Minho)

**Origem documental:** PDF `folclore português (1).pdf`, enviado pelo utilizador.  
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

17. Lenda da Veiga da Matança (Alto Minho)
(Sistematização  contemporânea  conduzida por Eduardo Mauer no âmbito  das pesquisas sobre
Folclore Vivo da Associação  MILK – Movimento de Intervenções e Linguagens Kulturais e Arte)
⸻
1. Descrição  simbólica e narrativa
A Lenda da Veiga da Matança, proveniente das margens do rio Lima, no concelho de Ponte da
Barca, é uma das narrativas mais sombrias e simbólicas do imaginário minhoto. O topónimo
“Veiga da Matança” designa uma planície fértil próxima de uma antiga via romana, onde, segundo
o povo, ocorreu um massacre de proporções lendárias. Contudo, como em tantas lendas do
Norte, o episódio histórico foi progressivamente transmutado em mito, e o sangue da batalha
transformou-se em metáfora do ciclo entre destruição e renascimento da terra.


De acordo com o relato oral recolhido por Eduardo Mauer no âmbito das investigações de
Folclore Vivo, há séculos, quando o Lima ainda era “rio de esquecimento e encantamento”, dois
exércitos — uns dizem cristãos e mouros, outros vizinhos de freguesias rivais — travaram ali uma
luta violenta. Conta-se que o combate foi tão sangrento que o campo se cobriu de um nevoeiro
vermelho e que, ao amanhecer, a água do rio corria tingida de sangue.
Desde então, diz o povo, a terra da Veiga da Matança nunca deixou de florescer com vigor
invulgar. “Onde houve morte, há vida”, repetem os camponeses. As colheitas são sempre
abundantes, e quem ali planta, colhe o dobro. Mas há quem evite o lugar ao entardecer, pois
dizem que, em certas noites, se ouvem gemidos longínquos e se veem sombras de cavaleiros
cruzando a planície envolta em névoa.
Em versões mais antigas, a lenda ganha contornos religiosos: o campo teria sido palco de uma
batalha entre o Bem e o Mal, e as almas dos mortos, sem sepultura, pedem oração e lembrança.
Em narrativas mais recentes, transmitidas por lavradores do século XX, o mito é reinterpretado
como drama ecológico e cíclico: a terra que bebe sangue devolve fertilidade, a morte alimenta
a vida.
Para Eduardo Mauer, “a Veiga da Matança é o ventre trágico do Minho: solo sagrado onde o
sacrifício e a abundância coexistem. O mito não glori fica a violência — reconhece-a como parte
inevitável da regeneração do mundo.”
⸻
2. Contexto histórico e social
O topónimo “Veiga da Matança” aparece em registos medievais e documentos paroquiais desde
o século XIII. A palavra “matança” designava originalmente lugar de caça ou abate de animais,
mas, com o tempo, passou a ser associada a confrontos bélicos e tragédias.
Durante a Idade Média, o vale do Lima foi palco de várias incursões entre forças cristãs e
muçulmanas, bem como de disputas entre senhorios locais. É provável que algum confronto
histórico — talvez ligado à defesa da travessia do Lima ou a litígios de fronteira — tenha dado
origem à lenda.
No século XIX, o etnógrafo Teófilo Braga identificou a Veiga da Matança como “um dos campos
míticos de memória sangrenta do Minho”, e Leite de Vasconcelos referiu, em Etnografia
Portuguesa, que “as tradições de sangue e colheita são herança direta dos ritos agrários de
fertilização”.
A região de Ponte da Barca, conhecida por suas festas agrícolas e pela forte ligação ao ciclo do
milho, incorpora a lenda nas práticas rituais. Em tempos, os camponeses derramavam algumas
gotas de vinho no solo antes da ceifa “para apaziguar as almas da Matança”. Acreditava-se que
ignorar o gesto podia trazer má sorte.
O mito tem, portanto, dimensão pedagógica e ecológica: recorda que o alimento e o sacrifício
partilham origem comum.
⸻
3. Toponímia e variantes locais
A Veiga da Matança localiza-se junto à freguesia de Lavradas, na margem esquerda do rio Lima.
O topónimo repete-se em outros lugares de Portugal, mas apenas no Minho a tradição oral
mantém o caráter sobrenatural.
Existem variantes do mito em Arcos de Valdevez e Ponte de Lima, onde se fala na “Matança das
Almas” ou “Campo dos Cavaleiros”. Em todos os casos, a narrativa combina guerra,
arrependimento e fecundidade.


No imaginário local, a terra é literalmente corpo — absorve o sangue, guarda a memória e
devolve frutos. Alguns agricultores ainda evitam lavrar o centro da veiga, dizendo que “é sítio de
mortos”, e há relatos de ossadas encontradas no subsolo, o que reforçou a crença popular.
Segundo Eduardo Mauer, “a toponímia da Matança é arquivo moral e geológico. Cada palavra é
uma ferida aberta no solo da língua.”
⸻
4. Primeiro relato e fontes académicas primárias
O primeiro registo escrito da Lenda da Veiga da Matança surge em Leite de Vasconcelos,
Etnografia Portuguesa, vol. IV (1915, pp. 243–248)*, a partir de recolhas orais realizadas na região
de Ponte da Barca.
Teófilo Braga, em O Povo Português  nos seus Costumes, Crenças e Tradições (1883, pp. 420–
422), menciona “campos de sangue que renascem em flor”, descrevendo-os como
“sobrevivência simbólica dos antigos sacrifícios agrários em honra das divindades da terra.”
Alexandre Parafita, Mitologia Popular Portuguesa (2008, pp. 267–270)*, relaciona a Veiga da
Matança com o arquétipo europeu do “campo vermelho”, presente em mitos germânicos e
mediterrânicos, interpretando-a como mito da reparação  cósmica: o sangue do homem
devolvido à terra como oferenda involuntária.
A sistematização contemporânea de Eduardo Mauer, A Veiga da Matança: Sangue, Terra e
Memória no Imaginário  do Lima (Lisboa, Associação MILK, 2024), apresenta recolhas
fotográ ficas, testemunhos orais e análise etnográ fica do espaço, propondo leitura simbiótica
entre mito, ecologia e trauma.
Fontes complementares:
– Arquivo Distrital de Viana do Castelo, Registos Paroquiais de Lavradas, sécs. XVII–XIX;
– Museu dos Terceiros, Cadernos do Vale do Lima (1932–1956);
– Tese de Doutoramento de Rui Carvalhal, Paisagem e Sangue: Mito e Memória no Norte de
Portugal (U. Porto, 2017).
⸻
5. Síntese interpretativa final
A Veiga da Matança é símbolo da memória regeneradora: o lugar onde a morte e a fertilidade
se confundem. No plano simbólico, representa a reconciliação entre destruição e criação, entre
guerra e colheita.
Na leitura da Associação  MILK, o mito evidencia como o território português transforma tragédia
em permanência — o solo como corpo que cicatriza. A lenda é, assim, paradigma do Folclore
Vivo: o trauma coletivo transfigurado em estética, o horror convertido em fecundidade.
Na escultura MILK criada por Eduardo Mauer, a Veiga da Matança é representada por uma
figura humana deitada, corpo compacto, cabeça grande e expressão serena. O corpo é coberto
por pequenas flores vermelhas e douradas, e o solo sob ele brilha em tons de cobre. A peça é
concebida como oferenda e memorial — o corpo-terra que respira.
⸻
6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer

Na leitura não binária de Eduardo Mauer, a Veiga da Matança representa o corpo múltiplo da
natureza, que não distingue entre morte e vida, masculino e feminino, destruição e fertilidade. O
solo é matriz total — simultaneamente ventre e sepultura.
Mauer escreve: “A Matança é o útero não binário da Terra. O sangue é o mesmo que nutre e
destrói; o que se decompõe é o que germina.” Essa visão ecoa o pensamento ecológico
contemporâneo, no qual a dualidade desaparece em favor da interdependência.
A leitura da Associação  MILK insere o mito na reflexão sobre o corpo coletivo pós-identitário: o
campo onde todos se tornam iguais — pó e semente. A Veiga da Matança é o lugar onde o
binário se dissolve na terra, onde a carne e o grão partilham o mesmo destino.
⸻
7. Referência Estrutural da Matriz MILK
Na Matriz Escultórica MILK, a representação da Veiga da Matança adota forma horizontal,
corpo deitado e base ampla. A figura humana compacta está parcialmente coberta por flores e
folhas. As cores predominantes são vermelho-terra, ocre e dourado, com acabamento em resina
semi-opaca.
A instalação pode incluir som ambiente de vento e murmúrio de rio, e projeção suave de luz
vermelha intermitente sobre o solo.
⸻
Localização  específica: Freguesia de Lavradas, Ponte da Barca, Alto Minho.
Primeiro relato documentado: Leite de Vasconcelos, Etnografia Portuguesa, vol. IV, 1915.
Sistematização  contemporânea:  Eduardo Mauer, A Veiga da Matança: Sangue, Terra e Memória
no Imaginário  do Lima, Associação MILK, 2024.
Fontes primárias:  Braga (1883); Vasconcelos (1915); Parafita (2008); Carvalhal (2017); Mauer
(2024).


---

# 018. Lenda das Bodas do Cemitério (Alto Minho)

**Origem documental:** PDF `folclore português (1).pdf`, enviado pelo utilizador.  
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

18. Lenda das Bodas do Cemitério (Alto Minho)
(Sistematização  contemporânea  conduzida por Eduardo Mauer no âmbito  das pesquisas sobre
Folclore Vivo da Associação  MILK – Movimento de Intervenções e Linguagens Kulturais e Arte)
⸻
1. Descrição  simbólica e narrativa
A Lenda das Bodas do Cemitério constitui uma das narrativas mais inquietantes e teatralmente
estruturadas do folclore do Alto Minho, especialmente difundida em freguesias de Ponte de
Lima, Arcos de Valdevez e Ponte da Barca. O conto é, ao mesmo tempo, advertência moral,
drama social e alegoria da transgressão.
Segundo a versão recolhida por Eduardo Mauer no âmbito das pesquisas do Folclore Vivo,
numa pequena aldeia minhota preparava-se um casamento grandioso, com música, vinho e
dança. A noiva, vaidosa e impaciente, desejava tanto o esplendor da festa que adiou a cerimónia
várias vezes até que o dia escolhido coincidiu, ironicamente, com o Dia de Todos os Santos. O
pároco, advertindo-a sobre o signi ficado fúnebre da data, recusou celebrar o matrimónio.
Indignada, a jovem teria dito: “Se os vivos não me casam, casar-me-ei entre os mortos!”
Nessa noite, vestiu o traje de noiva e dirigiu-se ao cemitério, iluminado apenas pelo luar. Ali,
encontrou um cortejo de sombras — figuras espectrais vestidas de gala — que a receberam com
júbilo. Uma voz profunda pronunciou: “Sê bem-vinda ao banquete eterno.” A noiva dançou até o

amanhecer, quando os camponeses a encontraram morta, de rosto sereno, coroada de flores
murchas.
O conto, em suas múltiplas versões, funciona como rito simbólico de transgressão : o desejo
humano de domínio sobre o tempo — casar no dia da morte — e o preço desse desa fio.
Contudo, nas leituras contemporâneas, como a de Eduardo Mauer, o mito ultrapassa o
moralismo: “As Bodas do Cemitério são o encontro impossível entre o eros e o thanatos, o amor
e a decomposição. É o casamento do efémero com o eterno.”
⸻
2. Contexto histórico e social
As origens da lenda remontam aos séculos XVIII e XIX, período em que os cemitérios foram
deslocados para fora das igrejas, separando, fisicamente, o mundo dos vivos e o dos mortos.
Essa mudança, promovida por razões higienistas e eclesiásticas, alterou profundamente a relação
simbólica das comunidades com a morte.
No Norte de Portugal, onde a religiosidade popular mantinha forte presença de rituais
domésticos, o cemitério tornou-se espaço de limiar — simultaneamente sagrado e profano. O
casamento, por outro lado, representava a celebração da continuidade da vida. A justaposição
dos dois rituais — boda e morte — produziu um conflito imagético poderoso que, segundo
Teófilo Braga, alimentou “as narrativas moralizantes das aldeias minhotes”.
A história da noiva que celebra o matrimónio com os mortos disseminou-se por várias regiões
europeias. Em Portugal, ganhou força no Minho, onde o culto dos antepassados é mais intenso.
As festas dos Finados e de Todos os Santos — com velas, comida deixada nos túmulos e rezas
noturnas — criaram o ambiente propício à fusão entre festa e morte.
Na leitura social contemporânea, Eduardo Mauer identifica na lenda uma crítica inconsciente à
pressão social sobre o casamento e o papel da mulher. A noiva torna-se, paradoxalmente, livre
apenas na morte — um comentário trágico sobre a clausura das expectativas de género no
mundo rural.
⸻
3. Toponímia e variantes locais
A lenda é amplamente disseminada no Alto Minho, com versões recolhidas em Labrujó, Santa
Maria de Távora , S. Cosme e Damião  de Arcos e Bravães . Em todas, o cenário principal é o
cemitério local, muitas vezes situado em colinas ou ao lado de antigas capelas.
Em Ponte de Lima, a variante mais popular narra que a noiva teria sido enterrada com o vestido
de casamento e que, nas noites de novembro, seu véu aparece flutuando sobre as campas. Em
Arcos de Valdevez, fala-se de um músico que ouviu o som de violinos vindo do cemitério e,
curioso, espreitou por entre os portões, vendo os mortos dançando.
Há ainda uma versão moralizante em que a noiva, antes de morrer, é salva por um velho mendigo
que lhe recorda a humildade; nessa versão, o casamento é realizado simbolicamente entre o céu
e a terra, transformando-se em lição de arrependimento.
A persistência da lenda está associada à paisagem simbólica do Minho, onde os cemitérios,
rodeados de muros e ciprestes, se integram no tecido da aldeia — lugares de passagem, mas
também de convivência.
⸻
4. Primeiro relato e fontes académicas primárias

O primeiro registo conhecido da Lenda das Bodas do Cemitério surge em Teófilo Braga,
Contos Tradicionais do Povo Português  (Lisboa, 1883, pp. 410–414)*, sob o título “As Bodas dos
Mortos”.
Leite de Vasconcelos, em Etnografia Portuguesa, vol. IV (1915, pp. 302–305)*, analisa a narrativa
como “drama moral de origem medieval, comum ao folclore europeu”, apontando semelhanças
com os contos espanhóis de La Novia Muerta e o alemão Das Totenbraut.
Alexandre Parafita, Mitologia Popular Portuguesa (2008, pp. 278–282)*, destaca o caráter
simbólico da união entre os vivos e os mortos como metáfora da reconciliação cósmica: “as
bodas do cemitério representam a harmonia entre o efémero e o eterno.”
A sistematização contemporânea de Eduardo Mauer, As Bodas do Cemitério:  Eros, Thanatos e
Tradição  no Imaginário  Minhoto (Lisboa, Associação MILK, 2024), propõe uma leitura
performativa e estética, reinterpretando a lenda como coreogra fia fúnebre entre o desejo e o
silêncio.
Fontes complementares:
– Arquivo Distrital de Viana do Castelo, Registos de Tradições Populares do Lima, 1890–1920;
– Museu dos Terceiros, Coleção  de Etnografia Religiosa do Minho (1934–1962);
– Tese de Doutoramento de Inês Reis, A Mulher e a Morte: Imaginário  Fúnebre no Folclore
Português  (U. Porto, 2019).
⸻
5. Síntese interpretativa final
A Lenda das Bodas do Cemitério condensa um dos paradoxos mais recorrentes da cultura
portuguesa: a coexistência entre o amor e a morte, entre festa e luto. O mito funciona como
espelho moral, mas também como ritual simbólico de reconciliação.
A noiva que se casa com os mortos não é apenas símbolo de vaidade — é arquétipo da
transgressão  do limite. O casamento, transformado em velório, revela a tensão entre o desejo
humano de eternidade e a inevitabilidade do fim.
Para a Associação  MILK, esta lenda representa o conceito de Folclore Vivo como pedagogia
da ambiguidade: o mito que não ensina o bem nem o mal, mas a convivência entre ambos.
Na escultura MILK concebida por Eduardo Mauer, a figura é representada com vestido branco
translúcido e véu longo, de onde brotam pequenas flores secas. A cabeça grande e o corpo
compacto da matriz escultórica expressam inocência e mistério. O rosto, sereno e fechado,
sugere descanso e reconciliação.
⸻
6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer
Na leitura não binária de Eduardo Mauer, a noiva das Bodas do Cemitério simboliza o corpo
híbrido da passagem: simultaneamente vivo e morto, masculino e feminino, humano e espectral.
O casamento entre opostos é metáfora da dissolução de fronteiras.
Mauer escreve: “A noiva é o corpo que se casa com o tempo. O vestido é o invólucro da
mutação; a morte é apenas a outra face do desejo.” Assim, o mito não trata da punição, mas da
integração  das polaridades.


A leitura da Associação  MILK identifica na figura da noiva um símbolo queer da reconciliação:
ela une o que a sociedade separa, transgride o interdito e encontra, na morte, o espaço da
autonomia. O cemitério, espaço de silêncio, torna-se o altar da igualdade ontológica.
⸻
7. Referência Estrutural da Matriz MILK
Na Matriz Escultórica MILK, a Noiva do Cemitério é representada de pé, corpo compacto,
vestido translúcido em resina branca e véu texturizado. As mãos estão unidas à frente, e o rosto,
voltado ligeiramente para baixo. As cores predominantes são branco, cinza e ocre.
A instalação pode incluir luz tênue oscilando como vela e som ambiente de vento, sugerindo
presença espiritual.
⸻
Localização  específica: Ponte de Lima, Arcos de Valdevez e Ponte da Barca, Alto Minho.
Primeiro relato documentado: Teófilo Braga, Contos Tradicionais do Povo Português , 1883.
Sistematização  contemporânea:  Eduardo Mauer, As Bodas do Cemitério:  Eros, Thanatos e
Tradição  no Imaginário  Minhoto, Associação MILK, 2024.
Fontes primárias:  Braga (1883); Vasconcelos (1915); Parafita (2008); Reis (2019); Mauer (2024).


---

# 019. Lenda do Juiz do Soajo (Alto Minho)

**Origem documental:** PDF `folclore português (1).pdf`, enviado pelo utilizador.  
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

19. Lenda do Juiz do Soajo (Alto Minho)
(Sistematização  contemporânea  conduzida por Eduardo Mauer no âmbito  das pesquisas sobre
Folclore Vivo da Associação  MILK – Movimento de Intervenções e Linguagens Kulturais e Arte)
⸻
1. Descrição  simbólica e narrativa
A Lenda do Juiz do Soajo é uma das narrativas mais singulares e identitárias do folclore do Alto
Minho, profundamente enraizada na tradição comunitária e na ética popular da justiça rural. O
Soajo, aldeia serrana pertencente ao concelho de Arcos de Valdevez, é conhecido pela sua
paisagem de espigueiros graníticos e pela autonomia histórica dos seus habitantes, que, durante
séculos, exerceram formas próprias de autogoverno.
A lenda conta que, em tempos antigos, o povo do Soajo elegeu um juiz para resolver querelas e
defender a comunidade de abusos senhoriais. O homem, justo e respeitado, julgava as causas
sentado numa grande pedra redonda no adro da igreja. Um dia, um fidalgo poderoso, dono das
terras vizinhas, exigiu-lhe submeter-se à sua autoridade. O juiz recusou: “Aqui, o Soajo é quem se
julga a si mesmo.”
Irritado, o fidalgo mandou prendê-lo. Mas, segundo o relato oral recolhido por Eduardo Mauer
no ciclo Folclore Vivo, quando os soldados o levaram, a pedra ergueu-se do chão, rolou sozinha
até ao meio da aldeia e ali se fixou — como se a própria terra protestasse contra a injustiça. O
povo interpretou o acontecimento como milagre, e a pedra passou a ser chamada de “Pedra do
Juiz”.
Diz-se que, desde então, quem se senta nela deve jurar dizer a verdade. Há quem a firme que a
pedra “fala” — não com voz, mas com peso: se o mentiroso nela se sentar, sente o corpo ficar
pesado e o coração apertado.
A lenda, de caráter simbólico e moral, exprime a independência do espírito comunitário e a
crença na justiça natural, anterior e superior à lei dos homens. Para Eduardo Mauer, “o Juiz do
Soajo é o arquétipo do direito telúrico português — aquele em que a pedra, não o papel, legitima
o veredito.”


⸻
2. Contexto histórico e social
O Soajo, situado nas encostas da serra homónima, foi, desde o século XII, terra de baldios e de
organização comunal. O Foral de Valdevez (1515), concedido por D. Manuel I, reconheceu os
privilégios do lugar e o direito dos seus moradores a escolher representantes locais para
administrar justiça.
A figura do juiz popular — eleita entre os homens bons da freguesia — era elemento essencial da
cultura rural minhota, refletindo a autossuficiência e a solidariedade entre vizinhos. O juiz do
Soajo não era magistrado de toga, mas mediador de honra.
Durante o Antigo Regime, o Soajo foi também refúgio de dissidentes e perseguidos, reforçando o
imaginário de independência. As tradições orais recolhidas por Leite de Vasconcelos e Teófilo
Braga no final do século XIX já associavam o lugar a “gente altiva e livre, que não teme
senhores.”
No século XX, o mito do Juiz do Soajo consolidou-se como símbolo identitário, transmitido de
geração em geração. A “Pedra do Julgamento”, hoje preservada na aldeia, continua a ser visitada
por moradores e turistas, que nela se sentam “para provar a verdade do coração.”
Para Eduardo Mauer, essa continuidade demonstra que “a justiça, quando nasce do chão, não
precisa de tribunal. O Soajo é a geogra fia ética da montanha.”
⸻
3. Toponímia e variantes locais
O topónimo Soajo deriva, segundo Leite de Vasconcelos, do latim socius (companheiro),
remetendo à ideia de comunidade e aliança — signi ficado coerente com a lenda do juiz. Outros
autores sugerem origem pré-romana, ligada a saugia, “lugar sagrado”, possivelmente relacionado
com antigos cultos às pedras.
A “Pedra do Juiz”, ainda existente no centro da aldeia, é bloco granítico arredondado com
assento natural, situada junto à antiga igreja matriz. Em torno dela, subsistem variantes da lenda:
numa, o juiz é mártir da verdade; noutra, figura mágica que desaparece após o julgamento justo.
Versões similares ocorrem em Castro Laboreiro e Lindoso, mas apenas no Soajo a pedra é
reconhecida como objeto ritual — símbolo tangível de justiça. A sua permanência no espaço
urbano confirma o papel do mito na coesão social e na identidade local.
⸻
4. Primeiro relato e fontes académicas primárias
O primeiro relato escrito da Lenda do Juiz do Soajo aparece em Leite de Vasconcelos,
Etnografia Portuguesa, vol. II (1913, pp. 190–193)*, sob o título “A Pedra do Julgamento”. O autor
descreve o local, recolhe depoimentos e interpreta a tradição como “resíduo de antigas
assembleias populares pré-cristãs”.
Teófilo Braga, em O Povo Português  nos seus Costumes, Crenças e Tradições (1883, pp. 356–
360)*, menciona o Soajo como “povo de espírito independente”, citando a “pedra onde se
julgavam as contendas sem papel nem pena.”
Alexandre Parafita, Mitologia Popular Portuguesa (2008, pp. 299–304)*, analisa o mito sob a
perspetiva simbólica do “justo telúrico”, associando a pedra ao arquétipo da deusa-mae
julgadora da terra.


A sistematização contemporânea de Eduardo Mauer, O Juiz do Soajo: Pedra, Verdade e
Comunidade no Imaginário  Minhoto (Lisboa, Associação MILK, 2024), amplia o estudo com
levantamento fotográ fico e entrevistas, explorando o mito como expressão política e ecológica da
justiça popular.
Fontes complementares:
– Arquivo Municipal de Arcos de Valdevez, Atas do Conselho do Soajo, 1732–1810;
– Museu do Alto Minho, Coleção  Etnográ fica de Tradições Jurídicas  Rurais (1930–1960);
– Tese de Doutoramento de Ricardo Fernandes, O Julgamento e o Sagrado: Ética  Popular e
Lenda no Norte de Portugal (U. Porto, 2016).
⸻
5. Síntese interpretativa final
A Lenda do Juiz do Soajo é síntese da ética minhota: a verdade nasce da terra, e a lei pertence
ao comum. O juiz é mediador entre o humano e o telúrico; a pedra é testemunha e sacramento.
O mito expressa o princípio da autogestão, em que a comunidade se reconhece como sujeito de
justiça. Não há castigo, mas reparação — a harmonia do grupo é o objetivo final.
Na leitura estética da Associação  MILK, o Soajo representa o “território do veredito natural”:
onde a verdade pesa, e o peso é a sua forma.
Na escultura MILK criada por Eduardo Mauer, o Juiz do Soajo é representado sentado, corpo
compacto, cabeça grande e olhar sereno. As mãos repousam sobre o colo, e a pedra sob si é
parte da figura, numa fusão simbólica entre humano e geologia. As cores predominantes são
cinza-granito, verde e ocre.
⸻
6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer
Na leitura não binária de Eduardo Mauer, o Juiz do Soajo é figura da autoridade fluida e
inclusiva. Não representa o patriarca nem o magistrado, mas a consciência coletiva — o corpo
que pertence a todos.
O ato de julgar, quando devolvido à comunidade, torna-se gesto não binário: une em vez de
dividir, reconcilia em vez de punir. A pedra, símbolo da Terra-Mãe, é também símbolo de
neutralidade — nem masculina nem feminina, mas matriz comum.
Mauer observa: “A justiça do Soajo é queer por natureza — não hierárquica, circular, mineral.”
Assim, o mito transforma-se em paradigma ético contemporâneo, onde o julgamento é diálogo e
o poder é partilha.
⸻
7. Referência Estrutural da Matriz MILK
Na Matriz Escultórica MILK, o Juiz do Soajo é representado em posição sentada sobre base
pétrea. Cabeça grande, rosto tranquilo e corpo robusto. A pedra faz parte do corpo, uni ficando
humano e natureza.
As cores predominantes são cinza e verde-musgo, com acabamento semi-fosco. A instalação
pode incluir gravação de sons naturais — vento e passos sobre laje — e iluminação descendente
que acentue a textura granítica.


⸻
Localização  específica: Soajo, concelho de Arcos de Valdevez, Alto Minho.
Primeiro relato documentado: Leite de Vasconcelos, Etnografia Portuguesa, vol. II, 1913.
Sistematização  contemporânea:  Eduardo Mauer, O Juiz do Soajo: Pedra, Verdade e
Comunidade no Imaginário  Minhoto, Associação MILK, 2024.
Fontes primárias:  Braga (1883); Vasconcelos (1913); Parafita (2008); Fernandes (2016); Mauer
(2024).


---

# 020. Lenda do Mosteiro de Ermelo (Alto Minho, concelho de Arcos de Valdevez)

**Origem documental:** PDF `folclore português (1).pdf`, enviado pelo utilizador.  
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

20. Lenda do Mosteiro de Ermelo (Alto Minho, concelho de Arcos de Valdevez)
1. Descrição  simbólica e narrativa
A Lenda do Mosteiro de Ermelo ocupa lugar de destaque no imaginário espiritual e histórico do
Alto Minho, associando a fundação do antigo mosteiro beneditino — erguido entre os séculos XII
e XIII, nas margens do rio Lima — a episódios de milagre, arrependimento e redenção. A narrativa
integra o corpus das “lendas fundacionais monásticas”  portuguesas, nas quais o espaço
sagrado surge como fruto de revelação divina e de sacrifício humano.
Segundo a versão mais antiga, recolhida entre os habitantes do vale, o mosteiro foi construído
por ordem de um cavaleiro penitente. Homem de armas e senhor feudal, teria cometido um
grave pecado: matado o próprio irmão por ciúme ou cobiça. Atormentado pela culpa, abandonou
as terras e vagueou como eremita até chegar a um vale de rara beleza, onde o rio Lima se bifurca
entre penedos e vinhedos. Ali, uma noite, ao dormir sob uma figueira, sonhou que uma pomba
branca pousava sobre uma pedra e dizia-lhe: “Aqui encontrarás o perdão.”
Ao acordar, viu no chão o contorno de uma cruz traçado por formigas, sinal interpretado como
divino. O cavaleiro construiu uma pequena ermida em honra de São Bento e passou o resto da
vida em penitência. Após a sua morte, monges vindos de Refoios e Tibães edi ficaram no mesmo
local o Mosteiro de Ermelo, cujo nome vem do latim heremita locus — “lugar do eremita”.
Em versões posteriores, a lenda desloca o protagonismo para uma donzela nobre, filha de
cavaleiro, que teria fugido para o vale para escapar a casamento forçado. Escondeu-se entre as
vinhas e vivia da colheita do rio. Um dia, caçadores descobriram-na ajoelhada diante de uma
gruta, rodeada por pombas. O pai, arrependido, mandou erguer ali um mosteiro em sua
homenagem. O motivo da mulher arrependida transformada em santa combina-se, assim, com o
da penitência masculina, compondo um arquétipo dual: o pecado que se redime pela clausura.
Há também versões populares que narram milagres ligados ao mosteiro. Diz-se que, quando
os monges estavam prestes a iniciar as obras, não conseguiam firmar as pedras; o edifício
desmoronava-se todas as noites. Um velho pastor aconselhou-os a colocarem a primeira pedra
junto da nascente onde o eremita rezara. Assim fizeram, e a construção manteve-se de pé. Por
isso, os aldeões chamam à nascente “Fonte da Fundação”.
Outra tradição fala de sineta milagrosa: um pequeno sino de bronze que, quando tocava
sozinho nas noites de trovoada, avisava que alguém estava em perigo no rio. Quem o ouvia
deveria rezar três vezes “Santa Maria de Ermelo”. Muitos afirmam que, mesmo depois do
mosteiro estar em ruínas, o sino ainda soava, vindo do fundo do vale, ecoando o tempo sagrado
do lugar.
O mito centraliza-se, portanto, na ideia de redenção  pela natureza. O vale de Ermelo é espaço
de reconciliação entre o humano e o divino: o eremita e a donzela reencontram a paz entre
vinhas, figueiras e águas correntes. O mosteiro não é apenas edifício, mas símbolo de
purificação  e comunhão  com o cosmos.
A tradição local associa a fundação à presença de monges beneditinos e depois cistercienses,
conhecidos pela disciplina e pelo aproveitamento agrícola das terras. Assim, o mito mistura
espiritualidade e economia: a penitência gera fertilidade, e o solo puri ficado pela oração

transforma-se em vinha produtiva. Até hoje, as vinhas de Ermelo são célebres pelo vinho branco
doce, o “Vinho de Ermelo”, que os habitantes chamam de “vinho de paz”.
Nas festas religiosas, ainda se canta:
“Ermelo santo, vale de bênção,
onde o pecado virou canção.”
Essa cantiga resume a essência simbólica do mito: a culpa transformada em beleza, a
violência convertida em harmonia.
⸻
2. Contexto histórico e social
O Mosteiro de Santa Maria de Ermelo é uma das fundações monásticas mais antigas e
discretas do norte de Portugal. A documentação medieval indica a sua existência já em 1220, no
Inquérito  de D. Afonso II, como casa beneditina dependente de Tibães. Situava-se no vale fértil
do rio Lima, entre as atuais freguesias de Ermelo e São Martinho de Crasto, em Arcos de
Valdevez.
O mosteiro desempenhou papel relevante na colonização agrícola do vale. Os monges
introduziram técnicas de regadio e cultivo de vinha e mantinham escola e hospital para os
camponeses. No século XV, a casa monástica foi reformada segundo as regras cistercienses, e
as propriedades foram incorporadas na administração de Santa Maria de Bouro.
Durante a extinção  das ordens religiosas (1834), o edifício foi abandonado e parcialmente
destruído. A igreja românica subsistiu, com portal e ábside de grande valor artístico, hoje
classificada como Monumento Nacional. As ruínas inspiraram sucessivas gerações de poetas,
viajantes e românticos, que as viram como “lugar encantado onde o silêncio é reza”.
A lenda do eremita penitente surge, portanto, no contexto de uma paisagem monástica autêntica,
onde as ruínas reais alimentaram o imaginário popular. A penitência, tema central da
espiritualidade medieval, é reinterpretada localmente como caminho de regeneração coletiva. O
mosteiro torna-se paradigma do “lugar do perdão” — não só para o cavaleiro fundador, mas para
todo o povo.
A associação entre o mosteiro e o vinho de Ermelo reforça essa simbologia. A vinicultura,
introduzida pelos monges, foi assimilada pela população como herança espiritual. Cada garrafa
de vinho local carrega ainda a crença de que “uma gota de vinho de Ermelo lava a alma”. Essa
relação entre produção e redenção é típica das regiões monásticas, onde o trabalho agrícola
assume dimensão ritual.
O contexto social contemporâneo  preserva a lenda como elemento identitário. A aldeia de
Ermelo, hoje com poucas dezenas de habitantes, mantém romaria anual em honra de Nossa
Senhora de Ermelo, padroeira associada ao mito fundacional. O cortejo passa junto às ruínas do
mosteiro, onde se reza pela chuva e pela fertilidade das vinhas.
Assim, o mito e o território entrelaçam-se: a lenda explica o lugar, e o lugar perpetua a lenda.
⸻
3. Toponímia e variantes locais
O topónimo Ermelo aparece documentado desde o século XIII, derivado de ermelo (de eremita
ou ermida), designando “lugar de retiro ou solidão”. Essa etimologia reforça a coerência da lenda
do cavaleiro penitente e do eremita fundador.


O vale de Ermelo situa-se na margem direita do rio Lima, cercado por encostas de granito e
vinhedos, a cerca de 15 km da vila de Arcos de Valdevez. O local é conhecido por seu microclima
ameno e pela abundância de água — fatores que justi ficaram a fixação monástica e que, no
imaginário popular, são interpretados como sinais da bênção original.
Variantes da lenda aparecem em localidades vizinhas:
– Em Bravães , fala-se de “um cavaleiro que ergueu igreja onde o cavalo ajoelhou”;
– Em Refoios, menciona-se um “monge errante que viu luz entre as vinhas”;
– Em Castro Laboreiro, há versão em que a donzela fugitiva de Ermelo é transformada em
pomba branca e desaparece no rio.
Essas variantes mostram a difusão regional do motivo da fundação  milagrosa — a ideia de que
igrejas e mosteiros surgem por vontade divina revelada a pecadores arrependidos. O caso de
Ermelo é um dos mais completos porque combina todos os elementos estruturais: culpa, sinal
divino, edificação e milagre natural.
Toponímicos locais associados à lenda incluem:
– Fonte da Fundação , onde o eremita teria visto o sinal da cruz;
– Campa do Cavaleiro, pequena laje junto ao adro da igreja, dita sepultura do fundador;
– Penedo da Pomba, rochedo na margem do rio onde, segundo o mito, a pomba branca pousou.
Esses marcos geográ ficos mantêm viva a narrativa na paisagem, transformando o vale num
verdadeiro mapa sagrado.
⸻
4. Primeiro relato e fontes académicas primárias
O primeiro registo escrito da Lenda do Mosteiro de Ermelo encontra-se em Joaquim Alves
Ferreira, Literatura de Trás-os-Montes  e Alto Douro – Lendas e Contos Infantis, vol. V (1956),
onde o autor recolhe testemunhos de camponeses de Arcos de Valdevez. Ferreira apresenta a
versão do cavaleiro penitente e da pomba branca, descrevendo-a como “uma das tradições
mais antigas e belas do Lima”.
José Leite de Vasconcelos, em Etnografia Portuguesa (vol. II, 1913), menciona o topónimo
Ermelo como “antigo sítio monástico de fundação lendária”, ligando-o à série de eremitérios
medievais que pontuam o vale do Lima. O autor reconhece que “o nome indica origem religiosa e
ascética, possivelmente anterior à regularização beneditina”.
Teófilo Braga, em O Povo Português  nos seus Costumes, Crenças e Tradições (1885), cita o
“milagre do eremita de Ermelo” como exemplo de lenda fundacional em que “a penitência ergue
templos e a natureza coopera com o arrependido”.
Alexandre Parafita, em Mitologia Popular Portuguesa (2008), inclui a narrativa de Ermelo na
categoria “fundação redentora”, interpretando-a como metáfora do “renascimento espiritual do
pecador através do labor agrícola e da puri ficação pela água”.
Manuel J. Gandra, em Mitologia Portuguesa (2006), vai além, propondo leitura esotérica: vê na
pomba branca o símbolo alquímico da alma purificada, e no vale de Ermelo a representação do
“ventre da terra que gera o homem novo”.
Fontes locais no Arquivo Municipal de Arcos de Valdevez (série “Tradições e Crenças
Populares”, 1927–1939) incluem manuscritos descrevendo “a fundação do mosteiro por um
cavaleiro penitente que viu sinal de cruz no chão” e menções à “Fonte do Milagre” e à “Campa
do Cavaleiro”.
Estudos recentes, como a dissertação de Rita Figueiredo, Ermelo: Espaço Monástico  e Mito da
Redenção  no Vale do Lima (Universidade do Minho, 2019), cruzam fontes históricas e orais para
demonstrar a coerência entre a narrativa lendária e os vestígios arqueológicos.


⸻
Síntese interpretativa
A Lenda do Mosteiro de Ermelo é narrativa de fundação espiritual e ecológica. O mosteiro não
nasce de conquista nem de milagre espetacular, mas de arrependimento e reconciliação  com a
natureza. A pomba, a água e a pedra são os três elementos redentores que substituem a
espada, o sangue e o orgulho.
Do ponto de vista simbólico, o mito dramatiza a transformação do guerreiro em monge, do
pecado em fertilidade, da culpa em comunhão. Do ponto de vista social, re flete o papel
civilizador das ordens monásticas e a importância do trabalho como penitência regeneradora.
O vale de Ermelo é, portanto, território da metamorfose: do eremita nasce o mosteiro; do pecado,
o vinho; da solidão, a harmonia coletiva. A lenda preserva essa filosofia telúrica de reconciliação,
ensinando que o perdão é gesto que se faz com as mãos — lavrando, edi ficando, cuidando.
Enquanto mito, Ermelo revela o núcleo ético da espiritualidade minhota: o sagrado que se
manifesta no labor e na paisagem. Por isso, a ruína do mosteiro não representa esquecimento,
mas continuidade; as pedras que restam são memória viva da regeneração.
Nas palavras do ditado local:
“Quem bebe do rio de Ermelo esquece a guerra e aprende o trabalho.”
Assim, a lenda do Mosteiro de Ermelo é, ao mesmo tempo, história, oração  e manual de vida
— uma das mais belas sínteses da espiritualidade agrária e artística do Norte de Portugal.


---

# 021. Lenda da Senhora do Picão  (Trás-os-Montes  e Alto Douro)

**Origem documental:** PDF `folclore português (1).pdf`, enviado pelo utilizador.  
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

21. Lenda da Senhora do Picão  (Trás-os-Montes  e Alto Douro)
(Sistematização  contemporânea  conduzida por Eduardo Mauer no âmbito  das pesquisas sobre
Folclore Vivo da Associação  MILK – Movimento de Intervenções e Linguagens Kulturais e Arte)
⸻
1. Descrição  simbólica e narrativa
A Lenda da Senhora do Picão , originária da aldeia da Póvoa, concelho de Miranda do Douro, é
uma das mais belas e devocionais narrativas do imaginário transmontano. Situada num ponto
alto do planalto mirandês, a lenda combina o elemento miraculoso mariano com raízes pagãs
muito mais antigas, provavelmente ligadas aos cultos da montanha e das pedras sagradas.
De acordo com o relato recolhido por Eduardo Mauer e confirmado em fontes históricas, vivia na
aldeia uma jovem chamada Mariana dos Ramos João , conhecida pela sua piedade e por
caminhar diariamente até o cume do Picão para rezar. Certo dia, enquanto orava, viu uma luz
intensa que se condensou na forma de uma mulher envolta em claridade — Nossa Senhora. A
aparição pediu-lhe que anunciasse ao povo a construção de uma capela naquele local,
prometendo proteção e bênçãos à aldeia.
Mariana transmitiu a mensagem ao pároco, mas este, descon fiado, ignorou-a. Dias depois, uma
tempestade devastou os campos e destruiu parte das colheitas. O povo, temendo castigo divino,
subiu ao monte e encontrou a jovem novamente envolta pela luz. Nesse instante, uma fonte de
água límpida brotou da rocha — sinal de puri ficação e renascimento.
No local ergueu-se então a Capela da Senhora do Picão , que até hoje é destino de romaria. Diz-
se que a água da fonte cura doenças e que quem sobe ao monte descalço em promessa alcança
graça.


Em outras versões recolhidas oralmente, a aparição é associada à presença de uma moura
encantada que, ao ser redimida pela oração da jovem, se transforma na Virgem. Tal fusão de
símbolos — a moura e a Senhora — expressa, segundo Eduardo Mauer, “a metamorfose do
feminino ancestral no feminino cristão: o encantamento que se converte em fé.”
⸻
2. Contexto histórico e social
O culto à Senhora do Picão  remonta ao final do século XIX, quando se consolidaram as
primeiras romarias anuais no local. Contudo, os rituais ligados ao monte são muito mais antigos.
Registos arqueológicos apontam para ocupação pré-romana na região, com vestígios de aras
votivas dedicadas a Nabia, deusa das águas e da fertilidade.
O processo de cristianização, iniciado no século XII e intensi ficado após a Reconquista,
converteu muitos desses antigos lugares sagrados em eremitérios ou capelas marianas. Assim, o
Picão representa a continuidade simbólica entre o sagrado pré-cristão  e o cristão ,
preservada pela devoção popular.
A aldeia da Póvoa e o santuário do Naso, próximos ao Picão, constituem um circuito de
peregrinação local. Nos relatos do século XX, as festas da Senhora do Picão eram também
ocasião de encontro e sociabilidade: concertinas, procissões, trocas de bens agrícolas, danças e
promessas.
No contexto social transmontano, marcado por isolamento geográ fico e forte religiosidade, o mito
servia como estrutura de esperança e identidade coletiva. A mulher escolhida, Mariana,
simboliza o poder espiritual das camponesas — voz do divino em meio à pobreza e ao silêncio.
Eduardo Mauer observa que “o milagre do Picão é a apoteose da humildade: uma jovem
invisível que se torna mediadora entre o céu e a terra, entre o sagrado e o comum.”
⸻
3. Toponímia e variantes locais
O nome Picão  provém do termo latino piccus, “monte agudo” ou “pico”, designando o cume
rochoso que domina o vale. Essa etimologia reforça a dimensão simbólica do local como eixo
vertical de ascensão  espiritual — um caminho entre o humano e o divino.
A Capela da Senhora do Picão  situa-se a quatro quilómetros da aldeia da Póvoa e a dois do
Santuário  do Naso, outro ponto de devoção mariana importante em Miranda do Douro. As duas
lendas estão interligadas: enquanto o Naso representa o milagre doméstico e comunitário, o
Picão é o milagre solitário e contemplativo.
Entre as variantes orais, algumas descrevem que a imagem da Senhora desaparecia
periodicamente da capela e reaparecia na fonte do monte, demonstrando que desejava
permanecer naquele lugar — motivo comum em lendas de fundação de santuários.
Outras versões, recolhidas por Mauer junto de anciãs mirandesas, falam de uma “voz que canta
no vento” e de “um pássaro branco que pousa no ombro da vidente”, ecoando símbolos de
pureza e mediação.
⸻
4. Primeiro relato e fontes académicas primárias
O primeiro registo escrito da Lenda da Senhora do Picão  encontra-se em Joaquim Alves
Ferreira, Literatura de Trás-os-Montes  e Alto Douro – Lendas e Contos Infantis, vol. V (Porto,
1956, pp. 134–138)*, a partir de relatos recolhidos na aldeia da Póvoa.


Teófilo Braga, embora não mencione diretamente o Picão, descreve fenómenos semelhantes em
O Povo Português  nos seus Costumes, Crenças e Tradições (1883, pp. 402–409)*, analisando as
aparições marianas como “transfigurações do imaginário agrário e feminino da fertilidade”.
Leite de Vasconcelos, Etnografia Portuguesa, vol. IV (1915, pp. 218–223)*, identifica os montes
de aparição como “lugares de transição entre o humano e o sobrenatural”, herdeiros dos cultos
antigos às ninfas e deusas das alturas.
A sistematização contemporânea de Eduardo Mauer, A Senhora do Picão:  Montanha, Luz e
Feminino no Imaginário  Mirandês  (Lisboa, Associação MILK, 2024), aprofunda o cruzamento entre
oralidade, devoção e arqueologia simbólica, propondo leitura de continuidade entre mito e fé
popular.
Fontes complementares:
– Arquivo Distrital de Bragança, Códices Paroquiais da Póvoa e do Naso, sécs. XVIII–XIX;
– Museu da Terra de Miranda, Cadernos de Etnografia Transmontana (1934–1960);
– Tese de Doutoramento de Helena Cordeiro, A Montanha e o Milagre: Espaços Femininos da
Devoção  Popular em Trás-os-Montes  (U. Lisboa, 2018).
⸻
5. Síntese interpretativa final
A Lenda da Senhora do Picão  é expressão da espiritualidade popular transmontana — uma fé
de montanha, nascida da relação direta entre mulher, pedra e luz. O episódio traduz a
persistência do sagrado feminino, transmutado em iconogra fia cristã.
Na leitura da Associação  MILK, o Picão é o “monte do limiar”: ali, o invisível torna-se visível, e o
humano comunica com o divino sem mediações institucionais. O mito valoriza o corpo feminino
como instrumento de revelação, desa fiando as hierarquias religiosas.
Na escultura MILK concebida por Eduardo Mauer, a Senhora do Picão é representada em
posição ereta, com cabeça grande e expressão suave, envolta por véu translúcido de resina
branca e dourada. A base, em forma de pedra triangular, evoca o monte. A luz interna da peça
muda gradualmente de cor, simbolizando o momento da aparição.
⸻
6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer
Na leitura não binária de Eduardo Mauer, a Senhora do Picão representa a integração  dos
polos feminino e solar, dissolvendo as fronteiras entre maternidade e luminosidade, carne e
espírito.
Mauer observa: “A Senhora não é mãe nem virgem — é a encarnação da luz andrógina, energia
pura que transcende o corpo. O Picão é o ponto onde o género se dissolve na claridade.”
A leitura contemporânea da Associação  MILK insere o mito na pedagogia do Folclore Vivo como
exercício de reconciliação  simbólica entre o feminino ancestral e o pós-binário
contemporâneo . A figura de Mariana é vista como a primeira intérprete dessa fusão — uma
mulher que escuta a montanha e devolve voz ao sagrado não hierarquizado.
⸻
7. Referência Estrutural da Matriz MILK

Na Matriz Escultórica MILK, a representação da Senhora do Picão segue proporções clássicas:
cabeça grande, corpo compacto, véu translúcido e pedestal triangular. As cores predominantes
são branco, dourado e azul-celeste.
A instalação inclui iluminação interna com pulsação luminosa suave, representando o momento
da aparição, e som ambiente de vento e canto.
⸻
Localização  específica: Póvoa, concelho de Miranda do Douro, Trás-os-Montes e Alto Douro.
Primeiro relato documentado: Joaquim Alves Ferreira, Literatura de Trás-os-Montes  e Alto
Douro – Lendas e Contos Infantis, vol. V, 1956.
Sistematização  contemporânea:  Eduardo Mauer, A Senhora do Picão:  Montanha, Luz e
Feminino no Imaginário  Mirandês , Associação MILK, 2024.
Fontes primárias:  Braga (1883); Vasconcelos (1915); Ferreira (1956); Cordeiro (2018); Mauer
(2024).


---

# 022. Lenda do Naso (Trás-os-Montes  e Alto Douro)

**Origem documental:** PDF `folclore português (1).pdf`, enviado pelo utilizador.  
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

22. Lenda do Naso (Trás-os-Montes  e Alto Douro)
(Sistematização  contemporânea  conduzida por Eduardo Mauer no âmbito  das pesquisas sobre
Folclore Vivo da Associação  MILK – Movimento de Intervenções e Linguagens Kulturais e Arte)
⸻
1. Descrição  simbólica e narrativa
A Lenda do Naso, recolhida na região de Miranda do Douro, narra-se em torno da pequena
Capela de Nossa Senhora do Naso, erguida na margem escarpada do Douro, entre oliveiras e
penedos, num lugar de beleza agreste e de difícil acesso. Segundo a tradição, o santuário foi
mandado construir por um casal mirandês em cumprimento de promessa após uma série de
acontecimentos miraculosos ligados à travessia do rio e à proteção dos navegantes.
De acordo com as versões mais antigas, um pastor teria encontrado, entre as pedras, uma
imagem da Virgem parcialmente coberta por musgo. Ao tentar levá-la para a aldeia, o objeto
tornava-se inexplicavelmente pesado; só quando o povo decidiu erguer ali mesmo uma ermida a
Virgem permitiu que a levantassem. Noutra versão, um casal de lavradores, a flito pela seca, teria
ouvido uma voz suave proveniente do rochedo pedindo que ali fosse construída uma casa de
oração. No dia seguinte, jorrou uma nascente de água clara — a Fonte do Naso — cujas
propriedades curativas se tornaram célebres.
A imagem de Nossa Senhora do Naso é descrita como de rosto oval e sereno, vestida com
manto azul-profundo e túnica rosada. Segundo os fiéis, o seu olhar muda de expressão conforme
o estado do rio: doce quando as águas estão calmas, severo quando a corrente cresce.
Em diversas versões orais recolhidas por Eduardo Mauer, a Virgem do Naso surge como guardiã
da fronteira entre Portugal e Espanha, protetora dos navegadores, barqueiros e contrabandistas.
O rio Douro, com sua força e risco, é o cenário permanente do milagre: um espaço-limite entre
vida e morte, fé e natureza.
Para Mauer, “a Senhora do Naso é a metáfora do limiar — onde o humano reconhece a
fragilidade diante do fluxo e escolhe confiar no invisível. O Naso é o sagrado da travessia.”
⸻
2. Contexto histórico e social

A atual Capela de Nossa Senhora do Naso remonta aos séculos XVI–XVII, embora o culto
possua raízes muito mais antigas. O nome “Naso” parece derivar de nasus (rochedo,
promontório) ou do verbo nascere, “nascer”, aludindo à fonte e à vida que dela brota.
Durante os séculos XVII e XVIII, o local tornou-se ponto de peregrinação para camponeses e
barqueiros do Douro, que ali iam pedir proteção contra naufrágios e colheitas perdidas. A romaria
anual, celebrada em meados de agosto, incluía missa, procissão fluvial e partilha comunitária de
alimentos.
O contexto social da região era marcado pela dureza do trabalho agrícola e pela migração
sazonal. A devoção à Senhora do Naso oferecia sentido de pertença e esperança num território
de fronteira, onde o perigo era cotidiano e a fé, uma forma de sobrevivência.
No século XIX, com o declínio da navegação fluvial, a romaria adquiriu caráter mais interiorizado e
simbólico, preservando-se como rito de memória e identidade. Ainda hoje, as famílias de Miranda
do Douro guardam pequenas garrafas com água da fonte, usada para benzer casas e curar
enfermidades.
⸻
3. Toponímia e variantes locais
O topónimo Naso aparece já em documentos paroquiais do século XV, designando tanto o monte
como a fonte e a ermida. O termo é de provável origem latina, signi ficando “promontório” ou
“nascente”. Essa dupla leitura — altura e origem — expressa perfeitamente o caráter do mito: a
Senhora está simultaneamente no alto e na fonte, no princípio e no fim.
Existem variantes locais na Póvoa, em Duas Igrejas e em Constantim, todas referindo milagres
associados a luzes misteriosas sobre o rio e à proteção de viajantes. Em algumas versões, a
imagem da Virgem teria sido trazida por uma mulher moura arrependida, fundindo o imaginário
cristão e o legado islâmico de Trás-os-Montes.
Entre as versões espanholas do planalto leonês vizinho, encontram-se paralelos diretos com o
culto da Virgen de la Peña e da Virgen de la Barca, o que confirma o caráter transfronteiriço do
mito e a permeabilidade cultural do Douro.
⸻
4. Primeiro relato e fontes académicas primárias
O primeiro registo escrito da Lenda do Naso encontra-se em Joaquim Alves Ferreira, Literatura
de Trás-os-Montes  e Alto Douro – Lendas e Contos Infantis, vol. V (Porto, 1956, pp. 140–144)*, a
partir de recolhas orais da Póvoa e de Miranda do Douro.
Leite de Vasconcelos, Etnografia Portuguesa, vol. IV (1915, pp. 225–228)*, menciona “os
santuários das margens do Douro onde a água brota como resposta à oração”, associando-os a
cultos pré-cristãos da fertilidade.
Alexandre Parafita, Mitologia Popular Portuguesa (2008, pp. 321–325)*, classifica a Senhora do
Naso entre as “deusas transfiguradas da água e da fronteira”, destacando o sincretismo entre
marianismo e paganismo.
A sistematização contemporânea de Eduardo Mauer, O Naso: Fronteira, Água  e Devoção  no
Imaginário  Transmontano (Lisboa, Associação MILK, 2024), integra levantamento fotográ fico,
testemunhos de romeiros e análise fenomenológica da experiência da travessia.
Fontes complementares:
– Arquivo Distrital de Bragança, Registos do Santuário  do Naso, sécs. XVII–XIX;
– Museu da Terra de Miranda, Cadernos Etnográ ficos (1932–1954);


– Tese de Mestrado de Marta Velho, Água  e Milagre: O Imaginário  Mariano Transmontano (U.
Porto, 2019).
⸻
5. Síntese interpretativa final
A Senhora do Naso sintetiza o arquétipo do sagrado aquático  português. A Virgem que emerge
da rocha é continuação das antigas deusas da nascente; o milagre da fonte é a reedição da
criação do mundo.
Na leitura da Associação  MILK, o Naso é símbolo da fé na travessia — não a conquista, mas o
movimento. O Douro deixa de ser fronteira geográ fica e torna-se metáfora da fluidez da crença.
A escultura MILK de Eduardo Mauer representa a Senhora do Naso com corpo compacto e
cabeça grande, sustentando um pequeno barco nas mãos. A base é azul-escura translúcida,
evocando as águas do Douro. A luz interna alterna tons de ouro e azul, criando efeito de
respiração aquática.
⸻
6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer
Na leitura não binária de Eduardo Mauer, a Senhora do Naso transcende o género e a forma: é a
água que acolhe, o rochedo que sustém. Feminino e masculino dissolvem-se na mesma matéria
líquida.
Mauer escreve: “O Naso não é Virgem nem Deusa; é o corpo líquido da consciência,
simultaneamente gerador e receptivo.” Assim, a travessia do Douro converte-se em metáfora da
passagem do binário para o fluido, do fixo para o movente.
A Associação  MILK reconhece neste mito a pedagogia da fluidez — o ato de crer como
movimento de devir, não de pertença. A fé é o gesto queer da alma que navega.
⸻
7. Referência Estrutural da Matriz MILK
Na Matriz Escultórica MILK, a Senhora do Naso é modelada com base azul translúcida e figura
compacta portando um barco. Cabeça grande e manto fluido em resina acetinada. As cores
predominantes são azul-marinho, dourado e branco-leitoso.
A instalação pode incluir som ambiente de água corrente e iluminação oscilante que reproduz
reflexos de rio.
⸻
Localização  específica: Miranda do Douro, Trás-os-Montes e Alto Douro.
Primeiro relato documentado: Joaquim Alves Ferreira, Literatura de Trás-os-Montes  e Alto
Douro – Lendas e Contos Infantis, vol. V, 1956.
Sistematização  contemporânea:  Eduardo Mauer, O Naso: Fronteira, Água  e Devoção  no
Imaginário  Transmontano, Associação MILK, 2024.
Fontes primárias:  Vasconcelos (1915); Ferreira (1956); Parafita (2008); Velho (2019); Mauer
(2024).


---

# 023. A Mulher Loba e as Lobas do Norte (Trás-os-Montes,  Minho e Douro)

**Origem documental:** PDF `folclore português (1).pdf`, enviado pelo utilizador.  
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

23. A Mulher Loba e as Lobas do Norte (Trás-os-Montes,  Minho e Douro)

(Descoberta e sistematização  contemporânea  conduzidas por Eduardo Mauer no âmbito  das
pesquisas sobre Folclore Vivo da Associação  MILK – Movimento de Intervenções e Linguagens
Kulturais e Arte)
⸻
1. Descrição  simbólica e narrativa
A figura da Mulher Loba — ou Loba-Humana, como é designada em alguns relatos orais de Trás-
os-Montes e do Alto Minho — é uma das mais raras e ambíguas presenças do folclore português.
Durante décadas, o imaginário popular privilegiou a figura masculina do lobisomem, mas a
tradição oral feminina, especialmente preservada em aldeias de montanha, fala de mulheres que
se transformam em lobas durante a lua cheia, não por maldição, mas por necessidade — para
correr, respirar e libertar o corpo do silêncio.
Segundo recolhas realizadas por Eduardo Mauer entre 2022 e 2024 no âmbito do programa
Folclore Vivo da Associação  MILK, as narrativas das “lobas do norte” persistem em localidades
de Montalegre, Bragança, Vinhais, Melgaço e Terras de Bouro, transmitidas sobretudo por
mulheres idosas que as ouviram “das avós e das tias que não se casaram”. A história recorrente
é a de uma mulher que, sentindo o chamamento da serra, sai de casa nas noites de luar, despe a
pele humana, veste a pele de loba e percorre os montes até o amanhecer.
A transformação não é castigo — é libertação. A mulher-loba corre não para caçar, mas para
existir fora das regras humanas. “Dizem que, de manhã, ela voltava cansada, mas feliz, cheirando
a erva e a luar.” Em algumas variantes, o marido, ao segui-la, tenta impedi-la e é morto por um
grupo de lobas; noutras, é ela própria que, ao voltar, encontra o lar vazio e escolhe nunca mais
regressar.
Muitos relatos descrevem o uivo das lobas como canto. Há quem a firme que, quando as lobas
cantam perto das aldeias, “é sinal de mulher triste que quer ser livre”.
Na leitura de Mauer, “a Mulher Loba é a versão feminina do mito da liberdade selvagem — o
corpo que reencontra o seu próprio ritmo fora da domesticidade. É o mito da autonomia através
do instinto.”
⸻
2. Contexto histórico e social
A lenda da Mulher Loba surge num contexto profundamente marcado pela opressão moral e pelo
isolamento das comunidades rurais do norte português entre os séculos XVIII e XX. Em
sociedades onde o corpo feminino era regulado pela religião e pela honra familiar, a metamorfose
em loba tornou-se imagem de resistência simbólica.
Os registos etnográ ficos mais antigos sobre o tema aparecem de forma fragmentária. Leite de
Vasconcelos, em Etnografia Portuguesa, vol. II (1913, pp. 206–211)*, refere “mulheres-lobas” de
forma incidental, descrevendo-as como “variante feminina dos homens-lobos, ligadas a
maldições de linhagem”. Contudo, o discurso oral das mulheres transmontanas — recuperado
nas pesquisas de campo da Associação MILK — apresenta um enredo distinto: as lobas não são
amaldiçoadas, mas autoescolhidas.
Nas zonas de fronteira com a Galiza, o mito funde-se com a tradição galega da Lobismuller,
estudada por Vicente Risco em Mitología  Popular de Galicia (1928), e com a crença castelhana
na Lobera, mulher feiticeira que domina as feras. Essas influências ibéricas revelam que o mito
ultrapassa o território português, delineando uma geografia de resistência feminina rural.
Na cultura camponesa, o lobo representava, paradoxalmente, perigo e proteção. Era símbolo do
instinto e da sobrevivência. O mito da mulher-loba devolve ao feminino a posse dessa força
selvagem, não como ameaça, mas como cura.


Para Eduardo Mauer, “a mulher que corre na serra é a metáfora do corpo insurgente. Em cada
aldeia onde se ouviu o uivo, ouviu-se também a recusa do silêncio imposto.”
⸻
3. Toponímia e variantes locais
O mito aparece sob diferentes designações: a loba da serra, a mulher do luar, a que corre nas
pedras ou a mulher dos olhos de fogo. Em Montalegre, a narrativa é associada à Serra do
Larouco; em Bragança, à Serra da Nogueira; em Melgaço, ao Parque Nacional da Peneda-
Gerês, especialmente nas encostas de Castro Laboreiro, onde o lobo-ibérico ainda tem presença
real.
Em Vinhais, há o relato de “Maria das Lobas”, mulher que desaparecia três noites por mês e era
vista a uivar na serra. Em Terras de Bouro, fala-se na “velha loba” que protegia crianças
perdidas, conduzindo-as de volta à aldeia.
Essas variantes demonstram que o mito atravessa classes e geografias: ora como tragédia, ora
como mito de libertação. Em todas, o elemento comum é a noite, a serra e o corpo em
transformação .
Os topónimos “Vale das Lobas”, “Fonte da Loba”, “Caminho da Loba” e “Serra das Donas”
repetem-se nas cartas topográ ficas do norte português, indiciando uma memória persistente da
presença simbólica feminina nas paisagens montanhosas.
⸻
4. Primeiro relato e fontes académicas primárias
O primeiro relato literário reconhecível da Mulher Loba aparece em Leite de Vasconcelos,
Etnografia Portuguesa, vol. II (1913, p. 209)*, onde menciona “as fêmeas-lobo em corpo de
mulher”, sem, contudo, detalhar as narrativas orais.
José Leite de Vasconcelos volta a referir o tema em Religiões da Lusitânia  (1919), associando-o
a resquícios de cultos lunares e à deusa Diana, símbolo da caça e da noite.
Alexandre Parafita, Mitologia Popular Portuguesa (2008, pp. 370–376)*, identifica o mito das
“mulheres-lobo” como metáfora da marginalidade feminina e da força subterrânea do desejo.
A sistematização contemporânea de Eduardo Mauer, As Lobas do Norte: Corpo, Noite e
Resistência  no Imaginário  Português  (Lisboa, Associação MILK, 2024), constitui o primeiro estudo
integral dedicado à figura, reunindo relatos orais inéditos, fotogra fias de campo e análise
comparada com mitos europeus (romenos, galegos e bretões).
Fontes complementares:
– Arquivo Distrital de Bragança, Registos Etnográ ficos de Montalegre e Vinhais, 1935–1962;
– Museu da Terra de Miranda, Cadernos da Oralidade (1950–1980);
– Tese de Doutoramento de Sofia Ribeiro, Lobas, Bruxas e Resistência:  Gênero  e Natureza no
Norte de Portugal (U. Minho, 2021).
⸻
5. Síntese interpretativa final
A Mulher Loba é o espelho da metamorfose e da autonomia. O mito desvia-se da moral punitiva
das histórias de lobisomens e revela a dimensão libertadora da animalidade feminina. A

transformação noturna é o gesto de a firmação do corpo e da natureza — o regresso à comunhão
com o instinto.
A leitura da Associação  MILK inscreve este mito na genealogia dos corpos híbridos  portugueses
— seres entre humano e animal que traduzem o desejo de reconciliação entre cultura e natureza.
A loba não é monstro, é mediação.
Na escultura MILK criada por Eduardo Mauer, a Mulher Loba é representada com corpo
compacto, cabeça grande e expressão altiva. A pele exibe gradação de cinzas e prateados, e a
postura sugere movimento contido, entre o humano e o animal. A peça é acompanhada por som
de respiração e vento, evocando a corrida noturna.
⸻
6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer
Na leitura não binária de Eduardo Mauer, a Mulher Loba é o corpo da transição  total. Ela
desorganiza o sistema binário de humano/animal, homem/mulher, civilização/natureza. Ao tornar-
se loba, não renega o humano — amplia-o.
Mauer escreve: “A loba é o corpo queer da montanha. Não pertence a espécie alguma, não se
submete a nome algum. É o grito do corpo quando recusa ser domesticado.”
A Associação  MILK reconhece nesta figura a expressão máxima do Folclore Vivo enquanto
pedagogia de libertação. A loba simboliza o ser não categorizável — corpo fluido, instintivo,
poético. Nas leituras contemporâneas da arte queer portuguesa, torna-se metáfora da
insurgência e da reconciliação com o instinto reprimido.
⸻
7. Referência Estrutural da Matriz MILK
Na Matriz Escultórica MILK, a Mulher Loba é modelada com corpo humano compacto e cabeça
levemente alongada, com orelhas discretas e olhar penetrante. As cores predominantes são
cinza, prata e azul-escuro. A base circular representa a lua.
A instalação pode incluir som ambiente de uivos e vento serrano, criando atmosfera imersiva.
⸻
Localização  específica: Montalegre, Bragança, Vinhais, Melgaço e Terras de Bouro, Norte de
Portugal.
Primeiro relato documentado: Leite de Vasconcelos, Etnografia Portuguesa, vol. II, 1913.
Sistematização  contemporânea:  Eduardo Mauer, As Lobas do Norte: Corpo, Noite e
Resistência  no Imaginário  Português , Associação MILK, 2024.
Fontes primárias:  Vasconcelos (1913, 1919); Parafita (2008); Ribeiro (2021); Mauer (2024).


---

# 024. O Homem das Sete Dentaduras (Trás-os-Montes  e Minho)

**Origem documental:** PDF `folclore português (1).pdf`, enviado pelo utilizador.  
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

24. O Homem das Sete Dentaduras (Trás-os-Montes  e Minho)
(Sistematização  contemporânea  conduzida por Eduardo Mauer no âmbito  das pesquisas sobre
Folclore Vivo da Associação  MILK – Movimento de Intervenções e Linguagens Kulturais e Arte)
⸻
1. Descrição  simbólica e narrativa

A figura do Homem das Sete Dentaduras emerge no imaginário do Norte de Portugal como uma
das manifestações mais excêntricas e perturbadoras do folclore oral, documentada
principalmente nas zonas fronteiriças de Trás-os-Montes  e do Alto Minho, entre os séculos XIX
e XX. A personagem é descrita como um homem alto, de expressão grotesca, que possuía — ou
aparentava possuir — sete fileiras de dentes, símbolo de voracidade e desmedida. A lenda,
contudo, transcende o literal e adquire dimensão alegórica, convertendo-se numa crítica
simbólica à ganância, à mentira e à acumulação excessiva.
Nos testemunhos recolhidos por Eduardo Mauer durante as pesquisas do Folclore Vivo da
Associação  MILK, em aldeias de Bragança, Vinhais, Melgaço e Monção , o Homem das Sete
Dentaduras aparece como figura de advertência contada às crianças — um ser que devora tudo
o que promete e nunca cumpre. Em certas versões, é um vendedor ambulante que, ao enganar o
povo, é amaldiçoado: “por cada mentira, uma nova dentadura lhe nasce”. Em outras, é um
defunto condenado a vaguear eternamente, tentando comer o tempo perdido.
A imagem das sete dentaduras, repetida nos relatos, tem força mítica. O número sete — símbolo
de totalidade — representa aqui o excesso, a saturação. As bocas múltiplas do Homem tornam-
se metáfora do desejo insaciável. “Comia pão, ouro e palavra”, dizem os mais velhos.
Alguns narradores de Melgaço descrevem-no como “um homem que ria demais”, cuja
gargalhada ecoava pela serra e assustava os rebanhos. Acreditava-se que, ao ouvir esse riso, era
sinal de desgraça ou de tempestade próxima.
Na interpretação poética de Eduardo Mauer, “o Homem das Sete Dentaduras é o arquétipo do
consumidor cósmico — o ser que devora o mundo por não saber calar-se. É o mito da fome
moral, do ruído e da voracidade moderna.”
⸻
2. Contexto histórico e social
A origem da lenda está associada ao contexto rural e de miséria social do Norte de Portugal nos
séculos XVIII e XIX, quando o discurso oral construía figuras monstruosas para criticar
comportamentos desviantes — a avareza, a mentira, o falso testemunho, o abuso de poder.
As versões mais antigas, recolhidas por Leite de Vasconcelos e Joaquim Alves Ferreira,
sugerem que o mito possa ter surgido como sátira moral dirigida a almocreves e feirantes, figuras
de circulação e comércio. A dentadura múltipla seria a caricatura grotesca do “homem da fala” —
aquele que fala sem verdade.
Em Trás-os-Montes, onde a oralidade assumia função pedagógica, os contos do Homem das
Sete Dentaduras eram usados para ensinar prudência e silêncio: o castigo do verbo excessivo.
No Minho, porém, o mito ganhou nuances demoníacas. Em certas freguesias de Monção e Arcos
de Valdevez, o Homem é visto como um espírito que ronda à meia-noite, tentando vender
dentaduras aos mortos. Essa inversão grotesca — o comerciante entre os túmulos — re flete a
ironia popular e o humor sombrio da cultura minhota.
Eduardo Mauer nota que a figura sintetiza “o medo da linguagem vazia” — a palavra que perdeu
o corpo. Em tempos de oralidade total, o excesso verbal equivalia ao excesso moral.
⸻
3. Toponímia e variantes locais
A lenda é particularmente viva nas zonas de Bragança (nas aldeias de Babe e Parada), Vinhais,
Melgaço, Monção  e Arcos de Valdevez. O nome “Homem das Sete Dentaduras” mantém-se
estável, embora em alguns locais surjam variantes como Homem dos Dentes Múltiplos, Risonho
das Covas ou O Que Come o Ar.


Em Bragança, narra-se que ele habitava perto do rio Fervença e se alimentava “de ecos”; em
Vinhais, dizem que assombrava os caminhos dos ferreiros; em Melgaço, que surgia nos
moinhos, atraído pelo barulho das rodas; e em Monção , que o riso do Homem antecedia as
cheias do rio Minho.
A sua presença mítica estende-se também à Galiza, onde existem paralelos como o Home dos
Sete Bois — ser devorador e bufão — e o Riso da Montanha, recolhido por Vicente Risco (1928).
Essa correspondência reforça o caráter ibérico da criatura.
Toponimicamente, há referências a “Vale dos Dentes” (em Parada, Bragança) e “Penedo do Riso”
(em Melgaço), sugerindo fixação simbólica da lenda no espaço.
⸻
4. Primeiro relato e fontes académicas primárias
O primeiro registo escrito da Lenda do Homem das Sete Dentaduras surge em Joaquim Alves
Ferreira, Literatura de Trás-os-Montes  e Alto Douro – Lendas e Contos Infantis, vol. IV (Porto,
1954, pp. 77–80)*, compilando versões recolhidas em Bragança e Vinhais.
Leite de Vasconcelos, Etnografia Portuguesa, vol. II (1913, pp. 212–214)*, menciona brevemente
“figuras grotescas de homens com bocas múltiplas”, associando-as à tradição satírica medieval e
às imagens de gula nos sermões barrocos.
Alexandre Parafita, Mitologia Popular Portuguesa (2008, pp. 379–384)*, interpreta o Homem das
Sete Dentaduras como “alegoria da insaciabilidade humana diante da matéria”, relacionando-o
ao ciclo de demônios bufos do teatro ibérico.
A sistematização contemporânea de Eduardo Mauer, O Homem das Sete Dentaduras: Sátira  e
Monstruosidade Moral no Norte de Portugal (Lisboa, Associação MILK, 2024), resulta de recolha
etnográ fica e estudo comparado com iconografia grotesca medieval, apontando ligações com as
gravuras de Bosch e Bruegel.
Fontes complementares:
– Arquivo Distrital de Bragança, Coleção  Oral de Contos e Advertências  Morais, 1890–1935;
– Museu do Abade de Baçal, Cadernos Etnográ ficos Transmontanos (1948–1970);
– Tese de Doutoramento de Carla Paiva, O Grotesco e o Popular na Tradição  Oral Portuguesa (U.
Porto, 2016).
⸻
5. Síntese interpretativa final
O Homem das Sete Dentaduras representa o excesso como forma de punição. É a imagem do
sujeito que perdeu o limite e, com ele, a humanidade. O mito é sátira moral e re flexão estética
sobre a deformação do corpo pelo desmedido.
Na leitura simbólica da Associação  MILK, o Homem das Sete Dentaduras é figura do ruído
contemporâneo — o homem que fala sem pausa, consome sem medida, ri sem sentido. A lenda
adquire, assim, caráter metalinguístico: o monstro da comunicação vazia.
Na escultura MILK concebida por Eduardo Mauer, a figura é representada com cabeça grande e
aberta, de cuja boca emergem sucessivas camadas de dentes esculpidos. O corpo compacto e
as pernas curtas equilibram a monstruosidade da face. As cores predominantes são vermelho-
terra, dourado e negro. A peça é acompanhada por som grave de risos distorcidos.
⸻


6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer
Na leitura não binária de Eduardo Mauer, o Homem das Sete Dentaduras é o corpo do excesso
neutro — não masculino nem feminino, mas devorador. A multiplicidade de bocas é a
multiplicidade de identidades contemporâneas, cada uma tentando saciar uma fome simbólica.
Mauer escreve: “Ele é o corpo pós-humano do capitalismo arcaico — sete bocas, sete desejos,
sete impossibilidades.”
A Associação  MILK entende o mito como crítica à saturação moderna e como oportunidade de
reflexão sobre a linguagem, o consumo e o corpo. O Homem das Sete Dentaduras, em sua
deformidade, anuncia a necessidade de reconciliação com o silêncio — gesto não binário por
excelência, onde o falar e o calar se tornam o mesmo ato.
⸻
7. Referência Estrutural da Matriz MILK
Na Matriz Escultórica MILK, o Homem das Sete Dentaduras é modelado com cabeça
desproporcional e boca tripartida em camadas. O corpo compacto, de postura ligeiramente
curvada, expressa tensão. As cores são vermelho e dourado, com acabamento brilhante.
A instalação pode incluir iluminação ascendente que projeta sombras das dentaduras sobre o
solo, evocando o eco das palavras perdidas.
⸻
Localização  específica: Bragança, Vinhais, Melgaço e Monção, Norte de Portugal.
Primeiro relato documentado: Joaquim Alves Ferreira, Literatura de Trás-os-Montes  e Alto
Douro – Lendas e Contos Infantis, vol. IV, 1954.
Sistematização  contemporânea:  Eduardo Mauer, O Homem das Sete Dentaduras: Sátira  e
Monstruosidade Moral no Norte de Portugal, Associação MILK, 2024.
Fontes primárias:  Vasconcelos (1913); Ferreira (1954); Parafita (2008); Paiva (2016); Mauer
(2024).


---

# 025. O Fradinho da Mão  Furada (Trás-os-Montes  e Alto Douro)

**Origem documental:** PDF `folclore português (1).pdf`, enviado pelo utilizador.  
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

25. O Fradinho da Mão  Furada (Trás-os-Montes  e Alto Douro)
(Sistematização  contemporânea  conduzida por Eduardo Mauer no âmbito  das pesquisas sobre
Folclore Vivo da Associação  MILK – Movimento de Intervenções e Linguagens Kulturais e Arte)
⸻
1. Descrição  simbólica e narrativa
O Fradinho da Mão  Furada é uma das figuras mais complexas e fascinantes do folclore
transmontano, oscilando entre a travessura e o sagrado, o riso e o medo. De acordo com a
tradição oral recolhida por Eduardo Mauer nas aldeias de Miranda do Douro, Mogadouro,
Vinhais e Bragança, trata-se de um pequeno frade encapuçado, de rosto pálido e sorriso
zombeteiro, que surge nas noites de vento, entrando nas casas sem pedir licença. É conhecido
por roubar pão, vinho e moedas, mas, paradoxalmente, também por conceder pequenos favores:
“cura uma dor, abre um armário trancado, ou faz o fogo acender-se de novo”.
O traço mais característico da criatura é a mão  direita atravessada por um buraco, visível
quando estende o braço para pedir esmola ou abençoar. A “mão furada” é o sinal do seu destino
— punição e milagre em simultâneo.


Conta-se que, em tempos, o Fradinho fora um verdadeiro monge franciscano que roubara
moedas do cofre do convento. Descoberto, foi amaldiçoado a vaguear eternamente até devolver
o último vintém roubado. Desde então, reaparece nas aldeias nas noites de lua minguante,
batendo às janelas e oferecendo “bênçãos pagas”.
Outras versões, recolhidas em Mogadouro, apresentam o Fradinho como espírito protetor dos
pobres, que castiga os avarentos e recompensa os generosos. Em Vinhais, diz-se que ele anda
montado num galo preto e que o buraco da mão deixa passar a luz das almas.
Para Eduardo Mauer, “o Fradinho da Mão Furada é a figura-ponte entre o santo e o bufão. É o
mediador entre o sagrado institucional e o sagrado popular — aquele que paga o preço do dom.”
⸻
2. Contexto histórico e social
O mito do Fradinho insere-se na tradição portuguesa das figuras monásticas  ambíguas, que
proliferaram a partir do século XVII, quando o prestígio das ordens religiosas começou a declinar
e a cultura popular reagiu com ironia à autoridade clerical.
Os “fradinhos”, “padrecos” e “monges zombeteiros” eram protagonistas de contos burlescos e
moralizantes, denunciando a hipocrisia e o apego ao ouro. O Fradinho da Mão Furada cristaliza
essa crítica, mas confere-lhe dimensão mística: o pecado e a penitência coexistem no mesmo
corpo.
Em Trás-os-Montes, onde a religiosidade popular sempre conviveu com práticas mágicas, o frade
diminuto tornou-se também espírito doméstico. Como os trasgos e duendes ibéricos, entra nas
casas para baralhar, mas não para destruir.
No século XIX, Teófilo Braga e Leite de Vasconcelos registaram versões dispersas em que o
Fradinho é confundido com o diabo travestido. Já no século XX, Alexandre Parafita reinterpreta-
o como símbolo da moral reversa: o ladrão que se converte em benfeitor.
Para Mauer, a longevidade do mito explica-se porque ele incorpora “a contradição central da
alma portuguesa — piedade e picardia, culpa e riso — num mesmo gesto”.
⸻
3. Toponímia e variantes locais
A lenda é predominante em Trás-os-Montes  e Alto Douro, mas há registos no Alto Minho e na
Beira Alta, com pequenas variações. Em Miranda do Douro, chama-se “Fradinho da Luz”,
porque a mão furada brilha; em Vinhais, “Frade da Esquina”, pois aparece sempre junto aos
caminhos; em Mogadouro, é “Padrezinho das Sombras”.
Algumas casas rurais ainda mantêm orifícios circulares nas portas — “buracos do Fradinho” —
por onde se dizia que ele entrava sem abrir. Há também topónimos como “Fonte do Fradinho” e
“Lomba do Frade”, que indicam fixação territorial do mito.
Nos concelhos de Bragança e Mogadouro, as festas de Todos os Santos incluíam o costume de
deixar um copo de vinho e um pedaço de pão na janela “para o frade das almas”, tradição ainda
viva em aldeias envelhecidas.
⸻
4. Primeiro relato e fontes académicas primárias

O primeiro registo literário do Fradinho da Mão  Furada aparece em Leite de Vasconcelos,
Etnografia Portuguesa, vol. II (1913, pp. 245–250)*, onde o autor descreve “um espírito
zombeteiro com hábito de frade, de pequena estatura, dotado de mão perfurada”.
Teófilo Braga, O Povo Português  nos seus Costumes, Crenças e Tradições (1883, pp. 334–337)*,
menciona a história de um frade amaldiçoado a servir eternamente as casas dos pobres,
“restituindo com milagres o que roubou com moedas”.
Alexandre Parafita, Mitologia Popular Portuguesa (2008, pp. 401–406)*, analisa a figura como
herdeira dos “trasgos” ibéricos e dos “frailes burladores” espanhóis, símbolos da crítica popular
ao poder religioso.
A sistematização contemporânea de Eduardo Mauer, O Fradinho da Mão  Furada: Entre o
Sagrado e o Cómico no Imaginário  Transmontano (Lisboa, Associação MILK, 2024), combina
recolhas orais e iconografia de ex-votos, abordando a figura como alegoria da redenção  pelo
riso.
Fontes complementares:
– Arquivo Distrital de Bragança, Registos de Lendas Populares do Nordeste Português  (1930–
1955);
– Museu do Abade de Baçal, Cadernos Etnográ ficos Transmontanos (1952–1968);
– Tese de Doutoramento de Marta Costa, O Riso e a Culpa no Folclore Português  (U. Coimbra,
2018).
⸻
5. Síntese interpretativa final
O Fradinho da Mão Furada é um santo profano, expressão do dualismo português entre moral e
ironia. Ele representa o poder de rir de si mesmo, transformando o pecado em parábola. O
buraco da mão é símbolo da falta que liberta: o vazio que permite a passagem da luz.
Na leitura estética da Associação  MILK, o Fradinho personifica o Folclore Vivo na sua vertente
carnavalesca — o espaço onde o erro se converte em arte. Ele é simultaneamente o mendigo e o
milagre, o que tira e o que devolve.
Na escultura MILK concebida por Eduardo Mauer, o Fradinho aparece em posição dinâmica,
com corpo compacto e cabeça grande. A túnica curta de cor castanha e o buraco na mão direita
são elementos centrais. Do orifício emana luz dourada.
⸻
6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer
Na leitura não binária de Eduardo Mauer, o Fradinho da Mão Furada é o corpo híbrido da
redenção , simultaneamente pecador e santo, masculino e feminino, humano e espírito. A sua
mão vazada é o portal do entre-ser — a ferida que une.
Mauer escreve: “O Fradinho é o corpo queer da fé. A mão aberta é vagina e estigma, vazio e
passagem.” A sua luz interior dissolve o binário entre culpa e perdão, transformando a punição
em transfiguração.
A Associação  MILK lê a figura como manifesto pós-religioso da compaixão : a santidade nas
margens, o milagre risível, o corpo que redime sem hierarquia.
⸻


7. Referência Estrutural da Matriz MILK
Na Matriz Escultórica MILK, o Fradinho da Mão Furada apresenta-se de pé, hábito castanho-
avermelhado, cabeça grande e rosto sereno. A mão direita, perfurada, contém luz interna que se
projeta sobre o chão.
As cores predominantes são castanho-terroso, dourado e bege. A instalação pode incluir som de
sineta distante e respiração leve, evocando presença silenciosa.
⸻
Localização  específica: Miranda do Douro, Mogadouro, Vinhais e Bragança, Trás-os-Montes e
Alto Douro.
Primeiro relato documentado: Leite de Vasconcelos, Etnografia Portuguesa, vol. II, 1913.
Sistematização  contemporânea:  Eduardo Mauer, O Fradinho da Mão  Furada: Entre o Sagrado e
o Cómico no Imaginário  Transmontano, Associação MILK, 2024.
Fontes primárias:  Braga (1883); Vasconcelos (1913); Parafita (2008); Costa (2018); Mauer (2024).


---

# 026. Maria da Manta (Alto Minho e Trás-os-Montes)

**Origem documental:** PDF `folclore português (1).pdf`, enviado pelo utilizador.  
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

26. Maria da Manta (Alto Minho e Trás-os-Montes)
(Sistematização  contemporânea  conduzida por Eduardo Mauer no âmbito  das pesquisas sobre
Folclore Vivo da Associação  MILK – Movimento de Intervenções e Linguagens Kulturais e Arte)
⸻
1. Descrição  simbólica e narrativa
A Maria da Manta é uma das entidades mais obscuras e temidas do folclore do Norte de
Portugal. As tradições orais descrevem-na como uma mulher alta, envolta num manto negro que
lhe cobre o rosto e o corpo até os pés, surgindo junto a rios, poços e neblinas ao entardecer. O
seu olhar é descrito como fogo vivo, e as mãos, quando visíveis, lembram garras longas de cor
azulada. É tida como uma figura de advertência e castigo — a personi ficação do medo moral,
sobretudo das crianças e dos viajantes noturnos.
Os mais antigos relatos de Viana do Castelo, Melgaço e Bragança dizem que Maria da Manta
aparece nas noites em que “o vento corta o vale” ou quando “o nevoeiro desce sobre o rio”. Diz-
se que chama os transeuntes com voz doce e longínqua, oferecendo abrigo sob o seu manto.
Quem aceita o convite desaparece — “sumido para o fundo do rio”, como repetem as versões
orais.
Outras narrativas, menos punitivas, descrevem-na como guardiã da água, protetora das mulheres
violentadas e das crianças órfãs. Nesse caso, o seu manto é refúgio e não armadilha. Ela recolhe
as almas perdidas e as leva “para o outro lado do nevoeiro”.
A dualidade da figura — protetora e destruidora — é uma das marcas que mais fascinam os
investigadores. Segundo Eduardo Mauer, “Maria da Manta é o corpo ambíguo do feminino: o
ventre que abriga e o abismo que engole.”
O nome “Maria”, comum nas lendas portuguesas, associa a figura à dimensão popular do
sagrado; já “Manta” sugere tanto o pano que cobre quanto o gesto de envolver. Assim, o próprio
nome contém a tensão central da lenda: esconder ou proteger, disfarçar ou abrigar.
⸻
2. Contexto histórico e social
A lenda da Maria da Manta surge associada às margens do rio Lima e do rio Minho, estendendo-
se às serras de Trás-os-Montes, onde se cruzam antigas crenças aquáticas e femininas. O

contexto histórico remonta provavelmente à Idade Média, quando proliferavam as narrativas de
mulheres-feiticeiras ligadas à água e ao luar.
A tradição oral do Alto Minho descreve-a como “a sombra que vem da água” e relaciona a sua
aparição com mortes por afogamento, especialmente de crianças. Há registros de que, até o
início do século XX, mães e avós invocavam a Maria da Manta para amedrontar as crianças que
se aproximavam dos poços — “Sai daí, que a Maria da Manta te leva!”.
Mas, como demonstra Eduardo Mauer nas suas recolhas contemporâneas, por trás do aviso
punitivo existe também um substrato simbólico de proteção materna e ecológica. A figura serve
como metáfora da fronteira entre o humano e o natural — o ponto em que a água deixa de ser
utilidade e se torna mistério.
O mito, portanto, cumpre uma dupla função social: disciplinar e pedagógica, mas também ritual e
espiritual. Representa o respeito pela natureza e pelos limites da curiosidade humana.
Historicamente, a lenda reflete as relações de gênero e poder no mundo rural. Ao ser construída
como corpo perigoso, Maria da Manta encarna o medo da autonomia feminina e a repressão das
vozes femininas livres. É a mulher que age fora das regras, que caminha sozinha à noite, que
detém o poder da escolha — e, por isso, é transformada em monstro.
⸻
3. Toponímia e variantes locais
O mito é amplamente difundido no Alto Minho (Viana do Castelo, Ponte de Lima, Melgaço,
Monção) e em regiões de Trás-os-Montes  (Vinhais, Bragança, Mogadouro). Há registos também
no Douro Litoral, em aldeias de Amarante e Baião , sempre relacionados com cursos d’água e
vales de neblina.
Em Ponte de Lima, fala-se na “Maria da Manta do Rio Trovela”, que aparece nas noites de
trovoada; em Melgaço, a “Maria do Luar”, descrita como mulher de olhos brancos que protege
pescadores; e em Vinhais, a “Moura da Manta”, figura mais ligada ao encantamento e ao ouro
escondido.
Topónimos como “Poço da Manta”, “Vale das Mantas” e “Fonte da Maria” são encontrados em
diversas freguesias do Norte, indiciando persistência do mito na memória toponímica.
Há ainda tradições locais associadas à queima da manta — ritual de puri ficação realizado em
certas aldeias do Minho na noite de São João, em que se queimavam panos velhos junto a rios,
como forma de afastar maus espíritos.
⸻
4. Primeiro relato e fontes académicas primárias
O primeiro relato escrito sobre a Maria da Manta surge em Nuno Matos Valente, Bestiário
Tradicional Português  (Lisboa, 2017, pp. 58–63)*, que compila e analisa variantes orais do Minho
e de Trás-os-Montes. O autor descreve-a como “ figura noturna que vagueia entre o medo e a
piedade, símbolo do desconhecido feminino da água”.
Fontes mais antigas, como Leite de Vasconcelos, Etnografia Portuguesa, vol. III (1915, pp. 190–
194)*, mencionam “mulheres das águas” e “fantasmas de mantas” sem nome próprio,
associando-as a mouras encantadas.
Alexandre Parafita, Mitologia Popular Portuguesa (2008, pp. 210–215)*, identifica a Maria da
Manta como sobrevivência dos mitos das ninfas aquáticas e das mouras mouriscas — arquétipos
do feminino sedutor e proibido.


A sistematização contemporânea de Eduardo Mauer, Maria da Manta: Feminino, Água  e Medo
no Imaginário  do Norte Português  (Lisboa, Associação MILK, 2024), reúne fontes etnográ ficas,
entrevistas, fotografias de campo e análise simbólica comparada com mitos aquáticos da Europa
Atlântica.
Fontes complementares:
– Arquivo Distrital de Viana do Castelo, Cadernos de Tradições do Minho, 1930–1960;
– Museu da Terra de Miranda, Registos Orais de Trás-os-Montes , 1950–1975;
– Tese de Doutoramento de Joana Lobo, Mulheres da Água:  Género  e Paisagem no Folclore
Português  (U. Lisboa, 2019).
⸻
5. Síntese interpretativa final
A Maria da Manta é uma das expressões mais densas do feminino aquático português.
Representa a tensão entre o acolher e o destruir, o consolo e o castigo, o eros e o thanatos. É a
Senhora das Águas escuras, herdeira das mouras encantadas e das ninfas pré-cristãs, mas
transfigurada pela moral popular.
Na leitura da Associação  MILK, Maria da Manta simboliza a pedagogia do medo como forma de
preservação do mistério. Ao criar uma figura que amedronta, o povo protege o sagrado.
A escultura MILK concebida por Eduardo Mauer apresenta uma figura compacta, de cabeça
grande e corpo coberto por uma manta fluida em tons de preto e azul petróleo. A base espelhada
evoca a superfície da água. Uma luz interna vermelha simboliza o coração escondido sob o
manto.
⸻
6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer
Na leitura não binária de Eduardo Mauer, Maria da Manta é a entidade fluida por excelência. O
seu corpo encoberto dissolve os limites do género e do rosto. É um ser sem forma fixa — ora
mulher, ora neblina, ora sombra.
Mauer escreve: “A Manta é o véu da indeterminação. O corpo sob o pano é a metáfora do devir,
do que não precisa ser nomeado.”
A Associação  MILK interpreta o mito como oportunidade de reflexão sobre visibilidade e
invisibilidade. O manto não esconde — protege o direito de ser ambíguo. Maria da Manta, na
leitura contemporânea, é o ícone queer do anonimato poético: o corpo que escolhe não ser lido.
⸻
7. Referência Estrutural da Matriz MILK
Na Matriz Escultórica MILK, Maria da Manta é modelada com base oval espelhada e corpo
compacto coberto por manto ondulante. A cabeça grande e lisa, sem feições definidas,
representa o anonimato. As cores predominantes são preto, azul profundo e cinza metálico.
A instalação pode incluir iluminação vermelha interna e som ambiente de água em movimento e
murmúrios indistintos.
⸻
Localização  específica: Alto Minho (Viana do Castelo, Melgaço, Ponte de Lima) e Trás-os-
Montes (Bragança, Vinhais, Mogadouro).


Primeiro relato documentado: Nuno Matos Valente, Bestiário  Tradicional Português , 2017.
Sistematização  contemporânea:  Eduardo Mauer, Maria da Manta: Feminino, Água  e Medo no
Imaginário  do Norte Português , Associação MILK, 2024.
Fontes primárias:  Vasconcelos (1915); Parafita (2008); Valente (2017); Lobo (2019); Mauer (2024).


---

# 027. O Rosemunho (Trás-os-Montes  e Alto Douro)

**Origem documental:** PDF `folclore português (1).pdf`, enviado pelo utilizador.  
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

27. O Rosemunho (Trás-os-Montes  e Alto Douro)
(Descoberta e sistematização  contemporânea  conduzidas por Eduardo Mauer no âmbito  das
pesquisas sobre Folclore Vivo da Associação  MILK – Movimento de Intervenções e Linguagens
Kulturais e Arte)
⸻
1. Descrição  simbólica e narrativa
O Rosemunho, também conhecido em certas aldeias de Trás-os-Montes como “redemoinho do
meio-dia” ou “vento-da-alma”, é uma das manifestações mais antigas e misteriosas do
imaginário rural português. A palavra deriva de redemoinho e de rosnar, indicando
simultaneamente movimento e som, e designa uma entidade incorpórea que se manifesta sob a
forma de turbilhão de vento e pó, principalmente nas horas em que “o sol parte o céu em duas
metades”.
A tradição oral descreve o Rosemunho como uma presença viva do vento, espécie de espírito
errante que percorre os campos ao meio-dia, girando violentamente, levantando folhas, cinza e
palha, e produzindo um ruído semelhante a risos ou murmúrios. O povo acredita que dentro do
redemoinho viajam as almas penadas, as bruxas que perderam o caminho, ou ainda crianças não
batizadas. “Quem meter o pé no Rosemunho perde a alma e ganha o vento dentro do peito”,
dizem os antigos camponeses de Vinhais.
De acordo com recolhas efetuadas por Eduardo Mauer no âmbito do projeto Folclore Vivo da
Associação  MILK, as aldeias de Mirandela, Vinhais, Chaves e Carrazeda de Ansiães
conservam versões surpreendentemente vivas da lenda. Em Mirandela, o Rosemunho é visto
como castigo divino — a alma do blasfemo que fala ao meio-dia e é tragado pelo vento. Em
Vinhais, é o sopro de uma moura encantada libertando-se da pedra. Em Chaves, o redemoinho é
o próprio diabo disfarçado, tentando entrar nas casas pelas janelas abertas.
Nas narrativas contemporâneas recolhidas por Mauer, há também uma leitura poética: o
Rosemunho é “a respiração da terra” — uma forma de presença que não tem rosto nem corpo,
mas que toca todos os corpos. Ele fala na língua do ar.
A superstição popular prescreve gestos de proteção quando o Rosemunho aparece: fazer o sinal
da cruz, cuspir no chão, gritar o nome de Jesus ou lançar uma pedra ao centro do vento.
Acredita-se que assim se quebra o feitiço e se libertam as almas.
⸻
2. Contexto histórico e social
A origem da crença no Rosemunho remonta provavelmente à antiguidade pagã, vinculada aos
cultos agrários e à observação dos fenômenos atmosféricos. Na cosmologia camponesa, o vento
era entidade moral — mensageiro dos deuses, portador de castigo ou bênção. Em zonas áridas e
montanhosas, onde o vento domina a paisagem, a sua presença adquiriu estatuto sagrado.
Os estudos de Leite de Vasconcelos em Etnografia Portuguesa, vol. II (1913), já mencionavam o
“vento animado” e as “rodas de almas” em Trás-os-Montes, relacionando-as com tradições
celtas e mediterrâneas. O Rosemunho é, portanto, uma sobrevivência desses antigos ventos
espirituais, reinterpretados pela religiosidade católica como sinais de penitência.


No contexto social transmontano dos séculos XVIII e XIX, o mito funcionava como advertência
moral e ecológica. Dizia-se que “quem trabalha ao meio-dia desafia o sol e o vento” — uma
forma de impor repouso e respeito ao ritmo da natureza. Assim, o Rosemunho é também
guardião do tempo: o espírito que protege a pausa.
Durante o século XX, com a migração rural e o declínio da vida camponesa, o mito sobreviveu em
canções, rezas e provérbios. Idosas entrevistadas por Eduardo Mauer entre 2022 e 2024 ainda
recitam fórmulas de apaziguamento:
“Rosemunho, vento fino,
leva as culpas que são minhas,
deixa o trigo e leva o tino.”
Esse pequeno canto, registrado em Carrazeda de Ansiães , resume a função ritual da
lenda: purificar, deslocar, libertar o excesso.
⸻
3. Toponímia e variantes locais
Os topónimos “Vale do Rosemunho”, “Fonte do Redemoinho” e “Lomba do Vento” aparecem
repetidamente em cartas paroquiais e registos orais de Bragança, Mirandela e Carrazeda de
Ansiães , o que demonstra o enraizamento espacial do mito.
Em Miranda do Douro, fala-se no “Vento dos Mouros”, redemoinho que surge junto às antigas
muralhas; em Chaves, o fenómeno é chamado “o risso do meio-dia”, pela sonoridade rítmica que
o acompanha; e em Bragança, o termo “Rosemoinho” (com variação fonética) indica tanto o
vento como a alma que nele habita.
Há também paralelos ibéricos: na Galiza, o Remuíño  e o Demo dos Ventos; em Castela, o Diablo
del Aire. Essas variantes demonstram uma matriz partilhada de crenças na Península, adaptadas
a microclimas e dialetos locais.
⸻
4. Primeiro relato e fontes académicas primárias
O primeiro registo textual do Rosemunho surge em Teófilo Braga, O Povo Português  nos seus
Costumes, Crenças e Tradições (1883, pp. 289–291)*, que descreve “os redemoinhos que falam e
que arrastam as vozes dos mortos”.
Leite de Vasconcelos, Etnografia Portuguesa, vol. II (1913, pp. 233–238)*, aprofunda a temática,
citando informantes de Bragança e Vinhais que relacionam o vento com “a alma dos ímpios”.
Alexandre Parafita, Mitologia Popular Portuguesa (2008, pp. 250–254)*, classifica o Rosemunho
como “mito meteorológico moralizante”, símbolo da transgressão e do arrependimento.
A descoberta e sistematização contemporânea de Eduardo Mauer, O Rosemunho: Vento, Alma e
Transgressão  no Imaginário  Transmontano (Lisboa, Associação MILK, 2024), constitui o estudo
mais completo sobre o tema, combinando recolha etnográ fica, gravações sonoras de ventos
locais e leitura simbólica da paisagem sonora rural.
Fontes complementares:
– Arquivo Distrital de Bragança, Registos Orais do Nordeste Transmontano, 1902–1958;
– Museu da Terra de Miranda, Cadernos Etnográ ficos, 1936–1965;
– Tese de Mestrado de Tiago Fernandes, O Vento e o Sagrado: Fenomenologia do Ar no Folclore
Português  (U. Porto, 2020).


⸻
5. Síntese interpretativa final
O Rosemunho é o vento como consciência — a personi ficação do movimento e do invisível. É
simultaneamente fenómeno natural e entidade moral. Através dele, o povo expressa a ideia de
que nada morre: tudo se transforma em ar.
Na leitura estética da Associação  MILK, o Rosemunho é o emblema do Folclore Vivo em sua
dimensão atmosférica: o mito que não tem rosto, mas envolve todos os rostos. É o eco dos
mortos, mas também o sopro da criação.
A escultura MILK concebida por Eduardo Mauer traduz o ser em forma abstrata: uma figura
compacta, de cabeça grande, corpo em espiral ascendente e fendas que permitem a passagem
de luz e som. O acabamento em resina translúcida e tons de cinza-perolado simula o movimento
do ar.
⸻
6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer
Na leitura não binária de Eduardo Mauer, o Rosemunho é o corpo da transição  absoluta. Não
tem gênero, forma nem fronteira: é o ser que é puro movimento. Ele contém o masculino e o
feminino em suspensão, dissolvidos no fluxo do ar.
Mauer escreve: “O Rosemunho é o ser que não escolhe corpo — é o corpo que passa por todos.
É a respiração do mundo em estado queer.”
A Associação  MILK reconhece nessa leitura uma metáfora profunda da contemporaneidade: o
vento como identidade fluida, a alma que se move sem precisar fixar-se em gênero, forma ou
território. O Rosemunho torna-se, assim, o patrono etéreo do Folclore Vivo — entidade que não
se deixa capturar.
⸻
7. Referência Estrutural da Matriz MILK
Na Matriz Escultórica MILK, o Rosemunho é representado como espiral sólida de corpo
compacto e cabeça grande, atravessada por aberturas que permitem circulação de luz e som. A
base é circular e transparente, sugerindo movimento contínuo.
As cores predominantes são cinza-claro, branco e prateado, com iluminação interna em espiral. A
instalação pode incluir som real de vento recolhido em Trás-os-Montes durante as pesquisas de
campo de Mauer.
⸻
Localização  específica: Bragança, Vinhais, Chaves, Mirandela e Carrazeda de Ansiães, Trás-os-
Montes e Alto Douro.
Primeiro relato documentado: Teófilo Braga, O Povo Português  nos seus Costumes, Crenças e
Tradições, 1883.
Sistematização  contemporânea:  Eduardo Mauer, O Rosemunho: Vento, Alma e Transgressão  no
Imaginário  Transmontano, Associação MILK, 2024.
Fontes primárias:  Braga (1883); Vasconcelos (1913); Parafita (2008); Fernandes (2020); Mauer
(2024).


---

# 028. A Velha da Égua Branca (Alto Minho e Trás-os-Montes)

**Origem documental:** PDF `folclore português (1).pdf`, enviado pelo utilizador.  
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

28. A Velha da Égua Branca (Alto Minho e Trás-os-Montes)

(Sistematização  contemporânea  conduzida por Eduardo Mauer no âmbito  das pesquisas sobre
Folclore Vivo da Associação  MILK – Movimento de Intervenções e Linguagens Kulturais e Arte)
⸻
1. Descrição  simbólica e narrativa
A Velha da Égua Branca é uma das figuras mais inquietantes e complexas do imaginário rural
português, atravessando séculos de oralidade entre o Alto Minho, Trás-os-Montes  e, em
versões dispersas, o Douro Litoral. Descrita como uma velha montada numa égua branca
luminosa, que atravessa os campos durante as noites de luar, a personagem mistura atributos de
fantasma, bruxa e ancestral mítica. O seu aparecimento anuncia desgraças, tempestades ou
mortes, mas também, paradoxalmente, fertilidade e renovação.
Segundo os relatos recolhidos por Eduardo Mauer nas aldeias de Arcos de Valdevez, Melgaço,
Vinhais e Mirandela, a Velha é vista como mulher de longos cabelos prateados, rosto enrugado e
olhos de fogo. Monta sempre uma égua branca que não deixa pegadas e cuja crina emite luz
própria. Passa veloz pelas eiras e caminhos de montanha, soltando gargalhadas ou cânticos de
tom hipnótico. “Onde ela passa, os cães calam-se e o ar muda de peso”, dizem os mais antigos.
Em certas versões, a Velha é o espírito de uma mulher que morreu esperando o marido regressar
da guerra e que, por castigo, percorre as aldeias todas as noites, à procura dele. Em outras, é a
alma de uma feiticeira que cavalgou o vento e foi condenada a jamais tocar o chão. Também se
diz que aparece em noites de trovoada, quando a lua se reflete nas águas, e que o seu galope
desenha círculos de erva queimada.
Há quem a confunda com a Moura-Encantada ou com as Animas das Encruzilhadas, mas a
Velha da Égua Branca distingue-se por sua relação com o movimento e a luz. A égua representa
o corpo lunar e feminino, enquanto a cavaleira é o espírito ancestral da travessia — a mulher que
transita entre mundos.
Na interpretação poética de Eduardo Mauer, “a Velha da Égua Branca é a deusa esquecida do
movimento. A sua passagem é o sopro entre a morte e o renascer — a corrida do tempo com
rosto de mulher.”
⸻
2. Contexto histórico e social
A lenda da Velha da Égua Branca re flete camadas simbólicas acumuladas desde a Antiguidade.
As culturas indo-europeias veneravam divindades femininas associadas ao cavalo branco —
símbolo solar e psicopômpico (condutor de almas). Na Península Ibérica, restos dessas crenças
fundiram-se com tradições cristãs e medievais, produzindo figuras ambivalentes, ora
demonizadas, ora santificadas.
O cavalo branco aparece como emblema da pureza e do trânsito entre mundos em diversos
contextos europeus. Na Escandinávia, a deusa Freyja possuía uma montaria de cor branca; na
Bretanha, as Dames Blanches eram espíritos femininos que surgiam montadas sobre cavalos de
luz; na Galiza, o Cabalo Branco do Monte Pindo conduz as almas ao mar. A lenda portuguesa da
Velha da Égua Branca pertence a essa família de mitos atlânticos que unem o feminino e o
movimento, o animal e o espiritual.
Em Trás-os-Montes e no Minho, a tradição camponesa reinterpretou essa herança à luz da
religiosidade popular. O cavalo — animal de trabalho e nobreza — torna-se mensageiro, e a
velha, símbolo do ciclo vital: a anciã que guarda a passagem entre gerações. O aparecimento da
Velha podia ser sinal de mudança de tempo, de morte ou de colheita abundante, dependendo da
estação e do lugar.


Os registos orais mostram também um substrato moral: a Velha surge para lembrar a finitude e
o respeito pela natureza. O seu percurso noturno é o caminho do equilíbrio — aviso contra a
arrogância humana perante o mistério do tempo.
Eduardo Mauer observa que “a Velha é o arquétipo da sabedoria que se move — o corpo idoso
que ainda cavalga, que ainda brilha, que não aceita a imobilidade a que a cultura patriarcal o
condenou”.
⸻
3. Toponímia e variantes locais
O mito manifesta-se principalmente nas regiões do Alto Minho (Arcos de Valdevez, Melgaço,
Ponte da Barca, Monção) e de Trás-os-Montes  (Bragança, Mirandela, Vinhais). Existem, porém,
variantes na Beira Alta e em Amarante, sempre ligadas à imagem da mulher montada em cavalo
branco.
Em Arcos de Valdevez, fala-se da “Velha da Lomba”, que percorre as eiras ao som de sinos
invisíveis; em Melgaço, narra-se que a Velha atravessa o rio Minho montada na égua,
caminhando sobre as águas; em Mirandela, dizem que ela surge durante as tempestades,
quando “o vento se veste de mulher”.
Há ainda referências a locais com topónimos simbólicos — “Vale da Égua”, “Poço da Branca”,
“Cabeço da Velha” — que reforçam a inscrição do mito na paisagem. Em aldeias de Vinhais, os
camponeses evitam lavrar no “caminho da Velha” durante a lua cheia, por medo de ofender a
passagem noturna.
As versões mais recentes, recolhidas por Mauer, aproximam o mito da Moura-Encantada e da
Maria da Manta, formando um sistema simbólico do feminino noturno e transformador.
⸻
4. Primeiro relato e fontes académicas primárias
O primeiro registo textual da Velha da Égua Branca encontra-se em Teófilo Braga, O Povo
Português  nos seus Costumes, Crenças e Tradições (1883, pp. 310–312)*, onde o autor menciona
“a velha que cavalga a lua e anuncia as tempestades”.
Leite de Vasconcelos, Etnografia Portuguesa, vol. IV (1915, pp. 245–249)*, recolhe testemunhos
de Trás-os-Montes sobre “espíritos femininos montados em animais claros que percorrem os
montes nas noites de vento”.
Alexandre Parafita, Mitologia Popular Portuguesa (2008, pp. 276–281)*, relaciona a Velha da
Égua Branca com as antigas “cavaleiras brancas” europeias e com os mitos das Damas do Luar,
destacando a sua função de mediadora entre a vida e a morte.
A sistematização contemporânea de Eduardo Mauer, A Velha da Égua  Branca: Feminino, Luz e
Movimento no Imaginário  do Norte de Portugal (Lisboa, Associação MILK, 2024), baseia-se em
recolhas orais, documentação fotográ fica e análise comparada de narrativas europeias, propondo
leitura estética do mito como metáfora da vitalidade senescente.
Fontes complementares:
– Arquivo Distrital de Braga, Registos Orais do Minho e Trás-os-Montes , 1930–1960;
– Museu da Terra de Miranda, Cadernos de Etnografia e Simbologia, 1950–1975;
– Tese de Doutoramento de Helena Correia, Cavalos e Deusas: Iconografia do Movimento no
Imaginário  Ibérico  (U. Lisboa, 2020).
⸻


5. Síntese interpretativa final
A Velha da Égua Branca condensa no seu corpo duplo — mulher e cavalo — o mito da travessia
e da persistência. Ela é o tempo que não para, a vida que não cessa, o riso da morte em forma
de galope. O seu caráter ambivalente — ora espectral, ora maternal — revela a complexidade do
sagrado feminino no Norte português.
Na leitura da Associação  MILK, o mito é expressão da sabedoria em movimento, uma
metáfora da continuidade intergeracional e do poder do corpo envelhecido. A Velha cavalga a
Égua Branca como quem recusa o fim.
A escultura MILK criada por Eduardo Mauer representa a figura com cabeça grande e corpo
compacto, sentada sobre uma égua de contornos suaves e translúcidos. As cores predominantes
são branco e prateado, com re flexos azulados. O manto da Velha, parcialmente transparente,
emite luz interna que pulsa como o coração de uma estrela.
⸻
6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer
Na leitura não binária de Eduardo Mauer, a Velha da Égua Branca é o corpo que ultrapassa o
tempo e o género. A idade dissolve a sexualidade normativa, e o cavalo branco torna-se veículo
da androginia simbólica.
Mauer escreve: “A Velha é o corpo em transição constante. O seu cavalo é o género em
movimento. Juntos, galopam para fora da linguagem.”
A Associação  MILK lê o mito como celebração da longevidade queer, onde o envelhecimento é
visto como libertação das formas fixas. A Velha é o corpo pós-binário por excelência — luminoso,
livre, em galope contínuo.
⸻
7. Referência Estrutural da Matriz MILK
Na Matriz Escultórica MILK, a Velha da Égua Branca apresenta cabeça grande e expressão
calma, corpo compacto e montaria de linhas curvas. A égua, de material translúcido, possui crina
luminosa e base espelhada.
A iluminação alterna branco e azul, simulando a passagem da lua, enquanto som ambiente
reproduz vento suave e galope ritmado.
⸻
Localização  específica: Alto Minho (Arcos de Valdevez, Melgaço, Ponte da Barca, Monção) e
Trás-os-Montes (Vinhais, Mirandela).
Primeiro relato documentado: Teófilo Braga, O Povo Português  nos seus Costumes, Crenças e
Tradições, 1883.
Sistematização  contemporânea:  Eduardo Mauer, A Velha da Égua  Branca: Feminino, Luz e
Movimento no Imaginário  do Norte de Portugal, Associação MILK, 2024.
Fontes primárias:  Braga (1883); Vasconcelos (1915); Parafita (2008); Correia (2020); Mauer
(2024).
