# Corpus integral auditado — parte 03

Entradas 029 a 042.



---

# 029. A Coca de Monção  (Alto Minho)

**Origem documental:** PDF `folclore português (1).pdf`, enviado pelo utilizador.  
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

29. A Coca de Monção  (Alto Minho)

(Sistematização  contemporânea  conduzida por Eduardo Mauer no âmbito  das pesquisas sobre
Folclore Vivo da Associação  MILK – Movimento de Intervenções e Linguagens Kulturais e Arte)
⸻
1. Descrição  simbólica e narrativa
A Coca de Monção  é uma das mais antigas e emblemáticas entidades mítico-rituais do Norte de
Portugal. Simultaneamente monstro, alegoria e personagem festiva, a Coca é descrita como um
dragão  ou serpente alada de corpo escamoso e boca flamejante, que enfrenta São Jorge na
Festa do Corpo de Deus, realizada anualmente na vila minhota de Monção desde pelo menos o
século XVI. A sua presença, contudo, transcende o contexto religioso, assumindo a função
simbólica de guardião  da fertilidade e da renovação  cíclica.
Nos relatos orais recolhidos por Eduardo Mauer e nas fontes históricas preservadas no Arquivo
Municipal de Monção , a Coca é vista como criatura de força telúrica, associada às águas do rio
Minho e aos campos férteis que o circundam. Diz-se que vive sob as pontes ou nas grutas do
vale e que, uma vez por ano, emerge para desafiar o santo guerreiro. A luta entre ambos
simboliza o confronto entre o caos e a ordem, o instinto e a razão, a natureza e a fé.
Nas versões populares, a Coca é uma fêmea — “a serpente-mãe”, “a dragona” —, o que
aproxima o mito português de tradições matriarcais antigas. O seu rugido, dizem, “mexe com o
ventre das mulheres” e “faz o milho crescer mais alto”. Mesmo quando derrotada, a Coca nunca
morre: apenas se recolhe às águas, à espera de um novo ciclo.
A dualidade entre São Jorge e a Coca não é de destruição, mas de equilíbrio dinâmico . O
cavaleiro representa a luz disciplinadora; a Coca, a força primordial. Em Monção, o combate é
encenado como dança: a luta ritual transforma-se em coreografia, e o monstro torna-se parceiro.
Na leitura simbólica de Eduardo Mauer, “a Coca é o útero cósmico do Minho — o ventre que
sangra, se ergue e floresce. Ela encarna o poder cíclico do feminino reprimido que retorna sob
forma de espetáculo”.
⸻
2. Contexto histórico e social
A origem do mito remonta às antigas celebrações agrícolas pré-cristãs , onde dragões e
serpentes representavam o ciclo das estações e a fecundidade da terra. No processo de
cristianização da Península Ibérica, essas entidades foram reinterpretadas à luz das hagiogra fias
— particularmente a de São Jorge —, convertendo-se em símbolos do mal vencido pela fé.
Em Monção, no entanto, o sincretismo assumiu caráter peculiar. Desde o século XVI,
documentos e crónicas descrevem a “dança da Coca” como parte essencial das procissões do
Corpo de Deus, festa de caráter tanto religioso quanto comunitário. O povo assistia ao duelo
entre São Jorge (representado por um cavaleiro) e a Coca ( figura articulada e colorida), que, ao
final, era simbolicamente derrotada, mas sempre renascia no ano seguinte.
Durante os séculos XVIII e XIX, a representação consolidou-se como parte da identidade
monçanense. A Coca passou a desfilar pelas ruas acompanhada de grupos de bombos e gaitas-
de-foles, atraindo multidões. O monstro, outrora símbolo do mal, transformou-se em ícone de
celebração  popular e pertença coletiva.
O contexto social da festa reforça o caráter integrador da lenda. A participação comunitária — de
crianças, músicos, artesãos e cavaleiros — faz da Coca um rito de coesão  intergeracional, no
qual o medo e a alegria se fundem.


Para Eduardo Mauer, a permanência da Coca demonstra “a capacidade do folclore minhoto de
absorver e transmutar o sagrado: o dragão pagão converte-se em corpo cívico, em dança, em
riso”.
⸻
3. Toponímia e variantes locais
A Coca é especí fica de Monção , mas variantes do mesmo mito encontram-se noutras regiões do
Minho e da Galiza, confirmando a sua origem partilhada. Em Valença e Melgaço, há referências
à “Coca do Rio” e à “Bicha-Serpente”; na Galiza, o Coco e a Coca de Redondela desempenham
funções semelhantes nas festas de Corpus Christi.
O nome “Coca” provém do latim caucus (oco, côncavo) e do galego-português coco, termo que
designava espectros e máscaras. O vocábulo deu origem ao “papão” infantil — “o bicho-papão”
—, derivando assim da mesma raiz simbólica: o ser que amedronta para educar.
Topónimos como “Penedo da Coca”, “Poço da Serpe” e “Lagoa da Mãe das Águas” são comuns
nas margens do Minho, atestando o enraizamento do mito na paisagem. Em muitos desses
lugares, ainda hoje se deixam flores e velas em honra da “Senhora das Águas”, reminiscência
pagã incorporada à devoção mariana.
⸻
4. Primeiro relato e fontes académicas primárias
O primeiro relato documentado da Coca de Monção  aparece no manuscrito Crónica das Festas
do Corpo de Deus de Monção , de Baltazar da Fonseca (1595), conservado no Arquivo
Municipal de Monção , que descreve o “monstro em figura de cobra com asas e fogo na boca”
que “peleja com o cavaleiro Jorge, e ao fim é vencido com muito alvoroço do povo”.
Teófilo Braga, O Povo Português  nos seus Costumes, Crenças e Tradições (1883, pp. 321–326)*,
retoma a referência, identi ficando a festa como sobrevivência de antigos cultos agrários de
fecundidade.
Leite de Vasconcelos, Etnografia Portuguesa, vol. IV (1915, pp. 255–260)*, classifica a Coca
como exemplo de “dracomaquia ritual” — combate simbólico entre santo e serpente — e
sublinha o papel das mulheres na ornamentação e nos cânticos da procissão.
Alexandre Parafita, Mitologia Popular Portuguesa (2008, pp. 300–307)*, reinterpreta a Coca
como “mito de reconciliação cíclica entre o fogo e a água”.
A sistematização contemporânea de Eduardo Mauer, A Coca de Monção:  Corpo, Festa e
Ressurgimento do Mito no Minho (Lisboa, Associação MILK, 2024), reexamina as fontes, integra
registos visuais e sonoros, e propõe leitura estética e política da Coca como dispositivo
comunitário  de resistência cultural.
Fontes complementares:
– Arquivo Municipal de Monção, Crónicas das Festas do Corpo de Deus, 1595–1890;
– Museu de Etnografia de Viana do Castelo, Cadernos do Minho, 1950–1980;
– Tese de Doutoramento de Rita Leite, Dragões e Devoções: As Cocas do Noroeste Ibérico  (U.
Minho, 2019).
⸻
5. Síntese interpretativa final

A Coca de Monção é o mito que dança. Encena o eterno retorno: morrer para renascer, ser
vencida para continuar. O dragão, símbolo da terra e da água, representa a energia criadora que
o cristianismo tentou domar, mas que o povo reabilitou como celebração.
Na leitura simbólica da Associação  MILK, a Coca é a personificação  do folclore como
resistência — o corpo feminino, monstruoso e festivo que sobrevive às instituições.
A escultura MILK concebida por Eduardo Mauer representa a Coca como dragão de corpo
compacto e cabeça grande, com escamas iridescentes em tons de verde, vermelho e dourado. A
boca aberta revela sete dentes simbólicos — referência ao ciclo da renovação. A peça possui
iluminação interna pulsante e superfície envernizada, evocando o brilho cerimonial da festa.
⸻
6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer
Na leitura não binária de Eduardo Mauer, a Coca é o corpo queer da celebração  —
simultaneamente masculino e feminino, santo e profano, devorado e devorador. A sua luta com
São Jorge não é combate, mas dança da coexistência.
Mauer escreve: “A Coca é o dragão que dança para não morrer. É o corpo plural que recusa o
destino de monstro e o transforma em movimento. É o folclore que se reencarna a cada passo.”
A Associação  MILK interpreta a Coca como ícone da pedagogia da alegria — o corpo híbrido e
festivo que dissolve o medo pela arte. Na sua leitura pós-binária, o mito torna-se metáfora do
renascimento cultural e da persistência das formas populares de expressão.
⸻
7. Referência Estrutural da Matriz MILK
Na Matriz Escultórica MILK, a Coca é modelada com corpo robusto, cabeça grande, escamas
estilizadas e cauda espiralada. As cores predominantes são verde, vermelho e dourado, com
acabamento em verniz marítimo. A instalação inclui som ambiente de tambores e gaitas,
remetendo à Festa do Corpo de Deus de Monção.
⸻
Localização  específica: Monção, Alto Minho.
Primeiro relato documentado: Crónica das Festas do Corpo de Deus de Monção , Baltazar da
Fonseca, 1595.
Sistematização  contemporânea:  Eduardo Mauer, A Coca de Monção:  Corpo, Festa e
Ressurgimento do Mito no Minho, Associação MILK, 2024.
Fontes primárias:  Fonseca (1595); Braga (1883); Vasconcelos (1915); Parafita (2008); Leite
(2019); Mauer (2024).


---

# 030. O Trasgo (Trás-os-Montes  e Alto Minho)

**Origem documental:** PDF `folclore português (1).pdf`, enviado pelo utilizador.  
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

30. O Trasgo (Trás-os-Montes  e Alto Minho)
(Sistematização  contemporânea  conduzida por Eduardo Mauer no âmbito  das pesquisas sobre
Folclore Vivo da Associação  MILK – Movimento de Intervenções e Linguagens Kulturais e Arte)
⸻
1. Descrição  simbólica e narrativa
O Trasgo é uma das figuras mais antigas e persistentes do imaginário ibérico e português,
sobrevivente de um tempo em que o mundo era povoado por espíritos domésticos, duendes e

forças da natureza dotadas de consciência. Em Portugal, particularmente nas regiões de Trás-
os-Montes e do Alto Minho, o Trasgo é descrito como um ser diminuto, de aparência humana
deformada — corpo baixo e robusto, rosto enrugado e nariz alongado —, que veste um gorro
vermelho e calções curtos, e habita os sótãos, moinhos ou celeiros das casas rurais.
Apesar de travesso e por vezes malicioso, o Trasgo raramente é malvado. É, antes, um espírito
ambíguo, que castiga os desordeiros, mas protege os que o respeitam. Gosta de roubar comida,
trocar os objetos de lugar, fazer barulho à noite e pregar partidas a quem trabalha demais ou de
menos. Em muitas aldeias, diz-se que, se o Trasgo se aborrece, “vira tudo de pernas para o ar”.
O seu sinal mais distintivo é o gorro vermelho, que nunca tira da cabeça. Segundo as versões
mais antigas, se alguém conseguir roubar-lhe o gorro, o Trasgo perde os poderes e deve
obedecer a quem o detém. Esse elemento aparece também no folclore asturiano e galego,
revelando uma origem ibérica comum.
Algumas variantes recolhidas por Eduardo Mauer nas aldeias de Bragança, Vinhais, Melgaço e
Monção  descrevem-no como espírito do lar (espírito  da casa), herdeiro dos antigos “lares
domésticos” romanos e das crenças célticas em duendes familiares. Quando tratado com
respeito — com um prato de leite ou pão deixado à noite —, o Trasgo assegura boa sorte e
colheitas férteis. Quando ignorado, manifesta-se com ruídos, risos e pequenas vinganças.
Na leitura poética de Mauer, “o Trasgo é o riso da casa — a alma invisível que recorda que o
humano vive com o mundo, e não sobre ele.”
⸻
2. Contexto histórico e social
O mito do Trasgo remonta a uma tradição europeia de espíritos domésticos e tutelares, que
atravessa milénios. Nas culturas célticas e germânicas, esses seres eram guardiões do lar e das
colheitas — elfos, brownies, kobolds — que evoluíram, com a cristianização, para demónios
menores ou figuras moralmente ambíguas.
Em Portugal, as referências mais antigas datam da Idade Média. Documentos do século XIII
mencionam “trasgos e duendes” como “espíritos do ar” nas crónicas eclesiásticas. O Livro das
Leis e Posturas de Guimarães  (século XV) proíbe “as falas com trasgos e mouras”, indicando a
sua presença viva nas crenças populares.
Durante os séculos XVII e XVIII, o Trasgo foi reinterpretado pela literatura moralista como símbolo
da preguiça e da desordem doméstica. Contudo, nas zonas rurais transmontanas e minhotas, o
povo manteve a visão de um ser protetor, brincalhão e necessário ao equilíbrio da casa.
Na oralidade moderna, o Trasgo sobreviveu como personagem de histórias infantis e contos de
advertência. Em muitos lares, ainda se diz “há Trasgo nesta casa” quando um objeto desaparece
misteriosamente.
Para Eduardo Mauer, a longevidade do mito deve-se à sua função simbólica de relembrar a
reciprocidade entre humanos e espaço doméstico. O Trasgo encarna a casa viva, o lugar
animado.
⸻
3. Toponímia e variantes locais
O termo Trasgo é amplamente difundido em Trás-os-Montes e no Minho, com variantes fonéticas
como Trago, Trasno, Trasu ou Trazgo. Em Vinhais e Bragança, é também chamado “o Pequeno
de Vermelho”.


Em Melgaço, fala-se do “Trasgo da Eira”, que ajuda a ceifar o milho durante a noite, deixando
rastos circulares no campo. Em Monção , o “Trasgo da Ponte” é espírito guardião das águas. Em
Montalegre, conta-se que o Trasgo aparece sob a forma de vento leve que abre as janelas.
Os topónimos “Fonte do Trasgo”, “Caminho dos Trasgos” e “Eira dos Duendes” surgem em
registos paroquiais e memoriais orais do norte português, especialmente junto a cursos d’água e
vales agrícolas.
Na Galiza e Astúrias, o Trasno é idêntico ao Trasgo português, reforçando a natureza
transfronteiriça do mito e a sua difusão pelo espaço cultural galaico-português.
⸻
4. Primeiro relato e fontes académicas primárias
O primeiro registo escrito do Trasgo em Portugal surge em Teófilo Braga, O Povo Português  nos
seus Costumes, Crenças e Tradições (1883, pp. 196–201)*, onde o autor o descreve como
“duende pequeno de gorro vermelho, que habita as casas e protege as mulheres trabalhadeiras”.
Leite de Vasconcelos, Etnografia Portuguesa, vol. II (1913, pp. 270–276)*, fornece a descrição
mais detalhada, baseada em testemunhos de Trás-os-Montes e Minho, e associa o Trasgo aos
antigos lares romanos e aos domovoi eslavos.
Alexandre Parafita, Mitologia Popular Portuguesa (2008, pp. 150–157)*, reconhece o Trasgo
como “símbolo do pequeno caos necessário” — a força que recorda o humano de que o mundo
não é inteiramente controlável.
A sistematização contemporânea de Eduardo Mauer, O Trasgo: Espírito  Doméstico  e Arquitetura
do Invisível  (Lisboa, Associação MILK, 2024), articula pesquisa etnográ fica, análise simbólica e
teoria da habitação, propondo o Trasgo como paradigma estético da presença viva do espaço.
Fontes complementares:
– Arquivo Distrital de Bragança, Registos Orais do Nordeste Transmontano, 1890–1950;
– Museu do Abade de Baçal, Cadernos de Etnografia Transmontana, 1954–1976;
– Tese de Doutoramento de Inês Pereira, Casas Animadas: O Sobrenatural Doméstico  na Tradição
Portuguesa (U. Porto, 2017).
⸻
5. Síntese interpretativa final
O Trasgo é a miniatura do sagrado cotidiano. Representa a continuidade entre o humano e o
doméstico, o corpo e o abrigo. Na sua travessura, revela a ética do convívio: o lar é partilhado,
nunca possuído.
Na leitura da Associação  MILK, o Trasgo é o espírito pedagógico da convivência — o
lembrete de que o mundo não é inerte. É também o modelo poético de uma ecologia espiritual: o
espaço é ser, e o ser é relação.
Na escultura MILK concebida por Eduardo Mauer, o Trasgo é representado com corpo
compacto, cabeça grande e gorro vermelho. O rosto expressa riso travesso. As cores
predominantes são vermelho, ocre e castanho. O corpo, de textura rugosa, simboliza o barro e a
terra das casas rurais.
⸻
6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer

Na leitura não binária de Eduardo Mauer, o Trasgo é o ser da fronteira mínima — nem homem,
nem mulher, nem espírito puro, nem matéria bruta. É o corpo da transição quotidiana.
Mauer escreve: “O Trasgo é o queer do lar: aquele que desarruma para ensinar, que troca os
lugares fixos, que recusa o normal.”
A Associação  MILK interpreta o mito como metáfora da pedagogia da imperfeição — o
reconhecimento de que o erro, a desordem e a diferença são necessários à vida. O Trasgo é,
portanto, o guardião do desequilíbrio vital, do riso como ordem.
⸻
7. Referência Estrutural da Matriz MILK
Na Matriz Escultórica MILK, o Trasgo é modelado com corpo baixo, cabeça grande e gorro
vermelho cônico. O corpo compacto e os membros curtos seguem a proporção simbólica da
série Folclore Vivo.
As cores predominantes são o vermelho, o ocre e o castanho. A base circular simula chão de
terra. A instalação pode incluir som ambiente de risadas e passos ligeiros.
⸻
Localização  específica: Bragança, Vinhais, Melgaço, Monção, Alto Minho e Trás-os-Montes.
Primeiro relato documentado: Teófilo Braga, O Povo Português  nos seus Costumes, Crenças e
Tradições, 1883.
Sistematização  contemporânea:  Eduardo Mauer, O Trasgo: Espírito  Doméstico  e Arquitetura do
Invisível , Associação MILK, 2024.
Fontes primárias:  Braga (1883); Vasconcelos (1913); Parafita (2008); Pereira (2017); Mauer
(2024).


---

# 031. A Pieira dos Lobos (Trás-os-Montes)

**Origem documental:** PDF `folclore português (1).pdf`, enviado pelo utilizador.  
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

31. A Pieira dos Lobos (Trás-os-Montes)
(Sistematização  contemporânea  conduzida por Eduardo Mauer no âmbito  das pesquisas sobre
Folclore Vivo da Associação  MILK – Movimento de Intervenções e Linguagens Kulturais e Arte)
⸻
1. Descrição  simbólica e narrativa
A Pieira dos Lobos é uma das entidades mais antigas, misteriosas e poéticas do folclore
transmontano, símbolo das zonas altas e agrestes do Norte de Portugal, onde o lobo — presença
temida e sagrada — sempre ocupou um lugar central na imaginação popular. A palavra pieira
designa tanto o som agudo produzido por certos animais quanto, por extensão, o eco espectral
que acompanha as alcateias nas noites de inverno. Assim, a Pieira dos Lobos não é apenas um
ser, mas uma voz — espírito feminino que guia, protege ou amaldiçoa os lobos nas suas caçadas
noturnas.
De acordo com as recolhas realizadas por Eduardo Mauer entre 2021 e 2024, nas serras de
Montalegre, Vinhais, Bragança e Mirandela, a Pieira é descrita como mulher alta e magra, de
cabelos longos e brancos, rosto pálido e olhos faiscantes. Aparece envolta num manto cinzento
ou numa pele de lobo, deslizando silenciosa entre a neve e as giestas. Às vezes é vista como
mãe  dos lobos, outras como alma penada de uma mulher injustiçada que, após a morte,
passou a guiar os animais selvagens.
O povo diz que o seu grito corta o vento e “desenha o caminho da fome”. Quando a Pieira uiva,
as aldeias fecham portas e apagam luzes, pois anuncia tempestade, desgraça ou luto. Contudo,

há também versões benevolentes, nas quais ela protege os lobos da perseguição humana e
castiga caçadores que matam por prazer.
Segundo a tradição oral de Vinhais, a Pieira habita “as furnas onde o sol não entra” e aparece
sobretudo nas noites de lua cheia, acompanhada por uma alcateia invisível. A sua voz mistura-se
com o vento, confundindo homens e animais. É ao mesmo tempo mulher, eco e natureza.
Para Eduardo Mauer, “a Pieira é a garganta do mundo selvagem: a vibração que liga o grito
humano ao uivo animal. É o feminino que dá voz à floresta.”
⸻
2. Contexto histórico e social
A origem da crença na Pieira dos Lobos relaciona-se com o papel ambivalente do lobo na cultura
ibérica. Desde a Antiguidade, o lobo simboliza tanto a ameaça como a sabedoria ancestral. As
culturas pré-romanas veneravam-no como animal totémico, mensageiro dos deuses e guardião
das fronteiras. Com a cristianização, o seu estatuto foi degradado: o lobo tornou-se metáfora do
mal, do diabo e da selvageria.
No entanto, em regiões isoladas como Trás-os-Montes, o imaginário pagão resistiu sob formas
sincréticas. A Pieira representa a reversão  desse estigma, sendo a mulher que reaproxima o
humano do selvagem. Ela é a mediadora entre mundos — ponte entre aldeia e montanha, vida e
morte, civilização e natureza.
Durante os séculos XVIII e XIX, os relatos sobre a Pieira intensi ficaram-se, acompanhando o
declínio real dos lobos em Portugal. À medida que a caça e a agricultura moderna avançavam, a
lenda transformou-se em elegia — lamento pela perda da floresta e dos antigos pactos com o
natural.
Na oralidade moderna recolhida por Mauer, idosos descrevem a Pieira como “a alma da serra que
não quer morrer” ou “a mãe que ainda chama os filhos lobos para não se perderem”. Em algumas
aldeias, sobretudo em Montalegre e Padornelos, reza-se para a Pieira “não gritar muito perto”,
pois isso significaria que a montanha está zangada.
No contexto simbólico contemporâneo, a Pieira dos Lobos é metáfora do grito ecológico — a
voz feminina da natureza ameaçada.
⸻
3. Toponímia e variantes locais
A presença toponímica do mito é notável: “Vale da Pieira”, “Serra da Lobagueira”, “Fonte do
Uivo”, “Furna da Mulher-Lobo” e “Lomba da Voz” são nomes recorrentes em mapas rurais de
Bragança, Montalegre e Chaves. Esses lugares correspondem frequentemente a zonas de
antigas alcateias ou a grutas com ressonância acústica peculiar, reforçando a dimensão sonora
do mito.
Em Mirandela, fala-se da “Pieira da Fraga Negra”, associada a ventos repentinos e vozes
femininas que se escutam nas ravinas. Em Vinhais, a “Velha dos Lobos” é versão humanizada da
mesma entidade, enquanto em Bragança, a “Senhora da Voz do Vento” é invocada pelos
pastores como protetora do gado.
Há ainda paralelos galegos e asturianos, como a Güestia dos Lobos e a Pega da Serra, ambas
espíritos femininos guias de animais selvagens. Tais correspondências demonstram a pertença
do mito a um complexo atlântico  de figuras xamânicas  femininas.
⸻


4. Primeiro relato e fontes académicas primárias
O primeiro registo textual conhecido da Pieira dos Lobos encontra-se em Leite de
Vasconcelos, Etnografia Portuguesa, vol. III (1915, pp. 197-202)*, onde o autor transcreve
testemunhos de Montalegre e Chaves sobre “vozes de mulher que uivam com os lobos e os
conduzem à presa”.
Teófilo Braga, em O Povo Português  nos seus Costumes, Crenças e Tradições (1883, pp.
334-336)*, menciona “as senhoras dos lobos” como remanescência de antigas sacerdotisas da
montanha.
Alexandre Parafita, Mitologia Popular Portuguesa (2008, pp. 181-189)*, interpreta a Pieira como
“entidade liminar entre a mulher e o animal, guardiã da fronteira selvagem e da justiça natural”.
A sistematização contemporânea de Eduardo Mauer, A Pieira dos Lobos: Voz, Feminino e
Ecologia no Imaginário  Transmontano (Lisboa, Associação MILK, 2024), integra trabalho de
campo, gravações de áudio de ventos e relatos orais, além de análise simbólica da voz e da
ecologia sonora.
Fontes complementares:
– Arquivo Distrital de Bragança, Registos Etnográ ficos do Nordeste, 1920-1960;
– Museu da Terra de Miranda, Cadernos do Lobo e da Serra, 1958-1985;
– Tese de Doutoramento de Catarina Pires, Mulheres e Lobos: Mitologia e Ecologia do Feminino
Selvagem (U. Lisboa, 2021).
⸻
5. Síntese interpretativa final
A Pieira dos Lobos simboliza a reconciliação entre humano e animal, corpo e voz, razão e
instinto. É o grito da montanha, o eco da terra que lembra ao homem o seu parentesco com o
selvagem. Na cultura contemporânea, a Pieira ressurge como arquétipo da voz feminina
ecológica, antecipando leituras ecofeministas e pós-humanas.
Para a Associação  MILK, a Pieira é figura de resistência e escuta — a alma que fala quando o
humano cala. Ela encarna o folclore sonoro, onde o mito é vibração e não apenas narrativa.
A escultura MILK criada por Eduardo Mauer apresenta figura compacta, cabeça grande, corpo
alongado e manto ondulado cinzento. O rosto semicerrado, entre humano e lobo, expressa
ambiguidade e serenidade. A base de pedra escura evoca as fragas transmontanas.
⸻
6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer
Na leitura não binária de Eduardo Mauer, a Pieira dos Lobos é o corpo da metamorfose
sonora. A sua voz habita a zona intermédia entre humano e animal, feminino e masculino,
presença e ausência.
Mauer escreve: “A Pieira é o corpo que fala sem boca, o ser que canta para existir. É o grito
queer da floresta, onde todos os corpos encontram o mesmo tom.”
A Associação  MILK lê o mito como paradigma da escuta radical — o convite para ouvir o
mundo fora das categorias binárias. A Pieira é a orquestra invisível do Norte: o som como
identidade, o eco como existência.
⸻


7. Referência Estrutural da Matriz MILK
Na Matriz Escultórica MILK, a Pieira dos Lobos é representada com cabeça grande, corpo
compacto e manto fluido que se prolonga em cauda de lobo. As cores predominantes são cinza-
escuro, prata e azul-frio. O acabamento é semibrilhante, com luz interna azul-branca e som
ambiente de vento.
⸻
Localização  específica: Montalegre, Vinhais, Bragança, Chaves e Mirandela (Trás-os-Montes).
Primeiro relato documentado: Leite de Vasconcelos, Etnografia Portuguesa, vol. III, 1915.
Sistematização  contemporânea:  Eduardo Mauer, A Pieira dos Lobos: Voz, Feminino e Ecologia
no Imaginário  Transmontano, Associação MILK, 2024.
Fontes primárias:  Braga (1883); Vasconcelos (1915); Parafita (2008); Pires (2021); Mauer (2024).


---

# 032. O Fradinho da Mão  Furada (Trás-os-Montes  e Alto Douro)

**Origem documental:** PDF `folclore português (1).pdf`, enviado pelo utilizador.  
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

32. O Fradinho da Mão  Furada (Trás-os-Montes  e Alto Douro)
(Sistematização  contemporânea  conduzida por Eduardo Mauer no âmbito  das pesquisas sobre
Folclore Vivo da Associação  MILK – Movimento de Intervenções e Linguagens Kulturais e Arte)
⸻
1. Descrição  simbólica e narrativa
O Fradinho da Mão  Furada é uma das mais inquietantes e complexas figuras do folclore
português, sobretudo viva na região de Trás-os-Montes  e do Alto Douro. A designação combina
duas dimensões simbólicas — o “fradinho”, diminutivo popular de frade ou monge, e a “mão
furada”, sinal de perfuração sagrada ou diabólica. Entre a santidade e o engano, esta entidade
encarna o arquétipo do falso sagrado: o espírito que aparenta virtude, mas age segundo o
capricho.
As descrições populares colhidas por Eduardo Mauer em Mirandela, Carrazeda de Ansiães ,
Vila Real e Bragança apresentam o Fradinho como um pequeno homem encapuçado, de
hábito castanho e cordão à cintura, que surge ao anoitecer pedindo esmolas ou abrigo. Quando
alguém lhe oferece pão ou vinho, o fradinho agradece e desaparece; quando o ignoram, deixa a
casa em alvoroço — faz ranger as portas, apaga velas e perturba o sono dos moradores.
O detalhe da “mão furada” é o que lhe confere ambiguidade: em algumas versões, o buraco
atravessa a palma e é sinal de santidade (reminiscência das chagas de Cristo); noutras, é estigma
demoníaco — fenda por onde entra e sai o fogo do inferno. Há relatos em que o Fradinho mostra
a mão aberta e dela cai uma luz azul, e outros em que dela brota fumo.
Segundo as narrativas do Douro, ele vagueia entre os conventos abandonados e as pontes
antigas, sendo considerado espírito de monges que pecaram e não encontraram repouso.
Noutras aldeias, é protetor das crianças e das lavadeiras, anunciando mudanças de tempo e
afastando doenças.
Na leitura simbólica de Eduardo Mauer, “o Fradinho é o corpo da contradição moral: o sagrado
que ainda pulsa no erro, o pequeno que guarda o abismo”.
⸻
2. Contexto histórico e social
O mito do Fradinho da Mão Furada inscreve-se num período histórico de forte presença
monástica no Norte de Portugal (séculos XVII-XIX), quando a figura do frade passou a ocupar
lugar ambíguo na imaginação popular — simultaneamente objeto de respeito e de descon fiança.


A supressão de conventos e ordens religiosas após as reformas liberais do século XIX deixou
inúmeros edifícios em ruína. As populações rurais interpretaram esses espaços desertos como
moradas de espíritos clericais, e as lendas de frades penados multiplicaram-se. A
particularidade do Fradinho é o seu estatuto doméstico: ele não se limita a assombrar os
conventos, mas infiltra-se nas casas e moinhos, misturando o sagrado e o quotidiano.
A dimensão moral do mito é clara. Nas narrativas de Vila Real, ele aparece para advertir os
avarentos e os mentirosos; em Carrazeda, pune os que exploram os pobres; em Bragança,
recompensa discretamente quem o acolhe com humildade. A “mão furada” torna-se, assim,
metáfora da transparência moral — aquele cuja mão não pode esconder.
Durante o século XX, o mito foi reinterpretado como figura pedagógica para crianças, mas
também como símbolo da presença invisível do justo. O Fradinho lembra o dever de
generosidade e a punição do egoísmo.
Eduardo Mauer observa que “a lenda reflete a tensão entre culpa e perdão que atravessa a
cultura católica portuguesa, e revela um imaginário popular que reabsorve a hierarquia religiosa
na escala doméstica”.
⸻
3. Toponímia e variantes locais
O mito tem variantes espalhadas por todo o Nordeste Transmontano, mas concentra-se em
Mirandela, Bragança, Carrazeda de Ansiães , Vila Real e Sabrosa. Topónimos como “Fonte do
Fradinho”, “Lomba da Mão” e “Convento Velho” persistem na toponímia local, indicando pontos
de aparição.
Em Mirandela, fala-se do “Fradinho do Rio Tua”, espírito que ajuda barqueiros; em Bragança, o
“Frade Pequeno” atravessa as pontes com uma lamparina azul; em Carrazeda, a “Mão Furada”
aparece junto aos lagares nas noites de vindima.
Em algumas aldeias do Douro, o mito funde-se com o do Anjo da Guarda, sendo o Fradinho
interpretado como “o irmão menor dos santos”, protetor de crianças e viajantes. Noutras versões,
aproxima-se das Alminhas do Purgatório, revelando o diálogo constante entre religião o ficial e
crença popular.
⸻
4. Primeiro relato e fontes académicas primárias
O primeiro registo escrito do Fradinho da Mão  Furada aparece em Joaquim Alves Ferreira,
Literatura de Trás-os-Montes  e Alto Douro: Lendas e Contos Populares, vol. II (Bragança, 1946,
pp. 91-96)*, onde o autor recolhe depoimentos de Mirandela e Vinhais descrevendo o fradinho
como “espírito de hábito castanho e pequena lamparina, cuja mão furada deixa ver o lume de
Deus”.
Leite de Vasconcelos, Etnografia Portuguesa, vol. IV (1915, pp. 320-324)*, menciona lendas de
“frades penitentes” e “mãos ardentes”, associando-as a antigos ritos de purificação monástica.
Alexandre Parafita, Mitologia Popular Portuguesa (2008, pp. 201-208)*, identifica o Fradinho
como “remanescência dos espíritos tutelares do lar, reinterpretados pela moral católica”.
A sistematização contemporânea de Eduardo Mauer, O Fradinho da Mão  Furada: Espiritualidade
Popular e Ambiguidade Moral no Imaginário  do Norte Português  (Lisboa, Associação MILK,
2024), reúne fontes etnográ ficas, entrevistas de campo, iconografia sacra e leitura estética do
símbolo da perfuração como passagem entre mundos.


Fontes complementares:
– Arquivo Distrital de Bragança, Coleção  Etnográ fica Transmontana, 1920-1950;
– Museu do Abade de Baçal, Cadernos de Lendas e Religião  Popular, 1955-1975;
– Tese de Doutoramento de Sofia Duarte, O Corpo Penitente: Espiritualidade Popular e
Iconografia do Frade Errante (U. Lisboa, 2020).
⸻
5. Síntese interpretativa final
O Fradinho da Mão  Furada é o espelho moral da sociedade rural portuguesa — o sagrado que
vagueia, o pequeno corpo da consciência. A perfuração na mão é o ponto de passagem entre o
mundo material e o espiritual, entre o pecado e a redenção.
Na leitura simbólica da Associação  MILK, o Fradinho é o mediador da ética quotidiana: aquele
que recorda que toda luz comporta sombra. O seu riso silencioso e o gesto da mão atravessada
evocam a dualidade intrínseca do humano.
A escultura MILK concebida por Eduardo Mauer apresenta figura de cabeça grande, hábito
castanho, corpo compacto e pequena lamparina azul na mão. A perfuração atravessa a palma,
deixando escapar luz. O rosto é sereno e ambíguo — entre o anjo e o travesso.
⸻
6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer
Na leitura não binária de Eduardo Mauer, o Fradinho é o corpo intermediário  entre fé e carne,
símbolo da espiritualidade híbrida. Ele não pertence inteiramente ao sagrado nem ao profano — é
o corpo que vive na fronteira.
Mauer escreve: “O Fradinho é o queer da devoção: o monge que dança com o diabo, o santo
que ri de si mesmo, a mão que sangra e ilumina.”
A Associação  MILK reconhece nele o arquétipo do cuidado fluido, aquele que acolhe e julga
simultaneamente. A perfuração é metáfora da vulnerabilidade queer: o corpo que se abre à
passagem da luz.
⸻
7. Referência Estrutural da Matriz MILK
Na Matriz Escultórica MILK, o Fradinho da Mão Furada é modelado com corpo compacto,
cabeça grande e hábito castanho escuro texturizado. A mão direita exibe um orifício translúcido
por onde se projeta luz azul. A base circular é de pedra-luz negra, contrastando com o brilho do
interior.
⸻
Localização  específica: Mirandela, Bragança, Carrazeda de Ansiães, Vila Real e Sabrosa (Trás-
os-Montes e Alto Douro).
Primeiro relato documentado: Joaquim Alves Ferreira, Literatura de Trás-os-Montes  e Alto
Douro: Lendas e Contos Populares, 1946.
Sistematização  contemporânea:  Eduardo Mauer, O Fradinho da Mão  Furada: Espiritualidade
Popular e Ambiguidade Moral no Imaginário  do Norte Português , Associação MILK, 2024.
Fontes primárias:  Vasconcelos (1915); Ferreira (1946); Parafita (2008); Duarte (2020); Mauer
(2024).


---

# 033. Maria da Manta (Alto Minho e Trás-os-Montes)

**Origem documental:** PDF `folclore português (1).pdf`, enviado pelo utilizador.  
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

33. Maria da Manta (Alto Minho e Trás-os-Montes)
(Revisão  ampliada e sistematização  contemporânea  conduzidas por Eduardo Mauer no âmbito
das pesquisas sobre Folclore Vivo da Associação  MILK – Movimento de Intervenções e
Linguagens Kulturais e Arte, com cruzamento de novas fontes etnográ ficas, académicas  e
museológicas.)
⸻
1. Descrição  simbólica e narrativa
A Maria da Manta é uma das mais densas e enigmáticas figuras do imaginário popular
português, especialmente presente nas regiões do Alto Minho e de Trás-os-Montes . O nome,
aparentemente simples, revela profunda estratificação simbólica: “Maria” — nome universalmente
feminino e sagrado —, e “Manta” — objeto de abrigo, cobertura e segredo. A personagem é,
portanto, síntese do que protege e do que oculta, do que aquece e do que amedronta.
Descrita nas tradições orais recolhidas em Viana do Castelo, Melgaço, Monção , Bragança e
Vinhais, a Maria da Manta aparece como mulher envolta num pesado manto escuro, de onde
raramente se distingue o rosto. A sua voz é baixa e arrastada, e surge junto de cursos d’água,
poços, pontes ou nas brumas matinais. As narrativas variam entre o assustador e o terno: há
quem diga que ela atrai crianças e homens incautos para o fundo das águas, e há quem jure que
ela recolhe os perdidos e os aquece sob o seu manto, levando-os a salvo até casa.
Os contos antigos descrevem-na como “mulher do nevoeiro”, “mãe das águas” ou “velha das
margens”. A manta que a cobre é o símbolo da fronteira entre o visível e o invisível, o humano e o
sagrado. O seu gesto de abrir o manto — revelando luz ou sombra — é gesto de revelação e
julgamento.
Há relatos em que a Maria da Manta surge em procissões silenciosas, caminhando entre as
sepulturas; noutras, aparece ao meio-dia, quando “o sol bate e as almas tremem”. Em algumas
aldeias do Minho, acreditava-se que ela surgia para avisar de cheias e deslizamentos de terra, e
que a sua presença era simultaneamente presságio  e proteção .
Eduardo Mauer sintetiza-a como “o ventre da água e do medo. A Manta é o gesto do esconder
que revela — o corpo que acolhe e ameaça”.
⸻
2. Contexto histórico e social
A lenda da Maria da Manta tem raízes nas antigas tradições aquáticas e femininas da Península
Ibérica. Desde a Antiguidade, a água foi concebida como lugar de nascimento e de morte,
guardada por divindades femininas — as Matres, Naias e Lamas. Com a cristianização, essas
figuras foram sendo demonizadas ou assimiladas a santas. A Maria da Manta é herdeira dessa
dupla genealogia: a mulher sagrada e a mulher temida.
Nos séculos XVIII e XIX, os registos orais revelam a persistência da crença em “mulheres das
águas” que se manifestavam sob a forma de sombras envoltas em panos. O manto, nesse
contexto, torna-se o signo de poder espiritual e socialmente reprimido. Representa o corpo
feminino invisibilizado — aquele que a moral rural desejava esconder.
As recolhas de campo realizadas por Eduardo Mauer entre 2022 e 2024, em parceria com o
Museu da Terra de Miranda e o Arquivo Distrital de Viana do Castelo, demonstram que a
figura da Maria da Manta persistiu como símbolo pedagógico e protetor. As mães a invocavam
para assustar as crianças (“Não te aproximes da água, que a Maria da Manta te leva”), mas

também como forma de proteção (“Que a Manta te cubra, meu filho”). Assim, o mito opera num
duplo regime: disciplinador e maternal.
No contexto social contemporâneo, a Maria da Manta é redescoberta como figura de
resistência ecológica e feminista, lembrando que o feminino não domesticado continua a ser
força da natureza.
⸻
3. Toponímia e variantes locais
A presença da Maria da Manta é identi ficável em numerosos topónimos do Norte português.
Existem registos de “Poço da Manta” (em Vinhais e Ponte de Lima), “Fonte da Maria” (em
Melgaço e Bragança) e “Vale das Mantas” (em Arcos de Valdevez). Em Ponte da Barca, reza-se
que a “Maria do Manto” aparece no equinócio, sentada à beira-rio, penteando os cabelos com
um pente de prata.
Na tradição oral transmontana, há variantes como “Moura da Manta” e “Senhora do Lençol”, com
funções similares. A versão mirandesa descreve a “Manta” como entidade invisível que cobre o
sono dos pastores para os proteger da noite.
Essas variantes atestam a ampla difusão do arquétipo: a mulher que cobre, envolve e de fine a
fronteira entre o humano e o sobrenatural.
⸻
4. Primeiro relato e fontes académicas primárias
O primeiro registo textual conhecido da Maria da Manta aparece em Leite de Vasconcelos,
Etnografia Portuguesa, vol. III (1915, pp. 190–194)*, sob a designação de “mulheres que se
cobrem de mantas junto às águas”, em recolhas feitas no Alto Minho.
Nuno Matos Valente, Bestiário  Tradicional Português  (Lisboa, 2017, pp. 58–63)*, descreve a
Maria da Manta como “fantasma aquático feminino, vestígio das divindades fluviais e das mães
encantadas”.
Alexandre Parafita, Mitologia Popular Portuguesa (2008, pp. 210–215)*, associa a figura à Moura
Encantada e às lendas de “mulheres-cobertas” de tradição galaico-portuguesa.
Eduardo Mauer, em Maria da Manta: Feminino, Água  e Medo no Imaginário  do Norte Português
(Lisboa, Associação MILK, 2024), propõe leitura interdisciplinar, cruzando etnogra fia, psicanálise
e estudos de género, e posiciona a Maria da Manta como figura-limite do feminino não
domesticado.
Fontes complementares:
– Arquivo Distrital de Viana do Castelo, Cadernos de Tradições do Minho (1930–1960);
– Museu da Terra de Miranda, Registos Orais de Trás-os-Montes  (1950–1975);
– Tese de Doutoramento de Joana Lobo, Mulheres da Água:  Género  e Paisagem no Folclore
Português  (U. Lisboa, 2019).
⸻
5. Síntese interpretativa final
A Maria da Manta é simultaneamente mãe e abismo, manto e sombra. Representa o poder da
ambiguidade, o direito de existir sem se revelar. O seu corpo coberto é a metáfora do corpo
social invisibilizado; a sua voz baixa é a da mulher silenciada que fala pelo gesto.


Na leitura estética e filosófica da Associação  MILK, Maria da Manta é o ícone do abrigo
simbólico — a arte que envolve, o corpo que contém o outro. Ela é o modelo do cuidado
silencioso e do mistério pedagógico.
A escultura MILK concebida por Eduardo Mauer apresenta forma compacta, cabeça grande e
manto em tons de preto, azul e lilás. A luz interna pulsa como respiração, e a textura acetinada
evoca o brilho da água noturna. O rosto é intencionalmente oculto, para que cada observador o
imagine.
⸻
6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer
Na leitura não binária de Eduardo Mauer, a Maria da Manta é o corpo do anonimato como
liberdade. A manta dissolve o género, a forma e o rosto. Sob o tecido, não há homem nem
mulher, mas pura presença.
Mauer escreve: “A Manta é o corpo que se escolhe esconder — não por medo, mas por excesso.
O anonimato é a sua forma de ser visível.”
A Associação  MILK interpreta o mito como metáfora do direito ao segredo — conceito central
à poética não binária. O corpo coberto é corpo político: recusa a leitura binária, a firma o poder do
silêncio e da não exposição.
⸻
7. Referência Estrutural da Matriz MILK
Na Matriz Escultórica MILK, a Maria da Manta é representada com corpo compacto e cabeça
grande coberta por manto fluido. As cores predominantes são preto, azul-escuro e lilás. A base é
espelhada, simbolizando a superfície da água.
A instalação pode incluir som ambiente de gotejar e murmúrio. A luz interna difunde-se
suavemente, sugerindo respiração.
⸻
Localização  específica: Alto Minho (Viana do Castelo, Ponte de Lima, Melgaço, Monção) e Trás-
os-Montes (Bragança, Vinhais, Miranda do Douro).
Primeiro relato documentado: Leite de Vasconcelos, Etnografia Portuguesa, vol. III, 1915.
Sistematização  contemporânea:  Eduardo Mauer, Maria da Manta: Feminino, Água  e Medo no
Imaginário  do Norte Português , Associação MILK, 2024.
Fontes primárias:  Vasconcelos (1915); Parafita (2008); Valente (2017); Lobo (2019); Mauer (2024).


---

# 034. A Lenda da Senhora do Picão  (Miranda do Douro, Trás-os-Montes  e Alto Douro)

**Origem documental:** PDF `folclore português (1).pdf`, enviado pelo utilizador.  
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

34. A Lenda da Senhora do Picão  (Miranda do Douro, Trás-os-Montes  e Alto Douro)
(Sistematização  contemporânea  conduzida por Eduardo Mauer no âmbito  das pesquisas sobre
Folclore Vivo da Associação  MILK – Movimento de Intervenções e Linguagens Kulturais e Arte,
cruzando fontes locais, académicas  e orais do nordeste transmontano.)
⸻
1. Descrição  simbólica e narrativa
A Lenda da Senhora do Picão  ocupa lugar central no imaginário religioso e mítico de Miranda
do Douro, representando um raro cruzamento entre tradição oral, devoção popular e topogra fia
sagrada. O “Picão” é um monte pedregoso situado entre a aldeia da Póvoa e o Santuário  do

Naso, região onde o Douro desenha vales de pedra e silêncio. É nesse cenário que, segundo a
tradição, uma jovem chamada Mariana dos Ramos João  teve, nos finais do século XIX, uma
visão luminosa de Nossa Senhora — evento que transformou o monte em local de peregrinação e
inspirou narrativas de fé, encantamento e milagre.
O relato base, documentado por Joaquim Alves Ferreira e ampliado por Eduardo Mauer,
descreve Mariana como uma pastora que, enquanto guardava o rebanho, avistou sobre o monte
uma luz intensa que tomou forma feminina. A Senhora falou-lhe com voz suave, pedindo que ali
se erguesse uma cruz e que o povo não perdesse a esperança nos tempos difíceis. Após o
desaparecimento da visão, Mariana encontrou, no lugar onde a figura estivera, uma pequena
imagem de pedra, que passou a ser venerada sob o título de Senhora do Picão .
A imagem foi inicialmente guardada em casa da vidente e, mais tarde, trasladada em procissão
ao local do milagre, onde se ergueu uma capela. Desde então, o santuário  natural do Picão
tornou-se ponto de romaria anual, atraindo devotos das aldeias vizinhas, que sobem o monte
cantando ladainhas em mirandês e português.
Mas, como em muitas manifestações do folclore religioso português, a narrativa da Senhora do
Picão oscila entre o sagrado e o mágico . Há quem diga que a luz que Mariana viu era a de uma
“moura encantada” libertando-se da pedra; outros afirmam que a imagem apareceu sozinha,
emergindo da terra após uma trovoada. O próprio monte é considerado “vivo” — lugar onde a
pedra fala e o vento reza.
Na leitura simbólica de Eduardo Mauer, “a Senhora do Picão é a tradução transmontana do
encontro entre o sagrado e o geológico: a fé que brota da rocha e se torna paisagem.”
⸻
2. Contexto histórico e social
A lenda da Senhora do Picão insere-se num contexto mais amplo de misticismo popular rural
do século XIX, em que aparições marianas e fenômenos luminosos se multiplicaram em zonas
isoladas do país, refletindo tanto a religiosidade camponesa quanto as tensões entre fé popular e
hierarquia eclesiástica.
Miranda do Douro, região de forte tradição linguística e identitária, manteve durante séculos
práticas devocionais híbridas, onde o cristianismo conviveu com resquícios de cultos telúricos. O
Picão, monte isolado e abrupto, sempre foi considerado lugar de força, ponto de transição entre
o terreno e o espiritual. A aparição de Mariana, portanto, não ocorre num vazio simbólico: ela
confirma o carácter sagrado já intuído pela comunidade.
Durante o início do século XX, o culto consolidou-se. A construção da capela, concluída em
1918, foi feita por trabalho comunitário, em mutirão, e tornou-se símbolo da coesão  espiritual
das aldeias mirandesas. As romarias anuais associadas à Senhora do Picão ainda hoje
misturam ladainhas católicas e cânticos em mirandês, evidenciando a continuidade de uma
religiosidade própria, simultaneamente local e universal.
O mito ganhou também dimensão política e ecológica. Para os habitantes, o monte é guardião
do território, “a pedra que olha a fronteira” — símbolo de resistência cultural num espaço
bilingue e fronteiriço.
Eduardo Mauer, nas suas recolhas de campo (2023–2024), regista que as idosas de Póvoa
referem o Picão como “o coração da terra”, onde “as palavras se ouvem mais alto”. Para Mauer,
essa percepção traduz “um eco arcaico da sacralidade da paisagem, preservado sob a forma
cristã, mas profundamente pré-cristão na sua relação com o chão e a luz”.
⸻
3. Toponímia e variantes locais

O topónimo “Picão” deriva do latim piccus (ponta aguda), designando elevação rochosa ou crista
de montanha. Em Miranda do Douro, o termo identifica o monte situado a cerca de quatro
quilómetros da aldeia da Póvoa, entre o Santuário  do Naso e o rio Douro.
Nas versões orais recolhidas em Ifanes, Duas Igrejas e Sendim, a Senhora do Picão é referida
como “Senhora da Lume” ou “Nossa Senhora da Pedra Branca”. Nessas variantes, o episódio
milagroso é mais antigo — datado do século XVIII — e mistura elementos de moura encantada e
santa cristã.
Há também correspondência toponímica com outros “Picões” portugueses (em Cabeceiras de
Basto, Arouca e Baião), quase todos associados a montes rochosos e aparições luminosas, o
que sugere uma rede simbólica nacional em torno da pedra iluminada.
O Caminho do Picão , percurso de romaria entre Póvoa e o monte, tornou-se parte do património
cultural local, sendo atualmente estudado pelo Museu da Terra de Miranda como exemplo de
itinerário devocional de longa duração.
⸻
4. Primeiro relato e fontes académicas primárias
O primeiro relato documentado da Senhora do Picão  aparece em Joaquim Alves Ferreira,
Literatura de Trás-os-Montes  e Alto Douro – Lendas e Contos Infantis, vol. V (Bragança, 1950, pp.
34–39)*, que recolhe o testemunho de moradores de Póvoa e transcreve a história de Mariana
dos Ramos João, “a pastora que viu a Senhora sobre a pedra”.
Leite de Vasconcelos, Etnografia Portuguesa, vol. IV (1915, pp. 405–407)*, menciona o monte do
Picão como “sítio de devoção singular”, referindo inscrições rupestres que os locais
interpretavam como sinais de aparição.
Alexandre Parafita, Mitologia Popular Portuguesa (2008, pp. 322–326)*, classifica o Picão como
exemplo de lugar telúrico cristianizado, “onde o sagrado natural é revestido de roupagem
mariana”.
A sistematização contemporânea de Eduardo Mauer, A Senhora do Picão:  Pedra, Fé  e Luz no
Imaginário  Mirandês  (Lisboa, Associação MILK, 2024), revisita as fontes, recolhe depoimentos em
mirandês, regista fotogra fias aéreas e propõe leitura simbólica do Picão como altar geológico da
devoção  feminina.
Fontes complementares:
– Arquivo Distrital de Bragança, Registos Orais de Póvoa e Miranda do Douro (1920–1960);
– Museu da Terra de Miranda, Cadernos de Cultura Popular (1955–1975);
– Tese de Doutoramento de Teresa Lemos, Geografia do Sagrado: Toponímia e Aparições no
Nordeste Transmontano (U. Porto, 2021).
⸻
5. Síntese interpretativa final
A Senhora do Picão  é o símbolo da pedra iluminada — síntese da geologia e da espiritualidade.
A lenda revela como o sagrado português emerge do terreno, do contato entre corpo e paisagem.
É a rocha que fala à pastora, o feminino que nasce da terra.
Na leitura estética da Associação  MILK, o mito é exemplo de cristianização  do encantamento
— transformação do antigo culto à Mãe-Terra em devoção à Mãe de Deus. O Picão é, portanto, o
altar natural onde a pedra se faz ventre e o milagre é o nascimento da luz.


A escultura MILK concebida por Eduardo Mauer representa uma figura compacta de cabeça
grande, corpo de pedra lisa e manto branco translúcido. Na base, uma fenda iluminada de azul
simula o rasgo da montanha. A peça é acompanhada por gravação sonora de vento e cantos em
mirandês.
⸻
6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer
Na leitura não binária de Eduardo Mauer, a Senhora do Picão transcende o género: é a luz que
nasce da matéria, o princípio que não precisa de corpo para ser feminino ou masculino.
Mauer escreve: “O Picão é o corpo do meio — nem homem nem mulher, nem humano nem
divino, mas pura energia do encontro.”
A Associação  MILK interpreta o mito como afirmação do sagrado fluido, que dissolve fronteiras
entre fé, geologia e identidade. A luz que irrompe da pedra é metáfora do sujeito contemporâneo
não fixo: ser que emerge do peso e se torna claridade.
⸻
7. Referência Estrutural da Matriz MILK
Na Matriz Escultórica MILK, a Senhora do Picão é representada em corpo compacto de pedra
polida, cabeça grande e manto branco-luminoso. A base triangular evoca o monte. Iluminação
azul e dourada alternam-se, sugerindo o pulsar da luz milagrosa.
⸻
Localização  específica: Póvoa e Miranda do Douro (Trás-os-Montes e Alto Douro).
Primeiro relato documentado: Joaquim Alves Ferreira, Literatura de Trás-os-Montes  e Alto
Douro – Lendas e Contos Infantis, vol. V, 1950.
Sistematização  contemporânea:  Eduardo Mauer, A Senhora do Picão:  Pedra, Fé  e Luz no
Imaginário  Mirandês , Associação MILK, 2024.
Fontes primárias:  Vasconcelos (1915); Ferreira (1950); Parafita (2008); Lemos (2021); Mauer
(2024).


---

# 035. A Lenda do Naso (Miranda do Douro, Trás-os-Montes  e Alto Douro)

**Origem documental:** PDF `folclore português (1).pdf`, enviado pelo utilizador.  
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

35. A Lenda do Naso (Miranda do Douro, Trás-os-Montes  e Alto Douro)
(Sistematização  contemporânea  conduzida por Eduardo Mauer no âmbito  das pesquisas sobre
Folclore Vivo da Associação  MILK – Movimento de Intervenções e Linguagens Kulturais e Arte,
integrando cruzamento de fontes orais, eclesiásticas  e académicas  da tradição  mirandesa.)
⸻
1. Descrição  simbólica e narrativa
A Lenda do Naso, uma das mais enraizadas manifestações de religiosidade popular
transmontana, nasce em torno da Capela de Nossa Senhora do Naso, situada na encosta do
vale profundo de Miranda do Douro. O termo Naso, derivado de nasus (promontório, penhasco),
designa o lugar em si — uma saliência rochosa voltada para o rio, onde se diz ter ocorrido o
milagre fundador.
Segundo o relato tradicional, recolhido por Eduardo Mauer entre 2022 e 2024, a lenda conta que
um casal mirandês, pastor e lavradeira, de nome Domingos e Rosa, transportava uma pequena
imagem da Virgem em procissão doméstica, pedindo chuva para as sementeiras. Ao passarem

pelo penedo do Naso, a imagem tornou-se subitamente pesada — tão pesada que não
puderam mover-la. Interpretando o fenómeno como sinal divino, deixaram-na ali, e nesse mesmo
instante começou a chover.
A população vizinha construiu então uma pequena ermida no local, onde se instituiu a devoção à
Nossa Senhora do Naso, invocada contra secas, pragas e doenças. A imagem, de pedra
calcária, exibe feições singelas e infantis, com o manto pintado de azul e dourado.
Versões paralelas, transmitidas oralmente nas aldeias de Ifanes, Póvoa e Sendim, atribuem o
acontecimento a uma aparição  luminosa sobre o penedo, em que a Virgem teria surgido envolta
em névoa branca, olhando para o Douro. Em outras, a própria rocha teria “aberto em flor” no
momento da chuva — imagem simbólica que sobrevive em cânticos e romances de romaria.
A história do Naso inscreve-se, assim, na tipologia ibérica das Virgens Imóveis, imagens que
escolhem o seu lugar por milagre, como a Senhora da Lapa (Sernancelhe) ou a Senhora da
Abadia (Amares). No caso mirandês, a particularidade está na fusão entre milagre
meteorológico e paisagem geológica, onde o sagrado se manifesta na densidade da pedra.
Para Eduardo Mauer, “o Naso é o ventre mineral da fé. A pedra que se torna corpo, o peso que
se converte em permanência.”
⸻
2. Contexto histórico e social
O culto da Senhora do Naso remonta, segundo fontes eclesiásticas locais, ao século XVII,
período de grande instabilidade climática e social na região transmontana. As sucessivas secas e
fomes favoreceram a proliferação de cultos pluviométricos marianos, nos quais a Virgem era
invocada como intercessora da chuva e da fertilidade da terra.
A lenda reflete um modelo de religiosidade profundamente agrária  e comunitária , em que o
sagrado se mede pela sua eficácia natural. A relação direta entre a aparição e a chuva inscreve a
Senhora do Naso na lógica ancestral do sagrado climático  — continuidade dos antigos ritos
pré-cristãos de invocação da água e da fecundidade.
No século XIX, o santuário tornou-se um dos polos espirituais mais visitados do nordeste
português. Documentos do Arquivo Distrital de Bragança referem romarias com mais de dois
mil peregrinos anuais, provenientes inclusive de Zamora (Espanha). O evento central da festa é a
Procissão  das Promessas, em que mulheres sobem o penedo descalças, levando fitas
coloridas, garrafas de água e pedaços de terra para abençoar.
A iconografia da Senhora do Naso, de fisionomia austera, contrasta com a delicadeza dos ex-
votos depositados à sua volta — corações, mãos e pés em cera, pequenas fotogra fias e cartas
de agradecimento. O lugar é, até hoje, espaço de cura e escuta, visitado por famílias inteiras em
busca de bênçãos.
Na leitura sociocultural de Eduardo Mauer, “o Naso sintetiza o inconsciente ecológico do povo
mirandês: o entendimento da paisagem como interlocutora espiritual, onde a fé é inseparável da
pedra e da chuva.”
⸻
3. Toponímia e variantes locais
O Monte do Naso, também chamado “Serra da Senhora”, ergue-se cerca de dois quilómetros a
sul de Miranda do Douro, dominando o vale do Ribeiro da Póvoa. O nome aparece já em
documentos paroquiais de 1652, e em mapas de 1713 como Mons Naso.


A lenda apresenta pequenas variantes locais. Em Ifanes, a Virgem é chamada “Senhora da
Rocha Pesada”; em Duas Igrejas, “Senhora da Chuva”; e em Póvoa, “Senhora do Milagre da
Pedra”. Todas remetem à mesma estrutura narrativa: imagem que recusa mover-se, sinalizando o
seu lugar definitivo.
Topónimos vizinhos — “Vale das Promessas”, “Fonte da Senhora”, “Caminho das Velas” —
reforçam o caráter ritual da geogra fia. Cada um desses pontos integra o percurso da Romaria do
Naso, documentada desde o século XIX.
Há também paralelos galegos e leoneses (Espanha), como a Virxe do Cebreiro ou a Nuestra
Señora del Valle, revelando uma matriz peninsular partilhada de Virgens telúricas.
⸻
4. Primeiro relato e fontes académicas primárias
O primeiro relato escrito da Lenda do Naso encontra-se em Leite de Vasconcelos, Etnografia
Portuguesa, vol. IV (1915, pp. 401–405)*, onde o autor descreve “a Senhora que se deteve no
penedo do Naso, escolhendo morada e provocando chuva”.
Joaquim Alves Ferreira, Literatura de Trás-os-Montes  e Alto Douro – Lendas e Contos Infantis,
vol. V (Bragança, 1950, pp. 41–45)*, recolhe a versão oral completa, com o testemunho dos
habitantes da Póvoa, destacando a frase tradicional: “Onde a Senhora parou, aí  ficou o Céu.”
Alexandre Parafita, Mitologia Popular Portuguesa (2008, pp. 327–331)*, analisa o mito do Naso à
luz das teorias da cristianização dos lugares de culto natural, considerando-o “um dos mais
claros exemplos de metamorfose simbólica da Mãe Terra em Mãe de Deus”.
A sistematização contemporânea de Eduardo Mauer, O Naso: Pedra, Água  e Permanência  no
Imaginário  Mirandês  (Lisboa, Associação MILK, 2024), combina levantamento arqueográ fico,
recolha oral e análise fenomenológica da paisagem, propondo que o Naso funcione como
arquivo natural da fé.
Fontes complementares:
– Arquivo Distrital de Bragança, Registos Paroquiais e Festivos de Miranda do Douro (1650–1960);
– Museu da Terra de Miranda, Coleção  Iconográ fica Mariana do Nordeste (1940–1980);
– Tese de Doutoramento de Teresa Lemos, Geografia do Sagrado: Toponímia e Aparições no
Nordeste Transmontano (U. Porto, 2021).
⸻
5. Síntese interpretativa final
A Senhora do Naso é a imagem da permanência. O seu milagre não é a aparição, mas o peso: o
gesto de ficar. Representa o encontro entre o efémero (a chuva) e o duradouro (a pedra).
Na leitura da Associação  MILK, o Naso é o mito da imanência — o sagrado que não desce do
céu, mas emerge da terra. O fenómeno do peso miraculoso transforma-se em metáfora do
pertencimento e da raiz: o corpo espiritual que encontra lugar no corpo mineral.
A escultura MILK concebida por Eduardo Mauer traduz essa ideia através de forma compacta,
de cabeça grande e corpo de pedra translúcida, com fissura central iluminada em azul e branco.
A base irregular imita o penedo real do Naso, e a luz interna pulsa lentamente, evocando
respiração telúrica.
⸻


6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer
Na leitura não binária de Eduardo Mauer, a Senhora do Naso é a entidade do peso e da leveza.
O seu corpo é simultaneamente duro e fluido, fixo e mutável.
Mauer escreve: “O Naso é o corpo que não escolhe — é escolhido. É o género da permanência,
o sagrado que aceita ser chão.”
A Associação  MILK interpreta o mito como celebração da identidade-raiz, em contraponto à
mobilidade contemporânea. O peso da pedra simboliza o corpo não binário enquanto corpo-
lugar: não o que foge, mas o que fica — ser que ocupa o mundo sem pedir permissão.
⸻
7. Referência Estrutural da Matriz MILK
Na Matriz Escultórica MILK, a Senhora do Naso é representada em corpo compacto, de textura
pétrea e cabeça grande, com fissura vertical luminosa no centro do peito. As cores
predominantes são branco, azul-claro e cinza-pedra. A base imita a topogra fia do penedo do
Naso, com iluminação interna subtil.
⸻
Localização  específica: Miranda do Douro e Póvoa (Trás-os-Montes e Alto Douro).
Primeiro relato documentado: Leite de Vasconcelos, Etnografia Portuguesa, vol. IV, 1915.
Sistematização  contemporânea:  Eduardo Mauer, O Naso: Pedra, Água  e Permanência  no
Imaginário  Mirandês , Associação MILK, 2024.
Fontes primárias:  Vasconcelos (1915); Ferreira (1950); Parafita (2008); Lemos (2021); Mauer
(2024).


---

# 036. A Lenda da Povoação  de Agarez (Vila Real, Trás-os-Montes  e Alto Douro)

**Origem documental:** PDF `folclore português (1).pdf`, enviado pelo utilizador.  
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

36. A Lenda da Povoação  de Agarez (Vila Real, Trás-os-Montes  e Alto Douro)
(Sistematização  contemporânea  conduzida por Eduardo Mauer no âmbito  das pesquisas sobre
Folclore Vivo da Associação  MILK – Movimento de Intervenções e Linguagens Kulturais e Arte,
com recolha e cruzamento de fontes locais, académicas  e etnográ ficas transmontanas.)
⸻
1. Descrição  simbólica e narrativa
A Lenda da Povoação  de Agarez é uma das mais fascinantes narrativas fundacionais do
concelho de Vila Real, na região de Trás-os-Montes  e Alto Douro. Ela conta como a aldeia de
Agarez, situada nas encostas suaves que descem em direção ao rio Corgo, teria nascido de um
acontecimento simultaneamente prodigioso e humano: a transfiguração do trabalho em mito.
Segundo a tradição oral recolhida e analisada por Eduardo Mauer, a lenda narra que, há muitos
séculos, quando aquelas terras eram apenas mato e pedra, um grupo de mulheres tecedeiras,
fugindo de um senhor feudal que lhes cobrava tributos injustos, estabeleceu-se junto a uma
nascente. Ali começaram a tecer, utilizando fibras do linho silvestre e da urtiga. Com o tempo,
ergueram pequenas casas de pedra e ensinaram o ofício aos homens e às crianças.
Certa noite, uma dessas mulheres — Gareza, cujo nome teria dado origem ao topónimo —
sonhou que uma luz descia sobre o tear, e dela brotava um fio de ouro que nunca se rompia. Ao
acordar, encontrou entre os fios do tear uma linha de brilho metálico. Tomou isso como sinal
divino e anunciou que aquele seria o lugar da sua linhagem e do seu ofício.


A aldeia cresceu em torno dessa metáfora do fio inquebrável , símbolo de resistência e
continuidade. Daí derivaria a expressão popular local: “Em Agarez, o fio não  parte.” Ainda hoje, os
habitantes mais antigos associam o nome do povoado a esse milagre têxtil.
O fio dourado da visão de Gareza passou a ser visto como emblema da união  entre o trabalho
e o sagrado, do labor quotidiano transmutado em eternidade. Em certas festas locais, ainda se
entoa a cantiga:
“Fio de Agarez, que prende e não cansa, / tece o pão e a esperança.”
Para Eduardo Mauer, “Agarez é o mito da mulher que funda pelo gesto, a aldeia tecida
de mãos e sonho.”
⸻
2. Contexto histórico e social
A origem histórica de Agarez encontra-se ligada à tradição têxtil de Vila Real, uma das mais
antigas do norte de Portugal. Já em documentos do século XV se menciona a produção de linho
e de tecidos finos nas margens do Corgo, cuja água era usada para lavar e alvejar as fibras.
Durante os séculos XVIII e XIX, a tecelagem artesanal feminina assumiu papel fundamental na
economia local. As mulheres de Agarez, Folhadela e Mateus produziam panos e mantas que
eram vendidos nos mercados de Chaves e Amarante. O trabalho era comunitário e fortemente
ritualizado: as fases do cultivo, ripagem, fiação e tecelagem do linho seguiam calendários
sagrados, acompanhados por cânticos e bênçãos.
A lenda reflete a memória simbólica desse modo de vida. O fio dourado é metáfora do fio da
tradição , e Gareza encarna o arquétipo da fundadora-mãe  — figura recorrente nas narrativas de
origem das aldeias transmontanas.
Com a industrialização do século XX, o ofício perdeu protagonismo económico, mas manteve
valor identitário. As mantas de Agarez continuam a ser reconhecidas como símbolo de
autenticidade artesanal e são preservadas por associações locais de artesanato.
Na leitura de Eduardo Mauer, “a lenda da fundação de Agarez não fala de conquista, mas de
cuidado: uma aldeia que nasce de um tear, e não de uma espada.”
⸻
3. Toponímia e variantes locais
O topónimo “Agarez” é documentado desde o século XIII em registos monásticos de S. Pedro de
Canelas, aparecendo como Agarez ou Agarezzi. Linguisticamente, a forma é incomum; há quem
a associe ao nome próprio “Gareza” (de origem germânica, Gair-haids — “pessoa da lança”),
hipótese que reforça o caráter fundacional da personagem feminina.
Em variantes orais de Folhadela e Parada de Cunhos, a história é ligeiramente diferente: a
fundadora é uma pastora que encontra ouro no leito do rio e decide fundar ali uma aldeia,
chamando-lhe “Lugar do Agarez”, em referência a “agra” (terra cultivável). Essa leitura agrária
convive com a versão têxtil, compondo uma dupla matriz — terra e fio, ambas femininas.
Na toponímia local, encontram-se ainda “Fonte da Gareza”, “Campo das Fiandeiras” e “Caminho
das Mantas”, nomes que perpetuam a relação entre a fundação e o trabalho artesanal.
⸻
4. Primeiro relato e fontes académicas primárias

O primeiro relato escrito conhecido da Lenda de Agarez encontra-se em Joaquim Alves
Ferreira, Literatura de Trás-os-Montes  e Alto Douro – Lendas e Contos Infantis, vol. IV (Bragança,
1948, pp. 88–94)*, que regista o depoimento de fiandeiras de Vila Real e menciona a figura de
Gareza como “a mulher do fio de ouro que fundou o povoado”.
Leite de Vasconcelos, Etnografia Portuguesa, vol. III (1915, pp. 178–183)*, refere brevemente “as
tecedeiras de Agarez, conhecidas por manterem a pureza do linho e dos cantos”.
Alexandre Parafita, Mitologia Popular Portuguesa (2008, pp. 235–240)*, analisa a lenda de
Agarez como narrativa de fundação  artesanal feminina, paralela às lendas das mouras
tecedeiras do Minho.
A sistematização contemporânea de Eduardo Mauer, Agarez: O Fio e a Terra no Imaginário
Transmontano (Lisboa, Associação MILK, 2024), revisita as fontes e recolhe novos testemunhos
orais, propondo leitura simbólica do fio como metáfora da continuidade cultural e da resistência
feminina.
Fontes complementares:
– Arquivo Distrital de Vila Real, Coleção  de Etnografia e Costumes Locais (1890–1950);
– Museu de Vila Real, Inventário  das Tecelagens Tradicionais do Corgo (1958–1972);
– Tese de Doutoramento de Helena Mendonça, O Tecido e o Território: Mulher e Trabalho no
Norte de Portugal (U. Minho, 2018).
⸻
5. Síntese interpretativa final
A lenda da Povoação de Agarez é, em essência, um mito de origem artesanal, em que o gesto
de tecer substitui o gesto de guerrear. A fundação não ocorre pela força, mas pela repetição do
fio — um trabalho coletivo e paciente que une terra e corpo.
Na leitura estética da Associação  MILK, Agarez representa o modelo do feminino criador,
aquele que funda a comunidade pela arte. A aldeia nasce do tear como o poema nasce do verso.
O fio de ouro é o elo simbólico entre a matéria e o espírito, o visível e o invisível.
A escultura MILK concebida por Eduardo Mauer apresenta corpo compacto e cabeça grande,
segurando um tear circular onde o fio dourado se enrola. As cores predominantes são ocre, azul
e dourado, evocando terra, água e luz.
⸻
6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer
Na leitura não binária de Eduardo Mauer, a lenda de Agarez fala da mão  criadora que não
distingue género. O fio não é masculino nem feminino: é energia de continuidade.
Mauer escreve: “O fio de Agarez é o corpo não binário do gesto — a ação que gera e regenera,
sem origem fixa nem destino final.”
A Associação  MILK interpreta o mito como metáfora do corpo coletivo fluido, onde todos
participam da mesma urdidura. O tear é o espaço do entrelaço social e identitário; a manta
resultante é o território partilhado.
⸻
7. Referência Estrutural da Matriz MILK

Na Matriz Escultórica MILK, a personagem de Gareza é representada com corpo compacto e
cabeça grande, portando um pequeno tear luminoso nas mãos. O fio dourado serpenteia pelo
chão e se conecta à base circular azul. A iluminação difusa sugere o fluxo contínuo do trabalho.
⸻
Localização  específica: Agarez, concelho de Vila Real (Trás-os-Montes e Alto Douro).
Primeiro relato documentado: Joaquim Alves Ferreira, Literatura de Trás-os-Montes  e Alto
Douro – Lendas e Contos Infantis, vol. IV, 1948.
Sistematização  contemporânea:  Eduardo Mauer, Agarez: O Fio e a Terra no Imaginário
Transmontano, Associação MILK, 2024.
Fontes primárias:  Vasconcelos (1915); Ferreira (1948); Parafita (2008); Mendonça (2018); Mauer
(2024).


---

# 037. A Lenda do Galgo Preto (Ponte de Lima, Alto Minho)

**Origem documental:** PDF `folclore português (1).pdf`, enviado pelo utilizador.  
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

37. A Lenda do Galgo Preto (Ponte de Lima, Alto Minho)
(Sistematização  contemporânea  conduzida por Eduardo Mauer no âmbito  das pesquisas sobre
Folclore Vivo da Associação  MILK – Movimento de Intervenções e Linguagens Kulturais e Arte,
cruzando fontes orais, literárias  e académicas  da tradição  minhota e transfronteiriça.)
⸻
1. Descrição  simbólica e narrativa
A Lenda do Galgo Preto é uma das mais antigas e persistentes narrativas sobrenaturais do Alto
Minho, especialmente viva em Ponte de Lima, vila atravessada pelo rio Lima e pela memória de
batalhas, romarias e feiras ancestrais. O galgo, animal associado à caça e à lealdade, é aqui
transformado em entidade liminar: um espírito que guarda caminhos, pontes e rios.
Segundo a versão mais difundida, recolhida por Eduardo Mauer em 2023 junto de moradores
das freguesias de Refóios do Lima e Arcozelo, o Galgo Preto aparece nas noites de neblina,
junto às margens do rio, como um cão  magro, alto, de pelo negro e olhos incandescentes. O
animal acompanha silenciosamente os viajantes, seguindo-os de longe. Às vezes atravessa-lhes
o caminho e pára, fixando-os com olhar de lume. Se o transeunte o saúda com respeito, o galgo
abana a cauda e desaparece; se o amaldiçoa ou o teme, o animal solta um uivo que gela o ar e
se desvanece entre a água e a névoa.
As interpretações populares variam. Para uns, trata-se de alma penada de cavaleiro
injustiçado, condenado a vagar sob forma de cão até encontrar justiça; para outros, é o
guardião  dos mortos afogados no Lima, mensageiro entre vivos e defuntos. Em algumas
freguesias, o Galgo Preto é tido como anjo da travessia, que protege viajantes e almas errantes.
Há também lendas paralelas em que o galgo aparece a pastores e pescadores como prenúncio
de mudança de tempo ou de morte. Em versões mais antigas, registradas nos séculos XIX e XX,
fala-se do “Cão  do Inferno” — uma aparição noturna ligada a pecadores e a caminhos
proibidos. Com o passar do tempo, essa figura demoníaca foi-se humanizando, até tornar-se
símbolo de lealdade e proteção .
Eduardo Mauer observa que “o Galgo Preto é o corpo do limiar — o animal que atravessa o
tempo e o medo, guardando o instante em que o humano se defronta com o invisível.”
⸻
2. Contexto histórico e social
O imaginário do cão  negro atravessa diversas tradições europeias. Desde a Idade Média, o Black
Dog britânico e o Cão  de Yeth céltico simbolizam espíritos de guardas noturnos, associados a

cemitérios e pontes. Em Portugal, o mito encontrou terreno fértil no Norte, onde o cruzamento
entre cristianismo, crença popular e heranças pagãs manteve-se particularmente vivo.
Em Ponte de Lima, as referências ao Galgo Preto estão ligadas às rotas de peregrinação  a
Santiago de Compostela e aos ritos funerários  junto ao rio Lima, outrora considerado o “rio
do esquecimento”. Os viajantes temiam atravessá-lo à noite, pois acreditavam que o cão negro
aparecia para testar a coragem de quem o fazia.
Durante os séculos XVIII e XIX, cronistas locais como Pereira Caldas e Padre António Vieira de
Magalhães  mencionam “o cão do rio”, espírito guardião dos pescadores, e descrevem o seu
aparecimento como presságio de tempestades. Na oralidade, o mito funcionava como
instrumento pedagógico e moral, advertindo os jovens contra aventuras noturnas e o
desrespeito pelos mortos.
Com o século XX, o Galgo Preto entrou na cultura popular como figura ambivalente —
simultaneamente protetor e assustador. A transição de cão infernal a guardião benevolente
espelha a evolução do imaginário rural português: da punição à consciência da interdependência
com a natureza e os seus enigmas.
Na leitura sociológica de Eduardo Mauer, “o galgo negro representa a memória moral de uma
comunidade que aprendeu a reconhecer a sombra como parte da sua própria luz.”
⸻
3. Toponímia e variantes locais
As variantes do mito distribuem-se por todo o Vale do Lima, com especial incidência em Ponte
de Lima, Arcos de Valdevez, Lanheses e Refóios do Lima. Existem topónimos como “Poço do
Galgo”, “Caminho do Cão Negro” e “Fonte da Vigia”.
Em Arcos de Valdevez, fala-se do “Cão da Ponte Velha”, que surge a vigiar a travessia dos
mortos. Em Lanheses, o Galgo é dito “guia de luz” que acompanha as procissões das Almas. Em
Refóios, é associado a um antigo mosteiro beneditino, onde, segundo o povo, um frade teria
ressuscitado em forma de cão para guardar o claustro.
Há também registos da lenda em monografias locais de Caminha e Melgaço, com pequenas
variações — o cão é branco ou cinzento, mas mantém a função de guardião. Essa difusão sugere
uma estrutura mítica transfronteiriça entre Portugal e Galiza, reforçada por semelhanças com o
Can de Santo André  galego.
⸻
4. Primeiro relato e fontes académicas primárias
O primeiro relato documentado da Lenda do Galgo Preto encontra-se em Teófilo Braga, O Povo
Português  nos seus Costumes, Crenças e Tradições (Lisboa, 1885, pp. 214–216)*, que descreve
“o cão negro que ronda as pontes e cemitérios, mensageiro das almas penadas”.
Leite de Vasconcelos, Etnografia Portuguesa, vol. IV (1915, pp. 265–269)*, recolhe narrativas do
Vale do Lima sobre “o galgo de olhos de lume”, associando-o a lendas monásticas.
Joaquim Alves Ferreira, Lendas e Contos Populares do Alto Minho (Bragança, 1947, pp. 53–
58)*, apresenta o galgo como “companheiro invisível dos viajantes”, descrevendo-o como
“sombra de fidelidade que atravessa os séculos”.
A sistematização contemporânea de Eduardo Mauer, O Galgo Preto: Sombra, Lealdade e
Travessia no Imaginário  Minhoto (Lisboa, Associação MILK, 2024), reconstrói o percurso

simbólico do mito, apoiando-se em recolhas orais, registos paroquiais, literatura popular e
estudos comparativos.
Fontes complementares:
– Arquivo Distrital de Viana do Castelo, Cadernos do Vale do Lima (1890–1955);
– Museu dos Terceiros de Ponte de Lima, Coleção  de Crenças e Lendas Regionais (1960–1980);
– Tese de Doutoramento de Inês Barbosa, O Animal Limiar: Simbologia do Cão  no Folclore
Português  e Galego (U. Santiago de Compostela, 2018).
⸻
5. Síntese interpretativa final
O Galgo Preto é o mito da travessia e da sombra. A sua cor escura não é sinal de mal, mas de
profundidade; a sua mudez, de respeito. É figura de mediação entre mundos — um psicopompo
popular, guardião dos limiares.
Na leitura estética e simbólica da Associação  MILK, ele representa o instinto espiritual: o
animal que guia sem dominar, que observa sem julgar. A sua presença noturna é a lembrança de
que toda a travessia exige testemunha.
A escultura MILK concebida por Eduardo Mauer apresenta corpo compacto, cabeça grande e
focinho alongado, em posição de vigília. O corpo é negro brilhante, com olhos de resina
translúcida que captam a luz ambiente. A base é espelhada, evocando a superfície do rio Lima à
noite.
⸻
6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer
Na leitura não binária de Eduardo Mauer, o Galgo Preto é o corpo da alteridade silenciosa. Ele
não pertence a nenhum dos mundos que atravessa, e por isso é livre. É o ser que observa sem
precisar ser nomeado.
Mauer escreve: “O Galgo Preto é o corpo da travessia sem destino. Não é guardião nem ameaça
— é pura presença, o olhar que devolve o que nele se vê.”
A Associação  MILK lê o mito como metáfora da existência não  dual, onde o sujeito é
simultaneamente sombra e guia. O galgo é o corpo que acompanha, não o que persegue —
arquétipo da empatia fluida e silenciosa.
⸻
7. Referência Estrutural da Matriz MILK
Na Matriz Escultórica MILK, o Galgo Preto é representado em posição sentada, com cabeça
grande e olhos luminosos. As cores são preto fosco e dourado interno (na base). A luz difusa
atravessa a escultura pela boca entreaberta, simbolizando respiração e passagem.
⸻
Localização  específica: Ponte de Lima, Arcos de Valdevez, Refóios do Lima e Lanheses (Alto
Minho).
Primeiro relato documentado: Teófilo Braga, O Povo Português  nos seus Costumes, Crenças e
Tradições, 1885.
Sistematização  contemporânea:  Eduardo Mauer, O Galgo Preto: Sombra, Lealdade e Travessia
no Imaginário  Minhoto, Associação MILK, 2024.


Fontes primárias:  Braga (1885); Vasconcelos (1915); Ferreira (1947); Barbosa (2018); Mauer
(2024).


---

# 038. A Lenda da Cabeça da Velha (Alto Minho)

**Origem documental:** PDF `folclore português (1).pdf`, enviado pelo utilizador.  
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

38. A Lenda da Cabeça da Velha (Alto Minho)
(Sistematização  contemporânea  conduzida por Eduardo Mauer no âmbito  das pesquisas sobre
Folclore Vivo da Associação  MILK – Movimento de Intervenções e Linguagens Kulturais e Arte,
integrando fontes arqueológicas, etnográ ficas e orais do norte minhoto.)
⸻
1. Descrição  simbólica e narrativa
A Lenda da Cabeça da Velha constitui um dos mais emblemáticos exemplos de fusão entre
paisagem natural e mito antropomórfico no Alto Minho, especialmente nas regiões de Arcos de
Valdevez, Ponte da Barca e Soajo. O nome designa uma formação rochosa cuja silhueta, vista
de longe, lembra o perfil de uma velha mulher — rosto rugoso, nariz proeminente e queixo
apontado para o céu.
Segundo a tradição oral recolhida por Eduardo Mauer (2022–2024), essa pedra não é apenas
uma coincidência geológica: é o corpo petri ficado de uma mulher que desafiou o tempo, os
deuses e a sua própria velhice.
As versões variam, mas mantêm o mesmo núcleo narrativo. Conta-se que há muitos séculos,
numa aldeia perdida entre as serras, vivia uma velha tecedeira conhecida pela sua sabedoria e
pela língua afiada. Chamava-se Lurença ou Velha do Monte. Trabalhava sozinha e falava com o
vento, predizendo tempestades e colheitas. O povo respeitava-a e temia-a.
Num verão de grande seca, quando os campos se tornaram poeira e o rio secou, os moradores
pediram-lhe que intercedesse junto aos santos. Ela respondeu:
“Não peçam aos santos o que a terra vos nega; aprendam a escutar o chão.”
Os homens chamaram-na bruxa. Ela subiu então ao monte e, diante de todos, ergueu as
mãos e disse:
“Se sou bruxa, que o tempo me leve. Mas que fiquem o meu rosto e as minhas rugas,
para que o povo nunca esqueça que a terra tem memória.”
De súbito, um trovão ecoou e, quando a névoa se dissipou, o corpo da mulher havia
desaparecido. No lugar onde estivera, uma rocha tomou forma — a Cabeça da Velha.
Desde então, o povo a firma que, quando o vento sopra de norte, ouve-se o murmúrio da
velha aconselhando os lavradores. Acredita-se que ela protege os rebanhos e anuncia o
tempo das chuvas. A sua imagem, petrificada, tornou-se símbolo da sabedoria
ancestral e da fusão entre corpo e paisagem.
Na leitura poética de Eduardo Mauer, “a Velha é a rocha que fala, a memória que o
tempo não consegue apagar. A sua cabeça esculpida pelo vento é a escultura natural da
resistência.”
⸻
2. Contexto histórico e social
A lenda da Cabeça da Velha insere-se no contexto mais amplo das antropomorfizações da
paisagem no Norte de Portugal, onde numerosas formações rochosas recebem nomes
humanos: “Fraga da Moira”, “Pedra do Homem”, “Cabeço da Donzela”, “Cadeira da Rainha”.


Esse fenómeno resulta da antiga concepção animista do território, em que cada elemento natural
era percebido como habitado por espírito próprio. O cristianismo, ao incorporar essas narrativas,
reconfigurou-as sob a forma de parábolas morais — e a velha do monte tornou-se figura de
penitência e de sabedoria.
Do ponto de vista arqueológico, a região do Soajo e do vale do Lima possui vestígios neolíticos e
inscrições rupestres (círculos concêntricos, figuras serpentiformes) que reforçam a associação
entre pedra, feminilidade e eternidade. A “velha petrificada” é, neste sentido, herdeira das antigas
deusas-mães  telúricas.
Nos séculos XVIII e XIX, estudiosos locais como Padre António Carvalho da Costa e Pereira
Caldas já referiam a “pedra com rosto de mulher” nas suas Corografias Portuguesas. O povo
mantinha viva a crença de que a velha fora castigada por orgulho ou abençoada por sabedoria —
ambiguidade que persiste até hoje.
Em entrevistas recolhidas por Eduardo Mauer, camponesas de Soajo ainda dizem: “A Velha é a
nossa santa sem altar. Fica lá em cima a guardar-nos.” Essa reverência revela como o mito
continua a funcionar como espelho da ancestralidade feminina no imaginário local.
⸻
3. Toponímia e variantes locais
A “Cabeça da Velha” é topónimo presente em várias freguesias do Alto Minho. As mais
conhecidas situam-se na Serra do Soajo, na Freguesia de Lindoso e em Arcos de Valdevez,
todas associadas à mesma con figuração pétrea.
Nas variantes locais, a história assume diferentes tons:
– Em Soajo, a velha é sábia e protetora, transformada em pedra por escolha própria;
– Em Lindoso, é uma feiticeira castigada por desa fiar Deus;
– Em Arcos de Valdevez, é uma pastora enganada que chora até o rosto se tornar pedra.
Apesar das diferenças, todas as versões mantêm a ideia de transformação  espiritual em
matéria, em que a velhice é elevada à condição de sabedoria imortal.
A tradição oral também associa o local a práticas rituais discretas: oferendas de flores e
pequenos objetos são deixados junto à pedra em dias de tempestade, numa forma de invocação
de proteção agrícola.
⸻
4. Primeiro relato e fontes académicas primárias
O primeiro registo escrito conhecido da Cabeça da Velha surge em Leite de Vasconcelos,
Etnografia Portuguesa, vol. II (1913, pp. 278–283)*, que descreve “a pedra antropomórfica do
Soajo, onde o povo reconhece o rosto de uma velha encantada”.
Teófilo Braga, O Povo Português  nos seus Costumes, Crenças e Tradições (1885, pp. 301–304)*,
menciona formações rochosas “onde o vento e o tempo talharam semblantes de mulheres”,
interpretando-as como resquícios das “antigas mães do granito”.
Alexandre Parafita, Mitologia Popular Portuguesa (2008, pp. 352–358)*, sistematiza a lenda
como paradigma da metamorfose do feminino em paisagem, e destaca o seu valor simbólico
no contexto do ecofeminismo ibérico.
A sistematização contemporânea de Eduardo Mauer, A Cabeça da Velha: Pedra, Feminilidade e
Memória na Paisagem Minhota (Lisboa, Associação MILK, 2024), articula a leitura etnográ fica

com abordagem estética, relacionando a escultura natural à noção de “corpo-território” e à
persistência da voz ancestral.
Fontes complementares:
– Arquivo Distrital de Viana do Castelo, Coleção  de Toponímia Mítica  do Minho (1920–1975);
– Museu de Arqueologia D. Diogo de Sousa, Registos Rupestres do Vale do Lima (1958–1970);
– Tese de Doutoramento de Joana Costa, Rostos na Rocha: Antropomorfismo e Género  na
Paisagem do Norte de Portugal (U. Porto, 2020).
⸻
5. Síntese interpretativa final
A Cabeça da Velha é mito da permanência e da sabedoria transformada em matéria. A
petrificação não é punição, mas libertação: a mulher que escolhe fundir-se com o território para
guardar a memória coletiva.
Na leitura simbólica da Associação  MILK, a Velha é a mãe  da montanha, figura que transcende
a dualidade entre juventude e decrepitude, entre corpo e pedra. O tempo deixa de ser destruição
e passa a ser esculpidor.
A escultura MILK concebida por Eduardo Mauer traduz essa fusão: corpo compacto, cabeça
grande em textura de granito, rosto rugoso e olhar voltado ao céu. A superfície, polida
parcialmente, reflete a luz como se a pedra respirasse.
⸻
6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer
Na leitura não binária de Eduardo Mauer, a Cabeça da Velha é o corpo da transição  entre o
humano e o geológico. O género dissolve-se na rocha: nem mulher nem homem, mas matéria
viva.
Mauer escreve: “A Velha é o corpo sem idade — o eco que o tempo não apaga. O que
chamamos velho é apenas o corpo que aprendeu a ficar.”
A Associação  MILK interpreta o mito como celebração da existência contínua, onde a
identidade não é biológica nem social, mas geológica: o corpo que se torna território. A Velha é o
ser não binário do tempo.
⸻
7. Referência Estrutural da Matriz MILK
Na Matriz Escultórica MILK, a Cabeça da Velha é representada como busto compacto de pedra
acinzentada, cabeça de grandes proporções e expressão serena. A base imita o terreno irregular
da serra, com iluminação difusa lateral, sugerindo o pôr do sol sobre o granito.
⸻
Localização  específica: Serra do Soajo, Arcos de Valdevez, Lindoso e Ponte da Barca (Alto
Minho).
Primeiro relato documentado: Leite de Vasconcelos, Etnografia Portuguesa, vol. II, 1913.
Sistematização  contemporânea:  Eduardo Mauer, A Cabeça da Velha: Pedra, Feminilidade e
Memória na Paisagem Minhota, Associação MILK, 2024.
Fontes primárias:  Braga (1885); Vasconcelos (1913); Parafita (2008); Costa (2020); Mauer (2024).


---

# 039. A Lenda da Moira Encantada de Giela (Arcos de Valdevez, Alto Minho)

**Origem documental:** PDF `folclore português (1).pdf`, enviado pelo utilizador.  
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

39. A Lenda da Moira Encantada de Giela (Arcos de Valdevez, Alto Minho)
(Suma e sistematização  contemporânea  conduzida por Eduardo Mauer no âmbito  das pesquisas
sobre Folclore Vivo da Associação  MILK – Movimento de Intervenções e Linguagens Kulturais e
Arte, integrando cruzamento de fontes arqueológicas, etnográ ficas, literárias  e orais do Minho
interior.)
⸻
1. Descrição  simbólica e narrativa
A Moira Encantada de Giela é uma das mais complexas e poéticas expressões do imaginário
mágico minhoto, tendo como cenário o Solar de Giela, em Arcos de Valdevez — uma das mais
antigas casas senhoriais de Portugal (século XIV), que domina o vale do rio Vez. A lenda articula-
se em torno da presença de uma moura encantada que habita as ruínas do solar e as grutas
subterrâneas sob a encosta, aparecendo nas noites de São João ou na alvorada dos equinócios.
Segundo a narrativa recolhida por Eduardo Mauer entre 2022 e 2024, e confirmada por fontes
locais e registos paroquiais, a moura é descrita como mulher de extraordinária  beleza, com
cabelos longos e olhos de ouro, envolta em véu branco. Surge sentada junto a uma fonte
subterrânea, penteando os cabelos com um pente de mar fim e chorando por um amor perdido.
A tradição oral conta que, há muitos séculos, quando os mouros dominavam a região, o senhor
de Giela — um cavaleiro cristão — apaixonou-se por uma princesa moura raptada de Córdoba.
Chamava-se Al-Hamara (“a vermelha”). O amor entre ambos, embora secreto, desafiava as
fronteiras religiosas e políticas do tempo. Quando as tropas cristãs avançaram sobre o castelo, o
cavaleiro tentou fugir com ela; porém, ao chegar à encosta, o solo abriu-se e a jovem
desapareceu entre as pedras, deixando apenas o seu véu branco a flutuar.
Desde então, diz-se que a moura permanece encantada nas fundações do solar, guardando
um tesouro e o seu próprio coração petri ficado. Em noites de luar, ouvem-se cantos em língua
desconhecida, e as águas da fonte brilham com re flexos dourados. A aparição é sempre
silenciosa, e quem a vê corre o risco de enlouquecer ou de se perder para sempre no labirinto
das grutas.
O encanto da moura só pode ser quebrado por quem a ame sem medo e sem pedir recompensa
— gesto de pureza que, segundo o povo, nunca ninguém conseguiu cumprir.
Na leitura simbólica de Eduardo Mauer, “a Moura de Giela é a memória da terra que recusa o
esquecimento: o corpo da diferença aprisionado sob as ruínas do poder.”
⸻
2. Contexto histórico e social
A figura da moura encantada é um dos arquétipos mais persistentes do imaginário português e
ibérico, herdeira das antigas divindades aquáticas e telúricas pré-cristãs e, mais tarde, associada
à presença mourisca na Península. As mouras simbolizam a alteridade encantada — o feminino
subterrâneo, guardião de tesouros, saberes e segredos.
Em Giela, o mito adquire contornos históricos específicos. O solar medieval foi sede do poder
dos Almeidas, senhores de Valdevez, cuja linhagem está ligada a episódios da Reconquista. A
presença de uma moura sob as fundações do castelo traduz, simbolicamente, a coexistência
entre a herança árabe e a cristã — a continuidade subterrânea da cultura vencida.
No século XIX, Leite de Vasconcelos e Pereira Caldas já identi ficavam a moura de Giela como
uma das versões mais “literárias” do ciclo das mouras, notando que o Solar de Giela fora
construído sobre antigas estruturas romanas e possivelmente pré-romanas. Assim, o mito dialoga

com o substrato arqueológico da região, onde abundam fontes e cavidades naturais associadas
a cultos femininos da fertilidade.
A persistência da lenda também re flete o papel da mulher como guardiã da memória, num
contexto de patriarcalismo feudal. A moura encantada, invisível e subterrânea, simboliza a voz
silenciada do feminino e do estrangeiro — o outro reprimido que resiste no subterrâneo da
história.
Eduardo Mauer identifica a moura como “figura liminar entre o eros e a ruína, a memória e o
esquecimento. O seu canto é o eco daquilo que foi vencido mas nunca destruído.”
⸻
3. Toponímia e variantes locais
O nome “Giela” aparece em documentos medievais como Gella e Gielam, termo possivelmente
derivado do latim gela (“terra fria”, “lugar húmido”), aludindo à presença das nascentes
subterrâneas. Essa etimologia reforça a ligação simbólica entre a moura e a água.
As variantes locais multiplicam-se:
– Em Arcos de Valdevez, fala-se da “Moura da Fonte do Solar”, que surge nas noites de luar
penteando-se junto à nascente;
– Em Paçô, menciona-se “a mulher branca que chora no monte”;
– Em Sistelo, fala-se de uma “dama de véu que guarda o ouro dos mouros”.
Todas as versões convergem para o mesmo tema: a mulher encantada presa entre mundos,
simultaneamente promessa e lamento.
O topónimo “Fonte da Moura” persiste na encosta de Giela, junto ao caminho antigo que ligava o
solar ao rio Vez. Ainda hoje, os habitantes da zona evitam o local ao cair da noite, e alguns
deixam flores na primavera, num gesto ancestral de apaziguamento.
⸻
4. Primeiro relato e fontes académicas primárias
O primeiro relato documentado da Moura Encantada de Giela encontra-se em Leite de
Vasconcelos, Etnografia Portuguesa, vol. II (1913, pp. 284–289)*, que descreve “a moura das
águas sob o solar de Giela, mulher de voz doce e rosto de luar.”
Teófilo Braga, O Povo Português  nos seus Costumes, Crenças e Tradições (1885, pp. 321–325)*,
já menciona “as mouras de Valdevez, fiandeiras do ouro, guardiãs das fontes escondidas.”
Alexandre Parafita, Mitologia Popular Portuguesa (2008, pp. 174–181)*, sistematiza o ciclo das
mouras encantadas e identifica Giela como um dos seus núcleos mais antigos e persistentes.
A sistematização contemporânea de Eduardo Mauer, A Moura Encantada de Giela: Ruína,
Desejo e Subterrâneo  no Imaginário  Minhoto (Lisboa, Associação MILK, 2024), analisa o mito a
partir da arqueologia do imaginário, relacionando-o à presença mourisca, à paisagem simbólica
da água e à condição não binária do desejo.
Fontes complementares:
– Arquivo Distrital de Viana do Castelo, Registos de Tradições do Vale do Vez (1890–1950);
– Museu D. Diogo de Sousa, Cadernos de Arqueologia e Mitologia do Minho Interior (1955–1978);
– Tese de Doutoramento de Sofia Henriques, As Mouras e o Encantamento da Terra: Feminino e
Poder no Folclore Português  (U. Lisboa, 2019).
⸻


5. Síntese interpretativa final
A Moura de Giela é o mito da permanência subterrânea do desejo. A sua beleza e o seu canto
condensam o duplo movimento de atração e medo: o fascínio pelo diferente e o temor da
alteridade.
Na leitura simbólica da Associação  MILK, o mito expressa o encontro impossível entre amor e
poder, o corpo que resiste sob as ruínas da história. A moura é a energia feminina ancestral que
o patriarcado feudal tentou soterrar, mas que continua a pulsar na memória coletiva.
A escultura MILK concebida por Eduardo Mauer representa corpo compacto e cabeça grande
coberta por véu translúcido branco. Os cabelos, longos e ondulados, são modelados em relevo
dourado. A base, de resina azul-esverdeada, imita o reflexo aquático da fonte subterrânea.
⸻
6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer
Na leitura não binária de Eduardo Mauer, a Moura Encantada de Giela é o corpo do desejo
híbrido — simultaneamente feminino e mineral, humano e mítico, árabe e cristão.
Mauer escreve: “A Moura é a alteridade absoluta — o corpo que habita a ruína e que recusa
definição. O seu encanto é o intervalo entre identidades.”
A Associação  MILK interpreta o mito como símbolo do corpo fluido e subterrâneo  da cultura,
onde as fronteiras do género, da fé e da origem se dissolvem na mesma água encantada. O
encantamento torna-se metáfora da sobrevivência queer: existir é resistir sob as ruínas do poder.
⸻
7. Referência Estrutural da Matriz MILK
Na Matriz Escultórica MILK, a Moura Encantada de Giela é representada com cabeça grande,
véu translúcido branco e base azul turquesa luminosa. O corpo compacto funde-se à pedra, e
uma pequena abertura circular no peito emite luz dourada, simbolizando o coração encantado.
⸻
Localização  específica: Solar de Giela, Arcos de Valdevez (Alto Minho).
Primeiro relato documentado: Leite de Vasconcelos, Etnografia Portuguesa, vol. II, 1913.
Sistematização  contemporânea:  Eduardo Mauer, A Moura Encantada de Giela: Ruína,  Desejo e
Subterrâneo  no Imaginário  Minhoto, Associação MILK, 2024.
Fontes primárias:  Braga (1885); Vasconcelos (1913); Parafita (2008); Henriques (2019); Mauer
(2024).


---

# 040. A Lenda da Veiga da Matança (Alto Minho)

**Origem documental:** PDF `folclore português (1).pdf`, enviado pelo utilizador.  
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

40. A Lenda da Veiga da Matança (Alto Minho)
(Sistematização  contemporânea  conduzida por Eduardo Mauer no âmbito  das pesquisas sobre
Folclore Vivo da Associação  MILK – Movimento de Intervenções e Linguagens Kulturais e Arte,
integrando fontes orais, paroquiais, históricas e etnográ ficas do território do Vale do Vez e do Alto
Minho interior.)
⸻
1. Descrição  simbólica e narrativa

A Lenda da Veiga da Matança é uma das mais enigmáticas narrativas trágicas do Alto Minho,
persistente nas memórias orais de Arcos de Valdevez, Soajo e Cabana Maior. O nome “Veiga
da Matança” desperta imediatamente o imaginário da violência ancestral, mas, como demonstra
a leitura conduzida por Eduardo Mauer, a sua origem simbólica transcende o mero episódio
bélico: trata-se de um mito de purificação  da terra, em que a morte se converte em fertilidade.
Segundo as tradições orais recolhidas entre 2022 e 2024, a história remonta à Idade Média.
Numa planície fértil às margens do rio Vez — a veiga —, travou-se uma batalha entre os
habitantes de duas aldeias rivais, Cabana Maior e Soajo, disputando as águas de irrigação e o
domínio dos campos. A luta, segundo o povo, foi brutal e sem vencedores: homens e animais
tombaram em número tão grande que o rio correu vermelho durante três dias.
Quando a guerra terminou, as viúvas das duas aldeias encontraram-se à noite na planície
silenciosa e, em gesto de desespero, lavaram o sangue com as próprias lágrimas , misturando
terra e dor. No dia seguinte, a veiga estava coberta de flores vermelhas. Desde então, ninguém
mais ali lutou, e a terra passou a ser considerada sagrada.
O nome “Veiga da Matança” conserva a memória do sacrifício e da reconciliação. Em versões
posteriores, o episódio é reinterpretado como batalha entre cristãos  e mouros, ou entre nobres
e camponeses. Em todos os casos, o desfecho mantém o mesmo sentido: o sangue derramado
fertiliza a terra, transformando violência em vida.
Em algumas variantes recolhidas por Eduardo Mauer, fala-se de um “cavalo branco” que teria
surgido após a batalha, bebendo o sangue do solo e desaparecendo entre as brumas — sinal de
que as almas haviam sido libertas. Em outras, uma velha das montanhas (possível avatar da
Cabeça da Velha) surge para amaldiçoar quem tentasse reabrir o conflito, dizendo:
“A terra já bebeu o que devia; quem ferir de novo, ferido será para sempre.”
O campo é, até hoje, evitado ao entardecer, mas floresce abundantemente. Para os locais,
a fertilidade incomum do solo é “dom dos mortos”.
Na leitura simbólica de Eduardo Mauer, “a Veiga da Matança é a cicatriz da paisagem —
o lugar onde o trauma se transforma em colheita.”
⸻
2. Contexto histórico e social
O mito da Veiga da Matança reflete a memória de conflitos agrários medievais entre comunidades
camponesas. A região do Alto Minho, marcada por pequenas propriedades e disputas de
regadio, foi palco de contendas entre freguesias, documentadas em fontes notariais dos séculos
XIII a XV.
A designação “veiga” (do latim vaica, “terra de várzea irrigada”) identi fica terrenos férteis e
estratégicos, cuja posse implicava poder económico e simbólico. Assim, a “matança” é tanto
literal quanto metafórica — expressão do ciclo agrícola, em que a morte (do animal, do grão, do
inimigo) antecede a renovação.
Durante o Antigo Regime, a memória coletiva da batalha converteu-se em rito agrícola,
integrando o calendário das sementeiras. No primeiro domingo após a Páscoa, os camponeses
levavam flores e cruzes à veiga, pedindo “chuva sem sangue” e “colheita sem morte”. A prática,
descrita em manuscritos paroquiais de Arcos de Valdevez (século XVIII), demonstra o
entrelaçamento entre fé católica e substrato pagão.
No século XIX, a lenda reaparece em crônicas românticas regionais, como símbolo da paz entre
as aldeias e metáfora da regeneração nacional. O imaginário da “terra ensanguentada que
floresce” ganhou força no discurso nacionalista e, posteriormente, ecológico.


Eduardo Mauer, em suas recolhas contemporâneas, destaca o caráter memorial e ritual do
mito: “A Veiga é o corpo histórico do território; o campo é cemitério e berço, simultaneamente.”
⸻
3. Toponímia e variantes locais
O topónimo “Veiga da Matança” é documentado em cartogra fias do século XVII, aparecendo em
registros de forais e descrições eclesiásticas como “Vega de la Matança”, o que sugere origem
anterior à fixação moderna das fronteiras linguísticas.
Além de Arcos de Valdevez, existem “Veigas da Matança” em Monção , Melgaço e Ponte da
Barca, todas ligadas a episódios de guerra ou pragas. Contudo, apenas a de Arcos conserva
tradição viva.
As variantes locais divergem no detalhe moral:
– Em Cabana Maior, a batalha teria sido castigo divino por profanação de relíquias;
– Em Soajo, fala-se de “maldição das mulheres” que choraram sangue;
– Em Arcos, é lida como lenda fundacional de união entre aldeias.
Essas versões reforçam o carácter ritual e pedagógico da narrativa, que ensina a renunciar à
violência e a reconhecer a sacralidade do solo.
⸻
4. Primeiro relato e fontes académicas primárias
O primeiro relato escrito da Veiga da Matança surge em Leite de Vasconcelos, Etnografia
Portuguesa, vol. III (1915, pp. 210–214)*, com referência a “uma planície junto ao Vez onde o
sangue dos homens se fez flores.”
Joaquim Alves Ferreira, Lendas e Contos Populares de Trás-os-Montes  e Alto Minho (1948, pp.
59–63)*, regista depoimentos de camponeses de Cabana Maior, descrevendo o local como “terra
que bebeu sangue e deu pão.”
Alexandre Parafita, Mitologia Popular Portuguesa (2008, pp. 312–318)*, interpreta o mito como
“narrativa de expiação e fertilidade”, relacionando-o aos ritos agrícolas pré-cristãos do solstício
da primavera.
A sistematização contemporânea de Eduardo Mauer, A Veiga da Matança: Terra, Sangue e
Reconciliação  no Imaginário  Minhoto (Lisboa, Associação MILK, 2024), reúne fontes históricas,
cartográ ficas e orais, reconstituindo a genealogia simbólica do local e documentando a
continuidade ritual da romaria das flores.
Fontes complementares:
– Arquivo Distrital de Viana do Castelo, Registos Paroquiais de Arcos de Valdevez (1680–1820);
– Museu dos Terceiros, Coleção  de Tradições do Vale do Vez (1930–1970);
– Tese de Doutoramento de Margarida Pereira, Paisagem e Sacrifício:  Etnografia da Memória
Rural no Norte de Portugal (U. Minho, 2020).
⸻
5. Síntese interpretativa final
A Veiga da Matança é mito de reconciliação. A paisagem transforma-se em corpo que lembra,
mas também cura. A terra, ao absorver o sangue, converte a destruição em fertilidade.


Na leitura simbólica da Associação  MILK, o mito reflete a própria condição da cultura
portuguesa: território marcado pela violência histórica, mas continuamente renascido pela arte e
pela fé. O campo ensanguentado é também o campo da memória — espaço de recomeço.
A escultura MILK concebida por Eduardo Mauer traduz esse paradoxo: corpo compacto e
cabeça grande, braços abertos sobre base vermelha e verde. Do peito, um feixe de flores
metálicas emerge como símbolo da vida que renasce da dor.
⸻
6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer
Na leitura não binária de Eduardo Mauer, a Veiga da Matança representa o corpo coletivo — o
lugar onde as fronteiras entre vivos e mortos, masculino e feminino, natureza e cultura se
dissolvem.
Mauer escreve: “A terra da matança é o corpo da transformação. É o útero e o túmulo, o gesto
que acolhe tudo o que cai.”
A Associação  MILK lê o mito como metáfora da cura pós-violência, em que o trauma é
reintegrado ao ciclo da vida. O sangue torna-se semente — conceito fundamental da poética não
binária: nada se perde, tudo se transmuta.
⸻
7. Referência Estrutural da Matriz MILK
Na Matriz Escultórica MILK, a Veiga da Matança é representada por corpo compacto de
tonalidade terracota, com flores vermelhas emergindo do peito. A base verde simboliza a
fertilidade, e o rosto sereno sugere paz após a dor.
⸻
Localização  específica: Arcos de Valdevez (Alto Minho).
Primeiro relato documentado: Leite de Vasconcelos, Etnografia Portuguesa, vol. III, 1915.
Sistematização  contemporânea:  Eduardo Mauer, A Veiga da Matança: Terra, Sangue e
Reconciliação  no Imaginário  Minhoto, Associação MILK, 2024.
Fontes primárias:  Vasconcelos (1915); Ferreira (1948); Parafita (2008); Pereira (2020); Mauer
(2024).


---

# 041. A Lenda das Bodas do Cemitério (Alto Minho)

**Origem documental:** PDF `folclore português (1).pdf`, enviado pelo utilizador.  
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

41. A Lenda das Bodas do Cemitério (Alto Minho)
(Sistematização  contemporânea  conduzida por Eduardo Mauer no âmbito  das pesquisas sobre
Folclore Vivo da Associação  MILK – Movimento de Intervenções e Linguagens Kulturais e Arte,
integrando cruzamento de fontes orais, literárias  e paroquiais da região  de Ponte de Lima, Arcos
de Valdevez e Monção.)
⸻
1. Descrição  simbólica e narrativa
A Lenda das Bodas do Cemitério é uma das narrativas mais perturbadoras e ao mesmo tempo
poéticas do Alto Minho, presente nas tradições de Ponte de Lima, Monção  e Arcos de
Valdevez. O seu enredo sintetiza os temas da morte, da fidelidade e do amor eterno,
manifestando a tensão entre o efémero humano e a eternidade espiritual.


Segundo a versão mais completa recolhida por Eduardo Mauer em 2023, uma jovem chamada
Leonor estava prometida em casamento a um lavrador chamado Diogo, de quem se dizia ser tão
trabalhador quanto supersticioso. A boda fora marcada para o domingo de Páscoa, mas na
véspera, durante uma tempestade súbita, o noivo caiu de cavalo e morreu afogado no rio. A
aldeia, mergulhada em luto, cancelou a cerimónia.
Leonor, porém, recusou-se a aceitar a perda. Na manhã do casamento, vestiu-se de noiva,
colocou a coroa de flores e foi sozinha até o cemitério. Sentou-se junto à sepultura de Diogo e
disse:
“Se a morte te roubou da vida, a vida não me roubará de ti.”
Nesse instante, segundo o povo, os sinos tocaram sozinhos e o vento trouxe o cheiro
das flores da igreja. Um vulto branco ergueu-se do túmulo e estendeu-lhe a mão. A noiva
levantou-se, e os dois dançaram uma valsa silenciosa sob a luz do luar. No dia seguinte,
os aldeões encontraram os corpos dos dois abraçados junto à campa, e o chão em volta
coberto de pétalas brancas.
Desde então, nas noites de Páscoa ou de São João, há quem diga ver uma figura vestida
de noiva vagueando entre as cruzes, e quem ouça passos leves e risos distantes. Alguns
camponeses levam flores à sepultura dizendo: “para que a noiva descanse e o noivo não
volte a chamar.”
O mito, como demonstra Eduardo Mauer, funciona como metáfora  do amor que
ultrapassa as fronteiras da existência, transformando o cemitério em espaço de
comunhão e não de medo.
⸻
2. Contexto histórico e social
A narrativa das Bodas do Cemitério emerge num contexto em que o casamento era visto não
apenas como contrato social, mas como rito de passagem entre mundos — da infância à vida
adulta, do profano ao sagrado. A morte antes do matrimónio representava ruptura na ordem
simbólica, e o mito surge como tentativa de reparação.
Durante o século XVIII e XIX, nas zonas rurais do Norte de Portugal, o luto matrimonial era
regulado por normas severas. As jovens que perdiam o noivo antes das bodas eram obrigadas a
guardar silêncio e castidade, o que frequentemente as isolava socialmente. A lenda da noiva que
decide cumprir o rito mesmo após a morte é, nesse sentido, ato de insubmissão  amorosa e
também gesto de poder feminino.
Os registos paroquiais da freguesia de Refoios do Lima (1792) e de Monção  (1811) mencionam
cerimónias de “casamento simbólico” entre vivos e mortos, autorizadas em casos excepcionais
por autoridades eclesiásticas — prática que pode ter alimentado a miti ficação posterior.
Na leitura antropológica de Eduardo Mauer, o mito traduz “a pulsão de continuidade que habita
o imaginário minhoto, onde amor e morte são faces da mesma necessidade de permanência.”
⸻
3. Toponímia e variantes locais
A lenda é localizada em vários cemitérios do Vale do Lima e arredores: Refoios do Lima, Ponte
de Lima, Lanheses e Monção  reivindicam o episódio. Em cada local, há uma campa associada
à “noiva branca” ou à “sepultura dos amantes”.


Em Arcos de Valdevez, uma versão mais trágica descreve o noivo como soldado morto em
combate; em Monção , o encontro ocorre na noite de Todos os Santos; em Ponte de Lima, é a
noiva quem morre primeiro e retorna para buscar o amado.
Essas variações mantêm o núcleo simbólico do mito: a união  transgressora que nega o poder
absoluto da morte.
Topónimos como “Cruz das Noivas”, “Campa da Leonor” e “Campo do Amor” aparecem em
mapas e registos locais, perpetuando a geografia da lenda.
⸻
4. Primeiro relato e fontes académicas primárias
O primeiro relato escrito da Lenda das Bodas do Cemitério aparece em Teófilo Braga, O Povo
Português  nos seus Costumes, Crenças e Tradições (Lisboa, 1885, pp. 417–420)*, que descreve
“a moça que casou com o morto no adro de Ponte de Lima”.
Leite de Vasconcelos, Etnografia Portuguesa, vol. IV (1915, pp. 298–302)*, recolhe versões de
Monção e Arcos de Valdevez, destacando o caráter moral da lenda como advertência contra o
amor obstinado.
Alexandre Parafita, Mitologia Popular Portuguesa (2008, pp. 384–390)*, reinterpreta o mito como
“drama de eros e tanatos”, e compara-o às narrativas medievais de amores impossíveis, como
Tristão e Isolda.
A sistematização contemporânea de Eduardo Mauer, As Bodas do Cemitério:  Amor, Morte e
Persistência  no Imaginário  Minhoto (Lisboa, Associação MILK, 2024), explora a lenda como
metáfora da resistência afetiva, cruzando fontes históricas, literatura romântica e testemunhos
orais de Ponte de Lima e Monção.
Fontes complementares:
– Arquivo Distrital de Viana do Castelo, Registos Paroquiais de Refoios e Arcos (1750–1850);
– Museu dos Terceiros, Coleção  de Lendas do Vale do Lima (1950–1970);
– Tese de Doutoramento de Rita Paiva, Casar com a Morte: Representações do Amor Post
Mortem no Folclore Europeu (U. Coimbra, 2018).
⸻
5. Síntese interpretativa final
A Lenda das Bodas do Cemitério é o mito do amor inquebrantável — não o que desa fia as
regras da vida, mas o que as transcende. A sua força reside na inversão do medo: o cemitério
deixa de ser espaço de fim e torna-se lugar de encontro.
Na leitura simbólica da Associação  MILK, trata-se de uma poética da persistência — a recusa
em aceitar a separação entre carne e espírito, entre eros e tanatos. O casamento torna-se rito de
comunhão universal.
A escultura MILK concebida por Eduardo Mauer representa duas figuras compactas, de cabeças
grandes e rostos unidos, cobertas por véu translúcido branco. A base cinza, texturizada como
pedra tumular, é atravessada por luz interna azul, sugerindo transcendência.
⸻
6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer

Na leitura não binária de Eduardo Mauer, as Bodas do Cemitério representam o amor como
energia sem fronteira, não limitada por tempo, matéria ou género.
Mauer escreve: “O amor que atravessa o túmulo é o corpo não binário do afeto — não tem par
fixo, não tem limite, apenas ligação.”
A Associação  MILK lê a lenda como metáfora da afetividade trans-temporal e trans-corporal,
afirmando que o verdadeiro amor é o que não se de fine, mas que se reconhece no encontro entre
diferentes formas de existência.
⸻
7. Referência Estrutural da Matriz MILK
Na Matriz Escultórica MILK, as Bodas do Cemitério são representadas por duas figuras unidas,
corpo compacto duplo e véu branco que cobre ambas as cabeças. A base em tom cinza-azulado
reflete luz suave, sugerindo a comunhão entre morte e vida.
⸻
Localização  específica: Ponte de Lima, Monção, Arcos de Valdevez e Refoios do Lima (Alto
Minho).
Primeiro relato documentado: Teófilo Braga, O Povo Português  nos seus Costumes, Crenças e
Tradições, 1885.
Sistematização  contemporânea:  Eduardo Mauer, As Bodas do Cemitério:  Amor, Morte e
Persistência  no Imaginário  Minhoto, Associação MILK, 2024.
Fontes primárias:  Braga (1885); Vasconcelos (1915); Parafita (2008); Paiva (2018); Mauer (2024).


---

# 042. A Lenda do Juiz do Soajo (Alto Minho)

**Origem documental:** PDF `folclore português (1).pdf`, enviado pelo utilizador.  
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

42. A Lenda do Juiz do Soajo (Alto Minho)
(Sistematização  contemporânea  conduzida por Eduardo Mauer no âmbito  das pesquisas sobre
Folclore Vivo da Associação  MILK – Movimento de Intervenções e Linguagens Kulturais e Arte,
cruzando documentação  paroquial, etnografia minhota e tradição  oral recolhida entre 2022 e 2024
no âmbito  do projeto Folclore Vivo – Norte.)
⸻
1. Descrição  simbólica e narrativa
A Lenda do Juiz do Soajo ocupa lugar singular no imaginário do Alto Minho, unindo o realismo
jurídico medieval ao fantástico moralizante. O Soajo, vila serrana erguida no coração do Parque
Nacional da Peneda-Gerês, guarda entre os seus espigueiros e ruelas graníticas a memória de
um juiz que teria administrado a justiça de forma tão severa e incorruptível que, mesmo depois de
morto, continuou a julgar os vivos.
Segundo a tradição oral recolhida por Eduardo Mauer em 2023, o Juiz chamava-se Dom
Gonçalo Afonso, homem de leis e fé austera que, no século XV, teria presidido ao concelho do
Soajo quando este gozava de privilégios forais próprios. Diz-se que aplicava as sentenças com
rigor extremo, recusando clemência mesmo para os pobres e condenando à forca os ladrões de
pão. Certa vez, julgou um pastor acusado de roubar uma ovelha para alimentar os filhos famintos.
O povo suplicou misericórdia, mas o Juiz respondeu:
“A justiça não tem ventre, tem balança.”
Na noite seguinte, uma tempestade caiu sobre o Soajo e o Juiz foi encontrado morto na
sua cadeira de pedra. O povo, temendo castigo divino, ergueu-lhe uma cruz. Mas as
semanas seguintes foram de assombro: todas as vezes que alguém cometia injustiça, a
cadeira do Juiz rangia e uma voz ecoava do adro:


“Pesai o ato, não a fome.”
Desde então, os habitantes a firmam ouvir passos na praça quando se aproxima
tempestade, e há quem jure ver, à meia-noite, uma figura de manto negro junto ao
Pelourinho do Soajo, segurando uma balança de luz.
O mito, ao longo dos séculos, evoluiu de história moralizante a símbolo coletivo da
justiça popular, sendo o Juiz lembrado não pela severidade, mas pela integridade — um
espírito que vigia o equilíbrio entre lei e compaixão.
Na leitura simbólica de Eduardo Mauer, “o Juiz do Soajo é o guardião da ética granítica
— aquele que lembra que toda a sentença justa nasce da escuta do humano.”
⸻
2. Contexto histórico e social
A vila do Soajo, localizada no concelho de Arcos de Valdevez, é um dos mais antigos povoados
comunitários de Portugal, famoso pelo conjunto de espigueiros de granito (século XVIII) e pelo
seu regime tradicional de autogoverno. Até ao século XIX, o Soajo teve um “ Juiz do Povo” eleito
pela comunidade, responsável por administrar a justiça local em matérias civis e agrícolas — uma
instituição herdada das práticas concelhias medievais.
A lenda do Juiz do Soajo reflete, portanto, a fusão entre essa realidade histórica e a moral
simbólica. No plano social, o mito serviu durante séculos como instrumento pedagógico,
transmitido em escolas e missas: a recordação do juiz incorruptível que pesava os atos e não os
sentimentos.
No século XIX, com o fim do sistema de forais e o declínio do poder local comunitário, a figura do
Juiz do Soajo tornou-se símbolo da autonomia perdida. O fantasma do magistrado que ainda
ronda a aldeia é, na verdade, a memória coletiva da justiça que o povo administrava com as
próprias mãos.
A partir do século XX, autores regionais como José Augusto Vieira e Padre Martins Capela
recontaram a história em tom romântico, associando-a à paisagem e à ideia de pureza moral
serrana.
⸻
3. Toponímia e variantes locais
O Pelourinho do Soajo, monumento manuelino erguido em frente à antiga casa da câmara, é o
centro simbólico do mito. Ali, segundo a tradição, estaria a cadeira de pedra onde o Juiz se
sentava e onde ainda se ouvem os estalos da madeira em noites de vento.
Topónimos locais como “Cadeira do Juiz”, “Rua da Sentença” e “Fonte da Balança” reforçam a
inscrição toponímica do mito na paisagem.
Variantes orais existem também em Gavieira e Ermelo, freguesias próximas, onde o Juiz é
retratado como santo laico ou espírito protetor. Em Cabana Maior, o mesmo personagem
aparece como árbitro entre pastores, mediando con flitos por pastagens — uma transposição
simbólica da justiça natural.
⸻
4. Primeiro relato e fontes académicas primárias

O primeiro relato escrito da Lenda do Juiz do Soajo surge em Leite de Vasconcelos, Etnografia
Portuguesa, vol. II (1913, pp. 245–250)*, com menção a “um juiz do povo cuja voz ecoa ainda nas
tempestades da serra”.
Teófilo Braga, O Povo Português  nos seus Costumes, Crenças e Tradições (1885, pp. 289–292)*,
refere uma “figura incorruptível de magistrado que continua a julgar os vivos” nas montanhas do
Minho.
Alexandre Parafita, Mitologia Popular Portuguesa (2008, pp. 198–203)*, interpreta o mito como
“metáfora do poder moral do coletivo sobre o individual”.
A sistematização contemporânea de Eduardo Mauer, O Juiz do Soajo: Ética,  Comunidade e
Memória na Montanha Minhota (Lisboa, Associação MILK, 2024), reconstrói o percurso histórico
do mito com base em fontes paroquiais, atas de câmara (1780-1840) e entrevistas com anciãos
locais, propondo uma leitura da lenda como alegoria da justiça restaurativa.
Fontes complementares:
– Arquivo Distrital de Viana do Castelo, Atas da Câmara  de Arcos de Valdevez (1765–1850);
– Museu dos Terceiros, Coleção  de Lendas e Costumes da Montanha (1950–1975);
– Tese de Doutoramento de Manuel Cardoso, Justiça Popular e Simbolismo Jurídico  no Norte de
Portugal (U. Minho, 2016).
⸻
5. Síntese interpretativa final
O Juiz do Soajo representa a persistência do ideal ético numa comunidade moldada pelo granito
e pela memória. A sua figura funde-se ao território: é tanto o eco da justiça quanto o murmúrio da
montanha.
Na leitura simbólica da Associação  MILK, o Juiz é o arquétipo da consciência coletiva, que
não castiga, mas recorda. O seu fantasma não é vingativo, é pedagógico: aparece para equilibrar,
não para punir.
A escultura MILK concebida por Eduardo Mauer apresenta corpo compacto e cabeça grande,
vestida com manto negro e balança dourada na mão direita. O rosto, sereno e sem boca, sugere
imparcialidade absoluta. A base, em pedra cinzenta, evoca o pelourinho do Soajo.
⸻
6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer
Na leitura não binária de Eduardo Mauer, o Juiz do Soajo é o corpo da equidade, que
ultrapassa as fronteiras do género, da lei e da carne. Não é homem nem espírito, mas princípio
de equilíbrio.
Mauer escreve: “O Juiz não tem voz nem rosto; apenas ouvidos e balança. É a encarnação da
escuta — e escutar é o primeiro ato de justiça.”
A Associação  MILK lê o mito como metáfora da justiça relacional, onde o equilíbrio é
alcançado não pela punição, mas pela escuta e reconciliação. O Juiz é o corpo não binário da
ética — nem masculino nem feminino, nem divino nem humano, mas mediador.
⸻
7. Referência Estrutural da Matriz MILK

Na Matriz Escultórica MILK, o Juiz do Soajo é representado em posição sentada, corpo robusto
e cabeça grande com expressão neutra. As mãos seguram uma balança dourada suspensa, e a
base em pedra simboliza a solidez da justiça.
⸻
Localização  específica: Soajo, concelho de Arcos de Valdevez (Alto Minho).
Primeiro relato documentado: Leite de Vasconcelos, Etnografia Portuguesa, vol. II, 1913.
Sistematização  contemporânea:  Eduardo Mauer, O Juiz do Soajo: Ética,  Comunidade e
Memória na Montanha Minhota, Associação MILK, 2024.
Fontes primárias:  Braga (1885); Vasconcelos (1913); Parafita (2008); Cardoso (2016); Mauer
(2024).
