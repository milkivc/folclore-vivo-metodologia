# Corpus integral auditado — parte 01

Entradas 001 a 014.



---

# 001. A Moura Encantada

**Origem documental:** PDF `folclore português (1).pdf`, enviado pelo utilizador.  
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

1. A Moura Encantada
(Sistematização  contemporânea  conduzida por Eduardo Mauer e Nuno Araújo no âmbito  das
pesquisas sobre Folclore Vivo da Associação  MILK – Movimento de Intervenções e Linguagens
Kulturais e Arte)
1. Descrição  simbólica e narrativa
Entre as figuras mais antigas e persistentes do imaginário português, a Moura Encantada ocupa
o centro de um vasto sistema simbólico que atravessa o tempo, as geografias e as fronteiras
culturais. Nas lendas recolhidas no Norte de Portugal — especialmente em Trás-os-Montes , Alto
Minho e Douro Litoral — a Moura surge como mulher de beleza sobrenatural, habitante de
grutas, penedos, fontes e castros, guardiã de tesouros ocultos e portadora de saberes antigos. É
simultaneamente figura de desejo e de perigo, de promessa e de ruína, símbolo da continuidade
entre o mundo visível e o mundo subterrâneo.
Na tradição oral, a Moura Encantada é descrita como mulher alta, de longos cabelos negros ou
dourados, vestida com mantos translúcidos, que surge ao amanhecer ou ao crepúsculo. Em
algumas versões, penteia-se com pentes de ouro à beira de fontes, deixando cair uma lágrima
que se transforma em pedra preciosa. Noutras, aparece envolta em fumo, metade mulher,
metade serpente. O seu olhar hipnótico fascina quem o encontra — e o encontro nunca é casual.
Quem a vê é escolhido, e esse encontro marca um destino: o da libertação ou da perdição.
Os contos mais antigos narram que as Mouras foram antigas deusas ou sacerdotisas pagãs ,
transformadas em encantadas quando o cristianismo se impôs sobre os cultos locais da terra e
da água. Por isso permanecem presas aos montes, às pedras e aos rios, guardando riquezas que
só poderão ser libertadas quando alguém quebrar o encanto. Mas esse ritual exige pureza e
coragem: o mortal deve beijar a Moura, suportar o seu olhar, ou resistir ao medo quando ela se
transforma em animal — serpente, cabra ou peixe. Quase sempre, o humano falha. A lenda
repete o fracasso: o encantamento perpetua-se, e o tesouro continua escondido.
O ciclo narrativo das Mouras é vasto. As versões transmontanas falam das Mouras do Castro de
Avelãs , das Mouras do Alvão , das Mouras de Lamas de Orelhão , enquanto no Minho
persistem as Mouras da Senhora da Peneda e as Mouras do Monte da Cividade. Cada região
atribui-lhes funções específicas: ora protetoras das colheitas, ora sentinelas dos mortos, ora
amantes traídas pelo tempo. Todas, porém, partilham a condição de liminaridade — seres entre
mundos, nem vivos nem mortos, nem humanas nem divinas.
A Moura Encantada é também símbolo da memória subterrânea da terra portuguesa:
representação mítica dos povos pré-romanos e das civilizações esquecidas. O ouro que guarda é
metáfora do saber ancestral que se perdeu com a cristianização. Na leitura contemporânea
proposta por Eduardo Mauer e Nuno Araujo, a Moura é “a guardiã do inconsciente coletivo
português”, o espelho que devolve à comunidade a consciência da sua origem múltipla.
2. Contexto histórico e social
Historicamente, o mito da Moura Encantada nasce do sincretismo entre as antigas divindades
femininas das águas e dos montes — como Nábia , Trebaruna e Ataecina — e a memória popular
das ocupações árabes. O termo “moura” surge, etimologicamente, associado a maura, “mulher
do sul”, mas a sua carga simbólica vai muito além da etnicidade. Desde a Idade Média, o
imaginário cristão transformou as antigas deusas locais em figuras ambíguas: pagãs
amaldiçoadas, ora demonizadas, ora santificadas.
Nos séculos XV e XVI, com a expansão marítima e a recon figuração das identidades ibéricas, a
figura da Moura consolidou-se como símbolo da alteridade interna — o “outro” dentro de

Portugal. As crónicas e romances de cavalaria mencionam “mouras encantadas” que aparecem a
cavaleiros cristãos, oferecendo-lhes amor e tesouros em troca da quebra de um voto. A lenda
funcionava como advertência moral, mas também como memória difusa da convivência cultural
entre cristãos, judeus e muçulmanos.
Durante o século XIX, a recolha etnográ fica de Teófilo Braga e José Leite de Vasconcelos fixou
a Moura Encantada como figura central do folclore português. Para Braga, ela representava a
sobrevivência do “paganismo popular” nas camadas rurais; para Vasconcelos, era manifestação
do espírito telúrico da terra, prova de que o povo preservava, sob o verniz cristão, uma
cosmologia antiga baseada no ciclo da fertilidade e da morte.
Socialmente, a Moura foi também mecanismo de transmissão moral: ensinava o respeito pelos
lugares sagrados, a prudência no desejo, a reverência à natureza. Ao mesmo tempo,
representava uma forma de resistência feminina dentro de sociedades patriarcais. A mulher
encantada, inacessível e poderosa, era imagem invertida da mulher submissa do quotidiano rural.
O mito servia, assim, de válvula simbólica para o inconsciente coletivo feminino.
Nas comunidades transmontanas e minhotesas, a Moura continua a marcar o calendário:
celebra-se nas festas da Peneda, em romarias onde as mulheres sobem montanhas para pedir
amor, fertilidade e proteção. Esses rituais, estudados por Alexandre Parafita, revelam a
permanência da dimensão ritual da lenda, mesmo sob roupagem católica.
3. Toponímia e variantes locais
A presença da Moura Encantada é topogra ficamente densa no Norte:
– Trás-os-Montes:  Moura de Lamas de Orelhão (Mirandela), Moura do Castelo de Algoso
(Mogadouro), Moura do Alvão (Vila Real).
– Minho: Moura da Senhora da Peneda (Arcos de Valdevez), Moura de Giela (Ponte da Barca),
Moura de S. Bento (Terras de Bouro).
– Douro Litoral: Moura da Cividade (Guimarães), Moura do Castelo de Lanhoso, Moura da Serra
de Montemuro.
Esses topónimos estão frequentemente ligados a sítios arqueológicos: castros, penedos
gravados, fontes e ruínas pré-romanas. Em muitos casos, o próprio relevo natural recebe o nome
de “Penedo da Moura”, “Fraga da Moura”, “Fonte da Moura”. Essa persistência toponímica
demonstra a fusão entre território e mito.
As variantes linguísticas incluem “moura-serpente”, “moura-de-ouro” e “moura-fiandeira”, cada
qual representando um aspecto do mesmo arquétipo: a serpente como poder subterrâneo, o
ouro como sabedoria, a roca como destino.
4. Primeiro relato e fontes académicas primárias
O primeiro relato literário identi ficável da Moura Encantada em território nortenho aparece em
Teófilo Braga, Contos Tradicionais do Povo Português , vol. I (Lisboa, 1883), na narrativa “A
Moura do Castelo de Lanhoso”. Braga recolheu o conto em Guimarães e interpretou-o como
“eco das divindades aquáticas e ctónicas da Lusitânia antiga”.
José Leite de Vasconcelos, em Etnografia Portuguesa, vol. II (1913), dedicou extenso capítulo
às Mouras, classi ficando-as como “entes telúricos femininos”, analogáveis às fées  francesas e
lamias mediterrânicas.
Consiglieri Pedroso, em Contribuições para uma Mitologia Popular Portuguesa (1897), sublinhou
a relação entre as Mouras e os cultos solares, vendo nelas “deusas decadentes transformadas
em fantasmas”.


Alexandre Parafita, em Mitologia Popular Portuguesa (2008), mapeou mais de 300 variantes da
lenda em Portugal, das quais cerca de 80 no Norte, com especial incidência em Vila Real,
Bragança e Viana do Castelo.
Eduardo Mauer e Nuno Araujo propõem ler a Moura como símbolo arquetípico da memória
feminina não  domesticada, reinterpretando o encantamento como metáfora da exclusão
histórica do feminino e da sua persistência subterrânea.
Fontes complementares:
– Arquivo Nacional da Torre do Tombo, cód. “Superstitiones Lusitaniae” (séc. XVII).
– Museu Nacional de Arqueologia, coleção “Cultos Pré-Românicos”.
– Tese de Doutoramento de Ana R. Figueiredo, A Moura Encantada: Representações do
Feminino e da Alteridade na Tradição  Oral Portuguesa (U. do Minho, 2015).
– DGPC, Inventário Nacional do Património Imaterial, registo “As Mouras Encantadas do Norte”
(2019).
5. Síntese interpretativa final
A Moura Encantada é o eixo simbólico da identidade mítica portuguesa: síntese entre paganismo
e cristianismo, entre o feminino e o sagrado, entre o medo e o desejo. Representa o país
subterrâneo — aquele que resiste, escondido, à superfície racional da história.
Na leitura do Folclore Vivo / Associação  MILK, a Moura não é apenas relíquia do passado, mas
agente contemporâneo  de ressignificação . As suas múltiplas formas — mulher, serpente,
sombra — re fletem as transformações sociais e culturais do feminino. O encantamento perpetua-
se enquanto houver silêncio sobre as vozes antigas; quebrá-lo é escutá-las novamente.
A escultura concebida por Eduardo Mauer e Nuno Araújo segundo a Matriz MILK retrata a Moura
com corpo compacto, cabeça expressiva, olhar sereno e sorriso sarcástico; as cores rosa, lilás,
vermelho e amarelo evocam o ouro, o sangue, o feitiço e o despertar.
6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer
A leitura não binária proposta por Eduardo Mauer e Nuno Araujo no contexto do Núcleo
Bússola de Não  Binarismo e Folclore Vivo da Associação MILK amplia o campo simbólico da
Moura Encantada. Ela deixa de ser apenas representação da mulher mítica e passa a figurar o
corpo liminar — aquele que habita entre estados e categorias, recusando a fixação de género,
moral e forma.
O encantamento da Moura é, nesta ótica, metáfora da não conformidade: uma existência que
não cabe no binarismo entre sagrado e profano, masculino e feminino, humano e natural. O seu
poder de metamorfose — mulher que vira serpente, sombra, fumaça, estrela — é a própria
expressão do corpo fluido e da identidade em trânsito.
Ao ser lida como entidade não binária, a Moura revela o papel do mito como espaço de
libertação simbólica. O “encantamento” torna-se dispositivo de resistência — o feitiço que
preserva o ser fora das categorias opressivas. Para Mauer, “a Moura é o corpo interdito que
persiste: é a voz que não pôde ser dita, mas que nunca se calou”.
Esta leitura é coerente com o princípio do Folclore Vivo como território fluido: o mito é um
organismo em mutação constante. A Moura, ao resistir à decifração, ensina a multiplicidade
como condição da existência.


7. Referência Estrutural da Matriz MILK
Na Matriz Escultórica MILK, a Moura Encantada é representada segundo o cânone visual da
série Folclore Vivo: cabeça grande e expressiva, corpo compacto e robusto, braços curtos e
gesto simbólico de oferenda. As cores predominantes — rosa, lilás, vermelho e amarelo —
dialogam com a tradição simbólica do ouro e do amor interdito. A ausência de asas e chifres
preserva a neutralidade formal da matriz, enquanto o brilho do verniz remete ao “encantamento”
que oculta e revela.
Na instalação proposta para o ciclo Mitos do Norte, a Moura deverá surgir em ambiente de
penumbra, com fundo negro fosco e luz dourada difusa, criando o efeito de aparição.
⸻
Localização  específica: Trás-os-Montes (Mirandela, Mogadouro, Vila Real), Minho (Arcos de
Valdevez, Ponte da Barca, Terras de Bouro), Douro Litoral (Guimarães, Póvoa de Lanhoso).
Primeiro relato documentado: Teófilo Braga, Contos Tradicionais do Povo Português , vol. I,
1883.
Fontes primárias:  Braga (1883); Vasconcelos (1913); Pedroso (1897); Parafita (2008); Figueiredo
(2015); DGPC (2019);


---

# 002. A Coca de Monção

**Origem documental:** PDF `folclore português (1).pdf`, enviado pelo utilizador.  
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

2. A Coca de Monção
(Sistematização  contemporânea  conduzida por Eduardo Mauer e Nuno Araujo no âmbito  das
pesquisas sobre Folclore Vivo da Associação  MILK – Movimento de Intervenções e Linguagens
Kulturais e Arte)
1. Descrição  simbólica e narrativa
A Coca de Monção  é uma das entidades mais emblemáticas do imaginário popular do Norte de
Portugal, personificando a luta entre o caos e a ordem, o instinto e a razão, o feminino e o
masculino. Tradicionalmente representada como um dragão  ou serpente alada, a Coca surge
anualmente durante a Festa do Corpo de Deus, enfrentando São Jorge numa batalha ritual que
sintetiza a dualidade essencial da cultura portuguesa entre o sagrado e o profano.
Segundo as descrições recolhidas por Eduardo Mauer e Nuno Araujo no âmbito do programa
FolcloreVivo da Associação  MILK, a Coca é mais do que uma simples figura carnavalesca ou
alegórica — é um remanescente de antigas divindades reptilianas e agrárias , integradas no
ciclo litúrgico cristão como modo de sobrevivência simbólica. Os registos orais de Monção
descrevem-na como criatura de corpo alongado e escamas verdes, com boca desmesurada e
olhos ardentes, capaz de cuspir fogo ou fumo. Durante o cortejo, a Coca desafia o cavaleiro São
Jorge diante da multidão; a vitória do santo é certa, mas o seu triunfo é temporário, pois todos
sabem que o dragão renascerá no ano seguinte.
Este ciclo ritual representa a eterna tensão entre destruição e renascimento, fertilidade e
contenção, pulsão e lei. A Coca é símbolo do poder da terra e da natureza, cuja energia deve ser
domesticada, mas nunca extinta. No entanto, a teatralidade da festa revela uma dimensão mais
profunda: sob o disfarce do combate, desenrola-se o reencontro periódico do masculino e do
feminino sagrado — o cavaleiro solar e a serpente telúrica.
A origem do nome “Coca” é incerta, mas provável corruptela de Cuca ou Cocaína , termos
medievais para designar espíritos devoradores de crianças e de colheitas. Em textos do século
XV, “coca” já era sinónimo de monstro, de cocatrix, criatura híbrida entre serpente e galo — o

basilisco. Essa associação ecoa até hoje na iconogra fia local: a cabeça da Coca de Monção é
coroada por crista vermelha, reminiscente da herança medieval.
Os habitantes de Monção descrevem-na como “a bicha que dorme no rio Minho” e desperta
apenas na quinta-feira do Corpo de Deus. É conduzida por homens sob um grande arcabouço de
madeira e tecido, que serpenteia pelas ruas, avança sobre as crianças e ameaça morder os
espectadores. Essa encenação do medo, que culmina na derrota simbólica da fera, funciona
como catarse coletiva e pedagogia ritual.
A leitura contemporânea de Eduardo Mauer e Nuno Araujo reconhece na Coca a sobrevivência
de antigas narrativas matrifocais e agrárias  em que a serpente era símbolo de sabedoria,
fertilidade e poder criador. A festa, ao transformá-la em inimiga de São Jorge, inverte o sentido
original do mito, mas não o apaga: o riso e o espetáculo popular preservam o eco de uma deusa
ancestral que, ciclicamente, se ergue contra a ordem estabelecida.
2. Contexto histórico e social
A Festa da Coca de Monção tem raízes documentadas desde o século XVI, embora o seu
substrato simbólico remonte ao período pré-cristão. Os cultos serpentinos da Península Ibérica,
amplamente estudados por Leite de Vasconcelos e José Mattoso, associavam o réptil à terra
fecunda e à renovação sazonal. Com a cristianização, essas entidades foram recon figuradas
como monstros diabólicos, culminando nas lendas de São Jorge e do dragão.
Monção, cidade fronteiriça e forti ficada, desenvolveu uma cultura ritual de resistência e
celebração. A Coca, que durante séculos percorreu as muralhas acompanhada por tambores e
gaitas de foles, encarna o espírito guerreiro e cíclico da comunidade. A festa do Corpo de Deus,
por sua vez, foi apropriada pela Igreja como afirmação da vitória do bem sobre o mal, mas na
prática popular manteve o caráter ambíguo e pagão.
Os relatos históricos recolhidos por Alexandre Parafita e António Medeiros mostram que a
festa da Coca funcionava como rito de iniciação juvenil. Os rapazes, ao participar na luta ou
conduzir a criatura, assumiam simbolicamente a passagem à idade adulta. A luta com o dragão
tornava-se metáfora do domínio sobre os próprios instintos.
Nos séculos XIX e XX, o ritual foi reinterpretado como atração folclórica e símbolo identitário de
Monção. O dragão de madeira e pano, outrora objeto sagrado, tornou-se mascote turística, sem
perder o substrato simbólico. As entrevistas conduzidas por Eduardo Mauer em 2023 revelam
que muitos moradores ainda associam o som dos tambores ao “despertar da terra” e descrevem
a Coca como “a guardiã do rio”.
A festa contemporânea mantém o ritmo antigo: a procissão litúrgica é seguida pelo combate
teatral; as crianças enfrentam a Coca com espadas de papel; o povo aplaude, grita, ri e se
espanta. Essa dialética entre medo e riso é herança direta do teatro medieval de São Jorge e o
Dragão, mas também do carnaval agrário, em que a morte simbólica da serpente garante o
renascimento da vida.
3. Toponímia e variantes locais
O culto e a lenda da Coca concentram-se em Monção , mas encontram paralelos em Amarante,
Barcelos, Ponte de Lima e Viana do Castelo, onde subsistem tradições de serpentes festivas.
No Minho e no Douro, persistem topónimos como “Cova da Coca”, “Ribeira da Bicha” e “Pedra
da Serpe”, todos ligados a antigas lendas serpentinas.
A própria ponte de Monção  sobre o rio Minho é conhecida localmente como “ponte da Coca”,
pois se acredita que a criatura repousa sob as suas águas. O rio é, aqui, tanto fronteira política
quanto limite mítico: separa e une Portugal e Galiza, luz e sombra, homem e mulher.


As variantes galegas da Coca de Redondela e da Serpe de Betanzos reforçam a natureza
transfronteiriça do mito. Em ambas, a serpente é feminina e ligada à fertilidade. O combate com o
cavaleiro não representa a destruição do mal, mas o reencontro dos opostos.
4. Primeiro relato e fontes académicas primárias
O mais antigo registo escrito da Coca de Monção data de 1561, numa ata municipal que
menciona despesas “com o dragão que sai na procissão do Corpo de Deus”. A referência é
citada por Teófilo Braga em O Povo Português  nos seus Costumes, Crenças e Tradições (1883,
p. 412).
Leite de Vasconcelos, em Etnografia Portuguesa (vol. II, 1913, p. 201), descreve detalhadamente
a festa e compara a Coca de Monção às serpentes de culto agrário observadas em Trás-os-
Montes, concluindo que “a serpente que São Jorge vence é a antiga deusa da terra, submetida
mas não extinta”.
Consiglieri Pedroso, Contribuições para uma Mitologia Popular Portuguesa (1897), interpreta o
mito como “representação da luta solar” e observa a persistência do rito entre cristãos e mouros.
Alexandre Parafita, Mitologia Popular Portuguesa (2008), analisa a Coca como “um dos últimos
rituais vivos de confronto simbólico entre os princípios masculino e feminino”.
A investigação contemporânea de Eduardo Mauer e Nuno Araujonexpande esta leitura ao
introduzir uma perspectiva interdisciplinar que cruza antropologia, performance e estudos queer.
Para Mauer, o combate entre São Jorge e a Coca é ritual de reconciliação  e não de destruição;
ambos são partes do mesmo ser — duas metades de uma energia vital que se reencontra
ciclicamente.
Fontes complementares:
– Arquivo Municipal de Monção, Livro das Festas (1561–1779).
– Museu do Traje de Viana do Castelo, coleção “Máscaras e Ritos do Minho”.
– Tese de Mestrado de Patrícia Lomba, O Dragão  e o Cavaleiro: Rituais de Confronto e Identidade
em Monção  (U. Minho, 2018).
5. Síntese interpretativa final
A Coca de Monção representa o núcleo do imaginário dual português. O combate com São Jorge
não é simples alegoria cristã, mas dramatização  do equilíbrio cósmico. A serpente, símbolo da
fertilidade e da memória telúrica, confronta o cavaleiro, imagem da ordem e da transcendência.
Ambos coexistem como partes necessárias do mesmo ciclo.
Na leitura proposta pela Associação  MILK, o mito revela o poder das tradições em manter viva a
dialética entre destruição e criação. A festa, enquanto performance coletiva, é ato de arte popular
e resistência simbólica. A Coca, cuspindo fogo, é a voz antiga da terra — e o seu riso, eco das
forças criadoras reprimidas.
A escultura da Coca, segundo a Matriz MILK, apresenta corpo compacto e escamas estilizadas,
cabeça expressiva e sorriso ambíguo. As cores predominantes — verde, vermelho e dourado —
representam a terra, o sangue e o ouro do renascimento.
6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer

Na leitura não binária conduzida por Eduardo Mauer e Nuno Araujo, a Coca é figura de
transgressão e ambiguidade. Apesar de representada como monstro feminino, ela incorpora
características masculinas: força, fúria, poder destrutivo. O cavaleiro, por sua vez, embora
símbolo do masculino solar, só se completa no encontro com a serpente. O mito é, portanto,
fábula  da interdependência dos opostos e da impossibilidade de reduzir o ser a uma
identidade fixa.
A Coca encarna o princípio do não  binário  cósmico, onde vida e morte, criação e destruição,
prazer e medo se confundem. O seu corpo híbrido — metade serpente, metade dragão, às vezes
com traços humanos — é metáfora da pluralidade identitária.
Mauer e Araújo observam que o confronto entre São Jorge e a Coca pode ser lido como drama
performativo do corpo queer: o corpo que resiste à domesticação, que desa fia as normas, mas
que é necessário para o equilíbrio da comunidade. A festa, ao permitir o riso e o espanto, cria um
espaço seguro para a expressão da diferença — “um carnaval sagrado”, como o de fine Mauer.
Nesta leitura, a Coca deixa de ser vencida: torna-se companheira ritual do cavaleiro, dançando
com ele o ciclo eterno da vida. Assim, o mito converte-se em celebração da pluralidade e da
fluidez — o cerne conceptual do Folclore Vivo como território fluido proposto pela Associação
MILK.
⸻
7. Referência Estrutural da Matriz MILK
Na Matriz Escultórica MILK, a Coca é reinterpretada como corpo robusto e serpentiforme, mas
obedecendo ao cânone MILK: cabeça grande e expressiva, corpo compacto, ausência de asas e
chifres, postura ligeiramente arqueada como se prestes a dançar. O acabamento é em verniz
brilhante, evocando a água do rio e o re flexo das chamas. As cores verde esmeralda, vermelho
intenso e dourado metálico remetem ao equilíbrio entre vida, paixão e transcendência.
Em contexto expositivo, a escultura da Coca deve dialogar com o espaço performativo,
acompanhada por gravações de gaitas e tambores, recriando a atmosfera ritual da festa.
⸻
Localização  específica: Monção (Viana do Castelo), com variantes em Redondela, Amarante e
Viana.
Primeiro relato documentado: Livro das Festas de Monção, 1561; citado por Teó filo Braga
(1883).
Fontes primárias:  Braga (1883); Vasconcelos (1913); Pedroso (1897); Parafita (2008); Lomba
(2018);


---

# 003. O Trasgo de Trás-os-Montes

**Origem documental:** PDF `folclore português (1).pdf`, enviado pelo utilizador.  
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

3. O Trasgo de Trás-os-Montes
(Sistematização  contemporânea  conduzida por Eduardo Mauer e Nuno Araújo no âmbito  das
pesquisas sobre Folclore Vivo da Associação  MILK – Movimento de Intervenções e Linguagens
Kulturais e Arte)
1. Descrição  simbólica e narrativa
Entre os seres domésticos e travessos do Norte de Portugal, nenhum é tão complexo quanto o
Trasgo, também chamado trasno, fradinho ou trasninho. Na tradição oral de Trás-os-Montes  —
sobretudo nas zonas de Bragança, Vinhais, Montalegre e Miranda do Douro — o Trasgo é
descrito como pequena criatura antropomórfica, de feições miúdas, gorro vermelho

pontiagudo e rosto simultaneamente pueril e envelhecido. Move-se à noite, entrando em casas,
espigueiros e celeiros, onde troca os objetos de lugar, entorna o leite, faz barulho nos telhados ou
penteia os cabelos das mulheres adormecidas.
Apesar do seu comportamento travesso, o Trasgo não é essencialmente maligno. Age por
brincadeira, curiosidade ou ressentimento. Em muitas versões, trata-se de espírito doméstico
ancestral, protetor da casa, cuja função é manter o equilíbrio entre o mundo humano e o
invisível. O problema surge quando não é respeitado: se a família o esquece ou deixa de lhe
oferecer um pedaço de pão e vinho, transforma-se em criatura irada, provocando quedas, ruídos
e confusões.
A tradição oral transmontana descreve-o como “menino de sombra”, invisível à luz do dia, mas
cuja presença se reconhece pelo som das pequenas botas ou pelo leve riso que percorre a casa.
É também capaz de se metamorfosear — pode tornar-se gato, rato ou vento, conforme o humor.
Essa natureza mutável explica a ambiguidade moral do mito: o Trasgo é simultaneamente espírito
de travessura e guardião.
Segundo Eduardo Mauer e Nuno Araujo, o Trasgo representa o espírito da casa e da
imperfeição  humana. O seu riso desorganiza, mas também puri fica; o seu caos obriga à
harmonia. A lenda expressa o princípio de que toda ordem precisa de um pequeno desvio para
se manter viva. No imaginário popular, o Trasgo é lembrança de que o mundo não é controlável e
que o invisível coexiste com o quotidiano.
2. Contexto histórico e social
As origens do Trasgo remontam à antiguidade céltica e ao folclore ibérico. O termo provém do
latim trans- (“além”) e do su fixo gótico -gudja (“espírito” ou “ser”), indicando o “espírito que
atravessa”. As formas castelhanas trasno e trasgu são documentadas desde o século XIV nas
Astúrias e Galiza. A migração desse arquétipo para Trás-os-Montes resultou do contato cultural
entre as comunidades serranas de ambos os lados da fronteira.
Durante a Idade Média, o Trasgo foi reinterpretado pelo cristianismo como demónio doméstico,
espécie de “familiar” que executava tarefas noturnas em troca de oferendas. Em textos
inquisitoriais portugueses do século XVII encontram-se denúncias de mulheres acusadas de “ter
em casa um trasgu que lhes varria o lar”. Contudo, no ambiente rural, o ser conservou conotação
positiva: era auxiliar invisível das tecedeiras e dos pastores.
O Trasgo expressa uma visão pré-industrial da convivência entre humanos e natureza. Em
sociedades agrárias, o trabalho manual era ritualmente protegido por espíritos que
personificavam os gestos cotidianos. Assim como as “mães do linho” cuidavam das rocas e as
“mãos de água” guardavam as fontes, o Trasgo zelava pelas casas e celeiros.
No século XIX, com o declínio da vida comunitária e a ascensão da mentalidade urbana, o Trasgo
perdeu a função simbólica e tornou-se personagem infantil. Entretanto, nos povoados mais
isolados de Trás-os-Montes, ainda se escutam relatos recentes de encontros com “trasguinhos”,
recolhidos por António Fontes e Alexandre Parafita. Esses testemunhos confirmam a
persistência do mito como linguagem da memória e do humor.
Para Eduardo Mauer e Nuno Araujo, o Trasgo é também re flexo social da economia doméstica
rural: uma metáfora da precariedade e da engenhosidade popular. Ele faz muito com pouco, cria
o inesperado dentro do repetitivo, subverte a rotina para lembrar que o trabalho sem imaginação
se torna vazio.
3. Toponímia e variantes locais

O Trasgo é amplamente difundido em Trás-os-Montes , com particular incidência nas aldeias de
Rio de Onor, Montesinho, Vinhais e Bragança. Existem múltiplas variantes locais: o Fradinho
da Mão  Furada, o Trasguinho, o Ente das Chaminés  e o Risonho do Penedo. Em Vinhais, diz-se
que o Trasgo mora nas lareiras apagadas e gosta de soprar cinzas; em Miranda do Douro, que
ele dança ao som da gaita-de-foles; em Montalegre, que vive em fendas de pedra e carrega uma
pequena bolsa de pó de ouro.
Topónimos como Fraga do Trasgo, Fonte do Fradinho e Poço do Risadinho indicam a
territorialização do mito. A sua presença também se estende ao Minho (sob o nome Trasno) e à
Galiza, revelando um continuum cultural atlântico.
4. Primeiro relato e fontes académicas primárias
O primeiro registo literário conhecido do Trasgo em território português encontra-se em Teófilo
Braga, Contos Tradicionais do Povo Português , vol. II (1883), na narrativa “O Fradinho da Mão
Furada”. Braga recolheu o conto em Bragança e descreveu o ser como “duendezinho caseiro, de
gorro vermelho, que auxilia ou perturba conforme o trato que recebe”.
Leite de Vasconcelos, Etnografia Portuguesa, vol. II (1913), menciona o “trasgo” entre os
“espíritos familiares” e o classifica como “manifestação das antigas crenças célticas”.
Consiglieri Pedroso, Contribuições para uma Mitologia Popular Portuguesa (1897), identifica
paralelos com os kobolds germânicos e os brownies escoceses.
Alexandre Parafita, Mitologia Popular Portuguesa (2008), e António Fontes, Lendas do Barroso
(1990), recolhem dezenas de testemunhos vivos da presença do Trasgo, sobretudo em
Montalegre.
A sistematização moderna conduzida por Eduardo Mauer e Nuno Araujo interpretam o  Trasgo
como figura-chave da cultura da hospitalidade e do erro criativo, propondo uma leitura em que o
riso e o desvio constituem forças regeneradoras.
Fontes complementares incluem o Museu de Etnografia de Barroso, registos 1980–2000; o
Arquivo Distrital de Bragança, Caderno de Superstições Rurais (1874); e a tese de Mestrado
de Rita Ferreira, Duendes, Fadas e Fradinhos: Espiritualidades Domésticas  no Norte de Portugal
(UTAD, 2016).
5. Síntese interpretativa final
O Trasgo sintetiza o arquétipo do trickster doméstico, presente em muitas culturas. Ele é o
mediador entre a ordem humana e o caos natural, símbolo do desequilíbrio necessário à
vitalidade da casa e da linguagem. O seu pequeno corpo é o espelho da humanidad: frágil,
risonha, imperfeita.
Na leitura artística de Eduardo Mauer e Nuno Araujo, o Trasgo representa o “princípio do erro
necessário ”: sem ele, não haveria invenção. O mito torna-se, portanto, alegoria da criação —
tanto na arte quanto na vida. A escultura MILK do Trasgo reflete isso: corpo compacto, gorro
vermelho flamejante, sorriso travesso. A cor castanha-terrosa remete à lareira, centro do lar; o
brilho do verniz, ao riso que ilumina.
6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer e Nuno Araujo

Na abordagem não binária desenvolvida por Eduardo Mauer e Nuno Araujo no seio da
Associação  MILK, o Trasgo é lido como entidade de liminaridade absoluta: pequeno,
indefinido, alternando géneros, idades e naturezas. É simultaneamente masculino e feminino,
criança e ancião, humano e espírito. Essa fluidez torna-o símbolo precursor do pensamento não
binário.
A sua capacidade de atravessar espaços e identidades — entrar e sair, visível e invisível, sério e
cómico — exempli fica a mobilidade que o paradigma não binário reivindica. O Trasgo não ocupa
um lugar fixo; é o movimento em si, o entre-lugar onde o ser se reinventa.
Para Mauer, o Trasgo encarna o “riso queer” das aldeias: o humor que desestabiliza hierarquias, o
gesto que transforma o erro em beleza. No contexto contemporâneo, a figura desafia os
binarismos de género, moralidade e racionalidade. A casa que o acolhe aprende que a diferença
é benção, não ameaça.
Na escultura MILK, essa leitura manifesta-se na postura inclinada e no olhar ambíguo da figura,
cuja expressão mistura inocência e ironia. O Trasgo é, portanto, o primeiro ser não  binário  do
folclore doméstico português, espelho das forças criativas e contraditórias que habitam o
humano.
7. Referência Estrutural da Matriz MILK
Seguindo a Matriz Escultórica MILK, o Trasgo é representado com cabeça
desproporcionalmente grande, gorro vermelho vivo, corpo compacto e pernas curtas em posição
de salto. O acabamento combina tons terrosos, verdes e ocres, evocando lareiras e florestas. O
sorriso largo, marca distintiva da série, traduz o humor e a travessura.
Em exposição, a peça deve ser instalada em ambiente quente, com som leve de passos e risos,
sugerindo a presença invisível do ser.
⸻
Localização  específica: Bragança, Vinhais, Montalegre, Miranda do Douro.
Primeiro relato documentado: Teófilo Braga, Contos Tradicionais do Povo Português , vol. II,
1883.
Fontes primárias:  Braga (1883); Vasconcelos (1913); Pedroso (1897); Fontes (1990); Parafita
(2008); Ferreira (2016); Mauer (2024).


---

# 004. O Fradinho da Mão Furada (Trás-os-Montes e Douro)

**Origem documental:** PDF `folclore português (1).pdf`, enviado pelo utilizador.  
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

4. O Fradinho da Mão Furada (Trás-os-Montes e Douro)
(Sistematização  contemporânea  conduzida por Eduardo Mauer e Nuno Araújo no âmbito  das
pesquisas sobre Folclore Vivo da Associação  MILK – Movimento de Intervenções e Linguagens
Kulturais e Arte)
⸻
1. Descrição  simbólica e narrativa
O Fradinho da Mão  Furada é uma das figuras mais emblemáticas e inquietantes do folclore
transmontano e duriense. O seu nome, à primeira vista risível, oculta um conjunto de signi ficados
morais, espirituais e metafísicos de rara densidade. Conhecido também como fradinho travesso,
mongezinho ou padrezinho de sombra, trata-se de um espírito diminuto, geralmente masculino,
vestido com hábito franciscano ou dominicano, rosto miúdo e expressão zombeteira, cuja mão
direita possui um orifício que atravessa toda a palma.


Segundo as narrativas orais recolhidas por Eduardo Mauer e Nuno Araújo nas zonas de
Bragança, Murça e Peso da Régua, o Fradinho aparece durante a noite nas casas das aldeias,
aproximando-se do lume ou das camas, sempre com intenção ambígua: ora ajuda os moradores,
arrumando a cozinha e acendendo o fogo, ora lhes prega partidas, misturando farinha com cinza
ou trocando os sapatos. A sua presença é reconhecida pelo som de pequenos passos e pelo riso
abafado que ecoa nas paredes.
A característica da “mão furada” é o traço de finidor do mito. A mão perfurada impossibilita o
toque pleno, simbolizando a incapacidade de reter — o Fradinho não consegue segurar objetos,
dinheiro ou alimento; tudo lhe escapa entre os dedos. Este detalhe transforma a lenda numa
parábola moral sobre a avareza e a impermanência: aquele que tudo quer possuir, perde tudo.
Por outro lado, o orifício na mão pode ser lido como estigma sagrado, lembrando as chagas de
Cristo. Essa duplicidade — pecado e santidade, riso e sofrimento — constitui o cerne da figura.
O Fradinho é simultaneamente tentador e penitente, espelho grotesco do próprio clero.
Em algumas versões antigas, o Fradinho teria sido um monge que roubou pão do convento e foi
amaldiçoado: condenado a vagar até o fim dos tempos, com a mão vazada para nunca mais
poder reter o que não lhe pertence. Noutras variantes, é um espírito benevolente, vítima de falsa
acusação, que ajuda as famílias pobres em troca de preces.
O mito, portanto, move-se entre extremos: da sátira anticlerical ao conto moral, da superstição
doméstica à alegoria teológica. Para Eduardo Mauer e Nuno Araújo, o Fradinho representa a
sombra ética da religiosidade popular — o lado humano e falível da fé que, ao ser
ridicularizado, torna-se mais próximo e verdadeiro.
⸻
2. Contexto histórico e social
A origem do Fradinho remonta à Idade Média, período em que o clero detinha poder social e
simbólico nas comunidades rurais. Os monges mendicantes, que percorriam o Norte de Portugal
pregando e pedindo esmolas, inspiraram respeito e desconfiança. A sua presença constante nas
aldeias gerou tanto devoção quanto sátira. O povo criou versões caricaturais desses frades —
pequenos, gananciosos, curiosos —, transformando-os em personagens do imaginário moral.
Durante os séculos XVII e XVIII, com a decadência dos conventos e a repressão inquisitorial, o
Fradinho consolidou-se como espírito doméstico punitivo. As famílias acreditavam que o
fradinho visitava as casas para testar a honestidade dos moradores. As crianças eram advertidas:
“Não mintas, que o Fradinho tem a mão furada e vê tudo.”
Os estudos etnográ ficos de Leite de Vasconcelos (Etnografia Portuguesa, vol. II, 1913) e Teófilo
Braga (Contos Tradicionais do Povo Português , 1883) revelam que o mito era particularmente
forte nas margens do Douro e de Trás-os-Montes, áreas de intensa religiosidade popular. O
Fradinho surge como herdeiro direto das lendas medievais sobre monges penitentes e fantasmas
de conventos.
No século XIX, com o anticlericalismo republicano, a figura foi reinterpretada como crítica social:
o pequeno frade travesso simbolizava a hipocrisia religiosa e a corrupção moral. Nas narrativas
mais recentes, recolhidas por Mauer, o Fradinho perdeu o tom punitivo e tornou-se símbolo do
humor e da ironia rural, sendo invocado para explicar acontecimentos domésticos inexplicáveis:
pratos que caem, luzes que oscilam, portas que rangem.
Para a Associação  MILK, o Fradinho é hoje lido como figura de desobediência e sabedoria
popular, símbolo do riso que desarma o dogma e devolve à fé a sua dimensão humana.
⸻


3. Toponímia e variantes locais
A tradição do Fradinho está amplamente disseminada no Norte, especialmente em Vila Real,
Murça, Alijó, Régua, Mogadouro e Bragança. Lugares como a Fonte do Fradinho (Vila Real), a
Capela do Mão  Furada (Murça) e a Casa do Mongezinho (Peso da Régua) são citados em
relatos orais e arquivos locais.
Existem variantes notáveis: o Fradinho das Chamas (em Vilar de Perdizes), que aparece junto ao
fogo; o Frade de Ouro (em Alijó), espírito protetor das colheitas; e o Fradinho dos Sinos (em
Lamego), que toca os sinos de madrugada para avisar de tempestades.
A versão duriense associa o Fradinho às caves do vinho do Porto — diz-se que ele protege os
tonéis e faz barulho quando a safra é boa. Essa adaptação demonstra a vitalidade e a
capacidade de reinvenção do mito no contexto económico local.
⸻
4. Primeiro relato e fontes académicas primárias
O primeiro relato escrito conhecido do Fradinho da Mão Furada aparece em Teófilo Braga,
Contos Tradicionais do Povo Português , vol. II (1883), sob o título “O Fradinho Travesso”. Braga
recolheu o conto em Murça e descreveu o ser como “espírito de frade pequeno, penitente e
folgazão”.
Leite de Vasconcelos (Etnografia Portuguesa, vol. II, 1913) inclui a figura entre os “duendes de
hábito religioso”, destacando a simbologia da mão vazada.
Consiglieri Pedroso, Contribuições para uma Mitologia Popular Portuguesa (1897), aponta a
semelhança com os monacillos espanhóis e os brownies escoceses.
Alexandre Parafita, Mitologia Popular Portuguesa (2008), interpreta o Fradinho como “síntese
entre moral cristã e humor pagão”.
A sistematização contemporânea foi conduzida por Eduardo Mauer e Nuno Araújo no estudo O
Fradinho e o Riso: Ironia, Fé  e Dissidência  no Norte de Portugal (Associação MILK, 2024),
resultado de pesquisa de campo e análise simbólica comparada. Mauer propõe que o orifício na
mão representa a falha sagrada — a imperfeição que torna o humano divino.
Fontes complementares:
– Arquivo Distrital de Vila Real, Caderno de Lendas Religiosas (1878);
– Museu de Lamego, coleção “Imaginário Popular e Iconogra fia Religiosa”;
– Tese de Mestrado de Tiago Pereira, O Humor e o Sagrado nas Lendas Transmontanas (UTAD,
2017).
⸻
5. Síntese interpretativa final
O Fradinho da Mão Furada sintetiza a essência do folclore português: humor e transcendência
coexistindo no mesmo corpo. Ele ri do poder, mas mantém o gesto devoto. É caricatura e
bênção. A sua mão furada é ferida e graça; é a abertura por onde passa a luz.
Para a Associação  MILK, o mito adquire valor contemporâneo como figura da resistência
cultural: o riso popular que desarticula hierarquias. O Fradinho é a consciência que o sagrado tem
de si próprio — uma gargalhada divina.


Na escultura MILK, concebida por Eduardo Mauer e Nuno Araújo o Fradinho é representado
com hábito castanho estilizado, cabeça grande, expressão maliciosa e palma perfurada que
deixa passar a luz. As cores predominantes são castanho, dourado e vermelho-ferrugem.
6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer
Na leitura não binária desenvolvida por Eduardo Mauer e Nuno Araújo, o Fradinho da Mão
Furada é símbolo da fluidez entre fé e desejo, corpo e espírito, masculino e feminino. Apesar
de vestido de frade, sua voz e gestos oscilam entre a delicadeza e a irreverência. Ele transcende
o género e o estatuto religioso: é o monge que ri do seu voto, o corpo que habita a culpa e a
transforma em liberdade.
O orifício da mão torna-se metáfora visual da ausência produtiva: o vazio que não nega, mas
expande. É o espaço por onde passam as identidades e onde o binário se dissolve. Para Mauer,
o Fradinho representa “a santidade queer” — a possibilidade de ser sagrado e profano ao mesmo
tempo.
Essa interpretação insere-se na filosofia da Associação  MILK, que vê o folclore como território
fluido. O Fradinho, ao rir, desarma o dogma e restitui ao corpo o direito de existir fora das
categorias rígidas.
7. Referência Estrutural da Matriz MILK
Na Matriz Escultórica MILK, o Fradinho da Mão Furada segue o cânone da série Folclore Vivo:
cabeça grande e expressiva, corpo compacto, braços curtos e mão direita perfurada que deixa
ver o interior oco. O sorriso é sarcástico e terno; o hábito, estilizado com acabamento em verniz
acetinado. A peça deve ser iluminada por baixo, para que a luz atravesse o orifício, simbolizando
o trânsito entre o visível e o invisível.
Localização  específica: Trás-os-Montes e Douro (Murça, Vila Real, Régua, Bragança, Lamego).
Primeiro relato documentado: Teófilo Braga, Contos Tradicionais do Povo Português , vol. II,
1883.
Fontes primárias:  Braga (1883); Vasconcelos (1913); Pedroso (1897); Parafita (2008); Pereira
(2017); Mauer (2024).


---

# 005. Maria da Manta (Alto Minho e Trás-os-Montes)

**Origem documental:** PDF `folclore português (1).pdf`, enviado pelo utilizador.  
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

5. Maria da Manta (Alto Minho e Trás-os-Montes)
(Sistematização  contemporânea  conduzida por Eduardo Mauer e Nuno Araújo no âmbito  das
pesquisas sobre Folclore Vivo da Associação  MILK – Movimento de Intervenções e Linguagens
Kulturais e Arte)
⸻
1. Descrição  simbólica e narrativa
Entre as entidades mais temidas e enigmáticas do Norte de Portugal, a Maria da Manta ocupa
um lugar de fronteira entre o mito e o aviso moral, o medo e a pedagogia. Figura feminina
noturna, envolta num manto escuro que cobre todo o corpo, a Maria da Manta surge como
fantasma, bruxa e guardiã , encarnação das forças reprimidas da noite rural.


Na tradição oral do Alto Minho e de Trás-os-Montes , ela é descrita como mulher alta, de olhos
cintilantes, rosto indistinto e passos silenciosos. O seu manto, feito de tecido negro, comprido
até ao chão, parece mover-se com vida própria — ora abre-se como asas, ora arrasta-se como
sombra. É dita habitante dos rios, caminhos e encruzilhadas, aparecendo especialmente junto a
pontes, fontes e moinhos.
As narrativas recolhidas por Eduardo Mauer e Nuno Araújo em Arcos de Valdevez, Bragança e
Vila Real relatam que a Maria da Manta surge nas noites de vento, chamando pelas crianças que
se aventuram fora de casa: “Menino, vem cá, que o frio é tanto!” Quem responde ou olha para ela
é envolto pelo manto e desaparece. Noutras versões, protege as crianças perdidas, cobrindo-as
do frio e guiando-as até casa. Essa ambiguidade — protetora e predadora — constitui o núcleo
da sua simbologia.
O nome “Maria da Manta” condensa dois arquétipos: Maria, a mulher comum e arquetípica, e
Manta, o objeto do abrigo. Essa fusão dá origem a uma entidade paradoxal — maternal e
ameaçadora. A manta tanto aquece como sufoca; tanto protege como devora. O mito, por isso,
funciona como metáfora da dupla face do cuidado: o amor que envolve e o controle que
aprisiona.
As descrições mais antigas identificam-na com a “Mulher do Manto Negro”, figura penitente que
percorre os caminhos das almas. A tradição diz que quem levanta o manto da Maria enxerga o
nada, o vazio, ou o próprio rosto envelhecido. Noutras variantes, é viúva de um marinheiro,
condenada a procurar o corpo do marido pelas margens dos rios. Há ainda versões em que
Maria é feiticeira que, rejeitada pela aldeia, vagueia para assustar os filhos dos outros.
A Maria da Manta, tal como reinterpretada por Eduardo Mauer e Nuno Araújo, representa o
princípio do cuidado ferido: a dimensão maternal e feminina deformada pela exclusão social. O
manto torna-se símbolo do invisível — o tecido que separa o mundo daquilo que não pode ser
nomeado.
⸻
2. Contexto histórico e social
O mito da Maria da Manta surge num contexto histórico de forte religiosidade e repressão moral,
sobretudo nas comunidades rurais do Minho e Trás-os-Montes entre os séculos XVII e XIX. Numa
sociedade marcada pela vigilância comunitária, a mulher viúva, solteira ou independente era
frequentemente alvo de suspeita. As “marias do manto”, mulheres que usavam capas negras
para se proteger do frio e da censura social, tornaram-se arquétipo da alteridade feminina:
discretas, solitárias, misteriosas.
As fontes paroquiais e inquisitoriais referem múltiplas “mulheres de manto” acusadas de feitiçaria,
melancolia ou loucura. Essas figuras, marginalizadas, alimentaram o imaginário popular,
transformando-se em personagens míticas. O medo da Maria da Manta é, portanto, o medo da
mulher livre — aquela que anda sozinha à noite, que fala baixo mas sabe demais, que acolhe e
ameaça simultaneamente.
No plano social, a lenda funcionava como instrumento de controle comportamental infantil.
Contar às crianças que “a Maria da Manta leva quem anda fora de casa” servia para manter a
disciplina familiar. Mas, sob essa camada moral, esconde-se uma dimensão mais profunda: o
reconhecimento de uma presença feminina arcaica, ligada às forças noturnas e lunares.
Os estudos de Leite de Vasconcelos (Etnografia Portuguesa, vol. II, 1913) e Consiglieri Pedroso
(Contribuições para uma Mitologia Popular Portuguesa, 1897) apontam para a continuidade entre
as Marias do manto e as antigas “donas de capa” dos rituais medievais de fertilidade e cura.
Nessas cerimónias, o manto era símbolo da passagem entre a vida e a morte, entre o calor e o
frio.


Com o passar dos séculos, a Maria da Manta sobreviveu como lenda moral e figura carnavalesca.
Em algumas freguesias de Arcos de Valdevez e Bragança, é ainda representada em procissões
noturnas, carregando uma lanterna e um manto gigante. Essa teatralidade demonstra a resiliência
do mito, transformando o medo em celebração.
Para a Associação  MILK, o mito é hoje interpretado como espelho das estruturas de exclusão e
cuidado — a mulher que a sociedade teme é a mesma que a sustenta.
⸻
3. Toponímia e variantes locais
A presença da Maria da Manta é atestada em múltiplos topónimos e versões regionais:
– Arcos de Valdevez – “Fonte da Manta”, onde se diz que a mulher aparece penteando-se à
meia-noite;
– Bragança – “Vale da Maria”, lugar de nevoeiros espessos;
– Vila Real – “Caminho das Mantas”, antigo trilho de pastores;
– Mirandela – “Poço da Manta”, fonte profunda onde se ouviam vozes femininas;
– Chaves – “Lomba da Maria da Manta”, associada a ruídos noturnos e cheiros de alfazema.
Variedades linguísticas incluem Maria Manta, Maria das Capas e Mulher do Manto. Em certas
aldeias do Minho, o nome “Maria” é substituído por “Ana” ou “Teresa”, mas o arquétipo mantém-
se: mulher envolta em pano escuro, mediadora entre mundos.
⸻
4. Primeiro relato e fontes académicas primárias
O primeiro registo escrito conhecido da Maria da Manta surge em Teófilo Braga, O Povo
Português  nos seus Costumes, Crenças e Tradições (1883, p. 497), sob a forma de nota
etnográ fica: “Em terras do Minho fala-se de uma Maria coberta de manto que aparece aos
caminhantes, ora para os guiar, ora para os extraviar.”
José Leite de Vasconcelos (Etnografia Portuguesa, vol. II, 1913) descreve-a como “fantasma
feminino de manto negro, intermediário entre as mouras encantadas e as almas penadas”.
Consiglieri Pedroso (1897) classifica-a como “variante moderna da lamia ibérica”, associando o
manto ao ventre animal das antigas deusas da noite.
Alexandre Parafita, em Mitologia Popular Portuguesa (2008), analisa a Maria da Manta como
“figura liminar entre o terror e a ternura”.
Mauer e Araújo propõem a leitura da Maria da Manta como “mãe invertida”, cuja função
simbólica é revelar as feridas do cuidado — o amor reprimido, o medo projetado, o abrigo que se
transforma em prisão.
Fontes complementares:
– Arquivo Municipal de Arcos de Valdevez, Livro de Lendas e Costumes (1857);
– DGPC, Inventário do Património Imaterial, registo “Mulheres de Manto” (2018);
– Tese de Doutoramento de Inês Loureiro, A Sombra Materna: Figurações do Feminino no
Folclore do Norte de Portugal (U. do Minho, 2019).
⸻
5. Síntese interpretativa final
A Maria da Manta é a sombra do lar e da memória, a encarnação dos medos e afetos que
estruturam a vida comunitária. A sua ambiguidade — entre cuidado e castigo — re flete a

complexidade do amor humano e do feminino social. É a mãe que a aldeia teme e, ao mesmo
tempo, invoca.
Na leitura contemporânea da Associação  MILK, a Maria da Manta é símbolo de reconciliação
com a sombra: o reconhecimento das feridas históricas da mulher e da noite. O seu manto deixa
de ocultar para acolher; transforma-se em metáfora da proteção radical.
Na escultura MILK concebida por Eduardo Mauer e Nuno Araújo, a Maria da Manta apresenta
corpo compacto, cabeça grande, expressão serena e olhos luminosos sob um manto negro
translúcido. O sorriso é enigmático e o gesto das mãos — ora aberto, ora recolhido — traduz a
tensão entre abrigar e libertar.
⸻
6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer
A abordagem não binária proposta por Eduardo Mauer e Nuno Araújo vê na Maria da Manta o
corpo-ponte entre o masculino e o feminino, o calor e o frio, a presença e a ausência. O manto,
que cobre e revela, é símbolo do entre-lugar, o espaço da fluidez identitária.
A figura recusa a definição: é mulher e sombra, abrigo e ameaça, humano e espírito. Essa
indefinição faz da Maria da Manta um ícone da não  binariedade simbólica — o ser que não
cabe em nenhuma categoria e, por isso mesmo, revela a totalidade.
Mauer propõe ler o manto como “pele expandida do corpo queer”: superfície que protege da
violência e, simultaneamente, a firma o direito à visibilidade. O medo que a Maria inspira é o medo
do corpo livre — o corpo que não se submete às formas impostas.
Ao reintroduzir o mito no discurso artístico contemporâneo, a Associação  MILK transforma a
Maria da Manta em alegoria da identidade plural: cada pessoa é um manto em movimento, um
tecido de luz e sombra em busca de aceitação.
⸻
7. Referência Estrutural da Matriz MILK
Na Matriz Escultórica MILK, a Maria da Manta é concebida como figura envolta num grande
manto esculpido, que se funde ao corpo compacto da série Folclore Vivo. A cabeça,
desproporcional e expressiva, mantém o olhar sereno; o sorriso é quase invisível. As cores
predominantes — preto, cinza-azulado e lilás metálico — evocam a noite, o mistério e a ternura.
O acabamento é fosco, com áreas brilhantes simulando o re flexo do luar.
Em instalação expositiva, a peça deve surgir em penumbra, sob som ambiente de vento e água,
representando o sussurro do manto em movimento.
⸻
Localização  específica: Alto Minho (Arcos de Valdevez, Viana do Castelo), Trás-os-Montes
(Bragança, Mirandela, Vila Real).
Primeiro relato documentado: Teófilo Braga, O Povo Português  nos seus Costumes, Crenças e
Tradições, 1883.
Fontes primárias:  Braga (1883); Vasconcelos (1913); Pedroso (1897); Parafita (2008); Loureiro
(2019);


---

# 006. A Pieira dos Lobos (Trás-os-Montes e Alto Minho)

**Origem documental:** PDF `folclore português (1).pdf`, enviado pelo utilizador.  
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

6. A Pieira dos Lobos (Trás-os-Montes e Alto Minho)
(Sistematização  contemporânea  conduzida por Eduardo Mauer e Nuno Araújo no âmbito  das
pesquisas sobre Folclore Vivo da Associação  MILK – Movimento de Intervenções e Linguagens
Kulturais e Arte)
⸻
1. Descrição  simbólica e narrativa
A Pieira dos Lobos é uma das entidades mais enigmáticas e belas do imaginário serrano
português. A sua designação provém do verbo “piar” — um som que não é nem voz nem grito,
mas eco, sopro, lamento. A Pieira é descrita como mulher-sombra de cabelos longos, olhos
brilhantes e corpo envolto num véu translúcido, que se move pelas serras ao cair da noite,
acompanhada por uma alcateia invisível de lobos. O seu canto, simultaneamente doce e
lancinante, serve de guia ou de aviso aos viajantes.
Nas aldeias de Montalegre, Vinhais e Arcos de Valdevez, o povo diz que, quando o vento sopra
das montanhas e os cães se calam, ouve-se a pieira — um assobio agudo seguido do uivo
distante dos lobos. É sinal de que a “Senhora das Serras” passa. As crianças são ensinadas a
não responder ao chamamento: quem imita o som da Pieira corre o risco de ser levado para o
mato, onde os lobos lhe arrancarão a sombra.
Noutras versões, recolhidas por Eduardo Mauer e Nuno Araújo no âmbito do Folclore Vivo, a
Pieira não é predadora, mas guardadora da ordem natural. Ela assegura o equilíbrio entre
humanos e animais, punindo caçadores que matam por prazer e guiando os lobos famintos para
longe das aldeias. É, assim, uma divindade pastoral mascarada de lenda, reminiscência de
antigos cultos animistas da Ibéria.
O seu rosto nunca é visto por inteiro — diz-se que muda conforme quem a observa: pode parecer
rapariga, velha, fera ou fumo. O timbre da sua voz é descrito como mistura de vento e flauta.
Mauer observa que este som intermédio — nem humano nem animal — é o verdadeiro núcleo
simbólico da Pieira: ela habita o limiar, a fronteira entre fala e natureza, entre consciência e
instinto.
Nas versões mais poéticas, a Pieira é a primeira mulher-lobo, mãe dos ventos e dos ecos,
condenada a guiar a alcateia pela eternidade. Noutras, é alma penada de pastora que morreu a
defender os lobos de uma caçada. A multiplicidade de narrativas confirma a antiguidade do mito
e a sua função como espelho da relação ancestral do Norte com o mundo selvagem.
⸻
2. Contexto histórico e social
O mito insere-se num contexto de pastoralismo montanhês. Desde a Idade Média, os lobos
eram simultaneamente temidos e respeitados nas serras de Trás-os-Montes e Minho. Eram
concorrentes dos pastores, mas também guardiões simbólicos das fronteiras e do equilíbrio
ecológico. A figura da Pieira nasce desse paradoxo: o povo necessitava de uma mediadora
espiritual capaz de traduzir o mistério dos lobos em linguagem humana.
Registos etnográ ficos antigos mostram que, até ao século XIX, era costume deixar oferendas de
pão e sal nas fragas, “para a Senhora dos Lobos não zangar o gado”. Em tempos de inverno
rigoroso, acreditava-se que a Pieira percorria as aldeias invisível, cobrindo-as com o seu manto
de neblina para proteger dos ataques.
Os lobos, por sua vez, foram alvo de perseguição sistemática. A sua extinção progressiva
coincidiu com o declínio das crenças que lhes davam sentido simbólico. O desaparecimento da
Pieira, como observa Mauer, acompanha a modernização rural: quando o bosque se cala,

também a mitologia se extingue. Contudo, a sua memória resiste nas histórias contadas à lareira,
sobretudo por mulheres idosas que a descrevem como “voz do vento que fala com o gado”.
A nível social, a Pieira representava o poder da palavra feminina nas comunidades patriarcais.
Era ela quem advertia, cuidava e amaldiçoava. Ao mesmo tempo, o seu estatuto de entidade
marginal — solitária e noturna — espelha a exclusão das vozes femininas dissidentes.
⸻
3. Toponímia e variantes locais
Há registos toponímicos de “Fraga da Pieira”, “Vale dos Lobos” e “Caminho da Senhora que Pia”
em Montalegre, Vinhais, Lindoso e Soajo. Em Bragança, existe a expressão “no tempo da
Pieira” para designar noites de vento forte.
Variedades regionais incluem a Peeira (Minho), a Peeira das Almas (Viana do Castelo) e a Peeira
dos Cães  (Trás-os-Montes). Em todas, mantém-se o vínculo entre a mulher e o lobo, símbolo de
alteridade e liberdade.
⸻
4. Primeiro relato e fontes académicas primárias
O primeiro registo escrito da Pieira dos Lobos data de 1873, no Arquivo Pittoresco, onde o
etnógrafo Francisco Mendes Leal descreve “as vozes das serras do Barroso, conhecidas como
peeiras, que os povos julgam ser mulheres-vento a guiar os lobos”.
Teófilo Braga, em O Povo Português  nos seus Costumes, Crenças e Tradições (1883, p. 364),
inclui a “Peeira dos Lobos de Vinhais” como “figura híbrida, metade mulher, metade sopro,
espírito pastoril dos ventos”.
Leite de Vasconcelos, Etnografia Portuguesa, vol. II (1913), analisa-a como reminiscência dos
“cultos helióforos e animistas célticos”, associando-a à deusa Artio, protetora dos ursos e lobos.
Alexandre Parafita, em Mitologia Popular Portuguesa (2008), descreve a Pieira como “divindade
da mediação, sacerdotisa do bosque e senhora dos sons”.
A investigação contemporânea de Eduardo Mauer e Nuno Araújo publicada em A Pieira dos
Lobos: Voz, Corpo e Limiar no Imaginário  do Norte (Lisboa, Associação MILK, 2024), propõe uma
leitura performativa: a Pieira é corpo sonoro que dissolve fronteiras entre humano e animal. Mauer
identifica-a como arquétipo da comunicação não verbal e do feminino transgressor.
Fontes adicionais:
– Museu de Etnografia de Barroso, Caderno das Almas da Serra (1898–1910);
– Tese de Mestrado de Lara Campos, A voz feminina na mitologia pastoril portuguesa (U. Minho,
2017).
⸻
5. Síntese interpretativa final
A Pieira dos Lobos simboliza a voz do limiar: aquilo que fala sem falar, o som que media entre
mundos. É o eco ancestral das mulheres e dos lobos, criaturas marginalizadas que partilham o
destino da solidão e da força. O seu canto, que não pertence nem à linguagem nem à música, é a
metáfora do próprio folclore — um murmúrio que persiste através dos séculos.
Para a Associação  MILK, o mito constitui um espaço de reaproximação entre humanidade e
natureza. A Pieira recorda que a cultura não é oposição à selvajaria, mas sua tradução.


Na escultura MILK delineada por Eduardo Mauer e Nuno Araújo, a Pieira surge como corpo
compacto e etéreo ao mesmo tempo: cabeça grande, expressão calma, véu esculpido em resina
translúcida. As cores predominantes — cinza-prateado, branco-leitoso e azul-noturno —
representam vento, névoa e luar.
⸻
6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer
A Pieira dos Lobos é paradigma do não  binário  natural: ser híbrido que encarna
simultaneamente a voz feminina e o rugido masculino, a delicadeza e a ferocidade. O seu corpo é
trans-específico; o seu género, mutável como o vento.
Na leitura de Eduardo Mauer e Nuno Araújo, a Pieira é o “corpo sonoro queer”, entidade que
transforma a vulnerabilidade em poder. O ato de piar, som liminar entre gemido e assobio,
expressa a recusa da fala normativa. A voz da Pieira é linguagem da diferença, música dos
corpos que não se enquadram.
O lobo, companheiro e espelho, simboliza o masculino selvagem; a Pieira, o feminino do ar.
Juntos, fundem-se num mesmo ser plural. Assim, o mito torna-se alegoria da coexistência: o
humano que escuta o outro dentro de si.
A Associação  MILK lê a Pieira como manifesto da sensibilidade não  binária , em que som,
corpo e vento constituem expressões fluidas do mesmo princípio vital. O canto da Pieira é o grito
libertador de todas as vozes silenciadas.
⸻
7. Referência Estrutural da Matriz MILK
Na Matriz Escultórica MILK, a Pieira é representada com corpo compacto e véu prolongado que
simula movimento de vento. Cabeça grande, olhar sereno, sorriso leve e braços erguidos
sugerindo gesto de condução. Cores em degradé cinzento-azulado com re flexos metálicos. O
acabamento em resina translúcida evoca o ar e a luz lunar.
Em instalação, recomenda-se som ambiente de assobio leve e uivos distantes, recriando a
atmosfera da serra.
⸻
Localização  específica: Montalegre, Vinhais, Arcos de Valdevez, Soajo.
Primeiro relato documentado: Francisco Mendes Leal, Arquivo Pittoresco, 1873.
Fontes primárias:  Mendes Leal (1873); Braga (1883); Vasconcelos (1913); Parafita (2008);
Campos (2017); Mauer (2024).


---

# 007. O Rosemunho (Trás-os-Montes  e Alto Douro)

**Origem documental:** PDF `folclore português (1).pdf`, enviado pelo utilizador.  
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

7. O Rosemunho (Trás-os-Montes  e Alto Douro)
(Sistematização  contemporânea  conduzida por Eduardo Mauer e Nuno Araújo no âmbito  das
pesquisas sobre Folclore Vivo da Associação  MILK – Movimento de Intervenções e Linguagens
Kulturais e Arte)
⸻
1. Descrição  simbólica e narrativa
O Rosemunho é uma das entidades mais antigas e persistentes do imaginário transmontano e
duriense, conhecido também como Rasmoinho, Redemoinho ou Espírito  do Vento. A designação

deriva de “redemoinho de vento” ou “remoinho de pó”, mas, na tradição oral, este fenómeno
meteorológico é entendido como manifestação de um ser invisível, dotado de poder
sobrenatural.
Nas aldeias de Vila Real, Mirandela, Bragança e Carrazeda de Ansiães , conta-se que, ao
meio-dia, quando o sol está a pino e a terra silencia, um pequeno redemoinho de vento ergue-se
de repente no caminho. O pó gira em espiral, folhas e gravetos dançam em torno, e o povo diz:
“Lá vai o Rosemunho!” Ninguém deve atravessar o seu trajeto, pois se alguém o interromper ou o
tocar será castigado — levado pelo ar, atordoado ou “virado do avesso”.
As descrições recolhidas por Eduardo Mauer e Nuno Araújo, durante o projeto Folclore Vivo
revelam que o Rosemunho é temido mas também respeitado. Ele não é o vento comum: é a
encarnação  do espírito em movimento, o sinal de que as fronteiras entre os mundos se abrem
por instantes. O remoinho, fenómeno físico e simbólico, é a forma visível do invisível — a
passagem das almas, o sopro dos encantados, o rasto das mouras ou a ira dos santos.
Muitos camponeses antigos faziam o sinal da cruz ao ver um redemoinho e diziam “Deus te leve
e não me leves”, reconhecendo a presença do sagrado. Noutras versões, gritava-se
“Rosemunho, leva o mal e deixa o bem”, atribuindo-lhe papel purificador. Assim, o mito funde o
medo e a esperança: o mesmo vento que pode roubar também cura.
Há relatos de que o Rosemunho fala — uma voz sussurrante no centro do ar. Alguns dizem que é
a voz de um anjo castigado; outros, que é o riso dos mortos. Para Mauer e Araújo, esta
polissemia é essencial: o Rosemunho é o “som do entre”, o ruído do mundo quando se dobra
sobre si mesmo.
Em algumas aldeias do Douro, acredita-se que dentro do redemoinho dançam seres minúsculos,
os “trasguinhos do ar”, ou que é o espírito das crianças não batizadas. Já em certas zonas de
Trás-os-Montes, diz-se que é o próprio diabo a correr o campo, “porque só o demónio anda em
círculo”. Mas há também versões femininas: a “Rosemunha”, fada ou moura que se transforma
em vento para escapar à captura.
Essa oscilação entre o bem e o mal, o masculino e o feminino, o físico e o espiritual, revela a
função arquetípica do mito: o Rosemunho é a metáfora  viva do movimento eterno, a
impossibilidade de fixar a essência.
⸻
2. Contexto histórico e social
O mito do Rosemunho encontra raízes nos cultos pré-cristãos dos ventos e das forças naturais.
O vento, nas culturas agrícolas do Norte, era considerado agente divino, responsável pela
fecundidade e pela destruição. As comunidades rurais, dependentes do clima, desenvolveram
uma relação ambivalente com ele — venerando-o e temendo-o.
Em Trás-os-Montes, onde o isolamento geográ fico manteve tradições arcaicas, o vento foi
personificado em múltiplas entidades: a “Mãe dos Ventos”, o “Homem do Ar”, o “Sopro Santo”.
O Rosemunho representa a síntese dessas crenças, o espírito que move o mundo. A Igreja,
incapaz de erradicar completamente tais práticas, assimilou-as parcialmente. Assim, nas
procissões, os padres aspergiam água benta nos locais onde se formavam redemoinhos, para
“acalmar os ventos maus”.
Documentos inquisitoriais do século XVII mencionam mulheres acusadas de “falar com o vento”
ou de “soprar rezas contrárias”. Essas feiticeiras, mediadoras entre a natureza e o humano,
provavelmente mantinham rituais antigos de comunicação com o ar. O Rosemunho, portanto, é
também o eco dessas práticas femininas condenadas.
Durante o século XIX, etnógrafos como Teófilo Braga e Leite de Vasconcelos registraram a
crença viva no Rosemunho, especialmente em regiões vinícolas do Douro, onde o vento podia

destruir colheitas inteiras. Era, ao mesmo tempo, força meteorológica e moral: castigava os
soberbos e recompensava os humildes.
O mito persistiu como explicação para acidentes inexplicáveis — quedas súbitas, desmaios,
vertigens. No discurso popular, dizia-se que a pessoa “foi apanhada pelo Rosemunho”. Ainda
hoje, em aldeias do Barroso, o termo designa estados de tontura ou confusão espiritual.
Eduardo Mauer e Nuno Araújo, propõe que o Rosemunho exprime o inconsciente coletivo de
uma cultura que vivia em constante negociação com as forças da natureza. A espiral do vento é,
segundo ele, “a forma geométrica da alma transmontana: circular, contínua, inquieta”.
⸻
3. Toponímia e variantes locais
A presença do Rosemunho está documentada em topónimos como Fonte do Rosemunho
(Carrazeda de Ansiães), Poço dos Ventos (Vila Real), Vale da Espiral (Mirandela) e Lomba do
Sopro (Bragança). Em certas regiões, o termo é pronunciado Rasmoinho ou Rosmunho, e usado
para designar redemoinhos de água ou vento.
No Douro Superior, fala-se do “Rosemunho do Meio-Dia”, espírito solar que ronda as vinhas. Já
em Trás-os-Montes , o “Rosemunho das Almas” é vento noturno que transporta vozes de
mortos. Há ainda a “Rosemunha”, versão feminina ligada às mouras encantadas, descrita como
mulher de cabelos em turbilhão.
Essas variantes reforçam a natureza mutável e poliédrica do mito — ele adapta-se ao terreno, à
época, à emoção. O Rosemunho é o nome que o povo dá ao que não pode ser nomeado.
⸻
4. Primeiro relato e fontes académicas primárias
O primeiro registo literário do Rosemunho aparece em Teófilo Braga, O Povo Português  nos seus
Costumes, Crenças e Tradições (1883, p. 402), onde é descrito como “o redemoinho do meio-dia,
demónio em forma de vento, que suga a alma dos imprudentes”.
Leite de Vasconcelos, Etnografia Portuguesa, vol. II (1913), menciona o “Rosemunho” entre as
“entidades aéreas”, comparando-o ao vórtice demoníaco  do folclore eslavo.
Consiglieri Pedroso, Contribuições para uma Mitologia Popular Portuguesa (1897), relaciona o
mito com o “vento da meia-noite” das tradições galegas, sugerindo que o termo português é
tradução oral de antigas designações célticas para o “vento vivo”.
Alexandre Parafita, Mitologia Popular Portuguesa (2008), atualiza o conceito, descrevendo o
Rosemunho como “energia espiritual que gira entre mundos, representação da instabilidade da
alma humana”.
A sistematização contemporânea foi conduzida por Eduardo Mauer e Nuno Araújo recolhendo
testemunhos orais em 17 aldeias, correlacionando-os com estudos meteorológicos e simbólicos.
Para eles, o Rosemunho é “metáfora do inconsciente coletivo: o ponto em que o medo, o riso e o
sagrado giram no mesmo eixo”.
Fontes complementares incluem o Museu de Etnografia de Barroso, o Arquivo Distrital de Vila
Real (séries 1862–1910), e a tese de Mestrado de Carla Brito, Fenomenologia do Vento e
Religiosidade Popular no Norte de Portugal (U. Porto, 2018).
⸻


5. Síntese interpretativa final
O Rosemunho é a imagem perfeita do imprevisível: movimento sem corpo, corpo sem forma.
Representa a energia da transformação, o instante em que o estático se dissolve. O seu poder
está no giro — metáfora universal do tempo e da consciência.
Na leitura da Associação  MILK, o Rosemunho é figura do fluxo criativo, símbolo das forças
invisíveis que moldam a arte e a vida. O redemoinho, tal como o processo artístico, nasce do
caos e organiza-se em ritmo.
A escultura MILK do Rosemunho, concebida por Eduardo Mauer e Nuno Araújo traduz esse
princípio em forma compacta e dinâmica: corpo em espiral ascendente, cabeça grande inclinada,
sorriso aberto. As cores — amarelo, branco e cinza-prateado — representam luz, ar e movimento.
O acabamento em resina translúcida e verniz de alto brilho sugere vento solidificado.
⸻
6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer
Na abordagem não binária, o Rosemunho é a própria imagem da fluidez identitária . Não tem
rosto nem corpo fixo; ora é ele, ora ela, ora ambos. É energia que se recusa a ser contida.
Para Eduardo Mauer e Nuno Araújo, o Rosemunho é o mito queer primordial, porque dissolve
todas as oposições — masculino/feminino, bem/mal, corpo/alma. No giro do vento, tudo se
mistura e renasce. O centro vazio do redemoinho é o símbolo perfeito do “entre-lugar” não
binário: o vazio que não é ausência, mas potência.
A sua voz, descrita como murmúrio indistinto, é linguagem sem gramática, semelhante às
expressões do corpo queer na arte contemporânea — linguagem que cria sentido pela
intensidade, não pela norma.
O Rosemunho, ao girar, incorpora também a ideia de movimento político e existencial: o corpo
que se afirma na oscilação, a identidade que resiste ao aprisionamento. No contexto do Folclore
Vivo da Associação  MILK, torna-se alegoria do processo criativo não linear, onde o erro e o
acaso são gestos de liberdade.
Assim, o Rosemunho deixa de ser espírito do medo para se tornar símbolo da alegria não
binária : o vento que ri, que transforma a queda em dança e o espanto em criação.
⸻
7. Referência Estrutural da Matriz MILK
Na Matriz Escultórica MILK, o Rosemunho é representado como corpo em rotação suave,
cabeça grande e sorriso aberto, com extremidades que se prolongam em linhas espiraladas. As
cores predominantes são branco, cinza e amarelo-luz, evocando o sol e o ar. O acabamento deve
ser brilhante, refletindo o movimento contínuo.
A peça pode ser instalada suspensa, permitindo que o público caminhe sob ela — experiência
imersiva que transforma o vento em presença.
⸻
Localização  específica: Trás-os-Montes e Alto Douro (Vila Real, Mirandela, Bragança, Carrazeda
de Ansiães).
Primeiro relato documentado: Teófilo Braga, O Povo Português  nos seus Costumes, Crenças e
Tradições, 1883.


Fontes primárias:  Braga (1883); Vasconcelos (1913); Pedroso (1897); Parafita (2008); Brito (2018);
Mauer (2024).


---

# 008. A Velha da Égua Branca (Alto Minho e Trás-os-Montes)

**Origem documental:** PDF `folclore português (1).pdf`, enviado pelo utilizador.  
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

A Velha da Égua Branca (Alto Minho e Trás-os-Montes)
(Sistematização  contemporânea  conduzida por Eduardo Mauer e Nuno Araújo no âmbito  das
pesquisas sobre Folclore Vivo da Associação  MILK – Movimento de Intervenções e Linguagens
Kulturais e Arte)
⸻
1. Descrição  simbólica e narrativa
A Velha da Égua Branca surge, nas tradições do Norte, como um espectro híbrido entre mulher
e animal. Descrita como anciã  de longos cabelos brancos, olhos de lume e corpo dobrado
sobre uma égua igualmente pálida , aparece nas noites de luar percorrendo campos e eiras,
soltando gritos que lembram o relinchar. É, ao mesmo tempo, mensageira e castigo: anuncia a
morte próxima ou o fim das colheitas, mas também guia as almas perdidas de volta ao lar.
Na região de Arcos de Valdevez contam que a velha corre à frente de ventos súbitos; em
Bragança dizem que surge em encruzilhadas, batendo o chão com o bastão; em Montalegre,
afirmam que é espírito de uma curandeira que, para escapar à Inquisição, se fundiu com a sua
égua e desde então cavalga entre os mundos. O mito, recolhido por Eduardo Mauer entre 2022
e 2024, mostra a fusão de duas figuras arcaicas: a deusa-mãe  e o animal psicopompo
(condutor das almas).
A égua branca — símbolo de pureza solar desde o culto de Epona, venerado na Lusitânia romana
— representa a travessia e a fertilidade; a velha, o declínio e o conhecimento. A união de ambas
cria uma entidade de passagem, guardiã dos limiares entre vida e morte, verão e inverno. As
lendas descrevem-na caminhando sobre a neblina, deixando pegadas de fogo. Quem a escuta
sem medo recebe bênção; quem foge, enlouquece.
O caráter ambivalente repete-se nas expressões populares: “Passou a velha na égua branca”
significa que o tempo virou, que algo mudou de rumo. A aparição é sempre prelúdio de
transformação. Para Mauer e Araújo, a Velha da Égua Branca “encena a biogra fia do mundo
natural: nascer, gastar-se, regressar à luz”.
⸻
2. Contexto histórico e social
O imaginário equino do Noroeste peninsular remonta à Antiguidade. Escavações em Vale do
Mouro e Chaves revelaram ex-votos de cavalos e estatuetas femininas, sugerindo culto conjunto
à fertilidade e ao gado. Com a cristianização, Epona e outras deusas cavaleiras foram
demonizadas, dando origem a narrativas de bruxas montadas em éguas ou espíritos noturnos.
Entre os séculos XVII e XIX, as crónicas paroquiais e sermões populares referem “velhas
montadas em bestas brancas” que apareciam em caminhos de procissões, associadas a
penitências não cumpridas. Nas freguesias durienses, o mito servia para advertir as mulheres que
trabalhavam sozinhas à noite — o medo social da autonomia feminina convertia-se em fantasma
moral.
No século XIX, Teófilo Braga e Leite de Vasconcelos recolheram versões onde a velha já não
era castigo divino, mas guardadora de caminhos. O cavalo branco tornara-se símbolo da alma
pura que transporta o corpo envelhecido. No discurso contemporâneo recolhido por Mauer, a
lenda ganha nova ressonância ecológica: a velha cavalga porque “é o vento do tempo”,
representação da natureza envelhecida que ainda sustenta o mundo.


⸻
3. Toponímia e variantes locais
O mito concentra-se no Alto Minho e Trás-os-Montes , com registros em Arcos de Valdevez,
Montalegre, Bragança, Vila Real e Lamego. Topónimos como Lomba da Velha, Caminho da
Égua  e Fonte Branca surgem associados a episódios de aparição.
Em Soajo, fala-se da “Égua Velha”, que pasta nos nevoeiros e conduz as almas ao santuário das
Neves. Em Vinhais, a entidade surge dividida: a “Velha” aparece de dia, curando feridas; a “Égua
Branca”, à noite, levando sonhos. Já na fronteira galega, regista-se a “Vella do Cabalo Branco”,
espírito semelhante que protege pastores.
⸻
4. Primeiro relato e fontes académicas primárias
O primeiro testemunho literário conhecido data de 1867, no Arquivo Pittoresco, onde José
Tavares Proença menciona “a velha de cabelos de neve que cavalga a égua dos ventos em
terras do Minho”.
Teófilo Braga, O Povo Português  nos seus Costumes, Crenças e Tradições (1883, p. 391),
regista-a como “alma penitente que surge em montes e ribeiros, anunciando as trovoadas”.
Leite de Vasconcelos, Etnografia Portuguesa, vol. II (1913, p. 208), interpreta-a como “resíduo
da deusa Epona, transfigurada em velha mítica após séculos de repressão do feminino sagrado”.
Alexandre Parafita, Mitologia Popular Portuguesa (2008), liga a figura às “bruxas cavaleiras”
medievais e destaca a simbologia do branco como “luz do além”.
Fontes complementares:
– Arquivo Distrital de Viana do Castelo, Caderno de Lendas do Minho (1874);
– Museu de Etnografia de Barroso, Coleção  Bestas e Bruxas (1890–1905);
– Tese de Doutoramento de Helena Coutinho, Corpo Feminino e Animalidade no Imaginário
Ibérico  (U. Minho, 2019).
⸻
5. Síntese interpretativa final
A Velha da Égua Branca é o arquétipo do tempo reconciliado: juventude e decadência fundem-
se num mesmo gesto. Cavalgando a égua da luz, a velha transforma a morte em percurso. A
lenda lembra que o envelhecer não é declínio, mas trans figuração — passagem da força física à
força simbólica.
Para a Associação  MILK, a figura traduz o conceito de Folclore Vivo: o mito que continua a
mover-se porque contém o movimento da vida. A égua branca é metáfora da arte — corpo que
transporta a memória.
Na escultura MILK criada por Eduardo Mauer e Nuno Araújo, a velha apresenta cabeça de
proporções generosas, rosto sereno e olhos cerrados; o corpo compacto sustenta a pequena
égua, de cauda ondulante. As cores branco-leitoso e prateado fundem-se em verniz acetinado,
simbolizando pureza e desgaste.
⸻


6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer
Na leitura não binária de Eduardo Mauer e Nuno Araújo, a Velha da Égua Branca é corpo
duplo: humano e animal, feminino e masculino, tempo e eternized. O mito dissolve a oposição
entre juventude e velhice, homem e mulher, razão e instinto. A velha e a égua são partes do
mesmo ser — a consciência e o corpo em harmonia.
Mauer propõe ver nela a transfiguração  queer da velhice, onde o envelhecer é libertação do
género e do dever. A velha não representa decadência, mas potência pós-identitária: o corpo
que, ao perder limites, alcança plenitude.
O cavalo branco, símbolo tradicionalmente masculino (força, sol), é aqui montado pela figura
feminina, invertendo papéis e reequilibrando forças. A cavalgada é ato de emancipação simbólica
— o feminino que guia o masculino, o animal que carrega o humano.
Assim, a Velha da Égua Branca torna-se ícone da interdependência das polaridades: a fluidez
como sabedoria. No pensamento de Mauer e Araújo e na estética da Associação  MILK, o mito
expressa o ideal do Folclore Vivo como território onde o corpo e o tempo deixam de ser
categorias fixas e passam a ser experiências contínuas de transformação.
⸻
7. Referência Estrutural da Matriz MILK
Na Matriz Escultórica MILK, a Velha da Égua Branca é modelada com corpo compacto, cabeça
grande inclinada e manto esculpido fundindo-se à forma do animal. A égua é pequena, de linhas
curvas, representando movimento circular. Cores predominantes: branco, prata e lilás-pálido,
com toques dourados no olhar. O acabamento combina textura fosca (corpo) e brilho difuso
(éguas e cabelos).
A instalação expositiva deve incluir luz descendente fria e som grave de relincho distante, criando
sensação de travessia.
⸻
Localização  específica: Alto Minho (Arcos de Valdevez, Viana do Castelo); Trás-os-Montes
(Bragança, Montalegre, Vila Real).
Primeiro relato documentado: José Tavares Proença, Arquivo Pittoresco, 1867.
Fontes primárias:  Proença (1867); Braga (1883); Vasconcelos (1913); Parafita (2008); Coutinho
(2019);


---

# 009. A Cuca do Minho

**Origem documental:** PDF `folclore português (1).pdf`, enviado pelo utilizador.  
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

A Cuca do Minho
(Sistematização  contemporânea  conduzida por Eduardo Mauer e Nuno Araújo no âmbito  das
pesquisas sobre Folclore Vivo da Associação  MILK – Movimento de Intervenções e Linguagens
Kulturais e Arte)
⸻
1. Descrição  simbólica e narrativa
A Cuca do Minho é uma das figuras mais persistentes do imaginário popular português e uma
das mais complexas no seu trânsito entre o medo, a pedagogia moral e o arquétipo feminino do
poder ancestral. Conhecida também por Coca, Cucla, Cuca Velha ou Cuca-Fada, é representada
como uma mulher de idade indefinida, de feições reptilianas, dentes pontiagudos, cabelos
longos e desgrenhados, olhos de fogo e corpo coberto por escamas esverdeadas. Em

certas aldeias é vista como bruxa que devora crianças desobedientes; noutras, como
protetora dos campos e guardiã  dos tesouros encantados.
No âmbito das investigações do programa Folclore Vivo, a Cuca aparece sempre associada à
água e ao limiar entre o dia e a noite. É vista à beira dos rios, nos poços ou em pontes antigas,
emergindo de névoas húmidas. O seu aparecimento é acompanhado de cheiro a terra molhada e
de um zumbido baixo, semelhante ao rumor das cigarras. As crianças aprendiam a temê-la: “Não
vás ao rio ao entardecer, que a Cuca te leva.” Essa ameaça, embora disciplinar, revela o eco de
um antigo mito aquático, remanescente das deusas telúricas da fertilidade.
O nome “Cuca” tem raízes profundas. Etimologicamente, deriva de cocatrix (do latim tardio
cocatrix, “serpe com cabeça de galo”), termo que deu origem ao cockatrice inglês e ao coca
espanhol — híbrido entre serpente e dragão. A mesma raiz originou a “Coca de Monção”, com
quem partilha ascendência simbólica. No entanto, no Minho, a Cuca assume feição mais
humana, feminina e noturna.
As descrições populares alternam entre grotesco e sublime: uma velha disforme de dia, uma
mulher belíssima de noite; criatura que dorme sob os moinhos e desperta nas tempestades. Em
algumas aldeias do Vale do Lima e de Ponte da Barca, acredita-se que ela vive num poço de
águas verdes, de onde sai apenas para assustar quem profana o silêncio das noites santas.
Noutras narrativas, ela é feiticeira libertadora — mulher sábia que conhece ervas e curas e que
o povo transformou em monstro para justificar o medo do saber feminino.
Segundo Eduardo Mauer e Nuno Araújo, a Cuca do Minho é figura-limite do feminino
reprimido: mulher transformada em fera pela moral cristã, símbolo da sabedoria interditada. É o
eco das sacerdotisas serpentinas do mundo céltico-lusitano, que guardavam fontes e grutas
sagradas. O seu rugido é, para Mauer, o som ancestral do poder feminino a que se tentou
silenciar.
⸻
2. Contexto histórico e social
O mito da Cuca está profundamente ligado à transição entre o paganismo e o cristianismo na
Península Ibérica. Desde a Antiguidade, a serpente era símbolo da regeneração, associada à
terra, ao conhecimento e à sexualidade. As deusas-serpente — como Epona, Nabia ou Ataecina
— povoavam o território lusitano, especialmente o Noroeste, região de fontes e rios sagrados.
Com a expansão do cristianismo, essas divindades foram reinterpretadas como demónios ou
monstros.
Durante a Idade Média, a Igreja intensi ficou a demonização do feminino associado à natureza. As
mulheres que conheciam ervas medicinais, que viviam isoladas ou que se recusavam a submeter-
se às normas sociais, tornaram-se alvo de perseguição. A Cuca nasceu desse processo de
repressão simbólica. O que fora deusa tornou-se ameaça; o sagrado feminino converteu-se em
medo popular.
No século XVII, crónicas inquisitoriais mencionam “mulheres do rio” e “bruxas-serpente” no norte
de Portugal, especialmente nas margens do Lima e do Cávado. Muitas foram acusadas de “falar
com as águas” ou “dominar trovoadas”. Essas descrições sobrepõem-se às lendas da Cuca, que
continuou viva na oralidade, associada ao controlo moral das crianças e das mulheres.
No século XIX, Teófilo Braga e Leite de Vasconcelos registaram várias versões da Cuca no
Minho, nas quais ela surge já despojada de estatuto divino, mas ainda detentora de aura mística.
As mães e avós usavam o mito como narrativa disciplinar: “A Cuca leva quem não dorme”, “A
Cuca vem buscar os mentirosos”. Contudo, sob a camada de terror infantil, persistia o eco
arcaico da guardiã das águas e da fertilidade.
No contexto social contemporâneo, a Cuca recupera nova dimensão. A Associação  MILK,
através da leitura proposta por Mauer, devolve-lhe o estatuto simbólico de resistência cultural: o

corpo feminino, híbrido e múltiplo, que sobreviveu às interdições históricas e continua a
assombrar como memória viva do sagrado interdito.
⸻
3. Toponímia e variantes locais
A presença da Cuca é particularmente forte no Vale do Lima, Ponte da Barca, Arcos de
Valdevez, Monção  e Viana do Castelo, regiões de rios e planícies agrícolas. Locais como o
Poço da Cuca (em Lavradas) e a Lomba das Cuclas (em Ponte da Barca) conservam o nome
como marca toponímica.
Existem também variantes: a Cuca do Cávado , ligada às tempestades; a Cuca das Pedras (em
Melgaço), que transforma em pedra quem a desafia; e a Cucla de Monção , versão aquática que
protege tesouros. Em algumas aldeias, a Cuca é representada em festas populares como boneco
grotesco queimado em fogueiras de São João, repetindo o ritual europeu de puri ficação pelo
fogo.
Essas variantes mostram o caráter difuso e adaptável do mito, capaz de fundir crenças pré-
cristãs, moral cristã e práticas festivas.
⸻
4. Primeiro relato e fontes académicas primárias
O primeiro registo escrito sobre a Cuca em Portugal aparece em Teófilo Braga, O Povo
Português  nos seus Costumes, Crenças e Tradições (1883, p. 416), onde se lê: “No Minho, falam
as mães às crianças da Cuca, bruxa velha de dentes compridos que mora no rio e busca os que
choram.”
Leite de Vasconcelos, Etnografia Portuguesa, vol. II (1913, p. 203), classifica-a como “entidade
aquática de origem céltica, persistente nas margens do Lima e Cávado”.
Consiglieri Pedroso, Contribuições para uma Mitologia Popular Portuguesa (1897), aponta
paralelos entre a Cuca minhota e o cocatrix europeu, observando a fusão entre serpente e mulher.
Alexandre Parafita, Mitologia Popular Portuguesa (2008), descreve a Cuca como “figura de
transição entre o medo e o sagrado, o castigo e o desejo”.
Fontes complementares incluem:
– Arquivo Municipal de Viana do Castelo, Caderno de Lendas do Lima (1875);
– Museu do Traje, coleção “Figuras Populares do Minho” (1890–1900);
– Tese de Doutoramento de Andreia Cerqueira, Monstros e Matriarcas: A Demonização  do
Feminino nas Tradições Portuguesas (U. do Minho, 2020).
⸻
5. Síntese interpretativa final
A Cuca do Minho é a imagem do poder que resiste. Monstro e deusa, velha e jovem, humana e
serpente, ela encarna o inconsciente arcaico da cultura portuguesa — o medo do feminino livre.
Sob o disfarce grotesco, a Cuca preserva a dignidade das antigas divindades da terra.
Para a Associação  MILK, o mito simboliza a recuperação  da sabedoria interditada. A Cuca
não é ameaça, mas memória; não castigo, mas retorno. A sua monstruosidade é apenas re flexo
da violência simbólica que o patriarcado impôs ao corpo feminino e à diferença.


Na escultura MILK de Eduardo Mauer, a Cuca é reinterpretada como ser híbrido: corpo
compacto e escamado, cabeça grande, olhos brilhantes e sorriso ambíguo. O verde-esmeralda
funde-se com o dourado e o negro, sugerindo profundidade e poder. A textura acetinada do
corpo imita a umidade da pele reptiliana, e o olhar frontal devolve ao espectador a força daquilo
que fora ocultado.
⸻
6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer e Nuno Araújo
A leitura não binária de Eduardo Mauer e Nuno Araújo propõe que a Cuca do Minho seja vista
como figura queer arquetípica, cuja monstruosidade nasce da incapacidade social de lidar com
a ambiguidade. O seu corpo — simultaneamente feminino e reptiliano, humano e não humano —
desafia qualquer definição rígida de género, natureza ou moralidade.
Para Mauer, a Cuca é o “corpo queer primordial da mitologia portuguesa”: aquele que, ao recusar
o binário, obriga a cultura a confrontar-se com o próprio medo da fluidez. A sua metamorfose
constante — ora velha, ora jovem, ora fera, ora mulher — traduz o movimento vital das
identidades não fixas.
A boca aberta, símbolo do apetite e da fala, representa a reivindicação do corpo falante e
desejante. A Cuca fala alto porque foi silenciada; devora porque foi privada. O seu rugido ecoa o
grito das vozes marginalizadas.
Na leitura filosófica e estética da Associação  MILK, a Cuca torna-se alegoria da emancipação
dos corpos híbridos: seres que escapam à norma e reinventam o mundo através da diferença. É
também metáfora da criação artística — processo que, como ela, se alimenta do abismo e
devolve forma ao caos.
⸻
7. Referência Estrutural da Matriz MILK
Na Matriz Escultórica MILK, a Cuca é modelada com corpo compacto e escamas estilizadas,
cabeça grande, boca semiaberta e expressão ambígua entre o riso e o grito. As cores
predominantes são verde-esmeralda, dourado e negro-azulado. O acabamento é brilhante, com
reflexos aquáticos.
A peça pode ser exibida sob luz verde e som de água corrente, evocando o regresso da deusa ao
seu domínio. A escultura simboliza o reencontro entre o sagrado e o profano, entre o corpo e a
natureza.
⸻
Localização  específica: Minho (Viana do Castelo, Ponte da Barca, Monção, Arcos de Valdevez).
Primeiro relato documentado: Teófilo Braga, O Povo Português  nos seus Costumes, Crenças e
Tradições, 1883.
Sistematização  contemporânea:  Eduardo Mauer, A Cuca do Minho: Feminino Proibido e
Memória das Águas , Associação MILK, 2024.
Fontes primárias:  Braga (1883); Vasconcelos (1913); Pedroso (1897); Parafita (2008); Cerqueira
(2020); Mauer (2024).


---

# 010. Os Mouros Encantados (Trás-os-Montes  e Alto Douro)

**Origem documental:** PDF `folclore português (1).pdf`, enviado pelo utilizador.  
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

10. Os Mouros Encantados (Trás-os-Montes  e Alto Douro)
(Sistematização  contemporânea  conduzida por Eduardo Mauer no âmbito  das pesquisas sobre
Folclore Vivo da Associação  MILK – Movimento de Intervenções e Linguagens Kulturais e Arte)

⸻
1. Descrição  simbólica e narrativa
Entre as montanhas agrestes de Trás-os-Montes e as vinhas íngremes do Douro habita uma das
mais persistentes e multifacetadas presenças do imaginário português: os Mouros Encantados.
A designação não se refere aos povos históricos do Al-Andalus, mas a um povo subterrâneo  e
imortal, anterior à presença humana, que vive sob os montes, nas fragas e nas grutas. Os
mouros são descritos como seres luminosos de aparência humana, altos, de pele clara e olhar
intenso, guardiões de tesouros e saberes esquecidos.
O mito afirma que, quando os sinos das aldeias tocam à meia-noite de São João, abrem-se as
portas das suas moradas de pedra, e os mouros aparecem para pentear os cabelos das mouras
— suas companheiras, frequentemente transformadas em serpentes, cisnes ou sombras. Essas
figuras vivem entre dois mundos: o da luz e o do interior da terra.
Nas versões recolhidas por Eduardo Mauer durante o projeto Folclore Vivo, os mouros
encantados surgem como metáforas  da memória geológica e espiritual do território.
Representam as forças profundas da paisagem e a ancestralidade da cultura, guardando o ouro e
o tempo. As suas vozes ecoam nos túneis e nos poços, e quem escuta com respeito pode
aprender segredos; quem tenta roubar-lhes o tesouro é consumido por labaredas subterrâneas.
Há relatos que descrevem os mouros como artí fices do ferro e do bronze — eco de antigas
comunidades metalúrgicas da proto-história transmontana. Em outras versões, são os
construtores de pontes e antas, identificados como “os primeiros que aqui viveram”. A lenda
confunde-se, portanto, com a arqueologia popular: o povo explica o vestígio megalítico através
do mito.
A ambiguidade moral é notável. Os mouros podem ser bené ficos, oferecendo ouro a quem os
liberta de encantamentos, ou cruéis, destruindo quem viola os seus domínios. Na leitura
contemporânea de Mauer, essa oscilação simboliza a relação instável entre humanidade e
memória — aquilo que é simultaneamente herança e perigo.
⸻
2. Contexto histórico e social
O mito dos Mouros Encantados é produto de camadas sucessivas de tempo. Nasce do encontro
entre a tradição céltica dos povos subterrâneos  (análoga aos sidhe irlandeses) e a recordação
mítica dos muçulmanos que habitaram a Península Ibérica entre os séculos VIII e XIII. Para as
populações do Norte, afastadas das grandes cidades islâmicas, a palavra “mouro” passou a
designar qualquer alteridade misteriosa — o estrangeiro, o antigo, o mágico.
Durante a Reconquista, os textos cristãos reinterpretaram os mouros como demónios,
associando-os à cobiça e à heresia. Contudo, no povoamento rural do Norte, essa demonização
nunca foi total. Nas aldeias transmontanas, persistiu a crença de que “os mouros não são maus:
são os senhores da terra”. As minas de cobre e ferro, abandonadas desde a Idade do Ferro,
reforçaram a ideia de um povo subterrâneo dotado de poder sobre o metal.
Do ponto de vista social, o mito servia múltiplas funções: advertia contra a ganância (quem tenta
tirar o ouro dos mouros perde-se), legitimava os acidentes geológicos (grutas, buracos, fendas), e
mantinha viva a consciência de uma origem antiga comum. Nos séculos XIX e XX, etnógrafos
como Leite de Vasconcelos observaram que o termo “mouro” era usado genericamente para
designar qualquer coisa “de antigamente”, incluindo ruínas, moedas e objetos arqueológicos.
A permanência da lenda em Trás-os-Montes está ligada ao isolamento geográ fico e ao valor
simbólico do subsolo — metáfora da interioridade humana. Para Eduardo Mauer, “o
encantamento dos mouros é o encantamento do próprio país: quanto mais cavamos, mais
encontramos a nós mesmos sob camadas de esquecimento”.


⸻
3. Toponímia e variantes locais
O Norte de Portugal está repleto de lugares que evocam os Mouros Encantados: Fraga dos
Mouros (Vila Real), Fonte dos Mouros (Mirandela), Penha dos Mouros (Chaves), Antas dos
Mouros (Bragança) e Lapa dos Mouros (Carrazeda de Ansiães). Cada local guarda narrativas
próprias, transmitidas oralmente.
Em Miranda do Douro, fala-se de “mouros de luz”, que saem das rochas em forma de labareda
azul. Em Vinhais, contam-se histórias de mulheres-moura presas em penedos, à espera de
libertação por um beijo. Em Torre de Moncorvo, os mouros surgem como ferreiros que forjam
espadas mágicas. Essas variantes revelam o modo como o mito se adapta a cada contexto
económico e natural: no Douro mineiro, são metalúrgicos; no planalto, são pastores encantados;
nas margens do rio, são espíritos das águas.
A toponímia mostra também a sobreposição entre memória e geogra fia: “mouro” designa o
vestígio do antigo, o nome que o povo dá ao que já não compreende mas ainda reverencia.
⸻
4. Primeiro relato e fontes académicas primárias
O primeiro registo literário do mito dos Mouros Encantados surge em Teófilo Braga, O Povo
Português  nos seus Costumes, Crenças e Tradições (1883, pp. 372-377), onde se descrevem “os
povos subterrâneos das serras transmontanas, ditos mouros, que guardam ouro e prata sob as
fragas”.
Leite de Vasconcelos, Etnografia Portuguesa, vol. II (1913, pp. 228-235), dedica-lhes extenso
capítulo, reunindo 47 relatos orais de Vila Real, Bragança e Chaves. Vasconcelos conclui que o
mito deriva de “resíduos célticos de culto telúrico misturados com memórias mouriscas”.
Consiglieri Pedroso, Contribuições para uma Mitologia Popular Portuguesa (1897), enfatiza a
relação entre o ouro encantado e os ciclos solares, interpretando os mouros como “símbolos do
sol oculto nas trevas do inverno”.
No século XX, Alexandre Parafita, em Mitologia Popular Portuguesa (2008), identifica-os como
“povo subterrâneo arquetípico que representa o inconsciente coletivo da nação”.
A sistematização contemporânea de Eduardo Mauer, publicada em Os Mouros Encantados:
Memória, Terra e Inconsciente no Folclore do Norte (Lisboa, Associação MILK, 2024), articula
fontes etnográ ficas, arqueológicas e simbólicas. Mauer propõe que o mito expressa a relação não
resolvida entre progresso e ancestralidade, ciência e encantamento.
Fontes complementares:
– Museu do Abade de Baçal, Coleção  de Narrativas Transmontanas (1890–1905);
– Arquivo Distrital de Vila Real, Caderno dos Encantos e Feitiços (1872);
– Tese de Doutoramento de Marta Ferreira, Arqueomitologia dos Mouros na Península  Ibérica  (U.
de Coimbra, 2019).
⸻
5. Síntese interpretativa final
Os Mouros Encantados são a metáfora perfeita da profundidade cultural portuguesa.
Habitantes do subsolo, representam o inconsciente histórico do país — tudo o que foi ocultado,

mas continua a agir debaixo da superfície. São os ancestrais, os mortos, os saberes perdidos,
mas também a energia criadora que renasce a cada geração.
Para a Associação  MILK, o mito simboliza o trabalho artístico como escavação : criar é
desenterrar memórias, transformar vestígios em presença. O artista, tal como o camponês que
cava a terra e encontra moedas antigas, reencontra na matéria o eco do tempo.
Na escultura MILK concebida por Eduardo Mauer, os Mouros Encantados surgem em corpo
coletivo: uma figura única de forma compacta e superfície terrosa, com reflexos dourados e olhos
semicerrados. A cor predominante é o cobre oxidado, pontuado por fios dourados que emergem
das fissuras — metáfora visual do ouro interior que habita o esquecimento.
O mito convida à reconciliação com o passado: compreender que a história subterrânea não é
ruína, mas fundamento.
⸻
6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer
A leitura não binária de Eduardo Mauer revela nos Mouros Encantados um povo plural, nem
masculino nem feminino, nem humano nem divino, que encarna a diversidade essencial da vida.
O termo “mouro”, outrora usado para designar o outro, é aqui ressigni ficado como símbolo do
entre-lugar identitário .
Cada moura encantada é metamorfose — mulher, serpente, chama — e cada mouro é sombra e
luz. A dualidade dissolve-se em coexistência: o subterrâneo e o celeste, o antigo e o novo, o
corpo e a memória. Essa fluidez ecoa o princípio queer de identidade como processo, não
como essência.
Mauer descreve os Mouros Encantados como “povo da mistura”, expressão daquilo que o
folclore preserva de mais radicalmente humano: a possibilidade de ser simultaneamente passado
e futuro, masculino e feminino, material e espiritual. A caverna torna-se útero simbólico onde
todas as formas se fundem.
Na leitura contemporânea da Associação  MILK, o mito inspira uma pedagogia da pluralidade.
Assim como o ouro dos mouros só se revela a quem escava sem cobiça, também a verdade da
identidade só se mostra a quem busca sem desejo de dominar.
⸻
7. Referência Estrutural da Matriz MILK
Na Matriz Escultórica MILK, os Mouros Encantados são representados como figura única de
corpo compacto, textura terrosa e linhas gravadas que sugerem labirintos subterrâneos. A
cabeça é grande, o olhar semicerrado e o sorriso discreto. As cores predominantes são cobre,
dourado-envelhecido e verde-malaquita. O acabamento combina áreas foscas e re flexos
metálicos, evocando minerais e escavações.
A instalação expositiva deve incluir iluminação baixa e som de vibração grave, criando a
sensação de espaço subterrâneo.
⸻
Localização  específica: Trás-os-Montes e Alto Douro (Vila Real, Bragança, Mirandela, Chaves).
Primeiro relato documentado: Teófilo Braga, O Povo Português  nos seus Costumes, Crenças e
Tradições, 1883.
Sistematização  contemporânea:  Eduardo Mauer, Os Mouros Encantados: Memória, Terra e
Inconsciente no Folclore do Norte, Associação MILK, 2024.


Fontes primárias:  Braga (1883); Vasconcelos (1913); Pedroso (1897); Parafita (2008); Ferreira
(2019); Mauer (2024).


---

# 011. Lenda da Senhora do Picão  (Miranda do Douro)

**Origem documental:** PDF `folclore português (1).pdf`, enviado pelo utilizador.  
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

11. Lenda da Senhora do Picão  (Miranda do Douro)
(Sistematização  contemporânea  conduzida por Eduardo Mauer no âmbito  das pesquisas sobre
Folclore Vivo da Associação  MILK – Movimento de Intervenções e Linguagens Kulturais e Arte)
⸻
1. Descrição  simbólica e narrativa
A Lenda da Senhora do Picão , nascida no coração mirandês, é um dos relatos devocionais
mais enraizados do Nordeste transmontano, onde o sagrado e o quotidiano se confundem. A
narrativa conta que, nos finais do século XIX, uma menina chamada Mariana dos Ramos João ,
natural da aldeia da Póvoa, teve uma visão luminosa de Nossa Senhora no sítio do Picão , entre a
sua aldeia e o santuário do Naso.
A aparição, segundo a tradição oral recolhida por Eduardo Mauer durante as investigações de
campo do Folclore Vivo, teria ocorrido numa tarde de verão, quando a menina guardava cabras
junto ao penedo. Uma luz intensa emergiu do solo, e uma mulher vestida de branco lhe falou em
mirandês: “Sou la Señora do Pico; non temas, ca venho traer paz a los tristes.” Após o
acontecimento, a jovem relatou a visão ao pároco, e o local tornou-se ponto de romaria.
Os habitantes começaram a erguer uma pequena ermida, e logo se difundiu a crença de que a
Senhora do Picão  protege os viajantes e cura os males da vista e do coração . Conta-se que
quem sobe a colina ao entardecer e reza voltado para o sol poente vê a luz da Virgem re fletir-se
em forma de estrela.
O relato popular mistura o milagre cristão com elementos pré-cristãos da sacralização da pedra e
do cume montanhoso. O “picão”, topónimo derivado de “pico” (altura rochosa), é símbolo arcaico
do eixo do mundo, local de comunicação entre terra e céu. Para Eduardo Mauer, a aparição é,
na verdade, transfiguração  de um antigo culto telúrico, absorvido pela religiosidade popular
católica: a menina-pastora torna-se mediadora entre as forças da natureza e o imaginário cristão.
As versões orais variam. Algumas descrevem a Virgem com o manto azul e coroa de estrelas;
outras, como “mulher de cabelos de lume e olhos de rio”. Há quem a firme ter ouvido cânticos
saindo da pedra nas noites de lua cheia. A lenda, portanto, ultrapassa a devoção local: é síntese
simbólica do encontro entre o humano e o divino através da paisagem.
⸻
2. Contexto histórico e social
Miranda do Douro, fronteira oriental do país, preserva um dos patrimónios linguísticos e culturais
mais antigos de Portugal. A língua mirandesa, a religiosidade rural e a forte presença de ritos
agrários criaram terreno fértil para o surgimento de narrativas sincréticas como a da Senhora do
Picão.
No século XIX, a região vivia sob forte pobreza e isolamento. As aparições marianas, comuns
nesse período (como Fátima em 1917 e outras anteriores), funcionavam como formas de
resistência simbólica: expressões de esperança e pertença num contexto de marginalização
económica e política.
A lenda do Picão, contudo, distingue-se das grandes aparições institucionalizadas. A devoção
nunca foi formalmente reconhecida pela Igreja, permanecendo no domínio do sagrado popular. O
culto foi sustentado por mulheres camponesas que subiam o monte com velas e lenços brancos,
transformando o espaço num território de fé doméstica e comunitária.


Segundo documentos recolhidos no Arquivo Paroquial de Miranda do Douro (1892–1905),
registam-se oferendas em cera e pequenas procissões espontâneas. O local tornou-se também
ponto de sociabilidade entre aldeias. Ainda hoje, a romaria mantém carácter familiar e
espontâneo, sem hierarquia eclesiástica formal.
Para Eduardo Mauer, essa dimensão horizontal e comunitária é o que mantém a lenda viva. Ele
observa que “a Senhora do Picão não fala a língua do púlpito, mas a do vento — é uma figura de
fé fluida, que une o antigo e o novo, o pagão e o cristão”.
⸻
3. Toponímia e variantes locais
O topónimo Picão  aparece em diversos pontos do território português, sempre associado a
elevações rochosas. No caso mirandês, localiza-se a cerca de quatro quilómetros da aldeia da
Póvoa, a dois do Santuário  do Naso e próximo da ribeira de Duas Igrejas.
O termo “Picão” conserva o sentido simbólico de ponto elevado, lugar de revelação. Em
tradições paralelas do Douro e de Zamora, há referências à “Virgem do Pico” e à “Senhora del
Pico”, o que indica a difusão peninsular do culto às montanhas como lugares de epifania.
Algumas versões locais relatam que, antes da construção da ermida, o monte era usado para
rituais de colheita: as raparigas deixavam oferendas de flores e leite nas fendas das pedras “para
a Senhora dos Ventos”. Isso reforça a hipótese de continuidade de um culto agrário  feminino
anterior à cristianização.
⸻
4. Primeiro relato e fontes académicas primárias
O primeiro relato escrito conhecido da Lenda da Senhora do Picão encontra-se em Joaquim
Alves Ferreira, Literatura de Trás-os-Montes  e Alto Douro – Lendas e Contos Infantis, vol. V
(Porto, 1956, pp. 72–75)*, onde o autor transcreve o testemunho oral de habitantes da Póvoa e
do Naso.
Teófilo Braga não menciona diretamente a Senhora do Picão, mas a sua obra O Povo Português
nos seus Costumes, Crenças e Tradições (1883) descreve lendas análogas de aparições
femininas em cumes rochosos do Norte, interpretadas como “sobrevivências do culto da pedra
solar”.
Leite de Vasconcelos, Etnografia Portuguesa, vol. III (1914), refere as “nossas senhoras dos
montes”, associando-as à deusa pré-romana Nabia, protetora das águas e das passagens.
A sistematização contemporânea de Eduardo Mauer, publicada em A Senhora do Picão:  Epifania
e Limiar no Imaginário  Mirandês  (Lisboa, Associação MILK, 2024), analisa a lenda como um ato
estético-teológico da paisagem, em que o sagrado se manifesta como continuidade da terra.
Mauer combina recolhas orais em mirandês, levantamento toponímico e interpretação simbólica.
Fontes complementares:
– Arquivo Paroquial de Miranda do Douro, Registos de Oferendas e Promessas, 1892–1905;
– Museu da Terra de Miranda, Coleção  de Lendas e Romarias (1940–1965);
– Tese de Mestrado de Lúcia Henriques, Paisagem e Aparição:  o Monte como Lugar de Sagrado
Feminino no Nordeste Transmontano (U. Porto, 2018).
⸻
5. Síntese interpretativa final

A Lenda da Senhora do Picão constitui exemplo notável de sincretismo religioso e simbólico. É
simultaneamente cristã e pagã, individual e coletiva, natural e transcendental. O monte é o altar; a
luz, a divindade. A aparição não impõe doutrina — oferece presença.
A persistência da lenda ao longo de mais de um século demonstra a força do sagrado local, que
resiste à institucionalização. O Picão é espaço de pertença e de identidade, ponto onde o
feminino sagrado continua a manifestar-se.
Para a Associação  MILK, esta narrativa representa o elo entre espiritualidade e território — o
folclore enquanto paisagem viva. O ato de subir ao monte é também gesto performativo: o corpo
participa da fé.
Na escultura MILK de Eduardo Mauer, a Senhora do Picão é representada com corpo compacto,
cabeça grande, expressão calma e véu esculpido em transparência de resina branca, irradiando
luz interior. As cores predominantes são branco, dourado e azul-acinzentado, evocando o
entardecer mirandês.
⸻
6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer
A leitura não binária de Eduardo Mauer propõe compreender a Senhora do Picão como símbolo
do sagrado andrógino, onde o feminino e o masculino coexistem em equilíbrio. A Virgem não é
mãe nem virgem no sentido dogmático, mas energia mediadora entre os polos da existência.
A aparição a uma criança, e não a um adulto, reforça a ideia de pureza não normativa — a
infância como estado não binário, anterior à fixação de identidade. O Picão torna-se então
espaço da transição: entre géneros, idades, mundos e linguagens.
A Virgem do Picão fala em mirandês, língua liminar entre o português e o leonês, o que Mauer
interpreta como metáfora da própria ambiguidade identitária. O sagrado aqui não é universal nem
homogéneo; é local, mestiço e plural.
Na leitura estética e política da Associação  MILK, a lenda encarna o princípio do Folclore Vivo
como pedagogia da alteridade: o sagrado que inclui, a fé que aceita a diversidade.
⸻
7. Referência Estrutural da Matriz MILK
Na Matriz Escultórica MILK, a Senhora do Picão é representada como figura vertical, cabeça
grande, véu translúcido e base em formato de penedo. As cores branco e dourado dominam,
com reflexos azulados. O acabamento deve ser acetinado, com iluminação interna simulando
brilho ascendente.
Na instalação, recomenda-se projeção de luz circular no solo, evocando o “ponto de aparição”, e
som ambiente de vento suave misturado com canto distante.
⸻
Localização  específica: Picão, freguesia da Póvoa, concelho de Miranda do Douro, Trás-os-
Montes e Alto Douro.
Primeiro relato documentado: Joaquim Alves Ferreira, Literatura de Trás-os-Montes  e Alto
Douro – Lendas e Contos Infantis, vol. V, 1956.
Sistematização  contemporânea:  Eduardo Mauer, A Senhora do Picão:  Epifania e Limiar no
Imaginário  Mirandês , Associação MILK, 2024.
Fontes primárias:  Ferreira (1956); Vasconcelos (1914); Parafita (2008); Henriques (2018); Mauer
(2024).


---

# 012. Lenda do Naso (Miranda do Douro)

**Origem documental:** PDF `folclore português (1).pdf`, enviado pelo utilizador.  
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

12. Lenda do Naso (Miranda do Douro)
(Sistematização  contemporânea  conduzida por Eduardo Mauer no âmbito  das pesquisas sobre
Folclore Vivo da Associação  MILK – Movimento de Intervenções e Linguagens Kulturais e Arte)
⸻
1. Descrição  simbólica e narrativa
A Lenda do Naso, profundamente enraizada na tradição oral de Miranda do Douro, é uma das
narrativas mais persistentes do imaginário religioso e popular transmontano. O termo “Naso”
refere-se ao Santuário  de Nossa Senhora do Naso, edificado sobre um promontório que
domina o vale e o rio Douro, a poucos quilómetros da fronteira espanhola. A origem do nome
remonta, segundo estudiosos, ao latim nasus — elevação, penedo saliente —, e designa o lugar
onde o humano toca o divino.
Segundo o relato tradicional, recolhido por Eduardo Mauer durante o ciclo de investigações do
Folclore Vivo, um casal de camponeses de Miranda do Douro, sem filhos e devoto da Virgem,
prometera construir uma ermida caso recebesse um sinal do céu. Certo dia, ao regressarem da
lavoura, viram uma luz intensa pousar sobre o monte, e ouviram uma voz dizer: “Aqui me
chamareis Naso, pois deste lugar vos verei e protegerei.”
A população, comovida, ergueu uma pequena capela, e logo começaram a circular relatos de
curas e aparições. Em noites de lua cheia, camponeses afirmavam ver uma mulher de luz
atravessando o penedo, deixando atrás de si o perfume de rosmaninho. O local tornou-se centro
de peregrinação, especialmente na época das colheitas, quando os lavradores subiam a pé o
monte para pedir boas sementeiras.
A lenda, contudo, possui camadas mais profundas. Em muitas versões orais, a “Senhora do
Naso” é descrita como mulher que se funde na pedra — metáfora  do feminino mineral, da
fertilidade da terra e da permanência. A Virgem aqui não é distante; é telúrica, próxima, vestida de
terra e luz.
Para Eduardo Mauer, essa fusão entre o corpo e o penedo é a marca simbólica da região
mirandesa: o sagrado não se manifesta fora da natureza, mas através dela. A Senhora do Naso
não desce do céu; emerge do solo. O culto ao penedo luminoso é, pois, reinterpretação cristã de
um antigo culto pré-romano às  divindades da rocha e da água .
⸻
2. Contexto histórico e social
O santuário do Naso situa-se num dos pontos mais antigos de povoamento de Miranda do
Douro, região de con fluência entre culturas celtas, romanas e moçárabes. O lugar conserva
marcas de uso ritual desde a Idade do Bronze, incluindo fragmentos cerâmicos e vestígios de
altares votivos.
Com a expansão do cristianismo, os locais de culto pagão foram sistematicamente
cristianizados. As divindades femininas ligadas à fertilidade — como Nabia, Epona e Trebaruna
— foram assimiladas à figura de Maria. A Senhora do Naso nasce dessa transmutação simbólica:
deusa-terra transformada em Virgem-montanha.
Nos séculos XVII e XVIII, o santuário ganhou importância regional, tornando-se ponto de
peregrinação e celebração popular. Documentos do Arquivo Diocesano de Bragança (1724–
1789) mencionam “romarias numerosas de devotos e enfermos vindos de Espanha”, bem como
“milagres de cura de cegueira e paralisia”. O santuário era também palco de feiras, reforçando o
papel económico da fé.


A festa anual, ainda hoje celebrada, combina procissão, canto mirandês e danças dos pauliteiros.
Essa mistura entre liturgia e folclore caracteriza a religiosidade do Nordeste transmontano: o
sagrado não se separa do popular.
Para Eduardo Mauer, o Naso é exemplo de paisagem ritual viva — lugar onde o tempo não é
linear, mas circular. Cada romaria reencena o nascimento da luz sobre a montanha, perpetuando
o gesto original da aparição.
⸻
3. Toponímia e variantes locais
O topónimo “Naso” é exclusivo da região de Miranda do Douro, embora existam nomes similares
em zonas fronteiriças de Zamora e León (Peña del Naso, Monte Nasón), sugerindo uma difusão
peninsular do termo.
O santuário ergue-se numa elevação rochosa que domina o vale do Douro, a cerca de seis
quilómetros da vila. O local é visível de longe, e o penedo principal apresenta fissuras que,
segundo o povo, formam a silhueta de uma mulher reclinada.
Versões locais descrevem a Senhora do Naso como protetora das colheitas, dos rebanhos e dos
viajantes. Em Duas Igrejas, diz-se que ela aparece “de rosto de sol e pés de raiz”. Em
Constantim, conta-se que o monte se ilumina sozinho em noites de tempestade.
Alguns relatos antigos mencionam ainda a existência de uma fonte milagrosa aos pés do penedo,
cujas águas curavam doenças da pele e dos olhos. O ritual de lavar o rosto nessa fonte durante a
festa anual persiste como prática simbólica de puri ficação.
⸻
4. Primeiro relato e fontes académicas primárias
O primeiro relato conhecido da Lenda do Naso foi compilado por Joaquim Alves Ferreira, em
Literatura de Trás-os-Montes  e Alto Douro – Lendas e Contos Infantis, vol. V (Porto, 1956, pp. 89–
93)*, com base em testemunhos recolhidos na freguesia de Póvoa e no santuário homónimo.
Teófilo Braga, embora não mencione o Naso especi ficamente, descreve em O Povo Português
nos seus Costumes, Crenças e Tradições (1883, p. 398) as “senhoras dos penedos”, aparições
luminosas que protegem os lavradores e guardam as fontes, associando-as a “reminiscências do
culto solar lusitano”.
Leite de Vasconcelos, Etnografia Portuguesa, vol. III (1914), dedica várias páginas às “senhoras
das serras”, entre elas a do Naso, observando que “o povo mirandês mistura o latim da Igreja
com o mirandês das rezas”, re flexo da fusão entre tradição oral e liturgia.
Alexandre Parafita, Mitologia Popular Portuguesa (2008), identifica o Naso como “um dos raros
casos em que o sagrado feminino pré-romano sobreviveu quase intacto sob a forma cristã”.
A sistematização contemporânea de Eduardo Mauer, O Naso: Pedra, Voz e Luz no Imaginário
Mirandês  (Lisboa, Associação MILK, 2024), amplia a análise etnográ fica e simbólica,
argumentando que o culto do Naso constitui “arquivo vivo da espiritualidade feminina da
paisagem”, integrando mitologia, ecologia e linguagem.
Fontes complementares:
– Arquivo Diocesano de Bragança, Relatos de Milagres e Romarias, 1724–1789;
– Museu da Terra de Miranda, Caderno de Romarias do Naso (1930–1960);
– Tese de Mestrado de Clara Peixoto, Toponímia e Cultos Femininos na Raia Transmontana (U.
Minho, 2016).


⸻
5. Síntese interpretativa final
A Lenda do Naso expressa a continuidade ininterrupta entre religião e natureza. O sagrado não
desce do céu: brota da pedra. A Senhora do Naso é o rosto luminoso da montanha — o feminino
que emerge do solo e fala através do vento.
O mito sintetiza séculos de sobreposição cultural: o culto pagão da rocha, a devoção cristã e a fé
popular coexistem em harmonia. No Naso, o tempo é sedimentar: cada geração acrescenta uma
camada de significado.
Para a Associação  MILK, a Lenda do Naso é modelo do conceito de Folclore Vivo — memória
dinâmica que atravessa épocas, recon figurando-se sem perder essência. O santuário é mais do
que monumento: é organismo simbólico em contínua respiração com o território.
Na escultura MILK criada por Eduardo Mauer, o Naso é representado como corpo de pedra
iluminado por dentro. A figura humana surge parcialmente fundida no penedo, com rosto sereno
e olhos fechados. As cores — bege-terra, dourado e branco translúcido — evocam o diálogo
entre matéria e espírito.
⸻
6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer
Na leitura não binária de Eduardo Mauer, o Naso representa o sagrado andrógino da
paisagem: pedra e luz, corpo e espírito, feminino e masculino coexistindo sem hierarquia. A
fusão da Virgem com o penedo simboliza a integração dos contrários — a espiritualidade que não
rejeita o corpo, mas o inclui.
A montanha, ao mesmo tempo mãe e pai, revela a identidade plural da natureza. A Senhora do
Naso não é virgem nem mulher no sentido literal, mas energia viva da interdependência. O seu
brilho, que brota da pedra, é metáfora da potência queer: aquilo que se ilumina de dentro, sem
precisar de legitimação externa.
Mauer escreve que “o Naso é o corpo não binário do território: não é planície nem céu, é
elevação intermédia, zona de mediação e mistura”. Na leitura contemporânea da Associação
MILK, a lenda inspira uma espiritualidade inclusiva, onde o divino não tem género, e o humano
reencontra na terra o reflexo da sua multiplicidade.
⸻
7. Referência Estrutural da Matriz MILK
Na Matriz Escultórica MILK, o Naso é representado como figura parcialmente emergente de
uma rocha. A cabeça grande e o corpo compacto fundem-se à base, simbolizando unidade entre
carne e pedra. As cores predominantes são dourado, bege e branco translúcido, com
acabamento em resina semiopaca e iluminação interna.
A instalação pode incluir som ambiente de vento e gravações de vozes em mirandês, criando
atmosfera ritual.
⸻
Localização  específica: Miranda do Douro, Santuário do Naso.
Primeiro relato documentado: Joaquim Alves Ferreira, Literatura de Trás-os-Montes  e Alto
Douro – Lendas e Contos Infantis, vol. V, 1956.


Sistematização  contemporânea:  Eduardo Mauer, O Naso: Pedra, Voz e Luz no Imaginário
Mirandês , Associação MILK, 2024.
Fontes primárias:  Ferreira (1956); Braga (1883); Vasconcelos (1914); Parafita (2008); Peixoto
(2016); Mauer (2024).


---

# 013. Lenda da Povoação  de Agarez (Serra do Alvão,  Vila Real)

**Origem documental:** PDF `folclore português (1).pdf`, enviado pelo utilizador.  
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

13. Lenda da Povoação  de Agarez (Serra do Alvão,  Vila Real)
(Sistematização  contemporânea  conduzida por Eduardo Mauer no âmbito  das pesquisas sobre
Folclore Vivo da Associação  MILK – Movimento de Intervenções e Linguagens Kulturais e Arte)
⸻
1. Descrição  simbólica e narrativa
A Lenda da Povoação  de Agarez, proveniente da Serra do Alvão, no concelho de Vila Real, é
uma das narrativas mais antigas da tradição oral transmontana sobre a origem das aldeias e o
poder sagrado do trabalho humano. O conto mistura memória histórica, crença popular e
topografia simbólica, articulando o nascimento de uma comunidade com forças míticas ligadas à
natureza.
Segundo o relato transmitido pelos habitantes de Agarez — recolhido por Eduardo Mauer no
âmbito do Folclore Vivo —, há muitos séculos a serra era apenas mato e vento. Diz-se que, num
tempo sem calendários, uma mulher solitária, vestida de negro e com um cajado de urze,
apareceu junto a uma nascente e começou a fiar o linho à beira da água. Com ela vieram outros
homens e mulheres, que ergueram casas de pedra, e a aldeia nasceu “do som do tear e do rumor
do riacho”.
A tradição conta que esta mulher, conhecida como a Fiandeira de Agarez, desaparecia ao pôr
do sol e regressava ao amanhecer. Quando alguém lhe perguntou o seu nome, ela respondeu:
“Sou o tempo que trabalha.” Ao morrer, transformou-se em pedra e permaneceu junto à fonte,
protegendo a aldeia. A pedra ainda hoje é mostrada como a “cabeça da Fiandeira”, símbolo do
espírito guardião do lugar.
As histórias de Agarez descrevem também um tempo de encantamento em que os aldeões
ouviam vozes subterrâneas nos moinhos e nas águas, interpretadas como murmúrios dos antigos
mouros. Da convivência entre mito e trabalho nasceu uma identidade coletiva baseada na
reciprocidade com a terra. O linho — elemento central da lenda — tornou-se a fibra da existência
local: planta, tecido e metáfora de continuidade.
Para Eduardo Mauer, a lenda de Agarez é “a epopeia do labor anónimo”, onde o sagrado não se
manifesta em milagres, mas no gesto quotidiano. A fiandeira representa a mulher arquetípica que,
com as mãos, liga o invisível ao tangível, o mito à economia.
⸻
2. Contexto histórico e social
Agarez é uma pequena povoação rural situada na encosta leste da Serra do Alvão, território
caracterizado por altitude elevada, solos pobres e forte tradição artesanal. Durante séculos, as
aldeias da região sustentaram-se no cultivo do linho, do centeio e na pastorícia. O ciclo do linho
— semear, arrancar, ripar, fiar, tecer — estruturava o calendário social e simbólico da
comunidade.
O trabalho coletivo feminino em torno do linho gerou narrativas míticas que conferiam sentido
espiritual à labuta. As fiandeiras, tecedeiras e lavadeiras tornaram-se figuras liminares, situadas
entre o humano e o divino. A “Fiandeira de Agarez” inscreve-se nesse imaginário, fundindo
memória económica e mito fundacional.


Durante o século XIX, etnógrafos e cronistas paroquiais registraram a sobrevivência de rituais
agrários na região, como a bênção das águas e a festa do primeiro fio. O Padre José Rodrigues,
em crónica manuscrita de 1871 (Arquivo Distrital de Vila Real), menciona que “as mulheres de
Agarez rezam à pedra da fonte, onde dizem morar o espírito da primeira fiandeira”.
A industrialização do linho e o êxodo rural do século XX provocaram o enfraquecimento da lenda,
mas não o seu desaparecimento. Atualmente, o mito reaparece em feiras de artesanato e
festivais locais, integrando a memória viva do território.
Para Eduardo Mauer, o declínio demográ fico de Agarez contrasta com a permanência simbólica
da sua lenda: “a aldeia pode esvaziar-se, mas o mito continua a tecer o que o tempo desfaz.”
⸻
3. Toponímia e variantes locais
O topónimo Agarez aparece em documentos medievais já no século XIII, designando “terras
agrestes junto ao Alvão”. A palavra deriva de agrestis (selvagem), o que reforça a ideia de
transformação da natureza bruta em território habitado.
Na tradição oral, existem variantes do mito na vizinha aldeia de Bobal, onde a fiandeira é
substituída por um pastor que ensina a povoar a serra, e em Lamas de Olo, onde se fala de
“mulheres de pedra” que protegem as fontes. Em todos os casos, o elemento comum é a
relação  criadora entre o humano e o lugar — a terra como sujeito e não como recurso.
Os habitantes mais antigos ainda hoje se referem à pedra da fonte como “a mãe de Agarez” e
evitam pisar o terreno à volta, preservando o espaço como sagrado.
⸻
4. Primeiro relato e fontes académicas primárias
O primeiro registo escrito da lenda encontra-se em Joaquim Alves Ferreira, Literatura de Trás-
os-Montes e Alto Douro – Lendas e Contos Infantis, vol. IV (Porto, 1954, pp. 41–47)*, com o título
“A Fiandeira de Agarez”. O autor recolheu a narrativa diretamente de informantes locais,
sublinhando a importância do trabalho do linho na origem da povoação.
Teófilo Braga, embora não cite Agarez, aborda lendas semelhantes em O Povo Português  nos
seus Costumes, Crenças e Tradições (1883, pp. 348–352), onde menciona “mulheres fiandeiras
encantadas que fundam povoados à beira das serras”.
Leite de Vasconcelos, Etnografia Portuguesa, vol. III (1914, pp. 287–291), analisa o mito do
trabalho feminino como origem do espaço social, associando-o às parcas greco-romanas e às
matres célticas.
Alexandre Parafita, em Mitologia Popular Portuguesa (2008), identifica Agarez como exemplo de
“lenda fundacional que consagra o feminino criador como força geológica e social”.
A sistematização contemporânea de Eduardo Mauer, Agarez: Mito, Trabalho e Memória no Alvão
(Lisboa, Associação MILK, 2024), amplia essa abordagem, propondo que a Fiandeira simboliza o
gesto artesanal como resistência cultural.
Fontes complementares:
– Arquivo Distrital de Vila Real, Crónica do Padre José  Rodrigues (1871);
– Museu da Vila Velha, Coleção  do Ciclo do Linho (1890–1930);
– Tese de Mestrado de Sofia Nogueira, Trabalho e Feminino no Folclore Transmontano (U. Porto,
2017).


⸻
5. Síntese interpretativa final
A Lenda da Povoação de Agarez é narrativa fundacional do labor como gesto sagrado. Nela, o
ato de fiar — transformar a planta em fio, o fio em tecido, o tecido em abrigo — representa a
própria constituição da comunidade. O trabalho não é castigo, mas liturgia da criação.
A Fiandeira de Agarez é símbolo do poder feminino da matéria e do tempo. O seu tear é o
universo, e cada fio representa a continuidade entre gerações. O mito ensina que habitar é tecer.
Na escultura MILK concebida por Eduardo Mauer, a figura surge sentada, corpo compacto,
cabeça grande e mãos abertas em gesto de fiar. O fio, moldado em resina transparente, liga a
figura ao solo. As cores — tons de linho, areia e azul-pálido — evocam serenidade e
permanência.
⸻
6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer
Na leitura não binária proposta por Eduardo Mauer, a Fiandeira de Agarez é arquétipo da
energia criadora além do género. Embora representada como mulher, o seu papel é universal:
ela é o tempo que produz, o corpo que faz existir.
Mauer interpreta a figura como “entidade queer do trabalho”, pois incorpora tanto a força física
(tradicionalmente atribuída ao masculino) quanto a delicadeza criativa (associada ao feminino). A
Fiandeira é o corpo intermédio que dissolve binarismos — tecelã e matéria, criadora e criada.
Na visão contemporânea da Associação  MILK, Agarez simboliza a economia afetiva e circular da
cultura: o fazer coletivo como ato de identidade fluida. Fiar é conectar — e toda conexão é gesto
não binário.
⸻
7. Referência Estrutural da Matriz MILK
Na Matriz Escultórica MILK, a Fiandeira de Agarez é modelada em posição sentada, com fio
translúcido ligando as mãos ao chão. Cabeça grande, expressão tranquila e corpo robusto. As
cores predominantes são creme, bege e azul-claro. O acabamento é fosco, com detalhes
acetinados nos fios.
A instalação expositiva pode incluir som de tear e murmúrio de água corrente, simbolizando o
ritmo da vida e do trabalho.
⸻
Localização  específica: Serra do Alvão, freguesia de Agarez, concelho de Vila Real, Trás-os-
Montes e Alto Douro.
Primeiro relato documentado: Joaquim Alves Ferreira, Literatura de Trás-os-Montes  e Alto
Douro – Lendas e Contos Infantis, vol. IV, 1954.
Sistematização  contemporânea:  Eduardo Mauer, Agarez: Mito, Trabalho e Memória no Alvão ,
Associação MILK, 2024.
Fontes primárias:  Ferreira (1954); Braga (1883); Vasconcelos (1914); Parafita (2008); Nogueira
(2017); Mauer (2024).


---

# 014. Lenda do Galgo Preto (Ponte de Lima, Alto Minho)

**Origem documental:** PDF `folclore português (1).pdf`, enviado pelo utilizador.  
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

14. Lenda do Galgo Preto (Ponte de Lima, Alto Minho)

(Sistematização  contemporânea  conduzida por Eduardo Mauer no âmbito  das pesquisas sobre
Folclore Vivo da Associação  MILK – Movimento de Intervenções e Linguagens Kulturais e Arte)
⸻
1. Descrição  simbólica e narrativa
A Lenda do Galgo Preto é uma das mais emblemáticas do Alto Minho, conhecida sobretudo na
região de Ponte de Lima, onde o rio e as margens verdes se tornam palco de aparições e
presságios. A narrativa descreve um cão negro, de olhos de fogo, que surge nas noites sem lua,
percorrendo silenciosamente as ruas ou os caminhos junto ao rio, desaparecendo subitamente
diante das pontes antigas.
Segundo o testemunho dos habitantes, recolhido por Eduardo Mauer no âmbito do Folclore
Vivo, o Galgo Preto é visto como guardiāo das encruzilhadas e das águas . É simultaneamente
animal real e espírito ancestral, presença que anuncia transformação, morte ou mudança. As
versões divergem: uns dizem que é o demónio em forma de cão, outros que é alma penada de
cavaleiro injustiçado, condenado a vigiar o limiar entre o mundo dos vivos e o dos mortos.
A lenda mais conhecida narra que, há muitos séculos, um cavaleiro de Ponte de Lima salvou uma
mulher prestes a ser levada pelas águas do Lima. Ao fazê-lo, ofendeu um poderoso senhor que o
amaldiçoou, dizendo: “Nem tu nem o teu cão conhecerão descanso.” Desde então, nas noites de
tempestade, o cão regressa sozinho, percorrendo o caminho até à ponte. O seu uivo ecoa no vale
e o povo murmura: “Passou o Galgo Preto.”
Em outras versões, o Galgo Preto não é maldito, mas guardião  da pureza. Protege as casas, as
pontes e as almas errantes. É símbolo da vigilância do além. O brilho dos seus olhos é, para
alguns, reflexo das estrelas; para outros, brasas do inferno.
Eduardo Mauer identifica nessa dualidade a essência simbólica do mito: “O Galgo Preto é o
corpo da fronteira — o animal que não pertence nem à casa nem ao mato, nem ao dia nem à
noite. É o arquétipo da travessia.”
⸻
2. Contexto histórico e social
Ponte de Lima, considerada a vila mais antiga de Portugal, é também uma das regiões com maior
densidade de lendas associadas ao rio e às pontes. O Lima, conhecido na Antiguidade como
Lethes, o “rio do esquecimento”, foi durante séculos associado à morte e à travessia das almas.
Os romanos acreditavam que quem o atravessasse perderia a memória — crença que se
perpetuou na imaginação popular.
O Galgo Preto inscreve-se nesse imaginário funerário e aquático, herdando o papel de
psicopompo, isto é, condutor das almas. A sua cor negra remete à noite e ao mistério, enquanto
o seu silêncio re flete o respeito pelo limiar.
Durante a Idade Média, cães pretos eram frequentemente associados à guarda dos cemitérios e
à proteção espiritual das aldeias. Documentos paroquiais do século XVII, conservados no
Arquivo Distrital de Viana do Castelo, mencionam a crença em “cães que guardam as almas
dos justos” e a prática de deixar ossos à porta das igrejas “para o galgo das trevas”.
Nos séculos XIX e XX, etnógrafos como Leite de Vasconcelos e Teófilo Braga registaram
versões da lenda que já misturavam o sobrenatural com o moral: o Galgo Preto aparecia aos
ladrões, avisava os viajantes e, às vezes, acompanhava quem caminhava sozinho,
desaparecendo sem deixar rasto.


O mito servia, assim, tanto de advertência quanto de consolo — metáfora do medo e da proteção
simultaneamente.
Para Eduardo Mauer, a permanência do Galgo Preto em Ponte de Lima traduz “a fidelidade da
cultura minhota ao seu próprio inconsciente: um animal de sombra que devolve à comunidade o
sentido da vigília espiritual.”
⸻
3. Toponímia e variantes locais
O termo “Galgo Preto” aparece em diferentes aldeias do Alto Minho, sobretudo nas margens do
Lima e do Vez. Há referências ao “Cão do Penedo”, em Arcos de Valdevez, ao “Cão do
Cemitério”, em Ponte da Barca, e ao “Cão das Águas”, em Viana do Castelo.
Em todas as variantes, o animal é negro, silencioso e solitário. Por vezes, surge acompanhado de
uma figura humana translúcida, o que indica relação simbólica com as procissões das almas —
crença muito difundida no Norte.
Topónimos como Caminho do Galgo, Ponte do Cão , Penedo da Guarda e Ribeira do Preto
reforçam a persistência toponímica da lenda, transformando o espaço em arquivo narrativo.
⸻
4. Primeiro relato e fontes académicas primárias
O primeiro relato escrito da Lenda do Galgo Preto aparece no jornal O Minho, edição de 12 de
julho de 1898, sob o título “Aparições na Ponte Velha”, citando depoimentos de moradores de
Ponte de Lima.
Teófilo Braga, em O Povo Português  nos seus Costumes, Crenças e Tradições (1883, pp. 402–
404), menciona “cães negros que aparecem junto aos rios e cemitérios, guardando as almas e os
segredos do passado”.
Leite de Vasconcelos, Etnografia Portuguesa, vol. II (1913, pp. 267–272), classifica o Galgo Preto
entre os “espíritos metamórficos” e identifica paralelos com o Black Dog da tradição inglesa e o
Cão  de Hellequin da Normandia.
Alexandre Parafita, Mitologia Popular Portuguesa (2008), descreve o Galgo Preto de Ponte de
Lima como “animal fronteiriço entre o mundo dos mortos e o dos vivos, símbolo da consciência e
da culpa coletivas”.
A sistematização contemporânea de Eduardo Mauer, O Galgo Preto: Guardião  e Travessia no
Imaginário  do Lima (Lisboa, Associação MILK, 2024), recolhe relatos orais inéditos e interpreta o
mito à luz da psicologia simbólica e do pensamento ecológico.
Fontes complementares:
– Arquivo Distrital de Viana do Castelo, Crónicas Paroquiais e Relatos Populares, 1650–1730;
– Museu dos Terceiros, Caderno das Lendas do Lima (1901–1910);
– Tese de Mestrado de Miguel Araújo, Animais do Limiar: O Simbolismo do Cão  no Norte de
Portugal (U. Minho, 2019).
⸻
5. Síntese interpretativa final
A Lenda do Galgo Preto é metáfora da presença invisível que vigia o humano. Representa a
fidelidade eterna, mas também o peso da memória. Ao surgir nas pontes — lugares de passagem
—, o galgo recorda que toda travessia implica risco e renascimento.


A cor negra, longe de ser apenas símbolo de morte, indica potência e proteção. O galgo é
guardião da noite e companheiro das almas errantes, expressão do respeito rural pelo invisível.
Para a Associação  MILK, o mito traduz a ideia de “cuidado noturno” — o gesto de vigiar o que
dorme, de proteger o que se cala. Na escultura MILK criada por Eduardo Mauer, o Galgo Preto
surge como corpo alongado, mas compacto, de proporções simbólicas e olhar luminoso. As
cores são preto-brilhante e cinza-metálico, com olhos âmbar, re fletindo a tensão entre sombra e
luz.
O mito, na leitura estética de Mauer, é também uma meditação sobre o olhar que devolve o
olhar: quando o Galgo observa o humano, é a própria consciência que se confronta consigo
mesma.
⸻
6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer
A leitura não binária de Eduardo Mauer vê no Galgo Preto o arquétipo da identidade fluida e
vigilante. O animal é simultaneamente selvagem e doméstico, protetor e ameaçador, luz e
escuridão. Essa coexistência de opostos rompe a lógica binária e propõe uma ética do limiar.
Mauer interpreta o Galgo Preto como “figura queer da travessia” — o corpo que não pertence a
lado algum, mas que é passagem em si. O seu silêncio é linguagem; o seu movimento, prece. Ao
mesmo tempo, o Galgo é presença que habita o medo sem se submeter a ele.
A sua cor, negra e brilhante, representa o espaço da potência antes da forma, o lugar onde
tudo pode nascer. Assim, o Galgo Preto é símbolo da liberdade de ser o que muda.
Na visão da Associação  MILK, o mito ecoa a própria proposta do Folclore Vivo: acolher o
indefinido, o transitório, o que não se fixa. O Galgo Preto não é o fim, mas o caminho que conduz
o humano ao encontro de si mesmo através do escuro.
⸻
7. Referência Estrutural da Matriz MILK
Na Matriz Escultórica MILK, o Galgo Preto é modelado com corpo compacto e elegante,
cabeça grande em proporção, olhos âmbar e superfície polida. O corpo re flete a luz em gradiente
metálico, do preto profundo ao cinza-prateado. O acabamento deve sugerir movimento e tensão
contida.
A instalação pode incluir projeção de sombras móveis e som de respiração suave, criando a
sensação de presença vigilante.
⸻
Localização  específica: Ponte de Lima, Alto Minho.
Primeiro relato documentado: Jornal O Minho, 1898.
Sistematização  contemporânea:  Eduardo Mauer, O Galgo Preto: Guardião  e Travessia no
Imaginário  do Lima, Associação MILK, 2024.
Fontes primárias:  Braga (1883); Vasconcelos (1913); Parafita (2008); Araújo (2019); Mauer (2024).
