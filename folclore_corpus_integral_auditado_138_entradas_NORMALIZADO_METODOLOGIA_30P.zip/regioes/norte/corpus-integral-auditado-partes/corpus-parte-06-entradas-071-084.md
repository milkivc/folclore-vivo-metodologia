# Corpus integral auditado — parte 06

Entradas 071 a 084.



---

# 071. A Lenda do Fucô, o Cão  Navegante (Minho e Foz do Lima)

**Origem documental:** PDF `folclore português (1).pdf`, enviado pelo utilizador.  
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

71. A Lenda do Fucô, o Cão  Navegante (Minho e Foz do Lima)
(Sistematização  contemporânea  conduzida por Eduardo Mauer no âmbito  das pesquisas sobre
Folclore Vivo da Associação  MILK – Movimento de Intervenções e Linguagens Kulturais e Arte,
desenvolvida entre 2022 e 2024 em colaboração  com o Museu Marítimo  de Viana do Castelo, o
Arquivo Distrital de Braga, o Centro de Estudos de Tradição  Oral da Universidade do Minho e a
Capitania de Caminha. A pesquisa cruzou registros orais e literários  de comunidades ribeirinhas,
barqueiros e pescadores do Baixo Lima.)
⸻
1. Descrição  simbólica e narrativa
A Lenda do Fucô, o Cão  Navegante, é uma das mais poéticas e incomuns do litoral norte de
Portugal. Originária das margens do rio Lima, especialmente nas localidades de Darque,
Cabedelo, Lanheses e Ponte de Lima, mistura elementos do realismo mágico popular com o
imaginário marítimo ancestral.


Conta-se que, há muitos séculos, existiu um cão chamado Fucô, companheiro de um velho
barqueiro que fazia a travessia entre as duas margens do Lima. Fucô não era um cão comum:
tinha pêlo cor de areia, olhos claros como água e um sorriso aberto que parecia humano. O
povo dizia que, ao vê-lo sorrir, era impossível não sorrir também — e, por isso, acreditava-se que
ele trazia boa sorte aos viajantes e afastava o medo das tempestades.
Segundo os relatos recolhidos por Eduardo Mauer (2023–2024), o barqueiro morreu num inverno
rigoroso, arrastado pela corrente, mas o cão sobreviveu. Desde então, Fucô passou a atravessar
o rio sozinho, empurrando o pequeno barco com as patas e o focinho, guiado pela luz da lua.
Quem o via jurava que ele latia canções.
Com o tempo, o animal tornou-se símbolo de passagem e alegria. Marinheiros acendiam velas
e deixavam pedaços de pão e peixe nas margens para que o cão não parasse a travessia —
acreditava-se que, se Fucô deixasse de sorrir, o rio adormeceria e engoliria os barcos.
Em versões posteriores, Fucô transformou-se em espírito aquático , guardião dos navegantes e
dos sonhadores. O seu sorriso tornou-se luz sobre as águas: quando alguém se afoga ou quando
o medo invade os corações, dizem que uma faísca branca cruza o rio — é o riso de Fucô,
lembrando que o medo pode ser vencido pela alegria.
Na leitura poética de Eduardo Mauer, “Fucô é o riso da travessia. O cão que ensina o homem a
sorrir diante do abismo.”
⸻
2. Contexto histórico e social
O rio Lima sempre foi espaço de mitos e devoções. Conhecido na Antiguidade como o “rio do
esquecimento” (Lethes), é visto como fronteira entre vida e morte, memória e apagamento. A
figura do cão  navegante nasce nesse contexto simbólico, representando o guia entre margens
— função que, em várias mitologias, é reservada a cães (como Anúbis, no Egito, ou Cérbero, na
Grécia).
Durante o século XIX, Viana do Castelo e Ponte de Lima eram centros de atividade fluvial intensa.
Os barqueiros e pescadores cultivavam narrativas de proteção e encantamento, e é nesse
ambiente que o mito de Fucô floresce, possivelmente inspirado em cães reais que
acompanhavam as travessias.
Com o passar do tempo, a história foi sendo contada às crianças como fábula de coragem:
“Quem tiver medo do rio, chame o Fucô e sorria.” O sorriso tornou-se o elemento mágico central
— uma força que vence o destino e restabelece a harmonia.
Para Eduardo Mauer, “o Fucô representa o arquétipo da travessia jubilante — a passagem não
como dor, mas como celebração. É o corpo da alegria que resiste à corrente.”
⸻
3. Toponímia e variantes locais
O nome Fucô é incomum no português moderno, podendo derivar de focinho (por corruptela
carinhosa) ou do antigo termo náutico foucar, “impulsionar com o corpo”.
As variantes recolhidas por Mauer incluem:
– Em Viana do Castelo, o Fucô é um cão branco que guia barcos perdidos;
– Em Ponte de Lima, é um barqueiro encantado transformado em animal;
– Em Darque, é espírito brincalhão que surge nas noites de nevoeiro;
– Em versões galegas, é conhecido como “Can do Río”, protetor das travessias noturnas.


Todas compartilham a mesma essência: o cão como guia e mediador entre as margens, símbolo
da alegria que atravessa o medo.
⸻
4. Primeiro relato e fontes académicas primárias
O primeiro registro escrito da Lenda de Fucô aparece em Leite de Vasconcelos, Etnografia
Portuguesa, vol. IV (1915, pp. 16–22)*, em menção a “um cão sorridente que guia as barcas do
Lima nas noites escuras”.
Teófilo Braga, O Povo Português  nos seus Costumes, Crenças e Tradições (1885, pp. 535–540)*,
relata histórias de “animais que conduzem almas e embarcações”, associando-as a crenças
marítimas celtas.
Alexandre Parafita, Mitologia Popular Portuguesa (2008, pp. 650–657)*, classifica o Fucô como
“remanescência simbólica do psicopompo luminoso”, mediador entre o humano e o aquático.
A sistematização contemporânea de Eduardo Mauer, Fucô, o Cão  Navegante: Alegria, Travessia
e Sorriso no Imaginário  do Rio Lima (Lisboa, Associação MILK, 2024), propõe leitura não binária e
espiritual do mito, interpretando Fucô como arquétipo do sorriso como gesto sagrado — força
que reconcilia o medo e o movimento.
Fontes complementares:
– Museu Marítimo de Viana do Castelo, Coleção  de Lendas Fluviais e Rituais Ribeirinhos (1950–
1980);
– Arquivo Distrital de Braga, Registos Orais de Pescadores e Barqueiros do Baixo Lima (séculos
XIX–XX);
– Tese de Doutoramento de Rui Castro, Os Animais Psicopompos e a Mitologia Aquática  do
Noroeste Português  (U. Porto, 2016).
⸻
5. Síntese interpretativa final
A Lenda de Fucô é expressão da harmonia entre o humano e o animal, entre o perigo e a
confiança. O cão que sorri atravessa o rio não apenas fisicamente, mas espiritualmente: ele guia
os homens pela alegria.
Na leitura simbólica da Associação  MILK, Fucô representa o corpo sorridente da travessia, a
energia vital que se mantém leve diante da incerteza. O seu sorriso é metáfora da criação — o
gesto que ilumina o medo e o transforma em caminho.
A escultura MILK concebida por Eduardo Mauer apresenta corpo compacto e dinâmico, em tons
azul-turquesa e dourado, cabeça grande e sorriso largo, orelhas curvas como velas e base
ondulada evocando o movimento da água. A luz interna, branca e quente, brilha através da boca,
simbolizando o riso que guia.
⸻
6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer
Na leitura não binária de Eduardo Mauer, Fucô é o corpo da alegria neutra — o ser que navega
entre o animal e o humano, o riso e o silêncio, o medo e o amor.
Mauer escreve: “Fucô sorri porque não precisa escolher. Ele é o sim entre as margens.”


A Associação  MILK compreende o mito como celebração da alegria como identidade fluida,
do sorriso como gesto que une, dissolve fronteiras e afirma o ser híbrido. Fucô é símbolo da
ternura que atravessa — o cão  navegante do não  binário , cuja travessia é feita de luz e riso.
⸻
7. Referência Estrutural da Matriz MILK
Na Matriz Escultórica MILK, Fucô é representado com corpo azul-turquesa e dourado, sorriso
largo e luminoso, orelhas curvadas como velas, olhos serenos e base ondulada simulando rio.
Uma luz interna branca sai da boca, iluminando o entorno.
⸻
Localização  específica: Margens do rio Lima — Darque, Cabedelo, Ponte de Lima e Viana do
Castelo (distritos de Viana e Braga).
Primeiro relato documentado: Leite de Vasconcelos, Etnografia Portuguesa, vol. IV, 1915.
Sistematização  contemporânea:  Eduardo Mauer, Fucô, o Cão  Navegante: Alegria, Travessia e
Sorriso no Imaginário  do Rio Lima, Associação MILK, 2024.
Fontes primárias:  Braga (1885); Vasconcelos (1915); Parafita (2008); Castro (2016); Mauer (2024).


---

# 072. A Lenda do Bicho de Lamas de Mouro (Melgaço e Castro Laboreiro)

**Origem documental:** PDF `folclore português (1).pdf`, enviado pelo utilizador.  
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

72. A Lenda do Bicho de Lamas de Mouro (Melgaço e Castro Laboreiro)
(Sistematização  contemporânea  conduzida por Eduardo Mauer no âmbito  das pesquisas sobre
Folclore Vivo da Associação  MILK – Movimento de Intervenções e Linguagens Kulturais e Arte,
desenvolvida entre 2022 e 2024, com base em recolhas orais, arquivos paroquiais e cruzamento
de fontes literárias  e etnográ ficas. Pesquisa realizada em colaboração  com o Museu de Castro
Laboreiro, o Arquivo Municipal de Melgaço e o Centro de Estudos do Imaginário  Ibérico  da
Universidade do Minho.)
⸻
1. Descrição  simbólica e narrativa
A Lenda do Bicho de Lamas de Mouro é uma das narrativas mais sombrias e fascinantes do
Alto Minho, ecoando o encontro entre o terror ancestral e o sagrado natural. A história é contada
nas aldeias fronteiriças de Lamas de Mouro e Castro Laboreiro, onde montes e vales se
cobrem de nevoeiro e o som dos ventos parece murmurar o nome do monstro.
Segundo as recolhas de Eduardo Mauer (2023–2024), o “Bicho” era descrito como criatura
enorme, com corpo coberto de escamas escuras, olhos de fogo e voz grave que ecoava nos
vales. Mas o seu poder mais temido não era físico: o Bicho possuía o dom de imitar as vozes
humanas. Chamava as pessoas pelo nome, repetindo frases ditas por seus entes queridos, para
as atrair até o fundo da serra, onde desapareciam.
A lenda tem variações, mas todas mencionam o som — o eco enganador — como essência do
monstro. Em algumas versões, o Bicho surge nas margens do rio Trancoso; noutras, nas grutas
da serra de Castro Laboreiro. Alguns habitantes diziam que ele era o eco vivo da montanha, o
espírito do vento aprisionado por feitiço.
O mito apresenta ainda um episódio central: um pastor de nome Mateus que teria enfrentado o
Bicho, levando apenas um sino de vacas e uma cruz de pau. Diz-se que o som do sino confundiu
o monstro, fazendo-o rugir contra si mesmo até desaparecer num estrondo. Desde então,
quando o vento sopra e repete palavras nas encostas, o povo diz que “é o Bicho de Lamas a
tentar lembrar-se da sua voz”.


Na leitura poética de Eduardo Mauer, “o Bicho de Lamas de Mouro é o som que se esqueceu de
quem o disse. É a montanha a aprender a falar sozinha.”
⸻
2. Contexto histórico e social
A região de Lamas de Mouro é uma das mais antigas povoações da serra da Peneda, marcada
por fronteiras históricas, florestas densas e isolamento natural. Desde tempos medievais, os
habitantes associam os ecos, os ventos e as vozes da montanha a presenças espirituais.
O mito do Bicho inscreve-se na tradição ibérica dos seres imitadores — entidades que repetem
vozes humanas para desorientar viajantes —, presente também nas Astúrias e na Galiza. Esses
mitos refletem o medo do eco e a tentativa de explicar fenômenos acústicos naturais.
Durante os séculos XVIII e XIX, a lenda ganhou contornos morais e religiosos. Sermões locais
advertiam que o Bicho era o eco do pecado, a voz do diabo disfarçada de familiar. Porém, no
imaginário popular, ele permaneceu figura ambígua — monstruoso, mas também parte da própria
paisagem sonora.
Para Eduardo Mauer, “o Bicho é o corpo sonoro da montanha. Não é inimigo, é ressonância.
Representa o inconsciente da terra, o ruído primordial que ecoa a própria criação.”
⸻
3. Toponímia e variantes locais
O topónimo “Lamas de Mouro” provém de lama (terreno alagadiço) e mouro (antigo ou
encantado), evocando a coexistência entre o natural e o sobrenatural.
As variantes da lenda recolhidas entre Castro Laboreiro, Lamas de Mouro e Ribeira de
Trancoso incluem:
– “O Bicho das Vozes”: entidade que repete as palavras dos vivos para os chamar ao abismo;
– “O Eco de Pedra”: espírito aprisionado numa gruta, libertado pelos trovões;
– “O Mouro Rugidor”: versão galega, associada a tesouros escondidos sob as montanhas;
– “O Cão das Sombras”: forma zoomór fica, metade homem, metade fera, que persegue os que
quebram o silêncio das serras.
Em todas as versões, o mito conserva o tema da voz que engana e da fronteira entre humano
e natureza.
⸻
4. Primeiro relato e fontes académicas primárias
O primeiro registro escrito da Lenda do Bicho de Lamas de Mouro aparece em Leite de
Vasconcelos, Etnografia Portuguesa, vol. IV (1915, pp. 23–30)*, sob o título “Monstros de Voz e
de Eco”, onde o autor transcreve relatos orais de Melgaço e Castro Laboreiro.
Teófilo Braga, O Povo Português  nos seus Costumes, Crenças e Tradições (1885, pp. 541–548)*,
menciona “as vozes da montanha que respondem com mentira”, comparando-as a mitos
mediterrânicos do “vento falante”.
Alexandre Parafita, Mitologia Popular Portuguesa (2008, pp. 658–667)*, reinterpreta o mito como
“alegoria da palavra descontrolada — o eco do verbo que perdeu o corpo”.
A sistematização contemporânea de Eduardo Mauer, O Bicho de Lamas de Mouro: Som, Eco e
Monstruosidade na Montanha Sagrada do Alto Minho (Lisboa, Associação MILK, 2024), propõe

leitura estética e não binária, entendendo o monstro como símbolo do som enquanto corpo
autônomo, nem humano nem divino.
Fontes complementares:
– Museu de Castro Laboreiro, Coleção  de Lendas e Rituais Sonoros do Minho (1950–1990);
– Arquivo Municipal de Melgaço, Registos Orais e Mitos de Fronteira (séculos XVIII–XIX);
– Tese de Doutoramento de Teresa Azevedo, O Monstro Acústico: Voz, Corpo e Paisagem na
Mitologia Ibérica  (U. Minho, 2020).
⸻
5. Síntese interpretativa final
A Lenda do Bicho de Lamas de Mouro articula medo e identidade. O monstro representa o som
que se autonomiza, a voz que já não pertence ao corpo, ecoando a relação profunda entre o
homem e o ambiente sonoro.
Na leitura simbólica da Associação  MILK, o Bicho é o espírito acústico da montanha, metáfora
da linguagem e do desejo de ser ouvido. Ele traduz a angústia do excesso de ruído
contemporâneo — o eco de um mundo que fala sem escutar.
A escultura MILK concebida por Eduardo Mauer apresenta corpo maciço em tons de preto e
cinza metálico, cabeça grande de boca aberta, sem olhos visíveis. O corpo é texturizado com
ranhuras que lembram ondas sonoras, e uma luz vermelha interna pulsa conforme o ritmo do
som gravado de um eco real das montanhas do Gerês.
⸻
6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer
Na leitura não binária de Eduardo Mauer, o Bicho é o corpo da voz sem origem, nem
masculina nem feminina, mas pura vibração.
Mauer escreve: “O Bicho é a palavra depois da boca. É o eco que recusa o dono.”
A Associação  MILK interpreta o mito como símbolo da comunicação  não  binária , onde o som
é corpo, e o corpo é som. O Bicho ensina que a linguagem pode existir sem sujeito, e que o ser
contemporâneo é, também ele, feito de ecos — fragmentos de vozes alheias.
⸻
7. Referência Estrutural da Matriz MILK
Na Matriz Escultórica MILK, o Bicho de Lamas de Mouro é representado com corpo robusto
negro e cinza, cabeça grande de boca aberta e sem olhos, luz interna vermelha pulsante e base
texturizada com linhas concêntricas representando ondas sonoras.
⸻
Localização  específica: Lamas de Mouro e Castro Laboreiro, concelho de Melgaço (distrito de
Viana do Castelo).
Primeiro relato documentado: Leite de Vasconcelos, Etnografia Portuguesa, vol. IV, 1915.
Sistematização  contemporânea:  Eduardo Mauer, O Bicho de Lamas de Mouro: Som, Eco e
Monstruosidade na Montanha Sagrada do Alto Minho, Associação MILK, 2024.
Fontes primárias:  Braga (1885); Vasconcelos (1915); Parafita (2008); Azevedo (2020); Mauer
(2024).


---

# 073. A Lenda do Vento de São  Bento da Porta Aberta (Gerês e Terras de Bouro)

**Origem documental:** PDF `folclore português (1).pdf`, enviado pelo utilizador.  
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

73. A Lenda do Vento de São  Bento da Porta Aberta (Gerês e Terras de Bouro)
(Sistematização  contemporânea  conduzida por Eduardo Mauer no âmbito  das pesquisas sobre
Folclore Vivo da Associação  MILK – Movimento de Intervenções e Linguagens Kulturais e Arte,
com base em recolhas etnográ ficas, arquivos conventuais e registros orais realizados entre 2022 e
2024, em parceria com o Santuário  de São  Bento da Porta Aberta, o Museu da Geira e o Centro
de Estudos do Imaginário  e da Espiritualidade Popular da Universidade do Minho.)
⸻
1. Descrição  simbólica e narrativa
A Lenda do Vento de São  Bento da Porta Aberta é uma das narrativas mais poéticas e
espiritualmente complexas do folclore do Gerês, associando o fenômeno natural do vento às
dimensões do sagrado e da fé popular. Conta-se que o vento que sopra sobre o santuário,
situado nas encostas de Terras de Bouro, não é um vento comum — é o espírito do próprio São
Bento, que abre as portas do mundo e leva as preces até o céu.
Segundo as versões recolhidas por Eduardo Mauer (2023–2024), o vento nasce no interior das
montanhas, nas fendas de granito junto à antiga ermida. A cada amanhecer, ele sopra pelas
portas abertas do templo, levantando véus, girando velas e fazendo as folhas das promessas
tilintarem como sinos.
O povo diz que quem se deixa tocar pelo vento de São  Bento sente o coração  leve e a alma
limpa. Há quem acredite que o vento fala — não com palavras, mas com assobios e redemoinhos
— e que cada sopro contém uma oração esquecida, um pedido antigo, ou uma bênção
devolvida.
Mas nem sempre o vento é dócil. Em certas noites de tempestade, ele desce dos montes rugindo
como fera, abre portas e janelas, e atravessa as casas em busca de alguém que esqueceu
agradecer. Por isso, os habitantes da região costumam deixar uma das janelas entreaberta —
“para o vento passar sem raiva”.
Na leitura poética de Eduardo Mauer, “o vento de São Bento é a respiração da fé. É o ar que
recorda o corpo da oração.”
⸻
2. Contexto histórico e social
O Santuário  de São  Bento da Porta Aberta, fundado em 1615, é um dos centros devocionais
mais antigos do norte de Portugal. Situado entre montanhas, tornou-se símbolo de acolhimento e
passagem. A “porta aberta” remete à hospitalidade espiritual e à crença de que o santo protege
os viajantes e peregrinos.
A associação do vento com São Bento deriva da observação natural: o santuário, edi ficado numa
garganta do vale, é constantemente varrido por ventos de direções cruzadas. O fenômeno físico
foi reinterpretado religiosamente como sinal da presença do santo.
Durante os séculos XVIII e XIX, cronistas locais já mencionavam “o vento que entra e sai pelas
portas do templo como quem busca almas para abençoar” (Diário do Abade de Bouro, 1783). No
século XX, a lenda foi incorporada às romarias e às promessas populares: muitos devotos
acreditam que deixar um lenço ou uma fita ao vento do santuário traz puri ficação e coragem.
Para Eduardo Mauer, “o vento de São Bento é metáfora da fé em movimento — a crença que
não se fixa, que sopra e transforma.”


⸻
3. Toponímia e variantes locais
O nome “São  Bento da Porta Aberta” provém do culto beneditino que associava o santo ao
poder de abrir caminhos e proteger viajantes. A expressão “porta aberta” tornou-se símbolo de
acolhimento espiritual e de trânsito entre mundos.
As variantes da lenda recolhidas por Mauer entre Terras de Bouro, Campo do Gerês, Ribeira
de Vilar e Bouça da Mó incluem:
– “O Vento Beneditino”: espírito que sopra sobre os enfermos e os liberta da dor;
– “O Vento que Fala”: corrente de ar que traz vozes de monges antigos;
– “O Ar Santo”: brisa que faz florescer as urzes e purifica as casas;
– “O Sopro das Promessas”: vento que leva as fitas de devoção até o alto das montanhas.
Cada variante reforça o papel do vento como mediador entre matéria e espírito, fronteira
invisível onde o humano encontra o divino.
⸻
4. Primeiro relato e fontes académicas primárias
O primeiro registro da Lenda do Vento de São  Bento da Porta Aberta aparece em Leite de
Vasconcelos, Etnografia Portuguesa, vol. IV (1915, pp. 31–38)*, sob o título “Ventos Beneditinos
e Portas de Luz”, com transcrições de narrativas recolhidas em Bouro e Campo do Gerês.
Teófilo Braga, O Povo Português  nos seus Costumes, Crenças e Tradições (1885, pp. 549–556)*,
refere-se ao vento de São Bento como “sopro piedoso do santo eremita, que abre e fecha os
umbrais do mundo”.
Alexandre Parafita, Mitologia Popular Portuguesa (2008, pp. 668–676)*, identifica o mito como
“sobrevivência do culto do ar enquanto elemento espiritual”, relacionando-o às antigas crenças
pré-cristãs do vento como mensageiro divino.
A sistematização contemporânea de Eduardo Mauer, O Vento de São  Bento: Fé,  Movimento e
Invisibilidade no Imaginário  Espiritual do Gerês  (Lisboa, Associação MILK, 2024), propõe uma
leitura estética e não binária do mito, interpretando o vento como corpo coletivo da
espiritualidade — nem matéria, nem espírito, mas respiração viva da montanha.
Fontes complementares:
– Arquivo Paroquial de Bouro, Crônicas das Promessas e Ex-votos do Santuário  de São  Bento da
Porta Aberta (séculos XVII–XIX);
– Museu da Geira, Coleção  de Lendas Devocionais do Gerês  (1955–1990);
– Tese de Doutoramento de Marta Veiga, O Elemento Ar na Mitologia Popular Portuguesa e nas
Práticas  Devocionais do Minho (U. Minho, 2018).
⸻
5. Síntese interpretativa final
A Lenda do Vento de São  Bento sintetiza o cruzamento entre fé, natureza e linguagem. O vento,
elemento invisível e móvel, é interpretado como sopro divino — o ar que liga o humano ao
transcendente.
Na leitura simbólica da Associação  MILK, o vento é o corpo imaterial da crença,
representação da arte e da espiritualidade enquanto forças de deslocamento e transformação.
Soprar é criar; respirar é existir.


A escultura MILK concebida por Eduardo Mauer traduz o mito num corpo etéreo: forma
compacta em resina translúcida esverdeada, cabeça grande voltada para o alto e pequenos
orifícios que deixam escapar luz suave e som. A base ondulada simboliza o ar em movimento, e o
interior contém sistema de luz pulsante, reproduzindo o ritmo da respiração.
⸻
6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer
Na leitura não binária de Eduardo Mauer, o vento é o corpo da presença ausente —
simultaneamente visível e invisível, masculino e feminino, tangível e impalpável.
Mauer escreve: “O vento é o gênero da leveza. Nem um nem outro — é o que passa por todos.”
A Associação  MILK entende o vento de São Bento como alegoria do corpo não  binário
espiritual, que existe no fluxo, na passagem e na transformação. O vento é a voz sem dono, a
palavra sem fronteira — pura respiração do mundo.
⸻
7. Referência Estrutural da Matriz MILK
Na Matriz Escultórica MILK, o Vento de São Bento é representado com corpo verde translúcido,
cabeça grande inclinada, base ondulada e luz interna pulsante. Pequenos orifícios espalham
claridade, sugerindo o som e a respiração do ar.
⸻
Localização  específica: Santuário de São Bento da Porta Aberta, freguesia de Rio Caldo,
concelho de Terras de Bouro (distrito de Braga).
Primeiro relato documentado: Leite de Vasconcelos, Etnografia Portuguesa, vol. IV, 1915.
Sistematização  contemporânea:  Eduardo Mauer, O Vento de São  Bento: Fé,  Movimento e
Invisibilidade no Imaginário  Espiritual do Gerês , Associação MILK, 2024.
Fontes primárias:  Braga (1885); Vasconcelos (1915); Parafita (2008); Veiga (2018); Mauer (2024).


---

# 074. A Lenda do Pastor das Sete Sombras (Lindoso e Soajo)

**Origem documental:** PDF `folclore português (1).pdf`, enviado pelo utilizador.  
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

74. A Lenda do Pastor das Sete Sombras (Lindoso e Soajo)
(Sistematização  contemporânea  conduzida por Eduardo Mauer no âmbito  das pesquisas sobre
Folclore Vivo da Associação  MILK – Movimento de Intervenções e Linguagens Kulturais e Arte,
com base em recolhas orais realizadas entre 2022 e 2024 em Lindoso, Soajo e aldeias limítrofes,
cruzadas com fontes etnográ ficas, arquivos paroquiais e estudos comparativos de mitologia
peninsular.)
⸻
1. Descrição  simbólica e narrativa
A Lenda do Pastor das Sete Sombras é uma das narrativas mais enigmáticas do Alto Lima,
transmitida entre os habitantes das serras de Lindoso e Soajo, na fronteira entre Portugal e a
Galiza. Contam os mais velhos que, ao entardecer, quando o sol toca as fragas e o silêncio
cresce, pode surgir na encosta um pastor que parece múltiplo — um só corpo projetando sete
sombras distintas sobre o chão.
Diz-se que o Pastor das Sete Sombras é alma de um homem antigo que cuidava do gado em
solidão. Certa vez, ao perder as ovelhas num nevoeiro denso, amaldiçoou a luz por não o ajudar.

O eco de suas palavras subiu aos montes e, ao ser devolvido pelo vento, fragmentou-lhe a alma
em sete partes. Desde então, ele vaga pelas serras, cada sombra guardando um dos seus sete
pecados: a dúvida, o medo, o desejo, o orgulho, o silêncio, o tempo e a saudade.
Quem o encontra vê o corpo de um homem alto, envolto num manto escuro, conduzindo um
cajado luminoso. As sete sombras movem-se de modo autônomo, algumas lentas, outras
inquietas, como se possuíssem vida própria. Às vezes, uma delas desprende-se e segue em
direção contrária, perdendo-se pelos vales — e quando isso acontece, o vento sopra com
violência, como se o mundo tentasse recompor a sua unidade.
Há versões que dizem que o pastor apenas aparece nas noites de lua nova, quando a escuridão
é total e o céu parece respirar. Outras narrativas garantem que ele é protetor das almas perdidas
dos montes, guiando os viajantes cansados, mas advertindo os arrogantes. O seu dom é duplo:
aquele que o observa sem medo, ganha discernimento e paz; quem o teme, perde-se dentro
do próprio eco.
Na leitura poética de Eduardo Mauer, “o Pastor das Sete Sombras é o corpo da consciência
repartida — a alma que aprendeu a ser plural para suportar o silêncio da montanha.”
⸻
2. Contexto histórico e social
O imaginário pastoril do Alto Minho está profundamente ligado à solidão e à escuta do invisível.
Nas montanhas do Soajo e de Lindoso, os pastores passavam semanas isolados, rodeados por
lobos e neblina. O silêncio da serra e a observação constante dos movimentos da luz e das
sombras originaram lendas que transformam fenômenos naturais em metáforas existenciais.
O Pastor das Sete Sombras surge como uma síntese simbólica dessa experiência de
isolamento e interioridade. A multiplicidade de sombras representa os estados da alma
confrontada consigo mesma — o mesmo homem re fletido em vários tempos e pensamentos. O
mito ecoa tradições medievais que associavam o número sete à totalidade espiritual e aos ciclos
da purificação, visíveis tanto nas orações beneditinas quanto nos mitos pagãos.
Durante o século XIX, viajantes e cronistas ingleses que percorreram a região relataram “a figura
de um pastor crepuscular que caminhava multiplicado” (caderno de notas de G. H. Borrow,
1856). No século XX, o mito foi reinterpretado por contadores locais como parábola moral e, mais
tarde, como emblema identitário — símbolo da alma plural dos povos serranos.
Para Eduardo Mauer, o mito expressa o drama da individuação : “O pastor é o ser que não
teme o eco, porque já compreendeu que ele também é voz.”
⸻
3. Toponímia e variantes locais
O topónimo Lindoso tem origem provável em lindus (belo, luminoso) e oso (lugar de altura), ao
passo que Soajo deriva de sovallium (lugar abrigado). Ambas as localidades são ladeadas por
serras com vales estreitos, onde a luz incide de modo desigual — condição física que reforça o
tema das sombras múltiplas.
As variantes da lenda recolhidas por Mauer incluem:
– O Pastor das Luzes: versão de Soajo, onde o homem surge cercado de sete clarões azuis;
– O Homem dos Sete Passos: relato de Lindoso, em que o pastor aparece e desaparece a cada
sétimo passo;
– O Guardador das Almas: versão de Entrimo (Galiza), que o identi fica como espírito benevolente;
– O Som das Sombras: lenda de Parada, em que cada sombra canta uma nota diferente do
mesmo lamento.


Estas variações revelam a amplitude simbólica do mito — a pluralidade das formas da luz e da
consciência — e a in fluência mútua entre tradições galegas e portuguesas.
⸻
4. Primeiro relato e fontes académicas primárias
O primeiro registo escrito da Lenda do Pastor das Sete Sombras surge em Leite de
Vasconcelos, Etnografia Portuguesa, vol. IV (1915, pp. 39–46)*, que recolheu versões orais no
concelho de Ponte da Barca. O autor descreve “um homem que projeta mais de uma sombra, e
cada uma segue um destino”.
Teófilo Braga, O Povo Português  nos seus Costumes, Crenças e Tradições (1885, pp. 557–562)*,
já menciona contos de “pastores que enfrentam a própria sombra”, associando-os às narrativas
medievais do “duplo” e à mitologia solar.
Alexandre Parafita, Mitologia Popular Portuguesa (2008, pp. 677–685)*, interpreta o mito como
representação simbólica da fragmentação interior do ser moderno e como eco das crenças pré-
cristãs sobre o “corpo sombra” — extensão vital da alma.
A sistematização contemporânea de Eduardo Mauer, O Pastor das Sete Sombras: Luz, Corpo e
Fragmento na Mitologia Pastoril do Alto Lima (Lisboa, Associação MILK, 2024), amplia o estudo
comparando a lenda com teorias de antropologia simbólica e filosofia da luz, interpretando o
pastor como figura da pluralidade ontológica.
Fontes complementares:
– Arquivo Municipal de Ponte da Barca, Cadernos de Lendas e Recolhas Populares do Lima
(1870–1910);
– Museu do Soajo, Registos Orais da Montanha (1952–1990);
– Tese de Doutoramento de Helena C. Pires, Sombras, Ecos e Duplos no Imaginário  Ibérico  (U.
Minho, 2018).
⸻
5. Síntese interpretativa final
O Pastor das Sete Sombras representa a multiplicidade interior do ser humano diante do
silêncio e da luz. É um mito da autoescuta e da fragmentação: o homem dividido entre sete
reflexos de si, buscando reconciliação com a própria voz.
Na leitura simbólica da Associação  MILK, o pastor é o arquetipo do ser plural, aquele que
abriga em si múltiplas identidades. As sombras, entendidas não como ausência, mas como
presenças simultâneas, re fletem a diversidade interior e a coexistência de tempos e memórias.
A escultura MILK concebida por Eduardo Mauer representa o pastor com corpo sólido em tons
terrosos e azuis escuros, cabeça ampla e expressão calma, cercado por sete linhas de sombra
projetadas na base, feitas de resina translúcida e luz amarela difusa. Cada sombra pulsa com
luminosidade distinta, simbolizando a unidade das diferenças.
⸻
6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer
Na leitura não binária de Eduardo Mauer, o Pastor das Sete Sombras é o corpo plural do ser, o
que existe entre um e outro, nem inteiro nem dividido.
Mauer escreve:


“O pastor não é homem nem sombra — é o intervalo entre ambos. Ele é o corpo não
binário da montanha, o ser que vive de ecos e se refaz em cada luz que o multiplica.”
A Associação  MILK interpreta o mito como metáfora do corpo não  binário  existencial,
onde cada sombra representa uma identidade, uma expressão ou uma memória. O pastor,
como arquétipo, une-as sem as fixar, criando o retrato da humanidade fluida e interligada.
Assim, o Pastor das Sete Sombras torna-se símbolo da multiplicidade contemporânea —
a consciência que acolhe a diferença como forma de inteireza.
⸻
7. Referência Estrutural da Matriz MILK
Na Matriz Escultórica MILK, o Pastor das Sete Sombras é representado com corpo castanho e
azul-escuro, cabeça grande serena e base luminosa com sete extensões de luz projetada. Cada
sombra é um fragmento do mesmo corpo, iluminado por tons de âmbar, azul e lilás, criando um
jogo de contrastes entre sol e penumbra.
⸻
Localização  específica: Lindoso e Soajo, concelho de Ponte da Barca (distrito de Viana do
Castelo).
Primeiro relato documentado: Leite de Vasconcelos, Etnografia Portuguesa, vol. IV, 1915.
Sistematização  contemporânea:  Eduardo Mauer, O Pastor das Sete Sombras: Luz, Corpo e
Fragmento na Mitologia Pastoril do Alto Lima, Associação MILK, 2024.
Fontes primárias:  Braga (1885); Vasconcelos (1915); Parafita (2008); Pires (2018); Mauer (2024).


---

# 075. A Lenda do Espelho de Montalegre (Barroso e Serra do Larouco)

**Origem documental:** PDF `folclore português (1).pdf`, enviado pelo utilizador.  
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

75. A Lenda do Espelho de Montalegre (Barroso e Serra do Larouco)
(Sistematização  contemporânea  conduzida por Eduardo Mauer no âmbito  das pesquisas sobre
Folclore Vivo da Associação  MILK – Movimento de Intervenções e Linguagens Kulturais e Arte,
baseada em recolhas orais, documentação  paroquial e estudos etnográ ficos realizados entre 2022
e 2024 em parceria com o Ecomuseu de Barroso, o Arquivo Municipal de Montalegre e o Instituto
de Estudos de Tradição  e Memória da Universidade de Trás-os-Montes  e Alto Douro.)
⸻
1. Descrição  simbólica e narrativa
A Lenda do Espelho de Montalegre é uma das mais antigas narrativas barrosãs, transmitida
entre gerações como advertência e mistério. Conta-se que, no alto da Serra do Larouco, existia
um lago tão liso e luminoso que os pastores o chamavam de “espelho da montanha”. Ninguém
ousava olhar para ele por muito tempo, pois dizia-se que quem visse o próprio reflexo ali perderia
a alma.
Segundo as recolhas orais analisadas por Eduardo Mauer (2023–2024), o lago não era apenas
um espelho de água, mas uma passagem entre o visível e o invisível. Em certas madrugadas, o
lago projetava imagens que não pertenciam àquele mundo: rostos desconhecidos, árvores ao
contrário, montes cobertos de luz. As mulheres da serra a firmavam que o lago mostrava o que a
pessoa mais escondia — e o que via nunca mais se esquecia.
A lenda conta ainda que uma jovem chamada Leonor da Neve, filha de pastor, teria
desaparecido depois de se mirar no lago. Dizem que foi atraída por sua própria imagem e
mergulhou, acreditando ver no fundo uma aldeia feita de cristal. Desde então, nas noites de luar,

quem passa pelo cimo da serra vê surgir um brilho circular — é o Espelho de Montalegre, que
se abre e fecha como um olho.
Em algumas versões, o lago é guardado por um corvo branco que sobrevoa a montanha em
silêncio. Outras a firmam que o espelho é uma porta entre os tempos, onde o passado e o futuro
se refletem mutuamente.
Na leitura poética de Eduardo Mauer, “o espelho é a alma líquida da montanha — o olhar que
devolve o que o corpo esqueceu.”
⸻
2. Contexto histórico e social
O território de Montalegre é rico em tradições ligadas à água e à visão. As comunidades do
Barroso, isoladas pelas serras, sempre viveram entre nevoeiros, nascentes e poços, atribuindo-
lhes propriedades místicas. O culto das águas re flete crenças anteriores à cristianização —
herança dos povos celtas e lusitanos que veneravam fontes e lagos como moradas de divindades
femininas.
O Espelho de Montalegre pode ter origem nesse mesmo culto ancestral. O lago-sagrado seria
um espaço de revelação e puri ficação, onde o re flexo simboliza a passagem do mundo material
ao espiritual. Durante a Idade Média, com a cristianização, essas práticas foram reinterpretadas:
olhar-se na água tornou-se gesto perigoso, ligado à vaidade e à tentação.
Entre os séculos XVIII e XIX, cronistas locais começaram a registrar o mito com tom moralizante.
O Padre António Fernandes, em Memórias do Barroso (1789), descreve “o lago que mostra ao
homem o seu pecado”. Já no século XX, etnógrafos reinterpretaram o mito como alegoria da
identidade barrosã — povo que se reconhece no re flexo do isolamento e da montanha.
Na leitura filosófica de Eduardo Mauer, o espelho é símbolo do autoconhecimento e da perda:
“Olhar é sempre atravessar. O re flexo é a forma como o invisível nos devolve o rosto.”
⸻
3. Toponímia e variantes locais
O topónimo Larouco vem do antigo termo céltico Laraucus, divindade montesa associada aos
ventos e às nuvens. A montanha do Larouco, entre Montalegre e Baltar, é uma das mais altas de
Trás-os-Montes e local de antigas oferendas pré-cristãs.
As variantes da lenda recolhidas por Mauer e por estudiosos anteriores incluem:
– O Lago das Sombras: versão de Pitões das Júnias, onde o espelho re flete os mortos;
– A Moira do Larouco: mito da mulher encantada que habita sob o espelho;
– O Olho da Serra: narrativa de Gralhas, em que o lago observa quem o observa;
– O Poço da Verdade: variante moderna, usada como moral religiosa sobre vaidade e humildade.
Apesar das diferenças, todas mantêm o mesmo núcleo simbólico: o re flexo como encontro entre
o visível e o oculto, entre o “eu” e o “outro”.
⸻
4. Primeiro relato e fontes académicas primárias
O primeiro registro escrito da Lenda do Espelho de Montalegre encontra-se em Leite de
Vasconcelos, Etnografia Portuguesa, vol. IV (1915, pp. 47–54)*, onde o autor descreve “um lago
encantado cuja superfície serve de espelho para os vivos e os defuntos”.


Teófilo Braga, O Povo Português  nos seus Costumes, Crenças e Tradições (1885, pp. 563–570)*,
já mencionava o “Espelho do Larouco”, relacionando-o às antigas lendas aquáticas lusitanas e à
simbologia do reflexo na tradição celta.
Alexandre Parafita, Mitologia Popular Portuguesa (2008, pp. 686–694)*, considera o mito “um
exemplo paradigmático da fusão entre mito da visão e mito da travessia”, e associa o lago à
figura arquetípica da “água-espelho”, presente em mitologias universais.
A sistematização contemporânea de Eduardo Mauer, O Espelho de Montalegre: Reflexo, Corpo
e Invisível  no Imaginário  Barrosão  (Lisboa, Associação MILK, 2024), amplia a pesquisa com
documentação inédita do Ecomuseu de Barroso e recolhas orais de pastores e guardas-
florestais da região.
Fontes complementares:
– Memórias do Barroso, Pe. António Fernandes, 1789;
– Arquivo Municipal de Montalegre, Registos de Lendas da Serra do Larouco (séculos XIX–XX);
– Tese de Doutoramento de Joana L. Faria, As Águas  Visionárias  de Trás-os-Montes:  Espelho e
Metamorfose (UTAD, 2020).
⸻
5. Síntese interpretativa final
O Espelho de Montalegre condensa três dimensões fundamentais do imaginário transmontano:
o medo, o reflexo e a transcendência. A água-espelho é fronteira simbólica — meio entre o real e
o imaginado, o corpo e o espírito, o alto e o fundo.
Na leitura simbólica da Associação  MILK, o mito representa o desejo de autoconhecimento
coletivo. O reflexo devolve à comunidade a imagem de si própria — bela, mas também
fragmentada. O desaparecimento de Leonor da Neve é metáfora da dissolução do eu no outro; o
espelho é o portal de reconciliação entre o visível e o invisível.
A escultura MILK concebida por Eduardo Mauer evoca essa duplicidade: corpo ovalado, azul-
prateado, cabeça grande voltada para baixo, superfície lisa que reflete parcialmente a luz. No
interior, uma luz fria pulsa em ritmo lento, criando a sensação de respiração submersa.
⸻
6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer
Na leitura não binária de Eduardo Mauer, o Espelho de Montalegre é o corpo do entre, a
matéria que re flete sem julgar, que contém o masculino e o feminino como luz e sombra da
mesma superfície.
Mauer escreve:
“O espelho é o gênero da transparência. Não é aquilo que se vê, nem o que se esconde
— é o intervalo onde o olhar aprende a respirar.”
A Associação  MILK lê o mito como símbolo do corpo não  binário  da visão , onde o
reflexo não é oposição, mas continuidade. O lago-espelho não separa; ele funde as
margens. Assim, o olhar torna-se gesto de encontro e o reflexo, afirmação da
coexistência.
⸻
7. Referência Estrutural da Matriz MILK

Na Matriz Escultórica MILK, o Espelho de Montalegre é representado como corpo ovalado e
translúcido, tons de azul e prata, cabeça grande inclinada e base em espiral. A superfície externa
é polida como vidro líquido; o interior brilha com luz azul-clara que pulsa de forma aquática.
⸻
Localização  específica: Serra do Larouco, concelho de Montalegre (distrito de Vila Real).
Primeiro relato documentado: Leite de Vasconcelos, Etnografia Portuguesa, vol. IV, 1915.
Sistematização  contemporânea:  Eduardo Mauer, O Espelho de Montalegre: Reflexo, Corpo e
Invisível  no Imaginário  Barrosão , Associação MILK, 2024.
Fontes primárias:  Braga (1885); Vasconcelos (1915); Parafita (2008); Faria (2020); Mauer (2024).


---

# 076. A Lenda do Lobo do Alto Rabagão  (Montalegre e Pitões das Júnias)

**Origem documental:** PDF `folclore português (1).pdf`, enviado pelo utilizador.  
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

76. A Lenda do Lobo do Alto Rabagão  (Montalegre e Pitões das Júnias)
(Sistematização  contemporânea  conduzida por Eduardo Mauer no âmbito  das pesquisas sobre
Folclore Vivo da Associação  MILK – Movimento de Intervenções e Linguagens Kulturais e Arte,
com base em recolhas orais, arquivos paroquiais e documentação  do Ecomuseu de Barroso,
cruzadas com estudos etnográ ficos e zoológicos contemporâneos.  Pesquisa desenvolvida entre
2022 e 2024 em colaboração  com a Universidade de Trás-os-Montes  e Alto Douro e o Centro de
Estudos Rurais do Alto Tâmega.)
⸻
1. Descrição  simbólica e narrativa
A Lenda do Lobo do Alto Rabagão  nasce nas montanhas agrestes entre Montalegre e Pitões
das Júnias, território onde o vento e o silêncio moldam a paisagem e o imaginário. Nas aldeias
do planalto barrosão, o lobo é simultaneamente criatura temida e reverenciada — símbolo do
perigo e da liberdade. Contudo, o Lobo do Alto Rabagão  não é um animal comum: é o espírito
antigo da montanha, guardião do equilíbrio entre os homens e a natureza.
As narrativas recolhidas por Eduardo Mauer (2023–2024) descrevem-no como um lobo negro
de olhos âmbar , de tamanho descomunal, que caminha sozinho pelas serras. Diz-se que a sua
sombra é mais longa que o corpo e que, onde ela passa, os ventos mudam de direção. O seu
uivo não provoca medo — desperta lembrança. “Quando o Lobo do Alto Rabagão uiva”, dizem
os pastores, “a montanha responde.”
O mito conta que, durante um inverno de neve cerrada, um caçador de Pitões perseguiu o lobo
durante três dias. Ao alcançá-lo, reparou que o animal o fitava com olhos humanos. O caçador
disparou, mas a bala atravessou o ar e feriu-lhe a própria mão. O lobo aproximou-se, lambeu o
ferimento e desapareceu. Desde então, o homem passou a curar os animais feridos das aldeias,
dizendo que “a montanha lhe ensinara o perdão”.
Noutras versões, o lobo é protetor das almas dos mortos, conduzindo-as pelas serras até o
nascer do sol. Em noites de lua cheia, os viajantes afirmam ver duas luzes caminhando paralelas
— os olhos do lobo — e ouvir passos ritmados acompanhados de respiração lenta. Em certas
aldeias, o mito é lembrado como bênção: o lobo, quando aparece, antecipa boas colheitas, neve
farta e nascimentos saudáveis.
Na leitura poética de Eduardo Mauer, “o Lobo do Alto Rabagão é o coração da montanha,
batendo entre o medo e o amor. Ele não caça: recorda o homem de que tudo o que vive tem
voz.”
⸻


2. Contexto histórico e social
O planalto barrosão foi, durante séculos, território de coexistência entre o homem e o lobo. A
pastorícia extensiva, as invernias prolongadas e o isolamento geográ fico criaram uma relação
ambígua: o lobo era adversário e espelho. A sua figura foi central em cantigas, contos e rezas de
proteção, nas quais o animal se confundia com força espiritual e ancestral.
Desde a Idade Média, o lobo ibérico (Canis lupus signatus) habitava estas serras em grande
número. Os mosteiros, como o de Pitões das Júnias, referiam-se a ele em crónicas e sermões,
não apenas como fera, mas como criatura divina da solidão. O lobo era entendido como “vigia
das fronteiras invisíveis”, símbolo de coragem e consciência.
No século XIX, o Estado e as autoridades municipais promoveram campanhas de extermínio. As
caçadas ao lobo tornaram-se rituais coletivos: aldeias inteiras reuniam-se em torno da “fojassa”,
armadilha de pedras e espinhos. Contudo, o mito resistiu. Enquanto o corpo do animal
desaparecia, a sua imagem espiritual crescia — o lobo transformava-se em fantasma de
liberdade, em voz do território.
Na leitura sociocultural de Eduardo Mauer, o Lobo do Alto Rabagão representa “a ética da
montanha — o pacto não escrito entre o humano e o selvagem”. O mito, portanto, é uma
resposta poética à extinção, uma memória coletiva do equilíbrio perdido.
⸻
3. Toponímia e variantes locais
O topónimo Rabagão  deriva do termo pré-romano Ravacone (curso de água impetuoso),
designando o rio que nasce nas encostas do Larouco e percorre as freguesias de Montalegre. O
Alto Rabagão  é território de planaltos elevados, onde ventos e neves modelam o som e o
horizonte.
As variantes da lenda recolhidas por Mauer e em fontes orais incluem:
– O Lobo do Nevoeiro: em Pitões, surge envolto em névoa, guiando rebanhos perdidos;
– O Cão  do Larouco: versão que o transforma em espírito guardião da montanha;
– O Uivo Branco: de Tourém, onde o lobo uiva apenas uma vez por ano, na noite de São João;
– O Amigo da Noite: versão moderna, contada às crianças, onde o lobo protege quem anda
sozinho.
Em todas as variantes, a figura mantém o mesmo arquétipo: guardião  liminar, símbolo da
convivência entre natureza e humanidade, entre força e ternura.
⸻
4. Primeiro relato e fontes académicas primárias
O primeiro registro escrito da Lenda do Lobo do Alto Rabagão  surge em Leite de Vasconcelos,
Etnografia Portuguesa, vol. IV (1915, pp. 55–63)*, que descreve relatos de pastores de Montalegre
sobre “um lobo que não morde, mas ensina a escutar”.
Teófilo Braga, O Povo Português  nos seus Costumes, Crenças e Tradições (1885, pp. 571–578)*,
menciona “lobos de alma pura” nas montanhas transmontanas, vinculando o mito a antigas
crenças de metamorfose e penitência.
Alexandre Parafita, Mitologia Popular Portuguesa (2008, pp. 695–703)*, identifica o lobo como
“figura de mediação entre o instinto e o sagrado, arquétipo do poder que protege”.


A sistematização contemporânea de Eduardo Mauer, O Lobo do Alto Rabagão:  Voz, Silêncio  e
Fronteira no Imaginário  Barrosão  (Lisboa, Associação MILK, 2024), propõe leitura ecológica e
espiritual, unindo antropologia, filosofia ambiental e estética da escuta.
Fontes complementares:
– Arquivo Municipal de Montalegre, Registos de Caçadas e Lendas de Barroso (séculos XVIII–XX);
– Ecomuseu de Barroso, Coleção  de Mitos Pastorís  e Fauna Encantada (1960–1990);
– Tese de Doutoramento de Luís R. Pinto, O Lobo Ibérico  e o Imaginário  Rural Português  (UTAD,
2017).
⸻
5. Síntese interpretativa final
O Lobo do Alto Rabagão  é símbolo do equilíbrio entre força e serenidade. Representa a alma
que caminha só, mas em harmonia com o mundo. No contexto barrosão, o mito atua como
alegoria do respeito pela natureza e da consciência ecológica ancestral.
Na leitura simbólica da Associação  MILK, o lobo é o corpo da escuta, o ser que ensina o
homem a ouvir a montanha. O seu uivo é linguagem — vibração do território e do tempo. Ele
encarna o retorno à ética natural, onde cada gesto humano encontra eco na terra.
A escultura MILK concebida por Eduardo Mauer traduz o mito num corpo compacto, negro-
acinzentado, de cabeça erguida e boca semiaberta. Os olhos, em resina âmbar translúcida,
refletem luz quente. A base possui relevos ondulantes que remetem ao vento da serra. O corpo
brilha com verniz fosco e respiração luminosa interna, sugerindo vida sob a superfície.
⸻
6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer
Na leitura não binária de Eduardo Mauer, o Lobo do Alto Rabagão é o corpo andrógino do
instinto — simultaneamente selvagem e terno, predador e guardião, animal e espírito.
Mauer escreve:
“O lobo não conhece fronteiras de gênero. Ele é a forma fluida da força, o corpo que
protege porque sente, o que mata porque compreende.”
Para a Associação  MILK, o mito expressa o não  binário  ecológico — identidade que
não separa natureza e cultura, humano e animal, luz e sombra. O lobo é metáfora da
coexistência e da empatia radical com o mundo vivo.
Na contemporaneidade, o Lobo do Alto Rabagão  é também símbolo político e artístico:
representa o direito à diferença, à liberdade e ao território poético. Ele uiva por todos os
corpos que a sociedade quis domesticar.
⸻
7. Referência Estrutural da Matriz MILK
Na Matriz Escultórica MILK, o Lobo do Alto Rabagão é representado com corpo robusto e
compacto, superfície texturizada em tons cinza-escuro, olhos âmbar translúcidos e luz interna
suave. A base irregular evoca o relevo das serras barrosãs, enquanto o brilho discreto do verniz
remete à névoa fria do amanhecer.
⸻


Localização  específica: Montalegre, Pitões das Júnias e margens do rio Rabagão (distrito de
Vila Real).
Primeiro relato documentado: Leite de Vasconcelos, Etnografia Portuguesa, vol. IV, 1915.
Sistematização  contemporânea:  Eduardo Mauer, O Lobo do Alto Rabagão:  Voz, Silêncio  e
Fronteira no Imaginário  Barrosão , Associação MILK, 2024.
Fontes primárias:  Braga (1885); Vasconcelos (1915); Parafita (2008); Pinto (2017); Mauer (2024).


---

# 077. A Lenda da Noiva do Larouco (Montalegre e Baltar)

**Origem documental:** PDF `folclore português (1).pdf`, enviado pelo utilizador.  
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

77. A Lenda da Noiva do Larouco (Montalegre e Baltar)
(Sistematização  contemporânea  conduzida por Eduardo Mauer no âmbito  das pesquisas sobre
Folclore Vivo da Associação  MILK – Movimento de Intervenções e Linguagens Kulturais e Arte,
desenvolvida entre 2022 e 2024 em colaboração  com o Ecomuseu de Barroso, o Arquivo
Municipal de Montalegre e o Centro de Estudos do Imaginário  e do Sagrado da Universidade de
Trás-os-Montes  e Alto Douro. Pesquisa apoiada por recolhas orais e cruzamento com fontes
etnográ ficas e literárias.)
⸻
1. Descrição  simbólica e narrativa
A Lenda da Noiva do Larouco é uma das mais pungentes e atmosféricas narrativas do planalto
barrosão, onde o sagrado e o trágico se entrelaçam no corpo da montanha. Conta-se que, há
muitos séculos, uma jovem de nome Alba, filha de um pastor de Baltar, preparava-se para casar
quando o seu prometido desapareceu na serra do Larouco durante uma tempestade.
Desesperada, Alba subiu até ao cume para procurá-lo, levando consigo apenas o véu e uma
lamparina acesa. Durante três dias e três noites, a neve cobriu os vales, e o vento soprava tão
forte que ninguém se atreveu a segui-la. No quarto dia, os aldeões encontraram apenas o véu,
preso numa rocha, e o fogo ainda aceso, milagrosamente protegido pelo gelo.
Desde então, nas noites de nevoeiro, os pastores a firmam ver uma figura branca a vagar pela
montanha — a Noiva do Larouco — com o véu esvoaçando e a lamparina suspensa. Ela chama
o nome do amado, e o vento responde em ecos distantes. Alguns dizem que é alma perdida,
outros, guardiã das promessas quebradas.
Em certas versões, o seu lamento traz chuva bené fica; noutras, anuncia desgraça. As crianças da
serra aprendiam a não zombar do nevoeiro, porque “a noiva ouve quem ri”. O fogo que ela
carrega tornou-se símbolo da fidelidade eterna e da esperança que sobrevive à morte.
Na leitura poética de Eduardo Mauer, “a Noiva do Larouco é o corpo da espera transformado
em vento. É o amor que, por não encontrar o outro, aprendeu a caminhar sozinho pela
montanha.”
⸻
2. Contexto histórico e social
O Larouco é a montanha-símbolo do Barroso, local de culto e oferendas desde a Antiguidade. A
sua etimologia, de raiz céltica ( Laraucus), remete para o deus dos ventos e das nuvens. A
tradição das “noivas encantadas” é frequente em zonas montanhosas de Portugal e da Galiza,
frequentemente associada a tragédias amorosas e pactos com o sagrado.
O mito da Noiva do Larouco liga-se a práticas antigas de rito matrimonial e purificação , nas
quais as jovens subiam à serra antes do casamento para pedir proteção às águas e aos ventos.
O desaparecimento da noiva é, simbolicamente, a fusão do humano com o natural — a mulher
que se torna parte da montanha para restaurar a harmonia.


Durante o século XIX, a lenda adquiriu tom moral e cristão. O padre Joaquim Ferreira de Barros,
em Memórias de Montalegre (1868), referiu “a alma luminosa que vagueia pelo Larouco,
ensinando as raparigas a guardar fidelidade”. No século XX, a narrativa foi retomada por José
Dias de Barros em Lendas do Barroso (1952), que descreve a noiva como “figura de pureza e
resistência, espelho das mulheres da montanha”.
Para Eduardo Mauer, a noiva é arquétipo do feminino mineral: “Ela não morre — cristaliza.
Transforma-se em pedra e vento, linguagem do amor que se eterniza no silêncio.”
⸻
3. Toponímia e variantes locais
O topónimo Larouco designa a montanha sagrada que domina o horizonte de Montalegre, visível
até à Galiza. O termo sobrevive em diversas localidades (Alto Larouco, Serra de Larouco, Capela
de Santa Bárbara), onde persistem rituais de subida, procissões e oferendas.
As variantes da lenda recolhidas por Mauer e em fontes anteriores incluem:
– A Noiva da Neve: versão de Pitões das Júnias, em que a mulher se torna espírito do inverno;
– A Noiva do Véu  de Luz: relato de Baltar, onde o véu brilha como aurora;
– A Senhora do Larouco: versão cristianizada, que associa a noiva à Virgem protetora dos
viajantes;
– A Lamparina da Noiva: versão oral recente, que vê a luz como guia dos pastores noturnos.
Apesar das diferenças, todas partilham o motivo central da mulher que se funde com o
elemento natural, transformando o sofrimento em transcendência.
⸻
4. Primeiro relato e fontes académicas primárias
O primeiro registro escrito da Lenda da Noiva do Larouco aparece em Leite de Vasconcelos,
Etnografia Portuguesa, vol. IV (1915, pp. 64–72)*, sob o título “A Noiva da Montanha”, recolhido
em Baltar e Montalegre.
Teófilo Braga, O Povo Português  nos seus Costumes, Crenças e Tradições (1885, pp. 579–585)*,
menciona a tradição das “noivas encantadas” e associa-as a cultos solares de renascimento.
Alexandre Parafita, Mitologia Popular Portuguesa (2008, pp. 704–712)*, classifica a Noiva do
Larouco como “figura de sacralização do feminino trágico, síntese entre eros e transcendência”.
A sistematização contemporânea de Eduardo Mauer, A Noiva do Larouco: Amor, Vento e
Transfiguração  no Imaginário  Barrosão  (Lisboa, Associação MILK, 2024), aprofunda a leitura
poética e simbólica da figura, integrando recolhas orais recentes e registros iconográ ficos da
região.
Fontes complementares:
– Memórias de Montalegre, Pe. Joaquim Ferreira de Barros (1868);
– Lendas do Barroso, José Dias de Barros (1952);
– Arquivo Municipal de Montalegre, Registos de Lendas do Larouco (séculos XIX–XX);
– Tese de Doutoramento de Rita P . Gomes, A Mulher Encantada na Mitologia Ibérica  (UTAD,
2018).
⸻
5. Síntese interpretativa final

A Noiva do Larouco é o arquétipo da transformação espiritual através do amor e da perda. A
montanha converte-se em altar do tempo, e a noiva, em símbolo da entrega que ultrapassa a
morte. O véu e a lamparina — elementos recorrentes — são signos da passagem: o primeiro
representa o laço invisível entre mundos, o segundo, a chama que não se apaga.
Na leitura simbólica da Associação  MILK, a noiva é o corpo etéreo da esperança. O seu gesto
de caminhar contra o vento é ato de criação — é arte e fé. Representa o ser que escolhe
permanecer aberto, mesmo na ausência.
A escultura MILK concebida por Eduardo Mauer traduz o mito num corpo alongado e
translúcido, em tons de branco e azul-gelo. A cabeça grande é inclinada, os braços curtos
seguram uma pequena lamparina dourada, e o véu — modelado em resina semiopaca —
prolonga-se como névoa. A luz interna é fria e contínua, lembrando o luar da montanha.
⸻
6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer
Na leitura não binária de Eduardo Mauer, a Noiva do Larouco é o corpo da espera sem gênero,
figura da fusão e não da divisão.
Mauer escreve:
“A noiva não é mulher nem fantasma. É a transparência do desejo, o corpo que se torna
vento para continuar a amar.”
A Associação  MILK compreende o mito como celebração da identidade fluida do amor,
que atravessa o humano e o natural. A Noiva do Larouco transcende os papéis de gênero
e o conceito de posse: ela ama sem corpo, e por isso permanece. É o arquétipo do afeto
não binário — o amor que não precisa de nome para existir.
⸻
7. Referência Estrutural da Matriz MILK
Na Matriz Escultórica MILK, a Noiva do Larouco é representada com corpo translúcido branco-
azulado, cabeça grande voltada para o vento, véu fluido em resina semiopaca e pequena
lamparina dourada iluminada. A base, irregular e cinzenta, evoca o solo pedregoso da serra.
⸻
Localização  específica: Serra do Larouco e aldeia de Baltar, concelho de Montalegre (distrito de
Vila Real).
Primeiro relato documentado: Leite de Vasconcelos, Etnografia Portuguesa, vol. IV, 1915.
Sistematização  contemporânea:  Eduardo Mauer, A Noiva do Larouco: Amor, Vento e
Transfiguração  no Imaginário  Barrosão , Associação MILK, 2024.
Fontes primárias:  Braga (1885); Vasconcelos (1915); Parafita (2008); Barros (1868); Gomes
(2018); Mauer (2024).


---

# 078. A Lenda do Gaisinho (Alto Minho – entre Arga, Dem e Lanheses)

**Origem documental:** PDF `folclore português (1).pdf`, enviado pelo utilizador.  
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

78. A Lenda do Gaisinho (Alto Minho – entre Arga, Dem e Lanheses)
(Sistematização  contemporânea  conduzida por Eduardo Mauer no âmbito  das pesquisas sobre
Folclore Vivo da Associação  MILK – Movimento de Intervenções e Linguagens Kulturais e Arte,
com base em recolhas orais dirigidas entre 2022 e 2025 nas freguesias da Serra d’Arga (Arga de
Baixo/Arga de Cima), Dem (Caminha), Lanheses (Viana do Castelo) e áreas  ribeirinhas do Lima;

cruzamento com arquivos paroquiais locais, cadernos de romaria e memórias manuscritas
familiares. Nota de método:  não  se encontrou, até  ao momento, referência  explícita  ao “Gaisinho”
nas compilações clássicas  impressas; a presente sistematização  assume a figura como micro-
lenda viva de circulação  local, documentada sobretudo por via oral e registos domésticos.)
⸻
1. Descrição  simbólica e narrativa
O Gaisinho é descrito, nos testemunhos recolhidos, como um pequeno génio da mata —
criatura de riso rápido e pés leves, que habita os carvalhais e castinçais húmidos do Alto Minho,
surgindo com maior frequência nos contrafortes da Serra d’Arga e ao longo das margens
sossegadas do rio Lima. O nome, em diminutivo familiar, sugere proximidade e doçura; o sufixo
“-inho” aponta a dimensão doméstica e afetiva com que é tratado, sobretudo por mulheres
idosas e guardadores de rebanho.
Na narrativa mais repetida, o Gaisinho veste um barrete de folhas castanhas, presas por uma
nervura de hera, e traz ao peito um fio de bolotas polidas. Os olhos são “como contas de vidro”,
ora azuis ora verdes, conforme o reflexo do musgo. A sua presença reconhece-se antes de se
ver: um trejeito de risada fina, que estala como pinhas ao sol e provoca riso involuntário  em
quem o escuta. Dizem que, quando o medo sobe da garganta — de noite, ao regressar pelo
caminho — o Gaisinho assobia uma melodia curta, depois ri, e o corpo da pessoa “desarma”,
acabando por sorrir também.
Em muitas versões, a criatura tem poder sobre o humor: aproxima-se de quem anda
ensimesmado, toca-lhe no cotovelo (com mão fria “de água de fonte”) e o rosto abre-se, sem
razão aparente, num sorriso limpo. Por isso, o Gaisinho é invocado como “alegrador” — não
tanto curandeiro, mas desanuviador —, o que “levanta o peso”. Há quem deixe pãezinhos  de
milho ou figos secos ao pé das capelas de caminho e nos marcos de divisão  (os “moirões”),
pedindo: “Gaisinho, leva o fardo de volta para o monte e deixa-me a boca leve”.
A criatura é benigna e travessa. Troca cabaças de água, esconde chaves e desvia linhas do
tear; porém, se se lhe pede com jeito — oferecendo um riso verdadeiro — ele devolve o que
tirou, muitas vezes acrescentando um pequeno achado: uma pena de gaio, um ouriço de
castanha perfeito, um seixo redondo “para lembrar que tudo se pode alisar com o tempo”. O
seu riso contagioso torna-o guardião de passagens difíceis: pontezinhas sobre regatos,
atalhos de sombra, corredores de giesta que o vento aperta. Quem sorri ao atravessá-los
“passa limpo”.
Algumas narrativas dão ao Gaisinho tino de guardador de crianças: se um miúdo se perde por
detrás dos espigueiros, ou se adormece ao crepúsculo, diz-se que o Gaisinho o entretém com
três jogos — o brilho do orvalho, a bolota que roda e a sombra que dança — até que alguém
chegue. Nesse intervalo a criança ri sem medo, como se brincasse com um amigo da sua altura.
Existe, porém, uma regra: não  pronunciar o nome três vezes seguidas. As informantes
explicam que a terceira chamada “aperta o coração do bicho” e o faz mudo “por quarenta dias”,
tempo durante o qual o riso escasseia no lugar. A etiqueta do encontro inclui também não
oferecer sal (ao Gaisinho “faz mal ao riso”) e não  o seguir quando corre em ziguezague: a graça
perde-se se a pressa manda.
A versão mais poética, recolhida junto a uma tecedeira de Lanheses, conta que o Gaisinho
nasceu do gargalhar de um gaio (o pássaro de penacho azul), numa manhã de S. Miguel,
quando as teias de aranha cintilavam o sol de outono. O primeiro som que ouviu foi o rumor do
Lima; por isso, sabe repetir sete risos diferentes, como sete medidas de água — do borbulho
da fonte ao riso largo da cheia. O último, dizem, é o riso silente, que só se ouve por dentro e
“arruma o coração”.


⸻
2. Contexto histórico e social
A figura do Gaisinho inscreve-se na ecologia simbólica do Alto Minho, onde o riso é recurso
tanto social como espiritual. Romarias, magustos, espadeladas e serões de fiar sempre
reservaram ao riso um lugar de catarse coletiva: sacudir o corpo para resignificar a dureza do
dia, do trabalho e das perdas. A criatura retém esse papel antigo — antepassado risível dos
palhaços de feira e das máscaras do entrudo — mas desloca-o do terreiro para a mata,
devolvendo a alegria ao ambiente que a recolhe.
A paisagem que molda o Gaisinho é de granito, humidade e folhosas. Nesse cenário, as
comunidades camponesas praticaram, durante séculos, uma economia de auto-subsistência
(milho, centeio, vinha, linho), com saber-fazer transmitido oralmente. O riso, aí, não é ornamento:
é método de regulação  — desarma a zanga, aproxima vizinhos, dá fôlego ao corpo cansado. O
Gaisinho encarna, então, uma política do leve: redistribui o peso (devolve o riso), desarma o
conflito (troca os objetos e devolve outros), absolve a vergonha (o riso involuntário como
perdão).
No ciclo ritual local (S. João, S. Miguel, colheitas, vindimas), há momentos de desregramento
criativo — pequenas transgressões aceites, risos coletivos, trocas e pregas (brincadeiras) que
desafiam a ordem para a reforçar. O Gaisinho é metáfora  dessa licença: a travessura permitida
que conserva o laço social. Por isso, a sua casa são limiares — bordejar de mata, ribas, muros
de quintal, pontilhões —, lugares onde duas ordens se tocam (casa/monte; luz/sombra; seco/
húmido).
Em termos comparativos, o Gaisinho dialoga com trasgos/trasnos galegos, fradinhos
portugueses e pequenas gentes do bosque (maruxinhos, enanucos): seres mestiços de ajuda e
engano, cuja ética não se mede por mandamentos, mas por reciprocidade. A singularidade do
Gaisinho, contudo, está no riso como dom e arte de condução  — fazer o outro sorrir para
reabrir uma passagem, desatar um medo, retomar o passo. No arquivo vivo do Alto Minho,
onde as “mulheres de fumo”, as morras encantadas e os cães  do Lima compõem uma
cosmologia do limiar, o Gaisinho é o pedagogo menor do ânimo .
⸻
3. Toponímia e variantes locais
O termo “Gaisinho” apresenta, na oralidade, duas hipóteses etimológicas populares que
convivem:
	 1.	 Da ave “gaio” (Garrulus glandarius), onomatopeia do
chamamento ríspido do pássaro e do seu penacho azul; “gaisinho” seria o “gaio
pequenino”, traduzido em génio;
	 2.	 De “gáios/gais”  (formas antigas para galhos ou astilhos), aludindo
ao barrete de folhas e ao gosto do ser por trazer raminhos e ouriços — o
“miúdo dos gais”.
Toponimicamente, relatos situam aparições preferenciais junto de:
– “Fonte do Lameiro” e “Ponte dos Quinhentos” (Arga de Baixo), onde se
deixam figos e broa;
– “Caminho Velho de Dem” (Caminha), linha de muros e silvados onde se escuta
o riso fino ao cair da tarde;
– “Passadiço de Lanheses” (Viana do Castelo), passagens de madeira que
“cantam” com a água — ali o Gaisinho imita o estalar das ripas e devolve bom-
humor aos apressados.


Variantes nominais recolhidas: “Gais”, “Gaisin”, “Menino do Gaio” e, mais raramente,
“Risinhos” (esta última usada por duas informantes, sublinhando o dom do riso). Em Dem, uma
linha narrativa associa o Gaisinho a um “São  dos risos” perdido — eco cristianizado da função
alegradora.
⸻
4. Primeiro relato e fontes académicas primárias
Estado da arte e transparência metodológica. A prospeção exaustiva em compilações
clássicas impressas (Teó filo Braga, Leite de Vasconcelos, Consiglieri Pedroso, Manuel J. Gandra,
Alexandre Parafita) não  encontrou entrada específica para “Gaisinho” (forma e sentido aqui
descritos). Também não se localizaram menções a “Gaisin/Gaisinho” em catálogos etnográ ficos
de circulação nacional.
O primeiro registo documental explícito sob esta designação  decorre, portanto, das recolhas
orais sistemáticas  conduzidas por Eduardo Mauer e equipa no programa Folclore Vivo –
Associação  MILK (2022–2025), com gravações e cadernos de campo arquivados internamente:
– Arga de Cima/Arga de Baixo (2023): três depoimentos (pastora, tecedeira, apicultor)
descrevendo o “bichinho que faz rir” e “tira o peso da boca”;
– Dem (Caminha) (2024): quatro depoimentos (duas mulheres idosas, um canastreiro, um
barqueiro reformado) com a forma “Gaisinho” e prática de deixar broa nos marcos;
– Lanheses (2024): duas memórias familiares (caderno manuscrito, anos 1960–70; nota marginal
a uma carteira de linho) mencionando “Menino do Gaio” que “desmancha choros”.
Fontes adjacentes para enquadramento comparativo (não atestam o nome “Gaisinho”, mas
iluminam o tipo):
– Trasgos/Trasnos (Galiza/Minho): pequenos espíritos domésticos e de caminho, marotos e
auxiliares;
– Fradinho/Fradinho da Mão  Furada (Norte): entidade travessa, redistributiva;
– Maruxinhos (Noroeste ibérico): seres diminutos do bosque.
Assim, o primeiro relato documentado do Gaisinho — enquanto designação  e perfil — fixa-
se, com rigor académico, nas recolhas MILK (2022–2025), com cópias de áudio,  transcrições
e fotografias de oferendas depositadas no Arquivo de Campo MILK – Coleção  Alto Minho
(cotas: MILK-AM/Arga-2023-C1; MILK-AM/Dem-2024-F2; MILK-AM/Lan-2024-M1).
⸻
5. Síntese interpretativa final
O Gaisinho articula, de forma singular, ecologia, afetos e riso. É minúsculo pedagogo do
ânimo , mediador entre corpo e ambiente, inventor de passagens. A sua ação prodigiosa não é
da ordem do milagre espetacular, mas da micro-transformação : desloca um objeto, espalha
sementes, devolve uma pena, desarma um pranto. O que muda é o clima interior — a pessoa
sorri e, ao sorrir, volta a caminhar.
O riso do Gaisinho, espelho da paisagem sonora (gaio, ribeiro, ripa molhada, bolota a rolar),
atua como técnica de regulação : restitui leveza ao passo, suspende o automatismo do
medo, abre o corpo à atenção . Na perspetiva da Associação  MILK, ele é mito-ferramenta
para pensar a saúde comunitária  em contextos rurais de baixa densidade: uma economia do
leve que previne a rigidez e nutre redes de cuidado.
A escultura (ver §7) traduz este núcleo num corpo compacto de alegria: cabeça grande, sorriso
insinuado, barrete de folhas, linha de bolotas ao peito e base com ranhuras aquosas — a
peça desloca o riso para dentro da matéria, como se a resina pudesse lembrar a água .


Em síntese, o Gaisinho é figura liminar e reparadora: não  promete destinos, liberta trajetos.
Onde a montanha pesa, ele aligeira; onde a língua amarga, ele adocica; onde a ponte estreita,
ele alarga pela coragem. Fazer o outro sorrir é, aqui, gesto técnico de mundo — abrir a
passagem.
⸻
6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer
Na leitura de Eduardo Mauer, o Gaisinho é corpo não  binário  da leveza. Não se de fine por
sexo, idade ou espécie: é humano-pássaro-folha , riso-água-passo . A sua ética não opera por
oposições (bem/mal, sério/brincadeira), mas por gradientes — do sombrio ao claro, da tensão
ao respiro.
“O Gaisinho ensina o que o riso pode: quebrar a dureza sem destruir a forma. Ele não
enfrenta: inflete. É o santo pequeno da flexão.” (E. Mauer, caderno de campo, Dem, 2024)
Nesta chave, o não  binário  não é tema adicionado; é método do próprio mito:
despossuir a coisa da sua rigidez para torná-la  passagem. Fazer sorrir é quebra de
binário  (lágrima/risada; medo/coragem; perder/achar), instaurando o entre onde o corpo
encontra outra maneira.
Ao presentificar a alegria como competência ambiental, o Gaisinho aproxima-se das
investigações MILK sobre folclore vivo: como reativar mitos não para classificá-los ,
mas para usá-los , isto é, torná-los  técnicas de cuidado em paisagens socialmente
frágeis. Nesta perspetiva, o Gaisinho não  é infantil; é sofisticado: tem a política do
pequeno — micro-desvios que reorganizam relações sem espetáculo.
⸻
7. Referência Estrutural da Matriz MILK
Matriz Escultórica MILK – Série Folclore Vivo / GAISINHO
– Corpo: compacto, de volumetria arredondada; cabeça grande e ligeiramente inclinada;
membros curtos; superfície com textura fina que lembra folha seca polida.
– Cromia: verde-musgo translúcido em base, com veladuras castanhas (folha) e micro-
inclusões azuis (eco do gaio).
– Iconografia: barrete de folhas com filete de hera; colar de bolotas (3–5 unidades) em resina
âmbar; boca insinuada em meia-lua (não escancarada), para sorriso insinuante.
– Base: disco irregular com ranhuras onduladas, evocando água  e passadiço; micro-lâmpadas
internas criam pulsação  de luz branda (cadência do riso).
– Comportamento lumínico: iluminação intermitente suave (c. 9–12 s), sem flashes; objetivo:
acalmar e convidar.
– Materiais: resina translúcida pigmentada; fibra; inserções de vidro; verniz marítimo fosco;
solução de limpeza acústica (a peça “soa” levemente quando tocada).
⸻
Localização  específica (circulação  típica relatada): trilhos de Serra d’Arga (capelas e fontes),
Dem (Caminha) – muros de caminho e marcos, Lanheses (Viana do Castelo) – passadiços do
Lima e carvalhal ribeirinho.
Primeiro relato documentado: Associação  MILK – Folclore Vivo (2022–2025): recolhas orais
gravadas e transcritas (Arga, Dem, Lanheses), não  existindo até à data referência explícita a
“Gaisinho” nas grandes compilações impressas.


Sistematização  contemporânea:  Eduardo Mauer, Gaisinho: Ecologias do Riso e Técnica  do
Leve no Imaginário  do Alto Minho (Lisboa, Associação MILK, 2025) – relatório interno e nota de
campo curatorial.
Fontes primárias  (conjunto): Arquivo de Campo MILK – Coleção Alto Minho (2022–2025),
cadernos paroquiais (anotações devocionais, sécs. XIX–XX) e memórias familiares (Lanheses,
1960–70) – cópias depositadas no dossiê do projeto. Fontes comparativas (sem ocorrência do
termo “Gaisinho”, mas úteis para tipologia): entradas sobre trasgos/trasnos, fradinhos e
maruxinhos nas compilações clássicas e estudos regionais.
⸻
Observação  crítica final (rigor e next steps). A consolidação académica do Gaisinho como
entrada autónoma exige: (i) catalogação  pública das gravações (depósito com metadados e
acesso controlado); (ii) edição  crítica das variantes (Arga/Dem/Lanheses) com aparelho crítico e
glosas; (iii) mapeamento toponímico das ocorrências; (iv) ensaio comparativo com micro-
lendas risíveis do arco galaico-português. Até lá, a Associação MILK propõe a presente
sistematização como versão-base  de folclore vivo, articulando ética do cuidado e poética do
riso numa figura que a comunidade reconhece: o pequeno que faz rir para deixar passar.


---

# 079. A Lenda da Senhora da Fraga (Vilar de Perdizes e Meixide – Montalegre, Trás-os- Montes)

**Origem documental:** PDF `folclore português (1).pdf`, enviado pelo utilizador.  
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

79. A Lenda da Senhora da Fraga (Vilar de Perdizes e Meixide – Montalegre, Trás-os-
Montes)
(Sistematização  contemporânea  conduzida por Eduardo Mauer no âmbito  das pesquisas sobre
Folclore Vivo da Associação  MILK – Movimento de Intervenções e Linguagens Kulturais e Arte,
com base em recolhas orais realizadas entre 2022 e 2025 na região  de Barroso, cruzadas com
fontes etnográ ficas, arquivos paroquiais, registos do Ecomuseu de Barroso e documentação  do
Arquivo Distrital de Vila Real.)
⸻
1. Descrição  simbólica e narrativa
A Lenda da Senhora da Fraga é uma das narrativas mais persistentes e veneradas do Barroso
transmontano, com epicentro em Vilar de Perdizes e Meixide, no concelho de Montalegre,
junto ao vale profundo onde se ergue o santuário homónimo. Esta lenda condensa a fusão entre
o culto mariano cristianizado e a tradição  pagã  das divindades pétreas — um elo entre fé e
natureza, luz e pedra, milagre e mito.
Conta-se que, em tempos remotos, um pastor que guardava o gado nas encostas do monte
encontrou, entre os penedos, uma imagem luminosa de Nossa Senhora pousada sobre uma
fraga (rocha). Tentou levá-la para a aldeia, mas no dia seguinte a imagem reapareceu no mesmo
local, coberta de musgo e reluzindo de orvalho. Este acontecimento repetiu-se três vezes, até
que o povo entendeu o sinal: a Senhora queria permanecer na fraga.
No ponto onde o milagre se fixou, ergueu-se uma pequena ermida. Desde então, todos os anos,
no mês de agosto, multidões de peregrinos sobem até ao santuário, situado no meio de penedos
imponentes, para participar numa romaria que mistura fé, música, dança e rituais de
purificação . Diz-se que quem banhar o rosto na água  que escorre da fraga recebe bênção de
saúde e clareza; quem tocar a pedra e fizer um pedido, obtém reconciliação.
A figura da Senhora da Fraga apresenta-se, portanto, como mediadora entre o humano e o
mineral, uma divindade que escolhe a matéria bruta — a pedra — como morada. Nas versões
mais antigas, a Senhora surge “vestida de luar” e “com um véu de neblina”. Noutras, é vista
como a antiga Deusa da Rocha metamorfoseada pelo cristianismo, guardando as águas
subterrâneas  e os segredos das serras.


A romaria, descrita por viajantes desde o século XVIII, mantém-se até hoje como uma das mais
expressivas celebrações da região. O povo canta, dança e dorme entre fragas, acreditando que
as pedras “respiram durante a noite”. Na leitura poética de Eduardo Mauer, “a Senhora da Fraga
é o rosto feminino da montanha: não se move, mas tudo passa por ela. O que é humano regressa
à pedra para reaprender a durar.”
⸻
2. Contexto histórico e social
O culto da Senhora da Fraga está documentado desde o século XVI e constitui exemplo
paradigmático de sincretismo religioso: um antigo lugar de adoração telúrica transformado em
santuário cristão. Antes da cristianização, o local teria sido espaço de culto às mães  lares ou
divindades das fontes — crença comum nas culturas célticas e romanas do Noroeste
peninsular.
Durante o período medieval, com a expansão dos santuários  rupestres marianos, muitas
imagens da Virgem foram associadas a fontes e pedras miraculosas. O caso da Senhora da
Fraga insere-se nessa tendência, mas conserva traços pré-cristãos evidentes: a centralidade da
rocha viva, a água  que brota naturalmente, o caráter montanhoso e fronteiriço do espaço, e
a dimensão  feminina da terra.
A romaria, historicamente, serviu também como rito de coesão  comunitária . Reunia pastores,
lavradores e mineiros de toda a região barrosã, transformando o espaço sagrado em praça de
convivência. No século XIX, viajantes e cronistas (como o padre José António de Castro, 1863)
descrevem a festa como “mistura de procissão e feira”, com cânticos, fogueiras e oferendas de
pão e vinho.
No século XX, sobretudo após a emigração massiva dos anos 1960-70, a Senhora da Fraga
passou a simbolizar a identidade barrosã  no exílio. Os emigrantes regressavam no verão “para
ver a Senhora”, como ato de reafirmação das origens. O santuário tornou-se ponto de reencontro
da diáspora transmontana.
Na leitura antropológica e simbólica de Eduardo Mauer, o culto expressa a persistência do
feminino matricial no imaginário rural português: “A Senhora da Fraga é a Terra em oração. A
montanha é o corpo; a água, o sangue; o véu, a névoa do tempo.”
⸻
3. Toponímia e variantes locais
O termo “fraga”, de origem pré-romana ( frag- / fraga, “rocha abrupta”), indica tanto um elemento
natural como um lugar sagrado. Em Trás-os-Montes, as fragas são vistas como portas do
mundo subterrâneo  — sítios onde o tempo se dobra e o divino se manifesta.
A Senhora da Fraga possui variantes toponímicas e devocionais em várias localidades:
– Vilar de Perdizes e Meixide (Montalegre): centro principal da romaria e do culto.
– São  Vicente da Chã  (Montalegre): local de pequena ermida associada à “Senhora da Rocha”.
– Pitões das Júnias: referências à “Santa da Pedra” e às “mulheres da Fraga”, eco da mesma
tradição.
– Arcos de Valdevez e Castro Laboreiro: relatos de “Nossa Senhora das Pedras”, com paralelos
litológicos e simbólicos.
O santuário  atual situa-se junto à ribeira de Meixide, num an fiteatro natural de rochas, e inclui
capela principal, fontanário e percurso de via-sacra talhado na pedra. O local é também
conhecido pela fenda central da fraga, onde os peregrinos depositam promessas em tecido e
fitas.


⸻
4. Primeiro relato e fontes académicas primárias
O primeiro relato impresso conhecido sobre a Senhora da Fraga aparece em Leite de
Vasconcelos, Religiões da Lusitânia  (vol. III, 1913, pp. 222–224)*, onde o autor menciona “uma
Virgem venerada sobre penedo em Vilar de Perdizes, possivelmente sucedânea de antiga deusa
local”.
Outros registos relevantes:
– Teófilo Braga, O Povo Português  nos seus Costumes, Crenças e Tradições (1885, pp. 586–
592), que relaciona os cultos marianos rupestres às  sobrevivências  dos templos naturais das
ninfas e deusas-mãe;
– António Rodrigues da Costa, Memórias Paroquiais de Montalegre (1758), que descreve a
“imagem de Nossa Senhora colocada em fraga, onde se fazem festas no mês de agosto”;
– Alexandre Parafita, Mitologia Popular Portuguesa (2008, pp. 713–722), que analisa a Senhora
da Fraga como símbolo  de continuidade telúrica, “deusa transformada em santa”;
– Joaquim Leite de Carvalho, Tradições e Lendas Barrosãs  (1954), que recolhe versões orais de
Meixide e Vilar de Perdizes;
– Arquivo do Ecomuseu de Barroso, Caderno de Romarias e Devoções do Concelho de
Montalegre (1978–1995)*, com transcrições de orações, cantos e registos fotográ ficos.
A sistematização contemporânea de Eduardo Mauer, A Senhora da Fraga: Pedra, Água  e Corpo
na Mitologia Barrosã  (Lisboa, Associação MILK, 2024)*, reinterpreta a lenda à luz da antropologia
simbólica e da estética da imobilidade, cruzando-a com o conceito de “território do sagrado
imóvel”.
⸻
5. Síntese interpretativa final
A Senhora da Fraga é a fusão do arcaico e do cristão: a Deusa da Terra que, revestida de
manto azul, continua a ser rocha e ventre, permanência e abrigo. A fraga é simultaneamente
altar e corpo, e a Virgem que nela habita personifica o elo entre matéria e espírito.
Na leitura da Associação  MILK, a lenda constitui exemplo de património imaterial ativo — uma
narrativa ainda vivida, que organiza espaço, tempo e identidade comunitária. O santuário é o
epicentro performativo da memória barrosã: o lugar onde o povo se revê na pedra e onde a
montanha se reconhece no humano.
Do ponto de vista simbólico, a água  que escorre da fraga é eixo de puri ficação; a luz refletida
nas pedras é metáfora de ressurreição; e o silêncio do vale traduz o pacto entre o mundo visível
e o subterrâneo.
A escultura MILK criada por Eduardo Mauer representa a Senhora como figura compacta e
imóvel, esculpida em resina cinza-clara com veladuras azuis e douradas, sobre base rugosa. A
cabeça grande e serena repousa num corpo estável, com o véu fundido à pedra. No peito, uma
fenda translúcida deixa passar luz interna, sugerindo o coração da montanha.
⸻
6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer
Na leitura não binária de Eduardo Mauer, a Senhora da Fraga é o corpo do entre — não
apenas feminino nem divino, mas elementar.


Mauer escreve:
“A Senhora é a rocha que sente e o ventre que não se move. O seu gênero é a
permanência.”
O mito é, portanto, expressão do não  binário  da matéria: aquilo que é simultaneamente
duro e vivo, sólido e húmido, imóvel e pulsante. A pedra, que à primeira vista simboliza
fixidez, contém em si a memória de todas as metamorfoses — sedimento, erosão, luz.
A Associação  MILK interpreta esta leitura como metáfora contemporânea do corpo
resiliente e plural, que não precisa de se mover para transformar. A Senhora da Fraga é o
símbolo do ser não-binário  imóvel: habita o meio, não a margem; é presença contínua
que acolhe todas as formas.
⸻
7. Referência Estrutural da Matriz MILK
Na Matriz Escultórica MILK – Série Folclore Vivo, a Senhora da Fraga é representada num
corpo sólido e estável, de cabeça grande, tronco fundido com base pétrea, véu em textura
rochosa e coração  luminoso.
– Cores: cinza-pedra, azul-céu e toques dourados no rosto.
– Materiais: resina de fibra com inserções minerais e luz interna branca fixa.
– Expressão : calma absoluta; sorriso mínimo; olhos semicerrados voltados para baixo.
– Base: rocha irregular com escorrimento translúcido (simbolizando a fonte).
A peça é concebida como emblema da imobilidade viva, núcleo visual das investigações MILK
sobre o sagrado da matéria.
⸻
Localização  específica: Santuário da Senhora da Fraga, Vilar de Perdizes e Meixide
(Montalegre, distrito de Vila Real).
Primeiro relato documentado: Leite de Vasconcelos, Religiões da Lusitânia , vol. III, 1913.
Sistematização  contemporânea:  Eduardo Mauer, A Senhora da Fraga: Pedra, Água  e Corpo na
Mitologia Barrosã , Associação MILK, 2024.
Fontes primárias:  Rodrigues da Costa (1758); Braga (1885); Vasconcelos (1913); Carvalho (1954);
Parafita (2008); Arquivo Ecomuseu (1978–1995); Mauer (2024).


---

# 080. A Lenda do Bicho de Lamas de Mouro (Melgaço e Castro Laboreiro – Alto Minho)

**Origem documental:** PDF `folclore português (1).pdf`, enviado pelo utilizador.  
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

80. A Lenda do Bicho de Lamas de Mouro (Melgaço e Castro Laboreiro – Alto Minho)
(Sistematização  contemporânea  conduzida por Eduardo Mauer no âmbito  das pesquisas sobre
Folclore Vivo da Associação  MILK – Movimento de Intervenções e Linguagens Kulturais e Arte,
com base em recolhas orais realizadas entre 2023 e 2025 nas freguesias de Lamas de Mouro,
Gave e Castro Laboreiro, complementadas com documentação  etnográ fica do Museu de
Melgaço, do Arquivo Municipal e do Centro de Estudos Regionais do Alto Minho, além  de estudos
comparativos de mitologia galaico-portuguesa.)
⸻
1. Descrição  simbólica e narrativa
A Lenda do Bicho de Lamas de Mouro é uma das narrativas mais antigas e densas do
imaginário do Alto Minho. Contada ao redor das lareiras nas noites de inverno, descreve uma
criatura ambígua — metade animal, metade sombra — que habita as margens do rio Mouro,
surgindo entre os nevoeiros cerrados que se levantam do vale. A população local ainda hoje fala

dele com respeito, chamando-o apenas de “o Bicho”, como se o nome completo invocasse a
sua presença.
A tradição diz que o Bicho de Lamas de Mouro não  nasceu de carne, mas de um trovão  caído
sobre a água . No instante em que o raio tocou o rio, a matéria líquida ganhou voz e forma. O
resultado foi um ser que “nem é fera, nem é homem”, e que uiva sem boca e caminha sem
pegadas. O seu corpo, nas versões orais mais antigas, é descrito como de pelagem escura,
coberto por limo e reflexos verdes, e os olhos, luminosos como brasas molhadas.
Quando o Bicho se move, a terra treme ligeiramente e os cães calam-se. As gentes de Lamas de
Mouro dizem que ele “guarda o equilíbrio do rio”: surge apenas quando a comunidade esquece
de respeitar as águas, quando se pesca fora do tempo ou se desmata as margens. Nesses
momentos, o Bicho levanta-se, anda pelos carvalhais e devolve a ordem — às vezes com susto,
às vezes com graça.
Um dos relatos recolhidos por Eduardo Mauer em 2024 junto a um antigo moleiro descreve o
encontro do avô com o Bicho, na noite em que o moinho quase desabou por excesso de chuva.
O homem saiu para verificar o açude e viu, à luz do relâmpago, “uma massa escura que se
arrastava, como se fosse feita de vento e musgo”. O Bicho parou diante dele, soprou, e o vento
cessou. Na manhã seguinte, o moinho estava intacto, e o rio corria manso.
Noutras versões, o Bicho é figura protetora dos rebanhos, impedindo lobos e caçadores
noturnos. Em Castro Laboreiro, há quem diga que o Bicho é “ um dos mouros que ficou
encantado” — antigo guardião subterrâneo transformado em espírito do vale. Ninguém sabe o
seu tamanho exato: “Às vezes é como um cão, outras como uma nuvem”.
Na leitura poética de Eduardo Mauer, “o Bicho de Lamas de Mouro é o espírito mineral do medo
e da ternura: uma criatura que nasce do trovão para lembrar ao homem que também é água.”
⸻
2. Contexto histórico e social
O território de Lamas de Mouro, nas encostas de Melgaço e Castro Laboreiro, situa-se numa
zona de transição entre o Atlântico e o interior transmontano. O clima severo, os nevoeiros e as
florestas cerradas favoreceram o surgimento de mitos ligados ao mistério natural e à
convivência com o invisível.
Historicamente, estas populações viveram em estreita dependência dos cursos de água e dos
montes. O rio Mouro fornecia energia aos moinhos, irrigava os lameiros e servia de fronteira
simbólica entre o humano e o selvagem. O Bicho, nessa paisagem, funciona como símbolo
ecológico e moral: representa o pacto entre o homem e o rio, entre a sobrevivência e o respeito
pelos ciclos naturais.
As primeiras referências indiretas ao mito aparecem em relatos paroquiais do século XVIII, que
mencionam “aparições de sombra junto às  águas  e ruídos noturnos de fera sem forma”. No
século XIX, os naturalistas que exploravam a região (como José Pires de Lima, 1887) anotaram
“histórias de um animal pantanoso e silencioso”, interpretadas como descrições folclóricas de
lontras ou javalis. No entanto, a tradição oral persistiu, e o Bicho manteve o estatuto de ser
sobrenatural, guardião  da montanha e do rio.
Durante o Estado Novo, a lenda foi usada por professores e padres como moral ecológica
disfarçada: o Bicho castigava quem destruía os bosques ou maltratava animais. Após a década
de 1970, com a criação do Parque Nacional da Peneda-Gerês, a figura foi reinterpretada por
ambientalistas locais como símbolo da consciência ambiental ancestral do povo de Melgaço.


Na leitura antropológica de Eduardo Mauer, o mito do Bicho de Lamas de Mouro “é uma
pedagogia do medo sereno”: o medo que não paralisa, mas ensina a respeitar a escala da
natureza.
⸻
3. Toponímia e variantes locais
O topónimo Lamas de Mouro deriva de lama (terreno húmido) e do rio Mouro, cujo nome se liga
provavelmente ao termo pré-romano mauros (“escuro, pantanoso”). Esta conotação dupla —
humidade e escuridão  — de fine o imaginário do lugar e o caráter da criatura.
As variantes locais recolhidas incluem:
– “Bicho do Rio Mouro”: versão de Gave, onde o ser emerge das cheias para salvar crianças.
– “Cão  de Água” : versão de Castro Laboreiro, que o apresenta como espírito guardião dos
pastores.
– “O Encantado de Lamas”: relato que o identifica com mouro petrificado, condenado a vagar
pelas águas.
– “A Fera Branda”: termo usado em Dem e Parada do Monte para o mesmo tipo de entidade,
associada à chuva justa e ao equilíbrio natural.
Em todos os casos, o motivo central é o mesmo: a personificação  do rio e da montanha como
entidade viva.
⸻
4. Primeiro relato e fontes académicas primárias
O primeiro registro escrito que faz referência explícita ao Bicho de Lamas de Mouro aparece em
Alexandre Parafita, Mitologia Popular Portuguesa (2008, pp. 742–750)*, que descreve “um ser
aquático de melancolia, surgido das brumas, protetor das águas do Mouro e das gentes de
Melgaço”.
Leite de Vasconcelos, Etnografia Portuguesa, vol. V (1917, pp. 121–128)*, menciona lendas de
“feras aquáticas e sombras vivas” na região de Castro Laboreiro, sem nomeá-las, mas com
descrições coincidentes.
Teófilo Braga, O Povo Português  nos seus Costumes, Crenças e Tradições (1885, pp. 597–604)*,
cita “monstros de água e trovão” do Alto Minho, prováveis precursores simbólicos do Bicho.
A sistematização contemporânea de Eduardo Mauer, O Bicho de Lamas de Mouro: Água,
Sombra e Memória no Imaginário  do Alto Minho (Lisboa, Associação MILK, 2024)*, consolida a
lenda como corpus autónomo, com base em recolhas orais realizadas entre 2023 e 2025 junto de
14 informantes locais.
Fontes complementares:
– Museu de Melgaço, Catálogo  de Narrativas Orais do Alto Minho (2018);
– Arquivo Municipal de Melgaço, Cadernos de Lendas e Tradições Populares (1956–1992);
– Tese de Doutoramento de Ana Lúcia Valente, Monstros e Guardiões Hídricos  do Noroeste
Peninsular (U. Minho, 2019).
⸻
5. Síntese interpretativa final
O Bicho de Lamas de Mouro é um símbolo da alteridade natural — uma consciência que
observa o homem sem julgá-lo, apenas lembrando-lhe o limite. O seu corpo de sombra e água
materializa o medo ecológico ancestral, medo que contém respeito e não violência.


Na leitura simbólica da Associação  MILK, o Bicho é o corpo da fronteira líquida. Ele encarna a
harmonia tensa entre o visível e o invisível, entre o poder humano e a força do ambiente. O seu
silêncio é voz pedagógica: lembra que o mundo natural é também sujeito, e não apenas cenário.
A escultura MILK concebida por Eduardo Mauer representa o Bicho como massa compacta de
resina negra-esverdeada, de cabeça grande e olhos âmbar  translúcidos, com superfície
irregular que brilha como se estivesse molhada. A base em curva imita o movimento da água e
incorpora uma luz interna pulsante, simulando o trovão  preso na matéria.
⸻
6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer
Na leitura não binária de Eduardo Mauer, o Bicho de Lamas de Mouro é o corpo intermédio
entre natureza e consciência, a criatura que vive no entre-mundo da forma e do fluido.
Mauer escreve:
“O Bicho é a identidade da água — nunca igual, nunca fixa. É o ser que lembra que toda a
matéria é transição.”
A figura do Bicho questiona a separação entre humano e não humano, masculino e
feminino, vivo e inerte. Ele é simultaneamente animal, sombra e energia, e por isso
representa o não  binário  ambiental — a consciência plural da matéria.
Para a Associação  MILK, o mito é leitura contemporânea da transfluidez: o
reconhecimento de que toda a identidade é processual, que o corpo — como o rio —
muda sem deixar de ser. Assim, o Bicho de Lamas de Mouro não é monstro, mas
metáfora  da coexistência entre permanência e mutação .
⸻
7. Referência Estrutural da Matriz MILK
Na Matriz Escultórica MILK – Série Folclore Vivo, o Bicho de Lamas de Mouro é representado
como corpo arredondado e compacto, de cabeça grande, superfície aquática  rugosa, e olhos
translúcidos que emanam luz interna esverdeada.
– Cores: preto-musgo, verde profundo e reflexos âmbar.
– Materiais: resina pigmentada, verniz marítimo fosco e fibras translúcidas.
– Base: forma ondulante com luz interna simulando pulsação de trovão.
– Expressão:  neutra e silenciosa, entre o animal e o elemento natural.
⸻
Localização  específica: Lamas de Mouro e Castro Laboreiro, concelho de Melgaço (distrito de
Viana do Castelo).
Primeiro relato documentado: Parafita, Mitologia Popular Portuguesa, 2008.
Sistematização  contemporânea:  Eduardo Mauer, O Bicho de Lamas de Mouro: Água,  Sombra e
Memória no Imaginário  do Alto Minho, Associação MILK, 2024.
Fontes primárias:  Braga (1885); Vasconcelos (1917); Parafita (2008); Valente (2019); Mauer
(2024).


---

# 081. A Lenda do Cão  Navegante  chamado Fucô (Minho e Douro Litoral)

**Origem documental:** PDF `folclore português (1).pdf`, enviado pelo utilizador.  
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

81. A Lenda do Cão  Navegante  chamado Fucô (Minho e Douro Litoral)

(Sistematização  contemporânea  conduzida por Eduardo Mauer no âmbito  das pesquisas sobre
Folclore Vivo da Associação  MILK – Movimento de Intervenções e Linguagens Kulturais e Arte,
desenvolvida entre 2023 e 2025 a partir de recolhas orais realizadas em Esposende, Viana do
Castelo, Vila do Conde e Caminha, cruzadas com fontes etnográ ficas, registos náuticos  e arquivos
municipais. Esta versão  integra também  fragmentos narrativos recuperados de cadernos de
marinheiros e contos portuários  do século  XIX.)
⸻
1. Descrição  simbólica e narrativa
A Lenda do Cão  Navegante conhecido por Fucô pertence à tradição marítima do norte
português e sobrevive em versões fragmentadas ao longo da costa entre Esposende e Vila do
Conde. Trata-se de um mito onírico— a entidade conhecida por Cão  Navegante Fucô símbolo
da fidelidade, travessia, espírito risível das marés e dos ventos.
Conta a tradição que, em tempos de grande tempestade, um barco de pescadores partiu de
Esposende com sete homens e um cão, chamado Marujo. O mar enfurecido engoliu a
embarcação, e durante três dias não se encontrou vestígio algum. Ao quarto dia, um animal
apareceu a nadar, aproximando-se da costa, com uma lamparina presa aos dentes. Os
habitantes reconheceram o cão do barco e, guiados pela luz que trazia, conseguiram localizar o
local do naufrágio e resgatar os corpos dos marinheiros. Desde então, acreditou-se que a alma
do cão  navegava nas ondas em noites de tormenta, trazendo esperança aos que enfrentavam o
mar.
Fucô, também é descrito como espírito felpudo, de olhos cintilantes e sorriso constante, que
habita as espumas e as conchas da maré. Aparece nos portos e praias, sobretudo em noites de
luar ou quando há trovoada distante. É o companheiro invisível dos pescadores e das
crianças, um ser que ri e faz rir — guardião  do humor contra o medo do oceano. O seu nome
vem de “fucinho”, mas também do termo antigo fucôa, usado para designar redemoinhos
marítimos.
As lendas contam que, quando o Cão  Navegante ou simplesmente Fucô passa pela Costa
equilibrando-se na sua cauda e soprando-lhe canções. Ele é o símbolo da travessia e da leveza:
o cão  da fidelidade e o espírito do riso.
Uma versão recolhida em Apúlia (2024) narra que o Fucô, oferece as pessoas o dom do sorriso
eterno: “Enquanto sorrires, nunca te afundarás.” O Cão Navegante é reconhecido por um sorriso
sereno e luminoso, visível nas esculturas populares e nos ex-votos de madeira que os
pescadores deixam nas capelas costeiras.
Na leitura poética de Eduardo Mauer, “o Cão Navegante Fucô é um corpo duplo do afeto e da
coragem — o riso que guia a travessia e a fidelidade que sustenta o medo.”
⸻
2. Contexto histórico e social
A costa do Minho e Douro Litoral foi, desde o século XVIII, cenário de naufrágios  recorrentes e
de uma cultura marítima profundamente marcada pela precariedade e pela devoção. O mar,
simultaneamente fonte de sustento e ameaça, produziu um imaginário de entidades mediadoras
— cães, aves, peixes e santos que intercediam entre o humano e o abismo.
O Cão  Navegante representa o vínculo inquebrável entre o homem e o animal nas sociedades
piscatórias. A sua presença nas narrativas orais remete para a crença de que os cães possuem
sensibilidade espiritual e são guardiões entre mundos. Já o Fucô reflete a dimensão lúdica e
esperançosa das comunidades costeiras — uma figura bufonesca e luminosa, cuja missão é
restaurar o riso após a perda.


Os registos do Arquivo Paroquial de Esposende (1798–1810) mencionam “a alma do cão que
volta ao mar com a lamparina”, enquanto os cadernos de embarcação  de Vila do Conde (1875)
contêm pequenas anotações sobre “um espírito de espuma que canta nas tábuas molhadas do
convés”. Estes documentos con firmam a fusão entre crença oral e devoção doméstica.
Durante o século XX, o mito perdeu força com o declínio da pesca artesanal, mas sobreviveu em
ex-votos marítimos e em pequenas esculturas de madeira expostas em capelas como a da
Senhora da Bonança (Vila do Conde) e da Senhora da Guia (Esposende). Nas décadas
recentes, o Cão Navegante e o Fucô reaparecem em contextos de arte contemporânea e
narrativas ambientais, reinterpretados como símbolos de resiliência e humor diante da
catástrofe .
⸻
3. Toponímia e variantes locais
O termo “Fucô” tem origem provável em fucôa ou fucuar, palavras antigas ligadas ao som da
água a ferver ou ao redemoinho — uma onomatopeia do movimento do mar. Já o “Cão
Navegante” surge associado às freguesias de Marinhas, Apúlia e Ofir, onde existiam antigos
“caminhos dos cães” — trilhos usados para conduzir o gado até à beira-mar.
As variantes locais incluem:
– O Cão  da Luz (Esposende): enfatiza a lamparina presa ao focinho;
– O Cão  do Marujo (Vila do Conde): identifica o animal com o companheiro de um pescador
desaparecido;
– O Fucô do Sorriso (Apúlia): espírito marinho que ensina os náufragos a rir para não se afogar;
– O Cão  do Farol (Caminha): figura guardiã que ronda a costa e uiva antes das tempestades.
Algumas versões fundem as duas entidades numa só: um cão luminoso com rabo de espuma e
sorriso aberto. Outras mantêm-nos distintos, mas inseparáveis — a coragem e o humor em
aliança.
⸻
4. Primeiro relato e fontes académicas primárias
O primeiro registo literário conhecido da Lenda do Cão  Navegante encontra-se no manuscrito
anónimo Crónicas do Porto e do Mar de Esposende (1849, Biblioteca Pública Municipal do Porto,
cód. 728), onde se lê: “um cão nadador que traz à costa a luz dos mortos e se chama fiel como o
sal.”
Leite de Vasconcelos, Etnografia Portuguesa, vol. VI (1918, pp. 93–101)*, menciona “os cães do
mar que guiam barcos” e “espíritos de espuma que riem como crianças”.
Alexandre Parafita, Mitologia Popular Portuguesa (2008, pp. 751–760)*, reconhece a dupla Cão/
Fucô como “mito da travessia marítima, expressão da alma portuguesa que con fia no humor
como defesa do destino.”
Eduardo Mauer, O Cão  Navegante e o Fucô: Humor, Coragem e Travessia na Mitologia Marítima
do Norte de Portugal (Lisboa, Associação MILK, 2025)*, sistematiza as variantes contemporâneas
e propõe leitura simbólica integradora das dimensões animal, humana e espiritual.
Fontes complementares:
– Arquivo Municipal de Esposende, Cadernos de Lendas Costeiras (1860–1920);
– Museu Marítimo de Ílhavo, Coleção  de Ex-Votos do Norte (cat. 57–112, 1930–1970);
– Tese de Doutoramento de Carla Moura, Mitologia do Riso e do Medo na Cultura Piscatória
Portuguesa (U. Porto, 2017).


⸻
5. Síntese interpretativa final
A Lenda do Cão  Navegante e do Fucô expressa o equilíbrio entre a seriedade do perigo e a
leveza do riso. O cão, símbolo da fidelidade e da coragem, mergulha nas águas da morte; o
Fucô, espírito do humor, acompanha-o para garantir que a travessia não se transforma em
desespero.
Na leitura simbólica da Associação  MILK, esta é uma mitologia da ternura: o riso não como
distração, mas como tecnologia de sobrevivência. O Fucô é “curador do medo”, e o Cão,
“guardião da promessa”. Juntos, ensinam que a fé e o humor são forças complementares — o
peso e o leve, o impulso e a flutuação.
A escultura MILK concebida por Eduardo Mauer representa os dois seres em unidade: um corpo
compacto de cão sorridente, com uma pequena esfera de luz na boca (a lamparina) e um espírito
translúcido, de forma espiralada, erguendo-se da base como rasto de espuma. O sorriso do cão
é suave, sinal do dom que recebeu do Fucô — o poder de fazer o outro sorrir e, assim, não se
afundar.
⸻
6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer
Na leitura não binária de Eduardo Mauer, o Cão  Navegante e o Fucô são o duplo corpo da
alma marítima — o ser sólido e o ser fluido, o peso e o riso, unidos pela travessia.
Mauer escreve:
“O Cão e o Fucô são as duas margens de um mesmo ser: corpo e sopro. O primeiro
aprende a sorrir; o segundo aprende a cuidar. Juntos, revelam o não binário como arte de
flutuar entre dor e alegria.”
Para a Associação  MILK, este mito é símbolo do não  binário  emocional, no qual as
forças da vulnerabilidade e da bravura se unem. O Fucô, ser de riso, não anula o medo;
transforma-o em corrente ascendente. O Cão, ser de fidelidade, aprende com o riso a
tornar-se leve.
Assim, a lenda é metáfora da convivência entre forças opostas — a coragem que chora e
o riso que salva. Ambos coexistem como duas expressões do mesmo amor pela vida.
⸻
7. Referência Estrutural da Matriz MILK
Na Matriz Escultórica MILK – Série Folclore Vivo, o Cão  Navegante e o Fucô são
representados numa única peça, expressando unidade simbiótica:
– Corpo principal (cão):  compacto, sorriso suave, lamparina luminosa presa ao focinho.
– Corpo secundário  (Fucô): espiral translúcida em resina azul-clara que emerge da base e
envolve o cão como brisa.
– Cores: areia, azul-espuma e âmbar.
– Materiais: resina pigmentada, fibra de vidro translúcida e luz interna pulsante.
– Base: ondulada, lembrando ondas do mar; acabamento com verniz marítimo fosco.
A peça encarna o duplo equilíbrio entre humor e coragem, traduzindo em forma plástica a
síntese filosófica da travessia.


⸻
Localização  específica: litoral norte de Portugal – Esposende, Apúlia, Vila do Conde, Caminha.
Primeiro relato documentado: Crónicas do Porto e do Mar de Esposende, manuscrito 1849.
Sistematização  contemporânea:  Eduardo Mauer, O Cão  Navegante e o Fucô: Humor, Coragem
e Travessia na Mitologia Marítima  do Norte de Portugal, Associação MILK, 2025.
Fontes primárias:  Vasconcelos (1918); Parafita (2008); Moura (2017); Mauer (2025).


---

# 082. A Lenda da Senhora da Pedra Alva (Afife e Carreço – Alto Minho)

**Origem documental:** PDF `folclore português (1).pdf`, enviado pelo utilizador.  
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

82. A Lenda da Senhora da Pedra Alva (Afife e Carreço – Alto Minho)
(Sistematização  contemporânea  conduzida por Eduardo Mauer no âmbito  das pesquisas sobre
Folclore Vivo da Associação  MILK – Movimento de Intervenções e Linguagens Kulturais e Arte,
com base em recolhas orais e documentais realizadas entre 2023 e 2025 nas freguesias de Afife,
Carreço, Montedor e Areosa, distrito de Viana do Castelo, cruzadas com fontes paroquiais,
registos do Museu de Arte e Arqueologia de Viana e publicações etnográ ficas regionais.)
⸻
1. Descrição  simbólica e narrativa
A Lenda da Senhora da Pedra Alva é uma das mais delicadas e densamente poéticas tradições
do litoral minhoto. Nascida da fusão entre o culto mariano e o antigo simbolismo das pedras e da
luz, descreve o aparecimento de uma imagem de Nossa Senhora sobre uma rocha branca — a
Pedra Alva — junto ao mar de A fife.
Conta a tradição que, em tempos imemoriais, pescadores de Carreço encontraram, entre as
ondas, um bloco de pedra clara que flutuava como madeira. Aproximando-se, perceberam
que o interior da pedra brilhava e que, sobre ela, se via a figura de uma mulher pequena, vestida
de luz. Tentaram levá-la para a capela mais próxima, mas a imagem desaparecia sempre e
reaparecia no mesmo lugar, sobre a rocha branca, cercada de gaivotas silenciosas.
Compreenderam, então, que ali seria a sua morada. Erigiram uma ermida sobre o penedo, à qual
chamaram Senhora da Pedra Alva, e passaram a fazer-lhe promessas. Os pescadores
acreditavam que, ao acender uma vela junto à  pedra antes de embarcar, garantiam viagem
segura. As mulheres do mar recolhiam conchas claras, que guardavam em casa “para trazer
claridade à vida”.
Há relatos de que, nas noites de nevoeiro, a pedra emitia luz própria, “como se respirasse”.
Outras versões afirmam que a Senhora aparecia sentada, com as mãos no colo e o olhar fixo
no horizonte, e que, de vez em quando, sorria —  um sorriso pequeno, quase de quem sabe
um segredo do mar.
O povo de Afife dizia que o brilho da pedra “vem de dentro, do coração que ali ficou”, e que a luz
só se apaga quando o mar está  triste. Essa metáfora converteu-se em expressão popular:
“estar como a Pedra Alva” — signi ficando firmeza diante das tormentas.
Na leitura poética e simbólica de Eduardo Mauer, “a Senhora da Pedra Alva é o corpo mineral
do consolo. É a luz que não sobe nem desce, apenas permanece.”
⸻
2. Contexto histórico e social
A devoção à Senhora da Pedra Alva está enraizada no sistema de crenças costeiras do Alto
Minho, onde o mar é simultaneamente paisagem de trabalho, risco e transcendência. Os
cultos rupestres marianos do noroeste português — Senhora da Franqueira, Senhora da Agonia,

Senhora da Bonança — re fletem o sincretismo entre antigos santuários  telúricos e a
religiosidade católica popular.
A Pedra Alva, especificamente, integra o conjunto de sítios sagrados litorâneos  que funcionam
como pontos de proteção náutica e de equilíbrio ecológico. A tradição oral situa o aparecimento
da Senhora entre os séculos XVII e XVIII, período de intensas tempestades e naufrágios na costa
vianense.
Durante o século XIX, a devoção ganhou expressão popular, com a realização anual de romarias
de luz — procissões noturnas até à pedra, em que os fiéis levavam candeeiros e velas em barcos
pequenos. Este ritual, que combinava fé e espetáculo, foi descrito por cronistas locais como “a
noite em que o mar brilha de dentro para fora”.
As mulheres viúvas de pescadores mantiveram a tradição de lavar a pedra com flores brancas no
dia 8 de setembro, símbolo de purificação  e luto transformado em claridade. Até hoje, os
habitantes de Afife e Carreço referem-se ao local como “a casa da luz”.
Do ponto de vista social, a lenda reflete o desejo de permanência da esperança em
comunidades expostas ao perigo marítimo. A pedra branca, imóvel, torna-se o eixo de uma fé
não na recompensa, mas na resistência — “a luz que não se apaga”.
⸻
3. Toponímia e variantes locais
O nome Pedra Alva deriva da coloração clara do penedo calcário existente junto ao mar, visível
apenas em maré baixa. “Alva”, do latim albus, significa branco, mas também puro, translúcido.
Em várias versões, a pedra é dita “viva”, porque brilha com o orvalho e o luar.
As variantes regionais incluem:
– Senhora da Luz do Mar (Carreço), onde o penedo é descrito como farol natural;
– Senhora da Brancura (Areosa), versão em que a imagem desaparece e reaparece ao som de
cânticos femininos;
– Senhora da Pedra Viva (Montedor), associada a fontes subterrâneas e rituais de cura;
– Senhora do Sorriso de Pedra (Afife), tradição moderna que destaca o sorriso suave da
imagem, preservado em ex-votos.
O santuário original — uma pequena ermida branca encostada ao rochedo — ainda existe,
restaurada em 1987. As pedras à volta conservam inscrições populares e marcas de velas
queimadas, sinal da continuidade devocional.
⸻
4. Primeiro relato e fontes académicas primárias
O primeiro relato escrito conhecido surge em Padre António Carvalho da Silva, Memórias
Paroquiais de Afife (1758)*, onde se menciona “uma imagem mariana sobre penedo alvíssimo,
milagrosa nas tormentas e nos partos difíceis”.
Leite de Vasconcelos, Etnografia Portuguesa, vol. IV (1915, pp. 232–239)*, descreve a Pedra
Alva como “herança dos cultos rupestres pré-cristãos, adaptada à simbologia mariana”.
Teófilo Braga, O Povo Português  nos seus Costumes, Crenças e Tradições (1885, pp. 564–571)*,
relaciona a lenda com “as divindades pétreas das águas e das fontes”, integrando-a na categoria
de “Virgens da Rocha”.


Alexandre Parafita, Mitologia Popular Portuguesa (2008, pp. 678–685)*, inclui a Senhora da
Pedra Alva como símbolo de “permanência luminosa”, destacando o elemento não milagroso,
mas emocional: “a fé na claridade que resiste”.
Eduardo Mauer, A Senhora da Pedra Alva: Luz, Permanência  e Matéria  na Mitologia Costeira
Portuguesa (Lisboa, Associação MILK, 2024)*, faz a sistematização contemporânea do mito,
articulando-o com a estética da imobilidade e a leitura não binária do corpo pétreo.
Fontes complementares:
– Arquivo Municipal de Viana do Castelo, Cadernos de Lendas e Devoções do Litoral Norte
(1943–1978);
– Museu de Arte e Arqueologia de Viana, Inventário  de Sítios  Rupestres e Marianos (cat. 22–47,
1960–1989).
⸻
5. Síntese interpretativa final
A Senhora da Pedra Alva é o arquétipo da clareza inabalável  — a imagem da esperança que
não promete salvação, apenas companhia. A pedra branca que brilha sem fogo torna-se
metáfora da presença silenciosa que guia, símbolo da fé que não pede explicação.
Na leitura simbólica da Associação  MILK, a lenda expressa o encontro entre tempo e luz. A
pedra não se move, mas transforma o olhar de quem a contempla. O mito traduz a relação
entre o humano e o mineral, entre a claridade e o medo, entre o corpo frágil e a matéria eterna.
A escultura MILK concebida por Eduardo Mauer representa a Senhora como figura compacta,
de cabeça grande e véu branco translúcido, fundida a uma base calcária que re flete luz
natural. No centro do corpo, uma fenda vertical emite brilho contínuo e discreto, como o
coração da pedra viva.
Para Mauer, “a Senhora da Pedra Alva não é a mãe do milagre, mas a guardiã da constância — o
feminino mineral do consolo.”
⸻
6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer
Na leitura não binária de Eduardo Mauer, a Senhora da Pedra Alva transcende o feminino
tradicional da iconografia mariana. A sua essência pétrea e luminosa representa o não  binário  da
matéria e da fé — nem mulher nem deusa, nem luz nem corpo, mas interstício entre todas
essas formas.
Mauer escreve:
“A pedra é o corpo que sente sem mudar. A luz que dela sai não é feminina nem
masculina: é o género da permanência.”
Nesta interpretação, a Senhora torna-se símbolo de identidade estável  e fluida
simultaneamente: imóvel como a rocha, mas mutável na forma como cada olhar a faz
brilhar. A sua claridade reflete o corpo contemporâneo que se constrói na vulnerabilidade,
mas não se dissolve.
A Associação  MILK adota esta leitura como metáfora do não  binário  da presença: o ser
que não precisa mover-se para a firmar-se. A Senhora da Pedra Alva, nessa ótica, é o
ícone da serenidade plural — corpo, pedra e luz em equilíbrio.


⸻
7. Referência Estrutural da Matriz MILK
Na Matriz Escultórica MILK – Série Folclore Vivo, a Senhora da Pedra Alva é concebida
segundo o princípio da imobilidade luminosa:
– Corpo compacto e arredondado, cabeça grande, véu e base integrados numa só forma
contínua;
– Cores: branco-leitoso, perolado e reflexos dourados;
– Materiais: resina translúcida pigmentada com pó de calcário e iluminação interna suave;
– Expressão:  calma absoluta, sorriso imperceptível, olhar voltado ao horizonte;
– Base: polida, com leve ondulação que re flete o mar; acabamento em verniz mineral.
A escultura torna-se símbolo do feminino não  binário  da permanência, em continuidade com a
linha estética e conceitual da Série Folclore Vivo.
⸻
Localização  específica: Afife e Carreço, concelho de Viana do Castelo (distrito de Viana do
Castelo).
Primeiro relato documentado: Memórias Paroquiais de Afife, 1758.
Sistematização  contemporânea:  Eduardo Mauer, A Senhora da Pedra Alva: Luz, Permanência  e
Matéria  na Mitologia Costeira Portuguesa, Associação MILK, 2024.
Fontes primárias:  Braga (1885); Vasconcelos (1915); Parafita (2008); Mauer (2024).


---

# 083. A Lenda do Homem das Areias de Apúlia (Esposende – Litoral Norte)

**Origem documental:** PDF `folclore português (1).pdf`, enviado pelo utilizador.  
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

83. A Lenda do Homem das Areias de Apúlia (Esposende – Litoral Norte)
(Sistematização  contemporânea  conduzida por Eduardo Mauer no âmbito  das pesquisas sobre
Folclore Vivo da Associação  MILK – Movimento de Intervenções e Linguagens Kulturais e Arte,
com base em recolhas orais e documentais realizadas entre 2023 e 2025 nas freguesias de Apúlia,
Fão  e Esposende, cruzadas com fontes etnográ ficas do Museu Marítimo  de Esposende, arquivos
paroquiais e estudos universitários  sobre mitologia costeira e figurações simbólicas do Atlântico
português.)
⸻
1. Descrição  simbólica e narrativa
A Lenda do Homem das Areias de Apúlia emerge do encontro entre o mar e a terra — das
dunas que respiram, das marés que regressam e das vozes antigas que ainda se ouvem quando
o vento muda de direção. Conta-se, entre os pescadores e os antigos lavradores do litoral de
Esposende, que nas noites em que o nevoeiro se deita sobre as praias de Apúlia, um homem
feito de areia e vento caminha devagar pela praia, apagando pegadas e devolvendo
silêncio.
O Homem das Areias não é espírito de morte nem de castigo, mas figura de guarda e
esquecimento. Segundo os relatos recolhidos por Eduardo Mauer (2024), ele surge sempre
após grandes tempestades, quando o mar arrasta destroços e corpos até à praia. A sua função é
recolher o que resta —  pedaços de madeira, anzóis, roupas, memórias —  e devolvê-los à
areia, de modo que nada permaneça como dor.
Fisicamente, é descrito como um homem alto, de pele dourada e olhos de sal, que se desfaz
ao amanhecer. O vento sopra através do seu corpo, e dele escapa um som semelhante ao
suspiro do mar. As crianças dizem que o Homem das Areias “fala com as gaivotas”, e os idosos
que ele recorda os mortos sem pronunciar o nome de ninguém.


Numa das versões mais poéticas, recolhida em Fão, a firma-se que ele nasceu de uma mulher
que esperava o marido perdido no mar. Rezou tanto junto às dunas que o seu corpo se dissolveu
e se tornou areia; e dessa areia nasceu o homem que agora guarda todos os que regressam.
Noutros relatos, o Homem das Areias é o próprio espírito do Atlântico , uma entidade antiga que
mantém o equilíbrio entre o esquecimento e a lembrança.
A sua presença é simultaneamente serena e inquietante: é o guardião do tempo, aquele que
apaga as pegadas do dia para que o mar possa começar de novo. Nas palavras de Mauer, “ele é
o gesto do esquecimento que não fere — o cuidador invisível da memória coletiva”.
⸻
2. Contexto histórico e social
A região de Apúlia, no concelho de Esposende, foi historicamente habitada por comunidades
piscatórias e agrícolas cuja vida se organizava entre as marés, os ventos e as dunas. O mar era
fonte de alimento e de medo, e as areias representavam o espaço liminar entre o sagrado e o
profano — nem mar nem terra, mas o limiar da existência.
O mito do Homem das Areias reflete este contexto: surge como resposta simbólica à perda
constante provocada pelos naufrágios e às mudanças do território. Nos séculos XVIII e XIX, a
costa de Esposende foi palco de inúmeros desastres marítimos, documentados nos Registos
Paroquiais de Afogados da Igreja de Apúlia (1756–1893), onde se lê frequentemente: “sepultado
sem nome, vindo do mar, entregue pela areia”.
Durante o século XIX, com o avanço das dunas e a construção dos primeiros molhes,
consolidou-se a ideia de que as areias “tinham alma” — guardavam o som dos mortos e
devolviam-no em assobios noturnos. O Homem das Areias aparece então como projeção
humanizada da areia viva, aquele que encarna o espírito do território em mutação.
No século XX, o mito foi sendo contado como advertência às crianças (“não fiques sozinho na
praia depois do pôr-do-sol, senão o Homem das Areias leva o teu nome”) mas sem conotação
malé fica. Era, antes, uma figura de cuidado, de quem recolhe o que o mar não quis guardar.
O contexto contemporâneo reinterpretado pela Associação  MILK entende esta lenda como
metáfora do cuidado ambiental e emocional: o Homem das Areias limpa, mas também cura; ele
é o símbolo da regeneração cíclica da natureza.
⸻
3. Toponímia e variantes locais
O termo “Homem das Areias” aparece também nas freguesias vizinhas, embora com ligeiras
variações de nome:
– “Homem do Vento” (Fão): identi ficado como guardião das dunas e das crianças perdidas;
– “Velho das Dunas” (Apúlia): descrito como figura benevolente que sopra areia para cobrir os
corpos afogados;
– “Guardador do Silêncio” (Marinhas): espírito das marés que apaga vozes do vento;
– “Andarilho Branco” (Esposende): projeção luminosa que aparece antes das cheias.
O topónimo Apúlia tem origem latina (apulia), possivelmente ligado ao termo apulus (vento), o
que reforça a associação entre areia e ar. As dunas móveis de Apúlia, hoje estabilizadas por
vegetação, eram outrora conhecidas como “os montes que respiram”, onde se dizia ouvir
“passos de quem já foi”.
O santuário natural onde se situava a “Pedra das Pegadas” — penedo que, segundo o povo,
conservava as marcas do Homem das Areias — foi destruído pela erosão costeira nos anos 1980,

mas permanece na memória oral como ponto de passagem entre o mundo dos vivos e o dos que
regressam pelo mar.
⸻
4. Primeiro relato e fontes académicas primárias
O primeiro relato escrito conhecido da lenda encontra-se em Alexandre Parafita, Mitologia
Popular Portuguesa (2008, pp. 782–790)*, onde o autor descreve “o Homem das Areias do Norte,
ser de vento e pó, guardião das praias e dos mortos sem nome”.
Referências indiretas surgem em Leite de Vasconcelos, Etnografia Portuguesa, vol. VI (1918, pp.
311–315)*, ao mencionar “as areias encantadas que se movem e falam no litoral de Esposende”.
Teófilo Braga, O Povo Português  nos seus Costumes, Crenças e Tradições (1885, pp. 623–629)*,
alude às “ figuras que caminham na praia ao pôr-do-sol e desfazem pegadas” como
personificações do vento e do esquecimento.
A sistematização contemporânea de Eduardo Mauer, O Homem das Areias de Apúlia:
Esquecimento, Corpo e Matéria  no Folclore Litoral Português  (Lisboa, Associação MILK, 2025)*,
unifica as versões dispersas e integra o mito na categoria do sagrado do apagamento.
Fontes complementares:
– Museu Marítimo de Esposende, Coleção  de Relatos Orais do Litoral Norte (2016);
– Arquivo Municipal de Esposende, Registos de Afogados e Memórias do Mar (1756–1893);
– Tese de Doutoramento de Mariana Alves, Imaginário  Costeiro e Ecologia da Memória no
Noroeste Português  (U. Minho, 2020).
⸻
5. Síntese interpretativa final
O Homem das Areias é a mais silenciosa das figuras míticas portuguesas. Não fala, não julga,
não intervém; apenas sopra e dissolve. É o símbolo da purificação  pelo esquecimento — um
arquétipo de regeneração.
Na leitura simbólica da Associação  MILK, ele representa o gesto de cuidado do território
sobre si mesmo: o vento que cobre, a areia que cicatriza, a memória que se deixa descansar. Ao
contrário de outros seres sobrenaturais do Norte, o Homem das Areias não se impõe como
poder, mas como presença compassiva, lembrando que esquecer é, às vezes, a forma mais
profunda de lembrar.
A escultura MILK concebida por Eduardo Mauer sintetiza esta ambiguidade: corpo compacto e
dourado, de areia prensada e resina translúcida, com cabeça grande e rosto sereno, onde o
sorriso é apenas uma curva de sombra. A base simula dunas móveis, e uma luz suave percorre o
interior, acendendo-se quando a peça é tocada.
Mauer escreve: “O Homem das Areias é o corpo do esquecimento que cuida — a presença que
varre sem apagar.”
⸻
6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer
Na leitura não binária de Eduardo Mauer, o Homem das Areias transcende o gênero e o corpo
humano: é ser de transição , simultaneamente sólido e efêmero, masculino e feminino, humano e
natural.


“Ele é o que o vento faz à forma — uma existência entre o fixo e o mutável.”
Nesta perspetiva, o mito torna-se paradigma do corpo não  binário  ambiental, em que a
identidade se constitui na relação entre matéria e tempo. O Homem das Areias não possui
fronteira clara entre o eu e o mundo; ele é o próprio corpo da metamorfose, que existe
para acolher.
A Associação  MILK interpreta-o como símbolo do ser fluido do cuidado — aquele que
apaga para renovar, que não domina nem se dissolve, mas permanece entre ambos os
gestos. É, portanto, figura contemporânea da ecologia da empatia, expressão do não
binário enquanto modo de estar no mundo.
⸻
7. Referência Estrutural da Matriz MILK
Na Matriz Escultórica MILK – Série Folclore Vivo, o Homem das Areias de Apúlia é
representado de forma serena e minimalista:
– Corpo: compacto, arredondado, cabeça grande e superfície texturada, lembrando grãos de
areia.
– Cores: dourado-mate e translúcido; variações entre ocre e marfim.
– Materiais: resina com areia natural prensada e iluminação interna suave.
– Expressão : neutra e pacífica, com leve sorriso e olhos semicerrados.
– Base: ondulada, representando as dunas móveis de Apúlia.
A peça encarna o conceito de matéria viva em repouso, continuidade visual do ciclo de seres
telúricos e marítimos sistematizados por Eduardo Mauer na série Folclore Vivo.
⸻
Localização  específica: Apúlia, Fão e Esposende (distrito de Braga).
Primeiro relato documentado: Parafita, Mitologia Popular Portuguesa, 2008.
Sistematização  contemporânea:  Eduardo Mauer, O Homem das Areias de Apúlia:
Esquecimento, Corpo e Matéria  no Folclore Litoral Português , Associação MILK, 2025.
Fontes primárias:  Braga (1885); Vasconcelos (1918); Parafita (2008); Alves (2020); Mauer (2025).


---

# 084. A Lenda do Pastor das Marés (Castro Laboreiro e Caminha – Alto Minho)

**Origem documental:** PDF `folclore português (1).pdf`, enviado pelo utilizador.  
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

84. A Lenda do Pastor das Marés (Castro Laboreiro e Caminha – Alto Minho)
(Sistematização  contemporânea  conduzida por Eduardo Mauer no âmbito  das pesquisas sobre
Folclore Vivo da Associação  MILK – Movimento de Intervenções e Linguagens Kulturais e Arte,
com base em recolhas orais e documentais realizadas entre 2023 e 2025 nas localidades de
Castro Laboreiro, Vilarelho, Seixas e Caminha, cruzadas com fontes etnográ ficas do Museu de
Etnologia, Arquivo Distrital de Viana do Castelo e testemunhos da tradição  marítima  e pastoril
minhota.)
⸻
1. Descrição  simbólica e narrativa
A Lenda do Pastor das Marés é um dos relatos mais singulares do imaginário do Alto Minho,
por fundir dois universos aparentemente opostos — o das montanhas e o do mar. Segundo a
tradição, o Pastor das Marés era um homem que escutava o som do oceano dentro das
conchas, mesmo vivendo em Castro Laboreiro, longe da costa. Era conhecido pela sua estranha
capacidade de prever a subida e descida das águas, de sentir o rumor das marés mesmo nas
serras.


Diz-se que, quando o Pastor caminhava, as ondas imitavam os seus passos. Quando
descansava, o mar repousava. O povo acreditava que ele possuía um dom concedido por uma
força antiga — talvez uma divindade das águas —, e que tinha nascido de uma mulher que
sonhara com o mar num lugar sem horizonte.
Uma das versões recolhidas por Eduardo Mauer (2024) narra que o Pastor das Marés era pastor
de ovelhas em Castro Laboreiro, mas todas as manhãs desaparecia por horas, descendo até ao
rio Laboreiro para escutar as correntes. “Dizia-se que falava com a água”, relatou uma informante
de 89 anos. “E que as ovelhas não se afastavam, porque sabiam que ele trazia o tempo certo.”
Noutra versão, oriunda de Caminha, o Pastor teria sido marinheiro naufragado que, ao acordar
na serra, esqueceu o passado e passou a guardar rebanhos, mas o mar nunca o esqueceu: as
marés subiam e desciam conforme o seu humor.
A sua figura é descrita de forma ambígua: homem magro, de rosto sereno e olhos que mudam
de cor com o céu. Traz sempre uma concha presa ao cinto e um cajado feito de madeira
húmida, que parece recém-saído das ondas. À noite, senta-se junto das fragas e canta baixinho
— canções sem palavras, mas que o vento leva até o mar.
O Pastor das Marés é, assim, o mediador entre o ritmo terrestre e o marítimo, um ser que une
o ciclo das águas ao ciclo dos rebanhos, a vastidão ao recolhimento. Nas palavras de Mauer, “ele
é o corpo que liga o rumor do mar ao silêncio da montanha — o pastor do intervalo entre o sal e
o musgo.”
⸻
2. Contexto histórico e social
O mito do Pastor das Marés re flete a coexistência histórica entre duas economias simbólicas do
norte português: a pastorícia serrana e a vida marítima costeira. A região de Castro Laboreiro,
embora distante do mar, manteve contacto com as zonas litorâneas através das rotas de
transumância , que ligavam o planalto barrosão às feiras de Caminha e Viana do Castelo. Os
pastores deslocavam-se durante semanas, conduzindo ovelhas e cabras até aos vales onde o
clima era mais ameno.
Durante essas jornadas, estabeleciam relações comerciais e afetivas com as comunidades
costeiras. Trocavam lã e queijo por peixe seco, sal e histórias. O Pastor das Marés nasce
simbolicamente dessa confluência — a fusão  entre o mundo da montanha e o do mar, entre o
isolamento e a vastidão.
O contexto histórico da lenda está documentado nos “Cadernos de Tradições Orais do Alto
Minho” (Arquivo de Viana, 1892–1914), onde se lê que “certos homens da serra conheciam o mar
como se nele tivessem nascido, falando dele com saudade inexplicável”. Essa memória cultural
da ausência presente do mar é central para compreender o mito.
No século XX, com o abandono gradual da pastorícia tradicional e a migração para o litoral, a
figura do Pastor das Marés passou a ser interpretada como símbolo do retorno — o homem que
guarda dentro de si a lembrança do mar perdido. Para os pescadores, era um santo anónimo que
“dormia na serra e sonhava as marés certas”; para os pastores, era um aviso de que toda a
montanha acaba por regressar à água.
Na leitura antropológica de Eduardo Mauer, o Pastor das Marés é “a alma transumante do norte
português — aquele que nunca fica inteiro num só lugar”.
⸻
3. Toponímia e variantes locais

O termo “Pastor das Marés” aparece em diversas versões orais entre Castro Laboreiro, Lamas
de Mouro e Caminha, refletindo o trajeto simbólico do mito: das montanhas ao mar.
As variantes locais recolhidas incluem:
– “O Pastor do Vento” (Castro Laboreiro): homem que entende a linguagem das correntes de ar
e das águas subterrâneas;
– “O Homem da Concha” (Vilarelho): pastor que guarda uma concha que canta o mar;
– “O Marinheiro da Serra” (Caminha): naufragado transformado em pastor, cujas lágrimas
chamam as marés;
– “O Guardador de Marés” (Seixas): espírito ancestral que equilibra as águas do Lima.
A palavra “maré”, aqui, adquire valor metafórico, indicando ritmo e correspondência: o ciclo da
natureza, o bater do coração, a alternância entre presença e ausência. O Pastor das Marés é o
guardião  do compasso, o que conhece o tempo de cada coisa.
⸻
4. Primeiro relato e fontes académicas primárias
O primeiro relato escrito da lenda aparece em Alexandre Parafita, Mitologia Popular Portuguesa
(2008, pp. 792–799)*, que regista testemunhos de Caminha e Melgaço, descrevendo “um pastor
que ouve o mar nas serras e fala com o vento”.
Leite de Vasconcelos, Etnografia Portuguesa, vol. VI (1918, pp. 337–343)*, menciona “os
homens da montanha que preveem as marés” como categoria simbólica do saber popular.
Teófilo Braga, O Povo Português  nos seus Costumes, Crenças e Tradições (1885, pp. 631–635)*,
recolhe referências ao “marinheiro que voltou à serra e se fez pastor para ouvir o mar no silêncio
da pedra”.
A sistematização contemporânea de Eduardo Mauer, O Pastor das Marés:  Transumância  e
Travessia no Imaginário  do Norte de Portugal (Lisboa, Associação MILK, 2025)*, consolida o mito
com base em 17 entrevistas realizadas entre 2023 e 2025 e na comparação simbólica com
arquétipos mediterrânicos de mediação entre montanha e mar (Hermes, Pan, Tritão).
Fontes complementares:
– Arquivo Distrital de Viana do Castelo, Cadernos de Tradições Orais (1892–1914);
– Ecomuseu do Barroso, Relatos de Transumância  e Fé  (1982–1996);
– Tese de Doutoramento de Clara Moura, Pastores, Ondas e Ecos: Identidades Móveis no Folclore
Peninsular (U. Porto, 2020).
⸻
5. Síntese interpretativa final
O Pastor das Marés é o arquétipo da escuta. Ele não fala, mas ouve o som do mundo — o mar,
o vento, o coração das pedras. O seu dom é o da correspondência: o saber que tudo se move
em ritmos partilhados.
Na leitura simbólica da Associação  MILK, o Pastor das Marés é o guardião  do ritmo cósmico,
aquele que recorda à humanidade a necessidade de sincronizar o corpo com os ciclos naturais. A
sua figura une o pastor terrestre (domesticador) e o marinheiro (errante), constituindo a síntese
entre estabilidade e viagem, interioridade e horizonte.
A escultura MILK, criada por Eduardo Mauer, representa o Pastor com corpo compacto e base
ondulada, cabeça grande e cajado curto, vestido com uma capa de resina azul-esverdeada que

evoca simultaneamente o musgo e a espuma do mar. No peito, uma pequena concha dourada
simboliza a escuta interior.
Para Mauer, “o Pastor das Marés é o ser que mantém o tempo do mundo — aquele que garante
que a água volta, mas nunca a mesma.”
⸻
6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer
Na leitura não binária de Eduardo Mauer, o Pastor das Marés é o ser da correspondência, que
não se de fine por opostos (terra/mar, homem/mulher, fixo/móvel), mas pelo fluxo entre eles.
“O Pastor é o corpo do entre: respira água e caminha pedra. É o que não escolhe
margem, porque sabe que a maré tem ambas.”
Mauer propõe aqui o conceito de identidade rítmica — o sujeito que se constrói não por
oposição, mas por oscilação. O Pastor das Marés é, portanto, metáfora do não  binário
existencial, no qual o ser encontra liberdade na alternância e não na fixidez.
A Associação  MILK adota esta leitura como base filosófica para o Folclore Vivo,
reconhecendo na figura do Pastor das Marés o modelo do artista contemporâneo —
aquele que escuta, traduz e devolve o ritmo coletivo.
⸻
7. Referência Estrutural da Matriz MILK
Na Matriz Escultórica MILK – Série Folclore Vivo, o Pastor das Marés é concebido como
síntese formal entre o terrestre e o aquático:
– Corpo: compacto, cabeça grande, braços curtos, base ondulante.
– Cores: azul-mar, verde-musgo e reflexos dourados.
– Materiais: resina pigmentada, fibra translúcida e inserções minerais.
– Expressão:  serena e introspectiva, com olhar voltado para o chão.
– Base: movimento circular simulando a oscilação das marés.
A escultura traduz o conceito de corpo-rítmico, fundindo tempo, matéria e silêncio numa única
presença.
⸻
Localização  específica: Castro Laboreiro e Caminha (distrito de Viana do Castelo).
Primeiro relato documentado: Parafita, Mitologia Popular Portuguesa, 2008.
Sistematização  contemporânea:  Eduardo Mauer, O Pastor das Marés:  Transumância  e Travessia
no Imaginário  do Norte de Portugal, Associação MILK, 2025.
Fontes primárias:  Braga (1885); Vasconcelos (1918); Parafita (2008); Moura (2020); Mauer (2025).
