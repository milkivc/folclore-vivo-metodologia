# Corpus integral auditado — parte 10

Entradas 127 a 138.



---

# 127. A Lenda do Homem das Sete Dentaduras (Minho e Alto Lima)

**Origem documental:** PDF `folclore português (1).pdf`, enviado pelo utilizador.  
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

127. A Lenda do Homem das Sete Dentaduras (Minho e Alto Lima)
(Sistematização  contemporânea  conduzida por Eduardo Mauer no âmbito  das pesquisas sobre
Folclore Vivo da Associação MILK – Movimento de Intervenções e Linguagens Kulturais e
Arte, com base em recolhas orais e documentais realizadas entre 2023 e 2025 em Ponte da
Barca, Arcos de Valdevez, Soajo e Lindoso, cruzadas com acervos do Museu dos Territórios de
Valdevez, Arquivo Municipal de Ponte da Barca, Ecomuseu do Alto Lima e fontes etnográ ficas
regionais sobre figuras grotescas, simbolismo dentário  e moralidades populares do Minho interior.)
⸻
1. Descrição  simbólica e narrativa

No coração do Alto Lima, onde o vento das serras mistura cheiro de milho e resina, corre a
história do Homem das Sete Dentaduras, personagem entre o humano e o espantalho,
conhecido por rir quando devia calar e morder quando devia falar. As versões mais antigas,
recolhidas por Eduardo Mauer (2024) junto a moradores de Soajo e Bravães , descrevem-no
como um homem de corpo pequeno e boca desmesurada, que guardava dentro da boca sete
dentaduras completas, uma sobre a outra, feitas de materiais diferentes — osso, madeira, ferro,
pedra, vidro, ouro e sombra.
Diz-se que nasceu sem dentes e que, em cada fase da vida, pedia a um artífice da aldeia que lhe
fizesse um novo jogo, até que um dia, cansado de trocar, decidiu não  tirar mais nenhum.
Começou a sobrepor dentaduras, e a cada nova camada, sua fala tornava-se mais confusa, até o
ponto em que já não distinguia riso de choro. A partir daí, o povo começou a dizer: “fala como o
das sete dentaduras” — expressão ainda usada em algumas aldeias para designar quem fala
muito e diz pouco.
Mas há outras versões. Em Arcos de Valdevez, conta-se que o Homem das Sete Dentaduras era
um feiticeiro errante que usava cada dentadura para falar com um mundo: a de osso para falar
com os mortos, a de ferro para com os lobos, a de ouro para enganar reis, a de pedra para calar,
a de vidro para ver, a de madeira para cantar, e a de sombra para dormir. As pessoas acreditavam
que, em noites de trovoada, ele atravessava o vale rindo — um riso que fazia os cães uivar e as
galinhas cessarem o canto.
Segundo um relato colhido em Ponte da Barca, o Homem vivia perto de uma ponte antiga, onde
guardava sete arcas. Dentro de cada uma, uma dentadura diferente, e em cada dentadura, uma
palavra proibida. Diziam que, quando as sete palavras fossem pronunciadas em sequência, as
montanhas se moveriam e os rios voltariam a correr de trás para diante. Por isso, o povo o temia
e o respeitava.
Eduardo Mauer escreve: “O Homem das Sete Dentaduras é a alegoria do excesso verbal — a
carne que mastiga o próprio som.”
⸻
2. Contexto histórico e social
O Alto Lima foi, durante séculos, região de travessias e oralidades densas. Entre os séculos
XVIII e XX, os contadores de histórias locais criaram figuras grotescas e morais para encenar
vícios humanos — a gula, o excesso, a mentira, o orgulho. O Homem das Sete Dentaduras
pertence a essa genealogia de “monstros pedagógicos” que, como o “homem da gaita”, a
“mulher das tripas” ou o “careto do forno”, serviam para transmitir preceitos sociais através da
sátira.
O número sete, recorrente na simbologia cristã e popular, sugere totalidade e limite: sete dias,
sete pecados, sete portões, sete camadas do mundo. No caso do Homem das Sete Dentaduras,
o número representa o limite da palavra — o ponto em que o excesso destrói o sentido.
Do ponto de vista antropológico, o mito integra a tradição das figuras bucais grotescas (bocas
excessivas, bocas devoradoras, bocas múltiplas), estudadas em contextos carnavalescos e
exorcísticos. O riso exagerado é ambíguo: simultaneamente libertador e ameaçador.
O Ecomuseu do Alto Lima conserva registos orais de festas de inverno em que mascarados
com bocas desproporcionadas percorrem as aldeias, recolhendo lenha e pão — herdeiros
performativos do Homem das Sete Dentaduras. Nessas celebrações, o riso e o medo convivem,
refletindo a estrutura social camponesa: ordem e desordem, autoridade e rebeldia.
Na leitura contemporânea da Associação  MILK, a figura expressa a tensão entre voz e escuta,
verbo e silêncio, comunicação  e ruído — dilemas profundamente atuais.


⸻
3. Toponímia e variantes locais
Os nomes “Homem das Sete Dentaduras” e “Homem da Boca de Sete Camadas” circulam
oralmente em Soajo, Bravães, Lavradas e Sampriz. Em algumas freguesias, a expressão “ tem a
boca do das dentaduras” é usada para repreender tagarelas.
Em Ponte da Barca, há uma vereda chamada “ Caminho do Riso”, próxima à ponte medieval
sobre o Lima, onde se diz que o Homem ria até ecoar nas águas. Em Lindoso, uma pedra de
granito com sete depressões circulares é apontada como “ as marcas dos dentes do Homem”,
embora arqueólogos locais a classifiquem como laje de moagem neolítica — o que reforça a
hibridização entre mito e vestígio material.
No Arquivo Municipal de Arcos de Valdevez, um documento de 1911 menciona, em coletânea
escolar manuscrita, a “história do homem dos sete risos e sete bocas”, possivelmente versão
primitiva do mito.
⸻
4. Primeiro relato e fontes académicas primárias
A primeira referência textual indireta ao mito encontra-se no manuscrito Lendas Populares do
Vale do Lima, de João  Gonçalves Pereira (1911, Arquivo Municipal de Arcos de Valdevez, cód.
AAV-11/1911), onde surge a expressão “homem das sete bocas, risonho e estranho”.
Fontes clássicas que fundamentam a tipologia:
– Teófilo Braga, O Povo Português  nos seus Costumes, Crenças e Tradições (1885, pp. 872-877):
discute “figuras orais do riso e da gula” e a moralidade associada ao “excesso de boca”.
– Leite de Vasconcelos, Etnografia Portuguesa, vol. XII (1933, pp. 67-75): descreve personagens
caricaturais transmontanas com bocas desproporcionadas, “metonímias da fala e da fome”.
– Alexandre Parafita, Mitologia Popular Portuguesa (2008, pp. 1220-1235): analisa “figuras do
verbo” — seres cuja palavra tem poder material.
– Eduardo Mauer, O Homem das Sete Dentaduras: Palavra e Silêncio  no Alto Lima (Lisboa,
Associação MILK, 2025): sistematiza depoimentos e interpreta o mito como crítica simbólica ao
ruído contemporâneo.
Fontes complementares:
– Ecomuseu do Alto Lima, Coleção  Oral – Ritos de Inverno e Risos da Montanha (1970-2020);
– Museu dos Territórios de Valdevez, Inventário  de Personagens Populares do Lima (2019);
– Tese de Doutoramento de Helena Furtado, O Riso e o Medo: Figuras Grotescas no Norte de
Portugal (U. Porto, 2016).
⸻
5. Síntese interpretativa final
O Homem das Sete Dentaduras é símbolo do excesso de verbo — a incapacidade humana de
conter o som. Ele transforma a fala em masticar, o pensamento em ruído. A multiplicidade das
dentaduras representa a tentativa de possuir todas as vozes e, por isso, perder a própria.
Na leitura simbólica da Associação  MILK, esta figura opera como alegoria do ruído social
contemporâneo : sobreposição de discursos, saturação de informação, ausência de escuta. O
mito reaparece como crítica poética ao excesso de fala que consome sentido.
A escultura MILK concebida por Eduardo Mauer apresenta o corpo compacto da matriz padrão,
mas com boca larga e sete camadas de dentes modeladas em relevo sucessivo, cada uma

com textura e cor distinta. As dentaduras superiores são de tom metálico; as inferiores, terrosas;
e a última, quase invisível — feita de sombra projetada.
Mauer escreve: “O Homem das Sete Dentaduras é o eco da própria garganta. Cada dente é um
silêncio que não aprendeu a ser palavra.”
⸻
6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer
“O Homem das Sete Dentaduras é corpo não binário da voz: simultaneamente fala e
carne, dizer e devorar.”
Nesta leitura, a boca torna-se órgão  de mediação  e conflito: entre dentro e fora,
alimento e verbo, som e silêncio. O não binário manifesta-se na coexistência de contrários
— fala que alimenta e fala que fere.
A Associação  MILK utiliza essa figura em performances denominadas “Oficinas do Riso
Denso”, nas quais artistas e comunidades exploram o som gutural e o riso como
ferramentas de descompressão emocional e crítica social, promovendo consciência da
fala e da escuta.
⸻
7. Referência Estrutural da Matriz MILK
Na Matriz Escultórica MILK – Série Folclore Vivo, o Homem das Sete Dentaduras apresenta:
– Corpo: compacto, ligeiramente inclinado para a frente;
– Cores: mistura de tons metálicos e terrosos;
– Materiais: resina pigmentada em camadas com pó de ferro, mica e óxidos naturais;
– Expressão:  riso ambíguo — simultaneamente alegre e perturbador;
– Base: oval, polida, refletindo o eco do som.
Integra o eixo “Corpos do Riso e do Excesso” do projeto Folclore Vivo, dedicado a figuras
grotescas, bufonescas e carnavalescas do Norte de Portugal.
⸻
Localização  específica: Ponte da Barca, Arcos de Valdevez, Soajo e Lindoso (distrito de Viana
do Castelo).
Primeiro relato documentado: João Gonçalves Pereira, Lendas Populares do Vale do Lima
(manuscrito, 1911, Arquivo Municipal de Arcos de Valdevez).
Sistematização  contemporânea:  Eduardo Mauer, O Homem das Sete Dentaduras: Palavra e
Silêncio  no Alto Lima, Associação MILK, 2025.
Fontes primárias:  Braga (1885); Vasconcelos (1933); Parafita (2008); Furtado (2016); Mauer
(2025).


---

# 128. A Lenda do Bicho de Lamas de Mouro (Melgaço e Castro Laboreiro – Alto Minho)

**Origem documental:** PDF `folclore português (1).pdf`, enviado pelo utilizador.  
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

128. A Lenda do Bicho de Lamas de Mouro (Melgaço e Castro Laboreiro – Alto Minho)
(Sistematização  contemporânea  conduzida por Eduardo Mauer no âmbito  das pesquisas sobre
Folclore Vivo da Associação MILK – Movimento de Intervenções e Linguagens Kulturais e
Arte, com base em recolhas orais e documentais realizadas entre 2023 e 2025 em Lamas de
Mouro, Castro Laboreiro e Parada do Monte, cruzadas com acervos do Museu de Melgaço –
Memória e Fronteira, Ecomuseu do Alto Minho, Arquivo Municipal de Melgaço, além  de

fontes académicas  e etnográ ficas sobre mitos de monstros de fronteira, metamorfoses
teriomórficas e guardiães  aquáticos  nas tradições galaico-portuguesas.)
1. Descrição  simbólica e narrativa
Entre as penedias húmidas e os vales de nevoeiro de Lamas de Mouro, junto às águas frias do
rio Trancoso, o povo fala de um ser antigo que habita os desfiladeiros e as lagoas mais fundas —
o Bicho de Lamas de Mouro. Não há quem o descreva do mesmo modo: para uns é serpente
de escamas azuis com olhos de fogo; para outros, mistura de cão e peixe; há ainda quem diga
que é um homem antigo transformado em fera por ter profanado a nascente sagrada.
Nos relatos coligidos por Eduardo Mauer (2024), o Bicho é descrito como criatura de voz grave
e humana, que fala através da água. Quando alguém se aproxima da lagoa nas noites de luar, o
reflexo vibra e a superfície murmura frases antigas, como se a própria montanha falasse.
Segundo a tradição, quem responde ao Bicho perde a fala — “porque a água não devolve
palavras, só ecos”.
Uma versão recolhida em Parada do Monte narra que o Bicho era outrora um pastor de Castro
Laboreiro que, ambicioso, quis atravessar o rio com um rebanho de ouro prometido por uma
moura encantada. Ao quebrar o juramento de silêncio, o ouro virou escamas, o pastor virou fera,
e desde então ronda as margens, procurando quem o escute sem medo.
As mulheres de Lamas de Mouro, ao lavarem roupa no rio, ainda dizem, meio a sério, meio a rir:
“Que o Bicho leve a dor e traga só espuma.” Este refrão, repetido em voz baixa, é considerado
um encantamento de proteção  e purificação .
Nas noites de neblina densa, os pastores afirmam ver duas luzes amarelas pairando sobre a
água. Uns dizem ser os olhos do Bicho; outros, os re flexos das lanternas dos mortos que ele
guia. O certo é que ninguém ousa atirar pedras ao rio — por respeito ou por temor.
Eduardo Mauer sintetiza: “O Bicho de Lamas de Mouro é o corpo da culpa dissolvido em
corrente. É o rumor do arrependimento que o ser humano deixou correr no rio.”
⸻
2. Contexto histórico e social
Lamas de Mouro é território de montanha e passagem, antigo corredor entre o Gerês e a Galiza,
marcado por rios de caudal forte e clima rigoroso. A convivência entre o humano e o elemento
aquático produziu, ao longo dos séculos, mitos de entidades guardiãs  das águas , muitas vezes
híbridas — meio animal, meio espiritual.
No imaginário do Alto Minho, o “bicho” não é necessariamente maligno; é a personificação  do
mistério natural. Representa o que escapa à compreensão, o limite da linguagem. O termo
“bicho” é usado aqui como categoria simbólica ampla, englobando criaturas aquáticas,
metamórficas ou liminares — “os que vivem entre mundos”.
A documentação paroquial e etnográ fica da região (séculos XVIII–XIX) mostra o uso de “bicho”
para descrever tanto figuras míticas quanto doenças e assombrações (“tem o bicho”,
“apanhou o bicho do rio”). Isso demonstra a dimensão moral e preventiva da lenda: educar o
respeito pelas águas, evitar banhos noturnos e travessias perigosas.
Durante o século XX, com a construção de pontes e barragens no vale do Trancoso, surgiram
novos relatos sobre o Bicho, agora associado a acidentes de obra e desaparecimentos
inexplicáveis . O mito foi reconfigurado como metáfora do desequilíbrio ambiental e da memória
dos rios submersos.


Na leitura contemporânea da Associação  MILK, o Bicho é o guardião  do silêncio fluvial —
aquele que lembra que a água também tem voz, e que todo o gesto humano sobre o território
deixa eco.
⸻
3. Toponímia e variantes locais
Topónimos como “Poço do Bicho”, “Fraga Encantada” e “Corga da Voz” aparecem nos mapas
orais de Lamas de Mouro e Castro Laboreiro, recolhidos por Mauer entre 2023 e 2025. Essas
designações persistem em conversas de moradores mais velhos, embora sem registro formal em
cartografia moderna.
Variantes regionais:
– Em Melgaço, o Bicho é descrito como “serpente-moura”, associada à lenda das Sete Fontes.
– Em Castro Laboreiro, fala-se no “Cão  da Água ”, fera que protege a passagem do rio Trancoso
e surge antes das tempestades.
– Na Galiza próxima, o paralelo mais direto é o Bicho da Corga de Abaixo, descrito em crónicas
orais como “espírito de pastor afogado”.
Essas variantes confirmam a natureza transfronteiriça do mito e a continuidade simbólica entre
guardiães aquáticos de Portugal e da Galiza.
⸻
4. Primeiro relato e fontes académicas primárias
O primeiro registro escrito alusivo à figura encontra-se em J. Leite de Vasconcelos, Etnografia
Portuguesa, vol. XI (1928, pp. 230–236)*, que menciona “as lendas do Bicho do Rio Trancoso,
serpente falante que se ouve em Lamas de Mouro”.
Outras fontes que dialogam com o motivo:
– Teófilo Braga, Crenças Populares de Portugal (1902, pp. 418–425): descrição de “animais
mágicos das águas” e da crença em “seres protetores de nascentes e lagos”.
– Alexandre Parafita, Mitologia Popular Portuguesa (2008, pp. 1236–1248): classifica o “bicho de
água” como arquétipo da consciência ecológica popular.
– Eduardo Mauer, O Bicho de Lamas de Mouro: Água,  Voz e Fronteira (Associação MILK, 2025),
resultado das recolhas orais e cruzamentos etnográ ficos de campo.
Fontes complementares:
– Museu de Melgaço – Inventário  de Narrativas do Alto Minho (1979–2018);
– Ecomuseu do Alto Minho – Coleção  Oral “Rios e Memórias” (1975–2021);
– Tese de Doutoramento de Isabel Fontes, Bestiários  Atlânticos:  Monstros e Metamorfoses na
Península  Ibérica  (U. do Minho, 2015).
⸻
5. Síntese interpretativa final
O Bicho de Lamas de Mouro simboliza o desequilíbrio e a redenção  do humano através da
água . É a consciência do erro convertida em corpo natural. O mito ensina que todo o ato de
profanação — seja ganância, seja descuido ambiental — encontra retorno simbólico no elemento
que foi ferido.
Na leitura simbólica da Associação  MILK, o Bicho não é castigo nem guardião moral, mas
memória viva da relação  com o território. É o rio dotado de espinha e voz. Sua figura híbrida,

entre homem e fera, traduz a condição contemporânea do humano: natureza transformada em
desejo e arrependimento.
A escultura MILK, concebida por Eduardo Mauer, segue a matriz padrão, mas apresenta textura
reptiliana e corpo arqueado, com olhos translúcidos e leve iridescência azul-esverdeada. O
dorso revela escamas formadas por fragmentos de vidro reciclado, simbolizando a
coexistência entre o natural e o arti ficial.
Mauer escreve: “O Bicho de Lamas de Mouro é o espelho que a água ergue para o homem. E
nele, o homem vê-se dividido.”
⸻
6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer
“O Bicho é corpo não binário da fronteira: simultaneamente humano e animal, água e
carne, culpa e cuidado.”
Nesta leitura, o Bicho encarna a transição  permanente entre categorias — é ser em
mutação contínua. Essa fluidez ecoa o pensamento contemporâneo sobre identidades
híbridas e ecológicas, onde o corpo é paisagem e a paisagem, corpo.
A Associação  MILK utiliza o mito nas oficinas “Vozes do Rio”, propondo exercícios de
escuta subaquática e performance vocal, explorando a relação entre corpo, som e
território. A prática artística torna-se espaço de reconciliação  sensorial com o
ambiente.
⸻
7. Referência Estrutural da Matriz MILK
Na Matriz Escultórica MILK – Série Folclore Vivo, o Bicho de Lamas de Mouro apresenta:
– Corpo: alongado, arqueado, mantendo a proporção da matriz compacta adaptada à forma
reptiliana;
– Cores: azul-esverdeado iridescente com reflexos aquáticos;
– Materiais: resina pigmentada, fragmentos de vidro e mica;
– Expressão:  olhar de calma antiga, sugerindo consciência;
– Base: curva, lembrando o movimento da água;
– Eixo curatorial: Corpos de Fronteira — seres de transição, híbridos e metamór ficos.
⸻
Localização  específica: Lamas de Mouro, Castro Laboreiro, Parada do Monte (distrito de Viana
do Castelo).
Primeiro relato documentado: Leite de Vasconcelos, Etnografia Portuguesa, vol. XI, 1928.
Sistematização  contemporânea:  Eduardo Mauer, O Bicho de Lamas de Mouro: Água,  Voz e
Fronteira, Associação MILK, 2025.
Fontes primárias:  Braga (1902); Vasconcelos (1928); Parafita (2008); Fontes (2015); Mauer (2025).
⸻


---

# 129. A Lenda do Cervo da Lua de Castro Laboreiro (Melgaço – Peneda-Gerês)

**Origem documental:** PDF `folclore português (1).pdf`, enviado pelo utilizador.  
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

129. A Lenda do Cervo da Lua de Castro Laboreiro (Melgaço – Peneda-Gerês)
(Sistematização  contemporânea  conduzida por Eduardo Mauer no âmbito  das pesquisas sobre
Folclore Vivo da Associação MILK – Movimento de Intervenções e Linguagens Kulturais e
Arte, com base em recolhas orais e documentais realizadas entre 2023 e 2025 em Castro

Laboreiro, Lamas de Mouro e Parada do Monte, cruzadas com fontes do Museu de Melgaço –
Memória e Fronteira, Parque Nacional da Peneda-Gerês, Arquivo Distrital de Viana do
Castelo e estudos sobre zoomorfismo sagrado, mitologia lunar e simbologia da caça na tradição
galaico-portuguesa.)
⸻
1. Descrição  simbólica e narrativa
Nos altos penhascos de Castro Laboreiro, onde o vento é tão antigo quanto o granito e a lua se
reflete inteira nas águas da Peneda, fala-se de um animal que não pertence nem à terra nem ao
céu: o Cervo da Lua. Diz o povo que ele só aparece três vezes por ano — nas noites em que a
lua cheia coincide com nevoeiro cerrado — e que, quando passa, os cães calam-se e as sombras
mudam de lugar.
As versões recolhidas por Eduardo Mauer (2024) descrevem-no como um cervo branco, de
olhos cinzentos e chifres que brilham como prata líquida. A sua pelagem reflete a luz, e quem o
vê tem a sensação de que o corpo se dissolve em névoa. Alguns a firmam que ele não caminha,
mas flutua sobre o terreno, sem deixar pegadas. Outros dizem que surge acompanhado de um
brilho azulado, semelhante ao das auroras frias do inverno.
Segundo os mais velhos de Castro Laboreiro, o Cervo da Lua é o espírito de um antigo caçador
que, arrependido de matar por vaidade, pediu perdão à Deusa da Serra. Esta, compadecida,
transformou-o em cervo imortal para que protegesse as crias e jamais voltasse a derramar
sangue. Desde então, vaga entre os montes, vigiando os caçadores e confundindo os caminhos.
Em outra versão, o Cervo não é guardião, mas mensageiro entre mundos: guia as almas
perdidas pelas serras até a luz da lua. Quando alguém morre longe de casa, o Cervo aparece
diante da janela, imóvel, até o primeiro galo cantar. Acredita-se que, ao segui-lo com os olhos, a
alma encontra caminho de volta à aldeia.
Uma narrativa particularmente poética, recolhida em Lamas de Mouro, conta que o Cervo
aparece diante das crianças que nascem sob o signo lunar de dezembro e que, nessas casas, a
lua nunca falta sobre o telhado. As mães deixam um pedaço de pão e um ramo de urze à porta,
oferenda silenciosa à lua viva da montanha.
Eduardo Mauer escreve: “O Cervo da Lua é o corpo da culpa reconciliado com a claridade. É o
silêncio que aprende a re fletir.”
⸻
2. Contexto histórico e social
O cervo é, desde tempos pré-históricos, um símbolo central nas culturas atlânticas . Gravado
em penedos, pintado em grutas e narrado em cânticos, representa a passagem, o renascimento
e o ciclo das estações. Nas montanhas do norte de Portugal, o cervo sempre foi visto como
animal liminar — simultaneamente selvagem e divino.
O Parque Nacional da Peneda-Gerês, onde se localiza Castro Laboreiro, conserva uma das
populações mais antigas de cervídeos da Península. Desde o período castrejo, o animal está
associado a rituais de caça sagrada, fertilidade e iniciação. Escavações arqueológicas em S.
Julião  de Calvos e Mezio revelaram artefactos com chifres gravados e inscrições lunares,
sugerindo a persistência do culto ao cervo-lua.
Durante a Idade Média, com a cristianização das serras, o mito pagão foi reinterpretado sob o
signo mariano: o Cervo tornou-se figura de pureza e guia espiritual, e o seu brilho lunar passou
a ser visto como símbolo da Virgem. Contudo, a oralidade popular manteve o tom animista,
preservando a ideia do animal como mediador entre os mundos natural e espiritual.


No século XX, o mito foi revitalizado em contextos turísticos e etnográ ficos, mas perdeu o sentido
iniciático original. A sistematização conduzida pela Associação  MILK procura restituir-lhe a
densidade simbólica original, articulando-a com ecologia contemporânea,  espiritualidade laica
e arte ambiental.
⸻
3. Toponímia e variantes locais
Topónimos como “Vale do Cervo”, “Fraga da Lua” e “Corga Branca” persistem na área de
Castro Laboreiro e Lamas de Mouro, indicando associação entre o animal e a luminosidade
noturna. Documentos paroquiais de 1798 referem “a caça do cervo branco das brumas da
Peneda”, possivelmente eco da lenda.
Variantes regionais:
– Em Melgaço, fala-se do “Veado da Senhora”, associado à lua e às aparições marianas.
– Na Galiza, o mito é paralelo ao do “ Ciervo Branco do Xurés”, protetor das fontes e das
árvores encantadas.
– Em Branda da Aveleira, o cervo é descrito como anjo-animal, aparecendo nas madrugadas
geladas para conduzir o rebanho ao abrigo.
A confluência de variantes demonstra a continuidade celto-galaica do mito, fundindo elementos
pagãos, cristãos e ecológicos.
⸻
4. Primeiro relato e fontes académicas primárias
O primeiro registro escrito alusivo ao “cervo da lua” surge em José Leite de Vasconcelos,
Etnografia Portuguesa, vol. XI (1928, pp. 255–263)*, ao mencionar “histórias do cervo branco que
guia viajantes perdidos nas serras de Melgaço”.
Outras fontes relevantes:
– Teófilo Braga, Crenças Populares de Portugal (1902, pp. 431–439): referência a “animais de
luz” que aparecem sob a lua como guias espirituais.
– Alexandre Parafita, Mitologia Popular Portuguesa (2008, pp. 1249–1261): interpretação
simbólica do cervo como “veículo da alma entre mundos”.
– Eduardo Mauer, O Cervo da Lua: Animal e Luz nas Montanhas de Castro Laboreiro (Associação
MILK, 2025): sistematização das recolhas orais e paralelos arqueomitológicos.
Fontes complementares:
– Parque Nacional da Peneda-Gerês, Inventário  de Narrativas da Montanha (1980–2020);
– Museu de Melgaço, Arquivo de Lendas e Ritos da Fronteira (1995–2019);
– Tese de Doutoramento de Marta Figueira, Zoomorfismo Sagrado no Noroeste Ibérico  (U. Minho,
2018).
⸻
5. Síntese interpretativa final
O Cervo da Lua é figura da reconciliação e do retorno. A sua brancura não é pureza ingênua,
mas memória da transformação. Ele encarna o desejo de equilíbrio entre luz e sombra, culpa e
redenção,  caça e contemplação .
Na leitura simbólica da Associação  MILK, o Cervo representa o corpo ecológico
espiritualizado: animal que ensina a relação ética com o ambiente, convocando o humano à

humildade diante do ciclo natural. A lua, espelho da terra, torna-se símbolo de consciência; o
cervo, espelho do humano que aprendeu a ser leve.
A escultura MILK de Eduardo Mauer segue a matriz padrão, reinterpretada em verticalidade
graciosa. O corpo compacto é alongado por chifres prateados que se abrem em forma de lua
crescente. A superfície é branca com véus azulados; pequenas incrustações de quartzo criam o
efeito de cintilação.
Mauer escreve: “O Cervo da Lua é o eco da terra na claridade do céu. Um corpo que aprendeu a
refletir sem ferir.”
⸻
6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer
“O Cervo da Lua é corpo não binário da luz — simultaneamente caça e caçador,
masculino e feminino, animal e espírito.”
Nesta leitura, o cervo dissolve os dualismos entre presa e predador, corpo e alma. Ele
representa o ser em equilíbrio dinâmico , que não domina nem se submete, mas flui. A
leitura contemporânea conduzida por Eduardo Mauer interpreta o mito como convite à
escuta e à empatia interespécies.
A Associação  MILK explora este símbolo no programa “Corpos Luminares”, uma série
de intervenções ambientais noturnas com projeções de luz e som nos vales do Gerês,
celebrando a interdependência entre humanos e animais.
⸻
7. Referência Estrutural da Matriz MILK
Na Matriz Escultórica MILK – Série Folclore Vivo, o Cervo da Lua apresenta:
– Corpo: compacto e ereto, prolongado pelos chifres-lua;
– Cores: branco-nebuloso, azul-prateado e reflexos perolados;
– Materiais: resina translúcida, pó de quartzo e pigmento lunar;
– Expressão:  calma, olhar voltado para cima;
– Base: circular, com leve brilho fosco, remetendo ao disco lunar;
– Eixo curatorial: Corpos de Luz e Travessia, dedicado às figuras luminosas e guias espirituais
do folclore português.
⸻
Localização  específica: Castro Laboreiro, Lamas de Mouro, Parada do Monte (distrito de Viana
do Castelo).
Primeiro relato documentado: Vasconcelos, Etnografia Portuguesa, vol. XI, 1928.
Sistematização  contemporânea:  Eduardo Mauer, O Cervo da Lua: Animal e Luz nas Montanhas
de Castro Laboreiro, Associação MILK, 2025.
Fontes primárias:  Braga (1902); Vasconcelos (1928); Parafita (2008); Figueira (2018); Mauer
(2025).
⸻


---

# 130. A Lenda do Pastor das Sombras de Pitões das Júnias (Montalegre – Serra do Gerês)

**Origem documental:** PDF `folclore português (1).pdf`, enviado pelo utilizador.  
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

130. A Lenda do Pastor das Sombras de Pitões das Júnias (Montalegre – Serra do Gerês)
(Sistematização  contemporânea  conduzida por Eduardo Mauer no âmbito  das pesquisas sobre
Folclore Vivo da Associação  MILK – Movimento de Intervenções e Linguagens Kulturais e Arte,

com base em recolhas orais e documentais realizadas entre 2023 e 2025 em Pitões das Júnias,
Tourém e Cabril, cruzadas com acervos do Ecomuseu de Barroso, do Arquivo Municipal de
Montalegre e séries  paroquiais sobre transumância,  confrarias rurais e ritos de encomendação.)
⸻
1. Descrição  simbólica e narrativa
Os habitantes de Pitões das Júnias dizem que, quando o vento muda de rumo entre o mosteiro
arruinado e a cascata, as sombras ganham ofício. É então que passa o Pastor das Sombras —
figura alta, sem rosto definido, bastão curto e capa de burel que não pesa. Ele não guarda
rebanhos de lã; guarda rebanhos de escuro. Recolhe as sombras espalhadas pelo entardecer,
soprando-as de volta aos corpos que se distraíram do próprio contorno.
Nas versões recolhidas por Eduardo Mauer (2024), o Pastor aparece ao cair da tarde e antes
do primeiro galo. Anda no limite entre a última luz e o início do frio. Quando passa junto às
hortas, as galinhas aquietam-se; quando cruza os lameiros, os cães não ladram — baixam a
cabeça, como se escutassem um silvo quase inaudível. Alguns dizem que apita “para dentro”,
isto é, não com a boca, mas com o peito; o som não se ouve: acalma.
Há quem garanta que sua capa é feita de peles de sombra: pedaços do que as coisas perdem
quando a lua sobe. Um velho de Cidadelhe descreveu a Mauer o encontro: “Vi a minha sombra
afastada de mim, como quando a fogueira dança; o Pastor passou e, com o cajado, trouxe-a de
volta, como quem chama um cordeiro tresmalhado.” Em outras versões, o Pastor recolhe
sombras de lobos para que não assombrem o gado durante a transumância; devolve-as às
matas, “onde o escuro precisa delas”.
Diz a tradição que, quando alguém morre fora de casa, o Pastor recolhe a sombra do ausente e
conduz-lha ao batente, para que a família a reconheça e o luto assente. Se o luto fica leve
demais, os sonhos fazem-se pesados; se o luto pesa excessivamente, os dias não passam. O
Pastor regula esse peso: “É ele quem mede a noite”, resumem as mulheres que velam.
Circula também o causo do aprendiz. Um rapaz, filho de pastor, quis aprender o ofício da
sombra. O Pastor levou-o ao adro do Mosteiro de Santa Maria das Júnias, mostrou-lhe a pedra
fria e disse: “Primeiro aprende a encostar o silêncio; só depois aprenderás a mover o escuro.” O
jovem tentou soprar as sombras apressadamente, e o vento devolveu-lhe poeira nos olhos.
Durante três invernos, aprendeu a ficar. Ao fim, já não precisava ver: ouvia as sombras pela
temperatura do ar.
Outra narrativa, recolhida junto da cascata de Pitões, explica a origem do Pastor: teria sido um
monge que, durante grandes nevões, conduzia aldeões perdidos com uma lanterna de chifres. Ao
morrer no cimo do Larouco, pediu que o deixassem guardando “o lado que falta ao lume” — a
sombra. Desde então, em noites de gelo, vê-se um brilho baixo, como brasa coberta: é o seu
passo breve.
Em todas as variantes, o Pastor das Sombras não  ameaça; apruma. É o ofício de devolver cada
presença ao seu contorno justo. Mauer define: “O Pastor das Sombras é a ética do limite: dá
forma ao que nos sobra e abrigo ao que nos falta.”
⸻
2. Contexto histórico e social
Pitões das Júnias ergue-se num anfiteatro granítico marcado por brandas e inverneiras, fojo dos
lobos, lameiros e veios de água fria. A economia pastoral moldou uma cosmologia do cuidado:
guiar, recolher, guardar. Nessa cultura, não é estranho que o verbo “apascentar” se estenda ao
invisível — sonhos, medos, memórias.


O Mosteiro de Santa Maria das Júnias (origem medieval, tradição eremítica anterior) adiciona
camada simbólica decisiva. A vida monástica — silêncio, regra, medida — contamina o
imaginário local: o Pastor das Sombras parece combinar ascetismo (escuta, contenção) e
pastorícia (guia, recolha). A passagem da encomendação  das almas e de procissões de
finados, documentadas no Barroso, oferece o fundo ritual para um agente liminar que
acompanha e apazigua.
No século XIX, com guerras, contrabando e mudanças de posse, intensi ficam-se histórias de
vigias noturnos; no século XX, com o êxodo rural, o mito tornou-se pedagógico: ensinar
prudência, respeitar noite, neblina, gelo. Hoje, em contexto de turismo de natureza, a figura volta
a converter-se em ética do lugar: caminhar devagar, não projetar luz excessiva, devolver
silêncio às ruínas e à cascata.
Para a Associação  MILK, o Pastor das Sombras integra o eixo “Travessias e Ecos”, como
psicopompo de cotidianidade: não transporta almas ao além; transporta medidas entre corpo e
mundo.
⸻
3. Toponímia e variantes locais
A recolha MILK (2023–2025) registou microtopónimos e designações orais: “Lomba do Pastor”
(vereda acima do mosteiro), “Corga do Cajado” (linha de água onde “a sombra arrefece”),
“Pedra do Sopro” (laje perto da cascata onde os narradores situam aparições). Em Tourém e
Paredes do Rio, variantes nomeiam “Pastor do Frio” e “Homem do Silvo”; em Cabril, fala-se no
“Guardador do Vento Baixo” (sopro que baixa o medo dos rebanhos).
No lado galego, encontram-se paralelos tipológicos: “Pastoreiro da Néboa” (Xurés), que
“apruma as sombras dos caminheiros”, reforçando o caráter transfronteiriço do motivo. Em toda
a família de variantes, persistem três marcas: horário  liminar, ofício de recolha e regulação  do
medo.
⸻
4. Primeiro relato e fontes académicas primárias
Até ao momento, não  se localiza nas grandes coletâneas clássicas (Braga, Vasconcelos) um
verbete sob a designação exata “Pastor das Sombras de Pitões das Júnias”. O que há são
motivos convergentes (figuras noturnas guardadoras, guias de passagem, vigias de veredas).
Para rigor:
	 •	 Primeira fixação  documental consolidada desta variante específica:
Dossiê MILK – Folclore Vivo (Barroso/Gerês): O Pastor das Sombras: medida, silêncio  e
recolha em Pitões das Júnias (recolhas de Eduardo Mauer, 2023–2025: 39 depoimentos
orais geo-referenciados, cadernos de campo, mapa de microtoponímia e fotografia de
lugares de narrativa; acervo interno MILK 2025).
	 •	 Fontes clássicas  de enquadramento tipológico (contexto, não
equivalência literal):
– J. Leite de Vasconcelos, Etnografia Portuguesa (1915–1942, passim): aparições viárias,
guardadores noturnos, “homens de capa” como marcadores de prudência.
– Teófilo Braga, O Povo Português  nos seus Costumes, Crenças e Tradições (1885):
psicopompos populares e ritos de encomendação; vigilâncias liminares.
– Alexandre Parafita, Mitologia Popular Portuguesa (2008): figuras liminares que regulam
medos coletivos e codificam a circulação noturna.
	 •	 Fontes locais e complementares:
– Ecomuseu de Barroso, Coleção  Oral – Vidas e Caminhos do Larouco (1974–2020).
– Arquivo Municipal de Montalegre, séries paroquiais sécs. XIX–XX (anotações sobre
vigílias, procissões e “silvos de recolher”).


Nota metodológica: por não existir (ainda) registo impresso canónico sob o título
atual, a presente entrada assume o estatuto de sistematização  crítica baseada
em oralidade contemporânea veri ficada e paralelos etnográ ficos robustos.
⸻
5. Síntese interpretativa final
O Pastor das Sombras condensa uma ecologia do limite. Num território de contrastes — neve/
verão, penedo/prado, silêncio/água —, ele executa uma tarefa simples e radical: dar casa à
sombra. Devolve contorno aos corpos, peso justo aos lutos, ritmo aos passos.
A pedagogia do mito é preciosa para a vida serrana (e para a contemporaneidade):
	 •	 Atenção  (antes do gesto, escuta-se o ar);
	 •	 Medida (nem luz demais nem de menos: a lanterna baixa para não cegar a
noite);
	 •	 Cuidado (acompanhar, não empurrar; recolher, não arrancar);
	 •	 Ritmo (o entardecer não é pressa, é costura do dia com a noite).
Na leitura simbólica da Associação  MILK, o Pastor é profissão  do invisível. Se o
Cavaleiro das Sombras (n.º 123) é escolta de travessia, o Pastor é curador de contornos.
Onde um garante caminho, o outro garante pertença.
A proposta escultórica de Eduardo Mauer segue a matriz MILK: corpo compacto, ligeira
inclinação à frente (passo curtíssimo), capa como volume dorsal único que, pela luz
rasante, projeta duas sombras — a do corpo e a “sombra recolhida”. O cajado é curto e
arredondado, mais batuta que arma. A cromia combina ardósia mate com velaturas
antracite; na orla da capa, uma linha translúcida âmbar sugere a lanterna branda.
Mauer resume numa frase curatorial: “O Pastor não apaga o escuro; ajusta-o.”
⸻
6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer
“O Pastor das Sombras é corpo não  binário  da claridade: não é luz contra treva, é
relação que permite que ambas coexistam.”
A leitura não binária desloca o mito para fora da dicotomia luz/escuro. A sombra
deixa de ser resíduo; torna-se recurso. O Pastor opera integração : devolve ao
corpo a parte que a pressa perdeu. Em termos de práticas MILK, isto inspira
protocolos de visita a lugares sensíveis (ruínas, cascatas, adros): redução de
ruído, lanternas de baixa intensidade, pausas de escuta, condução  do grupo pelo
ritmo do lugar.
No plano identitário, o Pastor propõe coabitação  de estados: visível/invisível,
presença/ausência, fixo/móvel. Essa coabitação é hoje ferramenta para pensar
cuidados comunitários, saúde mental, luto e pertença territorial.
⸻
7. Referência Estrutural da Matriz MILK
Matriz Escultórica – Série Folclore Vivo (Associação  MILK)
	 •	 Corpo: compacto, inclinado, altura média;


	 •	 Capa: volume dorsal contínuo, borda com inlay translúcido (farol brando);
	 •	 Cajado: curto, circular na ponta (gesto de “tocar o ar”);
	 •	 Cromia: preto-ardósia, antracite; filete âmbar discreto;
	 •	 Materiais: resina pigmentada com pó de ardósia; inserções translúcidas
âmbar;
	 •	 Base: elíptica, com microsulcos paralelos (marcas de passo curto);
	 •	 Eixo curatorial: Travessias e Ecos (figuras de regulação e cuidado do
limiar).
⸻
Localização  específica: Pitões das Júnias (mosteiro, cascata, lameiros e veredas altas), Tourém
e Cabril (distrito de Vila Real).
Primeiro relato documentado (fixação  específica): O Pastor das Sombras: medida, silêncio  e
recolha em Pitões das Júnias (Recolhas de Eduardo Mauer, 2023–2025; acervo MILK 2025).
Corpora e paralelos tipológicos: Vasconcelos (1915–1942, aparições/guardadores); Braga
(1885, psicopompos populares); Parafita (2008, figuras liminares).
Sistematização  contemporânea:  Eduardo Mauer, Pastor das Sombras: Contorno, Luto e Ritmo
na Alta Montanha, Associação MILK, 2025.
⸻


---

# 131. A Lenda da Senhora da Fraga de Vilar de Perdizes e Meixide (Montalegre – Barroso)

**Origem documental:** PDF `folclore português (1).pdf`, enviado pelo utilizador.  
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

131. A Lenda da Senhora da Fraga de Vilar de Perdizes e Meixide (Montalegre – Barroso)
(Sistematização  contemporânea  conduzida por Eduardo Mauer no âmbito  das pesquisas sobre
Folclore Vivo da Associação MILK – Movimento de Intervenções e Linguagens Kulturais e
Arte, com base em recolhas orais e documentais entre 2023 e 2025 em Vilar de Perdizes,
Meixide e Montalegre, cruzadas com acervos do Ecomuseu de Barroso, Arquivo Distrital de
Vila Real, Museu Nacional de Arqueologia e bibliografia etnográ fica sobre lendas marianas
rupestres e cultos sincréticos  da água  e da rocha na região  do Barroso e da Raia transmontana.)
⸻
1. Descrição  simbólica e narrativa
No extremo sul de Vilar de Perdizes, onde o granito se ergue em muralhas e o nevoeiro se move
como véu vivo, encontra-se uma fraga imensa com fenda central — lugar onde, segundo o povo,
apareceu a Senhora da Fraga. O relato mais antigo fala de uma pastora de Meixide que,
perdida entre o gado, avistou na rocha uma figura de luz reclinada, semelhante à sombra de uma
mulher dormindo. A voz dessa figura teria dito: “Aqui estou, onde o silêncio bebe a água.”
As versões orais, recolhidas por Eduardo Mauer (2024), variam: algumas descrevem a Senhora
como moura encantada de cabelos de rio, penteando-se com pente de prata junto à nascente;
outras, como imagem mariana que surge ao cair da tarde, projetando luz sobre o vale. Em
ambas, a pedra e a água são inseparáveis. A fraga “abre-se” quando alguém lhe fala com
ternura, deixando escorrer um fio límpido que “cura olhos e limpa dores”.
Contam as mulheres de Meixide que, em dias de seca, as aldeãs subiam à fraga descalças,
levando cântaros e fitas azuis. Tocavam a rocha com a testa, murmuravam promessas e
esperavam o primeiro orvalho. Quem falasse alto via a pedra fechar-se. Assim, a fraga aprendia
a distinguir o tom da humildade — só a voz baixa fazia brotar a água.
Há também o mito do jovem descrente, que zombou da crença e tentou quebrar a pedra com
martelo. A fraga não cedeu, mas o som ecoou três vezes, e no terceiro golpe o martelo voltou
contra ele, deixando marca no penedo — a “marca da desobediência”, ainda apontada pelos
habitantes como sinal de que “a pedra tem ouvido”.


Nas festas de agosto, ainda se realizam procissões simbólicas até a base da fraga, e velhas de
Vilar de Perdizes costumam recolher pequenas lascas do penedo para guardar nas arcas de
linho, acreditando que “seguram a calma da casa”.
Eduardo Mauer sintetiza: “A Senhora da Fraga é a pedagogia da escuta — o território que só se
abre à voz que não quer dominar.”
⸻
2. Contexto histórico e social
A região do Barroso, com seu relevo acidentado e forte religiosidade popular, constitui um dos
espaços mais densos em narrativas sobre rochas falantes, fontes miraculosas e aparições
femininas. O sincretismo entre o culto mariano e antigas devoções às águas é particularmente
evidente em Vilar de Perdizes, onde ermidas e fontes coexistem com topónimos como Fonte
Santa, Lagoa das Almas e Fraga das Donzelas.
A Senhora da Fraga inscreve-se nesse continuum simbólico: um híbrido entre o culto cristão e
as sobrevivências pré-cristãs ligadas à Deusa-Mãe  telúrica, guardiã das fontes. A penetração do
cristianismo na serra de Larouco, entre os séculos XII e XV, cristianizou os penedos sagrados,
convertendo antigas divindades aquáticas em versões da Virgem Maria. Assim, o gesto de “falar
baixo à pedra” preserva um rito ancestral de comunicação  com a terra, reinterpretado como
oração.
Durante os séculos XVIII e XIX, Vilar de Perdizes tornou-se um centro de romarias e feiras
religiosas, inclusive o famoso Congresso de Medicina Popular, que consolidou a reputação da
freguesia como espaço de saberes mágicos e curativos. Nesse contexto, a Senhora da Fraga
representa a face benigna do encantamento barrosão : o poder feminino que cuida, modera e
ensina.
No século XXI, a lenda tem sido revisitada em contextos de turismo e arte comunitária. O projeto
Folclore Vivo da Associação MILK propõe reler essa tradição como ecologia sensorial, onde a
relação com a pedra e a água expressa modos de sustentabilidade emocional e territorial.
⸻
3. Toponímia e variantes locais
Os moradores identificam o local da lenda como a Fraga da Senhora, próxima à linha de água
conhecida como Corga da Lenda. Há referências orais a “Fraga da Voz” e “Fonte da Luz”,
topónimos não o ficiais, mas preservados na memória coletiva.
Variantes regionais:
– Em Meixide, fala-se na “Senhora do Penedo”, entidade semelhante, ligada a uma fonte que
brota sob as raízes de um carvalho.
– Em Montalegre, registra-se a “Senhora da Pedra”, cuja imagem teria sido encontrada dentro
de um penedo partido.
– Em Tourém, existe a lenda da “Moura da Fonte”, que penteia os cabelos com giesta de ouro —
evidente paralelismo com a Senhora da Fraga.
A recorrência desses motivos con firma o padrão transmontano de sacralização  das rochas e
das águas  femininas, associadas à fertilidade, cura e proteção doméstica.
⸻
4. Primeiro relato e fontes académicas primárias

A primeira menção  documental à devoção à Senhora da Fraga em Vilar de Perdizes aparece
em José Leite de Vasconcelos, Etnografia Portuguesa, vol. X (1927, pp. 180–185)*, onde
descreve “a crença numa Senhora da Fraga, invocada pelas mulheres de Barroso em tempos de
seca”.
Fontes complementares:
– Teófilo Braga, O Povo Português  nos seus Costumes, Crenças e Tradições (1885, pp. 234–
239): referência a “Senhoras das Rochas e Fontes” como remanescência de cultos telúricos.
– Alexandre Parafita, Mitologia Popular Portuguesa (2008, pp. 1125–1136): análise da “Deusa
das Águas” e do processo de cristianização das fontes.
– Eduardo Mauer, Senhora da Fraga: Escuta e Fonte no Barroso (Associação MILK, 2025):
síntese das recolhas contemporâneas, depoimentos e registros fotográ ficos do local.
Fontes locais:
– Ecomuseu de Barroso, Coleção  Oral – Territórios da Água  (1980–2020);
– Arquivo Distrital de Vila Real, série de Romarias e Capelas Rurais (sécs. XIX–XX).
⸻
5. Síntese interpretativa final
A Senhora da Fraga é, antes de tudo, mito de escuta e medida. Ensina que o território
responde à qualidade da voz — o tom humano determina o milagre. É símbolo de reciprocidade:
quem fala com arrogância vê a pedra fechar-se; quem fala com humildade, vê-a abrir-se em
água.
Na leitura simbólica da Associação  MILK, trata-se de uma metáfora da escuta ecológica: a
natureza não se submete, responde conforme o modo de relação. A fraga torna-se espelho da
ética comunitária.
A escultura MILK de Eduardo Mauer traduz essa lógica num corpo compacto, semiaberto, como
se a rocha se dobrasse para ouvir. A fenda central, translúcida, deixa entrever um brilho aquático.
As cores variam entre o cinza-ardósia e o azul-leitoso; o gesto é simultaneamente pétreo e
maternal.
Mauer escreve: “A Senhora da Fraga é a orelha da montanha — a paisagem que aprendeu a
ouvir.”
⸻
6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer
“A Senhora da Fraga é corpo não binário do território: simultaneamente rocha e carne,
silêncio e palavra, mãe e montanha.”
Nesta leitura, a Senhora dissolve fronteiras entre matéria e espírito, natureza e feminino,
passividade e poder. Representa o feminino ativo, que não domina, mas modula. A sua
presença é entre — não é santa isolada nem moura sensual, mas interface de escuta.
A Associação  MILK desenvolve, a partir desse mito, oficinas chamadas “Escutar a
Pedra”, em que artistas e habitantes de Vilar de Perdizes exploram sons subterrâneos,
ressonâncias minerais e gravações de água como práticas artísticas e meditativas. A
lenda converte-se assim em ferramenta contemporânea  de reconexão  sensorial.
⸻
7. Referência Estrutural da Matriz MILK

Na Matriz Escultórica MILK – Série Folclore Vivo, a Senhora da Fraga apresenta:
– Corpo: compacto, vertical, levemente côncavo ao centro (gesto de escuta);
– Cores: cinza-ardósia com véus azulados;
– Materiais: resina mineralizada, pó de granito e resina translúcida azul;
– Expressão:  serena, olhar recolhido;
– Base: irregular, lembrando penedo natural;
– Eixo curatorial: Corpos da Escuta e da Água , dedicado às figuras que representam a
reciprocidade entre voz e natureza.
⸻
Localização  específica: Vilar de Perdizes e Meixide (Montalegre – Barroso, distrito de Vila Real).
Primeiro relato documentado: Leite de Vasconcelos, Etnografia Portuguesa, vol. X, 1927.
Sistematização  contemporânea:  Eduardo Mauer, Senhora da Fraga: Escuta e Fonte no Barroso,
Associação MILK, 2025.
Fontes primárias:  Braga (1885); Vasconcelos (1927); Parafita (2008); Mauer (2025).
⸻


---

# 132. A Lenda do Cão Navegante Fucô (Atlântico Luso-Brasileiro – Entre Minho/Douro e a Costa Norte do Brasil)

**Origem documental:** PDF `folclore português (1).pdf`, enviado pelo utilizador.  
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

132. A Lenda do Cão  Navegante Fucô (Atlântico  Luso-Brasileiro – Entre Minho/Douro e a
Costa Norte do Brasil)
(Sistematização  contemporânea  conduzida por Eduardo Mauer no âmbito  das pesquisas de
Folclore Vivo da Associação  MILK – Movimento de Intervenções e Linguagens Kulturais e Arte,
com base em recolhas orais e documentais realizadas entre 2023 e 2025 em Viana do Castelo,
Caminha, Porto e Aveiro, e no Brasil em Belém  (PA), São  Luís  (MA) e Salvador (BA), cruzadas com
acervos portuários,  museológicos e tipologias etnográ ficas sobre bestiários  marítimos,  cães
encantados, ritos de travessia e memória da emigração  transatlântica.)
⸻
1. Descrição  simbólica e narrativa
Os velhos dos cais ainda contam, com sorriso nos lábios, a história de Fucô, o Cão  Navegante
que atravessava o Atlântico como quem cruza um terreiro – de bordo em bordo, de porto em
porto –, reconhecido pelo sorriso largo e pelo dom raro de fazer sorrir quem o via. Dizem que
não era cão de dono, mas cão de rota: aparecia na amarração antes da largada, instalava-se
junto às espias como se entendesse cabos e correntes, e, na primeira vaga, já estava integrado à
guarnição.
Relatos recolhidos por Eduardo Mauer (2024–2025) em Viana do Castelo e no Porto descrevem-
no de pelagem escura, focinho salgado e olhar âmbar, desses que brilham por baixo de bonés de
marinheiro. O traço inconfundível, porém, era o riso: os cantos da boca erguiam-se num arco
franco, e os dentes, alvos, apareciam não em ameaça, mas em acolhimento – “sorriso de cão
que conhece o mar”, sintetizou um antigo prático do Douro. Diz-se que, ao primeiro enjoo dos
grumetes, Fucô encostava o corpo às botas dos rapazes e, com aquele riso, domava o
estômago e o medo.
A narrativa tem modos diferentes consoante a margem do oceano. No Minho e no Douro, Fucô
é “cão de água” que pressente maresia e mudança de vento; dá três voltas no convés antes da
virada de tempo e deita-se voltado para a proa quando a rota está “certa”. Na Amazónia e no
Maranhão , torna-se “cão de maré” que lê a cor da água : se a lama é mais densa, avisa para
esperar; se vem esverdeada e viva, abana a cauda e “autoriza” a subida do rio.


Uma versão ouvida em Belém do Pará  conta que Fucô teria salvado um batelão durante uma
pororoca: apoiado no tolete, ladrou três vezes contra a parede de água e, no silêncio seguinte,
todos remaram para o lado que o cão olhou. Outra, de São  Luís, diz que Fucô sabia travessias
de alma: acompanhava de longe as barcas funerárias que cruzavam igarapés estreitos e, ao final,
ficava imóvel no trapiche, “segurando” o choro dos que esperavam.
Em Caminha circula o episódio do “sorriso contra a tormenta”: marinheiros às voltas com
ondulação brava viram Fucô, encharcado, com a língua de fora e o riso inteiro – e juram que, de
repente, o medo perdeu o dente. Desde então, reza o dito: “Quando Fucô ri, o mar lembra-se de
poupar.”
Há quem sustente que Fucô nasceu de uma promessa de duas margens: pescadores minhotos
teriam pedido, em noite de nevoeiro, que o Rio Lima lhes devolvesse um filho; na outra banda do
Atlântico, à beira do Guamá, uma mãe rogava pela chegada do marido. O mar, que odeia
promessas soltas, teria parido um cão para costurar destinos. Daí o riso: ponte viva entre
saudade e porto.
Mauer registra um refrão de boca de cais, repetido como bênção: “ Fucô, dá-nos  teu riso / que o
sal fique doce e o regresso, viso.”
⸻
2. Contexto histórico e social
A lenda de Fucô nasce e cresce no mundo atlântico  luso-brasileiro, espaço de longa duração
onde se cruzam emigração, cabotagem, pesca longínqua, comércio de sal e cacau, e
deslocamentos afetivos. Cães  embarcados são presença antiga – para controle de pragas,
guarda e, sobretudo, companhia. O “cão do navio” é figura liminar: nem passageiro, nem carga;
tripulante de outra ordem, cuja função principal é civilizar o medo.
Entre os séculos XIX e XX, com a intensi ficação da emigração do Minho e de Trás-os-Montes
para o Brasil, portos como Viana, Leixões e Porto tornaram-se palcos de despedidas e de
retornos raros. A literatura de viagem e a memória oral registram rituais de boa sorte: tocar a
amurada três vezes, levar pão bento, recolher uma pedra do cais. Inserido nessa gramática de
proteção, Fucô opera como talisman vivo: o riso que desarma o mau agoiro, a proximidade
calorosa que humaniza um espaço de aço e intempérie.
Em águas brasileiras, a lenda absorve o vocabulário  amazónico e nordestino (marés,
pororocas, canais, ventos térmicos), e Fucô converte-se em interprete de águas . Na oralidade
dos trapiches, o cão navegante faz a ponte entre o engenho técnico da navegação  (ler céu,
ondas, corrente) e o engenho afetivo (manter coeso o ânimo da tripulação).
Para a Associação  MILK, Fucô condensa uma ética da hospitalidade marítima: lembrar que
todo navio é casa provisória, e todo porto, escola de cuidado. O riso – que nos relatos é atributo
ativo – transforma-se em dispositivo comunitário : a psicologia do bordo reconhece no cão uma
tecnologia emocional antes de a ciência lhe dar nome.
⸻
3. Toponímia e variantes locais
A cartografia afetiva recolhida por Mauer mapeia designações orais como “Cais do Fucô” (trecho
do molhe velho em Viana do Castelo), “Laje do Cão”  (pedra de espera na barra do Douro),
“Poita do Riso” (alcunha de uma poita em Aveiro), “Trapiche do Cão  Risonho” (modo como
dois narradores de Belém chamam um pontão de madeira). Tais topónimos não  figuram
oficialmente em cartas náuticas, mas persistem na fala de práticos e barqueiros, indício de
vinculação  simbólica ao trabalho marítimo.


Variantes narrativas:
	 •	 Fucô, o Guia de Bruma (Viana/Porto): aparece apenas em nevoeiros
fechados; ladeia a amurada e rosna baixo quando a proa “pede espera”.
	 •	 Fucô, o Cão  de Maré (Belém/São Luís): ladra para a corrente contrária;
cala-se quando a janela de subida abre.
	 •	 Fucô, o Cão  de Promessa (Salvador): acompanha embarcações que
levam promessas a igrejas costeiras; deita-se diante do altar e “sorri para a imagem”.
A constância  do sorriso atravessa todas as versões como assinatura ontológica: não é
simples antropomorfismo; é função  ritual – dispersar pânico, quebrar o feitiço do mau
tempo, fazer sorrir o outro para que o corpo recupere ritmo.
⸻
4. Primeiro relato e fontes académicas primárias
Até ao momento, não  há  um verbete canónico nos grandes repertórios oitocentistas/
novecentistas com a designação explícita “Cão  Navegante Fucô”. Por rigor, distinguem-se:
Primeira fixação  documental consolidada desta variante (denominação  e corpus):
	 •	 Dossiê MILK – Folclore Vivo (Atlântico  Luso-Brasileiro): Fucô, o Cão
Navegante: riso, rota e hospitalidade de bordo (recolhas de Eduardo Mauer, 2023–2025:
52 depoimentos orais entre Viana, Porto, Aveiro, Belém, São Luís e Salvador; cadernos de
bordo de três mestres de cabotagem; inventário de topónimos orais; acervo MILK 2025).
Fontes primárias  e analíticas de enquadramento tipológico (paralelos, não  equivalência
literal):
	 •	 J. Leite de Vasconcelos, Etnografia Portuguesa – referências a bestiários
marítimos e crenças de bordo (figuras protetoras, animais guias).
	 •	 Teófilo Braga, O Povo Português  nos seus Costumes, Crenças e Tradições
– notas sobre amuletos náuticos  e seres auxiliares no imaginário atlântico.
	 •	 Luís da Câmara  Cascudo, Dicionário  do Folclore Brasileiro – entradas
relativas a animais encantados, “cães de engenho” e crenças de porto, pertinentes como
matriz luso-brasileira de circulação de motivos.
	 •	 Arquivos portuários  e museológicos locais (relatos de práticos,
almanaques náuticos, jornais de cais) como lastro documental para a presença
tradicional de cães embarcados e narrativas de proteção.
Nota metodológica: onde a designação “Fucô” não aparece nas compilações clássicas,
a presente sistematização ancora-se na oralidade contemporânea  verificada (2023–
2025) e em paralelos etnográ ficos robustos sobre cães protetivos e crenças de bordo
no Atlântico luso-brasileiro.
⸻
5. Síntese interpretativa final
Fucô não  é mascote: é um ofício. O seu riso estabiliza a tripulação, regula a respiração coletiva,
recompõe o tempo humano dentro do tempo do mar. Como todo mito portuário, cumpre função
pragmática : manter o ânimo, conter o pânico, criar comunidade num espaço temporário. O cão
que ri dissolve hierarquias; aproxima capitão e grumete sob o mesmo gesto: “olha como ele
sorri…  vamos conseguir.”
Na leitura simbólica da Associação  MILK, Fucô encarna uma poética da hospitalidade: acolher
a vulnerabilidade alheia com um sinal simples, o sorriso. O sorriso não é ornamento; é técnica
relacional. O cão torna-se agente de descanso (no sentido de dar descanso ao medo),
convertendo o convés num lugar habitável.


A proposta curatorial traduz isso em práticas: “ Rituais de Bordo Suave” (círculos de respiração
antes da largada), “Inventário  de Sorrisos” (memórias de cais como recurso emocional), “Cartas
de Maré Afetiva” (mapas de portos e pessoas que receberam o riso de Fucô).
⸻
6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer
“Fucô é corpo não  binário  do Atlântico: nem fera nem humano, nem carga nem tripulante;
interface entre técnica e afeto.”
O cão navegante dissolve oposições: animal/artefato, trabalho/cuidado, profissional/
intuitivo. O riso, longe de ‘humanizar’ o animal, animaliza a nossa empatia – devolve-
nos uma competência primeira: coabitar. Na pedagogia MILK, Fucô inspira protocolos de
cuidado em mobilidade (no mar, na rua, na escola): a atenção e o humor como
infraestrutura emocional.
⸻
7. Referência Estrutural da Matriz MILK
Matriz Escultórica – Série Folclore Vivo (Associação  MILK)
	 •	 Corpo: compacto e arredondado (estabilidade de convés), tronco
ligeiramente avançado (prontidão).
	 •	 Focinho/Boca: desenho em arco sorridente, com leve abertura, sem
agressividade; dentes discretos (sinal de acolhimento).
	 •	 Textura: superfície com micro-estrias onduladas (peles de água e vento).
	 •	 Cromia: azul-anil profundo com velaturas de sal (brancos finos) e reflexos
âmbar nos olhos.
	 •	 Base: placa oval com sulcos paralelos (tábuas do convés) e um pequeno
ressalto a proa.
	 •	 Materiais: resina pigmentada com pó de fibra náutica e micro-partículas
peroladas (efeito de sal seco).
	 •	 Eixo curatorial: Travessias e Hospitalidades – figuras que transformam
mobilidade em cuidado.
⸻
Localização  específica (circuitos de narrativa):
	 •	 Portugal: Viana do Castelo, Caminha, Porto/Leixões, Aveiro.
	 •	 Brasil: Belém (PA), São Luís (MA), Salvador (BA).
Primeira fixação  documental desta variante: Fucô, o Cão  Navegante: riso, rota e hospitalidade
de bordo (recolhas de Eduardo Mauer, 2023–2025; acervo MILK 2025).
Corpora e paralelos tipológicos: Vasconcelos (bestiários marítimos; crenças de bordo), Teófilo
Braga (amuletos e seres auxiliares), Câmara Cascudo (animais encantados e crenças portuárias
no Brasil).
Sistematização  contemporânea:  Eduardo Mauer, Fucô e a Ética  do Riso de Bordo:
Hospitalidade em Ambientes de Risco, Associação MILK, 2025.
⸻


---

# 133. A Lenda do Bicho-Barco do Rio Minho (Caminha – A Guarda, fronteira luso-galega)

**Origem documental:** PDF `folclore português (1).pdf`, enviado pelo utilizador.  
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

133. A Lenda do Bicho-Barco do Rio Minho (Caminha – A Guarda, fronteira luso-galega)
(Sistematização  contemporânea  conduzida por Eduardo Mauer no âmbito  das pesquisas sobre
Folclore Vivo da Associação  MILK – Movimento de Intervenções e Linguagens Kulturais e Arte, a
partir de recolhas orais e documentais entre 2023 e 2025 em Caminha, Vila Nova de Cerveira e A
Guarda (Espanha), cruzadas com acervos do Museu do Mar de Caminha, Arquivo Municipal de
Cerveira, Museo do Mar de Galicia e Ecomuseu do Alto Minho; confrontadas com estudos
etnográ ficos sobre bestiários  fluviais, mecânicas  míticas  de travessia e imaginário  transfronteiriço.)
⸻
1. Descrição  simbólica e narrativa
Entre as águas do rio Minho, que ora é fronteira, ora espelho, conta-se a história do Bicho-
Barco, criatura de madeira e carne, meio embarcação meio animal, que navega sozinho nas
madrugadas de neblina, subindo e descendo o curso conforme o humor das marés. Os
pescadores de Caminha afirmam ouvir, por vezes, um estalido de remos sem remador e o
ranger de quilha a cortar a corrente: é o sinal de que o Bicho-Barco saiu da foz para “pastorear
almas cansadas de esperar a passagem”.
As descrições recolhidas por Eduardo Mauer (2024–2025) convergem em certos traços: o casco
lembra carvalho antigo, coberto de algas; da proa, porém, emerge um olho luminoso que se
acende e apaga como farol vivo; o convés respira, dilatando-se ao ritmo da maré. Quando o
nevoeiro é espesso, ouve-se um som baixo, mistura de apito e suspiro – “o ressonar do Bicho”.
A narrativa galega diz que o ser nasceu de um barco naufragado em 1580, cuja madeira,
resgatada e deixada a secar na praia, ganhou alma ao receber lágrimas de sete viúvas de
marinheiros. Desde então, o Bicho-Barco ronda o estuário, levando mensagens entre margens.
Se encontra alguém em apuros, aproxima-se silencioso e encosta-se ao cais; quem sobe sem
medo chega ao outro lado antes do amanhecer. Quem hesita, fica preso em círculos de corrente.
No lado português, há quem diga que o Bicho não transporta pessoas, mas recados: cartas não
escritas, promessas por cumprir. Por isso, pescadores deixam pedaços de pano amarrados em
remos ou fitas de sardinha seca – ofertas de apaziguamento. A embarcação-ser é também
espelho moral: reconhece quem atravessa por amor e recusa quem o faz por ganância.
Uma variação recolhida em Lanhelas fala de uma rapariga que se lançou ao rio para seguir o
namorado galego e foi salva pelo Bicho-Barco, que a trouxe à margem portuguesa, dizendo:
“Amar não é atravessar: é aprender o meio da água.” O tom moralizante suaviza-se noutras
versões, nas quais o Bicho é simples guardião  da fronteira viva, que impede o rio de morrer
quando os homens o fecham com barragens e medo.
Mauer anota: “O Bicho-Barco é o Atlântico em miniatura – corpo de travessia, máquina de
saudade.”
⸻
2. Contexto histórico e social
O vale do Minho é, desde a Antiguidade, território de intercâmbio  e migração . Entre feiras,
contrabandos e casamentos mistos, a fronteira foi mais permeável do que se supõe. O rio, eixo
de economia e de identidade, tornou-se também linha de tensão  simbólica: cada margem
projeta no espelho da outra seus medos e desejos.
O imaginário do barco encantado é recorrente no Noroeste ibérico. De San Brandán  ao “barco
das almas” do Xurés, as narrativas partilham o tema da embarcação  autônoma que conduz
vivos e mortos, recordando a travessia espiritual. O Bicho-Barco sintetiza esses motivos, mas

transfere-os para o plano fluvial: não atravessa oceanos, atravessa intervalos humanos – o
adormecer, o luto, a saudade.
No século XIX, com a intensi ficação da pesca e do comércio transfronteiriço, as margens viram
surgir superstições específicas de travessia: silêncios antes de empurrar o batel, proibições de
chamar o companheiro pelo nome dentro do rio, oferendas a “senhores das águas”. A lenda do
Bicho-Barco cristaliza essas práticas, dando-lhes corpo narrativo.
Hoje, o mito serve de símbolo partilhado de identidade luso-galega: festas, exposições e
roteiros culturais recuperam a figura como metáfora de cooperação entre margens. Para a
Associação  MILK, é paradigma da sustentabilidade simbólica de fronteira – o reconhecimento
de que o fluxo é condição de vida.
⸻
3. Toponímia e variantes locais
A recolha MILK 2025 regista topónimos orais: “Poço do Barco”, “Enseada do Olho”, “Corga
das Viúvas”, “Baía do Silvo” – todos vinculados a Caminha e Lanhelas. No lado galego,
persistem “Praia do Barco Vivo” e “Monte das Mensaxes” (A Guarda).
Variantes:
– O Barco das Viúvas (A Guarda): conduz lamentos femininos até ao mar aberto.
– O Barco da Néboa  (Caminha): aparece apenas em madrugadas sem lua; quem o vê perde por
instantes a sombra.
– O Bicho do Estuário  (Cerveira): mistura de peixe e batel; mergulha quando alguém profere
blasfémia.
⸻
4. Primeiro relato e fontes académicas primárias
Primeira fixação  documental consolidada:
	 •	 Dossiê MILK – Folclore Vivo (Norte Atlântico) : O Bicho-Barco do Minho:
travessia, fronteira e voz das águas  (recolhas de Eduardo Mauer, 2023–2025: 41
testemunhos orais geo-referenciados, mapa de microtoponímia e registo fotográ fico do
estuário; acervo MILK 2025).
Fontes de enquadramento tipológico:
– J. Leite de Vasconcelos, Etnografia Portuguesa, vol. XI (1928, pp. 266–274): “barcos
encantados e barcas das almas”.
– Teófilo Braga, Crenças Populares de Portugal (1902, pp. 447–452): referências a “bestiários
das águas fluviais”.
– Alexandre Parafita, Mitologia Popular Portuguesa (2008, pp. 1262–1275): análise do “barco
autónomo como símbolo de passagem”.
– Manuel Gandra, Os Mitos do Limiar Atlântico  (2014): discussão sobre rituais de travessia e
fronteiras simbólicas.
Fontes complementares:
– Museu do Mar de Caminha, Coleção  Oral – Histórias de Pescadores do Baixo Minho (1970–
2020);
– Museo do Mar de Galicia, Relatos do Xurés  e da Guarda (1995);
– Tese de Isabel Coutinho, Rios Fronteira e Imaginários  de Passagem (U. do Minho, 2017).
⸻
5. Síntese interpretativa final

O Bicho-Barco corporifica a metáfora  da travessia como relação ética. Ele ensina que
atravessar não é conquistar o outro lado, mas dialogar com a corrente. A embarcação viva
questiona a fronteira política: onde começa e acaba um rio que tem voz?
Na leitura simbólica da Associação  MILK, o mito opera como ecologia da permeabilidade –
reconhecimento da interdependência entre margens. O ser híbrido (barco/animal) propõe uma
visão não binária de pertença: cada margem contém a outra.
A escultura MILK concebida por Eduardo Mauer mantém a matriz padrão , adaptando-a ao
movimento fluvial: corpo alongado, proa-cabeça levemente erguida, fenda luminosa (o olho).
Textura em estrias horizontais, cores azuis e ferrugem. Quando iluminada, a peça projeta reflexo
ondulante, simulando maré.
Mauer escreve: “O Bicho-Barco é a fronteira que aprendeu a respirar. Se o mundo deixar de fluir,
ele deixa de existir.”
⸻
6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer
“O Bicho-Barco é corpo não binário da fronteira: nem barco nem bicho, nem morto nem
vivo, mas trânsito constante.”
A leitura contemporânea sublinha a fluidez identitária  e a coexistência dos opostos:
tecnologia (barco) e biologia (animal), margem portuguesa e galega, matéria e voz. O ser
hibridiza-se para preservar relação.
Na pedagogia MILK, o mito inspira laboratórios de escuta transfronteiriça entre
comunidades ribeirinhas, explorando gravações sonoras do rio, performances de
travessia silenciosa e criações colaborativas sobre o conceito de “andar-água” .
⸻
7. Referência Estrutural da Matriz MILK
Matriz Escultórica – Série Folclore Vivo (Associação  MILK)
	 •	 Corpo: alongado, base compacta; curva de proa elevada (cabeça).
	 •	 Cores: azul-acinzentado com véus ferrugíneos e re flexos de cobre.
	 •	 Materiais: resina náutica, pó de madeira, pigmento de óxido de ferro.
	 •	 Textura: estriada, evocando casco e escamas.
	 •	 Expressão:  olho central translúcido; ausência de boca (fala pela água).
	 •	 Base: elíptica ondulada, lembrando ondulação de rio.
	 •	 Eixo curatorial: Travessias e Fronteiras Vivas – entidades que habitam o
entre-margens.
⸻
Localização  específica: Estuário do Rio Minho (Caminha – A Guarda).
Primeiro relato documentado: O Bicho-Barco do Minho: travessia, fronteira e voz das águas
(Eduardo Mauer, 2025, acervo MILK).
Fontes primárias:  Vasconcelos (1928); Braga (1902); Parafita (2008); Gandra (2014); Coutinho
(2017).
⸻


---

# 134. A Lenda do Anjo da Neve de Montalegre (Larouco – Barroso, Trás-os-Montes)

**Origem documental:** PDF `folclore português (1).pdf`, enviado pelo utilizador.  
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

134. A Lenda do Anjo da Neve de Montalegre (Larouco – Barroso, Trás-os-Montes)
(Sistematização  contemporânea  conduzida por Eduardo Mauer no âmbito  das pesquisas sobre o
Folclore Vivo da Associação MILK – Movimento de Intervenções e Linguagens Kulturais e
Arte, com base em recolhas orais e documentais entre 2023 e 2025 em Montalegre, Padornelos e
Serra do Larouco; cruzadas com acervos do Ecomuseu de Barroso, Arquivo Distrital de Vila
Real, Museu de Arqueologia D. Diogo de Sousa (Braga) e tese de Maria Adelina Moura, As Marias
do Nevoeiro e as Águas  da Serra (U. do Minho, 2018).)
⸻
1. Descrição  simbólica e narrativa
Entre as neves perenes do Larouco, narra-se a aparição de uma figura de luz translúcida — o
Anjo da Neve — que surge nas madrugadas de geada e se desfaz ao primeiro som humano. Não
é mensageiro do céu nem espírito dos mortos: é o eco branco do silêncio, o que veste a
montanha para que o mundo descanse.
As versões recolhidas por Eduardo Mauer (2024–2025) descrevem-no como uma criança alta,
de rosto sem idade, olhos azul-acinzentados e asas que parecem feitas de cristais de gelo
suspensos. Quando respira, o ar condensa-se em anéis que caem no chão e se tornam flores de
neve. O passo é tão leve que não deixa rasto; só um som, semelhante a sino longínquo,
acompanha a sua passagem.
Os pastores dizem que o Anjo aparece quando o frio “pede compaixão”, aquecendo sem tocar.
Conta-se que em invernos rigorosos ele descia até as aldeias, rondando currais e lareiras. Em
Padornelos, uma mulher velha afirmou ter visto o Anjo entrar-lhe pela porta rachada, tocar o
berço do neto febril e deixá-lo dormir sem mais delírio. Quando o povo correu para agradecer,
encontrou apenas pegadas de água .
Há quem diga que o Anjo é filho da própria montanha. Nasce de cada primeira neve e morre no
degelo; por isso nunca tem nome. Outros afirmam que é moura desencantada que escolheu não
regressar à primavera, guardando a pureza fria da altitude. Um lavrador de Montalegre narrou a
Mauer: “Vi-o no cume, não tinha sombra. Sorriu e o vento parou. Depois, a neve caiu em círculos
como se o céu respirasse devagar.”
O Anjo da Neve é protetor dos viajantes perdidos. Os mais antigos aconselham: se o nevoeiro se
fechar e se ouvir som de sino, parar e esperar; o Anjo indica o caminho por reflexos, fazendo
brilhar cristais na direção certa. Quem tenta segui-lo de perto perde-se, pois o ser existe apenas
à distância segura do espanto.
⸻
2. Contexto histórico e social
O planalto do Larouco é um dos pontos mais altos de Portugal continental, espaço de
transumância, isolamento e espiritualidade natural. O clima rigoroso moldou hábitos de
resiliência comunitária , e o frio extremo adquiriu valor sagrado. Desde a Idade Média,
documentos de montaria e livros de viagem referem “mulheres brancas que guiam pastores”,
“neves que curam febres” e “luzes de inverno que se movem com consciência”.
Durante séculos, o povo de Barroso interpretou a neve como manto protetor — símbolo da
suspensão do tempo agrícola e oportunidade de renovação espiritual. O Anjo da Neve traduz
essa concepção: uma pausa cósmica entre a labuta e o repouso.
Em registos setecentistas do Arquivo Distrital de Vila Real (“Relatórios de Desamparo”, 1754),
menciona-se “uma aparição branca no cume, vista por rebanheiros”, tomada então por “milagre

de penitência”. No século XIX, Leite de Vasconcelos e, mais tarde, Teófilo Braga recolheram
alusões a “anjos do gelo” e “mães da neve”, mitos de função climatológica e moral.
No século XX, a modernização rural e o declínio da transumância quase apagaram o relato, que
reaparece nos anos 1980 em compilações locais e, a partir de 2023, nas pesquisas de Eduardo
Mauer, revalorizado como património de ecologia espiritual.
⸻
3. Toponímia e variantes locais
Os habitantes identificam vários lugares associados: Fraga do Anjo, Fonte Fria, Vale do Silvo e
Corga das Brancas.
Variantes:
– A Menina da Neve (Montalegre): figura que recolhe as últimas lágrimas do inverno.
– A Branca do Larouco (Padornelos): mulher que tece o frio para proteger os campos.
– O Vozio do Anjo (altiplano galego): neblina sonora que fala em tom infantil.
A semântica da cor branca e o vocabulário meteorológico aproximam estas versões,
consolidando uma cosmologia em que a pureza climática  é também pureza moral.
⸻
4. Primeiro relato e fontes académicas primárias
Primeira menção  explícita: Leite de Vasconcelos, Etnografia Portuguesa, vol. VIII (1926, pp.
201-206)* – referência a “anjos do frio e das neves do Barroso”.
Fontes complementares:
– Teófilo Braga, O Povo Português  nos seus Costumes, Crenças e Tradições (1885).
– Alexandre Parafita, Mitologia Popular Portuguesa (2008, pp. 1358-1364).
– Maria Adelina Moura, As Marias do Nevoeiro e as Águas  da Serra (U. do Minho, 2018).
– Eduardo Mauer, O Anjo da Neve e o Silêncio  da Montanha (Associação MILK, 2025).
Fontes locais: Ecomuseu de Barroso – Arquivo Oral: Histórias de Inverno (1980-2020).
⸻
5. Síntese interpretativa final
O Anjo da Neve é arquétipo de pureza e lentidão : força que convida ao recolhimento. Simboliza
o equilíbrio entre presença e ausência, calor e gelo, movimento e suspensão. Ao transformar o
frio em gesto protetor, o mito ensina uma ética da pausa.
Na leitura da Associação  MILK, é metáfora do cuidado silencioso. O Anjo não interfere; regula.
Representa o espaço de transição entre o humano e o natural, onde a vulnerabilidade se torna
sabedoria.
A escultura MILK de Eduardo Mauer reinterpreta-o como corpo compacto, branco-leitoso, com
pequenas incrustações de cristal. O rosto, quase liso, reflete luz; o tronco ergue-se em leve
inclinação, gesto de amparo.
Mauer escreve: “O Anjo da Neve é o frio que aprendeu a ser ternura.”
⸻


6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer
“O Anjo da Neve dissolve o género: é neve que sente, é corpo que se apaga.”
Na leitura não binária, a figura representa neutralidade e transparência — um corpo que
não reivindica identidade fixa. A pureza não é moral, é fenoménica: possibilidade de existir
sem fronteiras rígidas.
Nas práticas pedagógicas MILK, o mito inspira laboratórios de “escuta do silêncio” e
oficinas sobre tempos lentos, incentivando a atenção plena como forma de resistência à
aceleração contemporânea.
⸻
7. Referência Estrutural da Matriz MILK
Matriz Escultórica – Série Folclore Vivo (Associação  MILK)
	 •	 Corpo: compacto, vertical, com leve curvatura frontal (acolhimento).
	 •	 Cores: branco-leitoso, tons de azul-gelo e transparências.
	 •	 Materiais: resina translúcida com microcristais; base espelhada.
	 •	 Textura: lisa, fria ao toque visual.
	 •	 Expressão:  olhos semicerrados, boca mínima.
	 •	 Eixo curatorial: Corpos do Silêncio e da Lentidão  – figuras que
encarnam a pausa e o cuidado.
⸻
Localização  específica: Serra do Larouco – Montalegre (Trás-os-Montes).
Primeiro relato documentado: Leite de Vasconcelos, Etnografia Portuguesa, vol. VIII, 1926.
Sistematização  contemporânea:  Eduardo Mauer, O Anjo da Neve e o Silêncio  da Montanha,
Associação MILK, 2025.
⸻


---

# 135. A Lenda da Serpente do Tâmega  (Amarante – Marco de Canaveses, Vale do Tâmega)

**Origem documental:** PDF `folclore português (1).pdf`, enviado pelo utilizador.  
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

135. A Lenda da Serpente do Tâmega  (Amarante – Marco de Canaveses, Vale do Tâmega)
(Sistematização  contemporânea  conduzida por Eduardo Mauer no âmbito  do projeto Folclore
Vivo da Associação MILK – Movimento de Intervenções e Linguagens Kulturais e Arte, a
partir de recolhas orais (2023–2025) em Amarante (Cepelos/Lomba, Gatão, S. Gonçalo) e
Marco de Canaveses (Soalhães, Tabuado), cruzadas com acervos do Arquivo Municipal de
Amarante, Rota do Românico e bibliografia etnográ fica/mitográ fica sobre moura-serpente,
bestiários  fluviais e sacralização  de rochas e águas  no Noroeste peninsular.)
⸻
1. Descrição  simbólica e narrativa
No troço médio do rio Tâmega , onde o curso se estreita entre penedos e a corrente devolve
ecos às pontes, circula a narrativa da Serpente do Tâmega : uma entidade híbrida —
simultaneamente bicho de água  e moura encantada — que emerge em madrugadas de neblina
junto a fragas com marcas circulares e fontes que “cantam” após longas estiagens. Nas versões
colhidas por Eduardo Mauer em Cepelos/Lomba (Amarante) e Soalhães  (Marco), a serpente
aparece algures entre o humano e o fluvial: corpo longo e escuro, cabeça com luz baça “como
pedra molhada”, crina de algas que lhe cai pelas “costas” e um pente de prata preso nos fios —

sinal inequívoco da moura que, em anos de “lua-cheia-pousada”, se manifesta em forma de
cobra-mulher para guardar o que dorme na pedra e no leito do rio.
Conta-se que de sete em sete anos a Serpente desliza da fraga para a margem, sobe até um
terreiro semeado de giestas e penteia-se. Quem a surpreender sem medo e lhe entregar uma
palavra “redonda e limpa” (fórmula ritual que as informantes chamam “a palavra de bênção”)
merece três dádivas : segurança na travessia, água em tempo seco e sonho sem pesadelos para
as crianças. Mas se alguém quebrar o silêncio ou atirar pedra, o rio “toma de volta” a luz —
apagam-se as lamparinas, os remos falham, e o nevoeiro “garra” a ponte.
Uma versão amarantina situa a serpentária sob o Penedo da Moura (Fontelas/Monte), dizendo
que a moura “se funde com a cobra” quando desce a maré da noite, e que o brilho que a gente
julga luar é, às vezes, o dorso da Serpente a cortar a água . Em Gatão  (Rainha), narram que a
“Rainha do Penedo” desce a olhar o Tâmega nas noites de calor extremo; quando se deita na
rocha, o rio arrefece “um palmo” — indício de que a serpente-moura regula a temperatura da
água  e, com isso, o humor dos peixes e a sorte das redes.
Há ainda um episódio “de ponte”, recitado por barqueiros e retomado por professores locais:
num verão antigo, a Serpente, irritada com brigas de vizinhança, enrolou-se nos pegões e travou
a passagem das barcas; S. Gonçalo teria então engendrado um estratagema “de luz e cão”, para
desfazer o feitiço e libertar o curso — a memória popular funde aqui dois ciclos: o das pontes de
S. Gonçalo e o da moura-serpente que tutela a água. (A tradição das “pontes negociadas com
o Diabo”, firmemente associada a Amarante, fornece o pano de fundo moral da trégua entre
santo e rio.)
No Marco de Canaveses, junto a Soalhães/Tabuado , a Serpente é menos “moura” e mais besta
de nado, espécie de enguia colossal que se enrola nas raízes de amieiros e “fala por
borbulhas”. Pede respeito de margem (não lavar com sabão forte nas levadas, não cuspir nas
fontes) e licença de passagem aos canoeiros. A quem cumpre, oferece “espelho claro”: a água
perde a cor de ferrugem e “mostra fundo”.
Em todas as variantes, a Serpente do Tâmega  não é monstro devorador; é pedagogia de rio:
regula o gesto humano junto da água, premiando a medida (silêncio, limpeza, licença) e
castigando o excesso (gritos, lixo, pedra vã). Na formulação de Mauer: “A serpente é a
gramática do Tâmega — ensina a frase certa para falar com a corrente.”
⸻
2. Contexto histórico e social
O vale do Tâmega concentra, desde a Idade Média, topografias sagradas (pontes, penedos
singulares, fontes “de virtude”) e um código ribeirinho de etiqueta (horas de lavar, silêncio de
véspera, interditos de noite) que a oralidade traduz em mitos de moura-serpente e bichos de
água . A associação da moura à cobra (a “moura-serpente”) é um motivo clássico  no Noroeste
ibérico: a encantada “muda de pele” para habitar a fraga e o curso, guarda tesouros (ouro, saber
da água), desencanta por palavra ou beijo e reaparece de sete em sete anos — ciclo que, no
Tâmega, foi recontextualizado como cuidado do rio (abrir/fechar nascentes, refrear cheias,
limpar remoinhos).
No concelho de Amarante, lendas de penedos com mouras (Penedo da Moura/Fontelas;
Penedo da Rainha/Gatão) estão explicitamente ligadas ao Tâmega  — “a rainha contempla o
rio”/“a moura guarda o penedo do alto sobre as águas” — e formam um cinturão  simbólico que
enquadra a ponte de S. Gonçalo e o casario ribeirinho. Essas narrativas, recolhidas e divulgadas
em repositórios locais, consolidam a imagem do rio como eixo de encantamento feminino que
penteia a paisagem, literalmente, com o seu pente de prata.


Mais a jusante, em território do Rota do Românico  (Marco de Canaveses), a documentação
sobre Soalhães/Tabuado  fixa a antiguidade do povoamento e dos sítios devocionais que
costuram o vale, propondo para o “código ribeirinho” um lastro histórico de longa duração
(templos, passagens, ofícios). Estas persistências ajudam a explicar a resiliência do motivo
serpentário no quotidiano das margens.
Em chave comparada, estudos sobre religiosidades pré-cristãs  no Norte (Portugal/Galiza)
mostram a continuidade simbólica de rocha–fonte–serpente–feminino sagrado e os processos
de cristianização  (ermidas, cruzes, festas) que absorvem sem apagar os velhos sinais —
quadro no qual a Serpente do Tâmega  se lê hoje como interface ecológica: não demoniza o
rio; corrige a relação .
⸻
3. Toponímia e variantes locais
Toponímia oral cartografada (2023–2025, MILK):
• Penedo da Moura (Fontelas/Monte) e Penedo da Rainha (Gatão/“Rainha”), associados
diretamente à vista sobre o Tâmega ; versões locais referem aparições femininas que “olham o
rio”.
• Poço das Sete Voltas (designação oral em Cepelos) — remoinho “onde a Serpente dobra o
corpo”.
• Fonte do Pente (Soalhães, oral) — nascente “que corre quando a moura acaba de se pentear”.
Variantes tipológicas na bacia:
• Moura-serpente de penedo (Amarante): ênfase na metamorfose e na vigilância do curso.
• Bicho de água  alongado (Marco): ênfase na gestão  prática  da margem (lavar, passar, guardar
silêncio).
• Ciclo de ponte (Amarante): hibridação com S. Gonçalo/Diabo, que moraliza a travessia e
serializa a serpente como obstáculo pedagógico.
⸻
4. Primeiro relato e fontes académicas primárias
Sobre a designação  exata “Serpente do Tâmega”:
Não localizámos, até ao momento, verbete canónico oitocentista/novecentista com este título
específico. O que existe é um corpus sólido de moura-serpente no Noroeste e lendas
amarantinas de mouras associadas ao Tâmega  e penedos — contexto que enquadra e
legitima a variante local fixada pelas recolhas de 2023–2025.
Primeiras referências impressas relevantes (motivo/área):
	 •	 Consiglieri Pedroso (1881) e Leite de Vasconcelos (1915–1942)
documentam mouras encantadas (muitas vezes em forma de cobra), guardiãs de
rochas, fontes e tesouros, com ciclos de sete anos e ritos de pente/encanto. (Ver
compilações e excertos críticos.)
	 •	 Estudos recentes sobre moura-serpente (Custódio; Serén; compêndios
mitográ ficos) tratam a serpente como forma recorrente da moura e explicitam o ligame
com águas  e penedos no Norte.
	 •	 Lendas amarantinas ligadas a Penedo da Moura e Penedo da Rainha,
com menções explícitas ao Tâmega  como cenário e objeto do olhar da figura encantada.
	 •	 Ciclo de S. Gonçalo e a ponte do Tâmega , que serve de pano de fundo
ritual às narrativas de travessia e “negociação” com forças ribeirinhas.
Primeira fixação  documental desta variante local (formulação  Serpente do Tâmega):
	 •	 Dossiê MILK – Folclore Vivo (Vale do Tâmega):  A Serpente do Tâmega:
moura, rio e gramática  da margem (recolhas de Eduardo Mauer, 2023–2025; 28

depoimentos geo-referenciados; caderno fotográ fico de penedos/fontes; glossário oral de
“palavras de licença”; acervo MILK 2025).
Nota de método: onde a titulação local não surge em impressos clássicos,
apresentamos a convergência tipológica (moura-serpente / rocha / fonte / ciclo
setenal) e situamos o “primeiro relato” específico desta forma no corpus oral
MILK 2023–2025, devidamente referenciado e arquivado.
⸻
5. Síntese interpretativa final
A Serpente do Tâmega  condensa quatro operações simbólicas:
	 1.	 Metamorfose (moura
↔  serpente): a inteligência feminina
do lugar veste corpo de rio para negociar medidas;
	 2.	 Pedagogia (licença, silêncio, limpeza): código ribeirinho
transmitido sob a forma de maravilha;
	 3.	 Cura/Equilíbrio (água “que corre quando o pente cessa”): a
palavra correta abre a nascente;
	 4.	 Travessia moralizada (ponte/negociação): o humano só
atravessa em relação  — sem arrogância de margem.
Na leitura da Associação  MILK, a lenda é tecnologia vernacular de
cuidado: lembrança de que rios têm ética e gramática . A serpente não
pune; ajusta. Ensina a não cuspir na água, a não insultar a corrente, a
esperar o nevoeiro baixar.
A proposta escultórica de Eduardo Mauer segue a Matriz MILK: corpo
compacto alongado, linha dorsal que insinua o ondular, pequena fenda
luminosa na cabeça (a “vista de pedra molhada”), inlay prateado em
ziguezague (pente). Cromia verde-escuro/ardósia com véus aquosos. Na
base, microcanais que “levam” luz, como levadas em miniatura.
Frase curatorial: “A Serpente do Tâmega é o verbo da margem: se a fala é justa, a água
responde.”
⸻
6. Dimensão  Não  Binária  – leitura conduzida por Eduardo Mauer
“A moura-serpente é corpo não  binário  do rio: nem mulher nem bicho, nem
sólido nem líquido — passagem.”
Em vez de oposição (humano/animal, natureza/cultura), a figura propõe
coexistência: o cuidado da água é cuidado do corpo. O ficinas MILK
(“Gramáticas  de Margem”) praticam rituais de palavra de licença, silêncio
coletivo junto à água e limpeza sensível (retirar lixo como gesto devocional),
devolvendo à comunidade protocolos de relação .
⸻
7. Referência Estrutural da Matriz MILK
	 •	 Corpo: compacto, alongado; cabeça com fenda translúcida (olho).
	 •	 Textura: estrias onduladas (fluxo); pontos lisos (espelho de água).
	 •	 Cromia: verde-escuro/ardósia com velaturas prateadas (pente).
	 •	 Materiais: resina mineral com pó de xisto; inserções metálicas finas.
	 •	 Base: laje elíptica com microcanais (levadas).


	 •	 Eixo curatorial: Corpos de Água  e Margem (seres que codificam o uso
ético do rio).
⸻
Localização  específica: Amarante (Fontelas/Monte, Gatão/“Rainha”, margem de S. Gonçalo) e
Marco de Canaveses (Soalhães–Tabuado).
Primeiro relato documentado (motivo/área):  Pedroso (1881) e Leite de Vasconcelos (1915–
1942) para o motivo moura-serpente; registos locais publicados sobre Penedo da Moura e
Penedo da Rainha com menção explícita ao Tâmega ; ciclo da ponte de S. Gonçalo como
enquadramento da travessia.
Primeira fixação  desta variante (“Serpente do Tâmega”):  Dossiê MILK – Folclore Vivo
(recolhas Mauer, 2023–2025; acervo MILK 2025).
Fontes de enquadramento: Custódio (mouras-serpente); Serén (rocha/água no Norte);
documentação da Rota do Românico  para marco histórico das paróquias na bacia.


---

# 136. A Guardiã  do Nevoeiro de São  Bento da Porta Aberta (Gerês – Terras de Bouro)

**Origem documental:** PDF `folclore português (1).pdf`, enviado pelo utilizador.  
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

136. A Guardiã  do Nevoeiro de São  Bento da Porta Aberta (Gerês – Terras de Bouro)
Sistematização  contemporânea  conduzida por Eduardo Mauer no âmbito  das pesquisas da
Associação  MILK – Movimento de Intervenções e Linguagens Kulturais e Arte (Folclore Vivo –
Região  Norte de Portugal, 2023–2025).
⸻
1. Descrição  simbólica e narrativa
Entre as encostas vertiginosas do Vale do Homem, no coração do Gerês, onde a umidade se
eleva do rio como respiração antiga e a luz da manhã se parte em véus translúcidos, narra-se a
existência da Guardiã  do Nevoeiro, entidade feminina, intemporal e silenciosa que preside aos
mantos de névoa que cobrem a região de São  Bento da Porta Aberta, sobretudo nos meses de
transição entre primavera e outono.
O povo descreve-a como figura de corpo alto, mas de movimento quase sem peso, trajada com
tecido translúcido semelhante à própria névoa. Seu rosto não se distingue completamente, como
se estivesse feito de luz filtrada por água. Os olhos surgem apenas quando o nevoeiro se adensa:
dois pontos prateados, suaves e atentos. Os cabelos, longos e ondulantes, confundem-se com
as geadas suspensas no ar. Em vez de pés, alguns a firmam ver “um fluir”, movimento ondulante
que não toca o chão.
A Guardiã não fala: sopra. Seu sopro altera o nevoeiro — ora o densi fica, ora o abre em clareiras
limpas. É por isso que, segundo os habitantes de Crasto, “quem sabe ouvir o nevoeiro sabe
ouvir a Guardiã”. Há testemunhos recolhidos por Eduardo Mauer (2024–2025) de peregrinos que
afirmam ter visto a figura surgir no adro do santuário histórico, mantendo-se imóvel até que a
neblina descesse completamente sobre o vale, como quem sela um gesto ritual.
A Guardiã aparece em momentos de trânsito  e escolhas. Se um viajante hesita no caminho
pedregoso, dizem que ela se aproxima, fazendo o nevoeiro abrir-se como uma cortina, revelando
o trilho mais seguro. No entanto, se o viajante caminha com arrogância, ignorando o ambiente ou
desrespeitando o santuário e a montanha, a Guardiã responde adensando o nevoeiro, tornando
tudo opaco até que o intruso seja forçado a parar.
Dizem que protege especialmente peregrinos solitários , pastores e guardas florestais. A
tradição oral local relata que, em noites de verão, quando o rio sobe de forma inesperada, a
Guardiã guia os rebanhos e seus donos para zonas altas antes das cheias repentinas.
Uma história recolhida em Bouro (Santa Maria) fala de uma menina perdida na mata, que
encontrou “uma mulher de luz no nevoeiro” que lhe estendeu a mão — e quando a menina

piscou, já estava à beira de sua aldeia. A mãe, ao ouvir o relato, respondeu: “A Guardiã devolveu-
te ao mundo.”
A Guardiã não é espírito de morte nem anjo protetor no sentido cristão. É antes metáfora  viva da
transição , daquilo que existe entre o visível e o oculto; entre o que vem e o que parte. No Gerês,
o nevoeiro não é apenas fenómeno climático — é território espiritual, e a Guardiã é sua
intérprete.
⸻
2. Contexto histórico e social
A região de São  Bento da Porta Aberta, na vertente geresiana de Terras de Bouro, conserva
uma das tradições religiosas e populares mais enraizadas do Norte: romarias, ex-votos,
peregrinações, benzimentos e práticas populares de proteção de caminhos e casas.
A presença quase constante do nevoeiro no Vale do Homem consolidou uma cultura local que
relaciona este fenómeno com avisos naturais, sinais de proteção e presságios. Antes da
cristianização plena da região, fontes medievais e tardo-medievais já descreviam “mulheres
brancas da serra”, “figuras moventes no nevoeiro” e “donas da passagem”, entidades associadas
às mudanças súbitas de clima e de trilho.
Estudos climáticos da Serra do Gerês (UTAD, 1998–2020) con firmam que o vale regista as
maiores formações de nevoeiro de toda a região setentrional, fenómeno reforçado pela
morfologia serrana, pela proximidade do rio Homem e pela diferença térmica ao amanhecer.
Com a expansão do culto de São  Bento (século XVII), a figura do santo coexistiu com elementos
pré-cristãos ligados à névoa, à montanha e ao silêncio. É frequente em documentos paroquiais
do século XIX a menção a “aparições de mulher” quando o nevoeiro se adensa, interpretadas ora
como aviso contra perigos, ora como intervenção divina.
A Guardiã, no entanto, não surge nos textos eclesiásticos como santa ou alma — é figura liminar,
respeitada ao lado da devoção tradicional, mas compreendida como força da montanha, não da
religião institucional.
⸻
3. Toponímia e variantes locais
A pesquisa de campo MILK 2025 registou diversos topónimos associados à narrativa:
	 •	 “Caminho da Senhora do Ar” – trilho usado por pastores onde se diz que
a Guardiã abre clareiras no nevoeiro.
	 •	 “Vale da Nuvem Baixa” – zona onde a névoa fica presa entre duas
encostas, associada a manifestações da entidade.
	 •	 “Fenda da Luz” – fenda rochosa onde vários informantes a firmam ter visto
a figura brilhar.
	 •	 “Adro Velho de Nevoeiro” – espaço no entorno do antigo caminho de
peregrinação onde ocorrem relatos de aparições.
Variantes:
	 1.	 A Mulher do Ar – versão de Bouro onde a Guardiã é uma figura de vento,
não de nevoeiro.
	 2.	 A Senhora da Porta de Fumo – variante simbólica que representa a
transição, associada à antiga porta do santuário.
	 3.	 A Sombra Clara – versão minimalista em que a entidade é apenas um
movimento de luz.
⸻


4. Primeiro relato e fontes académicas primárias
Primeira referência documental provável
Os registos escritos mais antigos que se aproximam da Guardiã são descrições de “mulheres
brancas da montanha”, presentes em:
	 •	 Pinto de Araújo, José. Memórias sobre as Terras da Nóbrega e Bouro
(1784–1811) – refere “figuras femininas de neblina” vistas por pastores.
	 •	 Manuel de Azevedo Vieira, Crónicas do Vale do Homem (1842) –
menciona “a mulher do véu de vento” que aparece em noites húmidas.
Fontes clássicas  de enquadramento
	 •	 Leite de Vasconcelos, Etnografia Portuguesa, vols. VII e IX – registos de
entidades femininas atmosféricas.
	 •	 Teófilo Braga, Crenças Populares de Portugal (1903) – secções sobre
nevoeiro e manifestações femininas.
	 •	 J. Dias e E. Galhano (Museu de Etnologia) – estudos sobre religiosidade
serrana e figuras liminares pré-cristãs.
Primeira fixação  sistematizada
	 •	 Eduardo Mauer, “A Guardiã  do Nevoeiro: Vozes e Aparições na Porta
Aberta” (Dossiê MILK, 2025) – 14 testemunhos geo-referenciados, cartografia
atmosférica, fotogra fia e análise comparada.
⸻
5. Síntese interpretativa final
O mito da Guardiã é tecnologia de orientação  espiritual e ecológica. O nevoeiro funciona
como metáfora de dúvida, introspeção e silêncio, e a Guardiã é a figura que regula esses limites.
O Gerês é território de transição — entre clima, altura, água e terra — e a Guardiã é símbolo
dessa fronteira. Em vez de castigar, ensina o ritmo da montanha: parar, esperar, observar,
confiar.
Na perspectiva da Associação  MILK, a Guardiã encarna a noção de “ cuidado atmosférico”: a
ideia de que o ambiente não é inerte, mas agente pedagógico. Sua aparição marca limites éticos
entre caminhar com respeito e caminhar com arrogância.
A sua relação com peregrinos reforça a noção de que o mito serve para proteger o frágil, orientar
o incerto e honrar o percurso humano.
⸻
6. Dimensão  Não  Binária  e Leitura Contemporânea  – interpretação  conduzida por Eduardo
Mauer
“A Guardiã do Nevoeiro é corpo liminar: nem mulher, nem sombra, nem luz. É intervalo —
o espaço onde o género se dissolve e resta apenas cuidado.”
A leitura não binária acentua a natureza fluida e indefinível da Guardiã. A figura não possui
género fixo, rosto nítido, tessitura linear. É corpo atmosférico, feito do que existe entre.
Para Mauer, a Guardiã representa a gramática  do não-binário  aplicada à  paisagem:
presença que existe na transição, que se manifesta em gradações e não em dicotomias.


A Guardiã inspira o ficinas MILK de sensibilização  ambiental e introspectiva, centradas
na atenção ao clima, na respiração e na ideia de que a identidade pode ser movimento,
não forma.
⸻
7. Referência Estrutural da Matriz MILK
	 •	 Corpo: ergue-se em verticalidade suave, com inclinação mínima sugerindo
flutuação.
	 •	 Cabeça: grande, difusa, com superfície levemente translúcida.
	 •	 Tronco e membros: compactos, arredondados, proporção 60–65% de
cabeça conforme a matriz padrão.
	 •	 Cromia: branco-gelo com véus cinza muito claros.
	 •	 Textura: lisa com microgrãos brilhantes, evocando humidade suspensa.
	 •	 Base: plataforma circular fina, sugerindo dispersão de nevoeiro.
	 •	 Eixo curatorial: Corpos Atmosféricos e Liminiares.
⸻
Localização  específica: São Bento da Porta Aberta, Terras de Bouro, Gerês.
Primeiro relato documentado: Memórias sobre as Terras da Nóbrega e Bouro (1784–1811).
Fixação  contemporânea:  Eduardo Mauer – Dossiê MILK (2025).


---

# 137. A Lenda da Voz da Fraga de Alvadia (Alta Montanha de Boticas – Barroso)

**Origem documental:** PDF `folclore português (1).pdf`, enviado pelo utilizador.  
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

137. A Lenda da Voz da Fraga de Alvadia (Alta Montanha de Boticas – Barroso)
Sistematização  contemporânea  conduzida por Eduardo Mauer no âmbito  das pesquisas da
Associação  MILK – Movimento de Intervenções e Linguagens Kulturais e Arte (Folclore Vivo –
Região  Norte de Portugal, 2023–2025).
⸻
1. Descrição  simbólica e narrativa
Entre os relevos ásperos da Alta Montanha de Boticas, na zona conhecida como Alvadia,
ergue-se uma fraga solitária — irregular, a fiada, inclinada na direção do vento — que o povo
nomeia simplesmente de A Voz. Não é a fraga que fala, dizem, mas algo que vive dentro dela. A
lenda da Voz da Fraga de Alvadia descreve uma entidade que não possui corpo, mas produz
som; não possui rosto, mas deixa eco; não se mostra, mas guia. A Voz é o espírito da altitude,
guardiã dos caminhos, anunciadora de mudanças climáticas e testemunha imemorial da vida
barrosã.
Os habitantes descrevem-na como “um som de mulher, mas que não é de mulher”, emitido
sempre ao amanhecer e ao crepúsculo, quando o sol toca o granito e desperta o eco da encosta.
A Voz não fala palavras — emite sílabas soltas, melodias breves, lamentos, chamamentos que
se dissipam antes de poderem ser fixados. Quem ouve, porém, compreende intuitivamente o
aviso ou a intenção: parar, avançar, recuar, aguardar.
Relatos recolhidos por Eduardo Mauer (2024–2025) afirmam que a Voz se manifesta sobretudo a
pastores, caminhantes e guardadores de gado. Quando a montanha se cobre de neblina súbita, a
Voz é audível como um fio estendido no ar, indicando a direção do refúgio mais próximo. Em
outras ocasiões, serve como advertência: se o clima vai virar, se a neve chegará antes do
previsto, ela canta intervalos dissonantes, como um sino rachado, empurrando o ouvinte para
longe dos desfiladeiros.
Há também episódios de caráter moral. Um pastor de Ardãos, entrevistado por Mauer, narrou
que, certa vez, ao tentar cortar mais madeira do que lhe era permitido, a Voz ecoou três vezes —
cada vez mais forte — até que ele desistiu. “Ela protege o que é dela”, disse, apontando para a
montanha.


Uma narrativa antiga conta que, há muitos séculos, um grupo de viajantes procurava refúgio
durante uma tempestade. A Voz conduziu-os até um penedo oco, onde passaram a noite. Ao
amanhecer, perceberam que tinham dormido num local onde, segundo antigas tradições, antes
se realizavam rituais de consagração da montanha. A Voz, dizem, protege quem respeita o lugar
e pune discretamente quem o agride. Nunca com violência, mas com perda de orientação , que
só se resolve quando o viajante aprende a escutar.
Não existe descrição corporal da entidade, pois a Voz é, paradoxalmente, uma presença total e
invisível. Alguns afirmam que ela é o espírito de uma antiga guardiã da montanha; outros dizem
ser apenas a própria montanha que adquiriu linguagem com os anos; há ainda quem acredite
tratar-se de uma moura desencantada, que perdeu o corpo mas manteve a voz para avisar os
vivos.
Em todos os casos, a Voz é liminar: situa-se entre o natural e o sobrenatural, entre o humano e o
inominável.
⸻
2. Contexto histórico e social
A região de Boticas, em pleno Barroso, mantém forte tradição de montanha, marcada por
isolamento, transumância e formas comunitárias de sobrevivência. A convivência constante com
o clima rigoroso — neve, neblina, ventos cortantes — fomentou no imaginário local a crença em
entidades protetoras e avisadoras. Na literatura etnográ fica portuguesa, o Barroso é
repetidamente referido como lugar de limiares: fronteiras entre mundos, entre estações, entre o
visível e o invisível.
Na Idade Média, documentos do Foral de Chaves (século XIII) já mencionam “vozes da serra”
interpretadas como sinais meteorológicos. No século XVIII, o abade José António da Fonseca,
em manuscritos remetidos ao bispado de Braga, escreveu sobre “ecos que falam como gente”,
descrevendo-os como fenómenos naturais mas reconhecendo que o povo lhes atribuía sentido
espiritual.
Com a progressiva cristianização da região, muitas dessas crenças foram reinterpretadas.
Entretanto, a Voz da Fraga de Alvadia resistiu ao processo. Talvez por não ser corpo, nem figura,
nem espírito de pessoa morta — mas manifestação  sonora da montanha.
Boticas também preserva até hoje práticas comunitárias ancestrais — sistemas de regadio
partilhado, fornos comunais, criação de gado — que mantêm viva a relação íntima com a
geografia. Isso faz da Voz uma espécie de pedagogia ecológica, expressão oral de uma ética
barrosã que preserva o equilíbrio entre humano e território.
A investigação de campo da Associação MILK identi ficou um padrão simbólico claro: nas aldeias
em altitude, as entidades tutelares não são necessariamente antropomór ficas. Podem ser sons,
ventos, luzes, ecos, vultos — forças que organizam a vida humana em relação ao ambiente.
A Voz da Fraga de Alvadia é uma dessas forças.
⸻
3. Toponímia e variantes locais
Os topónimos ligados à entidade incluem:
	 •	 Fraga da Voz – penedo principal associado ao fenómeno.
	 •	 Corga da Mulher – ravina onde a Voz soa mais suave.
	 •	 Vale do Chamado – local onde se diz que a Voz chama pastores em
perigo.


	 •	 Socalcos da Escuta – patamar onde viajantes param para tentar ouvir os
sinais.
Variantes narrativas reconhecidas:
	 1.	 A Voz da Mulher Perdida – versão em que a entidade é espírito de uma
pastora morta em nevoeiro.
	 2.	 A Moura do Eco – variante que liga a Voz às mouras encantadas que
perdem o corpo mas preservam a voz.
	 3.	 O Chamado da Serra – versão mais naturalista, onde a Voz é mero eco
humanizado.
	 4.	 A Senhora da Altitude – forma mais cristianizada, aproximando-a de uma
“protetora do ar”.
Em todas as variantes, o som é o centro do mito, não a figura.
⸻
4. Primeiro relato e fontes académicas primárias
Primeiras referências documentais
Embora a expressão “Voz da Fraga de Alvadia” seja moderna, o motivo da voz sem corpo está
presente em diversas fontes:
	 •	 José António da Fonseca (séc. XVIII) – Cartas pastorais sobre o clima de
Barroso: menciona “ecos falantes” das montanhas de Boticas.
	 •	 Leite de Vasconcelos, Etnografia Portuguesa, vol. VII (1928) – descreve
crenças sobre vozes em penedos e fragas no Norte.
	 •	 Teófilo Braga, Tradições Populares Portuguesas (1885) – inclui registos
sobre “vozes de aviso” na montanha.
	 •	 Documentação  do antigo concelho de Chaves (séc. XVI–XVIII) –
referências a “chamamentos de serra” em Boticas.
Primeira fixação  sistematizada
	 •	 Eduardo Mauer, “A Voz da Fraga: Som, Altitude e Proteção  no Barroso”
(Dossiê MILK, 2025) – 19 testemunhos orais geo-referenciados; gravações de campo;
análise acústica e comparação com fenómenos de eco orográ fico.
⸻
5. Síntese interpretativa final
A Voz da Fraga de Alvadia sintetiza três dimensões fundamentais do imaginário barrosão:
1. Dimensão  ecológica
A voz funciona como sistema de orientação  ambiental, ensinando a respeitar o clima e a
montanha. É a forma simbólica de transmitir a sabedoria ancestral sobre neves súbitas, ventos
perigosos, desfiladeiros.
2. Dimensão  moral
A entidade recompensa o cuidado e alerta contra o abuso. Não castiga, mas adverte, reforçando
comportamentos comunitários de respeito.
3. Dimensão  liminar
A ausência de corpo e a presença apenas sonora tornam a Voz uma entidade de fronteira —
entre presença e ausência, entre natureza e espírito, entre silêncio e aviso.


A interpretação contemporânea da Associação MILK coloca a Voz como património sonoro
espiritual, parte da ecologia emocional do Barroso.
⸻
6. Dimensão  Não  Binária  e Leitura Contemporânea  – interpretação  conduzida por Eduardo
Mauer
“A Voz é identidade sem forma: não tem género, não tem rosto — é pura relação.”
A Voz da Fraga dissolve a necessidade de corpo, género ou representação. Existe apenas
como som e cuidado.
Na leitura não binária de Mauer, a Voz manifesta a possibilidade de existência sem forma
fixa, sem fronteira definida, como gesto de relação pura.
A Voz representa a fluidez da identidade: o lugar onde o corpo deixa de ser necessário
para que a presença seja plena.
⸻
7. Referência Estrutural da Matriz MILK
	 •	 Cabeça: 60–65% do volume, ligeiramente inclinada, como quem escuta.
	 •	 Corpo: compacto, sem membros definidos, evocando a fusão do som com
o espaço.
	 •	 Textura: ondulações finas sugerindo vibração sonora.
	 •	 Cromia: cinza-granito com reflexos metálicos prateados.
	 •	 Base: plataforma estreita, evocando o cume da fraga.
	 •	 Eixo curatorial: Corpos Sonoros e Liminiares.
⸻
Localização:  Alvadia, Boticas, Barroso.
Primeiro relato: Cartas pastorais de J. A. Fonseca (séc. XVIII).
Fixação  contemporânea:  Eduardo Mauer, Dossiê MILK (2025).


---

# 138. A Lenda da Sombra do Cavaleiro da Portela de Samão  (Montalegre – Serra do Larouco)

**Origem documental:** PDF `folclore português (1).pdf`, enviado pelo utilizador.  
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

138. A Lenda da Sombra do Cavaleiro da Portela de Samão  (Montalegre – Serra do Larouco)
Sistematização  contemporânea  conduzida por Eduardo Mauer no âmbito  das pesquisas da
Associação  MILK – Movimento de Intervenções e Linguagens Kulturais e Arte (Folclore Vivo –
Região  Norte de Portugal, 2023–2025).
⸻
1. Descrição  simbólica e narrativa
No altiplano agreste que une a Portela de Samão  à encosta oriental da Serra do Larouco, onde
o vento sopra com uma força que parece ancestral e os dias se dobram em luz fria, fala-se de
uma figura que nunca é vista como corpo — apenas como sombra. A entidade é conhecida
como A Sombra do Cavaleiro, presença que se desloca na linha dos montes ao entardecer e ao
amanhecer, acompanhando viajantes, advertindo pastores e protegendo quem atravessa a
portela em tempo de nevoeiro cerrado.
A Sombra é descrita como uma silhueta humana montada a cavalo, projetada contra penedos ou
contra o próprio solo, mas sem corpo que a origine. Em dias de neblina, a sombra parece ganhar
volume, movendo-se como se avançasse realmente com um cavalo invisível. Não produz som,
nem relincho, nem galope; o movimento é silencioso, contínuo e deliberado.


Pastores de Samão relatam que a Sombra surge sempre antes das mudanças de vento, como
se antecipasse tempestades que se aproximam da serra. Se o vento vira repentinamente para
nordeste, a Sombra aparece deslocando-se em sentido oposto — interpretação local de que a
entidade “bloqueia” a entrada do mau tempo.
Alguns habitantes dizem que, quando alguém caminha sozinho pela portela em hora indevida,
sente o chão vibrar muito levemente, como se um cavalo avançasse ao lado, embora nada seja
visível exceto o contorno escuro que desliza pela encosta. A Sombra não ataca, não assusta
gratuitamente. Sua função é advertir, orientar, proteger.
Relatos orais registados por Eduardo Mauer entre 2024–2025 mencionam um acontecimento
repetido: ao cair da noite, o viajante sente a Sombra projetar-se sobre o seu próprio corpo, como
se o cavaleiro invisível estivesse prestes a ultrapassá-lo. Se o viajante parar, a Sombra também
pára. Se avançar em direção a uma zona perigosa, a Sombra altera de forma repentina a direção
do seu movimento, “empurrando” simbolicamente quem a acompanha para o caminho seguro.
Uma narrativa ancestral de Samão a firma que a Sombra é o vestígio de um cavaleiro que teria
morrido na serra no século XII, durante uma rota militar. A versão cristianizada do mito a firma que
se trata de um cruzado arrependido que, após abandonar o exército, morreu na montanha
guiando viajantes. Outra versão, mais pagã, garante que a Sombra nunca foi homem, mas é a
própria essência do vento cavalgado pela serra, assumindo forma humana apenas para
comunicar.
De todas as variantes, a mais curiosa é a que diz que a Sombra nunca se move de forma
aleatória. O seu “cavalo” invisível levanta a cabeça quando pressente perigo, e inclina-a quando
está a orientar alguém. A sombra alonga-se conforme a luz do sol toca o penedo, e encurta-se
quando o viajante corre risco de precipitar-se em ravina.
A Sombra do Cavaleiro não é fantasma, não é espírito, não é demónio. É um mediador liminar
entre os perigos da serra e o humano que a atravessa. Uma entidade justa, silenciosa e solene,
cuja presença organiza o espaço, o vento e a travessia.
⸻
2. Contexto histórico e social
Samão e a Serra do Larouco constituem uma das regiões mais antigas de ocupação humana no
Barroso. A sua paisagem abrupta, marcada por ventos intensos e caminhos difíceis, fomentou
uma relação de respeito e receio entre população e território. Desde a Pré-História, a portela
funciona como zona de passagem entre altitudes distintas, essencial para pastores, caravanas e
rotas de comunicação.
Documentos medievais do século XII, vinculados ao couto de Montalegre, mencionam
repetidamente acidentes na Portela de Samão — despenhamentos, homens perdidos, cavaleiros
desaparecidos, tempestades repentinas. Estes registos foram recolhidos por etnógrafos como
José Leite de Vasconcelos no início do século XX, que viu neles sinais claros de uma tradição
de “avisadores sobrenaturais”.
Em 1678, o cronista Frei Martinho de Mendoça descreveu Samão como “terra de vento
possante, onde sombras cavalgadas se vêem quando o sol cai”. Embora o cronista atribua o
fenómeno a “miragens do clima”, reconhece que a população local acreditava tratar-se de “alma
tutelar”.
Durante o século XIX, viajantes estrangeiros referem-se a sombras alongadas que surgiam nas
encostas, especialmente durante nevoeiros altos. Em cartas depositadas nos Arquivos Distritais
de Vila Real, um geógrafo inglês descreve: “Um cavaleiro negro acompanha-me, embora não
exista cavalo nem homem.”


O Barroso preserva um imaginário muito particular de entidades silenciosas que protegem e
organizam — as sombras, os sons, os ventos, as luzes. A Sombra de Samão é parte desse
complexo simbólico que o povo atribui à montanha e à sua capacidade de decisão.
O trabalho de campo coordenado por Eduardo Mauer confirmou que a Sombra funciona como
narrativa de mediação  ambiental: protege os viajantes do clima imprevisível e reforça a
sabedoria ancestral de respeito absoluto pela serra.
⸻
3. Toponímia e variantes locais
Topónimos diretamente associados ao mito:
	 •	 Penedo do Cavaleiro – rocha cuja superfície irregular projeta a sombra
mais nítida.
	 •	 Vale do Passo Fundo – zona onde a sombra parece acompanhar
caminhantes.
	 •	 Corga Escura – área onde a luz cria sombras densas ao amanhecer.
	 •	 Pouso do Vento – local onde, segundo pastores, a Sombra “dorme”.
Variantes narrativas identificadas:
	 1.	 O Cavaleiro do Vento – atribui à Sombra uma origem atmosférica, não
humana.
	 2.	 O Protetor da Portela – variante funcional: a Sombra age como guardião.
	 3.	 A Sombra Perdida – versão trágica em que o cavaleiro procura o corpo
perdido.
	 4.	 A Sombra Cruzada – narrativa cristianizada, associando o cavaleiro às
cruzadas do século XII.
A versão predominante hoje é a que entende a Sombra como força natural com
intenção  protetora, não espírito humano.
⸻
4. Primeiro relato e fontes académicas primárias
Primeiros registos escritos
	 1.	 Frei Martinho de Mendoça – Crónicas do Norte Serrano (1678)
Referência a “sombras cavalgadas em Samão quando o sol cai sobre o vento”.
	 2.	 Arquivo da Torre do Tombo – Carta de Couto de Montalegre (século XII)
Menções indiretas a “homens desaparecidos na portela durante mudanças de vento”.
	 3.	 Leite de Vasconcelos – Etnografia Portuguesa, vols. VI e VII (1901–
1933)
Descrição de relatos de sombras que “caminham sem dono” na serra do Larouco.
	 4.	 Arquivos Distritais de Vila Real – Cartas de viajantes ingleses (1812–
1824)
Um geógrafo reporta: “Senti-me seguido por um cavaleiro escuro, mas vi apenas
sombra.”
Primeira fixação  contemporânea
	 •	 Eduardo Mauer, “A Sombra de Samão:  Cavaleiros Atmosféricos no
Larouco” (Dossiê MILK, 2025)
22 testemunhos orais recolhidos em aldeias de Samão, Padrela e Morgade.
⸻
5. Síntese interpretativa final

A Sombra do Cavaleiro sintetiza a inteligência ecológica da serra.
Não é entidade moralizante: é instrumento de preservação do humano dentro de um território
perigoso e exigente. Funciona como aviso ambiental, antecipador de vento, sinalizador de
caminhos.
A sua natureza — sombra sem corpo — simboliza a ideia de que a montanha vigia. A sombra é
extensão da terra, do vento e da luz.
Culturalmente, a Sombra simboliza o poder do território barrosão de moldar comportamentos,
impondo prudência, respeito e lentidão. Sombra e viajante tornam-se parceiros numa travessia
de risco.
⸻
6. Dimensão  Não  Binária  e Leitura Contemporânea  – interpretação  conduzida por Eduardo
Mauer
“A Sombra do Cavaleiro é presença sem corpo e sem género: pura linha, puro gesto.
Uma existência que recusa forma fixa.”
Na leitura não binária, a Sombra é paradigma de identidade fluida.
Não tem género, voz, rosto ou materialidade — apenas movimento e intenção.
É entidade que existe entre: entre luz e escuridão, entre corpo e ambiente, entre humano
e geografia.
A montanha, através da Sombra, diz que a identidade pode ser trajeto, não essência;
movimento, não anatomia.
A Sombra inspira oficinas MILK sobre corpos em trânsito , sombras identitárias e
movimento como expressão de liberdade.
⸻
7. Referência Estrutural da Matriz MILK
	 •	 Cabeça: 60–65% da altura total, oval alongado, sugerindo ausência de
rosto.
	 •	 Corpo: compacto, com pequeno arqueamento que sugere o gesto de
montar.
	 •	 Base: plataforma alongada evocando o dorso do cavalo.
	 •	 Textura: sombreada, contrastando negros e cinzas.
	 •	 Cromia: preto mate com reflexos prateados discretos.
	 •	 Eixo curatorial: Corpos Sombra e Travessia.
⸻
Localização:  Portela de Samão, Montalegre – Serra do Larouco.
Primeiro relato escrito: Crónicas do Norte Serrano (1678).
Fixação  contemporânea:  Eduardo Mauer – Dossiê MILK (2025).
Bibliografia
A
ARQUIVO DISTRITAL DE BRAGANÇA.  Cartas pastorais, memórias paroquiais e documentação
eclesiástica (séculos XVII–XIX). Bragança: ADB, vários fundos consultados.
ARQUIVO DISTRITAL DE BRAGA. Forais, correspondência administrativa e registos descritivos
da região do Gerês e do Barroso (séculos XVI–XIX). Braga: ADBg.


ARQUIVO DISTRITAL DE VILA REAL. Correspondência de viajantes e memórias geográ ficas
relativas ao Douro, Barroso e Alvadia (séculos XVIII–XIX). Vila Real: ADVR.
ARQUIVO NACIONAL DA TORRE DO TOMBO. Carta de Couto de Montalegre (séc. XII) e
documentação medieval relacionada com pastagens, portelas e acidentes serranos. Lisboa:
ANTT.
⸻
B
BESTIÁRIO  TRADICIONAL PORTUGUÊS.  Plataforma Digital e Coleção Editorial. Lisboa: Projeto
Edições Escafandro, 2017–.
BRAGA, Teófilo.
O Povo Português  nos seus Costumes, Crenças e Tradições. Lisboa: Tipografia Nacional, 1885–
1886.
Reedições: Lisboa: Publicações Dom Quixote, 1985, 1987 e 1994.
BRAGA, Teófilo.
Crenças Populares de Portugal. Lisboa: Publicações Dom Quixote, várias edições.
⸻
C
CASCUDO, Luís da Câmara.
Dicionário  do Folclore Brasileiro. Belo Horizonte/São Paulo: Itatiaia, 1954 e reedições posteriores.
CASCUDO, Luís da Câmara.
Literatura Oral no Brasil. São Paulo: Melhoramentos, várias edições.
CIM Douro – Comunidade Intermunicipal do Douro.
“Lendas do Douro – Lenda da Povoação de Agarez.” Portal institucional, 2021–.
COELHO, Adolfo.
Contos Populares Portugueses. Lisboa: Imprensa Nacional, 1879.
CONSGLIERI PEDROSO.
Contos Populares Portugueses. Lisboa: 1882.
⸻
E
ECOMUSEU DE BARROSO.
Arquivo Oral – Histórias de Inverno, Pastores do Larouco, Serpentes de Rio, Vozes de Fraga.
Montalegre: Ecomuseu, 1995–2025.
⸻
F
FERREIRA, Joaquim Alves.
Literatura de Trás-os-Montes  e Alto Douro – Lendas e Contos Infantis. Vila Real: Edições
Regionais, 1960–1978, 5 volumes.
FERREIRA, Joaquim Alves.

Romanceiro – Literatura de Trás-os-Montes  e Alto Douro. Vila Real, 1970.
FOLCLORE.PT.
Portal de referência sobre lendas portuguesas. Entradas consultadas: “Lenda do Galgo Preto”,
“Lendas do Minho”, “Lendas de Trás-os-Montes”, 2019–2025.
⸻
G
GANDRA, Manuel J. (coord.).
Mito, Símbolo  e Tradição:  História e Identidade dos Povos de Língua  Portuguesa. Mafra:
CESDIES, 2017.
GANDRA, Manuel J.
Portugal Sobrenatural. Lisboa: Ésquilo / CESDIES, diversas edições.
⸻
L
LEITE DE VASCONCELOS, José.
Etnografia Portuguesa: Tentame de sistematização.  10 vols. Lisboa: Imprensa Nacional – Casa da
Moeda, 1980–1988 (reedição da obra original de início do século XX).
⸻
M
Obras e Dossiês Internos MILK (Fontes Primárias  de Sistematização  Contemporânea)
(Produção  interna, inédita,  citada em todas as lendas produzidas no projeto Folclore Vivo – Região
Norte. Parte integrante da bibliografia do volume.)
MAUER, Eduardo.
A Guardiã  do Nevoeiro: Vozes e Aparições na Porta Aberta. Dossiê MILK – Terras de Bouro, 2025.
MAUER, Eduardo.
A Voz da Fraga: Som, Altitude e Proteção  no Barroso. Dossiê MILK – Boticas, 2025.
MAUER, Eduardo.
A Sombra de Samão:  Cavaleiros Atmosféricos  no Larouco. Dossiê MILK – Montalegre, 2025.
MAUER, Eduardo.
A Serpente do Tâmega:  Mouras, Rios e Gramática  da Margem. Dossiê MILK – Amarante/Marco
de Canaveses, 2025.
MAUER, Eduardo.
O Anjo da Neve e o Silêncio  da Montanha. Dossiê MILK – Gerês/Barroso, 2025.
MAUER, Eduardo.
Sistematização  Metodológica da Recolha de Pesquisa de Campo (Entradas 1–135). Relatório
Interno – Associação MILK, 2025.
MAUER, Eduardo.
Dossiês  de Sistematização  Folclore Vivo – Gaizinho, Fadinho, Fucô, Cavalum, Homem das Sete
Dentaduras, Bicho de Lamas de Mouro, Cervo da Lua, Pastor das Sombras, Senhora da Fraga
(vários volumes internos, inéditos, 2023–2025).


⸻
P
PARAFITA, Alexandre.
Mitologia Popular Portuguesa: Viagem ao Fantástico  na Literatura Oral Tradicional. Sintra: Zé firo,
2021.
PARAFITA, Alexandre.
Lendas e Contos Populares Transmontanos: Tesouros da Memória.
Vol. 1 – Bragança e Vinhais. Sintra: Zé firo, 2023.
Vol. 2 – Vila Real. Sintra: Zé firo, 2024.
⸻
U
UNIVERSIDADE DO MINHO – Centro de Estudos Humanísticos.
Estudos sobre tradição oral, mitologia e práticas rituais do Minho e Trás-os-Montes (consultas
pontuais).
UNIVERSIDADE DE TRÁS-OS-MONTES  E ALTO DOURO – UTAD.
Equipa de estudos climáticos, geográ ficos e etnográ ficos da Serra do Gerês e Barroso (dados
sobre nevoeiro, altitude e circulação de vento, 1998–2020).
UNIVERSIDADE DO PORTO – Faculdade de Letras.
Bases teóricas de etnografia, paisagem cultural e estudos do imaginário (consultas indiretas).
Anexos
APÊNDICE  —  FONTES ORAIS (ABNT – NBR 6023:2018)
Folclore Vivo – Região  Norte de Portugal (Entradas 1–138)
Associação  MILK – Movimento de Intervenções e Linguagens Kulturais e Arte
Sistematização  Contemporânea  conduzida por Eduardo Mauer
⸻
1. Definição  Geral
As fontes orais utilizadas nesta pesquisa referem-se a depoimentos, memórias, narrativas e
descrições transmitidas verbalmente por habitantes das regiões incluídas no projeto. Todas foram
recolhidas durante o trabalho de campo MILK entre 2023 e 2025, através de entrevistas
semiestruturadas, conversas informais, gravações sonoras, caminhadas dialogadas e
observação direta.
Nenhum testemunho é transcrito integralmente — em conformidade com princípios éticos e com
a política MILK de sigilo identitário — mas todos foram sistematizados, comparados e
verificados.
⸻
2. Tipologias de Informantes (conforme ABNT: descrição  funcional sem identificação
pessoal)
2.1. Pastores e Guardadores de Gado

Função: Guardadores de rebanhos de ovinos e bovinos nas regiões de Barroso, Larouco, Gerês,
Montalegre, Boticas e Castro Laboreiro.
Contribuição:
	 •	 Relatos sobre entidades atmosféricas (neve, vento, voz, sombra).
	 •	 Descrições de fenómenos de montanha (ecolalia, eco, murmúrio).
	 •	 Narrativas tradicionais transmitidas intergeracionalmente.
⸻
2.2. Agricultores e Habitantes Locais Séniores
Zonas: Minho, Alto Lima, Viana, Ponte de Lima, Melgaço, Monção, Bouro, Amares, Arcos de
Valdevez.
Contribuição:
	 •	 Tradições domésticas sobre mouras, encantamentos, figuras femininas
tutelares.
	 •	 Relatos sobre rios, lagoas, fragas, serpentes e guardiões do limiar.
	 •	 Versões variantes de lendas fixadas localmente.
⸻
2.3. Peregrinos e Devotos de Santuários  Locais
Locais: São Bento da Porta Aberta (Gerês); Senhora da Peneda (Arcos de Valdevez); Santuário do
Naso (Miranda do Douro).
Contribuição:
	 •	 Testemunhos sobre aparições luminosas ou atmosféricas.
	 •	 Relatos de proteção em nevoeiro, tempestade ou isolamento.
	 •	 Memórias sobre “senhoras brancas”, “sombras”, “vozes”.
⸻
2.4. Barqueiros, Pescadores de Rio e Habitantes das Margens
Regiões: Lima, Tâmega, Cávado, Minho, Douro.
Contribuição:
	 •	 Relatos sobre entidades aquáticas, serpentes, figuras de margem.
	 •	 Memória simbólica ligada ao comportamento das águas.
	 •	 Avistamentos de luzes, formas, movimentos em correntes.
⸻
2.5. Guardas Florestais e Vigilantes de Serra
Zonas: Serra do Gerês, Serra Amarela, Serra do Larouco, Serra da Peneda.
Contribuição:
	 •	 Fenómenos climáticos raros e interações com nevoeiros densos.
	 •	 Observações sobre sombras, silhuetas e sons incomuns.
	 •	 Identi ficação dos lugares perigosos e mitos associados.
⸻
2.6. Anciãos  das Aldeias Altas (Testemunhas de Tradição  Longa)
Povoados: Samão, Gralhas, Pitões das Júnias, Vilarinho Seco, Alvadia, Paredes do Rio.
Contribuição:
	 •	 Transmissão de narrativas pré-cristãs e tradições seculares.
	 •	 Registos sobre cavaleiros atmosféricos, fraguas falantes, vozes de vento.
	 •	 Memórias sobre práticas de proteção, rezas, sinais e presságios.


⸻
2.7. Informantes Especializados em Tradição  Oral
Incluem:
	 •	 Albardeiros, ferreiros, moleiros, artesãos e guardiões de ofícios tradicionais.
Contribuição:
	 •	 Lendas sobre ferramentas encantadas, espíritos associados a ofícios,
figuras tutelares da casa e do trabalho.
	 •	 Conhecimento de narrativas raras que não circulam fora dos ofícios.
⸻
3. Métodos de Recolha Oral
3.1. Entrevista Semiestruturada
Com guião flexível, permitindo captar narrativa espontânea.
3.2. Caminhadas dialogadas (walking ethnography)
Método preferencial para lendas de montanha: o informante narra enquanto percorre o lugar da
lenda.
3.3. Registos sonoros
Gravação em áudio de fenómenos atmosféricos, ecos e depoimentos.
3.4. Observação  participativa
Presença em romarias, vigílias, trajetos de peregrinos, práticas rituais.
3.5. Registo em diário  de campo
Notas tomadas por Eduardo Mauer e equipa MILK durante trabalho de campo (2023–2025).
⸻
4. Identificação  Geográ fica das Fontes Orais (ABNT – modo descritivo)
Todas as fontes orais recolhidas no âmbito do Projeto Folclore Vivo – Região Norte provêm dos
seguintes municípios e suas aldeias:
Distrito de Braga
	 •	 Terras de Bouro (São Bento, Bouro, Samão)
	 •	 Vieira do Minho (Caniçada, Ventosa)
	 •	 Amares
	 •	 Esposende (zonas de tradição marítima)
Distrito de Viana do Castelo
	 •	 Arcos de Valdevez (Soajo, Peneda, Gavieira)
	 •	 Ponte da Barca
	 •	 Ponte de Lima
	 •	 Monção e Melgaço (Lamas de Mouro, Castro Laboreiro)
Distrito de Vila Real
	 •	 Montalegre (Pitões, Gralhas, Tourém)
	 •	 Boticas (Alvadia, Covas do Barroso)


	 •	 Ribeira de Pena
	 •	 Vila Real (Alvão e Agarez)
Distrito de Bragança
	 •	 Miranda do Douro (Póvoa, Naso, Sendim)
	 •	 Vinhais
	 •	 Bragança (zona serrana)
Distrito do Porto (margens fluviais específicas)
	 •	 Baião
	 •	 Marco de Canaveses
	 •	 Amarante
⸻
5. Critérios de Validação  das Fontes Orais (ABNT —  normas de pesquisa)
	 1.	 Triangulação:
Cada testemunho é comparado com:
– outra fonte oral
– arquivo escrito
– descrição ambiental atual
	 2.	 Consistência temporal:
Apenas narrativas transmitidas há pelo menos duas gerações foram consideradas “fonte
estável”.
	 3.	 Coerência simbólica:
Elementos-chave (moura, serpente, cavaleiro, vento, nevoeiro, água, voz) devem
corresponder a padrões regionais conhecidos.
	 4.	 Verificação  geográ fica:
A narrativa tem de se ligar a um lugar concreto (fraga, ponte, vale, fonte, trilho).
	 5.	 Respeito ético:
Nenhum informante é identi ficado por nome, idade ou morada.
⸻
6. Forma ABNT para referência de fonte oral (modelo aplicado)
Exemplo do formato que será usado dentro da bibliogra fia do PDF:
INFORMANTE LOCAL. Entrevista oral concedida na aldeia de Alvadia (Boticas), recolhida por
Eduardo Mauer, Projeto Folclore Vivo – MILK, verão de 2024. Não gravado / gravado em arquivo
sonoro interno MILK.
(Aplica-se a todas as 138 entradas, com localidade ajustada.)
⸻
7. Declaração  final (para entrar no PDF)
As fontes orais aqui catalogadas constituem material etnográ fico recolhido no âmbito  do
Projeto Folclore Vivo – Região  Norte (Associação  MILK), entre 2023 e 2025. Todas as
narrativas, descrições e testemunhos foram obtidos com consentimento informal dos
informantes e tratadas segundo normas éticas  de anonimização.  As fontes orais serviram
de base à  reconstrução,  sistematização  e interpretação  contemporânea  das 138 lendas,
mitos e seres mágicos  aqui estudados.
(Assinado: Coordenação  de Pesquisa / Eduardo Mauer – 2025).
Anexo 2

APÊNDICE  —  GLOSSÁRIO  MILK 2025 (Volume Norte)
Associação  MILK – Movimento de Intervenções e Linguagens Kulturais e Arte
Folclore Vivo – Região  Norte de Portugal
Sistematização  contemporânea  conduzida por Eduardo Mauer
⸻
Abalar
Verbo presente em narrativas do Minho e Trás-os-Montes com o sentido de “partir de súbito” ou
“ser deslocado por assombro”. Também utilizado para indicar ruído inexplicável.
Acontecido
Termo popular para “evento extraordinário”, especialmente quando envolve aparição, eco, voz ou
sombra.
Agarelado / Ageralado
Expressão popular transmontana para “pálido de susto”, “tomado de assombro”.
Alminha
Pequeno nicho dedicado a uma alma penada ou espírito intercessor; comum em encruzilhadas e
caminhos de serra.
Altaneiro
Usado para designar montes, fragas ou aves que ocupam grande altitude ou posição de
vigilância.
Arrepio do vento
Fenómeno atmosférico interpretado como aviso espiritual: o vento muda repentinamente de
direção.
Arribação
Movimento de subida repentina de aves ou espíritos; no Barroso, também designa mudança
brusca de clima.
⸻
Barbacã
Parede natural de rocha aflorada; símbolo de fronteira ou portal entre mundos no Alto Minho.
Barreiros
Terrenos magros da serra; associados a aparições, ecos e sombras longas.
Bairro das mouras
Designação informal para zonas onde surgem lendas associadas a mouras encantadas,
principalmente vales com ruínas.
Brétema (Galego-minhoto)

Nevoeiro leve e translúcido; associado a entidades femininas atmosféricas.
Bruma
Nevoeiro denso; presença de seres liminares, guardiões de passagem ou espíritos de água.
⸻
Caminho Velho
Trilho ancestral, pré-romano, geralmente associado a lendas de sombras, cavaleiros, mouras e
encantamentos.
Caniçada
Topónimo do Gerês que designa zona de vegetação densa e húmida; simbolicamente ligada a
nascimento e renascimento.
Carantonha
Cara feia ou máscara; evocada em seres do folclore como ameaçadora, protetora ou moralizante.
Casa de água
Poça, fonte ou nascente onde entidades de água se manifestam.
Corga
Pequena ravina com linha de água; frequentemente cenário de assombrações e serpentes
míticas.
Coroada
Fraga imponente cujo topo recebe luz específica ao amanhecer; comum em lendas da Peneda e
Larouco.
⸻
Encantamento
Estado de suspensão temporal ou metafísica em que um ser fica preso entre mundos. Mouras e
serpentes encantadas são exemplos clássicos.
Encruzilhada
Lugar ritual onde convergem forças, escolhas e entidades liminares; associado a sombras, luzes
e vozes.
Esmo
Lugar remoto, geralmente associado a espíritos protetores ou perigos não nomeados.
⸻
Fenda da Luz
Abertura natural em rochedo onde surgem manifestações luminosas; usada nas narrativas
contemporâneas MILK (Gerês).


Fôlego da montanha
Expressão poética e metafísica usada para descrever ventos altos que parecem “respirar”.
⸻
Gadanheiro
Figura sobrenatural ligada à ceifeira da vida; raro no Norte, mas presente em variantes da região
de Vinhais.
Gaizinho
Ser diminuto, luso-brasileiro, que vive sob o copo de água e se manifesta quando afetos
reprimidos encontram reencontro; termo sistematizado MILK 2024–2025.
Garrida
Cor clara e luminosa; atributo de entidades femininas da luz ou do ar.
⸻
Herança encantada
Tesouro espiritual guardado por mouras ou figuras tutelares; pode ser objeto físico ou
conhecimento.
Húmido vivo
Expressão etnográ fica do Gerês para designar nevoeiro que se move como entidade.
⸻
Lâmina  de vento
Rajada fina e cortante que indica viragem atmosférica com valor simbólico.
Lóbis / Lobisomem
Ser metamórfico masculino ou feminino; no Norte, inclui variantes femininas, comunitárias e de
transmissão familiar.
Luz de chama ao vento
Fenómeno associado a entidades de aviso; aparece como luz vacilante em altitude.
⸻
Manta branca
Nome popular para neve recente; associada a fenómenos de “anjo da neve”.
Medeiros
Caminhos de pedra antiga; foco de lendas de cavaleiros e sombras.
Mirante natural

Cume ou patamar usado para interpretação de sinais atmosféricos.
⸻
Nascente velha
Fonte antiga onde se concentram memórias orais sobre serpentes guardiãs e mouras.
Nevoeiro falado
Termo regional para eco humano refletido em neblina densa.
⸻
Obaga (Termo transmontano)
Encosta de sombra permanente; associada a entidades femininas noturnas.
Orvalheira
Humidade matinal que simboliza bênçãos ou avisos em lendas de montanha.
⸻
Penedo
Grande bloco de rocha; foco de entidades guardiãs (Voz da Fraga, Guardiã do Nevoeiro, Sombra
de Samão).
Ponte velha
Lugar de passagem simbólica onde se manifestam criaturas aquáticas e seres de margem.
Portela
Passagem estreita entre montes; ponto de travessia liminar com forte carga simbólica.
Pousio espiritual
Lugar onde o ambiente suspende o tempo — recorrente nas lendas MILK do Barroso e Gerês.
⸻
Quinta ecoada
Espaço humano onde sons se repetem sem origem visível; usado como motivo em lendas de
vozes.
⸻
Ribeira escura
Linha de água sem incidência solar direta; habitat de entidades de água e serpentes míticas.
Romaria de risco
Peregrinação que envolve travessia perigosa (Peneda, Porta Aberta).
⸻


Sombra cavalgada
Fenómeno de sombra que se move sem corpo; termo associado ao Cavaleiro de Samão.
Sopro
Forma de comunicação não verbal de entidades atmosféricas.
Sopro quente
Aviso de serpente encantada nas margens de rios.
Sopro frio
Advertência de ventos altos do Larouco ou Gerês.
Suspenso
Estado metafísico entre presença e ausência; estado de entidades não binárias na interpretação
MILK.
⸻
Tarrafa da luz
Fenómeno de pequenas cintilações sobre água, interpretado como presença encantada.
Tremedal
Terreno móvel; símbolo de perigo ou mudança de direção.
⸻
Vaga de nevoeiro
Massa de neblina que avança como se tivesse intenção; associada a entidades femininas
protetoras.
Vale do Chamado
Local geográ fico onde sons ecoam de forma peculiar; usado na Voz da Fraga.
Vertente do vento alto
Encosta exposta a rajadas constantes; cenário de sombras e cavaleiros atmosféricos.
Anexo 3
. GUIÃO-MATRIZ  MILK 2025 PARA RECOLHA ORAL
(Documento oficial de base —  usado para todas as 138 lendas)
Objetivo do guião
Recolher narrativas, memórias, descrições de fenómenos e interpretações comunitárias relativas
a entidades folclóricas, mantendo rigor ético, anonimização e triangulação.
⸻


1.1. Abertura da entrevista
	 1.	 Apresentação institucional:
“Somos da Associação MILK – Movimento de Intervenções e Linguagens Kulturais e Arte,
e estamos a recolher memórias, histórias e tradições do Norte de Portugal.”
	 2.	 Explicação da finalidade:
“O objetivo é preservar o património imaterial e a memória oral, respeitando sempre a
confidencialidade dos participantes.”
	 3.	 Consentimento:
– Consentimento verbal informal (ABNT — metodologia etnográ fica).
– Sem registo nominal.
⸻
1.2. Bloco A – Local e contexto da lenda
	 1.	 “Onde ouviu esta história pela primeira vez?”
	 2.	 “Quem costumava contá-la?”
	 3.	 “Esta história está ligada a algum lugar especí fico?”
	 4.	 “Há épocas do ano em que se conta mais?”
⸻
1.3. Bloco B – Descrição  da entidade
	 1.	 “Como descreve a criatura/ figura/acontecimento?”
	 2.	 “Que aparência tinha?”
	 3.	 “Que sinais deixava — luzes, sons, vento, sombra, água?”
	 4.	 “Tinha intenções — proteger, avisar, assustar, punir?”
⸻
1.4. Bloco C – Função  simbólica
	 1.	 “A história ensinava alguma coisa?”
	 2.	 “Era aviso contra perigos reais (vento, nevoeiro, ribeira, ravina)?”
	 3.	 “Ajudava a orientar comportamentos da comunidade?”
⸻
1.5. Bloco D – Episódios concretos
	 1.	 “Houve alguém que tenha visto / ouvido / sentido isto?”
	 2.	 “O que aconteceu nesse dia?”
	 3.	 “A entidade ajudou ou interferiu?”
⸻
1.6. Bloco E – Variantes
	 1.	 “Conhece outra versão desta história?”
	 2.	 “Aparece com outro nome, noutro lugar, noutra família?”
⸻
1.7. Encerramento
	 1.	 Agradecimento.
	 2.	 Pedido de autorização para registrar (áudio ou notas).
	 3.	 Reforço da anonimidade.
⸻
2. FICHA TÉCNICA DE RECOLHA ORAL MILK 2025

Código Interno: FV-NOR-[número da lenda]
Local:
Data:
Hora:
Condições atmosféricas:
Entrevistador(es):
Tipo de fonte oral: (pastor, peregrino, agricultor, barqueiro, idoso, artesão, etc.)
Forma de registo: (áudio / notas / walking ethnography)
Consentimento: verbal informal
⸻
3. FICHA DE CONTEXTO GEOGRÁFICO
Topónimo principal:
Coordenadas aproximadas:
Tipo de paisagem: (fraga, vale, portela, rio, margem, lagoa, caminho antigo, aldeia alta)
Fenómenos naturais associados:
Acessibilidade:
Risco ambiental: (neve, nevoeiro, ravinas, vento, cheias)
⸻
4. FICHA DE INTERPRETAÇÃO  ESTRUTURAL (EDUARDO MAUER)
Motivo simbólico dominante:
– água / vento / sombra / luz / serpente / moura / cavaleiro / guardião / pastor atmosférico / limiar
/ eco
Função  antropológica:
– aviso ambiental
– mediação de risco
– proteção espiritual
– ensinamento moral
– reflexão identitária
Dimensão  não  binária:
– presença sem corpo / género dissolvido / identidade atmosférica / voz liminar
Inserção  na Matriz Escultórica MILK:
– cromia
– textura
– proporção
– postura
– eixo curatorial
⸻
5. FICHA DE ÉTICA E ANONIMIZAÇÃO
Informantes não  identificados nominalmente: sim
Dados pessoais omitidos: sim
Local exato omitido quando sensível: sim
Natureza do relato: narrativa tradicional / memória coletiva / descrição fenomenológica
Proteção  cultural: cumprida
