# Corpus integral auditado — parte 08

Entradas 099 a 112.



---

# 099. A Lenda do Eco de Terras de Bouro (Gerês – Serra do Amarela e Rio Homem)

**Origem documental:** PDF `folclore português (1).pdf`, enviado pelo utilizador.  
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

99. A Lenda do Eco de Terras de Bouro (Gerês – Serra do Amarela e Rio Homem)

(Sistematização  contemporânea  conduzida por Eduardo Mauer no âmbito  das pesquisas sobre
Folclore Vivo da Associação  MILK – Movimento de Intervenções e Linguagens Kulturais e Arte,
com base em recolhas orais e documentais realizadas entre 2023 e 2025 nas freguesias de Bouro
Santa Maria, Campo do Gerês,  Covide e Rio Caldo, cruzadas com fontes etnográ ficas do Museu
da Geira Romana, do Arquivo Municipal de Terras de Bouro e de estudos contemporâneos  sobre
mitologia sonora, oralidade natural e ecofenomenologia nas serras do norte português.)
⸻
1. Descrição  simbólica e narrativa
Entre os vales profundos e os penedos ressonantes do Gerês, o povo de Terras de Bouro fala do
Eco, uma entidade invisível que habita as montanhas e responde à voz humana com perfeição
perturbadora. Mais do que simples fenómeno acústico, o Eco é considerado espírito vivo — uma
presença inteligente que escuta, repete e, às vezes, transforma as palavras de quem ousa
chamá-lo.
Nas tradições locais, o Eco é descrito como voz sem corpo, sopro antigo da serra. Aparece
sobretudo nas manhãs frias, quando o nevoeiro cobre os vales e o silêncio é quase sólido. Se
alguém grita o próprio nome, o Eco devolve-o ligeiramente alterado, como se quisesse corrigi-lo.
Diz-se que essa distorção é a marca do outro lado do mundo, um lembrete de que toda voz é
sempre partilhada.
As recolhas de Eduardo Mauer (2024) registram múltiplas variantes do mito. Em algumas, o Eco
é alma de pastor morto, condenado a repetir para sempre os chamamentos do rebanho que
perdeu. Noutras, é filho da montanha e do vento, mensageiro entre vivos e mortos.
Um dos relatos mais antigos, transmitido por um eremita de Covide, conta que o Eco nasceu do
primeiro grito do mundo — quando a terra acordou e respondeu a si mesma. Desde então, vive
escondido nos desfiladeiros, alimentando-se de sons humanos.
Quem o ouve claramente é considerado abençoado: acredita-se que o Eco só responde aos que
trazem o coração aberto. Mas há quem o tema: há histórias de viajantes que enlouqueceram ao
escutar a própria voz multiplicada nas montanhas, “como se o mundo lhes devolvesse a alma
partida em mil pedaços”.
Mauer descreve o Eco como “voz que não pertence a ninguém e, por isso, fala por todos”.
⸻
2. Contexto histórico e social
O território de Terras de Bouro, inserido no Parque Nacional da Peneda-Gerês, é marcado por
acidentes geográ ficos de rara acústica: vales estreitos, encostas abruptas e grutas graníticas que
amplificam o som. Desde tempos pré-históricos, o eco foi interpretado como resposta do
sagrado.
Nas culturas indo-europeias, o eco personificava a comunicação com o invisível. Os gregos
chamavam-lhe Ekhó, ninfa condenada por Hera a repetir as palavras dos outros. Essa tradição
passou ao mundo romano e, por via da latinização e do cristianismo rural, fundiu-se com crenças
locais.
No norte de Portugal, sobretudo nas zonas serranas, o eco tornou-se metáfora  da
reciprocidade divina: quando o homem chama a montanha, é Deus ou a terra quem responde.
Durante a Idade Média, monges e eremitas da região de Bouro registaram nos seus diários a
prática contemplativa de “ouvir o retorno do som”, interpretando o fenómeno como oração
natural.


No século XIX, Leite de Vasconcelos e Rocha Peixoto observaram o uso do eco em festas e
romarias — os fiéis gritavam louvores para o monte, ouvindo o eco responder “Amém”, “Maria”,
“Deus”, o que era visto como confirmação espiritual.
O mito do Eco consolidou-se, assim, como símbolo de diálogo  entre humano e natureza,
testemunho de uma espiritualidade acústica que resiste até hoje nas práticas comunitárias das
aldeias de Bouro e Covide.
⸻
3. Toponímia e variantes locais
A lenda apresenta diversas variantes regionais:
– Eco de Bouro: a forma mais antiga e reverenciada;
– Voz do Homem (Covide): ligada ao rio de mesmo nome, onde se diz que o Eco habita nas
rochas;
– Sopro da Serra Amarela (Campo do Gerês): versão associada aos ventos e à alma do monte;
– Palavra do Céu (Rio Caldo): interpretação cristianizada, em que o eco é resposta divina.
Topónimos como “Penedo da Voz” e “Vale dos Ecos” aparecem em mapas antigos e relatos de
viajantes oitocentistas, comprovando o valor cultural atribuído ao fenómeno. Em Covide, há ainda
um local chamado “Altar da Escuta”, rocha natural onde os pastores chamavam o rebanho e
ouviam o eco multiplicado.
⸻
4. Primeiro relato e fontes académicas primárias
O primeiro registro literário da lenda do Eco de Bouro encontra-se em Leite de Vasconcelos,
Etnografia Portuguesa, vol. IX (1925, pp. 119–126)*, onde o autor descreve “voz repetida da
montanha, tida pelo povo como espírito guardião do vale”.
Teófilo Braga, O Povo Português  nos seus Costumes, Crenças e Tradições (1885, pp. 728–733)*,
faz referência à “voz do vento nas serras do Gerês”, relacionando-a a antigos cultos pagãos de
comunicação com o além.
Alexandre Parafita, Mitologia Popular Portuguesa (2008, pp. 932–939)*, classifica o Eco como
“entidade acústica mítica”, herdeira da ninfa grega Ekhó, mas reinterpretada no contexto
português como “consciência sonora do território”.
A sistematização contemporânea de Eduardo Mauer, O Eco de Terras de Bouro: Voz, Natureza e
Memória na Mitologia Sonora Portuguesa (Lisboa, Associação MILK, 2025)*, articula fontes orais,
descrições científicas e práticas artísticas para propor leitura fenomenológica do Eco enquanto
figura da reciprocidade ambiental.
Fontes complementares:
– Museu da Geira Romana, Coleção  Etnográ fica de Terras de Bouro (1970–2015);
– Arquivo Municipal de Terras de Bouro, Relatos Orais e Mitos da Montanha (1890–1940);
– Tese de Doutoramento de Teresa Coutinho, Fenomenologia do Som: O Eco e a Escuta no Norte
de Portugal (U. Minho, 2019).
⸻
5. Síntese interpretativa final
O Eco é o arquétipo da escuta e da resposta. Ele simboliza a consciência do território — a
montanha que fala de volta, a natureza que devolve ao humano o seu próprio som. A lenda

transforma o fenómeno físico em experiência espiritual e pedagógica: ouvir o eco é aprender a
ouvir a si mesmo no mundo.
Na leitura simbólica da Associação  MILK, o Eco é o corpo da relação  sonora. A montanha
torna-se instrumento, e o ar, memória vibrante. Essa reciprocidade constitui o princípio de uma
ética ecológica da escuta — ideia central nas investigações artísticas de Eduardo Mauer, que
concebe o som como diálogo entre presença e ausência.
A escultura MILK inspirada no Eco apresenta corpo compacto, cabeça grande e boca aberta num
gesto de ressonância. O interior é oco, criando uma câmara acústica que emite eco suave
quando se fala diante dela. As cores predominantes são cinza-ardósia e azul profundo, evocando
pedra e ar.
Mauer escreve: “O Eco não é resposta: é o convite do mundo para continuarmos a falar com ele.”
⸻
6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer
Na leitura não binária de Eduardo Mauer, o Eco é entidade sem fronteira — simultaneamente
voz e ouvido, ativo e passivo, presença e ausência.
“O Eco não responde nem fala: apenas coexiste. É o som que recusa hierarquia.”
A duplicidade do Eco dissolve o dualismo sujeito/objeto, masculino/feminino, natural/
humano. É símbolo do não  binário  acústico, no qual o som não pertence a ninguém e,
por isso, é de todos.
A Associação  MILK vê no mito uma metáfora poderosa para as práticas colaborativas e
artísticas contemporâneas: criar é ecoar, devolver ao mundo o que o mundo nos diz. O
Eco ensina o princípio da coexistência: existir é repetir de modo diferente, escutar para
existir.
⸻
7. Referência Estrutural da Matriz MILK
Na Matriz Escultórica MILK – Série Folclore Vivo, o Eco de Terras de Bouro apresenta:
– Corpo: compacto, cabeça grande e oca, boca aberta em forma de arco;
– Cores: cinza-ardósia e azul profundo;
– Materiais: resina com câmara acústica interna e acabamento fosco;
– Expressão:  neutra e meditativa;
– Base: semicircular, evocando o vale e o movimento sonoro.
A escultura integra o eixo “Vozes da Montanha” do projeto Folclore Vivo, dedicado às entidades
sonoras que expressam a reciprocidade entre humanidade e paisagem.
⸻
Localização  específica: Bouro Santa Maria, Campo do Gerês, Covide e Rio Caldo (distrito de
Braga).
Primeiro relato documentado: Vasconcelos, Etnografia Portuguesa, vol. IX, 1925.
Sistematização  contemporânea:  Eduardo Mauer, O Eco de Terras de Bouro: Voz, Natureza e
Memória na Mitologia Sonora Portuguesa, Associação MILK, 2025.
Fontes primárias:  Braga (1885); Vasconcelos (1925); Parafita (2008); Coutinho (2019); Mauer
(2025).


---

# 100. A Lenda da Senhora do Silêncio de Bravães  (Ponte da Barca – Vale do Lima)

**Origem documental:** PDF `folclore português (1).pdf`, enviado pelo utilizador.  
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

100. A Lenda da Senhora do Silêncio de Bravães  (Ponte da Barca – Vale do Lima)
(Sistematização  contemporânea  conduzida por Eduardo Mauer no âmbito  das pesquisas sobre
Folclore Vivo da Associação  MILK – Movimento de Intervenções e Linguagens Kulturais e Arte,
com base em recolhas orais e documentais realizadas entre 2023 e 2025 nas freguesias de
Bravães,  Vila Nova de Muía  e Nogueira, cruzadas com fontes etnográ ficas do Museu dos Terceiros
de Ponte de Lima, do Arquivo Municipal de Ponte da Barca e de estudos contemporâneos  sobre
espiritualidade feminina, silêncio  ritual e simbologia acústica no folclore português.)
⸻
1. Descrição  simbólica e narrativa
Entre os vales verdes e o murmúrio do Lima, em Bravães, conta-se que há uma figura que nunca
fala e, ainda assim, faz-se ouvir em toda a terra. Chamam-lhe a Senhora do Silêncio, uma
mulher vestida de branco, envolta em véu leve, que aparece nas madrugadas enevoadas junto à
antiga igreja românica.
Dizem os habitantes que a Senhora não pede nada, não ameaça, nem promete — apenas olha.
O seu olhar é tão profundo que “ensina mais que uma homilia inteira”, a firmam os mais velhos.
Segundo a tradição oral, recolhida por Eduardo Mauer (2024), a Senhora foi outrora uma jovem
monja do mosteiro de Bravães, famosa pela doçura da voz e pelo dom da música. Certo dia, ao
cantar durante uma procissão, a sua voz encantou um cavaleiro, que a seguiu até ao convento. A
jovem, tomada pelo medo de que o seu canto perturbasse os outros, fez voto de silêncio
eterno, pedindo a Deus que a transformasse em presença muda. Desde então, o povo começou
a ver, nas noites de lua, uma mulher luminosa caminhando entre os ciprestes, os lábios
cerrados e as mãos cruzadas sobre o peito.
Diz-se que quem tenta falar com ela ouve apenas o som do vento — e é esse o seu modo de
responder. Em algumas versões, o silêncio da Senhora cura os a flitos: basta estar perto dela para
sentir alívio e serenidade. Noutras, o silêncio é advertência: quem fala em excesso ou mente
diante da igreja perde a voz por três dias.
A lenda conserva uma beleza contida: o poder que emana não do som, mas da ausência dele.
Nas palavras de Mauer, “a Senhora do Silêncio é o eco sem voz do sagrado feminino — não
grita, mas reorganiza o mundo à sua volta”.
⸻
2. Contexto histórico e social
O Mosteiro de Bravães , construído no século XII e um dos mais belos exemplares do românico
português, sempre foi centro de religiosidade e peregrinação no Vale do Lima. Situado num ponto
de confluência entre a via medieval e o caminho para Santiago, o lugar servia de abrigo a
viajantes e monges.
O silêncio tem longa tradição nas ordens monásticas: era visto como disciplina espiritual e
instrumento de comunhão com o divino. No caso de Bravães, o silêncio ultrapassou o convento e
tornou-se mito local — transição entre o voto e a aparição.
Durante o século XIX, com a extinção das ordens religiosas, surgiram relatos de fiéis que viam
“uma freira de luz” à beira do Lima. O fenómeno foi interpretado por alguns como fantasma, por
outros como manifestação milagrosa. Nos anos 1930, o pároco de Bravães registou num caderno
paroquial: “Há quem diga que a mulher de branco é o próprio silêncio da terra, visível nas noites
em que o vento cessa e a água dorme.”


A lenda inscreve-se, portanto, num contexto social de religiosidade popular, em que o feminino é
associado ao recolhimento, à escuta e à mediação espiritual. No século XXI, sob o olhar da
Associação  MILK, a Senhora do Silêncio reaparece como metáfora da voz interior das
comunidades rurais, tantas vezes ignoradas, mas guardiãs de sabedoria profunda.
⸻
3. Toponímia e variantes locais
A designação “Senhora do Silêncio” é predominante em Bravães e arredores, mas a lenda
assume nomes diferentes noutras aldeias do vale:
– “Santa Muda” (Vila Nova de Muía): associada à penitência e ao voto monástico;
– “Virgem do Vento” (Nogueira): versão mais poética, onde a Senhora fala através das brisas;
– “Senhora da Escuta” (Ponte da Barca): reinterpretação moderna, utilizada em contextos
devocionais femininos.
Há referências cartográ ficas a um “Campo da Muda” (1758) nas Memórias Paroquiais,
possivelmente relacionado à devoção popular. Ainda hoje, o silêncio é observado como sinal de
respeito nas romarias locais — prática herdada da lenda.
⸻
4. Primeiro relato e fontes académicas primárias
O primeiro registro escrito da Lenda da Senhora do Silêncio encontra-se em Leite de
Vasconcelos, Etnografia Portuguesa, vol. IX (1925, pp. 127–133)*, que menciona “mulher vestida
de branco junto à igreja de Bravães, símbolo do voto e da contenção, venerada em silêncio pelos
moradores”.
Teófilo Braga, O Povo Português  nos seus Costumes, Crenças e Tradições (1885, pp. 734–740)*,
já aludia à “ figura branca das margens do Lima, santa sem nome que fala pelo vento”.
Alexandre Parafita, Mitologia Popular Portuguesa (2008, pp. 940–949)*, classifica a Senhora do
Silêncio como manifestação da “energia do recolhimento”, um arquétipo que liga o sagrado
feminino à escuta interior.
A sistematização contemporânea de Eduardo Mauer, A Senhora do Silêncio  de Bravães:  Voz
Interior e Imaginário  Acústico no Românico  Português  (Lisboa, Associação MILK, 2025)*, integra
análise histórica, fenomenologia da escuta e etnogra fia oral, interpretando o mito como
paradigma da comunicação  não  verbal e da espiritualidade relacional.
Fontes complementares:
– Arquivo Municipal de Ponte da Barca, Registos Paroquiais e Cadernos de Milagres (1700–1950);
– Museu dos Terceiros, Coleção  de Lendas do Lima e do Homem (1970–2019);
– Tese de Doutoramento de Sofia Moreira, O Silêncio  como Linguagem no Folclore do Norte de
Portugal (U. Porto, 2020).
⸻
5. Síntese interpretativa final
A Senhora do Silêncio representa o princípio feminino da escuta — a potência que reorganiza
o mundo sem pronunciar palavra. É o oposto da retórica e da violência sonora: o som ausente
que cura.
Na leitura simbólica da Associação  MILK, o silêncio não é vazio, mas forma expandida de
comunicação . A Senhora de Bravães transforma o som em presença, mostrando que o
essencial não precisa ser dito.


A escultura MILK concebida por Eduardo Mauer traduz esse conceito num corpo compacto e
vertical, de cabeça grande e olhos semicerrados. O rosto é sereno, os lábios selados e o véu
translúcido envolve o corpo como névoa. A base semicircular, em resina esbranquiçada, emite luz
interna suave e sem som, simulando o pulsar do silêncio.
Mauer escreve: “O silêncio da Senhora é mais audível que o clamor dos homens. Ela não fala: faz
o mundo respirar devagar.”
⸻
6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer
Na leitura não binária de Eduardo Mauer, a Senhora do Silêncio transcende o género e o corpo
— é voz sem dono, presença sem ruído.
“O silêncio é o som que não precisa de corpo. É o lugar onde todos os corpos
descansam.”
A figura simboliza o não  binário  acústico e espiritual: une o ativo e o passivo, o feminino
e o masculino, o som e a pausa. A sua força está em não ocupar espaço — em permitir
que o outro fale.
A Associação  MILK lê o mito como metáfora da escuta inclusiva, fundamento ético das
suas práticas artísticas e pedagógicas. A Senhora do Silêncio torna-se símbolo do
respeito pela diferença: falar menos para ouvir mais.
⸻
7. Referência Estrutural da Matriz MILK
Na Matriz Escultórica MILK – Série Folclore Vivo, a Senhora do Silêncio de Bravães
apresenta:
– Corpo: compacto e ereto, cabeça grande e véu translúcido;
– Cores: branco-neve, cinza-claro e reflexos perolados;
– Materiais: resina translúcida e luz interna suave;
– Expressão:  olhos semicerrados e rosto calmo;
– Base: semicircular, iluminada por dentro, sem som audível.
A escultura integra o eixo “Corpos do Silêncio” do projeto Folclore Vivo, dedicado às entidades
da escuta, da contenção e da memória interior.
⸻
Localização  específica: Bravães, Vila Nova de Muía e Nogueira (Ponte da Barca, distrito de
Viana do Castelo).
Primeiro relato documentado: Vasconcelos, Etnografia Portuguesa, vol. IX, 1925.
Sistematização  contemporânea:  Eduardo Mauer, A Senhora do Silêncio  de Bravães:  Voz Interior
e Imaginário  Acústico no Românico  Português , Associação MILK, 2025.
Fontes primárias:  Braga (1885); Vasconcelos (1925); Parafita (2008); Moreira (2020); Mauer
(2025).


---

# 101. A Lenda do Pastor das Sombras de Pitões das Júnias (Montalegre – Serra do Gerês)

**Origem documental:** PDF `folclore português (1).pdf`, enviado pelo utilizador.  
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

101. A Lenda do Pastor das Sombras de Pitões das Júnias (Montalegre – Serra do Gerês)

(Sistematização  contemporânea  conduzida por Eduardo Mauer no âmbito  das pesquisas sobre
Folclore Vivo da Associação  MILK – Movimento de Intervenções e Linguagens Kulturais e Arte,
com base em recolhas orais e documentais realizadas entre 2023 e 2025 em Pitões das Júnias,
Montalegre, Tourém  e Cabril, cruzadas com fontes etnográ ficas do Museu Etnográ fico de Vilar de
Perdizes, do Arquivo Municipal de Montalegre e de estudos contemporâneos  sobre
espiritualidade pastoril, crenças de montanha e mitologia das sombras no norte de Portugal.)
⸻
1. Descrição  simbólica e narrativa
Entre os cumes agrestes da Serra do Gerês, onde o vento sopra com voz humana e as pedras
guardam memórias, conta-se a história do Pastor das Sombras — figura ao mesmo tempo
temida e venerada pelas gentes de Pitões das Júnias. Segundo os mais velhos, trata-se de um
homem que perdeu o corpo, mas conservou a alma, condenado a guardar os rebanhos
invisíveis que percorrem as encostas durante a noite.
A tradição local descreve-o como sombra alta e delgada, trajada com capa de burel, chapéu
largo e cajado de luz pálida. Não tem rosto visível; apenas um brilho no lugar dos olhos, como
brasa de fogueira prestes a apagar-se. Quando a lua cheia se ergue sobre o mosteiro de Santa
Maria das Júnias, dizem que o Pastor aparece junto às fragas, soprando um assobio triste. Os
cães uivam, e os sinos das vacas ecoam sem que ninguém as veja.
As recolhas orais de Eduardo Mauer (2024) identificam diferentes versões da lenda. Em
algumas, o Pastor foi um homem real, pastor solitário que morreu durante uma tempestade de
neve ao tentar salvar o seu rebanho. Como prêmio pela bondade, Deus concedeu-lhe o dom de
continuar a guardar as montanhas, mas como sombra — para nunca mais sentir frio, fome ou
solidão.
Noutras variantes, o Pastor das Sombras é uma entidade ancestral, espírito guardião dos
animais selvagens e dos vivos perdidos. Quando alguém se desvia do caminho, ele surge e guia
o viajante de volta, sem palavra, apenas pelo som suave de um chocalho distante.
Há também versões sombrias: alguns acreditam que o Pastor é alma penada de um homem
avarento que explorava os seus criados e morreu amaldiçoado. O castigo seria guardar
eternamente as “sombras do gado” — rebanho que nunca cresce nem morre.
O imaginário popular o descreve como mediador entre os mundos, protetor dos seres da serra
e dos que se perdem na escuridão. As crianças eram advertidas: “Não chores à noite, senão o
Pastor das Sombras virá calar-te com o seu silvo.” Mas os mais velhos viam nele um símbolo de
respeito pela solidão do trabalho pastoril, metáfora viva do tempo e da escuta.
Mauer define-o como “figura que traduz a ética da montanha: presença discreta, invisível, mas
sempre vigilante — sombra que protege sem possuir.”
⸻
2. Contexto histórico e social
Pitões das Júnias, situada a mais de 1 200 metros de altitude, é uma das aldeias mais isoladas
de Portugal. A sua história confunde-se com a vida pastoril, marcada por longos invernos,
transumâncias e convivência estreita entre homem e natureza.
O Mosteiro de Santa Maria das Júnias, erguido no século IX e habitado por monges
beneditinos até o século XVI, já foi centro espiritual das comunidades serranas. Os monges
conviviam com pastores e partilhavam crenças sobre espíritos guardiães dos rebanhos —
tradições que se misturaram com o cristianismo e deram origem a figuras híbridas como o Pastor
das Sombras.


Na cultura oral barrosã, o ofício do pastor sempre foi envolto em mistério. Trabalhar só, falar com
os ventos, dormir entre lobos e neve — tudo isso alimentou a visão de que o pastor comunicava
com o invisível. O Ciclo das Almas Guardiãs , documentado por Leite de Vasconcelos (vol. IX,
1925), inclui figuras como o Pastor das Almas, o Homem da Névoa e o Gado Encantado.
O mito do Pastor das Sombras sintetiza essas crenças: representa a continuidade entre vida e
morte, entre presença e ausência. A sua função social é pedagógica: recordar à comunidade o
valor da humildade e da escuta. O silêncio do pastor ecoa a serenidade da montanha — lugar
onde o humano se dissolve no vasto.
Durante o século XX, o isolamento de Pitões e as di ficuldades da pastorícia fizeram do mito uma
referência identitária. Mesmo com o turismo moderno e a eletri ficação tardia (década de 1970), a
imagem do Pastor manteve-se viva nas narrativas orais. Hoje, integra roteiros culturais e
performances do projeto Folclore Vivo, que recupera o mito como símbolo da relação  ecológica
e afetiva com o território.
⸻
3. Toponímia e variantes locais
A lenda aparece sob vários nomes conforme a aldeia:
– Pastor das Sombras (Pitões das Júnias): versão principal e mais difundida;
– Pastor das Neves (Tourém): associado à morte por tempestade e ao rebanho espiritual;
– Pastor do Luar (Cabril): figura luminosa, guardião das cabras montesas;
– Homem da Sombra Comprida (Montalegre): versão sinistra, protetor dos caminhos noturnos.
Topónimos como “Fraga do Pastor”, “Vale do Silvo” e “Penedo da Luz” aparecem em registos
de campo e antigos mapas paroquiais. As variantes sugerem ampla difusão e adaptação do mito
ao longo das fronteiras do Barroso.
⸻
4. Primeiro relato e fontes académicas primárias
O primeiro registro escrito da lenda do Pastor das Sombras surge em Leite de Vasconcelos,
Etnografia Portuguesa, vol. IX (1925, pp. 134–140)*, onde o autor menciona “alma de pastor
aparecida nas serras de Barroso, vista como sombra protetora dos gados”.
Teófilo Braga, O Povo Português  nos seus Costumes, Crenças e Tradições (1885, pp. 741–746)*,
já descrevia crenças em “pastores encantados que surgem nos montes ao entardecer, repetindo
o silvo dos ventos”.
Alexandre Parafita, Mitologia Popular Portuguesa (2008, pp. 950–961)*, integra o Pastor das
Sombras no conjunto das “entidades mediadoras da montanha”, figuras que asseguram o
equilíbrio entre o visível e o invisível.
A sistematização contemporânea de Eduardo Mauer, O Pastor das Sombras: Escuta e Presença
na Mitologia de Barroso (Lisboa, Associação MILK, 2025)*, combina fontes orais recolhidas em
Pitões, Tourém e Montalegre com análise fenomenológica da sombra como metáfora da
coexistência.
Fontes complementares:
– Museu Etnográ fico de Vilar de Perdizes, Coleção  de Lendas e Ritos de Barroso (1970–2018);
– Arquivo Municipal de Montalegre, Relatos Populares do Alto Barroso (1890–1950);
– Tese de Doutoramento de Marta Carvalhal, A Montanha e o Invisível:  Narrativas de Solidão  no
Folclore Transmontano (U. Porto, 2020).
⸻


5. Síntese interpretativa final
O Pastor das Sombras é um dos mitos mais densos do norte de Portugal. Simboliza a presença
que não se vê, o cuidado que não se exibe, a continuidade do mundo através da memória. A
sombra, longe de representar o mal, é aqui expressão de equilíbrio: tudo o que existe projeta
sombra; sem ela, nada seria visível.
Na leitura simbólica da Associação  MILK, o Pastor é o guardião  do interstício — o espaço
entre o humano e o natural, entre a palavra e o silêncio. O seu gesto de guiar sem falar ecoa a
pedagogia ancestral da montanha: ensinar pelo exemplo e pela escuta.
A escultura MILK concebida por Eduardo Mauer reflete essa dimensão. Corpo compacto,
cabeça grande e capa em movimento, o Pastor ergue um cajado translúcido que parece emitir luz
interna. O corpo é negro-acinzentado, mas as bordas brilham levemente, como se a sombra
irradiasse claridade. Os olhos, duas pequenas faíscas, simbolizam a consciência silenciosa.
Mauer escreve: “A sombra do Pastor não é ausência de luz — é a forma que a luz encontra para
permanecer entre nós.”
⸻
6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer
Na leitura não binária de Eduardo Mauer, o Pastor das Sombras é figura de transição: nem vivo
nem morto, nem homem nem espírito, nem claro nem escuro.
“O Pastor das Sombras é o corpo não binário da montanha — aquele que não escolhe
lado, porque habita todos.”
A sombra é lida como metáfora da coexistência, da não dualidade. Na sua ambiguidade,
dissolve os opostos e propõe nova ética da convivência: não separar, mas sustentar as
diferenças dentro de si.
Para a Associação  MILK, o mito é matriz de leitura contemporânea sobre ecologia e
alteridade. A sombra do Pastor não ameaça, protege; não domina, acompanha. É o
princípio de uma presença relacional, não hierárquica, que inspira práticas comunitárias
e artísticas voltadas para a escuta do invisível.
⸻
7. Referência Estrutural da Matriz MILK
Na Matriz Escultórica MILK – Série Folclore Vivo, o Pastor das Sombras de Pitões das
Júnias apresenta:
– Corpo: compacto e vertical, cabeça grande sob chapéu largo, capa texturizada;
– Cores: negro-acinzentado com brilhos de luz fria;
– Materiais: resina pigmentada e acabamento semibrilhante, com iluminação interna difusa;
– Expressão:  calma, com olhos luminosos;
– Base: irregular, simulando terreno de montanha.
A escultura integra o eixo “Guardadores Invisíveis” do projeto Folclore Vivo, dedicado a
entidades tutelares ligadas à proteção do território e à escuta ecológica.
⸻
Localização  específica: Pitões das Júnias, Tourém, Cabril, Montalegre (distrito de Vila Real).


Primeiro relato documentado: Vasconcelos, Etnografia Portuguesa, vol. IX, 1925.
Sistematização  contemporânea:  Eduardo Mauer, O Pastor das Sombras: Escuta e Presença na
Mitologia de Barroso, Associação MILK, 2025.
Fontes primárias:  Braga (1885); Vasconcelos (1925); Parafita (2008); Carvalhal (2020); Mauer
(2025).


---

# 102. A Lenda do Cão  do Monte da Nogueira (Bragança – Trás-os-Montes)

**Origem documental:** PDF `folclore português (1).pdf`, enviado pelo utilizador.  
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

102. A Lenda do Cão  do Monte da Nogueira (Bragança – Trás-os-Montes)
(Sistematização  contemporânea  conduzida por Eduardo Mauer no âmbito  das pesquisas sobre
Folclore Vivo da Associação  MILK – Movimento de Intervenções e Linguagens Kulturais e Arte,
com base em recolhas orais e documentais realizadas entre 2023 e 2025 em Bragança, Parada,
Rebordainhos e Samil, cruzadas com fontes etnográ ficas do Museu do Abade de Baçal, do
Arquivo Distrital de Bragança e de estudos académicos  sobre zoomitologia, simbolismo canino e
crenças pastoris do nordeste transmontano.)
⸻
1. Descrição  simbólica e narrativa
Entre as encostas do Monte da Nogueira, nas serras frias que cercam Bragança, corre uma
lenda antiga sobre um cão  que não  pertence a nenhum homem, mas a todos os caminhos.
Chamam-lhe o Cão  do Monte da Nogueira, e dizem que o seu uivo anuncia tanto a salvação
como o perigo, conforme o coração de quem o ouve.
As recolhas orais feitas por Eduardo Mauer (2024) descrevem o animal como grande e negro,
com olhos cor de âmbar que brilham mesmo sem luar. A sua pelagem parece fumo e a respiração
exala um leve odor de terra molhada e pedra fria. Surge sempre à noite, silencioso, caminhando
lentamente pelos carreiros entre os castanheiros. Alguns afirmam que ele protege os viajantes
perdidos na serra; outros juram que o cão conduz as almas errantes ao destino final.
Há quem diga que ele não é um cão real, mas a sombra coletiva dos cães  mortos, condensada
em forma única para continuar a cumprir o papel de guardião. Quando uiva, os cães das aldeias
calam-se — sinal de respeito, não de medo. Em certas noites, o uivo ressoa entre os vales como
um cântico grave, de ritmo quase humano, o que levou os mais antigos a chamá-lo “ o cão  que
reza”.
A narrativa mais difundida afirma que o Cão do Monte da Nogueira nasceu do vínculo de
fidelidade entre um pastor e o seu animal. O pastor, surpreendido por uma nevada, morreu
congelado com o cão deitado sobre o seu corpo. Dias depois, encontraram ambos cobertos de
neve, e onde jaziam cresceu uma nogueira solitária. Desde então, nas noites de tempestade, o
cão ressurgiria como guardião da montanha, rondando os caminhos com olhos de lume.
A presença do Cão é ambígua: tanto inspira consolo como provoca terror. Em Bragança, diz-se
que quem o vê em silêncio é abençoado, mas quem o chama ou tenta segui-lo desaparece
na neblina. O seu poder não está na agressividade, mas na permanência — ele é o eco da
fidelidade em paisagem desolada.
Nas palavras de Mauer: “O Cão do Monte da Nogueira é a memória viva do vínculo — o amor
que continua a guardar, mesmo depois da morte.”
⸻
2. Contexto histórico e social
O Monte da Nogueira é uma das elevações mais simbólicas do nordeste transmontano,
integrando um sistema de montes sagrados associados a antigas práticas pastoris, rituais de

fertilidade e cultos à natureza. Nas aldeias circundantes (Rebordainhos, Parada, Samil), os cães
sempre desempenharam papel essencial: guardavam os rebanhos, protegiam as casas e
acompanhavam os mortos até ao cemitério — hábito documentado por Leite de Vasconcelos em
1923.
A ligação simbólica entre o cão e o mundo espiritual é muito antiga. Desde a Antiguidade, o cão
foi visto como animal psicopompo, mediador entre vivos e mortos — ideia presente nas
mitologias grega (Cérbero), celta (Cú Chulainn) e romana. Em Trás-os-Montes, essa herança
cruzou-se com a religiosidade popular cristã, originando figuras como o Cão  das Almas e o Cão
do Além, ambos parentes do mito do Monte da Nogueira.
Durante o século XIX, com o isolamento rural e as longas distâncias entre aldeias, o medo das
noites frias reforçou o valor dos cães como símbolos de lealdade e proteção. O Cão do Monte da
Nogueira emerge nesse contexto de solidão e fé, representando o equilíbrio entre o perigo e o
amparo — animal que vigia o limiar entre o humano e o selvagem.
O mito foi também interpretado como forma de educação  moral e ambiental: os pais contavam
a lenda para ensinar as crianças a respeitar os animais e não maltratar cães de pastoreio. Hoje, o
mito sobrevive como símbolo ecológico e afetivo, sendo recuperado em projetos de arte
contemporânea e percursos de memória promovidos pela Associação  MILK, em colaboração
com o Museu do Abade de Baçal e o Parque Natural de Montesinho.
⸻
3. Toponímia e variantes locais
A lenda apresenta várias variantes regionais:
– Cão  do Monte da Nogueira (Bragança): forma mais completa e documentada;
– Cão  do Lume Frio (Parada): associado a luzes errantes vistas nos caminhos;
– Cão  das Almas (Samil): protetor dos cemitérios e companheiro das procissões noturnas;
– Cão  de Sombra (Rebordainhos): ser inteiramente negro, de olhos azuis, que guia viajantes;
– Cão  Branco da Serra (Gimonde): inversão simbólica, protetor da infância e da pureza.
Topónimos como “Caminho do Cão ”, “Fonte do Pastor” e “Vale da Nogueira” aparecem em
mapas paroquiais e documentos do século XVIII, reforçando a presença do mito na geogra fia da
região.
⸻
4. Primeiro relato e fontes académicas primárias
O primeiro registro escrito da lenda do Cão  do Monte da Nogueira aparece em Leite de
Vasconcelos, Etnografia Portuguesa, vol. IX (1925, pp. 141–147)*, que descreve “animal negro e
luminoso visto nas serras de Bragança, tido por guardião das almas e protetor dos caminhos”.
Teófilo Braga, O Povo Português  nos seus Costumes, Crenças e Tradições (1885, pp. 747–751)*,
menciona o “cão da montanha” como espírito vigilante que acompanha os mortos e anuncia
tempestades.
Alexandre Parafita, Mitologia Popular Portuguesa (2008, pp. 962–970)*, interpreta o Cão do
Monte da Nogueira como herdeiro direto das tradições célticas e romano-ibéricas sobre cães
psicopompos, associando-o à permanência da alma fiel.
A sistematização contemporânea de Eduardo Mauer, O Cão  do Monte da Nogueira: Fidelidade e
Luz na Mitologia de Bragança (Lisboa, Associação MILK, 2025)*, integra recolhas orais,
iconografia religiosa e análise simbólica, propondo leitura do mito como expressão  arquetípica
da fidelidade e do cuidado.


Fontes complementares:
– Museu do Abade de Baçal, Coleção  de Relatos Populares Transmontanos (1900–2020);
– Arquivo Distrital de Bragança, Crónicas das Aldeias do Nordeste (1830–1920);
– Tese de Doutoramento de Hugo Tavares, Bestiário  do Norte: Fauna Imaginária  de Trás-os-
Montes (U. Lisboa, 2018).
⸻
5. Síntese interpretativa final
O Cão  do Monte da Nogueira representa o arquétipo da fidelidade eterna — o vínculo que
ultrapassa a morte. O seu uivo ecoa não como ameaça, mas como oração. O mito articula três
dimensões fundamentais: o animal como guardião, a montanha como santuário e a sombra como
forma de presença.
Na leitura simbólica da Associação  MILK, o cão é o mediador da ternura selvagem: protege
sem dominar, acompanha sem pedir. É metáfora da ética do cuidado, tão necessária na relação
contemporânea com o território e os outros seres vivos.
A escultura MILK concebida por Eduardo Mauer segue a matriz padrão, com corpo compacto,
cabeça grande e patas curtas, mas adota postura vigilante, focinho elevado e olhar luminoso. A
superfície preta e lisa é interrompida por finas linhas douradas que sugerem cicatrizes de luz. O
animal não ruge nem avança; repousa em silêncio, como se escutasse a montanha.
Mauer descreve-o assim: “O Cão do Monte da Nogueira não é fantasma nem fera — é o guardião
da memória e da escuta. Está lá para lembrar-nos que ninguém caminha só.”
⸻
6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer
Na leitura não binária de Eduardo Mauer, o Cão  do Monte da Nogueira simboliza a superação
da dicotomia entre animal e humano, luz e sombra, vida e morte.
“O Cão é o corpo que transita entre reinos — fiel ao que vive, leal ao que já partiu.”
O mito encarna o princípio do não  binário  relacional: coexistência, interdependência e
continuidade. O cão, figura marginal e ao mesmo tempo doméstica, expressa a fluidez
entre natureza e cultura, instinto e consciência.
Para a Associação  MILK, o Cão do Monte da Nogueira é também emblema
contemporâneo de empatia e ecologia emocional. A sua presença silenciosa lembra que o
amor e o cuidado podem ser forças políticas e artísticas.
⸻
7. Referência Estrutural da Matriz MILK
Na Matriz Escultórica MILK – Série Folclore Vivo, o Cão  do Monte da Nogueira apresenta:
– Corpo: compacto e sólido, cabeça grande, olhar erguido;
– Cores: negro-acinzentado com reflexos dourados;
– Materiais: resina pigmentada e acabamento em verniz marítimo;
– Expressão:  calma e vigilante;
– Base: circular, com textura de granito.
A escultura integra o eixo “Animais Guardiães ” do projeto Folclore Vivo, dedicado às criaturas
simbólicas que protegem o território e os vínculos afetivos entre seres.


⸻
Localização  específica: Bragança, Parada, Rebordainhos e Samil (distrito de Bragança).
Primeiro relato documentado: Vasconcelos, Etnografia Portuguesa, vol. IX, 1925.
Sistematização  contemporânea:  Eduardo Mauer, O Cão  do Monte da Nogueira: Fidelidade e
Luz na Mitologia de Bragança, Associação MILK, 2025.
Fontes primárias:  Braga (1885); Vasconcelos (1925); Parafita (2008); Tavares (2018); Mauer
(2025).


---

# 103. A Lenda da Noite de Ferro de Vinhais (Trás-os-Montes  – Terra Fria Transmontana)

**Origem documental:** PDF `folclore português (1).pdf`, enviado pelo utilizador.  
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

103. A Lenda da Noite de Ferro de Vinhais (Trás-os-Montes  – Terra Fria Transmontana)
(Sistematização  contemporânea  conduzida por Eduardo Mauer no âmbito  das pesquisas sobre
Folclore Vivo da Associação  MILK – Movimento de Intervenções e Linguagens Kulturais e Arte,
com base em recolhas orais e documentais realizadas entre 2023 e 2025 nas freguesias de
Vinhais, Candedo, Ervedosa e Edral, cruzadas com fontes etnográ ficas do Museu de Vinhais, do
Arquivo Distrital de Bragança e de estudos académicos  sobre cosmogonias climáticas,  crenças
rurais sobre o inverno e simbologia metalúrgica no imaginário  transmontano.)
⸻
1. Descrição  simbólica e narrativa
Em Vinhais, quando o frio aperta e o céu parece feito de estanho, os mais velhos dizem que está
a chegar a Noite de Ferro. É uma noite que não consta do calendário, mas todos sabem quando
se aproxima — o vento muda de direção, as chaminés gemem e o lume da lareira, mesmo alto,
parece não aquecer. Ninguém sai, ninguém canta. As portas ficam trancadas, e os sinos não
tocam.
Segundo o relato oral recolhido por Eduardo Mauer (2024), a Noite de Ferro é entidade
temporal e espiritual ao mesmo tempo. Não é um dia, mas uma presença — uma força antiga
que desce das montanhas da Sanábria e cobre a Terra Fria com um manto metálico de silêncio e
medo.
Os habitantes de Vinhais descrevem-na como “noite que respira”: as paredes rangem, o vento
bate como martelo, e ouve-se um som grave vindo da serra, como se gigantes batessem ferro no
escuro. É por isso que se diz que, nessa noite, o mundo volta a ser forjado.
Nas tradições mais antigas, essa noite simboliza o instante de suspensão  entre o inverno e a
morte. Acredita-se que os mortos caminham então entre os vivos, procurando o calor que já não
possuem. Mas há também quem veja a Noite de Ferro como prova divina: quem acender o lume
com fé verá o ferro brilhar em azul e estará protegido para o resto do ano.
Em algumas versões, é durante a Noite de Ferro que surge o Ferreiro Invisível, ser mítico que
percorre as aldeias com martelo e bigorna invisíveis, batendo três vezes nas portas das casas
puras e passando adiante das impuras. Cada batida é bênção, e quem a escuta sente o corpo
aquecer.
Outras narrativas falam de figuras sombrias encapuzadas, que caminham em fila pelos vales,
arrastando correntes — os chamados Ferros da Noite. O som das correntes é tido como “voz da
Terra”, eco da criação do mundo.
Mauer regista ainda versões femininas da lenda: a Senhora do Ferro, mulher de rosto coberto,
que surge junto aos poços gelados. Diz-se que transforma lágrimas humanas em lâminas,
guardando-as para a forja da próxima era.


O núcleo simbólico da Noite de Ferro é o limiar entre o tempo e o não-tempo  — o momento
em que o frio absoluto renova o calor da vida.
⸻
2. Contexto histórico e social
A região de Vinhais, situada na fronteira entre Portugal e Espanha, é uma das áreas mais frias e
isoladas de Trás-os-Montes. Durante séculos, o inverno extremo moldou o modo de vida local.
Temperaturas abaixo de zero, geadas prolongadas e nevões regulares criaram uma cultura de
resistência marcada por rituais de sobrevivência e coesão.
O mito da Noite de Ferro emerge desse contexto. Trata-se de uma cosmogonia climática , isto é,
uma explicação mítica para a dureza do inverno e para a necessidade de solidariedade
comunitária.
Desde o século XVII, há registos paroquiais de “noites em que o frio matou os rebanhos e as
vozes das igrejas se calaram” (Arquivo Distrital de Bragança, cód. 412, 1678). Essas descrições
ecoam o imaginário da Noite de Ferro, que, de acordo com a tradição oral, era o tempo em que o
céu e a terra deixavam de se distinguir.
A metalurgia rural, importante em Vinhais e Ervedosa desde o século XIX, in fluenciou fortemente
a simbologia da lenda. O ferro, metal de resistência e transformação, tornou-se metáfora do
caráter humano local — duro, mas capaz de ser moldado pelo fogo. O mito, portanto, não é
apenas sobre o frio físico, mas sobre o fogo interior necessário  à  sobrevivência.
No século XX, com a modernização e a migração, a Noite de Ferro tornou-se também metáfora
de saudade e distância: o frio das aldeias passou a representar o vazio deixado pelos que
partiram. Nas leituras contemporâneas, ela expressa tanto o rigor climático como o isolamento
emocional do interior português.
A Associação  MILK, sob direção de Eduardo Mauer, incluiu a Noite de Ferro no eixo “Terras do
Silêncio” do projeto Folclore Vivo, interpretando-a como metáfora  do tempo imaterial e da
resistência comunitária  — uma forma de poética social e ecológica.
⸻
3. Toponímia e variantes locais
A lenda apresenta diferentes denominações:
– Noite de Ferro (Vinhais): versão central e mais antiga;
– Noite da Forja (Candedo): ligada ao mito do Ferreiro Invisível;
– Noite das Correntes (Ervedosa): com ênfase nos “Ferros da Noite”;
– Senhora do Ferro (Edral): figura feminina associada ao inverno e ao destino.
Topónimos como “Vale das Correntes” e “Fonte do Ferro” surgem em registos cartográ ficos do
século XVIII, e há documentação de uma antiga Capela do Santo Ferreiro (atualmente em
ruínas) na serra de Nogueira, onde, segundo crónicas de 1860, os mineiros rezavam para “domar
o ferro e o frio”.
As variantes reforçam a ideia de um sistema simbólico regional, em que o frio, o metal e o som
das correntes funcionam como metáforas de transição e regeneração.
⸻
4. Primeiro relato e fontes académicas primárias

O primeiro relato escrito da Noite de Ferro encontra-se em Leite de Vasconcelos, Etnografia
Portuguesa, vol. IX (1925, pp. 148–153)*, que descreve “a noite em que o ferro canta nas
montanhas de Vinhais e os aldeões fecham as portas para que o frio não leve as almas.”
Teófilo Braga, O Povo Português  nos seus Costumes, Crenças e Tradições (1885, pp. 752–757)*,
menciona um rito invernal chamado “noite de ferro”, durante o qual os pastores batiam ferros e
sinos para espantar os maus espíritos — prática que pode ter dado origem à lenda.
Alexandre Parafita, Mitologia Popular Portuguesa (2008, pp. 971–980)*, classifica a Noite de
Ferro como uma das “cosmogonias climáticas do norte”, comparável às “noites das almas”
galegas e às “noites brancas” eslavas, associadas ao renascimento solar.
A sistematização contemporânea de Eduardo Mauer, A Noite de Ferro de Vinhais: Tempo,
Matéria  e Mito na Terra Fria Transmontana (Lisboa, Associação MILK, 2025)*, propõe leitura
interdisciplinar que une climatologia, mitologia e estética do silêncio.
Fontes complementares:
– Museu de Vinhais, Coleção  de Tradições de Inverno e Crenças Climáticas  (1972–2020);
– Arquivo Distrital de Bragança, Memórias Paroquiais da Terra Fria (1650–1900);
– Tese de Doutoramento de Ana Sequeira, O Frio como Símbolo:  Cosmologias do Norte
Português  (U. Porto, 2021).
⸻
5. Síntese interpretativa final
A Noite de Ferro é uma das mais poderosas metáforas do imaginário transmontano. Representa
o momento em que o frio se torna consciência, quando o tempo se dobra sobre si mesmo e
revela o poder criador da resistência.
Na leitura simbólica da Associação  MILK, o ferro é a matéria do tempo — duro, mas maleável. A
Noite de Ferro é o ritual do recomeço, a pausa necessária para que o fogo interior volte a
acender-se.
A escultura MILK criada por Eduardo Mauer para representar essa entidade assume corpo
compacto, cabeça grande e proporções da matriz padrão. A superfície metálica é texturizada
com pigmento de ferro oxidado e brilho interno azul-acinzentado. A figura ergue um martelo
simbólico, cuja forma lembra o som — não um instrumento de destruição, mas de criação.
Mauer descreve: “A Noite de Ferro é o tempo em que o mundo se forja novamente — não para
endurecer, mas para aprender a suportar.”
⸻
6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer
Na leitura não binária de Eduardo Mauer, a Noite de Ferro transcende a dualidade entre calor e
frio, vida e morte, luz e escuridão.
“A Noite de Ferro é o corpo neutro do tempo — nem quente, nem frio; nem dia, nem noite.
É o intervalo em que tudo respira antes de renascer.”
O mito revela a dimensão não binária da natureza: o equilíbrio que existe na oscilação, na
coexistência de extremos. A noite não é ausência de luz, mas seu repouso; o ferro não é
rigidez, mas possibilidade de transformação.


Para a Associação  MILK, essa leitura inspira práticas artísticas e pedagógicas centradas
na transição  e na resiliência, princípios estruturantes do projeto Folclore Vivo. A Noite de
Ferro ensina que o verdadeiro fogo nasce do frio — que a criação e o cuidado se forjam
juntos, na mesma bigorna.
⸻
7. Referência Estrutural da Matriz MILK
Na Matriz Escultórica MILK – Série Folclore Vivo, a Noite de Ferro de Vinhais apresenta:
– Corpo: compacto e simétrico, cabeça grande e braços erguidos em gesto de forja;
– Cores: cinza-ferro, azul-metálico e re flexos dourados de lume interno;
– Materiais: resina pigmentada com pó de ferro e acabamento oxidado;
– Expressão:  serena e concentrada;
– Base: circular, com textura granulada evocando carvão e metal.
A escultura integra o eixo “Terras do Silêncio” do projeto Folclore Vivo, dedicado aos mitos da
resistência climática, da transformação e da escuta profunda.
⸻
Localização  específica: Vinhais, Candedo, Ervedosa e Edral (distrito de Bragança).
Primeiro relato documentado: Vasconcelos, Etnografia Portuguesa, vol. IX, 1925.
Sistematização  contemporânea:  Eduardo Mauer, A Noite de Ferro de Vinhais: Tempo, Matéria  e
Mito na Terra Fria Transmontana, Associação MILK, 2025.
Fontes primárias:  Braga (1885); Vasconcelos (1925); Parafita (2008); Sequeira (2021); Mauer
(2025).


---

# 104. A Lenda do Homem das Pedras Frias (Montesinho – Bragança)

**Origem documental:** PDF `folclore português (1).pdf`, enviado pelo utilizador.  
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

104. A Lenda do Homem das Pedras Frias (Montesinho – Bragança)
(Sistematização  contemporânea  conduzida por Eduardo Mauer no âmbito  das pesquisas sobre
Folclore Vivo da Associação  MILK – Movimento de Intervenções e Linguagens Kulturais e Arte,
com base em recolhas orais e documentais realizadas entre 2023 e 2025 nas aldeias de
Montesinho, França e Portelo, cruzadas com fontes etnográ ficas do Museu do Abade de Baçal,
do Parque Natural de Montesinho e do Arquivo Distrital de Bragança, bem como estudos
contemporâneos  sobre petrificação  mítica,  simbolismo da geologia e antropomorfismo montanhês
no imaginário  transmontano.)
⸻
1. Descrição  simbólica e narrativa
No alto das serras geladas de Montesinho, onde o vento corta como vidro e a solidão é tão
antiga quanto as pedras, existe a história do Homem das Pedras Frias — um ser de rocha viva,
que respira lentamente o tempo e observa as aldeias desde o cume.
Os moradores descrevem-no como figura gigantesca de granito, com traços humanos moldados
pela erosão e um olhar que parece seguir quem passa. Ninguém sabe quando surgiu, mas todos
concordam que não  é apenas pedra. “A montanha tem um homem dentro”, dizem os pastores.
Segundo as recolhas orais de Eduardo Mauer (2024), a lenda conta que, há muitos séculos,
viveu em Montesinho um ferreiro solitário que dominava o fogo e o ferro como ninguém. Um
inverno rigoroso congelou-lhe a forja, e ele, em desespero, pediu à serra que o transformasse em
pedra para resistir ao frio. O pedido foi atendido: o homem petrificou-se de pé, o martelo ainda
na mão. Desde então, o seu corpo de pedra aquece-se apenas com os raios do sol.


Noutras versões, o Homem das Pedras Frias não é humano, mas guardião  geológico — espírito
da montanha que protege as aldeias de avalanches e tempestades. Em noites de neve, quando o
vento uiva como fera, diz-se que ele desce a encosta e cobre os telhados com o seu manto de
gelo, impedindo os desabamentos.
Há relatos de viajantes que a firmam ouvir batidas rítmicas vindas das rochas durante o inverno.
Os habitantes chamam-nas “os passos do Homem”, sinal de que ele ronda as fronteiras entre o
mundo dos vivos e o da pedra.
O mito contém profunda ambiguidade: o Homem é simultaneamente símbolo de proteção  e de
solidão  absoluta. Representa a fusão extrema entre homem e natureza — o humano que
desejou tanto resistir que acabou por se tornar imortal e imóvel.
Nas palavras de Mauer: “O Homem das Pedras Frias é a matéria que aprendeu a sentir. É a
montanha a lembrar-nos que o tempo também tem corpo.”
⸻
2. Contexto histórico e social
O Parque Natural de Montesinho, na Terra Fria de Bragança, é uma das regiões mais isoladas e
montanhosas de Portugal. Durante séculos, a sobrevivência dependia da pastorícia, do carvão e
da metalurgia artesanal. Os habitantes viviam em estreita relação com a paisagem, onde cada
rochedo tinha nome e cada som da serra guardava sentido.
A lenda do Homem das Pedras Frias reflete essa simbiose. Desde a Idade do Ferro, as
populações do nordeste português associaram as formações rochosas antropomór ficas a seres
petrificados por castigo ou sacrifício — crença partilhada em mitologias europeias (grega, celta e
escandinava).
Durante a romanização, o culto das pedras — ou lapidatio sacra — foi reinterpretado como
veneração de espíritos tutelares da terra. Com o cristianismo, essas figuras foram assimiladas em
narrativas moralizantes, nas quais os petrificados simbolizavam penitência e eternidade.
Em Montesinho, a fusão entre paganismo e cristianismo deu origem a um imaginário singular: o
homem que se torna pedra por amor à terra, não por culpa. O frio extremo da região e a dureza
da vida pastoril fizeram do mito uma metáfora  da resistência coletiva.
Durante o século XIX, cronistas como Pinho Leal e Leite de Vasconcelos registraram histórias de
“homens de granito que choram gelo” em Montesinho, interpretando-as como vestígios de um
antigo culto naturalista.
Na contemporaneidade, o Homem das Pedras Frias é retomado como símbolo ecológico e
patrimonial, representando a permanência do humano na paisagem. Em 2025, o mito foi
incorporado pela Associação  MILK como parte do eixo “Corpos da Montanha”, que investiga a
fronteira entre o corpo e o território na arte e na mitologia portuguesa.
⸻
3. Toponímia e variantes locais
A lenda aparece sob diversas designações:
– Homem das Pedras Frias (Montesinho): versão principal, centrada no guardião pétreo;
– Homem do Gelo (França): relato mais moral, no qual o homem petrifica por soberba;
– Velho da Serra (Portelo): figura protetora dos pastores;
– Homem de Granito (Bragança): variante mais recente, de caráter simbólico e artístico.
Topónimos como “Cabeço do Homem”, “Fraga do Velho” e “Vale das Pedras Frias” aparecem
em mapas paroquiais e registos municipais desde o século XVIII. O lugar conhecido como “Pedra

do Martelo” é apontado pelos habitantes como o exato ponto onde o ferreiro foi transformado em
pedra.
As variantes demonstram a disseminação regional do mito, que se expande por todo o planalto
de Montesinho, com adaptações morais e ambientais.
⸻
4. Primeiro relato e fontes académicas primárias
O primeiro registro escrito do Homem das Pedras Frias encontra-se em Leite de Vasconcelos,
Etnografia Portuguesa, vol. IX (1925, pp. 154–160)*, que descreve “figura rochosa em Montesinho
tida por corpo humano petrificado, objeto de devoção e temor entre pastores”.
Teófilo Braga, O Povo Português  nos seus Costumes, Crenças e Tradições (1885, pp. 758–763)*,
menciona crenças transmontanas sobre “homens de pedra e velhos imóveis”, associando-as às
petrificações mitológicas do imaginário mediterrânico.
Alexandre Parafita, Mitologia Popular Portuguesa (2008, pp. 981–990)*, interpreta o Homem das
Pedras Frias como símbolo da fusão entre o humano e o geológico, re flexo de uma mentalidade
arcaica que vê a montanha como ser vivo.
A sistematização contemporânea de Eduardo Mauer, O Homem das Pedras Frias: Corpo e
Matéria  na Mitologia de Montesinho (Lisboa, Associação MILK, 2025)*, combina fontes históricas,
recolhas orais e análise fenomenológica, propondo leitura do mito como expressão  poética da
permanência e da escuta geológica.
Fontes complementares:
– Museu do Abade de Baçal, Coleção  de Mitos e Relatos do Nordeste Transmontano (1950–
2019);
– Parque Natural de Montesinho, Inventário  Etnográ fico e Paisagístico  (1981–2020);
– Tese de Doutoramento de Inês Figueiredo, O Corpo e a Pedra: Simbolismo Geológico na
Cultura Popular Portuguesa (U. Coimbra, 2017).
⸻
5. Síntese interpretativa final
O Homem das Pedras Frias é o emblema do enraizamento — o humano que se torna natureza
para permanecer. É símbolo da fusão entre carne e granito, calor e frio, efemeridade e eternidade.
Na leitura simbólica da Associação  MILK, a petrificação é compreendida não como castigo, mas
como escolha: o desejo de permanecer no mundo, mesmo à custa da imobilidade. O Homem
das Pedras Frias representa, assim, o pacto entre o corpo e o território.
A escultura MILK concebida por Eduardo Mauer segue a matriz padrão, mas introduz texturas
inspiradas em rocha natural. O corpo é compacto, de superfície irregular, mesclando tons de
cinza, branco e azul-gelo. As mãos fundem-se com o corpo, e o olhar, de pedra translúcida,
reflete a luz ambiente.
Mauer descreve: “O Homem das Pedras Frias é o instante em que o humano aceita ser paisagem
— e, nesse gesto, descobre que a paisagem também respira.”
⸻
6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer

Na leitura não binária de Eduardo Mauer, o Homem das Pedras Frias é o ser da transição
absoluta — nem vivo nem morto, nem homem nem pedra, nem quente nem frio.
“Ele existe no ponto onde as categorias se dissolvem. É o corpo do não binário mineral.”
O mito propõe nova ontologia: o corpo como extensão do território e o território como
corpo. Essa fusão dissolve fronteiras entre humano e não humano, natureza e cultura,
fixidez e transformação.
A Associação  MILK lê a figura como modelo estético e ético: o artista contemporâneo,
tal como o Homem das Pedras Frias, deve aprender a escutar o tempo lento da matéria.
O mito torna-se, assim, símbolo do cuidado ecológico, da paciência e da coexistência.
⸻
7. Referência Estrutural da Matriz MILK
Na Matriz Escultórica MILK – Série Folclore Vivo, o Homem das Pedras Frias apresenta:
– Corpo: compacto e vertical, com superfície texturizada;
– Cores: cinza, branco e azul-gelo;
– Materiais: resina com pó de granito e acabamento mate;
– Expressão:  olhar fixo e sereno;
– Base: irregular, lembrando um afloramento rochoso.
A escultura integra o eixo “Corpos da Montanha” do projeto Folclore Vivo, dedicado às
entidades geológicas que expressam a fusão entre corpo e território.
⸻
Localização  específica: Montesinho, França e Portelo (distrito de Bragança).
Primeiro relato documentado: Vasconcelos, Etnografia Portuguesa, vol. IX, 1925.
Sistematização  contemporânea:  Eduardo Mauer, O Homem das Pedras Frias: Corpo e Matéria
na Mitologia de Montesinho, Associação MILK, 2025.
Fontes primárias:  Braga (1885); Vasconcelos (1925); Parafita (2008); Figueiredo (2017); Mauer
(2025).


---

# 105. A Lenda do Galo de Ouro de Chaves (Trás-os-Montes  – Vale do Tâmega)

**Origem documental:** PDF `folclore português (1).pdf`, enviado pelo utilizador.  
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

105. A Lenda do Galo de Ouro de Chaves (Trás-os-Montes  – Vale do Tâmega)
(Sistematização  contemporânea  conduzida por Eduardo Mauer no âmbito  das pesquisas sobre
Folclore Vivo da Associação  MILK – Movimento de Intervenções e Linguagens Kulturais e Arte,
com base em recolhas orais e documentais realizadas entre 2023 e 2025 em Chaves, Oura,
Vidago e Vilar de Nantes, cruzadas com fontes etnográ ficas do Museu da Região  Flaviense, do
Arquivo Municipal de Chaves e de estudos académicos  sobre simbolismo animal, lendas de
tesouros e imaginário  solar no norte de Portugal.)
⸻
1. Descrição  simbólica e narrativa
Entre as muralhas romanas de Chaves, antiga Aquae Flaviae, circula há séculos uma história
sobre um galo que canta debaixo da terra. Diz-se que o seu corpo é de ouro puro, mas o canto
é feito de luz, e que quem o escutar ao amanhecer jamais esquecerá o som — mistura de
esperança e aviso. É o Galo de Ouro de Chaves, entidade solar, guardiã de tesouros escondidos
e símbolo de renovação.


Segundo os relatos coligidos por Eduardo Mauer (2024), o galo habita um túnel subterrâneo que
liga as termas romanas ao antigo castelo. Em noites de lua cheia, o som de um leve cacarejo
metálico é ouvido sob o chão. Alguns a firmam que o galo canta sempre que o ouro da terra está
prestes a ser descoberto; outros dizem que o seu canto é prenúncio de guerra ou mudança.
A versão mais antiga da lenda conta que, durante o domínio romano, um ferreiro de Aquae
Flaviae teria fabricado um galo de ouro maciço como oferenda ao deus Júpiter. No entanto, os
soldados visigodos, ao invadir a cidade, enterraram-no para impedir que fosse saqueado. O galo
teria então ganhado vida, assumindo o dever de proteger o tesouro e o espírito da cidade.
Outras versões, recolhidas na aldeia de Oura, afirmam que o Galo de Ouro aparece no nascer do
sol de São João, quando o nevoeiro cobre o Tâmega. Quem o vir e o seguir até o seu esconderijo
encontrará “o ouro que não é para gastar”, expressão popular para designar o ouro simbólico
do renascimento interior.
Há ainda variantes cristianizadas que associam o galo ao milagre da inocência: conta-se que,
durante a Inquisição, um homem injustamente condenado à forca teria sido salvo pelo canto de
um galo assado que ressuscitou no prato do juiz — episódio semelhante ao famoso Galo de
Barcelos, mas aqui reinterpretado na tradição flaviense.
O mito do Galo de Ouro, portanto, entrelaça dois temas fundamentais: o tesouro oculto e o
canto solar da verdade. Em Chaves, é comum ouvir-se a expressão: “Quando o Galo de Ouro
cantar, a cidade acordará outra vez.”
Nas palavras de Mauer: “O Galo de Ouro é o eco solar que vive no subsolo — metáfora do
inconsciente coletivo de uma cidade que guarda, sob as ruínas, a promessa da sua própria luz.”
⸻
2. Contexto histórico e social
Chaves, situada no vale do Tâmega, foi desde a Antiguidade uma cidade termal e estratégica. O
seu subsolo guarda vestígios romanos, minas de ouro, galerias subterrâneas e restos de
aquedutos, o que explica o surgimento de lendas associadas ao ouro enterrado e guardado por
entidades mágicas .
Durante o período medieval, a região era ponto de passagem entre reinos e fronteiras, palco de
guerras e ocupações. A crença em guardiões subterrâneos surgiu como resposta simbólica à
instabilidade histórica. O galo, animal solar e vigilante, tornou-se guardião natural desses
espaços.
Na iconografia portuguesa, o galo é símbolo de vigilância  e ressurreição : anuncia o amanhecer
e afasta os maus espíritos. A sua associação ao ouro reforça a dimensão solar — metal do sol,
da claridade e da verdade. Em Chaves, essas camadas simbólicas cruzam-se com a herança
romana, onde o galo era consagrado a Mercúrio, deus das passagens e dos segredos ocultos.
O mito foi transmitido oralmente por famílias de ferreiros, mineiros e artesãos que trabalhavam o
metal e acreditavam na sua alma. Em tempos de fome, o galo tornou-se esperança: acreditava-
se que ele cantaria quando o povo voltasse a prosperar.
No século XX, a lenda foi reinterpretada por artistas locais e, recentemente, revalorizada pela
Associação  MILK, que a integra no ciclo “Animais de Luz”, explorando o galo como símbolo da
regeneração e da força criadora do povo flaviense.
⸻
3. Toponímia e variantes locais
A lenda apresenta múltiplas versões e extensões geográ ficas:


– Galo de Ouro (Chaves): figura central, subterrânea e solar;
– Galo de Luz (Oura): galo que canta apenas ao amanhecer do solstício;
– Galo do Tesouro (Vidago): protetor de minas abandonadas;
– Galo das Águas  (Vilar de Nantes): guardião das nascentes termais, de corpo dourado e crista
azul.
Topónimos como “Fonte do Galo”, “Ladeira do Tesouro” e “Poço do Ouro” aparecem em
registos municipais desde o século XVIII, indicando a antiguidade da crença. Há referências a um
antigo Arco do Galo, desaparecido no século XIX, onde, segundo crónicas locais, os viajantes se
benziam ao passar.
As variantes partilham o mesmo núcleo simbólico: o ouro como luz interior e o galo como
mediador entre escuridão  e claridade, entre o subterrâneo e o solar.
⸻
4. Primeiro relato e fontes académicas primárias
O primeiro relato escrito do Galo de Ouro de Chaves surge em Leite de Vasconcelos,
Etnografia Portuguesa, vol. IX (1925, pp. 161–167)*, onde se lê: “Em Chaves, fala-se dum galo de
ouro que canta sob as termas quando o sol desponta.”
Teófilo Braga, O Povo Português  nos seus Costumes, Crenças e Tradições (1885, pp. 764–770)*,
menciona “galos de ouro soterrados em cidades antigas” como símbolos de vigilância e
esperança, especialmente em Chaves e Lamego.
Alexandre Parafita, Mitologia Popular Portuguesa (2008, pp. 991–1003)*, dedica extenso estudo
ao mito, relacionando-o com cultos solares e tradições de renascimento, sublinhando o seu
caráter “solar e alquímico”.
A sistematização contemporânea de Eduardo Mauer, O Galo de Ouro de Chaves: Luz e
Subterrâneo  no Imaginário  Flaviense (Lisboa, Associação MILK, 2025)*, propõe uma leitura
simbólica centrada no ouro como metáfora da consciência coletiva, articulando mitologia,
arqueologia e arte contemporânea.
Fontes complementares:
– Museu da Região Flaviense, Coleção  de Lendas Urbanas de Aquae Flaviae (1970–2020);
– Arquivo Municipal de Chaves, Crónicas de Ouro e Fogo (séculos XVII–XIX);
– Tese de Doutoramento de Beatriz Cordeiro, Mitologias do Subterrâneo:  Ouro e Memória nas
Lendas do Norte de Portugal (U. Minho, 2019).
⸻
5. Síntese interpretativa final
O Galo de Ouro é símbolo de claridade interior e vigilância espiritual. Representa a promessa de
que, mesmo enterrada, a luz não se apaga. É, simultaneamente, guardião e anúncio: protege o
ouro (a sabedoria) e canta o novo dia (a esperança).
Na leitura simbólica da Associação  MILK, o galo é o sol subterrâneo , o arquétipo do despertar
coletivo. O seu canto, metálico e luminoso, é metáfora da voz criadora que rompe o silêncio.
A escultura MILK concebida por Eduardo Mauer segue a matriz padrão, com corpo compacto,
cabeça grande e crista estilizada. O corpo é dourado, com texturas que evocam escamas
metálicas, e o olhar ergue-se para o alto. O pedestal simula o subsolo, com fendas que deixam
escapar feixes de luz dourada.


Mauer descreve: “O Galo de Ouro não canta para anunciar o sol — ele é o sol a tentar ser
ouvido.”
⸻
6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer
Na leitura não binária de Eduardo Mauer, o Galo de Ouro ultrapassa a oposição entre noite e
dia, sombra e luz, matéria e espírito.
“O Galo é o corpo não binário da claridade: vive no escuro, mas é feito de luz.”
O mito propõe uma ética de coexistência: a luz subterrânea não nega a escuridão, antes a
habita e a transforma. Essa leitura é aplicada pela Associação  MILK às práticas artísticas
e pedagógicas que exploram o poder da voz e da luminosidade interior como
instrumentos de emancipação e cuidado.
O Galo de Ouro torna-se, assim, símbolo contemporâneo da criatividade não binária —
força que brota do invisível, mediando contrários e forjando harmonia.
⸻
7. Referência Estrutural da Matriz MILK
Na Matriz Escultórica MILK – Série Folclore Vivo, o Galo de Ouro de Chaves apresenta:
– Corpo: compacto, cabeça grande e crista elevada;
– Cores: dourado metálico com re flexos em cobre e vermelho;
– Materiais: resina pigmentada com pó de bronze e folha de ouro aplicada;
– Expressão:  altiva e serena;
– Base: circular, em tons terrosos, com fendas luminosas simulando o subsolo.
A escultura integra o eixo “Animais de Luz” do projeto Folclore Vivo, dedicado às entidades
luminosas e solares que simbolizam esperança, vigilância e criação.
⸻
Localização  específica: Chaves, Oura, Vidago e Vilar de Nantes (distrito de Vila Real).
Primeiro relato documentado: Vasconcelos, Etnografia Portuguesa, vol. IX, 1925.
Sistematização  contemporânea:  Eduardo Mauer, O Galo de Ouro de Chaves: Luz e Subterrâneo
no Imaginário  Flaviense, Associação MILK, 2025.
Fontes primárias:  Braga (1885); Vasconcelos (1925); Parafita (2008); Cordeiro (2019); Mauer
(2025).


---

# 106. A Lenda da Ponte das Almas de Vila Real (Trás-os-Montes  – Corgo e Tâmega)

**Origem documental:** PDF `folclore português (1).pdf`, enviado pelo utilizador.  
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

106. A Lenda da Ponte das Almas de Vila Real (Trás-os-Montes  – Corgo e Tâmega)
(Sistematização  contemporânea  conduzida por Eduardo Mauer no âmbito  das pesquisas sobre
Folclore Vivo da Associação  MILK – Movimento de Intervenções e Linguagens Kulturais e Arte,
com base em recolhas orais e documentais realizadas entre 2023 e 2025 em Vila Real, Borbela,
Mateus e Andrães,  cruzadas com fontes etnográ ficas do Museu da Vila Velha, do Arquivo Distrital
de Vila Real e de estudos académicos  sobre lendas hagiográ ficas, simbolismo hidráulico  e
narrativas espirituais transmontanas.)
⸻
1. Descrição  simbólica e narrativa

Na cidade de Vila Real, sobre o rio Corgo, ergue-se uma antiga ponte de pedra — estreita, de
arco único, envolta por vegetação e silêncio. Chamam-lhe a Ponte das Almas, e dizem que nela
ainda se escutam vozes que sussurram nomes de quem partiu sem despedida.
Segundo os relatos coligidos por Eduardo Mauer (2024), a lenda conta que a ponte foi
construída no século XV, durante a expansão da vila. Um pedreiro, ao terminar a obra, caiu ao rio
e morreu afogado. Desde então, em noites de nevoeiro, ouve-se o som de passos sobre a ponte,
embora ninguém atravesse. Acredita-se que é a alma do pedreiro que volta, veri ficando se a
estrutura ainda resiste ao tempo.
Mas a narrativa ganhou outras versões ao longo dos séculos. Uma delas fala de dois amantes
separados pela guerra, que juraram reencontrar-se na ponte ao fim de sete anos. O homem
regressou, mas a mulher havia morrido. Na madrugada seguinte, um pescador viu duas figuras
brancas caminhando lado a lado sobre o arco da ponte, desaparecendo no nevoeiro.
Noutra versão, o nome “Ponte das Almas” nasce de uma crença medieval segundo a qual todas
as almas penadas precisavam cruzar uma ponte espiritual para alcançar a luz. A ponte física
em Vila Real seria, assim, o reflexo visível dessa travessia invisível — um limiar entre mundos.
A tradição popular associa o local a um silêncio sagrado: “Quem atravessa a Ponte das Almas
não deve falar”, dizem os habitantes. O ruído perturba o descanso das almas e pode atrair “a
sombra do afogado”, figura que se aproxima de quem caminha sem respeito.
Em registos orais recolhidos por Mauer junto de moradores de Andrães, a ponte é também vista
como passagem de reconciliação : muitos habitantes que perderam familiares regressam ao
local para “falar com os seus mortos”. É ali, dizem, que o vento traduz as palavras humanas na
língua das almas.
O mito, portanto, articula três dimensões — a morte, a memória e o som. A ponte é
simultaneamente estrutura material e símbolo de passagem: é a voz do rio transformada em
caminho.
Mauer escreve: “A Ponte das Almas é a mais delicada das arquiteturas transmontanas —
construída não apenas de pedra, mas de tempo e ausência.”
⸻
2. Contexto histórico e social
A Ponte das Almas localiza-se nos arredores de Vila Real, sobre o rio Corgo, afluente do
Tâmega. A cidade, fundada no século XIII, sempre se desenvolveu junto das margens e dos
vales, onde a presença da água moldou o ritmo da vida.
Durante a Idade Média, pontes eram locais de liminaridade e fé — cruzamentos entre o terreno e
o sagrado. Eram espaços de peregrinação, de pagamento de promessas e de passagem de
cortejos fúnebres. Em muitos contextos europeus, acreditava-se que as almas atravessavam
pontes no caminho para o além.
O caso de Vila Real é exemplar: a ponte marca o encontro entre o mundo urbano e o natural, o
humano e o espiritual. Durante séculos, as populações rurais próximas realizavam procissões
noturnas com velas para homenagear os mortos — tradição que subsiste parcialmente nas
“Luminárias  das Almas”, celebradas ainda hoje em algumas aldeias.
No século XIX, com o declínio das práticas devocionais, a ponte tornou-se espaço de histórias
trágicas e amores impossíveis — símbolo de saudade e perda. O romantismo literário português
ajudou a reforçar essa visão, transformando a ponte em metáfora do intransponível.


Atualmente, a Ponte das Almas é integrada nos roteiros patrimoniais de Vila Real e no programa
“Folclore Vivo – Caminhos Invisíveis”, coordenado pela Associação  MILK, que propõe uma
leitura simbólica contemporânea: o monumento como metáfora de continuidade entre memória,
natureza e comunidade.
⸻
3. Toponímia e variantes locais
A lenda apresenta diferentes designações:
– Ponte das Almas (Vila Real): versão principal e hagiográ fica;
– Ponte Velha do Corgo (Mateus): nome histórico, associado ao trânsito comercial;
– Ponte da Promessa (Borbela): variante romântica ligada ao encontro dos amantes;
– Ponte dos Sussurros (Andrães): interpretação poética mais recente.
Os topónimos “Vale das Almas” e “Ribeiro da Luz” aparecem em documentos municipais do
século XVIII, indicando o caráter sagrado da região. O termo “ponte das almas” repete-se em
outras zonas do norte, mas a versão de Vila Real distingue-se pela associação direta ao rio Corgo
e à ideia de reconciliação entre vivos e mortos.
⸻
4. Primeiro relato e fontes académicas primárias
O primeiro registro escrito da Ponte das Almas surge em Leite de Vasconcelos, Etnografia
Portuguesa, vol. IX (1925, pp. 168–174)*, que descreve “ponte antiga junto ao Corgo, tida como
passagem das almas e lugar onde o vento fala em nome dos mortos”.
Teófilo Braga, O Povo Português  nos seus Costumes, Crenças e Tradições (1885, pp. 771–776)*,
já fazia referência a pontes encantadas do norte de Portugal, associadas a ritos de travessia e ao
simbolismo da água como fronteira espiritual.
Alexandre Parafita, Mitologia Popular Portuguesa (2008, pp. 1004–1015)*, dedica capítulo à
simbologia das pontes na mitologia lusitana, interpretando-as como “lugares de passagem da
matéria para o espírito”.
A sistematização contemporânea de Eduardo Mauer, A Ponte das Almas de Vila Real: Travessia
e Escuta no Imaginário  Hidráulico  Transmontano (Lisboa, Associação MILK, 2025)*, integra
depoimentos orais, estudos etnográ ficos e leituras fenomenológicas, propondo o conceito de
“ponte sonora” — espaço onde o som e o silêncio funcionam como mediações espirituais.
Fontes complementares:
– Museu da Vila Velha, Coleção  de Lendas e Patrimónios Flavienses (1970–2019);
– Arquivo Distrital de Vila Real, Crónicas do Corgo e do Tâmega  (séculos XVII–XIX);
– Tese de Doutoramento de Lara Meireles, A Água  e o Além:  Simbolismo Hidráulico  no Imaginário
Popular Português  (U. Porto, 2018).
⸻
5. Síntese interpretativa final
A Ponte das Almas é metáfora da travessia e da escuta. Representa o limiar onde o humano
reconhece a continuidade entre corpo e memória, som e ausência.
Na leitura simbólica da Associação  MILK, a ponte é o corpo da passagem — estrutura física
que traduz uma ética espiritual: atravessar respeitando o invisível. É também símbolo da arte e da
criação: a obra que liga margens e tempos.


A escultura MILK concebida por Eduardo Mauer segue a matriz padrão, mas incorpora
elementos arquitetónicos. O corpo compacto apresenta arco na zona abdominal, evocando a
forma da ponte; a cabeça é voltada para baixo, como quem escuta o rio. As cores vão do cinza-
ardósia ao azul profundo, com leve brilho prateado que simula o reflexo da água noturna.
Mauer escreve: “A ponte é o corpo que escuta o rio — e, escutando, recorda.”
⸻
6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer
Na leitura não binária de Eduardo Mauer, a Ponte das Almas dissolve as dualidades entre vida e
morte, presença e ausência, som e silêncio.
“A ponte é o corpo não binário da travessia — simultaneamente chão e abismo.”
O mito revela que o limiar é espaço de coexistência e não de separação. A ponte liga o
que o medo separa; transforma a perda em encontro, o luto em escuta.
Para a Associação  MILK, essa leitura fundamenta práticas de arte pública e educação
estética centradas na mediação  e na escuta coletiva, inspirando projetos comunitários
que trabalham o som, a memória e o cuidado como instrumentos de ligação.
A Ponte das Almas é, assim, um manifesto poético sobre a necessidade de atravessar
juntos — com respeito, silêncio e presença.
⸻
7. Referência Estrutural da Matriz MILK
Na Matriz Escultórica MILK – Série Folclore Vivo, a Ponte das Almas de Vila Real apresenta:
– Corpo: compacto, com arco esculpido na parte inferior;
– Cores: cinza, azul e prata;
– Materiais: resina pigmentada com pó de ardósia e acabamento semibrilhante;
– Expressão:  contemplativa, cabeça inclinada;
– Base: elíptica, com textura ondulada representando o rio.
A escultura integra o eixo “Caminhos Invisíveis” do projeto Folclore Vivo, dedicado a mitos de
travessia e reconciliação espiritual.
⸻
Localização  específica: Vila Real, Borbela, Mateus e Andrães (distrito de Vila Real).
Primeiro relato documentado: Vasconcelos, Etnografia Portuguesa, vol. IX, 1925.
Sistematização  contemporânea:  Eduardo Mauer, A Ponte das Almas de Vila Real: Travessia e
Escuta no Imaginário  Hidráulico  Transmontano, Associação MILK, 2025.
Fontes primárias:  Braga (1885); Vasconcelos (1925); Parafita (2008); Meireles (2018); Mauer
(2025).


---

# 107. A Lenda da Senhora do Salto (Aguiar de Sousa – Vale do Sousa, Distrito do Porto)

**Origem documental:** PDF `folclore português (1).pdf`, enviado pelo utilizador.  
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

107. A Lenda da Senhora do Salto (Aguiar de Sousa – Vale do Sousa, Distrito do Porto)
(Sistematização  contemporânea  conduzida por Eduardo Mauer no âmbito  das pesquisas sobre
Folclore Vivo da Associação  MILK – Movimento de Intervenções e Linguagens Kulturais e Arte,
com base em recolhas orais e documentais realizadas entre 2023 e 2025 em Aguiar de Sousa,
Paredes e Gondomar, cruzadas com fontes etnográ ficas do Museu Municipal de Paredes, do

Arquivo Distrital do Porto e de estudos académicos  sobre hagiografia popular, cultos marianos e
simbolismo fluvial no norte de Portugal.)
⸻
1. Descrição  simbólica e narrativa
No profundo vale cavado pelo rio Sousa, a poucos quilómetros de Aguiar de Sousa, ergue-se
um desfiladeiro abrupto, de rochedos escuros e som retumbante. É ali que o povo acredita que
se deu o milagre da Senhora do Salto, uma das mais antigas e veneradas lendas marianas do
norte de Portugal.
Conta-se que, há muitos séculos, um cavaleiro arrogante, de nome incerto — ora Gonçalo, ora
Nuno —, regressava de uma caçada. Montava um cavalo negro e descia a encosta a galope,
quando um demónio lhe apareceu na forma de nevoeiro, desafiando-o a saltar o abismo.
Tomado pela soberba, o cavaleiro cravou as esporas no animal e lançou-se no precipício,
gritando que nem Deus o poderia deter. Nesse instante, a Virgem Maria apareceu sobre as
pedras, estendeu o manto azul e suspendeu o cavalo no ar. O salto ficou gravado na rocha, e o
cavaleiro caiu de joelhos, reconhecendo o milagre.
As marcas das ferraduras, dizem, ainda hoje se veem nas fragas junto ao santuário, e nas noites
de tempestade o som do cavalo ecoa como aviso aos soberbos.
As recolhas orais de Eduardo Mauer (2024) documentam diferentes variações: em algumas, o
cavaleiro é descrito como mouro convertido; noutras, como fidalgo local que renega a fé. Em
todas, o gesto da Virgem transforma o abismo em espaço de salvação, tornando o “salto”
símbolo de redenção  pela humildade.
O milagre deu origem ao Santuário  da Senhora do Salto, hoje centro de romarias e festividades.
O local, dominado por formações rochosas e águas profundas, conserva uma energia que o povo
descreve como “mistura de medo e graça”.
Mauer resume: “A Senhora do Salto não é apenas a que salva — é a que interrompe a queda, a
que converte o instante do abismo em gesto de misericórdia.”
⸻
2. Contexto histórico e social
A lenda da Senhora do Salto insere-se num contexto de religiosidade medieval profundamente
marcado pelos cultos marianos locais, nos quais a Virgem aparece em lugares de perigo —
penhascos, rios, grutas — para mediar a relação entre o humano e o divino.
O vale de Aguiar de Sousa pertence a uma região antiga de transição entre o litoral e o interior,
atravessada por rotas comerciais e militares. Desde o século XII, a presença de mosteiros
beneditinos e cistercienses (como o de Paço de Sousa) difundiu práticas devocionais centradas
na intercessão mariana e na puri ficação dos pecados.
Durante o século XVII, a devoção à Senhora do Salto ganhou caráter o ficial com a construção da
ermida junto ao penedo do milagre, documentada em 1652. Nos séculos seguintes, o santuário
tornou-se importante centro de peregrinação, especialmente entre trabalhadores rurais e mineiros
da região, que ali pediam proteção contra quedas e acidentes.
No século XX, com a criação do Parque Natural da Senhora do Salto, o lugar passou a ser
simultaneamente espaço religioso e ecológico. Hoje, o santuário acolhe não apenas peregrinos,
mas também visitantes atraídos pela imponência da natureza e pela força simbólica do
desfiladeiro.


A Associação  MILK, sob coordenação de Eduardo Mauer, inclui esta lenda no eixo “Territórios
do Milagre”, explorando-a como arquétipo da travessia interior, onde o medo e a fé se
encontram no mesmo salto.
⸻
3. Toponímia e variantes locais
A designação “ Senhora do Salto” é exclusiva do santuário de Aguiar de Sousa, mas variantes da
lenda espalham-se por outras regiões com o mesmo tema do milagre sobre o abismo:
– Senhora da Ponte (Marco de Canaveses), onde a Virgem impede a queda de um carro de bois;
– Senhora da Rocha (Amares), ligada a uma aparição sobre penedo;
– Senhora do Vale (Resende), protetora dos viajantes.
Topónimos como “Penedo do Cavalo”, “Fraga da Ferradura” e “Vale da Graça” são
mencionados em registos do Arquivo Distrital do Porto (século XVIII).
A versão de Aguiar de Sousa distingue-se por unir elemento natural (o penedo e o rio) e
elemento moral (a soberba e a redenção) , o que explica a sua longevidade e o estatuto de
lugar sagrado.
⸻
4. Primeiro relato e fontes académicas primárias
O primeiro registro escrito da lenda da Senhora do Salto surge em Leite de Vasconcelos,
Etnografia Portuguesa, vol. IX (1925, pp. 175–182)*, que descreve o “milagre da Virgem sobre o
abismo do Sousa”.
Teófilo Braga, O Povo Português  nos seus Costumes, Crenças e Tradições (1885, pp. 777–784)*,
já mencionava lendas de aparições marianas sobre rochedos e associava a Senhora do Salto às
tradições ibéricas da “Virgem Interventora” — figura que detém o curso da natureza para salvar o
humano.
Alexandre Parafita, Mitologia Popular Portuguesa (2008, pp. 1016–1026)*, insere a lenda no
contexto das “hierofanias aquáticas”, interpretando o salto como passagem simbólica entre
orgulho e humildade, matéria e espírito.
A sistematização contemporânea de Eduardo Mauer, A Senhora do Salto: Milagre e Travessia no
Vale do Sousa (Lisboa, Associação MILK, 2025)*, combina estudo etnográ fico, recolha oral e
análise fenomenológica, destacando o gesto de suspensão como metáfora estética e espiritual.
Fontes complementares:
– Museu Municipal de Paredes, Coleção  de Lendas e Romarias do Vale do Sousa (1960–2020);
– Arquivo Distrital do Porto, Documentos Paroquiais e Romarias de Aguiar de Sousa (séculos
XVII–XIX);
– Tese de Doutoramento de Clara Mourão, O Milagre e o Abismo: Aparições Marianas em
Contexto de Risco Natural (U. Porto, 2016).
⸻
5. Síntese interpretativa final
A Senhora do Salto representa o momento em que o humano enfrenta o limite — o precipício —
e encontra a salvação não na força, mas na entrega. O “salto” é, assim, menos físico que
existencial.


Na leitura simbólica da Associação  MILK, o mito expressa o arquétipo da travessia
interrompida: o corpo suspenso entre queda e ascensão. O gesto da Virgem é gesto artístico —
um ato de interrupção criadora.
A escultura MILK concebida por Eduardo Mauer segue a matriz padrão, apresentando corpo
compacto e cabeça elevada, com manto que se desdobra em forma de penhasco. A figura
sustém, nas mãos abertas, um pequeno cavalo dourado — símbolo do orgulho humano detido
pela misericórdia. As cores alternam entre o azul profundo e o dourado translúcido, evocando o
encontro entre céu e terra.
Mauer descreve: “A Senhora do Salto é o instante em que o corpo deixa de cair e começa a
flutuar — o tempo em que o medo se converte em fé.”
⸻
6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer
Na leitura não binária de Eduardo Mauer, a Senhora do Salto dissolve as fronteiras entre
salvação e queda, pecado e graça, masculino e feminino.
“O milagre não está em deter o corpo, mas em compreender que cair e voar são o mesmo
gesto, visto de lados diferentes.”
O mito propõe uma espiritualidade fluida, onde o divino e o humano coexistem em
interdependência. A Virgem não é apenas figura materna e celestial, mas força neutra que
suspende o desequilíbrio.
A Associação  MILK interpreta o mito como modelo de cura simbólica e estética,
integrando-o em ações pedagógicas que exploram a travessia como experiência criativa
— do medo à con fiança, da rigidez à fluidez.
⸻
7. Referência Estrutural da Matriz MILK
Na Matriz Escultórica MILK – Série Folclore Vivo, a Senhora do Salto apresenta:
– Corpo: compacto e vertical, manto em formato de penhasco;
– Cores: azul-cobalto, branco e dourado translúcido;
– Materiais: resina pigmentada e folha de ouro;
– Expressão:  serena e protetora;
– Base: rochosa, com forma ascendente.
A escultura integra o eixo “Territórios do Milagre” do projeto Folclore Vivo, dedicado às
aparições e hierofanias que reconfiguram a relação entre fé, corpo e natureza.
⸻
Localização  específica: Aguiar de Sousa (Paredes, distrito do Porto).
Primeiro relato documentado: Vasconcelos, Etnografia Portuguesa, vol. IX, 1925.
Sistematização  contemporânea:  Eduardo Mauer, A Senhora do Salto: Milagre e Travessia no
Vale do Sousa, Associação MILK, 2025.
Fontes primárias:  Braga (1885); Vasconcelos (1925); Parafita (2008); Mourão (2016); Mauer
(2025).


---

# 108. A Lenda do Poço dos Mouros (Amarante – Serra do Marão)

**Origem documental:** PDF `folclore português (1).pdf`, enviado pelo utilizador.  
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

108. A Lenda do Poço dos Mouros (Amarante – Serra do Marão)

(Sistematização  contemporânea  conduzida por Eduardo Mauer no âmbito  das pesquisas sobre
Folclore Vivo da Associação  MILK – Movimento de Intervenções e Linguagens Kulturais e Arte,
com base em recolhas orais e documentais realizadas entre 2023 e 2025 em Amarante, Lomba,
Vila Chã  do Marão  e Canadelo, cruzadas com fontes etnográ ficas do Museu Amadeo de Souza-
Cardoso, do Arquivo Municipal de Amarante e de estudos académicos  sobre mitologia aquática,
imaginário  mourisco e simbologia subterrânea  no norte de Portugal.)
⸻
1. Descrição  simbólica e narrativa
No coração da Serra do Marão , onde as neblinas parecem esconder segredos e as águas
nascem frias e silenciosas, existe um lugar temido e venerado: o Poço dos Mouros. O poço,
formado por um desnível rochoso onde o rio Olo mergulha subitamente, é tido como morada de
seres encantados — mouros, mouras e serpentes de ouro — que guardam tesouros invisíveis e
memórias esquecidas.
Segundo as tradições recolhidas por Eduardo Mauer (2024), o Poço dos Mouros é tão fundo
“que não tem fim”, e quem nele olha demasiado tempo corre o risco de ver o próprio destino
refletido nas águas. Há quem diga que, ao meio-dia, o poço se ilumina por dentro, revelando o
brilho de uma cidade de ouro submersa. Outros afirmam que, nas noites de São João, se ouvem
cânticos vindos das profundezas, e que uma moura de longos cabelos prateados sobe à
superfície para pentear-se sob a lua.
Numa das versões mais antigas, contada por pastores de Canadelo, o poço seria o túmulo de um
rei mouro derrotado, que ao morrer amaldiçoou o vale, prometendo regressar “quando o ouro e
o luar se unissem”. Desde então, quem atira uma pedra ao poço ou profana o local é punido por
sonhos inquietos e doenças inexplicáveis.
Outras versões descrevem o Poço dos Mouros como portal entre mundos, guardado por uma
serpente de olhos verdes que, a cada cem anos, se transforma em mulher. Se alguém aceitar o
seu beijo sem medo, ela oferece um anel de luz e desaparece para sempre, libertando o feitiço.
O imaginário popular mistura medo e fascínio. As águas do poço são, ao mesmo tempo, abismo
e espelho, símbolo da fronteira entre o visível e o oculto. O mito ensina que há tesouros que só
podem ser vistos por quem não deseja possuí-los.
Mauer resume: “O Poço dos Mouros é o coração líquido do Marão — onde o tempo dorme, e o
ouro é apenas a luz que a alma reconhece.”
⸻
2. Contexto histórico e social
A presença de lendas mouriscas no norte de Portugal é herança da ocupação islâmica e da longa
convivência entre culturas durante a Idade Média. No caso de Amarante, a tradição dos “mouros
encantados” sobreviveu de forma particularmente intensa, associada a rios, fontes e poços.
A Serra do Marão , com as suas formações geológicas e nascentes profundas, gerou um
imaginário aquático e mineral que funde religiosidade popular, mitologia pagã e memória
histórica. O poço, enquanto figura simbólica, representa profundidade, segredo e regeneração
— temas universais presentes em múltiplas tradições espirituais.
Durante séculos, os poços e nascentes foram lugares de culto e sacrifício. As comunidades rurais
realizavam rituais de proteção das águas e de comunicação com o invisível. A lenda do Poço dos
Mouros é, portanto, testemunho da antiga sacralização  da água  e da sua associação com o
feminino, a fertilidade e o mistério.


No século XIX, estudiosos como Pinho Leal e Leite de Vasconcelos registraram histórias
semelhantes em todo o norte: “poços que guardam mouras”, “fontes que brilham ao meio-dia”,
“rios onde o ouro dorme”. O mito foi reinterpretado à luz do romantismo como expressão da
alma telúrica portuguesa, onde o sagrado se confunde com o natural.
Hoje, o Poço dos Mouros é destino de caminhantes e curiosos, integrando o Parque Natural do
Alvão–Marão . O local permanece inalterado, guardando o silêncio que o mito exige. A
Associação  MILK, sob coordenação de Eduardo Mauer, incorporou esta lenda no eixo “Águas
Encantadas” do projeto Folclore Vivo, enfatizando a água como metáfora da memória e do
inconsciente coletivo.
⸻
3. Toponímia e variantes locais
A lenda manifesta-se em diversas localidades da Serra do Marão e arredores:
– Poço dos Mouros (Amarante): versão principal, ligada ao rio Olo;
– Lagoa das Mouras (Canadelo): variante centrada na moura encantada;
– Poço da Cobra de Ouro (Vila Chã do Marão): associada à serpente guardiã;
– Poço do Encantamento (Lomba): versão mais simbólica, sem tesouro material.
Topónimos como “Fonte Mourisca”, “Vale das Serpentes” e “Caminho do Tesouro” aparecem
em registos paroquiais e em cartas militares do século XVIII, sugerindo ampla difusão do mito na
região.
Essas variantes reforçam o caráter hidromítico do Marão: cada nascente ou poço é um ponto de
comunicação entre mundos, onde o invisível toca o visível.
⸻
4. Primeiro relato e fontes académicas primárias
O primeiro registro escrito da Lenda do Poço dos Mouros aparece em Leite de Vasconcelos,
Etnografia Portuguesa, vol. IX (1925, pp. 183–189)*, que descreve “poço de águas fundas e
insondáveis em Amarante, onde o povo crê viverem mouros encantados e guardas de ouro”.
Teófilo Braga, O Povo Português  nos seus Costumes, Crenças e Tradições (1885, pp. 785–790)*,
já referia “fontes e poços encantados do norte”, interpretando o mito dos mouros como
sobrevivência do paganismo pré-cristão e da mitologia aquática europeia.
Alexandre Parafita, Mitologia Popular Portuguesa (2008, pp. 1027–1039)*, dedica extenso
capítulo ao imaginário mourisco, de finindo o Poço dos Mouros como “santuário subterrâneo
onde o tempo não flui como entre os vivos”.
A sistematização contemporânea de Eduardo Mauer, O Poço dos Mouros: Água,  Encantamento
e Memória no Marão  (Lisboa, Associação MILK, 2025)*, articula fontes orais recolhidas em Lomba
e Canadelo com análise estética da água como espelho do inconsciente coletivo, estabelecendo
paralelos entre mitologia lusa e psicanálise junguiana.
Fontes complementares:
– Museu Amadeo de Souza-Cardoso, Coleção  de Lendas do Marão  e do Alvão  (1965–2019);
– Arquivo Municipal de Amarante, Registos de Património Imaterial e Toponímia Popular (séculos
XVII–XX);
– Tese de Doutoramento de Joana Taveira, As Mouras e o Feminino Subterrâneo:  Mitologias da
Água  em Portugal (U. Lisboa, 2018).
⸻


5. Síntese interpretativa final
O Poço dos Mouros é símbolo da profundidade espiritual e da sedução do desconhecido. Nele,
o ouro representa não a riqueza material, mas o brilho do autoconhecimento — o tesouro oculto
que exige coragem para ser contemplado.
Na leitura simbólica da Associação  MILK, o poço é o útero do mundo, espaço de gestação e
esquecimento. Mergulhar no seu mistério é aceitar o chamado da sombra — e reconhecer que o
medo é também via de iniciação.
A escultura MILK concebida por Eduardo Mauer representa a moura de água em forma
compacta, cabeça grande e corpo ondulante. A superfície reflete tons de azul-turquesa, prata e
verde-esmeralda, com textura líquida. Nos olhos, pequenas incrustações douradas evocam o
ouro mítico.
Mauer escreve: “O Poço dos Mouros é o espelho onde o humano se vê dissolver — e, nesse
reflexo, reencontra a origem.”
⸻
6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer
Na leitura não binária de Eduardo Mauer, o Poço dos Mouros é metáfora da coexistência dos
opostos: luz e sombra, superfície e profundidade, masculino e feminino.
“A água é o corpo não binário por excelência — molda-se a tudo sem deixar de ser o que
é.”
O mito das mouras aquáticas é reinterpretado como narrativa sobre fluidez identitária e
afetiva. O poço torna-se símbolo do ser em transformação , espaço onde o corpo e a
alma se reinventam.
A Associação  MILK adota essa leitura nas suas práticas pedagógicas e artísticas,
utilizando a lenda como ponto de partida para discussões sobre ecologia, identidade e
escuta interior. O poço é o lugar do diálogo entre mundos — uma pedagogia da
profundidade.
⸻
7. Referência Estrutural da Matriz MILK
Na Matriz Escultórica MILK – Série Folclore Vivo, o Poço dos Mouros apresenta:
– Corpo: compacto e ondulante, com base circular simulando água;
– Cores: azul-turquesa, verde e prata;
– Materiais: resina translúcida com pigmento aquático e acabamento perolado;
– Expressão:  serena, com olhar reflexivo;
– Base: espelhada, representando a superfície do poço.
A escultura integra o eixo “Águas  Encantadas” do projeto Folclore Vivo, dedicado às entidades
aquáticas e subterrâneas do imaginário luso.
⸻
Localização  específica: Amarante, Lomba, Vila Chã do Marão e Canadelo (distrito do Porto).
Primeiro relato documentado: Vasconcelos, Etnografia Portuguesa, vol. IX, 1925.
Sistematização  contemporânea:  Eduardo Mauer, O Poço dos Mouros: Água,  Encantamento e
Memória no Marão , Associação MILK, 2025.


Fontes primárias:  Braga (1885); Vasconcelos (1925); Parafita (2008); Taveira (2018); Mauer
(2025).


---

# 109. A Lenda da Fraga Amarela (Baião  – Serra da Aboboreira)

**Origem documental:** PDF `folclore português (1).pdf`, enviado pelo utilizador.  
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

109. A Lenda da Fraga Amarela (Baião  – Serra da Aboboreira)
(Sistematização  contemporânea  conduzida por Eduardo Mauer no âmbito  das pesquisas sobre
Folclore Vivo da Associação  MILK – Movimento de Intervenções e Linguagens Kulturais e Arte,
com base em recolhas orais e documentais realizadas entre 2023 e 2025 em Baião,  Gestaçô,
Loivos do Monte e Ovil, cruzadas com fontes etnográ ficas do Museu Municipal de Baião,  do
Arquivo Distrital do Porto e de estudos académicos  sobre mitologia mineral, cromatismo
simbólico e narrativas encantatórias no norte de Portugal.)
⸻
1. Descrição  simbólica e narrativa
Na encosta poente da Serra da Aboboreira, sob a luz intensa que ao entardecer tinge as pedras
de ouro, ergue-se uma formação rochosa que o povo chama Fraga Amarela. O nome não deriva
apenas da cor, mas do encantamento que a envolve. Segundo a tradição, essa fraga é habitada
por uma moura luminosa, guardiã de um tesouro escondido e senhora de um segredo que só o
silêncio pode desvendar.
A lenda, recolhida por Eduardo Mauer (2024) junto de pastores e lavradores de Gestaçô e Loivos
do Monte, conta que todas as primaveras, no domingo da Ressurreição, ao nascer do sol, a fraga
brilha com luz própria. Nesse momento, uma mulher de longos cabelos dourados surge sentada
sobre a pedra, penteando-se com um pente de ouro. Os que a veem devem permanecer imóveis
e não falar, pois basta uma palavra para que ela desapareça.
Dizem que um jovem pastor, movido pela curiosidade, aproximou-se e perguntou-lhe quem era. A
moura sorriu, respondeu “sou o que a terra esconde e o sol revela” e, antes que ele pudesse
continuar, a fraga estremeceu e tudo voltou à escuridão.
Em outras versões, a Fraga Amarela não é apenas morada da moura, mas a própria encarnação
do sol. O amarelo seria o rastro de um antigo fogo celeste que caiu sobre a serra, petrificando a
luz. Em noites de luar, a fraga brilha de dentro para fora, como se guardasse um coração ardente.
As versões mais tardias (século XX) ligam o mito a tesouros mouriscos enterrados durante as
invasões cristãs. Um relato colhido por Mauer descreve camponeses que, ao cavar nas
imediações, encontraram um pote com uma moeda de ouro e uma serpente viva enrolada —
símbolo de proteção ancestral.
O encanto persiste porque ninguém conseguiu decifrar o verdadeiro tesouro da Fraga Amarela. O
povo diz: “Quem procura o ouro perde a luz; quem contempla a luz encontra o ouro.”
Mauer sintetiza: “A Fraga Amarela é o altar mineral do sol — a matéria que aprendeu a brilhar.”
⸻
2. Contexto histórico e social
A Serra da Aboboreira, situada entre os concelhos de Baião, Amarante e Marco de Canaveses,
é território arqueológico de excecional relevância, com dólmens, antas e gravuras rupestres
datadas do Neolítico. A presença da lenda da Fraga Amarela insere-se num continuum de cultos
solares e práticas votivas ligadas às pedras e aos ciclos da luz.
Durante a Idade do Bronze, o culto do Sol e do Ouro espalhou-se pelo noroeste peninsular, e as
formações geológicas de coloração amarela eram consideradas sagradas. Com a romanização,

esses cultos foram assimilados e reinterpretados sob figuras como Aurora e Sol Invictus,
permanecendo na memória coletiva mesmo após a cristianização.
A associação entre moura e luz representa uma fusão entre o paganismo e o imaginário
medieval. A moura é a guardiã do conhecimento subterrâneo; o amarelo, a cor da revelação.
Juntas, formam um arquétipo de transição entre sombra e claridade.
No contexto rural contemporâneo, a Fraga Amarela conserva importância simbólica e identitária.
É lugar de passagem para os rebanhos, ponto de orientação para caminhantes e cenário de
histórias transmitidas nas noites frias, junto ao lume.
A Associação  MILK, sob a coordenação de Eduardo Mauer, integra a Fraga Amarela no eixo
“Pedras e Luas” do projeto Folclore Vivo, como metáfora do encontro entre matéria e luz,
memória e permanência.
⸻
3. Toponímia e variantes locais
A designação Fraga Amarela aparece em registos paroquiais desde o século XVIII. O termo
“fraga” (do latim fracta, quebrada) designa penedo ou rochedo isolado; “amarela” refere-se tanto
à cor visível como à simbologia solar.
Variantes da lenda são conhecidas nas freguesias de Gestaçô, Ovil e Loivos do Monte, e
também noutras serras vizinhas sob nomes como “ Pedra Dourada” (Amarante) e “Lomba do
Sol” (Marco de Canaveses).
Em todas, o elemento comum é a presença de luz sobrenatural e tesouro oculto, associando o
ouro mineral ao ouro espiritual. Documentos do Arquivo Distrital do Porto (1793–1821) referem o
local como “Fraga de Nossa Senhora da Luz”, indício de sincretismo religioso posterior.
⸻
4. Primeiro relato e fontes académicas primárias
O primeiro registro escrito da Fraga Amarela encontra-se em Leite de Vasconcelos, Etnografia
Portuguesa, vol. IX (1925, pp. 190–197)*, onde o autor menciona “penedo de coloração viva em
Baião, de onde o povo a firma sair luz e voz de mulher”.
Teófilo Braga, em O Povo Português  nos seus Costumes, Crenças e Tradições (1885, pp. 791–
795)*, discute as “fragas douradas” do norte, interpretando-as como sobrevivência dos cultos
solares célticos e descrevendo-as como “pontos de fecundação simbólica da terra”.
Alexandre Parafita, Mitologia Popular Portuguesa (2008, pp. 1040–1049)*, inclui a Fraga Amarela
no corpus das “lendas luminosas”, defendendo que o brilho amarelado das pedras inspirou o
imaginário do ouro encantado e das mouras resplandecentes.
A sistematização contemporânea de Eduardo Mauer, Fraga Amarela: Luz, Matéria  e
Encantamento na Serra da Aboboreira (Lisboa, Associação MILK, 2025)*, combina observação
etnográ fica, análise fenomenológica da luz natural e recolha oral, propondo uma leitura estética e
espiritual da fraga como “relicário mineral da memória solar”.
Fontes complementares:
– Museu Municipal de Baião, Catálogo  de Lendas e Locais Sagrados da Aboboreira (1958–2020);
– Arquivo Distrital do Porto, Cartas Paroquiais e Registos de Património Oral de Baião  (séculos
XVIII–XX);
– Tese de Doutoramento de Marta Cordeiro, Pedras que Falam: Arqueomitologia e Paisagem
Sagrada no Noroeste Ibérico  (U. Minho, 2019).


⸻
5. Síntese interpretativa final
A Fraga Amarela é a cristalização do instante em que a luz se torna corpo. É o sol petri ficado, o
ouro imaterial que habita o seio da montanha. O mito afirma que a verdadeira riqueza não é o
tesouro escondido, mas a capacidade de ver o brilho onde outros veem pedra.
Na leitura simbólica da Associação  MILK, a Fraga Amarela representa o ciclo da revelação  — o
ponto em que a matéria se torna luminosa, a arte se torna natureza e o olhar se converte em
criação.
A escultura MILK concebida por Eduardo Mauer segue a matriz padrão, com corpo compacto e
cabeça levemente inclinada para cima, como quem recebe a luz. A superfície é revestida por
pigmentos amarelo-ocre e dourado translúcido, com pequenos reflexos que variam conforme o
ângulo da observação. No peito, um círculo solar em relevo simboliza o coração radiante da
fraga.
Mauer escreve: “A Fraga Amarela é o corpo que aprendeu a brilhar por dentro.”
⸻
6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer
Na leitura não binária de Eduardo Mauer, a Fraga Amarela é a dissolução dos limites entre luz e
sombra, feminino e masculino, visível e invisível.
“A fraga é o corpo mineral não binário: sólido e radiante, imóvel e vivo.”
O mito convida a compreender a identidade como fenômeno da luz — algo que se
manifesta em intensidades variáveis, sem forma fixa. A moura, com seu cabelo dourado,
não é mulher nem espírito, mas energia luminosa encarnada.
A Associação  MILK interpreta a Fraga Amarela como emblema da arte enquanto
travessia luminosa, propondo práticas pedagógicas que exploram o corpo como
superfície de brilho e escuta. O mito torna-se, assim, ponto de partida para uma reflexão
sobre visibilidade, pertença e transformação.
⸻
7. Referência Estrutural da Matriz MILK
Na Matriz Escultórica MILK – Série Folclore Vivo, a Fraga Amarela apresenta:
– Corpo: compacto, com leve inclinação para cima;
– Cores: amarelo-ocre, dourado translúcido e reflexos ocres;
– Materiais: resina com pigmentos minerais e acabamento luminescente;
– Expressão:  serena e radiante;
– Base: polida, refletindo a luz como superfície solar.
A escultura integra o eixo “Pedras e Luas” do projeto Folclore Vivo, dedicado aos mitos de luz e
matéria.
⸻
Localização  específica: Baião, Gestaçô, Ovil e Loivos do Monte (distrito do Porto).
Primeiro relato documentado: Vasconcelos, Etnografia Portuguesa, vol. IX, 1925.


Sistematização  contemporânea:  Eduardo Mauer, Fraga Amarela: Luz, Matéria  e Encantamento
na Serra da Aboboreira, Associação MILK, 2025.
Fontes primárias:  Braga (1885); Vasconcelos (1925); Parafita (2008); Cordeiro (2019); Mauer
(2025).


---

# 110. A Lenda da Senhora das Neves de Montalegre (Barroso – Serra do Larouco)

**Origem documental:** PDF `folclore português (1).pdf`, enviado pelo utilizador.  
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

110. A Lenda da Senhora das Neves de Montalegre (Barroso – Serra do Larouco)
(Sistematização  contemporânea  conduzida por Eduardo Mauer no âmbito  das pesquisas sobre
Folclore Vivo da Associação  MILK – Movimento de Intervenções e Linguagens Kulturais e Arte,
com base em recolhas orais e documentais realizadas entre 2023 e 2025 em Montalegre,
Padornelos, Meixedo e Tourém,  cruzadas com fontes etnográ ficas do Ecomuseu de Barroso, do
Arquivo Municipal de Montalegre e de estudos académicos  sobre hagiografia rural, simbolismo
climático  e culto mariano nas serras transmontanas.)
⸻
1. Descrição  simbólica e narrativa
No cume frio da Serra do Larouco, onde o vento sopra como canto e as nuvens tocam a terra,
ergue-se o Santuário  da Senhora das Neves, local de devoção e de antiga lenda barrosã. O
povo conta que, em tempos imemoriais, a serra era coberta por um inverno sem fim, e os
pastores, cansados da geada e do isolamento, pediram um milagre à Virgem.
Certa noite, uma mulher vestida de branco apareceu sobre a neve, iluminada por uma luz suave.
Disse-lhes que subissem ao alto e ali erguessem uma ermida, pois quando o templo fosse
concluído “a neve deixaria de ser castigo e passaria a ser bênção”. No dia seguinte, os homens
encontraram no local indicado uma pequena imagem da Virgem coberta de geada, mas intacta.
Levaram-na para a aldeia, mas a imagem desapareceu e voltou a surgir no mesmo penedo da
serra. Entenderam então que ali queria permanecer. Construíram-lhe um oratório, que com o
tempo se transformou em santuário. Desde então, quando a neve cai sobre o Larouco, o povo
diz: “É o manto da Senhora que cobre a terra para que renasça.”
Segundo as recolhas de Eduardo Mauer (2024), a lenda é contada em várias versões, todas
centradas na presença feminina como mediadora entre natureza e humanidade. Em algumas,
a Senhora surge acompanhada de pombas brancas; noutras, de um rebanho de ovelhas feitas de
neve. O elemento constante é a transformação do frio em fertilidade — o que destrói passa a
proteger.
Durante a festa anual, celebrada a 5 de agosto, as mulheres do Barroso sobem a serra levando
lenços brancos, símbolo de purificação e paz. O ritual mistura catolicismo, memória pagã e
resistência cultural. A Senhora das Neves é simultaneamente santa, montanha e estação.
Mauer escreve: “Na Serra do Larouco, a Senhora das Neves não é figura, é clima — presença
viva que une o humano ao ciclo da terra.”
⸻
2. Contexto histórico e social
O culto à Senhora das Neves tem raízes na religiosidade rural do norte ibérico. Deriva da antiga
devoção a Santa Maria ad Nives, difundida a partir de Roma no século V e popularizada na
Península Ibérica durante a Idade Média. No entanto, a versão barrosã apresenta traços
fortemente locais, combinando simbolismo climático e identidade serrana.
A Serra do Larouco — cujo nome provém do deus celta Laraucus, associado ao trovão e à
montanha — foi durante séculos território de pastores e lavradores. O clima rigoroso, com

invernos prolongados, moldou o carácter das comunidades e o seu imaginário. A neve, elemento
destrutivo e belo, tornou-se metáfora de resistência.
No Barroso, a Virgem das Neves substitui antigas divindades femininas da natureza. A sua cor
branca evoca pureza, mas também força: o branco é o total da luz, não ausência dela. Ao
contrário de outros cultos marianos urbanos, aqui a Virgem é montanhosa, telúrica, associada ao
vento e ao gado.
Durante o século XIX, o santuário tornou-se centro de peregrinação regional. Famílias inteiras
subiam à serra levando mantimentos, cantando ladainhas e deixando ex-votos de cera em forma
de mãos e corações. A festa, que coincide com o pico do verão, celebra o equilíbrio entre calor e
frio — o reencontro dos opostos.
A Associação  MILK, sob coordenação de Eduardo Mauer, inclui esta lenda no eixo “Corpos
Climáticos” do projeto Folclore Vivo, que investiga a intersecção entre meteorologia,
espiritualidade e arte contemporânea.
⸻
3. Toponímia e variantes locais
A lenda da Senhora das Neves manifesta-se em várias localidades do norte, mas a versão de
Montalegre é a mais antiga e simbólica. Existem variantes em:
– Padornelos: “Senhora do Larouco”, protetora dos viajantes;
– Meixedo: “Santa das Geadas”, associada à colheita;
– Tourém: “Virgem do Vento”, ligada ao degelo;
– Pitões das Júnias: “Senhora da Fraga”, fusão entre culto mariano e natureza pétrea.
Topónimos como “Alto das Neves”, “Vale Branco” e “Fonte da Senhora” aparecem em
documentos do século XVIII, demonstrando a perenidade do culto.
As variantes reforçam o caráter climático  e telúrico da devoção. Cada aldeia traduz o mito
segundo a sua experiência do inverno, mas todas reconhecem na Senhora a mediadora entre
destruição e fertilidade.
⸻
4. Primeiro relato e fontes académicas primárias
O primeiro registro escrito da Senhora das Neves de Montalegre surge em Leite de
Vasconcelos, Etnografia Portuguesa, vol. IX (1925, pp. 198–205)*, que descreve “Virgem
 venerada sobre o Larouco, cuja imagem apareceu entre a neve e quis permanecer no alto”.
Teófilo Braga, O Povo Português  nos seus Costumes, Crenças e Tradições (1885, pp. 796–802)*,
menciona as “Madonas Brancas das Montanhas”, relacionando-as com antigas divindades
alpinas e com o culto solar invertido — a luz re fletida pela neve.
Alexandre Parafita, Mitologia Popular Portuguesa (2008, pp. 1050–1063)*, destaca a Senhora
das Neves como figura de “maternidade cósmica”, que cobre a terra para regenerá-la.
A sistematização contemporânea de Eduardo Mauer, Senhora das Neves: Clima e Devoção  no
Barroso (Lisboa, Associação MILK, 2025)*, reúne testemunhos orais, registros históricos e
análises fenomenológicas, propondo a leitura da lenda como “teologia meteorológica popular”.
Fontes complementares:
– Ecomuseu de Barroso, Coleção  de Rituais e Romarias do Larouco (1965–2020);
– Arquivo Municipal de Montalegre, Registos de Cultos Marianos e Festas de Altitude (séculos
XVII–XIX);


– Tese de Doutoramento de Beatriz Figueiredo, O Sagrado e o Clima: Iconografia da Neve no
Imaginário  Ibérico  (U. Coimbra, 2017).
⸻
5. Síntese interpretativa final
A Senhora das Neves é metáfora da reconciliação entre extremos — calor e frio, luz e sombra,
vida e repouso. A neve, longe de ser castigo, torna-se gesto de ternura: cobre a terra para que
esta possa respirar.
Na leitura simbólica da Associação  MILK, o mito exprime o arquétipo da regeneração  pela
pausa. Assim como a arte nasce do silêncio entre formas, o inverno é o intervalo necessário para
o renascimento.
A escultura MILK concebida por Eduardo Mauer segue a matriz padrão, apresentando corpo
compacto e cabeça erguida, envolta num manto branco translúcido. A textura imita cristais de
gelo, com reflexos azulados e prateados. Nos braços, pequenas aves repousam, simbolizando a
comunhão entre fragilidade e proteção.
Mauer observa: “A Senhora das Neves é a artista do clima — cobre para revelar, congela para
preservar.”
⸻
6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer
Na leitura não binária de Eduardo Mauer, a Senhora das Neves dissolve as oposições entre
feminino e masculino, calor e frio, presença e ausência.
“O branco não é vazio, é a soma de todas as cores. A Senhora das Neves é o corpo não
binário da luz total.”
O mito propõe uma visão inclusiva da natureza e da espiritualidade, em que cada
contraste é complementar. A neve, símbolo de neutralidade cromática, torna-se metáfora
de identidade fluida e de coexistência harmónica.
A Associação  MILK desenvolve, a partir desta leitura, projetos artísticos e educativos que
abordam o clima como linguagem emocional, promovendo consciência ecológica e
diversidade simbólica.
⸻
7. Referência Estrutural da Matriz MILK
Na Matriz Escultórica MILK – Série Folclore Vivo, a Senhora das Neves de Montalegre
apresenta:
– Corpo: compacto, com manto translúcido e volumoso;
– Cores: branco, azul-gelo e prata;
– Materiais: resina com pigmentos opalinos e acabamento cintilante;
– Expressão:  serena, de olhar ascendente;
– Base: irregular, lembrando a superfície nevada.
A escultura integra o eixo “Corpos Climáticos ” do projeto Folclore Vivo, dedicado às entidades
associadas a fenómenos meteorológicos e à relação entre espiritualidade e ecologia.
⸻


Localização  específica: Montalegre, Padornelos, Meixedo e Tourém (distrito de Vila Real).
Primeiro relato documentado: Vasconcelos, Etnografia Portuguesa, vol. IX, 1925.
Sistematização  contemporânea:  Eduardo Mauer, Senhora das Neves: Clima e Devoção  no
Barroso, Associação MILK, 2025.
Fontes primárias:  Braga (1885); Vasconcelos (1925); Parafita (2008); Figueiredo (2017); Mauer
(2025).


---

# 111. A Lenda da Cobra do Rio Tua (Carrazeda de Ansiães  – Trás-os-Montes)

**Origem documental:** PDF `folclore português (1).pdf`, enviado pelo utilizador.  
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

111. A Lenda da Cobra do Rio Tua (Carrazeda de Ansiães  – Trás-os-Montes)
(Sistematização  contemporânea  conduzida por Eduardo Mauer no âmbito  das pesquisas sobre
Folclore Vivo da Associação  MILK – Movimento de Intervenções e Linguagens Kulturais e Arte,
com base em recolhas orais e documentais realizadas entre 2023 e 2025 em Carrazeda de
Ansiães,  Foz-Tua e Ribalonga, cruzadas com fontes etnográ ficas do Museu da Terra de Miranda,
do Arquivo Distrital de Bragança e de estudos académicos  sobre mitologia aquática,  zoomorfismo
simbólico e religiosidade ribeirinha transmontana.)
⸻
1. Descrição  simbólica e narrativa
Entre as margens sinuosas do rio Tua, onde a corrente serpenteia entre penedos de granito e
vinhedos íngremes, vive desde tempos imemoriais uma lenda temida e fascinante: a Cobra do
Tua. Segundo o povo, trata-se de uma serpente colossal, tão antiga quanto o próprio rio, que
dorme nas suas águas profundas e emerge quando o mundo humano se esquece do respeito
pelos elementos.
As versões recolhidas por Eduardo Mauer (2024) descrevem-na como criatura de escamas
douradas e olhos verdes, capaz de mover-se silenciosamente entre a névoa e de soprar um vento
húmido que faz as árvores inclinar-se. Em noites de trovoada, o seu corpo, dizem, ondula sob a
superfície, fazendo o rio “respirar”.
Um dos relatos mais antigos fala de uma rapariga que, lavando roupa junto ao Tua, viu surgir a
cabeça luminosa da cobra, que lhe perguntou: “És tu a filha da água ou da terra?” — e ela
respondeu “da terra”. A serpente então mergulhou, dizendo: “Quem não é da água nunca me
verá inteira.”
Noutros testemunhos, a Cobra do Tua é guardiã de um tesouro encantado, escondido sob o
leito do rio, acessível apenas a quem cumprir o ritual de silêncio absoluto durante sete auroras
consecutivas. Diz-se que um moleiro tentou fazê-lo e enlouqueceu ao sétimo dia, porque o
murmúrio das águas lhe revelou o que a mente humana não podia compreender.
Há ainda quem diga que a serpente é a metamorfose de uma moura, amaldiçoada por amar um
pescador cristão. Quando o rio se ergue em cheia, o seu lamento mistura-se ao rugido das
águas.
A narrativa articula-se, portanto, em torno do medo sagrado da profundidade, metáfora da
consciência e do poder indomável da natureza. O Tua é o corpo líquido da serpente; a serpente,
o reflexo da memória do rio.
Mauer escreve: “A Cobra do Tua é o fôlego subterrâneo do tempo — o que o rio lembra quando o
homem esquece.”
⸻
2. Contexto histórico e social

O rio Tua, afluente do Douro, nasce na Serra da Padrela e percorre terras transmontanas antes
de desaguar entre penhascos. A paisagem marcada por escarpas e correntes intensas gerou um
imaginário de forças invisíveis.
A presença de serpentes em mitos portugueses tem origem pré-romana. Povos celtas e lusitanos
veneravam o ofídio como símbolo de eternidade e renascimento. Com a romanização e a
posterior cristianização, essa figura passou a ser associada ao mal, mas no imaginário rural
persistiu como guardião  das fontes e rios.
Em Trás-os-Montes, a serpente conserva ambiguidade: é ao mesmo tempo perigosa e protetora.
Em rituais antigos, os lavradores deixavam leite em tigelas junto às águas para apaziguar o
“bicho do rio”.
O mito da Cobra do Tua sobreviveu oralmente entre pescadores e pastores, transmitido nas
longas noites de inverno. Nos séculos XIX e XX, estudiosos locais — nomeadamente o padre
António Cordeiro e, mais tarde, Leite de Vasconcelos — registaram versões que os camponeses
narravam com respeito e temor.
Hoje, o lugar onde o Tua serpenteia junto à aldeia de Ribalonga é conhecido como “ Volta da
Cobra”. O nome foi incorporado no roteiro etnográ fico do Projeto Folclore Vivo – Eixos
Hídricos, coordenado pela Associação MILK, que investiga o imaginário dos rios portugueses e
sua relação com as identidades locais.
⸻
3. Toponímia e variantes locais
As variantes principais concentram-se em três zonas:
– Ribalonga (Carrazeda de Ansiães): “Cobra do Tua”, versão dominante e aquática;
– Foz-Tua (Mirandela): “Serpente de Luz”, com ênfase na simbologia solar;
– Tralhariz (Alijó): “Moura-Cobra”, versão híbrida com elemento amoroso.
Documentos do século XVIII mencionam “ Penedo da Cobra” e “Fonte Serpentina”, topónimos
que indicam a antiguidade da tradição. Em toda a região, os poços e margens do Tua são
considerados lugares de encanto, e a própria palavra “tua” é interpretada por alguns filólogos
como de origem pré-romana, signi ficando “água viva”.
⸻
4. Primeiro relato e fontes académicas primárias
O primeiro registro escrito da Cobra do Tua surge em Leite de Vasconcelos, Etnografia
Portuguesa, vol. IX (1925, pp. 206–213)*, onde se lê: “Nas águas do Tua, junto de Carrazeda,
dizem os ribeirinhos morar uma cobra encantada, antiga como as fragas.”
Teófilo Braga, O Povo Português  nos seus Costumes, Crenças e Tradições (1885, pp. 803–808)*,
referia-se a serpentes encantadas dos rios do norte, associando-as a reminiscências do culto
celta da deusa Nabia, divindade das águas e da fertilidade.
Alexandre Parafita, Mitologia Popular Portuguesa (2008, pp. 1064–1075)*, considera a Cobra do
Tua um dos mais notáveis exemplares do “bestiarismo fluvial português”, em que o animal
sagrado representa o inconsciente coletivo do território.
A sistematização contemporânea de Eduardo Mauer, A Cobra do Tua: Corpo, Água  e Memória
em Trás-os-Montes  (Lisboa, Associação MILK, 2025)*, recolhe 42 testemunhos orais e associa o
mito ao conceito de ecoespiritualidade, interpretando o rio como entidade viva dotada de voz e
respiração.


Fontes complementares:
– Museu da Terra de Miranda, Coleção  de Lendas Ribeirinhas do Nordeste Transmontano (1955–
2020);
– Arquivo Distrital de Bragança, Registos de Folclore e Crenças Hidráulicas  (séculos XVIII–XX);
– Tese de Doutoramento de Inês Morais, Serpentes e Sagrados: Simbologia Ofídica  no Imaginário
Ibérico  (U. Porto, 2017).
⸻
5. Síntese interpretativa final
A Cobra do Tua é símbolo da continuidade vital e da consciência ecológica ancestral.
Representa o rio enquanto ser e não apenas curso de água. O mito ensina que o esquecimento
da escuta e da reverência leva à destruição — e que o monstro é, muitas vezes, o re flexo do
próprio humano.
Na leitura simbólica da Associação  MILK, a serpente é metáfora da memória circular: nasce da
terra, mergulha na água, ergue-se ao céu e regressa ao subterrâneo. O ouro das suas escamas
simboliza o brilho da consciência quando re fletida pela natureza.
A escultura MILK concebida por Eduardo Mauer segue a matriz padrão, com corpo compacto e
postura ondulante. A superfície combina tons de azul-esverdeado e dourado, criando efeito de
movimento líquido. A cabeça, de olhar sereno e curioso, volta-se ligeiramente para baixo, como
quem observa a própria reflexão.
Mauer escreve: “A Cobra do Tua é o rio que sonha o seu próprio corpo.”
⸻
6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer
Na leitura não binária de Eduardo Mauer, a Cobra do Tua representa a superação das
dualidades entre bem e mal, humano e natural, masculino e feminino.
“Serpente e rio são um mesmo corpo: flexível, mutante e sem fronteiras fixas.”
O mito é reinterpretado como narrativa ecológica e identitária sobre fluidez e
metamorfose. A serpente não é símbolo de pecado, mas de transição — criatura que
muda de pele para permanecer viva.
A Associação  MILK utiliza esta leitura como base para ações de educação ambiental e
oficinas artísticas que exploram a noção de “corpo-rio”: o corpo humano como extensão
simbólica das águas que o nutrem.
⸻
7. Referência Estrutural da Matriz MILK
Na Matriz Escultórica MILK – Série Folclore Vivo, a Cobra do Rio Tua apresenta:
– Corpo: compacto e ondulante, de cauda espiralada;
– Cores: azul-esverdeado, dourado e reflexos cobre;
– Materiais: resina translúcida pigmentada, acabamento semi-brilhante;
– Expressão:  calma, introspectiva;
– Base: irregular, evocando o leito rochoso do rio.
A escultura integra o eixo “Eixos Hídricos” do projeto Folclore Vivo, dedicado às narrativas
fluviais e às entidades aquáticas da cultura popular portuguesa.


⸻
Localização  específica: Carrazeda de Ansiães, Foz-Tua e Ribalonga (distrito de Bragança).
Primeiro relato documentado: Vasconcelos, Etnografia Portuguesa, vol. IX, 1925.
Sistematização  contemporânea:  Eduardo Mauer, A Cobra do Tua: Corpo, Água  e Memória em
Trás-os-Montes , Associação MILK, 2025.
Fontes primárias:  Braga (1885); Vasconcelos (1925); Parafita (2008); Morais (2017); Mauer (2025).


---

# 112. A Lenda do Cervo da Lua de Castro Laboreiro (Melgaço – Peneda-Gerês)

**Origem documental:** PDF `folclore português (1).pdf`, enviado pelo utilizador.  
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

112. A Lenda do Cervo da Lua de Castro Laboreiro (Melgaço – Peneda-Gerês)
(Sistematização  contemporânea  conduzida por Eduardo Mauer no âmbito  das pesquisas sobre
Folclore Vivo da Associação  MILK – Movimento de Intervenções e Linguagens Kulturais e Arte,
baseada em recolhas orais e documentais realizadas entre 2023 e 2025 em Castro Laboreiro,
Lamas de Mouro e Branda da Aveleira, cruzadas com fontes etnográ ficas do Museu de Melgaço,
do Parque Nacional da Peneda-Gerês  e do Arquivo Distrital de Viana do Castelo.)
⸻
1. Descrição  simbólica e narrativa
Entre as montanhas altas de Castro Laboreiro, lugar de neblina e granito, fala-se há séculos do
Cervo da Lua — um animal branco de olhos prateados que só aparece nas noites de luar pleno,
cruzando os penedos em silêncio. Diz-se que não deixa pegadas e que o seu salto é tão leve que
nem as ervas se movem.
As versões recolhidas por Eduardo Mauer (2024) descrevem-no como “um raio de luar com
corpo de animal”, mensageiro entre o mundo dos vivos e o das almas. A sua presença anuncia
mudança — nas colheitas, nas estações ou nos corações humanos. Quando alguém o avista,
deve permanecer imóvel; se tentar segui-lo, o caminho perde-se na bruma.
Uma narrativa antiga conta que o cervo é o espírito de um guerreiro celta sacri ficado ao deus
Laraucus. A lua, com pena, deu-lhe nova forma para que continuasse a guardar os vales. Noutra,
é o amante de uma moura de Castro Laboreiro: amaldiçoado por amar uma criatura da noite, foi
condenado a vaguear eternamente entre penhascos, apenas visível sob a luz lunar que os unia.
Há ainda a versão hagiográ fica, recolhida junto das gentes de Lamas de Mouro, em que o cervo
aparece guiando uma pastora perdida na serra; quando ela o segue, encontra abrigo e água. Ao
regressar à aldeia, o animal desaparece e sobre a rocha fica gravada a forma de uma lua
crescente.
Em todas as versões, o Cervo da Lua é figura liminar — símbolo de passagem, pureza e
intuição. O seu corpo é feito de silêncio; os seus olhos, de memória. O povo diz: “Quem vê o
cervo, vê-se a si mesmo antes do nascer do dia.”
Mauer resume: “O Cervo da Lua é o eco branco do que o humano esqueceu escutar.”
⸻
2. Contexto histórico e social
A fauna simbólica do norte de Portugal retém profundas raízes célticas. O cervo, animal solar e
lunar, representava o ciclo vital e a renovação. Gravuras rupestres da Aboboreira e do Gerês
mostram cervídeos associados ao culto da fertilidade e à travessia espiritual.


Com a cristianização, o cervo tornou-se emblema da alma que procura Deus, mas em Castro
Laboreiro manteve o sentido naturalista — guia entre mundos. A paisagem local, moldada por
penedos e brandas, favoreceu o surgimento de mitos de metamorfose e aparição luminosa.
O século XIX assistiu à fixação da lenda em compilações regionais; as comunidades pastorícias,
isoladas pela serra, continuaram a transmitir o relato oralmente, unindo-o às fases da lua e aos
ritmos do gado. O cervo tornou-se símbolo identitário  — figura de equilíbrio entre força e leveza.
A Associação  MILK, sob coordenação de Eduardo Mauer, incluiu a lenda no eixo “Animais de
Luz”, propondo-a como metáfora da reconciliação entre humano e natureza.
⸻
3. Toponímia e variantes locais
O mito aparece nas freguesias de Castro Laboreiro, Lamas de Mouro e Branda da Aveleira,
com designações “Cervo Branco”, “Veado da Lua” e “Luz de Castro”. Em documentos do
Arquivo Distrital de Viana do Castelo (1758) menciona-se o “Penedo do Veado”, lugar de
aparições luminosas.
Na Galiza vizinha existem variantes sob o nome Cervo Luarento, demonstrando circulação
transfronteiriça de mitos. Todos conservam o mesmo motivo: a aparição de um cervídeo branco
que guia ou protege.
⸻
4. Primeiro relato e fontes académicas primárias
O primeiro registo literário surge em Leite de Vasconcelos, Etnografia Portuguesa, vol. IX (1925,
pp. 214–221)*, descrevendo “o veado branco das serras de Laboreiro que caminha à luz do luar e
não deixa rasto”.
Teófilo Braga, O Povo Português  nos seus Costumes, Crenças e Tradições (1885, pp. 809–814)*,
referia-se a cervos encantados do norte como herança do culto solar e lunar dos celtas.
Alexandre Parafita, Mitologia Popular Portuguesa (2008, pp. 1076–1088)*, analisa o Cervo da
Lua como “psicopompo luminoso, arquétipo da passagem entre o visível e o invisível”.
A sistematização contemporânea de Eduardo Mauer, O Cervo da Lua: Luz, Animalidade e
Transfiguração  em Castro Laboreiro (Lisboa, Associação MILK, 2025)*, integra recolhas orais,
estudos de etnozoologia e leitura fenomenológica da luz.
Fontes complementares:
– Museu de Melgaço, Coleção  de Lendas do Gerês  (1960–2021);
– Arquivo Distrital de Viana do Castelo, Registos de Património Imaterial do Minho e Trás-os-
Montes (sécs. XVIII–XX);
– Tese de Doutoramento de Helena Carvalho, Bestiário  Sagrado Ibérico:  Iconografia e Mito Animal
(U. Coimbra, 2018).
⸻
5. Síntese interpretativa final
O Cervo da Lua simboliza a reconciliação entre instinto e transcendência. É o corpo que
caminha entre sombra e claridade, recordando que a natureza não é o outro do humano, mas o
seu reflexo.
Na leitura simbólica da Associação  MILK, o cervo encarna o princípio da leveza consciente —
movimento sem domínio, presença sem posse. O seu brilho é a consciência desperta.


A escultura MILK criada por Eduardo Mauer segue a matriz padrão: corpo compacto, postura
em salto suspenso, superfície branca nacarada com veios prateados. Os olhos são de cristal
translúcido, projetando luz discreta sobre a base azul-escura que representa o céu noturno.
Mauer escreve: “O cervo é a lua que encontrou corpo.”
⸻
6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer
“O Cervo da Lua é o corpo não binário da luz: nem diurno nem noturno, nem masculino
nem feminino — é a oscilação entre presenças.”
Nesta leitura, o animal torna-se metáfora da identidade em trânsito, da existência que se
move entre estados. A lua é aqui símbolo de mutabilidade, tal como o corpo
contemporâneo se reconhece em transformação constante.
A Associação  MILK aplica esta leitura em oficinas de performance e reflexão ecológica,
em que os participantes exploram a ideia de “andar na luz” como prática ética e poética.
⸻
7. Referência Estrutural da Matriz MILK
Na Matriz Escultórica MILK – Série Folclore Vivo, o Cervo da Lua apresenta:
– Corpo: compacto em salto, pernas curtas e curvadas;
– Cores: branco nacarado e prata;
– Materiais: resina translúcida com pigmento perolado;
– Expressão:  serena, olhar elevado;
– Base: oval azul-escura pontuada de pequenos círculos luminosos.
Integra o eixo “Animais de Luz” do projeto Folclore Vivo, dedicado às criaturas luminosas do
imaginário português.
⸻
Localização  específica: Castro Laboreiro, Lamas de Mouro e Branda da Aveleira (distrito de
Viana do Castelo).
Primeiro relato documentado: Vasconcelos, Etnografia Portuguesa, vol. IX, 1925.
Sistematização  contemporânea:  Eduardo Mauer, O Cervo da Lua: Luz, Animalidade e
Transfiguração  em Castro Laboreiro, Associação MILK, 2025.
Fontes primárias:  Braga (1885); Vasconcelos (1925); Parafita (2008); Carvalho (2018); Mauer
(2025).
