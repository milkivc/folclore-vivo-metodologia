# 086. A Lenda do Coração  de Nevoeiro (Serra d’Arga e Caminha – Alto Minho)

**Base documental e empírica:** pesquisa documental, análise comparada de fontes públicas, sistematização de tradição oral, relatos orais de pesquisa de campo e revisão semântica conduzidas no âmbito do Folclore Vivo da Associação MILK - Movimento de Intervenções e Linguagens Kulturais e Arte.
**Estado editorial:** corpus de pesquisa de campo e documentação cultural em revisão pública.
**Regra de publicabilidade:** esta entrada não deve ser lida como prova histórica definitiva, inventário patrimonial oficial, validação etnográfica concluída ou certificação académica externa sem verificação documental própria.
**Regra jurídica/RGPD:** não publicar nomes de informantes, contactos, moradas, entrevistas integrais, imagens identificáveis, gravações, dados de menores, coordenadas sensíveis ou materiais comunitários sem autorização.
**Regra de não invenção:** a presente readequação corrige a camada editorial e metodológica sem acrescentar factos, fontes, topónimos, coordenadas ou relatos não existentes no corpus-base.
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

86. A Lenda do Coração  de Nevoeiro (Serra d’Arga e Caminha – Alto Minho)

(Sistematização  contemporânea  conduzida por Eduardo Mauer no âmbito  das pesquisas sobre
Folclore Vivo da Associação  MILK – Movimento de Intervenções e Linguagens Kulturais e Arte,
com base em recolhas orais realizadas entre 2023 e 2025 em Arga de Cima, Arga de Baixo e
Caminha, cruzadas com fontes etnográ ficas do Museu de Viana do Castelo, Arquivo Municipal de
Caminha e estudos de mitologia atlântica  e simbologia atmosférica  do norte português.)
⸻
1. Descrição  simbólica e narrativa
A Lenda do Coração  de Nevoeiro é uma das mais poéticas do imaginário minhoto, nascida na
Serra d’Arga, onde a montanha toca o Atlântico e as névoas formam véus espessos que se
movem como corpos vivos. O mito conta que, nas madrugadas de nevoeiro, pode ver-se um
coração  luminoso pulsando dentro da bruma, pairando entre os vales de Arga de Cima e
Caminha.
Dizem os habitantes locais que o coração não pertence a ninguém — é o próprio nevoeiro que
ama. Quando o coração aparece, as ovelhas param de pastar, os cães deixam de ladrar e o
silêncio cobre a serra. O brilho é descrito como vermelho-dourado, translúcido, movendo-se
devagar “como se respirasse”.
As versões recolhidas por Eduardo Mauer (2024) apresentam o coração como presença
protetora, associada ao amor impossível entre uma pastora e um pescador. Conta-se que a
pastora via, do alto da serra, o brilho dos barcos no mar, e cada noite acendia uma lanterna para
que o amado encontrasse o caminho de volta. Numa madrugada de tempestade, o barco
afundou-se. A jovem desceu a montanha em pranto e desapareceu no nevoeiro. Desde então,
dizem que o nevoeiro ganhou coração — e que pulsa sempre que a serra sente saudade do mar.
Noutras versões, o coração é um sinal atmosférico sagrado, “respiração da terra” que protege
os viajantes e anuncia boas colheitas. O nevoeiro seria, assim, o corpo da montanha; o coração,
o seu espírito.
Há também relatos de monges de Arga (séc. XVIII) que descrevem “uma luz vermelha a mover-se
entre os vales, parecendo lanterna de anjo”. Essa tradição funde espiritualidade cristã e
simbolismo telúrico, reforçando a ideia do coração como energia viva do lugar.
Mauer interpreta o mito como metáfora do sentimento coletivo da paisagem: “O Coração de
Nevoeiro é o amor do território por si mesmo — o instante em que a terra se recorda de respirar.”
⸻
2. Contexto histórico e social
A Serra d’Arga, situada entre o vale do Lima e o mar de Caminha, é região de antigas devoções
e rituais atmosféricos. As populações locais sempre conviveram com o nevoeiro denso que cobre
a serra durante grande parte do ano, fenómeno natural que inspirou tanto medo quanto fascínio.
Historicamente, o nevoeiro era visto como presença espiritual. Os pastores chamavam-no
“manto da Senhora” e acreditavam que escondia os mortos que voltavam a visitar o mundo. O
coração luminoso, segundo tradições do século XIX, seria o sinal benigno dessa visita, oposto
às aparições sombrias.
O culto simbólico ao nevoeiro manifesta-se também nas romarias da Senhora do Minho e de
São  João  d’Arga, onde velas são acesas no alto da serra “para iluminar a bruma”. A lenda do
Coração de Nevoeiro insere-se nesse contexto como mito conciliador entre o medo e a fé.


Durante o século XX, o mito assumiu função moral: os anciãos contavam às crianças que o
coração pulsava apenas quando havia paz na aldeia — o nevoeiro só brilha quando o povo
está  em harmonia.
Nas recolhas da Associação  MILK, registradas entre 2023 e 2025, verificou-se que a lenda
continua viva: caminhantes, guardas florestais e fotógrafos relatam ter visto “a luz do coração”
em noites húmidas. Para o imaginário contemporâneo, tornou-se símbolo do amor persistente
e da união  entre natureza e afeto.
⸻
3. Toponímia e variantes locais
O topónimo “Arga” tem origem pré-romana e designa montanha sagrada ( arga significando altura
ou brilho). As aldeias de Arga de Baixo, Arga de Cima e Arga de São  João  conservam lendas
paralelas:
– “Coração  da Serra” (Arga de Cima): a montanha tem alma que brilha quando alguém morre
longe;
– “Luz de Névoa” (Caminha): lanterna de alma perdida que orienta os pescadores;
– “Fogo Branco” (Arga de São João): sinal de reconciliação entre terra e mar.
Em todos os casos, a luz é símbolo de vida e memória coletiva. O termo “nevoeiro”, além de
fenómeno meteorológico, é usado metaforicamente em ditados locais: “O coração perde-se no
nevoeiro quando esquece de amar devagar.”
O local mais frequentemente associado à aparição é o Vale do Covelo, entre Arga e Dem, onde a
bruma forma redemoinhos luminosos nas primeiras horas do dia.
⸻
4. Primeiro relato e fontes académicas primárias
O primeiro registro escrito da lenda encontra-se em Leite de Vasconcelos, Etnografia
Portuguesa, vol. VII (1920, pp. 228–232)*, que menciona “uma luz pulsante observada na serra
d’Arga, considerada sinal de alma viva da montanha”.
Teófilo Braga, O Povo Português  nos seus Costumes, Crenças e Tradições (1885, pp. 645–650)*,
refere “as luzes vermelhas dos montes que respiram”, identificando-as como sobrevivências dos
cultos naturais.
Alexandre Parafita, Mitologia Popular Portuguesa (2008, pp. 810–818)*, consagra a versão do
“Coração de Nevoeiro” como metáfora amorosa e ecológica, “símbolo da reciprocidade entre
serra e oceano”.
A sistematização contemporânea de Eduardo Mauer, O Coração  de Nevoeiro: Atmosfera, Amor
e Matéria  na Mitologia Atlântica  Portuguesa (Lisboa, Associação MILK, 2025)*, propõe leitura
interdisciplinar entre fenomenologia, ecologia e arte, reconhecendo o mito como expressão
sensível da afetividade ambiental.
Fontes complementares:
– Arquivo Municipal de Caminha, Registos de Tradições da Serra d’Arga (1860–1938);
– Museu de Viana do Castelo, Coleção  Luzes e Aparições do Minho (cat. 45–76, 1950–1985);
– Tese de Doutoramento de Leonor Tavares, Mitologias da Névoa  e da Claridade no Noroeste
Ibérico  (U. Porto, 2019).
⸻
5. Síntese interpretativa final

O Coração  de Nevoeiro é o símbolo máximo  da reciprocidade entre natureza e emoção. O seu
brilho não é apenas luminoso, é afetivo: o pulsar da terra pela memória do amor humano.
Na leitura simbólica da Associação  MILK, esta lenda representa o ponto culminante da poética
da matéria viva. O nevoeiro, elemento efémero e instável, torna-se corpo e coração; aquilo que
se dispersa ganha centro e batimento.
A escultura MILK concebida por Eduardo Mauer traduz essa inversão: uma forma oval,
compacta, de resina translúcida cinza-perolada, com núcleo interno pulsante de luz vermelha. O
corpo, de cabeça grande e tronco denso, assemelha-se a um ser em repouso respirando
nevoeiro. A luz interna muda de intensidade, criando o efeito de respiração da montanha.
Mauer escreve: “O Coração de Nevoeiro é a emoção da paisagem: o amor de quem não precisa
ser visto para continuar a pulsar.”
⸻
6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer
Na leitura não binária de Eduardo Mauer, o Coração  de Nevoeiro representa a fusão  dos
contrários  — visível e invisível, matéria e ar, corpo e atmosfera.
“O coração é o entre — o ponto em que o amor deixa de ter forma para tornar-se
vibração.”
Para Mauer, este mito é metáfora do não  binário  atmosférico, em que as fronteiras entre
corpo e ambiente se dissolvem. O nevoeiro é o corpo do mundo em estado de incerteza,
e o seu coração é a certeza de que a vida continua mesmo sem contorno.
A Associação  MILK lê este mito como expressão  do afeto contemporâneo , aquele que
não exige de finição para existir. O Coração de Nevoeiro encarna o amor fluido e empático,
não  sexual nem espiritual apenas, mas ambiental — amor que é respiração partilhada.
⸻
7. Referência Estrutural da Matriz MILK
Na Matriz Escultórica MILK – Série Folclore Vivo, o Coração  de Nevoeiro é representado em
forma compacta e luminosa:
– Corpo: arredondado, cabeça grande e tronco reduzido, com cavidade central iluminada.
– Cores: cinza-perolado, branco-fumo e vermelho interno pulsante.
– Materiais: resina translúcida, luz interna variável, acabamento fosco.
– Expressão:  neutra, olhos semicerrados, semblante de respiração.
– Base: curva e fina, evocando vapor em suspensão.
A escultura encarna o conceito de matéria atmosférica viva, eixo das investigações MILK sobre
a fusão entre tempo, corpo e ambiente.
⸻
Localização  específica: Serra d’Arga e Caminha (distrito de Viana do Castelo).
Primeiro relato documentado: Vasconcelos, Etnografia Portuguesa, vol. VII, 1920.
Sistematização  contemporânea:  Eduardo Mauer, O Coração  de Nevoeiro: Atmosfera, Amor e
Matéria  na Mitologia Atlântica  Portuguesa, Associação MILK, 2025.
Fontes primárias:  Braga (1885); Vasconcelos (1920); Parafita (2008); Tavares (2019); Mauer
(2025).
