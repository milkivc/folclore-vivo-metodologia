# 111. A Lenda da Cobra do Rio Tua (Carrazeda de Ansiães  – Trás-os-Montes)

**Base documental e empírica:** pesquisa documental, análise comparada de fontes públicas, sistematização de tradição oral, relatos orais de pesquisa de campo e revisão semântica conduzidas no âmbito do Folclore Vivo da Associação MILK - Movimento de Intervenções e Linguagens Kulturais e Arte.
**Estado editorial:** corpus de pesquisa de campo e documentação cultural em revisão pública.
**Regra de publicabilidade:** esta entrada não deve ser lida como prova histórica definitiva, inventário patrimonial oficial, validação etnográfica concluída ou certificação académica externa sem verificação documental própria.
**Regra jurídica/RGPD:** não publicar nomes de informantes, contactos, moradas, entrevistas integrais, imagens identificáveis, gravações, dados de menores, coordenadas sensíveis ou materiais comunitários sem autorização.
**Regra de não invenção:** a presente readequação corrige a camada editorial e metodológica sem acrescentar factos, fontes, topónimos, coordenadas ou relatos não existentes no corpus-base.
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

111. A Lenda da Cobra do Rio Tua (Carrazeda de Ansiães  – Trás-os-Montes)
(Sistematização  contemporânea  conduzida por Eduardo Mauer no âmbito  das pesquisas sobre
Folclore Vivo da Associação  MILK – Movimento de Intervenções e Linguagens Kulturais e Arte,
com base em recolhas orais e documentais realizadas entre 2023 e 2025 em Carrazeda de
Ansiães,  Foz-Tua e Ribalonga, cruzadas com fontes etnográ ficas do Museu da Terra de Miranda,
do Arquivo Distrital de Bragança e de estudos académicos  sobre mitologia aquática,  zoomorfismo
simbólico e religiosidade ribeirinha transmontana.)
⸻
1. Descrição  simbólica e narrativa
Entre as margens sinuosas do rio Tua, onde a corrente serpenteia entre penedos de granito e
vinhedos íngremes, vive desde tempos imemoriais uma lenda temida e fascinante: a Cobra do
Tua. Segundo o povo, trata-se de uma serpente colossal, tão antiga quanto o próprio rio, que
dorme nas suas águas profundas e emerge quando o mundo humano se esquece do respeito
pelos elementos.
As versões recolhidas por Eduardo Mauer (2024) descrevem-na como criatura de escamas
douradas e olhos verdes, capaz de mover-se silenciosamente entre a névoa e de soprar um vento
húmido que faz as árvores inclinar-se. Em noites de trovoada, o seu corpo, dizem, ondula sob a
superfície, fazendo o rio “respirar”.
Um dos relatos mais antigos fala de uma rapariga que, lavando roupa junto ao Tua, viu surgir a
cabeça luminosa da cobra, que lhe perguntou: “És tu a filha da água ou da terra?” — e ela
respondeu “da terra”. A serpente então mergulhou, dizendo: “Quem não é da água nunca me
verá inteira.”
Noutros testemunhos, a Cobra do Tua é guardiã de um tesouro encantado, escondido sob o
leito do rio, acessível apenas a quem cumprir o ritual de silêncio absoluto durante sete auroras
consecutivas. Diz-se que um moleiro tentou fazê-lo e enlouqueceu ao sétimo dia, porque o
murmúrio das águas lhe revelou o que a mente humana não podia compreender.
Há ainda quem diga que a serpente é a metamorfose de uma moura, amaldiçoada por amar um
pescador cristão. Quando o rio se ergue em cheia, o seu lamento mistura-se ao rugido das
águas.
A narrativa articula-se, portanto, em torno do medo sagrado da profundidade, metáfora da
consciência e do poder indomável da natureza. O Tua é o corpo líquido da serpente; a serpente,
o reflexo da memória do rio.
Mauer escreve: “A Cobra do Tua é o fôlego subterrâneo do tempo — o que o rio lembra quando o
homem esquece.”
⸻
2. Contexto histórico e social

O rio Tua, afluente do Douro, nasce na Serra da Padrela e percorre terras transmontanas antes
de desaguar entre penhascos. A paisagem marcada por escarpas e correntes intensas gerou um
imaginário de forças invisíveis.
A presença de serpentes em mitos portugueses tem origem pré-romana. Povos celtas e lusitanos
veneravam o ofídio como símbolo de eternidade e renascimento. Com a romanização e a
posterior cristianização, essa figura passou a ser associada ao mal, mas no imaginário rural
persistiu como guardião  das fontes e rios.
Em Trás-os-Montes, a serpente conserva ambiguidade: é ao mesmo tempo perigosa e protetora.
Em rituais antigos, os lavradores deixavam leite em tigelas junto às águas para apaziguar o
“bicho do rio”.
O mito da Cobra do Tua sobreviveu oralmente entre pescadores e pastores, transmitido nas
longas noites de inverno. Nos séculos XIX e XX, estudiosos locais — nomeadamente o padre
António Cordeiro e, mais tarde, Leite de Vasconcelos — registaram versões que os camponeses
narravam com respeito e temor.
Hoje, o lugar onde o Tua serpenteia junto à aldeia de Ribalonga é conhecido como “ Volta da
Cobra”. O nome foi incorporado no roteiro etnográ fico do Projeto Folclore Vivo – Eixos
Hídricos, coordenado pela Associação MILK, que investiga o imaginário dos rios portugueses e
sua relação com as identidades locais.
⸻
3. Toponímia e variantes locais
As variantes principais concentram-se em três zonas:
– Ribalonga (Carrazeda de Ansiães): “Cobra do Tua”, versão dominante e aquática;
– Foz-Tua (Mirandela): “Serpente de Luz”, com ênfase na simbologia solar;
– Tralhariz (Alijó): “Moura-Cobra”, versão híbrida com elemento amoroso.
Documentos do século XVIII mencionam “ Penedo da Cobra” e “Fonte Serpentina”, topónimos
que indicam a antiguidade da tradição. Em toda a região, os poços e margens do Tua são
considerados lugares de encanto, e a própria palavra “tua” é interpretada por alguns filólogos
como de origem pré-romana, signi ficando “água viva”.
⸻
4. Primeiro relato e fontes académicas primárias
O primeiro registro escrito da Cobra do Tua surge em Leite de Vasconcelos, Etnografia
Portuguesa, vol. IX (1925, pp. 206–213)*, onde se lê: “Nas águas do Tua, junto de Carrazeda,
dizem os ribeirinhos morar uma cobra encantada, antiga como as fragas.”
Teófilo Braga, O Povo Português  nos seus Costumes, Crenças e Tradições (1885, pp. 803–808)*,
referia-se a serpentes encantadas dos rios do norte, associando-as a reminiscências do culto
celta da deusa Nabia, divindade das águas e da fertilidade.
Alexandre Parafita, Mitologia Popular Portuguesa (2008, pp. 1064–1075)*, considera a Cobra do
Tua um dos mais notáveis exemplares do “bestiarismo fluvial português”, em que o animal
sagrado representa o inconsciente coletivo do território.
A sistematização contemporânea de Eduardo Mauer, A Cobra do Tua: Corpo, Água  e Memória
em Trás-os-Montes  (Lisboa, Associação MILK, 2025)*, recolhe 42 testemunhos orais e associa o
mito ao conceito de ecoespiritualidade, interpretando o rio como entidade viva dotada de voz e
respiração.


Fontes complementares:
– Museu da Terra de Miranda, Coleção  de Lendas Ribeirinhas do Nordeste Transmontano (1955–
2020);
– Arquivo Distrital de Bragança, Registos de Folclore e Crenças Hidráulicas  (séculos XVIII–XX);
– Tese de Doutoramento de Inês Morais, Serpentes e Sagrados: Simbologia Ofídica  no Imaginário
Ibérico  (U. Porto, 2017).
⸻
5. Síntese interpretativa final
A Cobra do Tua é símbolo da continuidade vital e da consciência ecológica ancestral.
Representa o rio enquanto ser e não apenas curso de água. O mito ensina que o esquecimento
da escuta e da reverência leva à destruição — e que o monstro é, muitas vezes, o re flexo do
próprio humano.
Na leitura simbólica da Associação  MILK, a serpente é metáfora da memória circular: nasce da
terra, mergulha na água, ergue-se ao céu e regressa ao subterrâneo. O ouro das suas escamas
simboliza o brilho da consciência quando re fletida pela natureza.
A escultura MILK concebida por Eduardo Mauer segue a matriz padrão, com corpo compacto e
postura ondulante. A superfície combina tons de azul-esverdeado e dourado, criando efeito de
movimento líquido. A cabeça, de olhar sereno e curioso, volta-se ligeiramente para baixo, como
quem observa a própria reflexão.
Mauer escreve: “A Cobra do Tua é o rio que sonha o seu próprio corpo.”
⸻
6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer
Na leitura não binária de Eduardo Mauer, a Cobra do Tua representa a superação das
dualidades entre bem e mal, humano e natural, masculino e feminino.
“Serpente e rio são um mesmo corpo: flexível, mutante e sem fronteiras fixas.”
O mito é reinterpretado como narrativa ecológica e identitária sobre fluidez e
metamorfose. A serpente não é símbolo de pecado, mas de transição — criatura que
muda de pele para permanecer viva.
A Associação  MILK utiliza esta leitura como base para ações de educação ambiental e
oficinas artísticas que exploram a noção de “corpo-rio”: o corpo humano como extensão
simbólica das águas que o nutrem.
⸻
7. Referência Estrutural da Matriz MILK
Na Matriz Escultórica MILK – Série Folclore Vivo, a Cobra do Rio Tua apresenta:
– Corpo: compacto e ondulante, de cauda espiralada;
– Cores: azul-esverdeado, dourado e reflexos cobre;
– Materiais: resina translúcida pigmentada, acabamento semi-brilhante;
– Expressão:  calma, introspectiva;
– Base: irregular, evocando o leito rochoso do rio.
A escultura integra o eixo “Eixos Hídricos” do projeto Folclore Vivo, dedicado às narrativas
fluviais e às entidades aquáticas da cultura popular portuguesa.


⸻
Localização  específica: Carrazeda de Ansiães, Foz-Tua e Ribalonga (distrito de Bragança).
Primeiro relato documentado: Vasconcelos, Etnografia Portuguesa, vol. IX, 1925.
Sistematização  contemporânea:  Eduardo Mauer, A Cobra do Tua: Corpo, Água  e Memória em
Trás-os-Montes , Associação MILK, 2025.
Fontes primárias:  Braga (1885); Vasconcelos (1925); Parafita (2008); Morais (2017); Mauer (2025).
