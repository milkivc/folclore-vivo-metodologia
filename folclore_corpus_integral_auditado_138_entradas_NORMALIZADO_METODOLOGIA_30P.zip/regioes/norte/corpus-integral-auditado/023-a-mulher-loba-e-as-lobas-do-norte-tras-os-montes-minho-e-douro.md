# 023. A Mulher Loba e as Lobas do Norte (Trás-os-Montes,  Minho e Douro)

**Base documental e empírica:** pesquisa documental, análise comparada de fontes públicas, sistematização de tradição oral, relatos orais de pesquisa de campo e revisão semântica conduzidas no âmbito do Folclore Vivo da Associação MILK - Movimento de Intervenções e Linguagens Kulturais e Arte.
**Estado editorial:** corpus de pesquisa de campo e documentação cultural em revisão pública.
**Regra de publicabilidade:** esta entrada não deve ser lida como prova histórica definitiva, inventário patrimonial oficial, validação etnográfica concluída ou certificação académica externa sem verificação documental própria.
**Regra jurídica/RGPD:** não publicar nomes de informantes, contactos, moradas, entrevistas integrais, imagens identificáveis, gravações, dados de menores, coordenadas sensíveis ou materiais comunitários sem autorização.
**Regra de não invenção:** a presente readequação corrige a camada editorial e metodológica sem acrescentar factos, fontes, topónimos, coordenadas ou relatos não existentes no corpus-base.
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

23. A Mulher Loba e as Lobas do Norte (Trás-os-Montes,  Minho e Douro)

(Descoberta e sistematização  contemporânea  conduzidas por Eduardo Mauer no âmbito  das
pesquisas sobre Folclore Vivo da Associação  MILK – Movimento de Intervenções e Linguagens
Kulturais e Arte)
⸻
1. Descrição  simbólica e narrativa
A figura da Mulher Loba — ou Loba-Humana, como é designada em alguns relatos orais de Trás-
os-Montes e do Alto Minho — é uma das mais raras e ambíguas presenças do folclore português.
Durante décadas, o imaginário popular privilegiou a figura masculina do lobisomem, mas a
tradição oral feminina, especialmente preservada em aldeias de montanha, fala de mulheres que
se transformam em lobas durante a lua cheia, não por maldição, mas por necessidade — para
correr, respirar e libertar o corpo do silêncio.
Segundo recolhas realizadas por Eduardo Mauer entre 2022 e 2024 no âmbito do programa
Folclore Vivo da Associação  MILK, as narrativas das “lobas do norte” persistem em localidades
de Montalegre, Bragança, Vinhais, Melgaço e Terras de Bouro, transmitidas sobretudo por
mulheres idosas que as ouviram “das avós e das tias que não se casaram”. A história recorrente
é a de uma mulher que, sentindo o chamamento da serra, sai de casa nas noites de luar, despe a
pele humana, veste a pele de loba e percorre os montes até o amanhecer.
A transformação não é castigo — é libertação. A mulher-loba corre não para caçar, mas para
existir fora das regras humanas. “Dizem que, de manhã, ela voltava cansada, mas feliz, cheirando
a erva e a luar.” Em algumas variantes, o marido, ao segui-la, tenta impedi-la e é morto por um
grupo de lobas; noutras, é ela própria que, ao voltar, encontra o lar vazio e escolhe nunca mais
regressar.
Muitos relatos descrevem o uivo das lobas como canto. Há quem a firme que, quando as lobas
cantam perto das aldeias, “é sinal de mulher triste que quer ser livre”.
Na leitura de Mauer, “a Mulher Loba é a versão feminina do mito da liberdade selvagem — o
corpo que reencontra o seu próprio ritmo fora da domesticidade. É o mito da autonomia através
do instinto.”
⸻
2. Contexto histórico e social
A lenda da Mulher Loba surge num contexto profundamente marcado pela opressão moral e pelo
isolamento das comunidades rurais do norte português entre os séculos XVIII e XX. Em
sociedades onde o corpo feminino era regulado pela religião e pela honra familiar, a metamorfose
em loba tornou-se imagem de resistência simbólica.
Os registos etnográ ficos mais antigos sobre o tema aparecem de forma fragmentária. Leite de
Vasconcelos, em Etnografia Portuguesa, vol. II (1913, pp. 206–211)*, refere “mulheres-lobas” de
forma incidental, descrevendo-as como “variante feminina dos homens-lobos, ligadas a
maldições de linhagem”. Contudo, o discurso oral das mulheres transmontanas — recuperado
nas pesquisas de campo da Associação MILK — apresenta um enredo distinto: as lobas não são
amaldiçoadas, mas autoescolhidas.
Nas zonas de fronteira com a Galiza, o mito funde-se com a tradição galega da Lobismuller,
estudada por Vicente Risco em Mitología  Popular de Galicia (1928), e com a crença castelhana
na Lobera, mulher feiticeira que domina as feras. Essas influências ibéricas revelam que o mito
ultrapassa o território português, delineando uma geografia de resistência feminina rural.
Na cultura camponesa, o lobo representava, paradoxalmente, perigo e proteção. Era símbolo do
instinto e da sobrevivência. O mito da mulher-loba devolve ao feminino a posse dessa força
selvagem, não como ameaça, mas como cura.


Para Eduardo Mauer, “a mulher que corre na serra é a metáfora do corpo insurgente. Em cada
aldeia onde se ouviu o uivo, ouviu-se também a recusa do silêncio imposto.”
⸻
3. Toponímia e variantes locais
O mito aparece sob diferentes designações: a loba da serra, a mulher do luar, a que corre nas
pedras ou a mulher dos olhos de fogo. Em Montalegre, a narrativa é associada à Serra do
Larouco; em Bragança, à Serra da Nogueira; em Melgaço, ao Parque Nacional da Peneda-
Gerês, especialmente nas encostas de Castro Laboreiro, onde o lobo-ibérico ainda tem presença
real.
Em Vinhais, há o relato de “Maria das Lobas”, mulher que desaparecia três noites por mês e era
vista a uivar na serra. Em Terras de Bouro, fala-se na “velha loba” que protegia crianças
perdidas, conduzindo-as de volta à aldeia.
Essas variantes demonstram que o mito atravessa classes e geografias: ora como tragédia, ora
como mito de libertação. Em todas, o elemento comum é a noite, a serra e o corpo em
transformação .
Os topónimos “Vale das Lobas”, “Fonte da Loba”, “Caminho da Loba” e “Serra das Donas”
repetem-se nas cartas topográ ficas do norte português, indiciando uma memória persistente da
presença simbólica feminina nas paisagens montanhosas.
⸻
4. Primeiro relato e fontes académicas primárias
O primeiro relato literário reconhecível da Mulher Loba aparece em Leite de Vasconcelos,
Etnografia Portuguesa, vol. II (1913, p. 209)*, onde menciona “as fêmeas-lobo em corpo de
mulher”, sem, contudo, detalhar as narrativas orais.
José Leite de Vasconcelos volta a referir o tema em Religiões da Lusitânia  (1919), associando-o
a resquícios de cultos lunares e à deusa Diana, símbolo da caça e da noite.
Alexandre Parafita, Mitologia Popular Portuguesa (2008, pp. 370–376)*, identifica o mito das
“mulheres-lobo” como metáfora da marginalidade feminina e da força subterrânea do desejo.
A sistematização contemporânea de Eduardo Mauer, As Lobas do Norte: Corpo, Noite e
Resistência  no Imaginário  Português  (Lisboa, Associação MILK, 2024), constitui o primeiro estudo
integral dedicado à figura, reunindo relatos orais inéditos, fotogra fias de campo e análise
comparada com mitos europeus (romenos, galegos e bretões).
Fontes complementares:
– Arquivo Distrital de Bragança, Registos Etnográ ficos de Montalegre e Vinhais, 1935–1962;
– Museu da Terra de Miranda, Cadernos da Oralidade (1950–1980);
– Tese de Doutoramento de Sofia Ribeiro, Lobas, Bruxas e Resistência:  Gênero  e Natureza no
Norte de Portugal (U. Minho, 2021).
⸻
5. Síntese interpretativa final
A Mulher Loba é o espelho da metamorfose e da autonomia. O mito desvia-se da moral punitiva
das histórias de lobisomens e revela a dimensão libertadora da animalidade feminina. A

transformação noturna é o gesto de a firmação do corpo e da natureza — o regresso à comunhão
com o instinto.
A leitura da Associação  MILK inscreve este mito na genealogia dos corpos híbridos  portugueses
— seres entre humano e animal que traduzem o desejo de reconciliação entre cultura e natureza.
A loba não é monstro, é mediação.
Na escultura MILK criada por Eduardo Mauer, a Mulher Loba é representada com corpo
compacto, cabeça grande e expressão altiva. A pele exibe gradação de cinzas e prateados, e a
postura sugere movimento contido, entre o humano e o animal. A peça é acompanhada por som
de respiração e vento, evocando a corrida noturna.
⸻
6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer
Na leitura não binária de Eduardo Mauer, a Mulher Loba é o corpo da transição  total. Ela
desorganiza o sistema binário de humano/animal, homem/mulher, civilização/natureza. Ao tornar-
se loba, não renega o humano — amplia-o.
Mauer escreve: “A loba é o corpo queer da montanha. Não pertence a espécie alguma, não se
submete a nome algum. É o grito do corpo quando recusa ser domesticado.”
A Associação  MILK reconhece nesta figura a expressão máxima do Folclore Vivo enquanto
pedagogia de libertação. A loba simboliza o ser não categorizável — corpo fluido, instintivo,
poético. Nas leituras contemporâneas da arte queer portuguesa, torna-se metáfora da
insurgência e da reconciliação com o instinto reprimido.
⸻
7. Referência Estrutural da Matriz MILK
Na Matriz Escultórica MILK, a Mulher Loba é modelada com corpo humano compacto e cabeça
levemente alongada, com orelhas discretas e olhar penetrante. As cores predominantes são
cinza, prata e azul-escuro. A base circular representa a lua.
A instalação pode incluir som ambiente de uivos e vento serrano, criando atmosfera imersiva.
⸻
Localização  específica: Montalegre, Bragança, Vinhais, Melgaço e Terras de Bouro, Norte de
Portugal.
Primeiro relato documentado: Leite de Vasconcelos, Etnografia Portuguesa, vol. II, 1913.
Sistematização  contemporânea:  Eduardo Mauer, As Lobas do Norte: Corpo, Noite e
Resistência  no Imaginário  Português , Associação MILK, 2024.
Fontes primárias:  Vasconcelos (1913, 1919); Parafita (2008); Ribeiro (2021); Mauer (2024).
