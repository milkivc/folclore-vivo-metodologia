# 137. A Lenda da Voz da Fraga de Alvadia (Alta Montanha de Boticas – Barroso)

**Base documental e empírica:** pesquisa documental, análise comparada de fontes públicas, sistematização de tradição oral, relatos orais de pesquisa de campo e revisão semântica conduzidas no âmbito do Folclore Vivo da Associação MILK - Movimento de Intervenções e Linguagens Kulturais e Arte.
**Estado editorial:** corpus de pesquisa de campo e documentação cultural em revisão pública.
**Regra de publicabilidade:** esta entrada não deve ser lida como prova histórica definitiva, inventário patrimonial oficial, validação etnográfica concluída ou certificação académica externa sem verificação documental própria.
**Regra jurídica/RGPD:** não publicar nomes de informantes, contactos, moradas, entrevistas integrais, imagens identificáveis, gravações, dados de menores, coordenadas sensíveis ou materiais comunitários sem autorização.
**Regra de não invenção:** a presente readequação corrige a camada editorial e metodológica sem acrescentar factos, fontes, topónimos, coordenadas ou relatos não existentes no corpus-base.
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

137. A Lenda da Voz da Fraga de Alvadia (Alta Montanha de Boticas – Barroso)
Sistematização  contemporânea  conduzida por Eduardo Mauer no âmbito  das pesquisas da
Associação  MILK – Movimento de Intervenções e Linguagens Kulturais e Arte (Folclore Vivo –
Região  Norte de Portugal, 2023–2025).
⸻
1. Descrição  simbólica e narrativa
Entre os relevos ásperos da Alta Montanha de Boticas, na zona conhecida como Alvadia,
ergue-se uma fraga solitária — irregular, a fiada, inclinada na direção do vento — que o povo
nomeia simplesmente de A Voz. Não é a fraga que fala, dizem, mas algo que vive dentro dela. A
lenda da Voz da Fraga de Alvadia descreve uma entidade que não possui corpo, mas produz
som; não possui rosto, mas deixa eco; não se mostra, mas guia. A Voz é o espírito da altitude,
guardiã dos caminhos, anunciadora de mudanças climáticas e testemunha imemorial da vida
barrosã.
Os habitantes descrevem-na como “um som de mulher, mas que não é de mulher”, emitido
sempre ao amanhecer e ao crepúsculo, quando o sol toca o granito e desperta o eco da encosta.
A Voz não fala palavras — emite sílabas soltas, melodias breves, lamentos, chamamentos que
se dissipam antes de poderem ser fixados. Quem ouve, porém, compreende intuitivamente o
aviso ou a intenção: parar, avançar, recuar, aguardar.
Relatos recolhidos por Eduardo Mauer (2024–2025) afirmam que a Voz se manifesta sobretudo a
pastores, caminhantes e guardadores de gado. Quando a montanha se cobre de neblina súbita, a
Voz é audível como um fio estendido no ar, indicando a direção do refúgio mais próximo. Em
outras ocasiões, serve como advertência: se o clima vai virar, se a neve chegará antes do
previsto, ela canta intervalos dissonantes, como um sino rachado, empurrando o ouvinte para
longe dos desfiladeiros.
Há também episódios de caráter moral. Um pastor de Ardãos, entrevistado por Mauer, narrou
que, certa vez, ao tentar cortar mais madeira do que lhe era permitido, a Voz ecoou três vezes —
cada vez mais forte — até que ele desistiu. “Ela protege o que é dela”, disse, apontando para a
montanha.


Uma narrativa antiga conta que, há muitos séculos, um grupo de viajantes procurava refúgio
durante uma tempestade. A Voz conduziu-os até um penedo oco, onde passaram a noite. Ao
amanhecer, perceberam que tinham dormido num local onde, segundo antigas tradições, antes
se realizavam rituais de consagração da montanha. A Voz, dizem, protege quem respeita o lugar
e pune discretamente quem o agride. Nunca com violência, mas com perda de orientação , que
só se resolve quando o viajante aprende a escutar.
Não existe descrição corporal da entidade, pois a Voz é, paradoxalmente, uma presença total e
invisível. Alguns afirmam que ela é o espírito de uma antiga guardiã da montanha; outros dizem
ser apenas a própria montanha que adquiriu linguagem com os anos; há ainda quem acredite
tratar-se de uma moura desencantada, que perdeu o corpo mas manteve a voz para avisar os
vivos.
Em todos os casos, a Voz é liminar: situa-se entre o natural e o sobrenatural, entre o humano e o
inominável.
⸻
2. Contexto histórico e social
A região de Boticas, em pleno Barroso, mantém forte tradição de montanha, marcada por
isolamento, transumância e formas comunitárias de sobrevivência. A convivência constante com
o clima rigoroso — neve, neblina, ventos cortantes — fomentou no imaginário local a crença em
entidades protetoras e avisadoras. Na literatura etnográ fica portuguesa, o Barroso é
repetidamente referido como lugar de limiares: fronteiras entre mundos, entre estações, entre o
visível e o invisível.
Na Idade Média, documentos do Foral de Chaves (século XIII) já mencionam “vozes da serra”
interpretadas como sinais meteorológicos. No século XVIII, o abade José António da Fonseca,
em manuscritos remetidos ao bispado de Braga, escreveu sobre “ecos que falam como gente”,
descrevendo-os como fenómenos naturais mas reconhecendo que o povo lhes atribuía sentido
espiritual.
Com a progressiva cristianização da região, muitas dessas crenças foram reinterpretadas.
Entretanto, a Voz da Fraga de Alvadia resistiu ao processo. Talvez por não ser corpo, nem figura,
nem espírito de pessoa morta — mas manifestação  sonora da montanha.
Boticas também preserva até hoje práticas comunitárias ancestrais — sistemas de regadio
partilhado, fornos comunais, criação de gado — que mantêm viva a relação íntima com a
geografia. Isso faz da Voz uma espécie de pedagogia ecológica, expressão oral de uma ética
barrosã que preserva o equilíbrio entre humano e território.
A investigação de campo da Associação MILK identi ficou um padrão simbólico claro: nas aldeias
em altitude, as entidades tutelares não são necessariamente antropomór ficas. Podem ser sons,
ventos, luzes, ecos, vultos — forças que organizam a vida humana em relação ao ambiente.
A Voz da Fraga de Alvadia é uma dessas forças.
⸻
3. Toponímia e variantes locais
Os topónimos ligados à entidade incluem:
	 •	 Fraga da Voz – penedo principal associado ao fenómeno.
	 •	 Corga da Mulher – ravina onde a Voz soa mais suave.
	 •	 Vale do Chamado – local onde se diz que a Voz chama pastores em
perigo.


	 •	 Socalcos da Escuta – patamar onde viajantes param para tentar ouvir os
sinais.
Variantes narrativas reconhecidas:
	 1.	 A Voz da Mulher Perdida – versão em que a entidade é espírito de uma
pastora morta em nevoeiro.
	 2.	 A Moura do Eco – variante que liga a Voz às mouras encantadas que
perdem o corpo mas preservam a voz.
	 3.	 O Chamado da Serra – versão mais naturalista, onde a Voz é mero eco
humanizado.
	 4.	 A Senhora da Altitude – forma mais cristianizada, aproximando-a de uma
“protetora do ar”.
Em todas as variantes, o som é o centro do mito, não a figura.
⸻
4. Primeiro relato e fontes académicas primárias
Primeiras referências documentais
Embora a expressão “Voz da Fraga de Alvadia” seja moderna, o motivo da voz sem corpo está
presente em diversas fontes:
	 •	 José António da Fonseca (séc. XVIII) – Cartas pastorais sobre o clima de
Barroso: menciona “ecos falantes” das montanhas de Boticas.
	 •	 Leite de Vasconcelos, Etnografia Portuguesa, vol. VII (1928) – descreve
crenças sobre vozes em penedos e fragas no Norte.
	 •	 Teófilo Braga, Tradições Populares Portuguesas (1885) – inclui registos
sobre “vozes de aviso” na montanha.
	 •	 Documentação  do antigo concelho de Chaves (séc. XVI–XVIII) –
referências a “chamamentos de serra” em Boticas.
Primeira fixação  sistematizada
	 •	 Eduardo Mauer, “A Voz da Fraga: Som, Altitude e Proteção  no Barroso”
(Dossiê MILK, 2025) – 19 testemunhos orais geo-referenciados; gravações de campo;
análise acústica e comparação com fenómenos de eco orográ fico.
⸻
5. Síntese interpretativa final
A Voz da Fraga de Alvadia sintetiza três dimensões fundamentais do imaginário barrosão:
1. Dimensão  ecológica
A voz funciona como sistema de orientação  ambiental, ensinando a respeitar o clima e a
montanha. É a forma simbólica de transmitir a sabedoria ancestral sobre neves súbitas, ventos
perigosos, desfiladeiros.
2. Dimensão  moral
A entidade recompensa o cuidado e alerta contra o abuso. Não castiga, mas adverte, reforçando
comportamentos comunitários de respeito.
3. Dimensão  liminar
A ausência de corpo e a presença apenas sonora tornam a Voz uma entidade de fronteira —
entre presença e ausência, entre natureza e espírito, entre silêncio e aviso.


A interpretação contemporânea da Associação MILK coloca a Voz como património sonoro
espiritual, parte da ecologia emocional do Barroso.
⸻
6. Dimensão  Não  Binária  e Leitura Contemporânea  – interpretação  conduzida por Eduardo
Mauer
“A Voz é identidade sem forma: não tem género, não tem rosto — é pura relação.”
A Voz da Fraga dissolve a necessidade de corpo, género ou representação. Existe apenas
como som e cuidado.
Na leitura não binária de Mauer, a Voz manifesta a possibilidade de existência sem forma
fixa, sem fronteira definida, como gesto de relação pura.
A Voz representa a fluidez da identidade: o lugar onde o corpo deixa de ser necessário
para que a presença seja plena.
⸻
7. Referência Estrutural da Matriz MILK
	 •	 Cabeça: 60–65% do volume, ligeiramente inclinada, como quem escuta.
	 •	 Corpo: compacto, sem membros definidos, evocando a fusão do som com
o espaço.
	 •	 Textura: ondulações finas sugerindo vibração sonora.
	 •	 Cromia: cinza-granito com reflexos metálicos prateados.
	 •	 Base: plataforma estreita, evocando o cume da fraga.
	 •	 Eixo curatorial: Corpos Sonoros e Liminiares.
⸻
Localização:  Alvadia, Boticas, Barroso.
Primeiro relato: Cartas pastorais de J. A. Fonseca (séc. XVIII).
Fixação  contemporânea:  Eduardo Mauer, Dossiê MILK (2025).

---

## Bloco de normalização territorial e de aparição

**Localização específica (normalização editorial):** território indicado no título e no corpo da entrada: **A Lenda da Voz da Fraga de Alvadia (Alta Montanha de Boticas – Barroso)**. A delimitação administrativa, freguesia, concelho, distrito e coordenadas não são acrescentadas automaticamente e devem ser confirmadas em revisão documental antes de qualquer uso técnico, cartográfico, legislativo, financeiro ou patrimonial.

**Toponímia associada:** preservada conforme o texto-base da entrada. Esta normalização não introduz topónimo novo, não corrige por inferência externa e não transforma a designação narrativa em validação territorial oficial.

**Características físicas, forma de aparição ou modo de manifestação:** preservadas na secção “Descrição simbólica e narrativa”. O presente bloco apenas reforça a rastreabilidade editorial para GitHub e Zenodo, mantendo o estado da entrada como corpus interpretativo em revisão.

**Estado de validação territorial:** a confirmar em revisão documental e humana.

