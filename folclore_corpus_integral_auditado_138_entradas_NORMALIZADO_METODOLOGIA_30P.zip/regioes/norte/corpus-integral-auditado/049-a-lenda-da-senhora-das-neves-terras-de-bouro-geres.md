# 049. A Lenda da Senhora das Neves (Terras de Bouro, Gerês)

**Base documental e empírica:** pesquisa documental, análise comparada de fontes públicas, sistematização de tradição oral, relatos orais de pesquisa de campo e revisão semântica conduzidas no âmbito do Folclore Vivo da Associação MILK - Movimento de Intervenções e Linguagens Kulturais e Arte.
**Estado editorial:** corpus de pesquisa de campo e documentação cultural em revisão pública.
**Regra de publicabilidade:** esta entrada não deve ser lida como prova histórica definitiva, inventário patrimonial oficial, validação etnográfica concluída ou certificação académica externa sem verificação documental própria.
**Regra jurídica/RGPD:** não publicar nomes de informantes, contactos, moradas, entrevistas integrais, imagens identificáveis, gravações, dados de menores, coordenadas sensíveis ou materiais comunitários sem autorização.
**Regra de não invenção:** a presente readequação corrige a camada editorial e metodológica sem acrescentar factos, fontes, topónimos, coordenadas ou relatos não existentes no corpus-base.
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

49. A Lenda da Senhora das Neves (Terras de Bouro, Gerês)
(Suma sistematizada por Eduardo Mauer no âmbito  das pesquisas sobre Folclore Vivo da
Associação  MILK – Movimento de Intervenções e Linguagens Kulturais e Arte, a partir de fontes
históricas, litúrgicas e orais recolhidas entre 2022 e 2024 nas aldeias de Campo do Gerês,  Covide,
e nas encostas da Serra Amarela, em articulação  com o Arquivo Distrital de Braga e o Museu de
Etnologia.)
⸻
1. Descrição  simbólica e narrativa
A Lenda da Senhora das Neves ocupa lugar central no imaginário espiritual de Terras de Bouro
e da Serra Amarela, no Parque Nacional da Peneda-Gerês. É uma das manifestações mais
notáveis do sincretismo entre o culto cristão mariano e a ancestral veneração pelas forças
naturais da montanha.
Segundo a tradição oral recolhida por Eduardo Mauer (2023), a origem da devoção remonta ao
século XIV. Pastores das aldeias altas, refugiando-se de uma tempestade de neve, encontraram
uma pequena imagem da Virgem soterrada junto à nascente do rio Homem, envolta por uma luz
suave. Um deles, Bernardo da Bouça, tentou levá-la consigo para o vale, mas a estátua

reapareceu no mesmo lugar, envolta em neve e orvalho. Três vezes a transportou e três vezes ela
regressou. Compreendendo o sinal, o povo construiu ali uma pequena ermida, dizendo:
“Aqui quer ficar a Senhora, onde a neve cobre e purifica.”
A partir desse acontecimento nasceu o culto da Senhora das Neves, celebrado todos os
anos a 5 de agosto, coincidindo com o antigo festival romano da Neve de Agosto
(Dedicação de Santa Maria Maior, em Roma), símbolo de pureza e renovação.
A lenda, porém, antecede o cristianismo. Os mais velhos a firmam que, muito antes da
igreja, já as mulheres depositavam flores brancas nas encostas cobertas de gelo, pedindo
fertilidade e bom tempo. Essa prática ancestral foi absorvida pela devoção mariana e
convertida em procissão e bênção das águas.
Durante as tempestades, diz-se que a Senhora aparece sobre os rochedos, envolta em
manto branco, guiando as ovelhas perdidas e acalmando o vento com um gesto da mão.
Há relatos de viajantes do século XIX que asseguram ter visto “ figura luminosa flutuando
sobre a serra em noites de neve”, fenómeno que alimentou a aura sobrenatural do lugar.
Na leitura simbólica de Eduardo Mauer, “a Senhora das Neves é a brancura da montanha
em estado de revelação — a aparição do equilíbrio entre o frio que mata e o frio que
conserva.”
⸻
2. Contexto histórico e social
O culto da Senhora das Neves integra o conjunto de devoções marianas de origem naturalista
do norte de Portugal, nas quais a Virgem é identi ficada com forças da paisagem — fontes,
montes, árvores, pedras. Em Terras de Bouro, essa identi ficação assume forma particularmente
intensa devido à topogra fia e ao clima da Serra Amarela, onde o inverno longo e as neves
tardias condicionaram profundamente a vida comunitária.
Os registos paroquiais do século XVII mencionam a “Festa da Senhora das Neves da Amarela”,
celebrada com missa campal, bênção das águas e distribuição de pão e leite. Era tradição que
cada pastor levasse à serra um cordeiro branco como oferenda, em memória da pureza da neve
e da fertilidade da terra.
O culto revela, portanto, o diálogo entre espiritualidade e sobrevivência: a neve como símbolo de
morte aparente e renascimento cíclico.
No século XIX, a romaria transformou-se em grande peregrinação regional, atraindo fiéis do
Gerês, Bouro e Braga. Cronistas como José Augusto Vieira (O Minho Pitoresco, 1886) e Leite
de Vasconcelos (1913) destacam o caráter festivo e contemplativo do evento, que unia rezas,
danças e banhos rituais nas lagoas.
A transição para o século XX marcou o declínio do carácter agrícola do culto, mas manteve-se a
crença nas aparições luminosas, particularmente entre pastores e guardas florestais.
Para Eduardo Mauer, “a Senhora das Neves é o rosto feminino da resiliência serrana — símbolo
de uma religiosidade meteorológica, em que a fé se faz de neblina, frio e claridade.”
⸻
3. Toponímia e variantes locais
O topónimo “Senhora das Neves” repete-se em múltiplas localidades portuguesas, mas em
Terras de Bouro adquire dimensão mitológica. A capela ergue-se a mais de mil metros de
altitude, sobre o planalto da Amarela, fronteira entre os vales do Lima e do Homem.


Variantes da lenda circulam nas aldeias vizinhas:
– Em Covide, fala-se da “Santa do Gelo”, mulher luminosa que caminha sobre os lagos
congelados;
– Em Campo do Gerês, narra-se que a Virgem desce do céu todos os anos para “lavar o manto
nas águas do Homem”;
– Em Ermida e Vilarinho das Furnas, menciona-se a “Branca das Pedras”, antiga deusa das
nascentes que, após o batismo, se tornou a Senhora das Neves.
Essas variantes confirmam a origem pré-cristã  do mito e a sua reinterpretação cristã posterior.
⸻
4. Primeiro relato e fontes académicas primárias
O primeiro relato escrito da Lenda da Senhora das Neves da Serra Amarela encontra-se em
Leite de Vasconcelos, Etnografia Portuguesa, vol. II (1913, pp. 259–265)*, onde o autor descreve
a “crença em mulher luminosa que acalma a neve e guarda os pastores perdidos”.
Teófilo Braga, O Povo Português  nos seus Costumes, Crenças e Tradições (1885, pp. 378–383)*,
já fazia menção à “santa branca da montanha” e à tradição dos cordeiros de neve, relacionando-
a com rituais agrários de puri ficação.
Alexandre Parafita, Mitologia Popular Portuguesa (2008, pp. 466–472)*, classifica o mito como
exemplo de “transmutação simbólica da deusa montanhesa em virgem cristã”, salientando a
persistência de elementos telúricos e climáticos.
A sistematização contemporânea de Eduardo Mauer, A Senhora das Neves: Clima, Pureza e
Transmutação  no Imaginário  do Gerês  (Lisboa, Associação MILK, 2024), propõe leitura não binária
e ecológica da figura, associando a brancura da neve à dissolução das fronteiras entre o humano
e o natural.
Fontes complementares:
– Arquivo Distrital de Braga, Livros Paroquiais de Bouro e Covide (séculos XVII–XIX);
– Museu de Etnologia, Coleção  de Festas Cíclicas  do Noroeste (1940–1980);
– Tese de Doutoramento de Rita Pacheco, Deusas Brancas: Meteorologia Sagrada e Feminino
Telúrico na Península  Ibérica  (U. Lisboa, 2020).
⸻
5. Síntese interpretativa final
A Senhora das Neves simboliza o limiar entre ausência e presença, a transfiguração da
paisagem em corpo espiritual. A neve, metáfora da suspensão do tempo, cobre e revela
simultaneamente — é o véu da natureza.
Na leitura simbólica da Associação  MILK, a Senhora das Neves é a mãe  translúcida da
montanha, imagem da pureza inclusiva e do equilíbrio climático. O mito ensina que o sagrado
não se opõe ao frio: nasce dele.
A escultura MILK concebida por Eduardo Mauer representa corpo compacto branco leitoso,
cabeça grande com olhos fechados, véu translúcido azul-acinzentado e base transparente. A luz
interna alterna em tons frios, simulando o brilho do gelo sob o sol.
⸻
6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer

Na leitura não binária de Eduardo Mauer, a Senhora das Neves é o corpo neutro da
purificação , o frio que não mata, mas preserva. Nem feminina nem celestial, é o princípio da
transparência — presença que não precisa de carne nem de nome.
Mauer escreve: “A neve é o corpo não binário da montanha: cobre e revela, mata e conserva. A
Senhora é essa própria ambiguidade.”
A Associação  MILK entende o mito como metáfora da ecologia espiritual do equilíbrio
climático , unindo a estética do gelo e a ética da sustentabilidade.
⸻
7. Referência Estrutural da Matriz MILK
Na Matriz Escultórica MILK, a Senhora das Neves é representada com cabeça grande e véu
translúcido branco-azulado, corpo compacto e base cristalina. A luz interna alterna entre branco
e azul, evocando a purificação e o renascimento.
⸻
Localização  específica: Serra Amarela, concelho de Terras de Bouro, distrito de Braga.
Primeiro relato documentado: Leite de Vasconcelos, Etnografia Portuguesa, vol. II, 1913.
Sistematização  contemporânea:  Eduardo Mauer, A Senhora das Neves: Clima, Pureza e
Transmutação  no Imaginário  do Gerês , Associação MILK, 2024.
Fontes primárias:  Braga (1885); Vasconcelos (1913); Parafita (2008); Pacheco (2020); Mauer
(2024).
