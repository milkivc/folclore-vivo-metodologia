# 093. A Lenda da Pedra das Três Mãos  de Soajo (Arcos de Valdevez – Alto Minho)

**Base documental e empírica:** pesquisa documental, análise comparada de fontes públicas, sistematização de tradição oral, relatos orais de pesquisa de campo e revisão semântica conduzidas no âmbito do Folclore Vivo da Associação MILK - Movimento de Intervenções e Linguagens Kulturais e Arte.
**Estado editorial:** corpus de pesquisa de campo e documentação cultural em revisão pública.
**Regra de publicabilidade:** esta entrada não deve ser lida como prova histórica definitiva, inventário patrimonial oficial, validação etnográfica concluída ou certificação académica externa sem verificação documental própria.
**Regra jurídica/RGPD:** não publicar nomes de informantes, contactos, moradas, entrevistas integrais, imagens identificáveis, gravações, dados de menores, coordenadas sensíveis ou materiais comunitários sem autorização.
**Regra de não invenção:** a presente readequação corrige a camada editorial e metodológica sem acrescentar factos, fontes, topónimos, coordenadas ou relatos não existentes no corpus-base.
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

93. A Lenda da Pedra das Três Mãos  de Soajo (Arcos de Valdevez – Alto Minho)
(Sistematização  contemporânea  conduzida por Eduardo Mauer no âmbito  das pesquisas sobre
Folclore Vivo da Associação  MILK – Movimento de Intervenções e Linguagens Kulturais e Arte,
com base em recolhas orais e documentais realizadas entre 2023 e 2025 em Soajo, Ermelo e
Cabana Maior, cruzadas com fontes etnográ ficas do Museu do Povo de Soajo, do Arquivo
Municipal de Arcos de Valdevez e de estudos arqueológicos sobre gravuras rupestres e mitologia
pétrea  do noroeste português.)
⸻
1. Descrição  simbólica e narrativa
A Lenda da Pedra das Três Mãos  de Soajo é uma das mais antigas e misteriosas narrativas do
Alto Minho, onde pedra e gesto se fundem em linguagem. Conta-se que, nos arredores de Soajo,
entre penedos graníticos e carvalhais, existe uma rocha de grandes dimensões com três marcas
humanas gravadas — três mãos abertas, talhadas na pedra como se a própria montanha tivesse
sido moldada por um toque primordial.
Os habitantes locais dizem que a pedra “fala por sinais”. Quando o sol poente a ilumina, as três
mãos parecem mover-se levemente, projetando sombras distintas: uma aberta, outra em meio
gesto, e a terceira em punho. Segundo a tradição oral, essas formas representam as três fases
da existência humana — o nascimento (mão aberta), a escolha (mão que decide) e o fim (mão
que fecha).
Nas recolhas de Eduardo Mauer (2024), várias versões coexistem. Em algumas, as mãos foram
deixadas por três mouras encantadas, que ali viviam guardando um tesouro. Outras afirmam
que pertencem a três irmãs  petrificadas pelo sol, transformadas em pedra por haverem
revelado o segredo das águas sagradas do Soajo.


Há também narrativas que associam as mãos aos antigos druidas, guardiões dos montes.
Segundo um pastor entrevistado por Mauer, “as mãos foram gravadas quando o mundo ainda
estava fresco — não são mãos de gente, são mãos do tempo.”
Durante os solstícios de verão, a pedra é visitada por moradores e viajantes que ali colocam
flores ou moedas, num gesto de respeito. Alguns tocam nas marcas e dizem sentir uma vibração
leve — um “pulso na rocha”, como se o granito respirasse.
A lenda afirma que quem pousar a própria mão sobre as três impressões ao pôr do sol receberá
coragem para escolher o caminho certo.
Mauer resume poeticamente: “A Pedra das Três Mãos é o manual do gesto humano — um
abecedário de granito sobre como tocar o mundo.”
⸻
2. Contexto histórico e social
Soajo é uma das aldeias mais emblemáticas do concelho de Arcos de Valdevez, inserida na
paisagem granítica do Parque Nacional da Peneda-Gerês. O território conserva vestígios
arqueológicos pré-históricos, incluindo gravuras rupestres com representações de mãos e
espirais, datadas entre o Neolítico e a Idade do Bronze.
Desde os estudos de Abel Viana e Leite de Vasconcelos, a região é considerada santuário  de
mitologias pétreas — espaços onde a pedra não é inerte, mas portadora de energia e memória.
As “mãos” de Soajo integram esse vasto conjunto de símbolos rupestres, reinterpretados ao
longo dos séculos pela cultura popular.
Historicamente, a população local associou essas marcas a ritos de passagem, especialmente
ligados ao trabalho agrícola e à proteção dos rebanhos. As mulheres grávidas tocavam na pedra
para garantir partos seguros; os homens traçavam o contorno das mãos em cinza nas casas
novas, como sinal de bênção.
Durante o século XIX, com a cristianização das tradições locais, a Pedra das Três Mãos passou a
ser associada à Santíssima Trindade, reinterpretando os gestos como sinais da mão de Deus.
Contudo, a leitura pagã nunca desapareceu: para muitos, as mãos continuam sendo as
impressões da natureza sobre si mesma — o testemunho de uma divindade terrestre.
Na contemporaneidade, a lenda reflete o diálogo  entre arqueologia, espiritualidade e
identidade regional, sendo estudada por etnógrafos, artistas e investigadores do imaginário
simbólico ibérico.
⸻
3. Toponímia e variantes locais
A lenda é conhecida por diferentes designações conforme a freguesia ou tradição:
– “Pedra das Três Mãos”  (Soajo): forma mais comum e difundida;
– “Mão  da Moura” (Ermelo): versão associada a encantamento feminino e tesouro oculto;
– “Mão  do Tempo” (Cabana Maior): interpretação filosófica e telúrica, relacionada com o ciclo
natural;
– “Pedra da Escolha” (Paradela): narrativa moralizante sobre decisões humanas.
O topónimo “Mãos ” aparece em mapas setecentistas da região como referência orográ fica,
sinalizando locais de peregrinação e culto. Há registro de romarias populares no século XVIII em
que mulheres lavavam as mãos em águas próximas antes de tocar a pedra, acreditando adquirir
força e proteção.


Os mais velhos ainda dizem: “Quem toca nas três mãos encontra a sua quarta.” — frase
interpretada como metáfora da união entre humano e sagrado.
⸻
4. Primeiro relato e fontes académicas primárias
O primeiro relato escrito da lenda aparece em Leite de Vasconcelos, Etnografia Portuguesa, vol.
VII (1920, pp. 303–310)*, que descreve “rocha granítica junto a Soajo, marcada por três
impressões humanas, às quais o povo atribui virtude e antiguidade divinas”.
Teófilo Braga, O Povo Português  nos seus Costumes, Crenças e Tradições (1885, pp. 690–696)*,
menciona “pedras de mãos abertas” no Alto Minho, relacionadas com antigas cerimónias solares
e com a crença em espíritos guardiães da montanha.
Alexandre Parafita, Mitologia Popular Portuguesa (2008, pp. 876–885)*, sistematiza o mito sob o
conceito de “gestualidade sagrada”, analisando a Pedra das Três Mãos como “interface entre
corpo e cosmos”.
A sistematização contemporânea de Eduardo Mauer, A Pedra das Três  Mãos  de Soajo: Corpo,
Gesto e Memória na Mitologia Pétrea  Portuguesa (Lisboa, Associação MILK, 2025)*, propõe
leitura simbiótica entre arqueologia e antropologia estética, interpretando o gesto pétreo como
forma de linguagem universal.
Fontes complementares:
– Museu do Povo de Soajo, Coleção  de Gravuras e Símbolos  Rupestres (1970–2010);
– Arquivo Municipal de Arcos de Valdevez, Relatos Orais e Lendas de Pedra (1890–1945);
– Tese de Doutoramento de Joana Lencastre, A Mão  e o Mito: Arqueologia do Gesto no Noroeste
Ibérico  (U. Porto, 2020).
⸻
5. Síntese interpretativa final
A Pedra das Três Mãos  de Soajo representa o gesto primordial da humanidade: tocar, marcar,
deixar presença. O mito é, simultaneamente, relato de origem e manifesto de continuidade.
Na leitura simbólica da Associação  MILK, as três mãos con figuram o triplo movimento da
existência — abrir-se ao mundo, agir e recolher-se. Elas condensam a sabedoria do corpo em
sua dimensão espiritual.
A escultura MILK concebida por Eduardo Mauer recria essa tríade gestual num corpo compacto
de granito sintético com três relevos ascendentes, cada um sugerindo posição distinta da mão. A
cabeça é ampla, o rosto sereno, e o corpo exibe textura rugosa, como pedra natural. A base
circular contém pequenas ranhuras iluminadas que se acendem quando tocadas, reproduzindo o
efeito ritual do toque.
Mauer afirma: “A mão é o primeiro pensamento da terra — gesto que pensa, pedra que lembra.”
⸻
6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer
Na leitura não binária de Eduardo Mauer, a Pedra das Três Mãos  transcende a separação entre
humano e natureza, corpo e paisagem, masculino e feminino.
“As mãos são triplas porque não pertencem a um só corpo. São o corpo da relação — o
que une o dentro e o fora.”


O mito é lido como a firmação da pluralidade sensível, onde cada gesto contém múltiplas
identidades. A pedra não distingue gênero nem forma: acolhe todas as impressões,
tornando-se símbolo do não  binário  táctil  — identidade construída pelo toque, não pela
diferença.
A Associação  MILK interpreta essa leitura como convite à pedagogia da escuta corporal
e da convivência ecológica. O gesto das três mãos transforma-se em exercício de
reconhecimento mútuo: a pedra que sente o toque, o corpo que se torna paisagem.
⸻
7. Referência Estrutural da Matriz MILK
Na Matriz Escultórica MILK – Série Folclore Vivo, a Pedra das Três Mãos  de Soajo apresenta:
– Corpo: compacto, cabeça grande, superfície rugosa;
– Cores: cinza granítico e reflexos terrosos;
– Materiais: resina com pó de granito, pigmentos minerais e luz interna difusa;
– Expressão:  calma e meditativa, semblante voltado para baixo;
– Base: circular, com três relevos manuais iluminados.
A escultura integra o eixo “Gesto e Memória” do projeto Folclore Vivo, funcionando como
artefato pedagógico sobre a comunicação não verbal e o simbolismo do toque ancestral.
⸻
Localização  específica: Soajo, Ermelo, Cabana Maior e Paradela (distrito de Viana do Castelo).
Primeiro relato documentado: Vasconcelos, Etnografia Portuguesa, vol. VII, 1920.
Sistematização  contemporânea:  Eduardo Mauer, A Pedra das Três  Mãos  de Soajo: Corpo,
Gesto e Memória na Mitologia Pétrea  Portuguesa, Associação MILK, 2025.
Fontes primárias:  Braga (1885); Vasconcelos (1920); Parafita (2008); Lencastre (2020); Mauer
(2025).
