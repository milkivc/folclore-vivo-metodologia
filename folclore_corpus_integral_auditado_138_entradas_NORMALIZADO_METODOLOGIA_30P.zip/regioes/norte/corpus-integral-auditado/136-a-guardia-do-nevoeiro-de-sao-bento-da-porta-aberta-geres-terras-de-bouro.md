# 136. A Guardiã  do Nevoeiro de São  Bento da Porta Aberta (Gerês – Terras de Bouro)

**Base documental e empírica:** pesquisa documental, análise comparada de fontes públicas, sistematização de tradição oral, relatos orais de pesquisa de campo e revisão semântica conduzidas no âmbito do Folclore Vivo da Associação MILK - Movimento de Intervenções e Linguagens Kulturais e Arte.
**Estado editorial:** corpus de pesquisa de campo e documentação cultural em revisão pública.
**Regra de publicabilidade:** esta entrada não deve ser lida como prova histórica definitiva, inventário patrimonial oficial, validação etnográfica concluída ou certificação académica externa sem verificação documental própria.
**Regra jurídica/RGPD:** não publicar nomes de informantes, contactos, moradas, entrevistas integrais, imagens identificáveis, gravações, dados de menores, coordenadas sensíveis ou materiais comunitários sem autorização.
**Regra de não invenção:** a presente readequação corrige a camada editorial e metodológica sem acrescentar factos, fontes, topónimos, coordenadas ou relatos não existentes no corpus-base.
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

136. A Guardiã  do Nevoeiro de São  Bento da Porta Aberta (Gerês – Terras de Bouro)
Sistematização  contemporânea  conduzida por Eduardo Mauer no âmbito  das pesquisas da
Associação  MILK – Movimento de Intervenções e Linguagens Kulturais e Arte (Folclore Vivo –
Região  Norte de Portugal, 2023–2025).
⸻
1. Descrição  simbólica e narrativa
Entre as encostas vertiginosas do Vale do Homem, no coração do Gerês, onde a umidade se
eleva do rio como respiração antiga e a luz da manhã se parte em véus translúcidos, narra-se a
existência da Guardiã  do Nevoeiro, entidade feminina, intemporal e silenciosa que preside aos
mantos de névoa que cobrem a região de São  Bento da Porta Aberta, sobretudo nos meses de
transição entre primavera e outono.
O povo descreve-a como figura de corpo alto, mas de movimento quase sem peso, trajada com
tecido translúcido semelhante à própria névoa. Seu rosto não se distingue completamente, como
se estivesse feito de luz filtrada por água. Os olhos surgem apenas quando o nevoeiro se adensa:
dois pontos prateados, suaves e atentos. Os cabelos, longos e ondulantes, confundem-se com
as geadas suspensas no ar. Em vez de pés, alguns a firmam ver “um fluir”, movimento ondulante
que não toca o chão.
A Guardiã não fala: sopra. Seu sopro altera o nevoeiro — ora o densi fica, ora o abre em clareiras
limpas. É por isso que, segundo os habitantes de Crasto, “quem sabe ouvir o nevoeiro sabe
ouvir a Guardiã”. Há testemunhos recolhidos por Eduardo Mauer (2024–2025) de peregrinos que
afirmam ter visto a figura surgir no adro do santuário histórico, mantendo-se imóvel até que a
neblina descesse completamente sobre o vale, como quem sela um gesto ritual.
A Guardiã aparece em momentos de trânsito  e escolhas. Se um viajante hesita no caminho
pedregoso, dizem que ela se aproxima, fazendo o nevoeiro abrir-se como uma cortina, revelando
o trilho mais seguro. No entanto, se o viajante caminha com arrogância, ignorando o ambiente ou
desrespeitando o santuário e a montanha, a Guardiã responde adensando o nevoeiro, tornando
tudo opaco até que o intruso seja forçado a parar.
Dizem que protege especialmente peregrinos solitários , pastores e guardas florestais. A
tradição oral local relata que, em noites de verão, quando o rio sobe de forma inesperada, a
Guardiã guia os rebanhos e seus donos para zonas altas antes das cheias repentinas.
Uma história recolhida em Bouro (Santa Maria) fala de uma menina perdida na mata, que
encontrou “uma mulher de luz no nevoeiro” que lhe estendeu a mão — e quando a menina

piscou, já estava à beira de sua aldeia. A mãe, ao ouvir o relato, respondeu: “A Guardiã devolveu-
te ao mundo.”
A Guardiã não é espírito de morte nem anjo protetor no sentido cristão. É antes metáfora  viva da
transição , daquilo que existe entre o visível e o oculto; entre o que vem e o que parte. No Gerês,
o nevoeiro não é apenas fenómeno climático — é território espiritual, e a Guardiã é sua
intérprete.
⸻
2. Contexto histórico e social
A região de São  Bento da Porta Aberta, na vertente geresiana de Terras de Bouro, conserva
uma das tradições religiosas e populares mais enraizadas do Norte: romarias, ex-votos,
peregrinações, benzimentos e práticas populares de proteção de caminhos e casas.
A presença quase constante do nevoeiro no Vale do Homem consolidou uma cultura local que
relaciona este fenómeno com avisos naturais, sinais de proteção e presságios. Antes da
cristianização plena da região, fontes medievais e tardo-medievais já descreviam “mulheres
brancas da serra”, “figuras moventes no nevoeiro” e “donas da passagem”, entidades associadas
às mudanças súbitas de clima e de trilho.
Estudos climáticos da Serra do Gerês (UTAD, 1998–2020) con firmam que o vale regista as
maiores formações de nevoeiro de toda a região setentrional, fenómeno reforçado pela
morfologia serrana, pela proximidade do rio Homem e pela diferença térmica ao amanhecer.
Com a expansão do culto de São  Bento (século XVII), a figura do santo coexistiu com elementos
pré-cristãos ligados à névoa, à montanha e ao silêncio. É frequente em documentos paroquiais
do século XIX a menção a “aparições de mulher” quando o nevoeiro se adensa, interpretadas ora
como aviso contra perigos, ora como intervenção divina.
A Guardiã, no entanto, não surge nos textos eclesiásticos como santa ou alma — é figura liminar,
respeitada ao lado da devoção tradicional, mas compreendida como força da montanha, não da
religião institucional.
⸻
3. Toponímia e variantes locais
A pesquisa de campo MILK 2025 registou diversos topónimos associados à narrativa:
	 •	 “Caminho da Senhora do Ar” – trilho usado por pastores onde se diz que
a Guardiã abre clareiras no nevoeiro.
	 •	 “Vale da Nuvem Baixa” – zona onde a névoa fica presa entre duas
encostas, associada a manifestações da entidade.
	 •	 “Fenda da Luz” – fenda rochosa onde vários informantes a firmam ter visto
a figura brilhar.
	 •	 “Adro Velho de Nevoeiro” – espaço no entorno do antigo caminho de
peregrinação onde ocorrem relatos de aparições.
Variantes:
	 1.	 A Mulher do Ar – versão de Bouro onde a Guardiã é uma figura de vento,
não de nevoeiro.
	 2.	 A Senhora da Porta de Fumo – variante simbólica que representa a
transição, associada à antiga porta do santuário.
	 3.	 A Sombra Clara – versão minimalista em que a entidade é apenas um
movimento de luz.
⸻


4. Primeiro relato e fontes académicas primárias
Primeira referência documental provável
Os registos escritos mais antigos que se aproximam da Guardiã são descrições de “mulheres
brancas da montanha”, presentes em:
	 •	 Pinto de Araújo, José. Memórias sobre as Terras da Nóbrega e Bouro
(1784–1811) – refere “figuras femininas de neblina” vistas por pastores.
	 •	 Manuel de Azevedo Vieira, Crónicas do Vale do Homem (1842) –
menciona “a mulher do véu de vento” que aparece em noites húmidas.
Fontes clássicas  de enquadramento
	 •	 Leite de Vasconcelos, Etnografia Portuguesa, vols. VII e IX – registos de
entidades femininas atmosféricas.
	 •	 Teófilo Braga, Crenças Populares de Portugal (1903) – secções sobre
nevoeiro e manifestações femininas.
	 •	 J. Dias e E. Galhano (Museu de Etnologia) – estudos sobre religiosidade
serrana e figuras liminares pré-cristãs.
Primeira fixação  sistematizada
	 •	 Eduardo Mauer, “A Guardiã  do Nevoeiro: Vozes e Aparições na Porta
Aberta” (Dossiê MILK, 2025) – 14 testemunhos geo-referenciados, cartografia
atmosférica, fotogra fia e análise comparada.
⸻
5. Síntese interpretativa final
O mito da Guardiã é tecnologia de orientação  espiritual e ecológica. O nevoeiro funciona
como metáfora de dúvida, introspeção e silêncio, e a Guardiã é a figura que regula esses limites.
O Gerês é território de transição — entre clima, altura, água e terra — e a Guardiã é símbolo
dessa fronteira. Em vez de castigar, ensina o ritmo da montanha: parar, esperar, observar,
confiar.
Na perspectiva da Associação  MILK, a Guardiã encarna a noção de “ cuidado atmosférico”: a
ideia de que o ambiente não é inerte, mas agente pedagógico. Sua aparição marca limites éticos
entre caminhar com respeito e caminhar com arrogância.
A sua relação com peregrinos reforça a noção de que o mito serve para proteger o frágil, orientar
o incerto e honrar o percurso humano.
⸻
6. Dimensão  Não  Binária  e Leitura Contemporânea  – interpretação  conduzida por Eduardo
Mauer
“A Guardiã do Nevoeiro é corpo liminar: nem mulher, nem sombra, nem luz. É intervalo —
o espaço onde o género se dissolve e resta apenas cuidado.”
A leitura não binária acentua a natureza fluida e indefinível da Guardiã. A figura não possui
género fixo, rosto nítido, tessitura linear. É corpo atmosférico, feito do que existe entre.
Para Mauer, a Guardiã representa a gramática  do não-binário  aplicada à  paisagem:
presença que existe na transição, que se manifesta em gradações e não em dicotomias.


A Guardiã inspira o ficinas MILK de sensibilização  ambiental e introspectiva, centradas
na atenção ao clima, na respiração e na ideia de que a identidade pode ser movimento,
não forma.
⸻
7. Referência Estrutural da Matriz MILK
	 •	 Corpo: ergue-se em verticalidade suave, com inclinação mínima sugerindo
flutuação.
	 •	 Cabeça: grande, difusa, com superfície levemente translúcida.
	 •	 Tronco e membros: compactos, arredondados, proporção 60–65% de
cabeça conforme a matriz padrão.
	 •	 Cromia: branco-gelo com véus cinza muito claros.
	 •	 Textura: lisa com microgrãos brilhantes, evocando humidade suspensa.
	 •	 Base: plataforma circular fina, sugerindo dispersão de nevoeiro.
	 •	 Eixo curatorial: Corpos Atmosféricos e Liminiares.
⸻
Localização  específica: São Bento da Porta Aberta, Terras de Bouro, Gerês.
Primeiro relato documentado: Memórias sobre as Terras da Nóbrega e Bouro (1784–1811).
Fixação  contemporânea:  Eduardo Mauer – Dossiê MILK (2025).
