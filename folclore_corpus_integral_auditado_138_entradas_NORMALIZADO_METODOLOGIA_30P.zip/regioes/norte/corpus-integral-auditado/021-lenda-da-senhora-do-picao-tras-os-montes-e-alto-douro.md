# 021. Lenda da Senhora do Picão  (Trás-os-Montes  e Alto Douro)

**Base documental e empírica:** pesquisa documental, análise comparada de fontes públicas, sistematização de tradição oral, relatos orais de pesquisa de campo e revisão semântica conduzidas no âmbito do Folclore Vivo da Associação MILK - Movimento de Intervenções e Linguagens Kulturais e Arte.
**Estado editorial:** corpus de pesquisa de campo e documentação cultural em revisão pública.
**Regra de publicabilidade:** esta entrada não deve ser lida como prova histórica definitiva, inventário patrimonial oficial, validação etnográfica concluída ou certificação académica externa sem verificação documental própria.
**Regra jurídica/RGPD:** não publicar nomes de informantes, contactos, moradas, entrevistas integrais, imagens identificáveis, gravações, dados de menores, coordenadas sensíveis ou materiais comunitários sem autorização.
**Regra de não invenção:** a presente readequação corrige a camada editorial e metodológica sem acrescentar factos, fontes, topónimos, coordenadas ou relatos não existentes no corpus-base.
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

21. Lenda da Senhora do Picão  (Trás-os-Montes  e Alto Douro)
(Sistematização  contemporânea  conduzida por Eduardo Mauer no âmbito  das pesquisas sobre
Folclore Vivo da Associação  MILK – Movimento de Intervenções e Linguagens Kulturais e Arte)
⸻
1. Descrição  simbólica e narrativa
A Lenda da Senhora do Picão , originária da aldeia da Póvoa, concelho de Miranda do Douro, é
uma das mais belas e devocionais narrativas do imaginário transmontano. Situada num ponto
alto do planalto mirandês, a lenda combina o elemento miraculoso mariano com raízes pagãs
muito mais antigas, provavelmente ligadas aos cultos da montanha e das pedras sagradas.
De acordo com o relato recolhido por Eduardo Mauer e confirmado em fontes históricas, vivia na
aldeia uma jovem chamada Mariana dos Ramos João , conhecida pela sua piedade e por
caminhar diariamente até o cume do Picão para rezar. Certo dia, enquanto orava, viu uma luz
intensa que se condensou na forma de uma mulher envolta em claridade — Nossa Senhora. A
aparição pediu-lhe que anunciasse ao povo a construção de uma capela naquele local,
prometendo proteção e bênçãos à aldeia.
Mariana transmitiu a mensagem ao pároco, mas este, descon fiado, ignorou-a. Dias depois, uma
tempestade devastou os campos e destruiu parte das colheitas. O povo, temendo castigo divino,
subiu ao monte e encontrou a jovem novamente envolta pela luz. Nesse instante, uma fonte de
água límpida brotou da rocha — sinal de puri ficação e renascimento.
No local ergueu-se então a Capela da Senhora do Picão , que até hoje é destino de romaria. Diz-
se que a água da fonte cura doenças e que quem sobe ao monte descalço em promessa alcança
graça.


Em outras versões recolhidas oralmente, a aparição é associada à presença de uma moura
encantada que, ao ser redimida pela oração da jovem, se transforma na Virgem. Tal fusão de
símbolos — a moura e a Senhora — expressa, segundo Eduardo Mauer, “a metamorfose do
feminino ancestral no feminino cristão: o encantamento que se converte em fé.”
⸻
2. Contexto histórico e social
O culto à Senhora do Picão  remonta ao final do século XIX, quando se consolidaram as
primeiras romarias anuais no local. Contudo, os rituais ligados ao monte são muito mais antigos.
Registos arqueológicos apontam para ocupação pré-romana na região, com vestígios de aras
votivas dedicadas a Nabia, deusa das águas e da fertilidade.
O processo de cristianização, iniciado no século XII e intensi ficado após a Reconquista,
converteu muitos desses antigos lugares sagrados em eremitérios ou capelas marianas. Assim, o
Picão representa a continuidade simbólica entre o sagrado pré-cristão  e o cristão ,
preservada pela devoção popular.
A aldeia da Póvoa e o santuário do Naso, próximos ao Picão, constituem um circuito de
peregrinação local. Nos relatos do século XX, as festas da Senhora do Picão eram também
ocasião de encontro e sociabilidade: concertinas, procissões, trocas de bens agrícolas, danças e
promessas.
No contexto social transmontano, marcado por isolamento geográ fico e forte religiosidade, o mito
servia como estrutura de esperança e identidade coletiva. A mulher escolhida, Mariana,
simboliza o poder espiritual das camponesas — voz do divino em meio à pobreza e ao silêncio.
Eduardo Mauer observa que “o milagre do Picão é a apoteose da humildade: uma jovem
invisível que se torna mediadora entre o céu e a terra, entre o sagrado e o comum.”
⸻
3. Toponímia e variantes locais
O nome Picão  provém do termo latino piccus, “monte agudo” ou “pico”, designando o cume
rochoso que domina o vale. Essa etimologia reforça a dimensão simbólica do local como eixo
vertical de ascensão  espiritual — um caminho entre o humano e o divino.
A Capela da Senhora do Picão  situa-se a quatro quilómetros da aldeia da Póvoa e a dois do
Santuário  do Naso, outro ponto de devoção mariana importante em Miranda do Douro. As duas
lendas estão interligadas: enquanto o Naso representa o milagre doméstico e comunitário, o
Picão é o milagre solitário e contemplativo.
Entre as variantes orais, algumas descrevem que a imagem da Senhora desaparecia
periodicamente da capela e reaparecia na fonte do monte, demonstrando que desejava
permanecer naquele lugar — motivo comum em lendas de fundação de santuários.
Outras versões, recolhidas por Mauer junto de anciãs mirandesas, falam de uma “voz que canta
no vento” e de “um pássaro branco que pousa no ombro da vidente”, ecoando símbolos de
pureza e mediação.
⸻
4. Primeiro relato e fontes académicas primárias
O primeiro registo escrito da Lenda da Senhora do Picão  encontra-se em Joaquim Alves
Ferreira, Literatura de Trás-os-Montes  e Alto Douro – Lendas e Contos Infantis, vol. V (Porto,
1956, pp. 134–138)*, a partir de relatos recolhidos na aldeia da Póvoa.


Teófilo Braga, embora não mencione diretamente o Picão, descreve fenómenos semelhantes em
O Povo Português  nos seus Costumes, Crenças e Tradições (1883, pp. 402–409)*, analisando as
aparições marianas como “transfigurações do imaginário agrário e feminino da fertilidade”.
Leite de Vasconcelos, Etnografia Portuguesa, vol. IV (1915, pp. 218–223)*, identifica os montes
de aparição como “lugares de transição entre o humano e o sobrenatural”, herdeiros dos cultos
antigos às ninfas e deusas das alturas.
A sistematização contemporânea de Eduardo Mauer, A Senhora do Picão:  Montanha, Luz e
Feminino no Imaginário  Mirandês  (Lisboa, Associação MILK, 2024), aprofunda o cruzamento entre
oralidade, devoção e arqueologia simbólica, propondo leitura de continuidade entre mito e fé
popular.
Fontes complementares:
– Arquivo Distrital de Bragança, Códices Paroquiais da Póvoa e do Naso, sécs. XVIII–XIX;
– Museu da Terra de Miranda, Cadernos de Etnografia Transmontana (1934–1960);
– Tese de Doutoramento de Helena Cordeiro, A Montanha e o Milagre: Espaços Femininos da
Devoção  Popular em Trás-os-Montes  (U. Lisboa, 2018).
⸻
5. Síntese interpretativa final
A Lenda da Senhora do Picão  é expressão da espiritualidade popular transmontana — uma fé
de montanha, nascida da relação direta entre mulher, pedra e luz. O episódio traduz a
persistência do sagrado feminino, transmutado em iconogra fia cristã.
Na leitura da Associação  MILK, o Picão é o “monte do limiar”: ali, o invisível torna-se visível, e o
humano comunica com o divino sem mediações institucionais. O mito valoriza o corpo feminino
como instrumento de revelação, desa fiando as hierarquias religiosas.
Na escultura MILK concebida por Eduardo Mauer, a Senhora do Picão é representada em
posição ereta, com cabeça grande e expressão suave, envolta por véu translúcido de resina
branca e dourada. A base, em forma de pedra triangular, evoca o monte. A luz interna da peça
muda gradualmente de cor, simbolizando o momento da aparição.
⸻
6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer
Na leitura não binária de Eduardo Mauer, a Senhora do Picão representa a integração  dos
polos feminino e solar, dissolvendo as fronteiras entre maternidade e luminosidade, carne e
espírito.
Mauer observa: “A Senhora não é mãe nem virgem — é a encarnação da luz andrógina, energia
pura que transcende o corpo. O Picão é o ponto onde o género se dissolve na claridade.”
A leitura contemporânea da Associação  MILK insere o mito na pedagogia do Folclore Vivo como
exercício de reconciliação  simbólica entre o feminino ancestral e o pós-binário
contemporâneo . A figura de Mariana é vista como a primeira intérprete dessa fusão — uma
mulher que escuta a montanha e devolve voz ao sagrado não hierarquizado.
⸻
7. Referência Estrutural da Matriz MILK

Na Matriz Escultórica MILK, a representação da Senhora do Picão segue proporções clássicas:
cabeça grande, corpo compacto, véu translúcido e pedestal triangular. As cores predominantes
são branco, dourado e azul-celeste.
A instalação inclui iluminação interna com pulsação luminosa suave, representando o momento
da aparição, e som ambiente de vento e canto.
⸻
Localização  específica: Póvoa, concelho de Miranda do Douro, Trás-os-Montes e Alto Douro.
Primeiro relato documentado: Joaquim Alves Ferreira, Literatura de Trás-os-Montes  e Alto
Douro – Lendas e Contos Infantis, vol. V, 1956.
Sistematização  contemporânea:  Eduardo Mauer, A Senhora do Picão:  Montanha, Luz e
Feminino no Imaginário  Mirandês , Associação MILK, 2024.
Fontes primárias:  Braga (1883); Vasconcelos (1915); Ferreira (1956); Cordeiro (2018); Mauer
(2024).
