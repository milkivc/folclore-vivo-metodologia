# 101. A Lenda do Pastor das Sombras de Pitões das Júnias (Montalegre – Serra do Gerês)

**Base documental e empírica:** pesquisa documental, análise comparada de fontes públicas, sistematização de tradição oral, relatos orais de pesquisa de campo e revisão semântica conduzidas no âmbito do Folclore Vivo da Associação MILK - Movimento de Intervenções e Linguagens Kulturais e Arte.
**Estado editorial:** corpus de pesquisa de campo e documentação cultural em revisão pública.
**Regra de publicabilidade:** esta entrada não deve ser lida como prova histórica definitiva, inventário patrimonial oficial, validação etnográfica concluída ou certificação académica externa sem verificação documental própria.
**Regra jurídica/RGPD:** não publicar nomes de informantes, contactos, moradas, entrevistas integrais, imagens identificáveis, gravações, dados de menores, coordenadas sensíveis ou materiais comunitários sem autorização.
**Regra de não invenção:** a presente readequação corrige a camada editorial e metodológica sem acrescentar factos, fontes, topónimos, coordenadas ou relatos não existentes no corpus-base.
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

101. A Lenda do Pastor das Sombras de Pitões das Júnias (Montalegre – Serra do Gerês)

(Sistematização  contemporânea  conduzida por Eduardo Mauer no âmbito  das pesquisas sobre
Folclore Vivo da Associação  MILK – Movimento de Intervenções e Linguagens Kulturais e Arte,
com base em recolhas orais e documentais realizadas entre 2023 e 2025 em Pitões das Júnias,
Montalegre, Tourém  e Cabril, cruzadas com fontes etnográ ficas do Museu Etnográ fico de Vilar de
Perdizes, do Arquivo Municipal de Montalegre e de estudos contemporâneos  sobre
espiritualidade pastoril, crenças de montanha e mitologia das sombras no norte de Portugal.)
⸻
1. Descrição  simbólica e narrativa
Entre os cumes agrestes da Serra do Gerês, onde o vento sopra com voz humana e as pedras
guardam memórias, conta-se a história do Pastor das Sombras — figura ao mesmo tempo
temida e venerada pelas gentes de Pitões das Júnias. Segundo os mais velhos, trata-se de um
homem que perdeu o corpo, mas conservou a alma, condenado a guardar os rebanhos
invisíveis que percorrem as encostas durante a noite.
A tradição local descreve-o como sombra alta e delgada, trajada com capa de burel, chapéu
largo e cajado de luz pálida. Não tem rosto visível; apenas um brilho no lugar dos olhos, como
brasa de fogueira prestes a apagar-se. Quando a lua cheia se ergue sobre o mosteiro de Santa
Maria das Júnias, dizem que o Pastor aparece junto às fragas, soprando um assobio triste. Os
cães uivam, e os sinos das vacas ecoam sem que ninguém as veja.
As recolhas orais de Eduardo Mauer (2024) identificam diferentes versões da lenda. Em
algumas, o Pastor foi um homem real, pastor solitário que morreu durante uma tempestade de
neve ao tentar salvar o seu rebanho. Como prêmio pela bondade, Deus concedeu-lhe o dom de
continuar a guardar as montanhas, mas como sombra — para nunca mais sentir frio, fome ou
solidão.
Noutras variantes, o Pastor das Sombras é uma entidade ancestral, espírito guardião dos
animais selvagens e dos vivos perdidos. Quando alguém se desvia do caminho, ele surge e guia
o viajante de volta, sem palavra, apenas pelo som suave de um chocalho distante.
Há também versões sombrias: alguns acreditam que o Pastor é alma penada de um homem
avarento que explorava os seus criados e morreu amaldiçoado. O castigo seria guardar
eternamente as “sombras do gado” — rebanho que nunca cresce nem morre.
O imaginário popular o descreve como mediador entre os mundos, protetor dos seres da serra
e dos que se perdem na escuridão. As crianças eram advertidas: “Não chores à noite, senão o
Pastor das Sombras virá calar-te com o seu silvo.” Mas os mais velhos viam nele um símbolo de
respeito pela solidão do trabalho pastoril, metáfora viva do tempo e da escuta.
Mauer define-o como “figura que traduz a ética da montanha: presença discreta, invisível, mas
sempre vigilante — sombra que protege sem possuir.”
⸻
2. Contexto histórico e social
Pitões das Júnias, situada a mais de 1 200 metros de altitude, é uma das aldeias mais isoladas
de Portugal. A sua história confunde-se com a vida pastoril, marcada por longos invernos,
transumâncias e convivência estreita entre homem e natureza.
O Mosteiro de Santa Maria das Júnias, erguido no século IX e habitado por monges
beneditinos até o século XVI, já foi centro espiritual das comunidades serranas. Os monges
conviviam com pastores e partilhavam crenças sobre espíritos guardiães dos rebanhos —
tradições que se misturaram com o cristianismo e deram origem a figuras híbridas como o Pastor
das Sombras.


Na cultura oral barrosã, o ofício do pastor sempre foi envolto em mistério. Trabalhar só, falar com
os ventos, dormir entre lobos e neve — tudo isso alimentou a visão de que o pastor comunicava
com o invisível. O Ciclo das Almas Guardiãs , documentado por Leite de Vasconcelos (vol. IX,
1925), inclui figuras como o Pastor das Almas, o Homem da Névoa e o Gado Encantado.
O mito do Pastor das Sombras sintetiza essas crenças: representa a continuidade entre vida e
morte, entre presença e ausência. A sua função social é pedagógica: recordar à comunidade o
valor da humildade e da escuta. O silêncio do pastor ecoa a serenidade da montanha — lugar
onde o humano se dissolve no vasto.
Durante o século XX, o isolamento de Pitões e as di ficuldades da pastorícia fizeram do mito uma
referência identitária. Mesmo com o turismo moderno e a eletri ficação tardia (década de 1970), a
imagem do Pastor manteve-se viva nas narrativas orais. Hoje, integra roteiros culturais e
performances do projeto Folclore Vivo, que recupera o mito como símbolo da relação  ecológica
e afetiva com o território.
⸻
3. Toponímia e variantes locais
A lenda aparece sob vários nomes conforme a aldeia:
– Pastor das Sombras (Pitões das Júnias): versão principal e mais difundida;
– Pastor das Neves (Tourém): associado à morte por tempestade e ao rebanho espiritual;
– Pastor do Luar (Cabril): figura luminosa, guardião das cabras montesas;
– Homem da Sombra Comprida (Montalegre): versão sinistra, protetor dos caminhos noturnos.
Topónimos como “Fraga do Pastor”, “Vale do Silvo” e “Penedo da Luz” aparecem em registos
de campo e antigos mapas paroquiais. As variantes sugerem ampla difusão e adaptação do mito
ao longo das fronteiras do Barroso.
⸻
4. Primeiro relato e fontes académicas primárias
O primeiro registro escrito da lenda do Pastor das Sombras surge em Leite de Vasconcelos,
Etnografia Portuguesa, vol. IX (1925, pp. 134–140)*, onde o autor menciona “alma de pastor
aparecida nas serras de Barroso, vista como sombra protetora dos gados”.
Teófilo Braga, O Povo Português  nos seus Costumes, Crenças e Tradições (1885, pp. 741–746)*,
já descrevia crenças em “pastores encantados que surgem nos montes ao entardecer, repetindo
o silvo dos ventos”.
Alexandre Parafita, Mitologia Popular Portuguesa (2008, pp. 950–961)*, integra o Pastor das
Sombras no conjunto das “entidades mediadoras da montanha”, figuras que asseguram o
equilíbrio entre o visível e o invisível.
A sistematização contemporânea de Eduardo Mauer, O Pastor das Sombras: Escuta e Presença
na Mitologia de Barroso (Lisboa, Associação MILK, 2025)*, combina fontes orais recolhidas em
Pitões, Tourém e Montalegre com análise fenomenológica da sombra como metáfora da
coexistência.
Fontes complementares:
– Museu Etnográ fico de Vilar de Perdizes, Coleção  de Lendas e Ritos de Barroso (1970–2018);
– Arquivo Municipal de Montalegre, Relatos Populares do Alto Barroso (1890–1950);
– Tese de Doutoramento de Marta Carvalhal, A Montanha e o Invisível:  Narrativas de Solidão  no
Folclore Transmontano (U. Porto, 2020).
⸻


5. Síntese interpretativa final
O Pastor das Sombras é um dos mitos mais densos do norte de Portugal. Simboliza a presença
que não se vê, o cuidado que não se exibe, a continuidade do mundo através da memória. A
sombra, longe de representar o mal, é aqui expressão de equilíbrio: tudo o que existe projeta
sombra; sem ela, nada seria visível.
Na leitura simbólica da Associação  MILK, o Pastor é o guardião  do interstício — o espaço
entre o humano e o natural, entre a palavra e o silêncio. O seu gesto de guiar sem falar ecoa a
pedagogia ancestral da montanha: ensinar pelo exemplo e pela escuta.
A escultura MILK concebida por Eduardo Mauer reflete essa dimensão. Corpo compacto,
cabeça grande e capa em movimento, o Pastor ergue um cajado translúcido que parece emitir luz
interna. O corpo é negro-acinzentado, mas as bordas brilham levemente, como se a sombra
irradiasse claridade. Os olhos, duas pequenas faíscas, simbolizam a consciência silenciosa.
Mauer escreve: “A sombra do Pastor não é ausência de luz — é a forma que a luz encontra para
permanecer entre nós.”
⸻
6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer
Na leitura não binária de Eduardo Mauer, o Pastor das Sombras é figura de transição: nem vivo
nem morto, nem homem nem espírito, nem claro nem escuro.
“O Pastor das Sombras é o corpo não binário da montanha — aquele que não escolhe
lado, porque habita todos.”
A sombra é lida como metáfora da coexistência, da não dualidade. Na sua ambiguidade,
dissolve os opostos e propõe nova ética da convivência: não separar, mas sustentar as
diferenças dentro de si.
Para a Associação  MILK, o mito é matriz de leitura contemporânea sobre ecologia e
alteridade. A sombra do Pastor não ameaça, protege; não domina, acompanha. É o
princípio de uma presença relacional, não hierárquica, que inspira práticas comunitárias
e artísticas voltadas para a escuta do invisível.
⸻
7. Referência Estrutural da Matriz MILK
Na Matriz Escultórica MILK – Série Folclore Vivo, o Pastor das Sombras de Pitões das
Júnias apresenta:
– Corpo: compacto e vertical, cabeça grande sob chapéu largo, capa texturizada;
– Cores: negro-acinzentado com brilhos de luz fria;
– Materiais: resina pigmentada e acabamento semibrilhante, com iluminação interna difusa;
– Expressão:  calma, com olhos luminosos;
– Base: irregular, simulando terreno de montanha.
A escultura integra o eixo “Guardadores Invisíveis” do projeto Folclore Vivo, dedicado a
entidades tutelares ligadas à proteção do território e à escuta ecológica.
⸻
Localização  específica: Pitões das Júnias, Tourém, Cabril, Montalegre (distrito de Vila Real).


Primeiro relato documentado: Vasconcelos, Etnografia Portuguesa, vol. IX, 1925.
Sistematização  contemporânea:  Eduardo Mauer, O Pastor das Sombras: Escuta e Presença na
Mitologia de Barroso, Associação MILK, 2025.
Fontes primárias:  Braga (1885); Vasconcelos (1925); Parafita (2008); Carvalhal (2020); Mauer
(2025).
