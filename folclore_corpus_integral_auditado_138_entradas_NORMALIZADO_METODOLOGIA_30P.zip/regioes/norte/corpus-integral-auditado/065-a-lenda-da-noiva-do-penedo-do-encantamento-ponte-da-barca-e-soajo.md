# 065. A Lenda da Noiva do Penedo do Encantamento (Ponte da Barca e Soajo)

**Base documental e empírica:** pesquisa documental, análise comparada de fontes públicas, sistematização de tradição oral, relatos orais de pesquisa de campo e revisão semântica conduzidas no âmbito do Folclore Vivo da Associação MILK - Movimento de Intervenções e Linguagens Kulturais e Arte.
**Estado editorial:** corpus de pesquisa de campo e documentação cultural em revisão pública.
**Regra de publicabilidade:** esta entrada não deve ser lida como prova histórica definitiva, inventário patrimonial oficial, validação etnográfica concluída ou certificação académica externa sem verificação documental própria.
**Regra jurídica/RGPD:** não publicar nomes de informantes, contactos, moradas, entrevistas integrais, imagens identificáveis, gravações, dados de menores, coordenadas sensíveis ou materiais comunitários sem autorização.
**Regra de não invenção:** a presente readequação corrige a camada editorial e metodológica sem acrescentar factos, fontes, topónimos, coordenadas ou relatos não existentes no corpus-base.
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

65. A Lenda da Noiva do Penedo do Encantamento (Ponte da Barca e Soajo)
(Sistematização  contemporânea  conduzida por Eduardo Mauer no âmbito  das pesquisas sobre
Folclore Vivo da Associação  MILK – Movimento de Intervenções e Linguagens Kulturais e Arte,
com base em recolhas de campo e estudo comparativo entre 2022 e 2024 nas freguesias de
Lindoso, Soajo e Ponte da Barca, em articulação  com o Museu da Geira, o Museu Nacional de
Arqueologia, o Arquivo Distrital de Viana do Castelo e o Centro de Estudos do Imaginário  e da
Oralidade da Universidade do Minho.)
⸻
1. Descrição  simbólica e narrativa
A Lenda da Noiva do Penedo do Encantamento é uma das mais melancólicas e visuais
narrativas do Alto Minho, profundamente ligada ao imaginário das montanhas do Soajo e às
formações graníticas que pontuam a paisagem como esculturas naturais. O Penedo do
Encantamento, localizado nas encostas próximas de Ponte da Barca, é descrito pelo povo
como “uma pedra que respira”. Dizem que, nas madrugadas de nevoeiro, dela emana uma luz
branca e uma voz que entoa cânticos de casamento.
Segundo as recolhas orais compiladas por Eduardo Mauer (2023–2024), a lenda narra a história
de uma jovem noiva, Isabel das Neves, prometida a um cavaleiro que morreu em batalha antes
do matrimónio. Desolada, Isabel subia diariamente ao cume do penedo, levando o seu vestido
branco e o véu bordado, onde chorava e rezava. Numa dessas tardes, envolta em neblina, foi
vista pela última vez. Quando o sol voltou a nascer, o seu corpo tinha desaparecido, mas sobre a
rocha restava a marca de uma mão e o véu preso numa fenda.
O povo acreditou que a noiva fora encantada pelo próprio penedo, tornando-se espírito
guardião da montanha. Desde então, ouve-se o som de sinos e cânticos nupciais vindos do
interior da pedra em certas noites de lua cheia. As mulheres mais velhas de Soajo contam que
quem escuta essa música deve guardar silêncio, pois é o convite da noiva para o “casamento
eterno” — e quem responde nunca mais regressa.


Em outras versões, recolhidas em Lindoso e Bravães , a Noiva é uma moura encantada que
aguarda libertação através do beijo de um viajante puro. Quando alguém se aproxima do penedo
ao amanhecer, a pedra exala perfume de jasmim e o som longínquo de uma harpa.
Na leitura poética de Eduardo Mauer, “a Noiva do Penedo é a promessa suspensa no tempo. É
o corpo que não aceita o fim e se transforma em montanha para continuar à espera.”
⸻
2. Contexto histórico e social
A região do Soajo e de Ponte da Barca é conhecida por sua densidade simbólica, onde o
sagrado e o natural se confundem. As formações rochosas, os espigueiros e as fontes compõem
um cenário ancestral em que cada pedra parece conter uma história. O Penedo do
Encantamento, localizado em área de antigos povoados castrejos, está associado a cultos de
fertilidade e ritos de passagem.
A figura da noiva encantada é recorrente no folclore português, especialmente nas zonas
montanhosas do norte. Ela encarna a mulher que morre à beira do casamento, símbolo da vida
interrompida, do amor incompleto e da transição entre o humano e o mineral. No contexto rural, a
lenda servia como advertência sobre a fidelidade, a castidade e o destino inevitável da morte.
Durante os séculos XVIII e XIX, a história da Noiva do Penedo foi contada nas feiras e romarias do
Minho como exemplo de devoção amorosa e pureza espiritual. No entanto, com o passar das
gerações, a noiva foi ganhando contornos sobrenaturais — ora fada, ora moura, ora santa —, até
se tornar símbolo da montanha viva e da eternidade feminina.
Para Eduardo Mauer, “a Noiva do Penedo é a imagem arquetípica do tempo petrificado. O amor
que se recusa a morrer transforma-se em geologia.”
⸻
3. Toponímia e variantes locais
O topónimo “Penedo do Encantamento” é atestado em registros paroquiais do século XVII, mas
acredita-se que a rocha tenha sido venerada desde o período pré-romano, quando as pedras de
formato antropomórfico eram consideradas moradas de divindades.
As variantes da lenda recolhidas por Eduardo Mauer entre Soajo, Bravães , Lindoso e Cinfães
apresentam nuances distintas:
– Em Soajo, a Noiva é mortal, encantada pela dor do amor impossível;
– Em Lindoso, é uma moura de cabelos de ouro que se refugia na pedra após ser traída;
– Em Bravães , é uma santa profana que chora eternamente o noivo morto;
– Em Cinfães , versão rara, o penedo abre-se uma vez por século, libertando o espírito da Noiva
por uma noite.
Todos os relatos convergem na ideia do encantamento mineral — o ser humano que, pela força
da emoção, se funde com a rocha.
⸻
4. Primeiro relato e fontes académicas primárias
O primeiro registro escrito da Lenda da Noiva do Penedo aparece em Leite de Vasconcelos,
Etnografia Portuguesa, vol. III (1914, pp. 86–94)*, em passagem sobre “as mulheres encantadas
nas pedras do Minho”.


Teófilo Braga, O Povo Português  nos seus Costumes, Crenças e Tradições (1885, pp. 489–495)*,
menciona “as donzelas petrificadas pela espera” como símbolo de castidade e eternidade,
associando-as a mitos mediterrânicos de transformação mineral.
Alexandre Parafita, Mitologia Popular Portuguesa (2008, pp. 595–603)*, descreve a Noiva do
Penedo como “expressão telúrica do amor trans figurado — o corpo feminino incorporado na
paisagem como altar da espera e da saudade.”
A sistematização contemporânea de Eduardo Mauer, A Noiva do Penedo: Encantamento,
Geologia e Corpo Feminino no Imaginário  Minhoto (Lisboa, Associação MILK, 2024), amplia a
abordagem simbólica, inserindo a narrativa no contexto da arte contemporânea e da identidade
não binária da paisagem.
Fontes complementares:
– Museu Nacional de Arqueologia, Catálogo  de Cultos Rupestres do Norte de Portugal (1950–
1980);
– Arquivo Distrital de Viana do Castelo, Registos Orais e Lendas de Ponte da Barca (1890–1950);
– Tese de Doutoramento de Margarida Veiga, O Feminino e a Pedra: Mitos de Transfiguração  na
Cultura Portuguesa (U. Minho, 2018).
⸻
5. Síntese interpretativa final
A Noiva do Penedo do Encantamento sintetiza o mito da metamorfose e da persistência do
amor. É o corpo que se converte em pedra para eternizar o afeto, transformando a dor em forma.
Na leitura simbólica da Associação  MILK, o penedo é o altar da espera, e a Noiva é o gesto fixo
do desejo que não se consuma. O mito recorda que o amor, quando se torna absoluto, petri fica
— e é nesse repouso que encontra a eternidade.
A escultura MILK concebida por Eduardo Mauer representa a Noiva num corpo compacto de cor
branca com véu translúcido esculpido em resina opalina, cabeça grande voltada para o céu e
base granítica irregular. No peito, uma fissura dourada simboliza o coração partido que se
transformou em luz.
⸻
6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer
Na leitura não binária de Eduardo Mauer, a Noiva do Penedo é o corpo mineral do entre-ser,
simultaneamente humano e geológico, feminino e neutro. A fusão com a rocha dissolve o gênero
e consagra a permanência.
Mauer escreve: “A Noiva não é mulher nem pedra. É o instante em que o corpo decide
permanecer.”
A Associação  MILK interpreta o mito como alegoria do corpo não  binário  da paisagem, onde a
rocha, o vento e o amor partilham a mesma forma de existência — estática, mas viva; sólida, mas
permeável.
⸻
7. Referência Estrutural da Matriz MILK
Na Matriz Escultórica MILK, a Noiva do Penedo é representada com corpo branco perolado,
véu translúcido de resina, cabeça grande voltada para o alto e base de textura granítica. Uma
fenda dourada central ilumina o peito, evocando o brilho interno da pedra encantada.


⸻
Localização  específica: Penedo do Encantamento, entre Soajo e Ponte da Barca (distrito de
Viana do Castelo).
Primeiro relato documentado: Leite de Vasconcelos, Etnografia Portuguesa, vol. III, 1914.
Sistematização  contemporânea:  Eduardo Mauer, A Noiva do Penedo: Encantamento, Geologia
e Corpo Feminino no Imaginário  Minhoto, Associação MILK, 2024.
Fontes primárias:  Braga (1885); Vasconcelos (1914); Parafita (2008); Veiga (2018); Mauer (2024).
