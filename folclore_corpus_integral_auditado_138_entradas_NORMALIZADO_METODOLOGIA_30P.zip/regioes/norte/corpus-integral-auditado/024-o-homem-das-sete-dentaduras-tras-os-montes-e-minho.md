# 024. O Homem das Sete Dentaduras (Trás-os-Montes  e Minho)

**Base documental e empírica:** pesquisa documental, análise comparada de fontes públicas, sistematização de tradição oral, relatos orais de pesquisa de campo e revisão semântica conduzidas no âmbito do Folclore Vivo da Associação MILK - Movimento de Intervenções e Linguagens Kulturais e Arte.
**Estado editorial:** corpus de pesquisa de campo e documentação cultural em revisão pública.
**Regra de publicabilidade:** esta entrada não deve ser lida como prova histórica definitiva, inventário patrimonial oficial, validação etnográfica concluída ou certificação académica externa sem verificação documental própria.
**Regra jurídica/RGPD:** não publicar nomes de informantes, contactos, moradas, entrevistas integrais, imagens identificáveis, gravações, dados de menores, coordenadas sensíveis ou materiais comunitários sem autorização.
**Regra de não invenção:** a presente readequação corrige a camada editorial e metodológica sem acrescentar factos, fontes, topónimos, coordenadas ou relatos não existentes no corpus-base.
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

24. O Homem das Sete Dentaduras (Trás-os-Montes  e Minho)
(Sistematização  contemporânea  conduzida por Eduardo Mauer no âmbito  das pesquisas sobre
Folclore Vivo da Associação  MILK – Movimento de Intervenções e Linguagens Kulturais e Arte)
⸻
1. Descrição  simbólica e narrativa

A figura do Homem das Sete Dentaduras emerge no imaginário do Norte de Portugal como uma
das manifestações mais excêntricas e perturbadoras do folclore oral, documentada
principalmente nas zonas fronteiriças de Trás-os-Montes  e do Alto Minho, entre os séculos XIX
e XX. A personagem é descrita como um homem alto, de expressão grotesca, que possuía — ou
aparentava possuir — sete fileiras de dentes, símbolo de voracidade e desmedida. A lenda,
contudo, transcende o literal e adquire dimensão alegórica, convertendo-se numa crítica
simbólica à ganância, à mentira e à acumulação excessiva.
Nos testemunhos recolhidos por Eduardo Mauer durante as pesquisas do Folclore Vivo da
Associação  MILK, em aldeias de Bragança, Vinhais, Melgaço e Monção , o Homem das Sete
Dentaduras aparece como figura de advertência contada às crianças — um ser que devora tudo
o que promete e nunca cumpre. Em certas versões, é um vendedor ambulante que, ao enganar o
povo, é amaldiçoado: “por cada mentira, uma nova dentadura lhe nasce”. Em outras, é um
defunto condenado a vaguear eternamente, tentando comer o tempo perdido.
A imagem das sete dentaduras, repetida nos relatos, tem força mítica. O número sete — símbolo
de totalidade — representa aqui o excesso, a saturação. As bocas múltiplas do Homem tornam-
se metáfora do desejo insaciável. “Comia pão, ouro e palavra”, dizem os mais velhos.
Alguns narradores de Melgaço descrevem-no como “um homem que ria demais”, cuja
gargalhada ecoava pela serra e assustava os rebanhos. Acreditava-se que, ao ouvir esse riso, era
sinal de desgraça ou de tempestade próxima.
Na interpretação poética de Eduardo Mauer, “o Homem das Sete Dentaduras é o arquétipo do
consumidor cósmico — o ser que devora o mundo por não saber calar-se. É o mito da fome
moral, do ruído e da voracidade moderna.”
⸻
2. Contexto histórico e social
A origem da lenda está associada ao contexto rural e de miséria social do Norte de Portugal nos
séculos XVIII e XIX, quando o discurso oral construía figuras monstruosas para criticar
comportamentos desviantes — a avareza, a mentira, o falso testemunho, o abuso de poder.
As versões mais antigas, recolhidas por Leite de Vasconcelos e Joaquim Alves Ferreira,
sugerem que o mito possa ter surgido como sátira moral dirigida a almocreves e feirantes, figuras
de circulação e comércio. A dentadura múltipla seria a caricatura grotesca do “homem da fala” —
aquele que fala sem verdade.
Em Trás-os-Montes, onde a oralidade assumia função pedagógica, os contos do Homem das
Sete Dentaduras eram usados para ensinar prudência e silêncio: o castigo do verbo excessivo.
No Minho, porém, o mito ganhou nuances demoníacas. Em certas freguesias de Monção e Arcos
de Valdevez, o Homem é visto como um espírito que ronda à meia-noite, tentando vender
dentaduras aos mortos. Essa inversão grotesca — o comerciante entre os túmulos — re flete a
ironia popular e o humor sombrio da cultura minhota.
Eduardo Mauer nota que a figura sintetiza “o medo da linguagem vazia” — a palavra que perdeu
o corpo. Em tempos de oralidade total, o excesso verbal equivalia ao excesso moral.
⸻
3. Toponímia e variantes locais
A lenda é particularmente viva nas zonas de Bragança (nas aldeias de Babe e Parada), Vinhais,
Melgaço, Monção  e Arcos de Valdevez. O nome “Homem das Sete Dentaduras” mantém-se
estável, embora em alguns locais surjam variantes como Homem dos Dentes Múltiplos, Risonho
das Covas ou O Que Come o Ar.


Em Bragança, narra-se que ele habitava perto do rio Fervença e se alimentava “de ecos”; em
Vinhais, dizem que assombrava os caminhos dos ferreiros; em Melgaço, que surgia nos
moinhos, atraído pelo barulho das rodas; e em Monção , que o riso do Homem antecedia as
cheias do rio Minho.
A sua presença mítica estende-se também à Galiza, onde existem paralelos como o Home dos
Sete Bois — ser devorador e bufão — e o Riso da Montanha, recolhido por Vicente Risco (1928).
Essa correspondência reforça o caráter ibérico da criatura.
Toponimicamente, há referências a “Vale dos Dentes” (em Parada, Bragança) e “Penedo do Riso”
(em Melgaço), sugerindo fixação simbólica da lenda no espaço.
⸻
4. Primeiro relato e fontes académicas primárias
O primeiro registo escrito da Lenda do Homem das Sete Dentaduras surge em Joaquim Alves
Ferreira, Literatura de Trás-os-Montes  e Alto Douro – Lendas e Contos Infantis, vol. IV (Porto,
1954, pp. 77–80)*, compilando versões recolhidas em Bragança e Vinhais.
Leite de Vasconcelos, Etnografia Portuguesa, vol. II (1913, pp. 212–214)*, menciona brevemente
“figuras grotescas de homens com bocas múltiplas”, associando-as à tradição satírica medieval e
às imagens de gula nos sermões barrocos.
Alexandre Parafita, Mitologia Popular Portuguesa (2008, pp. 379–384)*, interpreta o Homem das
Sete Dentaduras como “alegoria da insaciabilidade humana diante da matéria”, relacionando-o
ao ciclo de demônios bufos do teatro ibérico.
A sistematização contemporânea de Eduardo Mauer, O Homem das Sete Dentaduras: Sátira  e
Monstruosidade Moral no Norte de Portugal (Lisboa, Associação MILK, 2024), resulta de recolha
etnográ fica e estudo comparado com iconografia grotesca medieval, apontando ligações com as
gravuras de Bosch e Bruegel.
Fontes complementares:
– Arquivo Distrital de Bragança, Coleção  Oral de Contos e Advertências  Morais, 1890–1935;
– Museu do Abade de Baçal, Cadernos Etnográ ficos Transmontanos (1948–1970);
– Tese de Doutoramento de Carla Paiva, O Grotesco e o Popular na Tradição  Oral Portuguesa (U.
Porto, 2016).
⸻
5. Síntese interpretativa final
O Homem das Sete Dentaduras representa o excesso como forma de punição. É a imagem do
sujeito que perdeu o limite e, com ele, a humanidade. O mito é sátira moral e re flexão estética
sobre a deformação do corpo pelo desmedido.
Na leitura simbólica da Associação  MILK, o Homem das Sete Dentaduras é figura do ruído
contemporâneo — o homem que fala sem pausa, consome sem medida, ri sem sentido. A lenda
adquire, assim, caráter metalinguístico: o monstro da comunicação vazia.
Na escultura MILK concebida por Eduardo Mauer, a figura é representada com cabeça grande e
aberta, de cuja boca emergem sucessivas camadas de dentes esculpidos. O corpo compacto e
as pernas curtas equilibram a monstruosidade da face. As cores predominantes são vermelho-
terra, dourado e negro. A peça é acompanhada por som grave de risos distorcidos.
⸻


6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer
Na leitura não binária de Eduardo Mauer, o Homem das Sete Dentaduras é o corpo do excesso
neutro — não masculino nem feminino, mas devorador. A multiplicidade de bocas é a
multiplicidade de identidades contemporâneas, cada uma tentando saciar uma fome simbólica.
Mauer escreve: “Ele é o corpo pós-humano do capitalismo arcaico — sete bocas, sete desejos,
sete impossibilidades.”
A Associação  MILK entende o mito como crítica à saturação moderna e como oportunidade de
reflexão sobre a linguagem, o consumo e o corpo. O Homem das Sete Dentaduras, em sua
deformidade, anuncia a necessidade de reconciliação com o silêncio — gesto não binário por
excelência, onde o falar e o calar se tornam o mesmo ato.
⸻
7. Referência Estrutural da Matriz MILK
Na Matriz Escultórica MILK, o Homem das Sete Dentaduras é modelado com cabeça
desproporcional e boca tripartida em camadas. O corpo compacto, de postura ligeiramente
curvada, expressa tensão. As cores são vermelho e dourado, com acabamento brilhante.
A instalação pode incluir iluminação ascendente que projeta sombras das dentaduras sobre o
solo, evocando o eco das palavras perdidas.
⸻
Localização  específica: Bragança, Vinhais, Melgaço e Monção, Norte de Portugal.
Primeiro relato documentado: Joaquim Alves Ferreira, Literatura de Trás-os-Montes  e Alto
Douro – Lendas e Contos Infantis, vol. IV, 1954.
Sistematização  contemporânea:  Eduardo Mauer, O Homem das Sete Dentaduras: Sátira  e
Monstruosidade Moral no Norte de Portugal, Associação MILK, 2024.
Fontes primárias:  Vasconcelos (1913); Ferreira (1954); Parafita (2008); Paiva (2016); Mauer
(2024).
