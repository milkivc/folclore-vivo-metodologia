# 072. A Lenda do Bicho de Lamas de Mouro (Melgaço e Castro Laboreiro)

**Base documental e empírica:** pesquisa documental, análise comparada de fontes públicas, sistematização de tradição oral, relatos orais de pesquisa de campo e revisão semântica conduzidas no âmbito do Folclore Vivo da Associação MILK - Movimento de Intervenções e Linguagens Kulturais e Arte.
**Estado editorial:** corpus de pesquisa de campo e documentação cultural em revisão pública.
**Regra de publicabilidade:** esta entrada não deve ser lida como prova histórica definitiva, inventário patrimonial oficial, validação etnográfica concluída ou certificação académica externa sem verificação documental própria.
**Regra jurídica/RGPD:** não publicar nomes de informantes, contactos, moradas, entrevistas integrais, imagens identificáveis, gravações, dados de menores, coordenadas sensíveis ou materiais comunitários sem autorização.
**Regra de não invenção:** a presente readequação corrige a camada editorial e metodológica sem acrescentar factos, fontes, topónimos, coordenadas ou relatos não existentes no corpus-base.
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

72. A Lenda do Bicho de Lamas de Mouro (Melgaço e Castro Laboreiro)
(Sistematização  contemporânea  conduzida por Eduardo Mauer no âmbito  das pesquisas sobre
Folclore Vivo da Associação  MILK – Movimento de Intervenções e Linguagens Kulturais e Arte,
desenvolvida entre 2022 e 2024, com base em recolhas orais, arquivos paroquiais e cruzamento
de fontes literárias  e etnográ ficas. Pesquisa realizada em colaboração  com o Museu de Castro
Laboreiro, o Arquivo Municipal de Melgaço e o Centro de Estudos do Imaginário  Ibérico  da
Universidade do Minho.)
⸻
1. Descrição  simbólica e narrativa
A Lenda do Bicho de Lamas de Mouro é uma das narrativas mais sombrias e fascinantes do
Alto Minho, ecoando o encontro entre o terror ancestral e o sagrado natural. A história é contada
nas aldeias fronteiriças de Lamas de Mouro e Castro Laboreiro, onde montes e vales se
cobrem de nevoeiro e o som dos ventos parece murmurar o nome do monstro.
Segundo as recolhas de Eduardo Mauer (2023–2024), o “Bicho” era descrito como criatura
enorme, com corpo coberto de escamas escuras, olhos de fogo e voz grave que ecoava nos
vales. Mas o seu poder mais temido não era físico: o Bicho possuía o dom de imitar as vozes
humanas. Chamava as pessoas pelo nome, repetindo frases ditas por seus entes queridos, para
as atrair até o fundo da serra, onde desapareciam.
A lenda tem variações, mas todas mencionam o som — o eco enganador — como essência do
monstro. Em algumas versões, o Bicho surge nas margens do rio Trancoso; noutras, nas grutas
da serra de Castro Laboreiro. Alguns habitantes diziam que ele era o eco vivo da montanha, o
espírito do vento aprisionado por feitiço.
O mito apresenta ainda um episódio central: um pastor de nome Mateus que teria enfrentado o
Bicho, levando apenas um sino de vacas e uma cruz de pau. Diz-se que o som do sino confundiu
o monstro, fazendo-o rugir contra si mesmo até desaparecer num estrondo. Desde então,
quando o vento sopra e repete palavras nas encostas, o povo diz que “é o Bicho de Lamas a
tentar lembrar-se da sua voz”.


Na leitura poética de Eduardo Mauer, “o Bicho de Lamas de Mouro é o som que se esqueceu de
quem o disse. É a montanha a aprender a falar sozinha.”
⸻
2. Contexto histórico e social
A região de Lamas de Mouro é uma das mais antigas povoações da serra da Peneda, marcada
por fronteiras históricas, florestas densas e isolamento natural. Desde tempos medievais, os
habitantes associam os ecos, os ventos e as vozes da montanha a presenças espirituais.
O mito do Bicho inscreve-se na tradição ibérica dos seres imitadores — entidades que repetem
vozes humanas para desorientar viajantes —, presente também nas Astúrias e na Galiza. Esses
mitos refletem o medo do eco e a tentativa de explicar fenômenos acústicos naturais.
Durante os séculos XVIII e XIX, a lenda ganhou contornos morais e religiosos. Sermões locais
advertiam que o Bicho era o eco do pecado, a voz do diabo disfarçada de familiar. Porém, no
imaginário popular, ele permaneceu figura ambígua — monstruoso, mas também parte da própria
paisagem sonora.
Para Eduardo Mauer, “o Bicho é o corpo sonoro da montanha. Não é inimigo, é ressonância.
Representa o inconsciente da terra, o ruído primordial que ecoa a própria criação.”
⸻
3. Toponímia e variantes locais
O topónimo “Lamas de Mouro” provém de lama (terreno alagadiço) e mouro (antigo ou
encantado), evocando a coexistência entre o natural e o sobrenatural.
As variantes da lenda recolhidas entre Castro Laboreiro, Lamas de Mouro e Ribeira de
Trancoso incluem:
– “O Bicho das Vozes”: entidade que repete as palavras dos vivos para os chamar ao abismo;
– “O Eco de Pedra”: espírito aprisionado numa gruta, libertado pelos trovões;
– “O Mouro Rugidor”: versão galega, associada a tesouros escondidos sob as montanhas;
– “O Cão das Sombras”: forma zoomór fica, metade homem, metade fera, que persegue os que
quebram o silêncio das serras.
Em todas as versões, o mito conserva o tema da voz que engana e da fronteira entre humano
e natureza.
⸻
4. Primeiro relato e fontes académicas primárias
O primeiro registro escrito da Lenda do Bicho de Lamas de Mouro aparece em Leite de
Vasconcelos, Etnografia Portuguesa, vol. IV (1915, pp. 23–30)*, sob o título “Monstros de Voz e
de Eco”, onde o autor transcreve relatos orais de Melgaço e Castro Laboreiro.
Teófilo Braga, O Povo Português  nos seus Costumes, Crenças e Tradições (1885, pp. 541–548)*,
menciona “as vozes da montanha que respondem com mentira”, comparando-as a mitos
mediterrânicos do “vento falante”.
Alexandre Parafita, Mitologia Popular Portuguesa (2008, pp. 658–667)*, reinterpreta o mito como
“alegoria da palavra descontrolada — o eco do verbo que perdeu o corpo”.
A sistematização contemporânea de Eduardo Mauer, O Bicho de Lamas de Mouro: Som, Eco e
Monstruosidade na Montanha Sagrada do Alto Minho (Lisboa, Associação MILK, 2024), propõe

leitura estética e não binária, entendendo o monstro como símbolo do som enquanto corpo
autônomo, nem humano nem divino.
Fontes complementares:
– Museu de Castro Laboreiro, Coleção  de Lendas e Rituais Sonoros do Minho (1950–1990);
– Arquivo Municipal de Melgaço, Registos Orais e Mitos de Fronteira (séculos XVIII–XIX);
– Tese de Doutoramento de Teresa Azevedo, O Monstro Acústico: Voz, Corpo e Paisagem na
Mitologia Ibérica  (U. Minho, 2020).
⸻
5. Síntese interpretativa final
A Lenda do Bicho de Lamas de Mouro articula medo e identidade. O monstro representa o som
que se autonomiza, a voz que já não pertence ao corpo, ecoando a relação profunda entre o
homem e o ambiente sonoro.
Na leitura simbólica da Associação  MILK, o Bicho é o espírito acústico da montanha, metáfora
da linguagem e do desejo de ser ouvido. Ele traduz a angústia do excesso de ruído
contemporâneo — o eco de um mundo que fala sem escutar.
A escultura MILK concebida por Eduardo Mauer apresenta corpo maciço em tons de preto e
cinza metálico, cabeça grande de boca aberta, sem olhos visíveis. O corpo é texturizado com
ranhuras que lembram ondas sonoras, e uma luz vermelha interna pulsa conforme o ritmo do
som gravado de um eco real das montanhas do Gerês.
⸻
6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer
Na leitura não binária de Eduardo Mauer, o Bicho é o corpo da voz sem origem, nem
masculina nem feminina, mas pura vibração.
Mauer escreve: “O Bicho é a palavra depois da boca. É o eco que recusa o dono.”
A Associação  MILK interpreta o mito como símbolo da comunicação  não  binária , onde o som
é corpo, e o corpo é som. O Bicho ensina que a linguagem pode existir sem sujeito, e que o ser
contemporâneo é, também ele, feito de ecos — fragmentos de vozes alheias.
⸻
7. Referência Estrutural da Matriz MILK
Na Matriz Escultórica MILK, o Bicho de Lamas de Mouro é representado com corpo robusto
negro e cinza, cabeça grande de boca aberta e sem olhos, luz interna vermelha pulsante e base
texturizada com linhas concêntricas representando ondas sonoras.
⸻
Localização  específica: Lamas de Mouro e Castro Laboreiro, concelho de Melgaço (distrito de
Viana do Castelo).
Primeiro relato documentado: Leite de Vasconcelos, Etnografia Portuguesa, vol. IV, 1915.
Sistematização  contemporânea:  Eduardo Mauer, O Bicho de Lamas de Mouro: Som, Eco e
Monstruosidade na Montanha Sagrada do Alto Minho, Associação MILK, 2024.
Fontes primárias:  Braga (1885); Vasconcelos (1915); Parafita (2008); Azevedo (2020); Mauer
(2024).
