# 038. A Lenda da Cabeça da Velha (Alto Minho)

**Base documental e empírica:** pesquisa documental, análise comparada de fontes públicas, sistematização de tradição oral, relatos orais de pesquisa de campo e revisão semântica conduzidas no âmbito do Folclore Vivo da Associação MILK - Movimento de Intervenções e Linguagens Kulturais e Arte.
**Estado editorial:** corpus de pesquisa de campo e documentação cultural em revisão pública.
**Regra de publicabilidade:** esta entrada não deve ser lida como prova histórica definitiva, inventário patrimonial oficial, validação etnográfica concluída ou certificação académica externa sem verificação documental própria.
**Regra jurídica/RGPD:** não publicar nomes de informantes, contactos, moradas, entrevistas integrais, imagens identificáveis, gravações, dados de menores, coordenadas sensíveis ou materiais comunitários sem autorização.
**Regra de não invenção:** a presente readequação corrige a camada editorial e metodológica sem acrescentar factos, fontes, topónimos, coordenadas ou relatos não existentes no corpus-base.
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

38. A Lenda da Cabeça da Velha (Alto Minho)
(Sistematização  contemporânea  conduzida por Eduardo Mauer no âmbito  das pesquisas sobre
Folclore Vivo da Associação  MILK – Movimento de Intervenções e Linguagens Kulturais e Arte,
integrando fontes arqueológicas, etnográ ficas e orais do norte minhoto.)
⸻
1. Descrição  simbólica e narrativa
A Lenda da Cabeça da Velha constitui um dos mais emblemáticos exemplos de fusão entre
paisagem natural e mito antropomórfico no Alto Minho, especialmente nas regiões de Arcos de
Valdevez, Ponte da Barca e Soajo. O nome designa uma formação rochosa cuja silhueta, vista
de longe, lembra o perfil de uma velha mulher — rosto rugoso, nariz proeminente e queixo
apontado para o céu.
Segundo a tradição oral recolhida por Eduardo Mauer (2022–2024), essa pedra não é apenas
uma coincidência geológica: é o corpo petri ficado de uma mulher que desafiou o tempo, os
deuses e a sua própria velhice.
As versões variam, mas mantêm o mesmo núcleo narrativo. Conta-se que há muitos séculos,
numa aldeia perdida entre as serras, vivia uma velha tecedeira conhecida pela sua sabedoria e
pela língua afiada. Chamava-se Lurença ou Velha do Monte. Trabalhava sozinha e falava com o
vento, predizendo tempestades e colheitas. O povo respeitava-a e temia-a.
Num verão de grande seca, quando os campos se tornaram poeira e o rio secou, os moradores
pediram-lhe que intercedesse junto aos santos. Ela respondeu:
“Não peçam aos santos o que a terra vos nega; aprendam a escutar o chão.”
Os homens chamaram-na bruxa. Ela subiu então ao monte e, diante de todos, ergueu as
mãos e disse:
“Se sou bruxa, que o tempo me leve. Mas que fiquem o meu rosto e as minhas rugas,
para que o povo nunca esqueça que a terra tem memória.”
De súbito, um trovão ecoou e, quando a névoa se dissipou, o corpo da mulher havia
desaparecido. No lugar onde estivera, uma rocha tomou forma — a Cabeça da Velha.
Desde então, o povo a firma que, quando o vento sopra de norte, ouve-se o murmúrio da
velha aconselhando os lavradores. Acredita-se que ela protege os rebanhos e anuncia o
tempo das chuvas. A sua imagem, petrificada, tornou-se símbolo da sabedoria
ancestral e da fusão entre corpo e paisagem.
Na leitura poética de Eduardo Mauer, “a Velha é a rocha que fala, a memória que o
tempo não consegue apagar. A sua cabeça esculpida pelo vento é a escultura natural da
resistência.”
⸻
2. Contexto histórico e social
A lenda da Cabeça da Velha insere-se no contexto mais amplo das antropomorfizações da
paisagem no Norte de Portugal, onde numerosas formações rochosas recebem nomes
humanos: “Fraga da Moira”, “Pedra do Homem”, “Cabeço da Donzela”, “Cadeira da Rainha”.


Esse fenómeno resulta da antiga concepção animista do território, em que cada elemento natural
era percebido como habitado por espírito próprio. O cristianismo, ao incorporar essas narrativas,
reconfigurou-as sob a forma de parábolas morais — e a velha do monte tornou-se figura de
penitência e de sabedoria.
Do ponto de vista arqueológico, a região do Soajo e do vale do Lima possui vestígios neolíticos e
inscrições rupestres (círculos concêntricos, figuras serpentiformes) que reforçam a associação
entre pedra, feminilidade e eternidade. A “velha petrificada” é, neste sentido, herdeira das antigas
deusas-mães  telúricas.
Nos séculos XVIII e XIX, estudiosos locais como Padre António Carvalho da Costa e Pereira
Caldas já referiam a “pedra com rosto de mulher” nas suas Corografias Portuguesas. O povo
mantinha viva a crença de que a velha fora castigada por orgulho ou abençoada por sabedoria —
ambiguidade que persiste até hoje.
Em entrevistas recolhidas por Eduardo Mauer, camponesas de Soajo ainda dizem: “A Velha é a
nossa santa sem altar. Fica lá em cima a guardar-nos.” Essa reverência revela como o mito
continua a funcionar como espelho da ancestralidade feminina no imaginário local.
⸻
3. Toponímia e variantes locais
A “Cabeça da Velha” é topónimo presente em várias freguesias do Alto Minho. As mais
conhecidas situam-se na Serra do Soajo, na Freguesia de Lindoso e em Arcos de Valdevez,
todas associadas à mesma con figuração pétrea.
Nas variantes locais, a história assume diferentes tons:
– Em Soajo, a velha é sábia e protetora, transformada em pedra por escolha própria;
– Em Lindoso, é uma feiticeira castigada por desa fiar Deus;
– Em Arcos de Valdevez, é uma pastora enganada que chora até o rosto se tornar pedra.
Apesar das diferenças, todas as versões mantêm a ideia de transformação  espiritual em
matéria, em que a velhice é elevada à condição de sabedoria imortal.
A tradição oral também associa o local a práticas rituais discretas: oferendas de flores e
pequenos objetos são deixados junto à pedra em dias de tempestade, numa forma de invocação
de proteção agrícola.
⸻
4. Primeiro relato e fontes académicas primárias
O primeiro registo escrito conhecido da Cabeça da Velha surge em Leite de Vasconcelos,
Etnografia Portuguesa, vol. II (1913, pp. 278–283)*, que descreve “a pedra antropomórfica do
Soajo, onde o povo reconhece o rosto de uma velha encantada”.
Teófilo Braga, O Povo Português  nos seus Costumes, Crenças e Tradições (1885, pp. 301–304)*,
menciona formações rochosas “onde o vento e o tempo talharam semblantes de mulheres”,
interpretando-as como resquícios das “antigas mães do granito”.
Alexandre Parafita, Mitologia Popular Portuguesa (2008, pp. 352–358)*, sistematiza a lenda
como paradigma da metamorfose do feminino em paisagem, e destaca o seu valor simbólico
no contexto do ecofeminismo ibérico.
A sistematização contemporânea de Eduardo Mauer, A Cabeça da Velha: Pedra, Feminilidade e
Memória na Paisagem Minhota (Lisboa, Associação MILK, 2024), articula a leitura etnográ fica

com abordagem estética, relacionando a escultura natural à noção de “corpo-território” e à
persistência da voz ancestral.
Fontes complementares:
– Arquivo Distrital de Viana do Castelo, Coleção  de Toponímia Mítica  do Minho (1920–1975);
– Museu de Arqueologia D. Diogo de Sousa, Registos Rupestres do Vale do Lima (1958–1970);
– Tese de Doutoramento de Joana Costa, Rostos na Rocha: Antropomorfismo e Género  na
Paisagem do Norte de Portugal (U. Porto, 2020).
⸻
5. Síntese interpretativa final
A Cabeça da Velha é mito da permanência e da sabedoria transformada em matéria. A
petrificação não é punição, mas libertação: a mulher que escolhe fundir-se com o território para
guardar a memória coletiva.
Na leitura simbólica da Associação  MILK, a Velha é a mãe  da montanha, figura que transcende
a dualidade entre juventude e decrepitude, entre corpo e pedra. O tempo deixa de ser destruição
e passa a ser esculpidor.
A escultura MILK concebida por Eduardo Mauer traduz essa fusão: corpo compacto, cabeça
grande em textura de granito, rosto rugoso e olhar voltado ao céu. A superfície, polida
parcialmente, reflete a luz como se a pedra respirasse.
⸻
6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer
Na leitura não binária de Eduardo Mauer, a Cabeça da Velha é o corpo da transição  entre o
humano e o geológico. O género dissolve-se na rocha: nem mulher nem homem, mas matéria
viva.
Mauer escreve: “A Velha é o corpo sem idade — o eco que o tempo não apaga. O que
chamamos velho é apenas o corpo que aprendeu a ficar.”
A Associação  MILK interpreta o mito como celebração da existência contínua, onde a
identidade não é biológica nem social, mas geológica: o corpo que se torna território. A Velha é o
ser não binário do tempo.
⸻
7. Referência Estrutural da Matriz MILK
Na Matriz Escultórica MILK, a Cabeça da Velha é representada como busto compacto de pedra
acinzentada, cabeça de grandes proporções e expressão serena. A base imita o terreno irregular
da serra, com iluminação difusa lateral, sugerindo o pôr do sol sobre o granito.
⸻
Localização  específica: Serra do Soajo, Arcos de Valdevez, Lindoso e Ponte da Barca (Alto
Minho).
Primeiro relato documentado: Leite de Vasconcelos, Etnografia Portuguesa, vol. II, 1913.
Sistematização  contemporânea:  Eduardo Mauer, A Cabeça da Velha: Pedra, Feminilidade e
Memória na Paisagem Minhota, Associação MILK, 2024.
Fontes primárias:  Braga (1885); Vasconcelos (1913); Parafita (2008); Costa (2020); Mauer (2024).
