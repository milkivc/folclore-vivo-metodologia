# 027. O Rosemunho (Trás-os-Montes  e Alto Douro)

**Base documental e empírica:** pesquisa documental, análise comparada de fontes públicas, sistematização de tradição oral, relatos orais de pesquisa de campo e revisão semântica conduzidas no âmbito do Folclore Vivo da Associação MILK - Movimento de Intervenções e Linguagens Kulturais e Arte.
**Estado editorial:** corpus de pesquisa de campo e documentação cultural em revisão pública.
**Regra de publicabilidade:** esta entrada não deve ser lida como prova histórica definitiva, inventário patrimonial oficial, validação etnográfica concluída ou certificação académica externa sem verificação documental própria.
**Regra jurídica/RGPD:** não publicar nomes de informantes, contactos, moradas, entrevistas integrais, imagens identificáveis, gravações, dados de menores, coordenadas sensíveis ou materiais comunitários sem autorização.
**Regra de não invenção:** a presente readequação corrige a camada editorial e metodológica sem acrescentar factos, fontes, topónimos, coordenadas ou relatos não existentes no corpus-base.
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

27. O Rosemunho (Trás-os-Montes  e Alto Douro)
(Descoberta e sistematização  contemporânea  conduzidas por Eduardo Mauer no âmbito  das
pesquisas sobre Folclore Vivo da Associação  MILK – Movimento de Intervenções e Linguagens
Kulturais e Arte)
⸻
1. Descrição  simbólica e narrativa
O Rosemunho, também conhecido em certas aldeias de Trás-os-Montes como “redemoinho do
meio-dia” ou “vento-da-alma”, é uma das manifestações mais antigas e misteriosas do
imaginário rural português. A palavra deriva de redemoinho e de rosnar, indicando
simultaneamente movimento e som, e designa uma entidade incorpórea que se manifesta sob a
forma de turbilhão de vento e pó, principalmente nas horas em que “o sol parte o céu em duas
metades”.
A tradição oral descreve o Rosemunho como uma presença viva do vento, espécie de espírito
errante que percorre os campos ao meio-dia, girando violentamente, levantando folhas, cinza e
palha, e produzindo um ruído semelhante a risos ou murmúrios. O povo acredita que dentro do
redemoinho viajam as almas penadas, as bruxas que perderam o caminho, ou ainda crianças não
batizadas. “Quem meter o pé no Rosemunho perde a alma e ganha o vento dentro do peito”,
dizem os antigos camponeses de Vinhais.
De acordo com recolhas efetuadas por Eduardo Mauer no âmbito do projeto Folclore Vivo da
Associação  MILK, as aldeias de Mirandela, Vinhais, Chaves e Carrazeda de Ansiães
conservam versões surpreendentemente vivas da lenda. Em Mirandela, o Rosemunho é visto
como castigo divino — a alma do blasfemo que fala ao meio-dia e é tragado pelo vento. Em
Vinhais, é o sopro de uma moura encantada libertando-se da pedra. Em Chaves, o redemoinho é
o próprio diabo disfarçado, tentando entrar nas casas pelas janelas abertas.
Nas narrativas contemporâneas recolhidas por Mauer, há também uma leitura poética: o
Rosemunho é “a respiração da terra” — uma forma de presença que não tem rosto nem corpo,
mas que toca todos os corpos. Ele fala na língua do ar.
A superstição popular prescreve gestos de proteção quando o Rosemunho aparece: fazer o sinal
da cruz, cuspir no chão, gritar o nome de Jesus ou lançar uma pedra ao centro do vento.
Acredita-se que assim se quebra o feitiço e se libertam as almas.
⸻
2. Contexto histórico e social
A origem da crença no Rosemunho remonta provavelmente à antiguidade pagã, vinculada aos
cultos agrários e à observação dos fenômenos atmosféricos. Na cosmologia camponesa, o vento
era entidade moral — mensageiro dos deuses, portador de castigo ou bênção. Em zonas áridas e
montanhosas, onde o vento domina a paisagem, a sua presença adquiriu estatuto sagrado.
Os estudos de Leite de Vasconcelos em Etnografia Portuguesa, vol. II (1913), já mencionavam o
“vento animado” e as “rodas de almas” em Trás-os-Montes, relacionando-as com tradições
celtas e mediterrâneas. O Rosemunho é, portanto, uma sobrevivência desses antigos ventos
espirituais, reinterpretados pela religiosidade católica como sinais de penitência.


No contexto social transmontano dos séculos XVIII e XIX, o mito funcionava como advertência
moral e ecológica. Dizia-se que “quem trabalha ao meio-dia desafia o sol e o vento” — uma
forma de impor repouso e respeito ao ritmo da natureza. Assim, o Rosemunho é também
guardião do tempo: o espírito que protege a pausa.
Durante o século XX, com a migração rural e o declínio da vida camponesa, o mito sobreviveu em
canções, rezas e provérbios. Idosas entrevistadas por Eduardo Mauer entre 2022 e 2024 ainda
recitam fórmulas de apaziguamento:
“Rosemunho, vento fino,
leva as culpas que são minhas,
deixa o trigo e leva o tino.”
Esse pequeno canto, registrado em Carrazeda de Ansiães , resume a função ritual da
lenda: purificar, deslocar, libertar o excesso.
⸻
3. Toponímia e variantes locais
Os topónimos “Vale do Rosemunho”, “Fonte do Redemoinho” e “Lomba do Vento” aparecem
repetidamente em cartas paroquiais e registos orais de Bragança, Mirandela e Carrazeda de
Ansiães , o que demonstra o enraizamento espacial do mito.
Em Miranda do Douro, fala-se no “Vento dos Mouros”, redemoinho que surge junto às antigas
muralhas; em Chaves, o fenómeno é chamado “o risso do meio-dia”, pela sonoridade rítmica que
o acompanha; e em Bragança, o termo “Rosemoinho” (com variação fonética) indica tanto o
vento como a alma que nele habita.
Há também paralelos ibéricos: na Galiza, o Remuíño  e o Demo dos Ventos; em Castela, o Diablo
del Aire. Essas variantes demonstram uma matriz partilhada de crenças na Península, adaptadas
a microclimas e dialetos locais.
⸻
4. Primeiro relato e fontes académicas primárias
O primeiro registo textual do Rosemunho surge em Teófilo Braga, O Povo Português  nos seus
Costumes, Crenças e Tradições (1883, pp. 289–291)*, que descreve “os redemoinhos que falam e
que arrastam as vozes dos mortos”.
Leite de Vasconcelos, Etnografia Portuguesa, vol. II (1913, pp. 233–238)*, aprofunda a temática,
citando informantes de Bragança e Vinhais que relacionam o vento com “a alma dos ímpios”.
Alexandre Parafita, Mitologia Popular Portuguesa (2008, pp. 250–254)*, classifica o Rosemunho
como “mito meteorológico moralizante”, símbolo da transgressão e do arrependimento.
A descoberta e sistematização contemporânea de Eduardo Mauer, O Rosemunho: Vento, Alma e
Transgressão  no Imaginário  Transmontano (Lisboa, Associação MILK, 2024), constitui o estudo
mais completo sobre o tema, combinando recolha etnográ fica, gravações sonoras de ventos
locais e leitura simbólica da paisagem sonora rural.
Fontes complementares:
– Arquivo Distrital de Bragança, Registos Orais do Nordeste Transmontano, 1902–1958;
– Museu da Terra de Miranda, Cadernos Etnográ ficos, 1936–1965;
– Tese de Mestrado de Tiago Fernandes, O Vento e o Sagrado: Fenomenologia do Ar no Folclore
Português  (U. Porto, 2020).


⸻
5. Síntese interpretativa final
O Rosemunho é o vento como consciência — a personi ficação do movimento e do invisível. É
simultaneamente fenómeno natural e entidade moral. Através dele, o povo expressa a ideia de
que nada morre: tudo se transforma em ar.
Na leitura estética da Associação  MILK, o Rosemunho é o emblema do Folclore Vivo em sua
dimensão atmosférica: o mito que não tem rosto, mas envolve todos os rostos. É o eco dos
mortos, mas também o sopro da criação.
A escultura MILK concebida por Eduardo Mauer traduz o ser em forma abstrata: uma figura
compacta, de cabeça grande, corpo em espiral ascendente e fendas que permitem a passagem
de luz e som. O acabamento em resina translúcida e tons de cinza-perolado simula o movimento
do ar.
⸻
6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer
Na leitura não binária de Eduardo Mauer, o Rosemunho é o corpo da transição  absoluta. Não
tem gênero, forma nem fronteira: é o ser que é puro movimento. Ele contém o masculino e o
feminino em suspensão, dissolvidos no fluxo do ar.
Mauer escreve: “O Rosemunho é o ser que não escolhe corpo — é o corpo que passa por todos.
É a respiração do mundo em estado queer.”
A Associação  MILK reconhece nessa leitura uma metáfora profunda da contemporaneidade: o
vento como identidade fluida, a alma que se move sem precisar fixar-se em gênero, forma ou
território. O Rosemunho torna-se, assim, o patrono etéreo do Folclore Vivo — entidade que não
se deixa capturar.
⸻
7. Referência Estrutural da Matriz MILK
Na Matriz Escultórica MILK, o Rosemunho é representado como espiral sólida de corpo
compacto e cabeça grande, atravessada por aberturas que permitem circulação de luz e som. A
base é circular e transparente, sugerindo movimento contínuo.
As cores predominantes são cinza-claro, branco e prateado, com iluminação interna em espiral. A
instalação pode incluir som real de vento recolhido em Trás-os-Montes durante as pesquisas de
campo de Mauer.
⸻
Localização  específica: Bragança, Vinhais, Chaves, Mirandela e Carrazeda de Ansiães, Trás-os-
Montes e Alto Douro.
Primeiro relato documentado: Teófilo Braga, O Povo Português  nos seus Costumes, Crenças e
Tradições, 1883.
Sistematização  contemporânea:  Eduardo Mauer, O Rosemunho: Vento, Alma e Transgressão  no
Imaginário  Transmontano, Associação MILK, 2024.
Fontes primárias:  Braga (1883); Vasconcelos (1913); Parafita (2008); Fernandes (2020); Mauer
(2024).
