# 088. A Lenda do Espelho do Sol das Pedras (Valença e Monção  – Alto Minho)

**Base documental e empírica:** pesquisa documental, análise comparada de fontes públicas, sistematização de tradição oral, relatos orais de pesquisa de campo e revisão semântica conduzidas no âmbito do Folclore Vivo da Associação MILK - Movimento de Intervenções e Linguagens Kulturais e Arte.
**Estado editorial:** corpus de pesquisa de campo e documentação cultural em revisão pública.
**Regra de publicabilidade:** esta entrada não deve ser lida como prova histórica definitiva, inventário patrimonial oficial, validação etnográfica concluída ou certificação académica externa sem verificação documental própria.
**Regra jurídica/RGPD:** não publicar nomes de informantes, contactos, moradas, entrevistas integrais, imagens identificáveis, gravações, dados de menores, coordenadas sensíveis ou materiais comunitários sem autorização.
**Regra de não invenção:** a presente readequação corrige a camada editorial e metodológica sem acrescentar factos, fontes, topónimos, coordenadas ou relatos não existentes no corpus-base.
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

88. A Lenda do Espelho do Sol das Pedras (Valença e Monção  – Alto Minho)
(Sistematização  contemporânea  conduzida por Eduardo Mauer no âmbito  das pesquisas sobre
Folclore Vivo da Associação  MILK – Movimento de Intervenções e Linguagens Kulturais e Arte,
com base em recolhas orais e documentais realizadas entre 2023 e 2025 nas freguesias de
Friestas, Verdoejo, Troporiz e Lapela, cruzadas com fontes etnográ ficas do Museu de Valença,
Arquivo Municipal de Monção  e estudos sobre simbolismo solar e imaginário  pétreo  do norte
português.)
⸻
1. Descrição  simbólica e narrativa
A Lenda do Espelho do Sol das Pedras é uma das mais luminosas e antigas narrativas do Alto
Minho. Conta-se que, nas margens do rio Minho, entre Valença e Monção, existe uma pedra lisa e
oval, conhecida entre os moradores como o “Espelho do Sol”. Segundo a tradição, quem se
debruça sobre ela ao amanhecer e vê o reflexo do sol sem sombra alguma tem o coração
limpo de mágoas .
A pedra encontra-se parcialmente submersa em determinadas épocas do ano, emergindo apenas
quando o rio desce. É dita encantada: quem a toca em silêncio escuta dentro de si o som de
um coração  batendo em ritmo de luz.
Os relatos orais recolhidos por Eduardo Mauer (2024) descrevem-na como uma superfície de
granito dourado que “brilha mesmo sem sol”, e afirmam que o reflexo nela visto não é apenas
imagem, mas presença. “O sol das pedras é vivo”, dizem os anciãos, “e devolve ao mundo a
alma de quem o contempla.”
Numa das versões, o Espelho teria sido criado por uma moura guardiã do rio, que colheu os
raios do sol e os prendeu dentro da rocha para que a claridade nunca faltasse ao Minho.
Noutros relatos, é o próprio rio que esculpiu a pedra com a sua corrente, criando nela um olho
luminoso — o olhar do sol sobre a água.
Em versões modernas, o mito adquire caráter filosófico: o Espelho do Sol é a metáfora  da
verdade interior, o lugar onde o ser se reencontra consigo mesmo através do re flexo natural.
Mauer sintetiza poeticamente: “O Espelho do Sol é o coração mineral do dia — o instante em que
a matéria devolve ao humano a luz que o habita.”
⸻
2. Contexto histórico e social
A região de Valença e Monção , fronteira natural entre Portugal e Galiza, é marcada por ritos
solares e práticas simbólicas associadas à luz, ao re flexo e à água. Desde a Antiguidade, as
populações locais realizavam cerimónias de solstício junto aos rios e pedras polidas, onde
acreditavam residirem forças bené ficas.


Durante o período romano, foram erguidos na região vários santuários  dedicados ao Sol
Invicto; vestígios dessas práticas persistiram nos topónimos “Pedras de Fogo” e “Monte da
Luminária”. O cristianismo assimilou parte desses rituais, convertendo a adoração do sol em
culto ao “Cristo-Luz”, e a pedra passou a ser símbolo da revelação divina.
Nos séculos XVIII e XIX, a lenda do Espelho do Sol das Pedras era contada como história de
reconciliação : quem cometesse injustiça ou guardasse rancor devia tocar na pedra ao nascer do
sol e “deixar que a luz lavasse o peso”. Era comum ver mulheres levando flores ou bacias de
água para “oferecer ao sol” nos primeiros dias de verão.
Durante o século XX, a lenda assumiu dimensão identitária. Para os moradores da fronteira, o
Espelho do Sol tornou-se símbolo de união  entre Portugal e Galiza, pois “o reflexo da pedra é
o mesmo visto de ambas as margens”.
As recolhas da Associação  MILK confirmam a permanência do mito em narrativas locais,
transmitidas por famílias ribeirinhas, onde o Espelho é tratado como ser vivo, que respira e
dorme.
⸻
3. Toponímia e variantes locais
O termo “Espelho do Sol das Pedras” varia entre freguesias:
– “Pedra do Sol” (Verdoejo): bloco polido junto ao rio, considerado altar natural;
– “Olho do Dia” (Troporiz): formação rochosa circular que re flete o nascer do sol em linha direta
com o Minho;
– “Pedra Cega” (Lapela): pedra que só brilha a quem não guarda ódio;
– “Pedra Luminosa” (Friestas): superfície onde o sol se reflete com mais força após
tempestades.
A própria palavra “espelho” tem, no dialeto local, sentido de revelação espiritual — “ver-se ao
espelho” significa reconhecer-se na natureza. A expressão “sol das pedras” refere-se ao brilho do
granito húmido ao amanhecer, mas também à luz interior de cada pessoa.
O local mais associado à lenda situa-se entre Friestas e Troporiz, onde existe ainda hoje uma
laje de granito inclinada sobre o rio, usada em rituais de solstício por grupos locais e visitantes
curiosos.
⸻
4. Primeiro relato e fontes académicas primárias
O primeiro registro escrito da lenda surge em Leite de Vasconcelos, Etnografia Portuguesa, vol.
VII (1920, pp. 263–268)*, que descreve “pedra junto ao Minho onde o sol se espelha e os devotos
buscam pureza de alma”.
Teófilo Braga, O Povo Português  nos seus Costumes, Crenças e Tradições (1885, pp. 657–662)*,
menciona “o culto solar das pedras claras do Minho, onde as mulheres rezam ao sol nascente
por clareza e saúde”.
Alexandre Parafita, Mitologia Popular Portuguesa (2008, pp. 830–838)*, interpreta o Espelho do
Sol como “figura sincrética entre divindade solar e consciência telúrica”, vinculando-o a rituais de
purificação e esperança.
A sistematização contemporânea de Eduardo Mauer, O Espelho do Sol das Pedras: Luz, Reflexo
e Matéria  no Imaginário  do Alto Minho (Lisboa, Associação MILK, 2025)*, associa o mito à
fenomenologia do reflexo e à arte da contemplação, propondo leitura estética e ecológica.


Fontes complementares:
– Arquivo Municipal de Monção, Lendas da Fronteira e do Minho (1902–1948);
– Museu de Valença, Coleção  de Tradições de Pedra e Água  (1985–2017);
– Tese de Doutoramento de Beatriz Coutinho, Sol, Pedra e Água:  Cosmologia Popular no Norte
Ibérico  (U. Minho, 2021).
⸻
5. Síntese interpretativa final
O Espelho do Sol das Pedras é o mito da clareza interior. A pedra representa a permanência, o
sol simboliza a consciência, e o re flexo é o encontro entre ambos. O seu poder não é mágico,
mas simbólico: lembra ao ser humano que a luz está  na matéria, e a verdade, no olhar que a
reconhece.
Na leitura simbólica da Associação  MILK, esta lenda manifesta o princípio da reciprocidade
luminosa — a natureza devolve ao humano a luz que recebe. O Espelho é o corpo do dia em
repouso: sólido e silencioso, mas capaz de gerar claridade.
A escultura MILK criada por Eduardo Mauer interpreta esse equilíbrio com forma compacta,
corpo de pedra polida e cabeça grande inclinada sobre uma base oval. No dorso, um círculo
dourado translúcido reflete a luz ambiente, recriando o efeito solar. A superfície, tratada com
verniz acetinado, capta e difunde o brilho, simbolizando a passagem entre sol e sombra.
Mauer escreve: “O Espelho do Sol é o rosto da pedra quando ela se lembra de ser luz.”
⸻
6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer
Na leitura não binária de Eduardo Mauer, o Espelho do Sol das Pedras é o lugar da
reversibilidade — aquilo que re flete sem separar.
“O Espelho não divide o sol da pedra, nem o humano da paisagem. Ele é o intervalo
luminoso onde tudo se reconhece sem se distinguir.”
Aqui, o mito transcende o binário luz/sombra, masculino/feminino, visível/invisível. O
reflexo torna-se símbolo do ser relacional, cuja identidade é construída pela
reciprocidade.
A Associação  MILK compreende o Espelho como figura fundadora de uma estética não
binária  da claridade, em que o brilho é gesto de encontro e não de oposição. Ele
encarna a filosofia do Folclore Vivo, onde o ser se reconhece na matéria e o sagrado se
manifesta no ato de ver.
⸻
7. Referência Estrutural da Matriz MILK
Na Matriz Escultórica MILK – Série Folclore Vivo, o Espelho do Sol das Pedras é
representado de forma minimalista e contemplativa:
– Corpo: compacto, de contornos arredondados e postura levemente inclinada;
– Cores: dourado-claro, cinza-pedra e reflexos prateados;
– Materiais: resina translúcida com pó de granito e verniz acetinado;
– Expressão:  neutra e serena, olhos semicerrados, semblante voltado para o chão;
– Base: oval e polida, simulando a pedra refletora.


A escultura simboliza o diálogo  entre opacidade e transparência, eixo essencial das
investigações escultóricas e simbólicas de Mauer na série Folclore Vivo.
⸻
Localização  específica: Friestas, Verdoejo, Troporiz e Lapela (distritos de Viana do Castelo).
Primeiro relato documentado: Vasconcelos, Etnografia Portuguesa, vol. VII, 1920.
Sistematização  contemporânea:  Eduardo Mauer, O Espelho do Sol das Pedras: Luz, Reflexo e
Matéria  no Imaginário  do Alto Minho, Associação MILK, 2025.
Fontes primárias:  Braga (1885); Vasconcelos (1920); Parafita (2008); Coutinho (2021); Mauer
(2025).
