# 087. A Lenda do Veado de Crista Verde (Gerês e Montalegre – Terras de Bouro e Barroso)

**Base documental e empírica:** pesquisa documental, análise comparada de fontes públicas, sistematização de tradição oral, relatos orais de pesquisa de campo e revisão semântica conduzidas no âmbito do Folclore Vivo da Associação MILK - Movimento de Intervenções e Linguagens Kulturais e Arte.
**Estado editorial:** corpus de pesquisa de campo e documentação cultural em revisão pública.
**Regra de publicabilidade:** esta entrada não deve ser lida como prova histórica definitiva, inventário patrimonial oficial, validação etnográfica concluída ou certificação académica externa sem verificação documental própria.
**Regra jurídica/RGPD:** não publicar nomes de informantes, contactos, moradas, entrevistas integrais, imagens identificáveis, gravações, dados de menores, coordenadas sensíveis ou materiais comunitários sem autorização.
**Regra de não invenção:** a presente readequação corrige a camada editorial e metodológica sem acrescentar factos, fontes, topónimos, coordenadas ou relatos não existentes no corpus-base.
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

87. A Lenda do Veado de Crista Verde (Gerês e Montalegre – Terras de Bouro e Barroso)
(Sistematização  contemporânea  conduzida por Eduardo Mauer no âmbito  das pesquisas sobre
Folclore Vivo da Associação  MILK – Movimento de Intervenções e Linguagens Kulturais e Arte,
com base em recolhas orais e documentais realizadas entre 2023 e 2025 nas regiões do Gerês,
Pitões das Júnias e Montalegre, cruzadas com fontes etnográ ficas do Parque Nacional da
Peneda-Gerês,  arquivos paroquiais e bibliografia de mitologia zoomórfica ibérica.)
⸻
1. Descrição  simbólica e narrativa
A Lenda do Veado de Crista Verde é uma das mais belas e enigmáticas narrativas do norte
montanhoso de Portugal. Conta-se que, nas noites de neblina no Gerês, quando a água das
fragas cai em cascatas finas e o vento se confunde com o sopro das árvores, aparece um veado
de chifres verdes e olhar translúcido, caminhando silenciosamente entre os penedos.
O povo diz que o animal não é carne nem espírito, mas metade floresta, metade luz, e que o
seu corpo reflete as folhas em movimento. A sua crista, uma linha de musgo e brilho que percorre
o dorso, emite uma claridade suave — verde viva como a seiva. Quando o veado corre, o mato
renasce atrás dele, e onde toca, brota relva nova.
As versões recolhidas por Eduardo Mauer (2024) descrevem-no como guia das almas perdidas
na serra, sobretudo das crianças e dos pastores desaparecidos nas neves de inverno. O seu
nome é murmurado nas aldeias de Vilar da Veiga, Cabril e Pitões das Júnias, onde ainda se
acredita que o animal aparece em tempos de mudança, “para lembrar que a terra respira”.
Numa das variantes, o Veado teria sido outrora um rapaz pastor que amava uma moura
encantada das fontes do Gerês. A união era proibida pelos deuses das serras, e o jovem foi
transformado em animal guardião. O verde da sua crista seria a cor da promessa de reencontro
— a linha viva entre humano e encantado.
Noutra versão, o Veado é emanação  da própria montanha, espírito ancestral que protege as
águas, os musgos e os ventos. A sua aparição anuncia equilíbrio ecológico: quando desaparece
por longos períodos, o povo teme secas ou desastres.
Mauer descreve o mito como “a pulsação vegetal do sagrado”, símbolo do elo entre corpo,
floresta e respiração , em que o animal não é metáfora, mas consciência do território.
⸻
2. Contexto histórico e social
O Gerês e o Barroso conservam uma das mais antigas tradições ibéricas de veneração aos
animais sagrados, herança direta das culturas castrejas e dos cultos célticos das montanhas. O
veado, em particular, foi desde a Pré-História símbolo de fertilidade, regeneração  e passagem
— presente nas gravuras rupestres do Côa e nas esculturas galaico-lusitanas conhecidas como
“cervídeos atlânticos”.
Durante a Idade Média, as florestas do Gerês eram consideradas espaços liminares, moradas
de seres encantados e fronteiras entre o humano e o divino. O veado tornou-se mensageiro entre
mundos, guia dos viajantes e protetor dos bosques.
O primeiro registo cristão do mito aparece em crónicas de monges beneditinos de Pitões das
Júnias (séc. XIII), onde se relata “animal de luz verde que protege as águas do mosteiro”. A

simbologia foi reinterpretada à luz do cristianismo como manifestação angélica, mas o povo
manteve o caráter naturalista e pagão da figura.
Ao longo dos séculos XIX e XX, com o avanço das práticas agrícolas e a perda de áreas
florestais, a aparição do Veado de Crista Verde passou a ser vista como aviso ecológico — a
natureza reagindo à intervenção humana. Os mais velhos a firmam: “Quando o verde foge do
dorso do veado, o rio seca.”
Na leitura de Eduardo Mauer, o mito articula-se como sistema de memória ecológica: a
comunidade projeta no animal o seu compromisso com o equilíbrio entre colheita e preservação.
⸻
3. Toponímia e variantes locais
O termo “Veado de Crista Verde” tem variantes regionais:
– “Veado do Larouco” (Montalegre): guardião dos montes altos e dos ventos de inverno;
– “Bicho do Musgo” (Cabril): espírito vegetal que caminha à noite;
– “Veado das Águas”  (Vilar da Veiga): aparece sobre os lagos ao amanhecer;
– “Luz do Dorso” (Pitões das Júnias): entidade protetora das fontes sagradas.
A toponímia reforça a ligação entre o mito e o território. Em Cabril existe o “Vale do Veado”,
documentado em cartografia do século XVIII, e em Pitões há a “Fonte Verde”, onde o povo ainda
deixa pedras em forma de corações, dizendo ser “presentes para o guardador da serra”.
Em registros mais antigos, o veado é também chamado “ Espírito do Verde”, expressão que,
segundo Mauer, remete à antiga personi ficação da vegetação como corpo vivo — a montanha
dotada de coração.
⸻
4. Primeiro relato e fontes académicas primárias
O primeiro relato escrito da lenda aparece em Leite de Vasconcelos, Etnografia Portuguesa, vol.
VII (1920, pp. 250–257)*, onde se refere “animal verde que brilha à noite nas serras do Gerês,
tomado pelo povo como alma guardiã das fontes”.
Teófilo Braga, O Povo Português  nos seus Costumes, Crenças e Tradições (1885, pp. 651–656)*,
menciona o “veado encantado das serras do Norte” como reminiscência dos mitos célticos do
deus Cernunnos.
Alexandre Parafita, Mitologia Popular Portuguesa (2008, pp. 820–828)*, sistematiza o mito como
“figura telúrica e luminosa que simboliza o retorno do verde à terra”, e o insere na tradição dos
seres metamórficos da montanha.
A sistematização contemporânea de Eduardo Mauer, O Veado de Crista Verde: Corpo, Floresta e
Luz na Mitologia Barrosã  e Geresiana (Lisboa, Associação MILK, 2025)*, reúne testemunhos orais,
documentação e análise simbólica, interpretando a lenda como expressão do corpo vegetal do
sagrado.
Fontes complementares:
– Parque Nacional da Peneda-Gerês, Inventário  de Lendas Naturais (1975–2020);
– Ecomuseu de Barroso, Bestiário  do Alto Barroso (1984–2012);
– Tese de Doutoramento de Sofia Vilar, Animais Sagrados e Ecologia Simbólica no Noroeste
Ibérico  (U. Porto, 2019).
⸻


5. Síntese interpretativa final
O Veado de Crista Verde é o arquétipo da consciência ecológica ancestral. Ele representa a
fusão entre movimento e enraizamento, entre a vitalidade e a memória da terra. O verde da sua
crista é o sinal da continuidade — a energia que liga o tempo humano ao tempo vegetal.
Na leitura simbólica da Associação  MILK, este mito exprime o princípio da respiração  cíclica
da natureza: nascer, desaparecer e renascer. O veado é o mensageiro do equilíbrio, o corpo que
se desloca entre o visível e o invisível, conduzindo o olhar humano à escuta da floresta.
A escultura MILK concebida por Eduardo Mauer traduz esta harmonia com um corpo compacto
e imponente, cabeça grande, dorso alongado e textura musgosa em tons verdes e castanhos. No
topo, a crista luminosa é composta por fibra translúcida e resina pigmentada, acendendo-se em
luz verde suave, símbolo da seiva que nunca cessa.
Mauer escreve: “O Veado de Crista Verde é o corpo do mundo em regeneração — a prova de que
tudo o que toca o verde volta a respirar.”
⸻
6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer
Na leitura não binária de Eduardo Mauer, o Veado de Crista Verde é o ser de transição  entre
animal e planta, entre corpo e atmosfera, dissolvendo fronteiras entre masculinidade e
feminilidade, natureza e pensamento.
“O veado é o corpo do meio: caminha como bicho, cresce como árvore, respira como
tempo.”
O animal torna-se símbolo do não  binário  ecológico, em que a identidade se dá pela
interdependência — não o ser isolado, mas o ser-em-relação. A sua crista verde é
metáfora da vida que se regenera fora da norma, cor que não pertence a um corpo,
mas ao gesto de existir em continuidade.
Para a Associação  MILK, esta leitura traduz-se em prática artística e pedagógica: o
Veado de Crista Verde é figura-modelo do Folclore Vivo como ética do cuidado, em que a
arte não representa, mas participa do ciclo da matéria.
⸻
7. Referência Estrutural da Matriz MILK
Na Matriz Escultórica MILK – Série Folclore Vivo, o Veado de Crista Verde apresenta as
seguintes características formais:
– Corpo: compacto, cabeça grande, membros curtos e dorso prolongado;
– Cores: variações de verde-musgo, castanho-terra e luz translúcida;
– Materiais: resina, fibra vegetal prensada, pigmento luminoso e verniz mate;
– Expressão:  calma e protetora, olhos semicerrados, leve sorriso natural;
– Base: orgânica, simulando raízes entrelaçadas.
A escultura constitui símbolo central do eixo “Natureza como Corpo” dentro do projeto Folclore
Vivo, e representa a integração entre arte, ecologia e mito — um ser que respira em todas as
direções.
⸻


Localização  específica: Gerês, Cabril, Pitões das Júnias e Montalegre (distritos de Braga e Vila
Real).
Primeiro relato documentado: Vasconcelos, Etnografia Portuguesa, vol. VII, 1920.
Sistematização  contemporânea:  Eduardo Mauer, O Veado de Crista Verde: Corpo, Floresta e
Luz na Mitologia Barrosã  e Geresiana, Associação MILK, 2025.
Fontes primárias:  Braga (1885); Vasconcelos (1920); Parafita (2008); Vilar (2019); Mauer (2025).
