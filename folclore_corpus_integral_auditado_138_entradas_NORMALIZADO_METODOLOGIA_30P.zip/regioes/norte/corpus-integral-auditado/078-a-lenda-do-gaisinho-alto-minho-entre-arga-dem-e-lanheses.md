# 078. A Lenda do Gaisinho (Alto Minho – entre Arga, Dem e Lanheses)

**Base documental e empírica:** pesquisa documental, análise comparada de fontes públicas, sistematização de tradição oral, relatos orais de pesquisa de campo e revisão semântica conduzidas no âmbito do Folclore Vivo da Associação MILK - Movimento de Intervenções e Linguagens Kulturais e Arte.
**Estado editorial:** corpus de pesquisa de campo e documentação cultural em revisão pública.
**Regra de publicabilidade:** esta entrada não deve ser lida como prova histórica definitiva, inventário patrimonial oficial, validação etnográfica concluída ou certificação académica externa sem verificação documental própria.
**Regra jurídica/RGPD:** não publicar nomes de informantes, contactos, moradas, entrevistas integrais, imagens identificáveis, gravações, dados de menores, coordenadas sensíveis ou materiais comunitários sem autorização.
**Regra de não invenção:** a presente readequação corrige a camada editorial e metodológica sem acrescentar factos, fontes, topónimos, coordenadas ou relatos não existentes no corpus-base.
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

78. A Lenda do Gaisinho (Alto Minho – entre Arga, Dem e Lanheses)
(Sistematização  contemporânea  conduzida por Eduardo Mauer no âmbito  das pesquisas sobre
Folclore Vivo da Associação  MILK – Movimento de Intervenções e Linguagens Kulturais e Arte,
com base em recolhas orais dirigidas entre 2022 e 2025 nas freguesias da Serra d’Arga (Arga de
Baixo/Arga de Cima), Dem (Caminha), Lanheses (Viana do Castelo) e áreas  ribeirinhas do Lima;

cruzamento com arquivos paroquiais locais, cadernos de romaria e memórias manuscritas
familiares. Nota de método:  não  se encontrou, até  ao momento, referência  explícita  ao “Gaisinho”
nas compilações clássicas  impressas; a presente sistematização  assume a figura como micro-
lenda viva de circulação  local, documentada sobretudo por via oral e registos domésticos.)
⸻
1. Descrição  simbólica e narrativa
O Gaisinho é descrito, nos testemunhos recolhidos, como um pequeno génio da mata —
criatura de riso rápido e pés leves, que habita os carvalhais e castinçais húmidos do Alto Minho,
surgindo com maior frequência nos contrafortes da Serra d’Arga e ao longo das margens
sossegadas do rio Lima. O nome, em diminutivo familiar, sugere proximidade e doçura; o sufixo
“-inho” aponta a dimensão doméstica e afetiva com que é tratado, sobretudo por mulheres
idosas e guardadores de rebanho.
Na narrativa mais repetida, o Gaisinho veste um barrete de folhas castanhas, presas por uma
nervura de hera, e traz ao peito um fio de bolotas polidas. Os olhos são “como contas de vidro”,
ora azuis ora verdes, conforme o reflexo do musgo. A sua presença reconhece-se antes de se
ver: um trejeito de risada fina, que estala como pinhas ao sol e provoca riso involuntário  em
quem o escuta. Dizem que, quando o medo sobe da garganta — de noite, ao regressar pelo
caminho — o Gaisinho assobia uma melodia curta, depois ri, e o corpo da pessoa “desarma”,
acabando por sorrir também.
Em muitas versões, a criatura tem poder sobre o humor: aproxima-se de quem anda
ensimesmado, toca-lhe no cotovelo (com mão fria “de água de fonte”) e o rosto abre-se, sem
razão aparente, num sorriso limpo. Por isso, o Gaisinho é invocado como “alegrador” — não
tanto curandeiro, mas desanuviador —, o que “levanta o peso”. Há quem deixe pãezinhos  de
milho ou figos secos ao pé das capelas de caminho e nos marcos de divisão  (os “moirões”),
pedindo: “Gaisinho, leva o fardo de volta para o monte e deixa-me a boca leve”.
A criatura é benigna e travessa. Troca cabaças de água, esconde chaves e desvia linhas do
tear; porém, se se lhe pede com jeito — oferecendo um riso verdadeiro — ele devolve o que
tirou, muitas vezes acrescentando um pequeno achado: uma pena de gaio, um ouriço de
castanha perfeito, um seixo redondo “para lembrar que tudo se pode alisar com o tempo”. O
seu riso contagioso torna-o guardião de passagens difíceis: pontezinhas sobre regatos,
atalhos de sombra, corredores de giesta que o vento aperta. Quem sorri ao atravessá-los
“passa limpo”.
Algumas narrativas dão ao Gaisinho tino de guardador de crianças: se um miúdo se perde por
detrás dos espigueiros, ou se adormece ao crepúsculo, diz-se que o Gaisinho o entretém com
três jogos — o brilho do orvalho, a bolota que roda e a sombra que dança — até que alguém
chegue. Nesse intervalo a criança ri sem medo, como se brincasse com um amigo da sua altura.
Existe, porém, uma regra: não  pronunciar o nome três vezes seguidas. As informantes
explicam que a terceira chamada “aperta o coração do bicho” e o faz mudo “por quarenta dias”,
tempo durante o qual o riso escasseia no lugar. A etiqueta do encontro inclui também não
oferecer sal (ao Gaisinho “faz mal ao riso”) e não  o seguir quando corre em ziguezague: a graça
perde-se se a pressa manda.
A versão mais poética, recolhida junto a uma tecedeira de Lanheses, conta que o Gaisinho
nasceu do gargalhar de um gaio (o pássaro de penacho azul), numa manhã de S. Miguel,
quando as teias de aranha cintilavam o sol de outono. O primeiro som que ouviu foi o rumor do
Lima; por isso, sabe repetir sete risos diferentes, como sete medidas de água — do borbulho
da fonte ao riso largo da cheia. O último, dizem, é o riso silente, que só se ouve por dentro e
“arruma o coração”.


⸻
2. Contexto histórico e social
A figura do Gaisinho inscreve-se na ecologia simbólica do Alto Minho, onde o riso é recurso
tanto social como espiritual. Romarias, magustos, espadeladas e serões de fiar sempre
reservaram ao riso um lugar de catarse coletiva: sacudir o corpo para resignificar a dureza do
dia, do trabalho e das perdas. A criatura retém esse papel antigo — antepassado risível dos
palhaços de feira e das máscaras do entrudo — mas desloca-o do terreiro para a mata,
devolvendo a alegria ao ambiente que a recolhe.
A paisagem que molda o Gaisinho é de granito, humidade e folhosas. Nesse cenário, as
comunidades camponesas praticaram, durante séculos, uma economia de auto-subsistência
(milho, centeio, vinha, linho), com saber-fazer transmitido oralmente. O riso, aí, não é ornamento:
é método de regulação  — desarma a zanga, aproxima vizinhos, dá fôlego ao corpo cansado. O
Gaisinho encarna, então, uma política do leve: redistribui o peso (devolve o riso), desarma o
conflito (troca os objetos e devolve outros), absolve a vergonha (o riso involuntário como
perdão).
No ciclo ritual local (S. João, S. Miguel, colheitas, vindimas), há momentos de desregramento
criativo — pequenas transgressões aceites, risos coletivos, trocas e pregas (brincadeiras) que
desafiam a ordem para a reforçar. O Gaisinho é metáfora  dessa licença: a travessura permitida
que conserva o laço social. Por isso, a sua casa são limiares — bordejar de mata, ribas, muros
de quintal, pontilhões —, lugares onde duas ordens se tocam (casa/monte; luz/sombra; seco/
húmido).
Em termos comparativos, o Gaisinho dialoga com trasgos/trasnos galegos, fradinhos
portugueses e pequenas gentes do bosque (maruxinhos, enanucos): seres mestiços de ajuda e
engano, cuja ética não se mede por mandamentos, mas por reciprocidade. A singularidade do
Gaisinho, contudo, está no riso como dom e arte de condução  — fazer o outro sorrir para
reabrir uma passagem, desatar um medo, retomar o passo. No arquivo vivo do Alto Minho,
onde as “mulheres de fumo”, as morras encantadas e os cães  do Lima compõem uma
cosmologia do limiar, o Gaisinho é o pedagogo menor do ânimo .
⸻
3. Toponímia e variantes locais
O termo “Gaisinho” apresenta, na oralidade, duas hipóteses etimológicas populares que
convivem:
	 1.	 Da ave “gaio” (Garrulus glandarius), onomatopeia do
chamamento ríspido do pássaro e do seu penacho azul; “gaisinho” seria o “gaio
pequenino”, traduzido em génio;
	 2.	 De “gáios/gais”  (formas antigas para galhos ou astilhos), aludindo
ao barrete de folhas e ao gosto do ser por trazer raminhos e ouriços — o
“miúdo dos gais”.
Toponimicamente, relatos situam aparições preferenciais junto de:
– “Fonte do Lameiro” e “Ponte dos Quinhentos” (Arga de Baixo), onde se
deixam figos e broa;
– “Caminho Velho de Dem” (Caminha), linha de muros e silvados onde se escuta
o riso fino ao cair da tarde;
– “Passadiço de Lanheses” (Viana do Castelo), passagens de madeira que
“cantam” com a água — ali o Gaisinho imita o estalar das ripas e devolve bom-
humor aos apressados.


Variantes nominais recolhidas: “Gais”, “Gaisin”, “Menino do Gaio” e, mais raramente,
“Risinhos” (esta última usada por duas informantes, sublinhando o dom do riso). Em Dem, uma
linha narrativa associa o Gaisinho a um “São  dos risos” perdido — eco cristianizado da função
alegradora.
⸻
4. Primeiro relato e fontes académicas primárias
Estado da arte e transparência metodológica. A prospeção exaustiva em compilações
clássicas impressas (Teó filo Braga, Leite de Vasconcelos, Consiglieri Pedroso, Manuel J. Gandra,
Alexandre Parafita) não  encontrou entrada específica para “Gaisinho” (forma e sentido aqui
descritos). Também não se localizaram menções a “Gaisin/Gaisinho” em catálogos etnográ ficos
de circulação nacional.
O primeiro registo documental explícito sob esta designação  decorre, portanto, das recolhas
orais sistemáticas  conduzidas por Eduardo Mauer e equipa no programa Folclore Vivo –
Associação  MILK (2022–2025), com gravações e cadernos de campo arquivados internamente:
– Arga de Cima/Arga de Baixo (2023): três depoimentos (pastora, tecedeira, apicultor)
descrevendo o “bichinho que faz rir” e “tira o peso da boca”;
– Dem (Caminha) (2024): quatro depoimentos (duas mulheres idosas, um canastreiro, um
barqueiro reformado) com a forma “Gaisinho” e prática de deixar broa nos marcos;
– Lanheses (2024): duas memórias familiares (caderno manuscrito, anos 1960–70; nota marginal
a uma carteira de linho) mencionando “Menino do Gaio” que “desmancha choros”.
Fontes adjacentes para enquadramento comparativo (não atestam o nome “Gaisinho”, mas
iluminam o tipo):
– Trasgos/Trasnos (Galiza/Minho): pequenos espíritos domésticos e de caminho, marotos e
auxiliares;
– Fradinho/Fradinho da Mão  Furada (Norte): entidade travessa, redistributiva;
– Maruxinhos (Noroeste ibérico): seres diminutos do bosque.
Assim, o primeiro relato documentado do Gaisinho — enquanto designação  e perfil — fixa-
se, com rigor académico, nas recolhas MILK (2022–2025), com cópias de áudio,  transcrições
e fotografias de oferendas depositadas no Arquivo de Campo MILK – Coleção  Alto Minho
(cotas: MILK-AM/Arga-2023-C1; MILK-AM/Dem-2024-F2; MILK-AM/Lan-2024-M1).
⸻
5. Síntese interpretativa final
O Gaisinho articula, de forma singular, ecologia, afetos e riso. É minúsculo pedagogo do
ânimo , mediador entre corpo e ambiente, inventor de passagens. A sua ação prodigiosa não é
da ordem do milagre espetacular, mas da micro-transformação : desloca um objeto, espalha
sementes, devolve uma pena, desarma um pranto. O que muda é o clima interior — a pessoa
sorri e, ao sorrir, volta a caminhar.
O riso do Gaisinho, espelho da paisagem sonora (gaio, ribeiro, ripa molhada, bolota a rolar),
atua como técnica de regulação : restitui leveza ao passo, suspende o automatismo do
medo, abre o corpo à atenção . Na perspetiva da Associação  MILK, ele é mito-ferramenta
para pensar a saúde comunitária  em contextos rurais de baixa densidade: uma economia do
leve que previne a rigidez e nutre redes de cuidado.
A escultura (ver §7) traduz este núcleo num corpo compacto de alegria: cabeça grande, sorriso
insinuado, barrete de folhas, linha de bolotas ao peito e base com ranhuras aquosas — a
peça desloca o riso para dentro da matéria, como se a resina pudesse lembrar a água .


Em síntese, o Gaisinho é figura liminar e reparadora: não  promete destinos, liberta trajetos.
Onde a montanha pesa, ele aligeira; onde a língua amarga, ele adocica; onde a ponte estreita,
ele alarga pela coragem. Fazer o outro sorrir é, aqui, gesto técnico de mundo — abrir a
passagem.
⸻
6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer
Na leitura de Eduardo Mauer, o Gaisinho é corpo não  binário  da leveza. Não se de fine por
sexo, idade ou espécie: é humano-pássaro-folha , riso-água-passo . A sua ética não opera por
oposições (bem/mal, sério/brincadeira), mas por gradientes — do sombrio ao claro, da tensão
ao respiro.
“O Gaisinho ensina o que o riso pode: quebrar a dureza sem destruir a forma. Ele não
enfrenta: inflete. É o santo pequeno da flexão.” (E. Mauer, caderno de campo, Dem, 2024)
Nesta chave, o não  binário  não é tema adicionado; é método do próprio mito:
despossuir a coisa da sua rigidez para torná-la  passagem. Fazer sorrir é quebra de
binário  (lágrima/risada; medo/coragem; perder/achar), instaurando o entre onde o corpo
encontra outra maneira.
Ao presentificar a alegria como competência ambiental, o Gaisinho aproxima-se das
investigações MILK sobre folclore vivo: como reativar mitos não para classificá-los ,
mas para usá-los , isto é, torná-los  técnicas de cuidado em paisagens socialmente
frágeis. Nesta perspetiva, o Gaisinho não  é infantil; é sofisticado: tem a política do
pequeno — micro-desvios que reorganizam relações sem espetáculo.
⸻
7. Referência Estrutural da Matriz MILK
Matriz Escultórica MILK – Série Folclore Vivo / GAISINHO
– Corpo: compacto, de volumetria arredondada; cabeça grande e ligeiramente inclinada;
membros curtos; superfície com textura fina que lembra folha seca polida.
– Cromia: verde-musgo translúcido em base, com veladuras castanhas (folha) e micro-
inclusões azuis (eco do gaio).
– Iconografia: barrete de folhas com filete de hera; colar de bolotas (3–5 unidades) em resina
âmbar; boca insinuada em meia-lua (não escancarada), para sorriso insinuante.
– Base: disco irregular com ranhuras onduladas, evocando água  e passadiço; micro-lâmpadas
internas criam pulsação  de luz branda (cadência do riso).
– Comportamento lumínico: iluminação intermitente suave (c. 9–12 s), sem flashes; objetivo:
acalmar e convidar.
– Materiais: resina translúcida pigmentada; fibra; inserções de vidro; verniz marítimo fosco;
solução de limpeza acústica (a peça “soa” levemente quando tocada).
⸻
Localização  específica (circulação  típica relatada): trilhos de Serra d’Arga (capelas e fontes),
Dem (Caminha) – muros de caminho e marcos, Lanheses (Viana do Castelo) – passadiços do
Lima e carvalhal ribeirinho.
Primeiro relato documentado: Associação  MILK – Folclore Vivo (2022–2025): recolhas orais
gravadas e transcritas (Arga, Dem, Lanheses), não  existindo até à data referência explícita a
“Gaisinho” nas grandes compilações impressas.


Sistematização  contemporânea:  Eduardo Mauer, Gaisinho: Ecologias do Riso e Técnica  do
Leve no Imaginário  do Alto Minho (Lisboa, Associação MILK, 2025) – relatório interno e nota de
campo curatorial.
Fontes primárias  (conjunto): Arquivo de Campo MILK – Coleção Alto Minho (2022–2025),
cadernos paroquiais (anotações devocionais, sécs. XIX–XX) e memórias familiares (Lanheses,
1960–70) – cópias depositadas no dossiê do projeto. Fontes comparativas (sem ocorrência do
termo “Gaisinho”, mas úteis para tipologia): entradas sobre trasgos/trasnos, fradinhos e
maruxinhos nas compilações clássicas e estudos regionais.
⸻
Observação  crítica final (rigor e next steps). A consolidação académica do Gaisinho como
entrada autónoma exige: (i) catalogação  pública das gravações (depósito com metadados e
acesso controlado); (ii) edição  crítica das variantes (Arga/Dem/Lanheses) com aparelho crítico e
glosas; (iii) mapeamento toponímico das ocorrências; (iv) ensaio comparativo com micro-
lendas risíveis do arco galaico-português. Até lá, a Associação MILK propõe a presente
sistematização como versão-base  de folclore vivo, articulando ética do cuidado e poética do
riso numa figura que a comunidade reconhece: o pequeno que faz rir para deixar passar.
