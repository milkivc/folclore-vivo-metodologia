# 052. A Lenda da Senhora da Franqueira (Barcelos e Esposende, Alto Minho)

**Base documental e empírica:** pesquisa documental, análise comparada de fontes públicas, sistematização de tradição oral, relatos orais de pesquisa de campo e revisão semântica conduzidas no âmbito do Folclore Vivo da Associação MILK - Movimento de Intervenções e Linguagens Kulturais e Arte.
**Estado editorial:** corpus de pesquisa de campo e documentação cultural em revisão pública.
**Regra de publicabilidade:** esta entrada não deve ser lida como prova histórica definitiva, inventário patrimonial oficial, validação etnográfica concluída ou certificação académica externa sem verificação documental própria.
**Regra jurídica/RGPD:** não publicar nomes de informantes, contactos, moradas, entrevistas integrais, imagens identificáveis, gravações, dados de menores, coordenadas sensíveis ou materiais comunitários sem autorização.
**Regra de não invenção:** a presente readequação corrige a camada editorial e metodológica sem acrescentar factos, fontes, topónimos, coordenadas ou relatos não existentes no corpus-base.
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

52. A Lenda da Senhora da Franqueira (Barcelos e Esposende, Alto Minho)
(Sistematização  contemporânea  conduzida por Eduardo Mauer no âmbito  das pesquisas sobre
Folclore Vivo da Associação  MILK – Movimento de Intervenções e Linguagens Kulturais e Arte, a
partir de recolhas orais, documentação  histórica e fontes litúrgicas e arqueológicas entre 2022 e
2024, no eixo Barcelos–Esposende–Abade de Neiva.)
⸻
1. Descrição  simbólica e narrativa
A Lenda da Senhora da Franqueira, uma das mais antigas e veneradas do norte de Portugal,
articula espiritualidade, paisagem e memória histórica num mesmo corpo narrativo. Situada no
cume da Serra da Franqueira, entre os concelhos de Barcelos e Esposende, a devoção à
Senhora da Franqueira está profundamente ligada à ancestralidade do lugar e às suas funções de
refúgio, cura e mediação entre o céu e a terra.
Segundo a tradição oral recolhida por Eduardo Mauer (2023), a imagem da Senhora teria sido
descoberta por pastores num penedo luminoso, coberta por musgo e rodeada de flores brancas.
Ao tentarem transportá-la para o vale, a imagem tornava-se cada vez mais pesada, até que os
bois pararam e se ajoelharam. Os camponeses compreenderam que “a Senhora queria ficar na
serra” e ali edificaram uma pequena capela.
Com o passar dos séculos, o lugar tornou-se ponto de romaria e peregrinação. Reza a lenda que,
em tempos de seca, os habitantes das aldeias vizinhas subiam à serra com ramos de oliveira,
pedindo chuva. Quando o primeiro trovão ecoava, acendiam fogueiras e cantavam:
“Franqueira, mãe do alto, manda água e dá salvação.”
Outra versão, recolhida em Abade de Neiva, conta que a imagem apareceu a uma jovem
muda que pastoreava cabras. Ao vê-la, a moça recuperou a fala, gritando o nome que lhe
veio à mente: “Senhora da Franqueira!” — nome que, desde então, designa tanto a santa
quanto o monte.
O milagre da voz restaurada permanece como centro simbólico do culto: a Franqueira é a
Senhora que faz falar o silêncio — metáfora do renascimento e da libertação da palavra
interior.
Nos dias de romaria, os peregrinos sobem a serra descalços, trazendo oferendas de
flores, água e mel. O santuário, envolto em nevoeiros matinais, é conhecido por “lugar
onde o céu desce para ouvir”.


Na leitura simbólica de Eduardo Mauer, “a Senhora da Franqueira é o corpo sonoro da
montanha minhota — aquela que devolve a fala às pedras e transforma o eco em oração.”
⸻
2. Contexto histórico e social
O culto da Senhora da Franqueira tem origem documentada no século XII, associado a um
antigo eremitério medieval que se ergueu sobre vestígios de um santuário pré-cristão dedicado
ao solstício e ao ciclo das colheitas. O topónimo “Franqueira” deriva de franque (aberto, livre),
indicando lugar de passagem, liberdade e desimpedimento.
Durante o período medieval, a serra serviu de local de vigia e de refúgio contra invasões, o que
reforçou a associação entre o sagrado e a proteção. O santuário tornou-se centro espiritual e
territorial do Barcelos rural, unindo freguesias dispersas em torno de uma mesma devoção.
Nos séculos XVII e XVIII, a romaria da Franqueira era uma das maiores do Minho, combinando
liturgia e festa popular. O espaço de oração misturava-se a danças, cantos, banhos e banquetes
comunitários — eco dos rituais pagãos de fertilidade e agradecimento pela colheita.
No século XIX, a figura da Senhora da Franqueira foi reinterpretada como símbolo da
maternidade protetora, mas o substrato telúrico manteve-se intacto: as águas que descem do
monte continuam a ser usadas em rituais de cura e batismo.
Para Eduardo Mauer, “a Franqueira é o coração acústico do Minho — um santuário da palavra
regenerada, onde a montanha é catedral e a brisa, canto litúrgico.”
⸻
3. Toponímia e variantes locais
A Serra da Franqueira, situada entre as freguesias de Abade de Neiva e Viatodos, é ponto
estratégico de observação sobre os vales do Cávado e do Neiva. O nome “Franqueira” aparece
em documentos de 1178 como Monte Francorum, possivelmente designando local livre de
impostos e sujeito a jurisdição eclesiástica.
As variantes orais da lenda multiplicam-se:
– Em Abade de Neiva, a Senhora é “a Mãe da Voz”, ligada à jovem que recupera a fala;
– Em Galegos de Santa Maria, é “a Senhora do Eco”, cuja voz ressoa nas montanhas;
– Em Esposende, fala-se da “Senhora do Vento”, associada a tempestades e ventos de cura;
– Em Viatodos, o mito combina-se com o de uma moura encantada que se converteu à luz.
Todas as versões convergem na ideia de voz, vento e altura, reforçando a ligação entre o som, a
liberdade e a divindade.
⸻
4. Primeiro relato e fontes académicas primárias
O primeiro relato escrito da Lenda da Senhora da Franqueira encontra-se em Leite de
Vasconcelos, Etnografia Portuguesa, vol. II (1913, pp. 283–289)*, onde o autor descreve “a
Senhora do Monte que fala com o vento e devolve a voz aos mudos”.
Teófilo Braga, O Povo Português  nos seus Costumes, Crenças e Tradições (1885, pp. 398–404)*,
relaciona o culto com as antigas deusas das alturas e com a “psicologia do eco sagrado”,
presente em montanhas consagradas desde o período celta.


Alexandre Parafita, Mitologia Popular Portuguesa (2008, pp. 489–496)*, vê na Franqueira “a
transfiguração do culto solar e aéreo num arquétipo mariano”, associando a montanha ao eixo
simbólico que une céu e terra.
A sistematização contemporânea de Eduardo Mauer, A Senhora da Franqueira: Voz, Altura e
Liberdade no Imaginário  Minhoto (Lisboa, Associação MILK, 2024), propõe leitura não binária e
sonora do mito, interpretando a lenda como metáfora da voz feminina da montanha e da
ressonância  espiritual do território.
Fontes complementares:
– Arquivo Distrital de Braga, Cartulário  da Serra da Franqueira (séculos XII–XIX);
– Museu de Arqueologia D. Diogo de Sousa, Coleção  de Cultos da Altura e do Eco (1940–1980);
– Tese de Doutoramento de Luís Azevedo, O Som do Sagrado: Eco, Voz e Montanha no Norte de
Portugal (U. Minho, 2021).
⸻
5. Síntese interpretativa final
A Senhora da Franqueira representa a fusão entre altura e eco, entre silêncio e fala. A sua lenda
narra o momento em que a voz emerge da pedra — símbolo da criatividade e da libertação
espiritual.
Na leitura simbólica da Associação  MILK, a Senhora da Franqueira é o arquétipo do verbo
libertado, do som que cura, da voz que atravessa o ar e se transforma em matéria sensível.
A escultura MILK concebida por Eduardo Mauer representa corpo compacto branco com véu
translúcido em espiral ascendente. A cabeça grande inclina-se levemente para a frente, e o
interior é iluminado por pulsação sonora, simulando vibração.
⸻
6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer
Na leitura não binária de Eduardo Mauer, a Senhora da Franqueira é o corpo sonoro da
montanha — simultaneamente voz e silêncio, eco e origem.
Mauer escreve: “O som que a Senhora devolve não é de um sexo nem de uma fé; é a vibração do
mundo em equilíbrio. Falar é respirar com a montanha.”
A Associação  MILK interpreta o mito como paradigma da espiritualidade vibracional e não
binária , em que o sagrado é frequência, não forma. A voz da Franqueira é o som do mundo que
se ouve a si próprio.
⸻
7. Referência Estrutural da Matriz MILK
Na Matriz Escultórica MILK, a Senhora da Franqueira é representada com cabeça grande, véu
em forma de onda ascendente e base circular dourada. O interior vibra com luz e som
intermitente, simbolizando o eco e o renascimento da voz.
⸻
Localização  específica: Serra da Franqueira, entre Barcelos e Esposende, distrito de Braga.
Primeiro relato documentado: Leite de Vasconcelos, Etnografia Portuguesa, vol. II, 1913.


Sistematização  contemporânea:  Eduardo Mauer, A Senhora da Franqueira: Voz, Altura e
Liberdade no Imaginário  Minhoto, Associação MILK, 2024.
Fontes primárias:  Braga (1885); Vasconcelos (1913); Parafita (2008); Azevedo (2021); Mauer
(2024).
