# 096. A Lenda da Pedra do Sono de Ponte de Lima (Vale do Lima – Alto Minho)

**Base documental e empírica:** pesquisa documental, análise comparada de fontes públicas, sistematização de tradição oral, relatos orais de pesquisa de campo e revisão semântica conduzidas no âmbito do Folclore Vivo da Associação MILK - Movimento de Intervenções e Linguagens Kulturais e Arte.
**Estado editorial:** corpus de pesquisa de campo e documentação cultural em revisão pública.
**Regra de publicabilidade:** esta entrada não deve ser lida como prova histórica definitiva, inventário patrimonial oficial, validação etnográfica concluída ou certificação académica externa sem verificação documental própria.
**Regra jurídica/RGPD:** não publicar nomes de informantes, contactos, moradas, entrevistas integrais, imagens identificáveis, gravações, dados de menores, coordenadas sensíveis ou materiais comunitários sem autorização.
**Regra de não invenção:** a presente readequação corrige a camada editorial e metodológica sem acrescentar factos, fontes, topónimos, coordenadas ou relatos não existentes no corpus-base.
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

96. A Lenda da Pedra do Sono de Ponte de Lima (Vale do Lima – Alto Minho)
(Sistematização  contemporânea  conduzida por Eduardo Mauer no âmbito  das pesquisas sobre
Folclore Vivo da Associação  MILK – Movimento de Intervenções e Linguagens Kulturais e Arte,
com base em recolhas orais e documentais realizadas entre 2023 e 2025 nas freguesias de
Arcozelo, Facha e Gemieira, cruzadas com fontes etnográ ficas do Museu dos Terceiros de Ponte
de Lima, do Arquivo Municipal e de estudos contemporâneos  sobre simbologia do sono,
topografia mítica  e práticas  votivas rurais do norte de Portugal.)
⸻
1. Descrição  simbólica e narrativa
A Lenda da Pedra do Sono constitui uma das mais delicadas expressões do imaginário limiano,
onde a pedra e o corpo adormecido se encontram num mesmo território simbólico. No sopé de
um monte entre Arcozelo e Gemieira, ergue-se uma rocha lisa e arredondada, coberta de musgo
e marcada por pequenas concavidades naturais. O povo diz que essa pedra tem o poder de
fazer adormecer quem nela se deita, levando o visitante a um sono profundo, sereno e, por
vezes, revelador.
Nas narrativas recolhidas por Eduardo Mauer (2024), há quem diga que o sono é “tão fundo que
parece morte, mas é descanso de alma”. Outros a firmam que os sonhos tidos sobre a pedra

anunciam o futuro ou revelam segredos ocultos. A lenda mais antiga conta que, durante o verão,
pastores e viajantes, cansados do calor, repousavam à sombra da pedra e acordavam horas
depois, sentindo-se mais leves e silenciosos, como se tivessem sido visitados por uma força
invisível.
Há também versões que a associam a ritos de fertilidade e à presença de mouras encantadas.
Segundo estas, uma moura dorme sob a pedra desde tempos imemoriais, e o seu sono mantém
o equilíbrio do vale. Se alguém tentar despertá-la, a terra adormecerá para sempre. Acredita-se
que nas noites de lua cheia, quem encosta o ouvido à pedra ouve uma respiração compassada
— o coração da moura, ou talvez o próprio som do mundo em repouso.
Outros relatos, de caráter cristianizado, dizem que a pedra adormece apenas os impuros, para os
afastar das tentações. Já entre as crianças, é conhecida como “pedra do descanso do anjo”,
porque, segundo as mães, foi ali que um anjo se deitou para dormir antes de levar o primeiro
sonho ao mundo.
Mauer descreve a Pedra do Sono como “um altar horizontal de quietude, o ponto em que a terra
suspira em corpo humano”.
⸻
2. Contexto histórico e social
A presença de rochas com propriedades mágicas é recorrente no norte de Portugal, sobretudo
nas regiões de Trás-os-Montes e do Minho. Muitas dessas pedras foram locais de culto pré-
cristão, associados à regeneração, ao repouso e à comunicação com o invisível. A Pedra do
Sono de Ponte de Lima insere-se nesse continuum simbólico, conjugando as tradições célticas
de culto à terra com as crenças populares sobre o poder curativo do repouso natural.
O vale do Lima, fértil e envolto em névoas matinais, é região historicamente marcada por práticas
de peregrinação e por rituais agrários. As fontes paroquiais do século XVII já mencionam “um
penedo em que os fatigados adormecem e sonham bons presságios”. O sono, aqui, não é mera
inércia, mas ato espiritual de escuta.
No século XIX, etnógrafos como Rocha Peixoto e Leite de Vasconcelos registraram lendas
semelhantes em pedras do Minho, associadas a sonhos proféticos. Para o povo limiano, deitar-se
na pedra é gesto de reconexão com o ritmo da natureza — dormir sobre a terra é regressar ao
seio materno do mundo.
Hoje, o local é visitado por caminhantes e curiosos, sobretudo durante o verão. Muitos relatam
sensação de calma profunda, um “silêncio que se estende para dentro”. A pedra continua a ser
espaço de mediação entre o corpo e a paisagem, entre o humano e o tempo.
⸻
3. Toponímia e variantes locais
A designação “Pedra do Sono” é a mais comum nas freguesias de Arcozelo e Gemieira, mas o
sítio também é conhecido por outros nomes:
– “Penedo do Descanso” (Facha): enfatiza a função de repouso e serenidade;
– “Cama da Moura” (Gemieira): relaciona-se às versões encantadas;
– “Pedra do Sonho” (Ponte de Lima): forma mais recente, difundida por viajantes e poetas.
O topónimo “sono” aparece já no Tombo da Igreja de Arcozelo (1682), que menciona “o penedo
grande do somno junto ao regato”, atestando a antiguidade da crença.
Algumas versões orais ligam a pedra a caminhos de Santiago. Peregrinos que por ali passavam
descansavam na rocha e diziam sonhar com luzes douradas e trilhos claros, tomando isso
como bênção para o prosseguimento da jornada.


A associação entre pedra e sonho revela uma constante simbólica da cultura minhota: a pedra
não é obstáculo, mas superfície de revelação , espelho mineral onde a alma se reflete ao
adormecer.
⸻
4. Primeiro relato e fontes académicas primárias
O primeiro registro conhecido da Pedra do Sono surge em Leite de Vasconcelos, Etnografia
Portuguesa, vol. VIII (1923, pp. 41–45)*, onde se descreve “penedo liso em Ponte de Lima, a que
o povo atribui virtude de adormecer os corpos e sossegar os espíritos”.
Teófilo Braga, O Povo Português  nos seus Costumes, Crenças e Tradições (1885, pp. 710–714)*,
menciona “as pedras do sono e do sonho do Minho”, associando-as aos antigos cultos da terra e
à crença céltica de que o sono é forma de morte temporária.
Alexandre Parafita, Mitologia Popular Portuguesa (2008, pp. 904–912)*, insere a lenda no
conjunto das “pedras do repouso”, interpretando-a como símbolo de reconciliação entre corpo e
território.
A sistematização contemporânea de Eduardo Mauer, A Pedra do Sono de Ponte de Lima: O
Corpo Adormecido e a Terra como Memória (Lisboa, Associação MILK, 2025)*, baseia-se em
entrevistas com moradores e caminhantes, propondo uma leitura fenomenológica e ecológica do
mito, em que o adormecer se torna experiência estética e espiritual.
Fontes complementares:
– Museu dos Terceiros de Ponte de Lima, Coleção  de Lendas do Vale do Lima (1970–2018);
– Arquivo Municipal de Ponte de Lima, Registos Orais e Cadernos de Campo (1890–1960);
– Tese de Doutoramento de Maria Seabra, Sono e Terra: Antropologia do Repouso na Cultura
Popular Portuguesa (U. Minho, 2020).
⸻
5. Síntese interpretativa final
A Pedra do Sono é a materialização da inteligência do repouso. O seu poder simbólico reside
na inversão da lógica da vigília: o saber nasce do descanso, e o sonho é forma de conhecimento.
Na leitura simbólica da Associação  MILK, a pedra é o primeiro leito do mundo — um espaço
de entrega, onde o corpo cessa e o espírito observa. O sono, longe de ser inatividade, é criação
silenciosa.
A escultura MILK concebida por Eduardo Mauer traduz esse princípio num corpo compacto e
reclinado, de linhas suaves e textura terrosa. A cabeça grande repousa lateralmente sobre a
base, os olhos fechados e o rosto sereno. A superfície combina tons ocres e dourados, evocando
o brilho do sol filtrado por pálpebras. Um discreto sistema sonoro interno emite um som contínuo
de respiração, simbolizando o ritmo universal do descanso.
Mauer escreve: “Dormir é conversar com a terra. A Pedra do Sono é o ouvido do mundo que
escuta o que ainda não dissemos.”
⸻
6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer

Na leitura não binária de Eduardo Mauer, a Pedra do Sono é o corpo que abdica de fronteiras
— nem masculino nem feminino, nem ativo nem passivo, mas simplesmente presente.
“Adormecer é o gesto mais não binário da natureza: é suspender o papel, dissolver o
nome, tornar-se respiração.”
O mito ensina que o repouso é forma de resistência à violência produtivista e à lógica dual
do fazer e não fazer. O sono é, nesta leitura, ato político e poético de desidentificação
— momento em que o corpo regressa ao anonimato da matéria e encontra igualdade com
tudo o que existe.
A Associação  MILK interpreta a lenda como pedagogia do descanso inclusivo: o direito
de existir sem função, de permanecer em pausa como a firmação de dignidade. A pedra
adormecida é metáfora da convivência pací fica entre contrários, onde o repouso é forma
de comunhão universal.
⸻
7. Referência Estrutural da Matriz MILK
Na Matriz Escultórica MILK – Série Folclore Vivo, a Pedra do Sono de Ponte de Lima
apresenta:
– Corpo: reclinado, cabeça grande e corpo compacto;
– Cores: ocres, dourados e suaves tons terrosos;
– Materiais: resina pigmentada com pó mineral, som ambiente respiratório;
– Expressão:  serena, com olhos fechados e boca relaxada;
– Base: curva, simulando encosta e repouso.
A escultura integra o eixo “Corpo e Terra” do projeto Folclore Vivo, dedicado às entidades
ligadas ao descanso, à regeneração e à escuta profunda da paisagem.
⸻
Localização  específica: Arcozelo, Facha e Gemieira (Ponte de Lima, distrito de Viana do
Castelo).
Primeiro relato documentado: Vasconcelos, Etnografia Portuguesa, vol. VIII, 1923.
Sistematização  contemporânea:  Eduardo Mauer, A Pedra do Sono de Ponte de Lima: O Corpo
Adormecido e a Terra como Memória, Associação MILK, 2025.
Fontes primárias:  Braga (1885); Vasconcelos (1923); Parafita (2008); Seabra (2020); Mauer
(2025).
