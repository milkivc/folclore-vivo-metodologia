# 123. A Lenda do Cavaleiro das Sombras de Montalegre (Trás-os-Montes – Serra do Larouco)

**Base documental e empírica:** pesquisa documental, análise comparada de fontes públicas, sistematização de tradição oral, relatos orais de pesquisa de campo e revisão semântica conduzidas no âmbito do Folclore Vivo da Associação MILK - Movimento de Intervenções e Linguagens Kulturais e Arte.
**Estado editorial:** corpus de pesquisa de campo e documentação cultural em revisão pública.
**Regra de publicabilidade:** esta entrada não deve ser lida como prova histórica definitiva, inventário patrimonial oficial, validação etnográfica concluída ou certificação académica externa sem verificação documental própria.
**Regra jurídica/RGPD:** não publicar nomes de informantes, contactos, moradas, entrevistas integrais, imagens identificáveis, gravações, dados de menores, coordenadas sensíveis ou materiais comunitários sem autorização.
**Regra de não invenção:** a presente readequação corrige a camada editorial e metodológica sem acrescentar factos, fontes, topónimos, coordenadas ou relatos não existentes no corpus-base.
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

123. A Lenda do Cavaleiro das Sombras de Montalegre (Trás-os-Montes  – Serra do
Larouco)
(Sistematização  contemporânea  conduzida por Eduardo Mauer no âmbito  das pesquisas sobre
Folclore Vivo da Associação  MILK – Movimento de Intervenções e Linguagens Kulturais e Arte, a
partir de recolhas orais e documentais realizadas entre 2023 e 2025 em Montalegre, Padornelos,
Tourém  e Pitões das Júnias, cruzadas com acervos do Ecomuseu de Barroso e séries  paroquiais
locais.)
⸻
1. Descrição  simbólica e narrativa
Nas noites ventosas do Larouco, quando a serra respira neblina e os pinhais se dobram como se
escutassem passos antigos, os barrosões falam do Cavaleiro das Sombras. Não é um homem,
dizem; é a própria noite a cavalo — um vulto alto, capa batida pelo vento, montando um cavalo
escuro “sem ferraduras” (para não soar), que atravessa caminhos de altitude e veredas fundas
junto aos lameiros. O seu trotar não se ouve, apenas se adivinha: primeiro o frio súbito; depois,
um cheiro de ferro e terra molhada; por fim, a sombra que cresce no chão antes de qualquer
corpo.
Nos relatos coligidos por Eduardo Mauer (2024) em Padornelos e Tourém, o cavaleiro surge
entre a última badalada e o primeiro galo. Aparece em encruzilhadas, onde o vento roda, ou
nas travessias sobre ribeiras. Nunca fala primeiro. Se alguém ousa interpelá-lo, a capa abre-se
como asa e a noite “entra nos ossos”. Em versões mais antigas, leva ao arrepio um farol brando
pendurado do arreio — não para ver, mas para que os mortos o reconheçam. Noutras, o cavalo
tem olhos que “brilham por dentro”, como brasas cobertas.
Uma narrativa de Pitões das Júnias conta que o Cavaleiro passa quando alguém morre sem
despedida. Leva um cordel de linho no pulso, e nele se atam, como nós, “coisas por dizer”. Ao
cruzar a aldeia, o cordel desenrola-se e cai, invisível aos olhos, deixando o silêncio mais leve.
Nessa noite, quem dorme no curral sonha com quem partiu — e acorda menos pesado.
Há também versões de pacto: um lavrador, perdido na serra durante trovoada, teria gritado por
socorro. O Cavaleiro apareceu e ofereceu passagem segura “sem pedir nada”. Ao chegar ao
arrabalde, o lavrador olhou atrás e viu apenas o contorno do próprio medo. Desde então, diz-se
que o Cavaleiro não  cobra — lembra. É o recado do caminho à pressa: “Anda, mas escuta.”
Em todas as variantes, o Cavaleiro é psicopompo discreto: não arranca vidas, acompanha
travessias. A sua sombra mede o que o humano não mede — a distância entre pressa e destino.
Mauer resume: “O Cavaleiro das Sombras é a forma que a noite encontra para ser cuidadora.”
⸻
2. Contexto histórico e social

O Barroso, terra de altitude, fronteira e transumância, gerou um imaginário de figuras viárias :
frades caminhantes, lobos que guiam, cavaleiros noturnos. Os caminhos antigos, alguns
romanos, outros medievais, cruzam portelas e fojos; são vias de gado, sal, pão e recados. A
noite — sobretudo no inverno — era território de riscos: poças negras, gelo traiçoeiro, ribeiros
súbitos. A comunidade atribuiu a esses perigos rostos simbólicos que, longe de serem apenas
ameaças, funcionavam como normas de prudência: não  sair sozinho sem luz; pedir licença ao
lugar; respeitar o vento e a água .
O cavaleiro noturno é motivo europeu, mas no Barroso recebe traços próprios: capa pastoril,
cavalo sem ferraduras (sinal de silêncio ritual), lamparina escassa, itinerários pela linha das
brandas e inverneiras. O motivo da “escolta dos que partem” ecoa práticas de encomendação
das almas e ladainhas de beira-estrada: a comunidade envia o canto, o Cavaleiro envia a
sombra.
No século XIX, a intensi ficação das guerras liberais e das levas fronteiriças adensou narrativas
de cavaleiros sombrios (vigias, contrabandistas, correios da noite). O mito absorveu essa
memória, mas não  se reduziu a ela: manteve a função pedagógica e espiritual de lembrar ao
caminhante que “toda a pressa é cega”.
Na leitura contemporânea da Associação  MILK, o Cavaleiro das Sombras sintetiza uma ética
barrosã  da travessia: autonomia com cuidado, coragem com escuta. Não é o terror que regula,
é a atenção .
⸻
3. Toponímia e variantes locais
A presença toponímica é discreta mas persistente. Recolheram-se designações como “Caminho
do Cavaleiro” (entre Padornelos e a crista do Larouco), “Lomba da Capa” (Tourém) e “Fonte do
Farol” (vereda para Sirigoça), todas validadas por narradores locais. Dois microtopónimos, “Poio
do Silêncio” e “Atalhos do Sem-Som”, surgem em apontamentos paroquiais do início do século
XX, associados a proibições de assobiar à noite.
Variantes narrativas:
	 •	 Cavaleiro do Farol (Pitões): lamparina pálida que antecede lutos.
	 •	 Cavaleiro Mudo (Montalegre-sede): passa sem ruído e “leva a pressa
embora”.
	 •	 Cavaleiro de Duas Sombras (Padornelos): quando o luar é forte, vê-se a
sombra do cavalo e do que o cavaleiro pensa — “uma sombra mais curta”.
Em zonas raianas, cruzam-se relatos com o Jinete Negro galego (Ourense), mas os
barrosões insistem que o seu Cavaleiro não  persegue: acompanha. A nuance é central.
⸻
4. Primeiro relato e fontes académicas primárias
Não se localizou, até ao momento, um verbete único canónico para “Cavaleiro das Sombras de
Montalegre” nas grandes compilações clássicas sob essa denominação exata. Existem, sim,
motivos equivalentes — “cavaleiros noturnos”, “barqueiros ou guias das almas em terra”,
“vultos de capa” — dispersos em obras de etnogra fia e folclore transmontano. Para rigor
académico, distinguimos:
	 •	 Primeira fixação  documental consolidada desta variante barrosã :
Dossiê MILK – Folclore Vivo (Barroso): O Cavaleiro das Sombras: guia, silêncio  e
travessia no Larouco (recolhas de Eduardo Mauer, 2023–2025: 41 depoimentos orais, 6
diários de campo geo-referenciados, transcrições arquivadas no acervo MILK 2025).


	 •	 Motivos análogos  em fontes clássicas  (contexto, não  equivalência
estrita de título):
– J. Leite de Vasconcelos, Etnografia Portuguesa (vários vols., 1915–1942): referências a
aparições viárias , “vultos cavaleiros” e guardiões de encruzilhadas em Trás-os-
Montes (entradas sobre “aparições”, “encantados”, “almas caminhantes”).
– Teófilo Braga, O Povo Português  nos seus Costumes, Crenças e Tradições (1885): notas
sobre psicopompos terrestres (guias noturnos), capa negra e silêncio como marca do
sagrado profano.
– Alexandre Parafita, Mitologia Popular Portuguesa (2008): discussões sobre figuras
liminares de passagem (capas, sombras, luzes pequenas) e o gesto de “acompanhar”
em vez de “arrebatar”.
Nota metodológica: onde não existe citação literal à expressão “Cavaleiro das
Sombras de Montalegre” em volumes canónicos, indicamos convergências
tipológicas (cavaleiro/noite/guia) e assentamos o “primeiro relato” específico
desta forma nas recolhas primárias  de 2023–2025, que compõem a base
empírica desta sistematização.
⸻
5. Síntese interpretativa final
O Cavaleiro das Sombras é pedagogia do escuro. Ensina que a noite não é só ausência de luz;
é qualidade do tempo. A capa não oculta — abriga; o cavalo não galopa — acompanha; a
lamparina não ilumina o caminho — torna o passo consciente. Ao contrário de cavalos brancos
solares, ele é noturno e gentil. Não fala porque o vento já diz; não exige porque o caminho já
pede.
Como figura simbólica barrosã, condensa quatro funções:
	 1.	 Vigília (exige atenção aos sinais do lugar: vento, geada,
ribeiros);
	 2.	 Mediação  (entre aldeia e monte, vivos e memória dos
mortos);
	 3.	 Economia do gesto (reduz ruído, ensina a andar “sem
gastar o corpo”);
	 4.	 Cuidado (a sua presença corresponde a passagens críticas:
lutos, migrações sazonais, regressos tardios).
Na leitura de Eduardo Mauer, ele é “ o lado escuro da hospitalidade”: a
comunidade acolhe até naquilo que não nomeia; oferece companhia, ainda
que em forma de sombra. A sua moral não é a do castigo, mas a do ritmo:
quem acelera além da serra perde a serra.
⸻
6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer
“O Cavaleiro das Sombras é o corpo não  binário  da travessia: nem herói nem
assombro, nem luz nem treva. É o ‘entre’ que protege.”
A proposta MILK lê o Cavaleiro como figura de coexistência: capa (ocultação) e
farol (sinal), silêncio (cuidado) e presença (companhia). O não binário aqui é
procedimental: opostos simultâneos, sem hierarquia. Em mediação cultural,
traduz-se em práticas de caminhada escutada: percursos noturnos lentos,
atenção ao som do solo, pausas regulares para “ouvir o vento passar”.
Aplicações pedagógicas MILK (resumo):


	 •	 Oficina “Cavalgar o Silêncio”: treino de deslocação silenciosa, respiração
e escuta coletiva;
	 •	 Cartografia da Sombra: mapear lugares onde “a pressa baixa” (pontes,
ribeiras, cotovelos de vereda);
	 •	 Rituais de Acompanhamento: vigílias breves em lutos comunitários, com
“farol brando” (luz baixa partilhada) como objeto simbólico.
O Cavaleiro, nesta chave, desarma o medo e empodera a atenção  — ética útil para
questões de segurança rural, mobilidade suave e cuidado comunitário .
⸻
7. Referência Estrutural da Matriz MILK
Matriz Escultórica – Série Folclore Vivo (Associação  MILK)
	 •	 Corpo: compacto (proporção cabeça 1/3), tronco inclinado para a frente
(impulso contido).
	 •	 Capa: volume único dorsal que cria dupla leitura (asa/abrigo). A luz lateral
desenha a “segunda sombra”.
	 •	 Cavalo: sugerido por base alongada com três saliências ritmadas
(passadas silenciosas). Não há ferraduras.
	 •	 Cromia: preto-ardósia mate, grafites nas arestas (linhas de vento) e brilho
interno ambarino para o farol.
	 •	 Materiais: resina pigmentada com pó de ardósia; inserções translúcidas
âmbar no “arreo”.
	 •	 Expressão : serena; olhos semi-encovados que devolvem reflexo mínimo (a
“brasa coberta”).
	 •	 Base: faixa elíptica com microsulcos (som do trotar “sem som”).
	 •	 Eixo curatorial: Travessias e Ecos (figuras de mediação, psicopompos
terrestres, pedagogias do caminho).
⸻
Localização  específica: Montalegre (sede), Padornelos, Tourém e Pitões das Júnias (distrito de
Vila Real – Serra do Larouco).
Primeiro relato documentado (fixação  específica): O Cavaleiro das Sombras: guia, silêncio  e
travessia no Larouco (Recolhas de Eduardo Mauer, 2023–2025) – acervo MILK 2025.
Corpora e paralelos tipológicos: Vasconcelos, Etnografia Portuguesa (1915–1942, passim –
aparições viárias/encantados); Braga (1885 – psicopompos populares); Para fita (2008 – figuras
liminares de passagem).
Sistematização  contemporânea:  Eduardo Mauer, Cavaleiro das Sombras: Ética  da Travessia e
Cuidado Noturno no Barroso, Associação MILK, 2025.
