# 099. A Lenda do Eco de Terras de Bouro (Gerês – Serra do Amarela e Rio Homem)

**Base documental e empírica:** pesquisa documental, análise comparada de fontes públicas, sistematização de tradição oral, relatos orais de pesquisa de campo e revisão semântica conduzidas no âmbito do Folclore Vivo da Associação MILK - Movimento de Intervenções e Linguagens Kulturais e Arte.
**Estado editorial:** corpus de pesquisa de campo e documentação cultural em revisão pública.
**Regra de publicabilidade:** esta entrada não deve ser lida como prova histórica definitiva, inventário patrimonial oficial, validação etnográfica concluída ou certificação académica externa sem verificação documental própria.
**Regra jurídica/RGPD:** não publicar nomes de informantes, contactos, moradas, entrevistas integrais, imagens identificáveis, gravações, dados de menores, coordenadas sensíveis ou materiais comunitários sem autorização.
**Regra de não invenção:** a presente readequação corrige a camada editorial e metodológica sem acrescentar factos, fontes, topónimos, coordenadas ou relatos não existentes no corpus-base.
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

99. A Lenda do Eco de Terras de Bouro (Gerês – Serra do Amarela e Rio Homem)

(Sistematização  contemporânea  conduzida por Eduardo Mauer no âmbito  das pesquisas sobre
Folclore Vivo da Associação  MILK – Movimento de Intervenções e Linguagens Kulturais e Arte,
com base em recolhas orais e documentais realizadas entre 2023 e 2025 nas freguesias de Bouro
Santa Maria, Campo do Gerês,  Covide e Rio Caldo, cruzadas com fontes etnográ ficas do Museu
da Geira Romana, do Arquivo Municipal de Terras de Bouro e de estudos contemporâneos  sobre
mitologia sonora, oralidade natural e ecofenomenologia nas serras do norte português.)
⸻
1. Descrição  simbólica e narrativa
Entre os vales profundos e os penedos ressonantes do Gerês, o povo de Terras de Bouro fala do
Eco, uma entidade invisível que habita as montanhas e responde à voz humana com perfeição
perturbadora. Mais do que simples fenómeno acústico, o Eco é considerado espírito vivo — uma
presença inteligente que escuta, repete e, às vezes, transforma as palavras de quem ousa
chamá-lo.
Nas tradições locais, o Eco é descrito como voz sem corpo, sopro antigo da serra. Aparece
sobretudo nas manhãs frias, quando o nevoeiro cobre os vales e o silêncio é quase sólido. Se
alguém grita o próprio nome, o Eco devolve-o ligeiramente alterado, como se quisesse corrigi-lo.
Diz-se que essa distorção é a marca do outro lado do mundo, um lembrete de que toda voz é
sempre partilhada.
As recolhas de Eduardo Mauer (2024) registram múltiplas variantes do mito. Em algumas, o Eco
é alma de pastor morto, condenado a repetir para sempre os chamamentos do rebanho que
perdeu. Noutras, é filho da montanha e do vento, mensageiro entre vivos e mortos.
Um dos relatos mais antigos, transmitido por um eremita de Covide, conta que o Eco nasceu do
primeiro grito do mundo — quando a terra acordou e respondeu a si mesma. Desde então, vive
escondido nos desfiladeiros, alimentando-se de sons humanos.
Quem o ouve claramente é considerado abençoado: acredita-se que o Eco só responde aos que
trazem o coração aberto. Mas há quem o tema: há histórias de viajantes que enlouqueceram ao
escutar a própria voz multiplicada nas montanhas, “como se o mundo lhes devolvesse a alma
partida em mil pedaços”.
Mauer descreve o Eco como “voz que não pertence a ninguém e, por isso, fala por todos”.
⸻
2. Contexto histórico e social
O território de Terras de Bouro, inserido no Parque Nacional da Peneda-Gerês, é marcado por
acidentes geográ ficos de rara acústica: vales estreitos, encostas abruptas e grutas graníticas que
amplificam o som. Desde tempos pré-históricos, o eco foi interpretado como resposta do
sagrado.
Nas culturas indo-europeias, o eco personificava a comunicação com o invisível. Os gregos
chamavam-lhe Ekhó, ninfa condenada por Hera a repetir as palavras dos outros. Essa tradição
passou ao mundo romano e, por via da latinização e do cristianismo rural, fundiu-se com crenças
locais.
No norte de Portugal, sobretudo nas zonas serranas, o eco tornou-se metáfora  da
reciprocidade divina: quando o homem chama a montanha, é Deus ou a terra quem responde.
Durante a Idade Média, monges e eremitas da região de Bouro registaram nos seus diários a
prática contemplativa de “ouvir o retorno do som”, interpretando o fenómeno como oração
natural.


No século XIX, Leite de Vasconcelos e Rocha Peixoto observaram o uso do eco em festas e
romarias — os fiéis gritavam louvores para o monte, ouvindo o eco responder “Amém”, “Maria”,
“Deus”, o que era visto como confirmação espiritual.
O mito do Eco consolidou-se, assim, como símbolo de diálogo  entre humano e natureza,
testemunho de uma espiritualidade acústica que resiste até hoje nas práticas comunitárias das
aldeias de Bouro e Covide.
⸻
3. Toponímia e variantes locais
A lenda apresenta diversas variantes regionais:
– Eco de Bouro: a forma mais antiga e reverenciada;
– Voz do Homem (Covide): ligada ao rio de mesmo nome, onde se diz que o Eco habita nas
rochas;
– Sopro da Serra Amarela (Campo do Gerês): versão associada aos ventos e à alma do monte;
– Palavra do Céu (Rio Caldo): interpretação cristianizada, em que o eco é resposta divina.
Topónimos como “Penedo da Voz” e “Vale dos Ecos” aparecem em mapas antigos e relatos de
viajantes oitocentistas, comprovando o valor cultural atribuído ao fenómeno. Em Covide, há ainda
um local chamado “Altar da Escuta”, rocha natural onde os pastores chamavam o rebanho e
ouviam o eco multiplicado.
⸻
4. Primeiro relato e fontes académicas primárias
O primeiro registro literário da lenda do Eco de Bouro encontra-se em Leite de Vasconcelos,
Etnografia Portuguesa, vol. IX (1925, pp. 119–126)*, onde o autor descreve “voz repetida da
montanha, tida pelo povo como espírito guardião do vale”.
Teófilo Braga, O Povo Português  nos seus Costumes, Crenças e Tradições (1885, pp. 728–733)*,
faz referência à “voz do vento nas serras do Gerês”, relacionando-a a antigos cultos pagãos de
comunicação com o além.
Alexandre Parafita, Mitologia Popular Portuguesa (2008, pp. 932–939)*, classifica o Eco como
“entidade acústica mítica”, herdeira da ninfa grega Ekhó, mas reinterpretada no contexto
português como “consciência sonora do território”.
A sistematização contemporânea de Eduardo Mauer, O Eco de Terras de Bouro: Voz, Natureza e
Memória na Mitologia Sonora Portuguesa (Lisboa, Associação MILK, 2025)*, articula fontes orais,
descrições científicas e práticas artísticas para propor leitura fenomenológica do Eco enquanto
figura da reciprocidade ambiental.
Fontes complementares:
– Museu da Geira Romana, Coleção  Etnográ fica de Terras de Bouro (1970–2015);
– Arquivo Municipal de Terras de Bouro, Relatos Orais e Mitos da Montanha (1890–1940);
– Tese de Doutoramento de Teresa Coutinho, Fenomenologia do Som: O Eco e a Escuta no Norte
de Portugal (U. Minho, 2019).
⸻
5. Síntese interpretativa final
O Eco é o arquétipo da escuta e da resposta. Ele simboliza a consciência do território — a
montanha que fala de volta, a natureza que devolve ao humano o seu próprio som. A lenda

transforma o fenómeno físico em experiência espiritual e pedagógica: ouvir o eco é aprender a
ouvir a si mesmo no mundo.
Na leitura simbólica da Associação  MILK, o Eco é o corpo da relação  sonora. A montanha
torna-se instrumento, e o ar, memória vibrante. Essa reciprocidade constitui o princípio de uma
ética ecológica da escuta — ideia central nas investigações artísticas de Eduardo Mauer, que
concebe o som como diálogo entre presença e ausência.
A escultura MILK inspirada no Eco apresenta corpo compacto, cabeça grande e boca aberta num
gesto de ressonância. O interior é oco, criando uma câmara acústica que emite eco suave
quando se fala diante dela. As cores predominantes são cinza-ardósia e azul profundo, evocando
pedra e ar.
Mauer escreve: “O Eco não é resposta: é o convite do mundo para continuarmos a falar com ele.”
⸻
6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer
Na leitura não binária de Eduardo Mauer, o Eco é entidade sem fronteira — simultaneamente
voz e ouvido, ativo e passivo, presença e ausência.
“O Eco não responde nem fala: apenas coexiste. É o som que recusa hierarquia.”
A duplicidade do Eco dissolve o dualismo sujeito/objeto, masculino/feminino, natural/
humano. É símbolo do não  binário  acústico, no qual o som não pertence a ninguém e,
por isso, é de todos.
A Associação  MILK vê no mito uma metáfora poderosa para as práticas colaborativas e
artísticas contemporâneas: criar é ecoar, devolver ao mundo o que o mundo nos diz. O
Eco ensina o princípio da coexistência: existir é repetir de modo diferente, escutar para
existir.
⸻
7. Referência Estrutural da Matriz MILK
Na Matriz Escultórica MILK – Série Folclore Vivo, o Eco de Terras de Bouro apresenta:
– Corpo: compacto, cabeça grande e oca, boca aberta em forma de arco;
– Cores: cinza-ardósia e azul profundo;
– Materiais: resina com câmara acústica interna e acabamento fosco;
– Expressão:  neutra e meditativa;
– Base: semicircular, evocando o vale e o movimento sonoro.
A escultura integra o eixo “Vozes da Montanha” do projeto Folclore Vivo, dedicado às entidades
sonoras que expressam a reciprocidade entre humanidade e paisagem.
⸻
Localização  específica: Bouro Santa Maria, Campo do Gerês, Covide e Rio Caldo (distrito de
Braga).
Primeiro relato documentado: Vasconcelos, Etnografia Portuguesa, vol. IX, 1925.
Sistematização  contemporânea:  Eduardo Mauer, O Eco de Terras de Bouro: Voz, Natureza e
Memória na Mitologia Sonora Portuguesa, Associação MILK, 2025.
Fontes primárias:  Braga (1885); Vasconcelos (1925); Parafita (2008); Coutinho (2019); Mauer
(2025).
