# 124. A Lenda da Mãe  das Brumas da Serra do Gerês (Minho–Trás-os-Montes)

**Base documental e empírica:** pesquisa documental, análise comparada de fontes públicas, sistematização de tradição oral, relatos orais de pesquisa de campo e revisão semântica conduzidas no âmbito do Folclore Vivo da Associação MILK - Movimento de Intervenções e Linguagens Kulturais e Arte.
**Estado editorial:** corpus de pesquisa de campo e documentação cultural em revisão pública.
**Regra de publicabilidade:** esta entrada não deve ser lida como prova histórica definitiva, inventário patrimonial oficial, validação etnográfica concluída ou certificação académica externa sem verificação documental própria.
**Regra jurídica/RGPD:** não publicar nomes de informantes, contactos, moradas, entrevistas integrais, imagens identificáveis, gravações, dados de menores, coordenadas sensíveis ou materiais comunitários sem autorização.
**Regra de não invenção:** a presente readequação corrige a camada editorial e metodológica sem acrescentar factos, fontes, topónimos, coordenadas ou relatos não existentes no corpus-base.
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

124. A Lenda da Mãe  das Brumas da Serra do Gerês (Minho–Trás-os-Montes)
(Sistematização  contemporânea  conduzida por Eduardo Mauer no âmbito  das pesquisas sobre
Folclore Vivo da Associação MILK – Movimento de Intervenções e Linguagens Kulturais e
Arte, com base em recolhas orais e documentais realizadas entre 2023 e 2025 em Campo do
Gerês,  Pitões das Júnias, Cabril e S. Bento da Porta Aberta, cruzadas com acervos do Parque
Nacional da Peneda-Gerês,  Museu de Arcos de Valdevez, Arquivo Distrital de Braga e estudos
sobre mitologia atmosférica,  simbologia maternal e entidades femininas elementares na tradição
ibérica.)
⸻


1. Descrição  simbólica e narrativa
Na madrugada das serras do Gerês, quando o nevoeiro se ergue dos vales e cobre tudo com um
véu de silêncio, os pastores murmuram: “Aí vem a Mãe  das Brumas.” Não se vê, sente-se — um
sopro úmido e morno, como respiração de mulher cansada. Dizem que é ela quem tece as
nuvens que dormem entre os penedos e que nenhum viajante regressa o mesmo depois de
atravessá-las.
As versões recolhidas por Eduardo Mauer (2024) descrevem-na como figura enorme, feita de
vapor e luz cinzenta. Quando quer ser vista, adota a forma de mulher idosa de cabelos longos e
molhados, envolta num manto branco que nunca seca. Carrega um cajado de teixo e conduz
consigo rebanhos invisíveis — “as ovelhas da névoa” — cujos balidos se confundem com o
vento.
Segundo a tradição, a Mãe das Brumas é guardiã  dos nascimentos e das despedidas. Surge
junto aos partos difíceis, envolvendo a casa com neblina para proteger o recém-nascido; mas
também aparece nos enterros solitários, cobrindo o caminho para que os vivos não vejam a dor
dos mortos. Em Pitões das Júnias, uma anciã entrevistada por Mauer a firmou: “Ela é o pano do
mundo — o que separa o que vai e o que fica.”
Outros relatos associam-na a antigas divindades aquáticas e montanhosas. Chamam-lhe
também “ Senhora do Ar Branco” ou “Véu do Gerês”. É simultaneamente benigna e temida:
quem a invoca em vão perde-se no nevoeiro; quem a respeita, encontra abrigo.
Há quem diga que, nos dias de calor intenso, a Mãe das Brumas se recolhe ao fundo dos lagos e
suspira. O nevoeiro que sobe é o seu suspiro transformado em forma.
Mauer sintetiza: “A Mãe das Brumas é o corpo do ar que pensa. É a respiração da montanha.”
⸻
2. Contexto histórico e social
O mito inscreve-se na ampla família das entidades atmosféricas femininas da Península Ibérica
— espíritos do vento, da chuva e da névoa, como as nubas, anjanas e dona d’aura galegas. No
Gerês, região de transição entre o Minho e Trás-os-Montes, a relação com o clima é visceral: a
sobrevivência rural dependia da leitura precisa da umidade e do vento.
A “mãe” representa força matricial: a natureza não como cenário, mas como organismo
sensível. Nas culturas pastoris, a bruma protege o gado do sol e oculta-o de predadores; logo, o
nevoeiro é percebido como manto protetor. A personificação dessa função materna gera a
figura da Mãe das Brumas.
Registos paroquiais do século XVIII mencionam procissões que “pediam à Senhora das Nuvens
para levantar o véu”, indicando um sincretismo com devoções marianas locais. O cristianismo
assimilou o mito sem o eliminar: a névoa tornou-se “lenço da Virgem”, mas o nome da Mãe das
Brumas persistiu no vocabulário oral.
Durante o século XX, com o despovoamento da serra e a criação do Parque Nacional, as
histórias migraram dos campos para a memória dos mais velhos. A Associação  MILK, ao
recolhê-las, percebeu nelas uma poderosa metáfora contemporânea da ecologia sensível: o
nevoeiro como pele entre mundos — visível e invisível, humano e natural.
⸻
3. Toponímia e variantes locais

O topónimo “Brumas” aparece em designações de cumes e vales: Corga das Brumas, Fojo da
Mãe , Caminho do Véu , Fraga da Senhora do Ar. Tais nomes constam de mapas militares e
paroquiais desde o século XIX.
Em Cabril, fala-se na “Moura da Névoa”, entidade menor que ajuda a Mãe das Brumas a
espalhar o orvalho. Em Campo do Gerês, chamam-lhe “Velha do Vento Manso”. Na Galiza,
variantes próximas são “ A Nai do Orballo” e “Dona Nebra”, reforçando a dimensão
transfronteiriça da figura.
A persistência toponímica confirma o enraizamento do mito no clima como sagrado cotidiano.
⸻
4. Primeiro relato e fontes académicas primárias
Não há menção explícita à expressão “Mãe das Brumas” nas grandes coletâneas do século XIX,
mas há registos correlatos:
– Teófilo Braga, O Povo Português  nos seus Costumes, Crenças e Tradições (1885, pp. 865–
871): descreve “senhoras do nevoeiro” e “donnas do ar” que tecem véus de nuvem para ocultar
tesouros.
– Leite de Vasconcelos, Etnografia Portuguesa, vol. X (1926, pp. 159–167): menciona aparições
nebulosas no Gerês e a crença em “brumas vivas que respiram”.
– Alexandre Parafita, Mitologia Popular Portuguesa (2008, pp. 1192–1206): interpreta as figuras
de névoa como “remanescências das deusas-mãe atmosféricas da Lusitânia”.
O primeiro registro sistematizado da designação específica Mãe  das Brumas foi realizado por
Eduardo Mauer em A Mãe  das Brumas: Respiração  e Mistério  no Gerês  (Associação MILK,
2025), a partir de 57 depoimentos orais e cruzamento de fontes paroquiais e ambientais.
Fontes complementares:
– Parque Nacional da Peneda-Gerês, Inventário  de Entidades Míticas  de Montanha (1980-2022);
– Arquivo Distrital de Braga, Registos de Devoções Meteorológicas (sécs. XVIII-XIX);
– Tese de Doutoramento de Laura Vilela, Mitologias Climáticas  do Noroeste Ibérico  (U. Minho,
2019).
⸻
5. Síntese interpretativa final
A Mãe  das Brumas é o arquétipo da maternidade atmosférica: envolve, vela, dissolve.
Representa a consciência do limite e a ternura do invisível. O nevoeiro é o gesto que protege em
vez de mostrar.
Na leitura simbólica da Associação  MILK, o mito traduz a inteligência do ar — a capacidade de
cuidar pelo encobrimento. Numa era de exposição constante, a Mãe das Brumas ensina o valor
do anonimato, do intervalo, da pausa respiratória da paisagem.
A escultura MILK criada por Eduardo Mauer segue a matriz padrão, reinterpretada em volume
translúcido: corpo compacto, contornos suaves e difusos, superfície leitosa que parece emitir
vapor. As cores variam entre branco-opalescente e cinza-prateado, com véus de resina
translúcida que se expandem em forma de manto.
Mauer escreve: “A Mãe das Brumas é o sopro do invisível a aprender corpo.”
⸻


6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer
“A Mãe das Brumas é corpo não binário do ar: nem sólido nem líquido, nem feminino nem
masculino — respiração partilhada.”
Nesta leitura, a figura simboliza a dissolução  das fronteiras. O corpo de vapor é mutável,
acolhe todas as formas. É a metáfora perfeita da identidade fluida e interdependente.
A Associação  MILK utiliza o mito em oficinas de respiração  coletiva e arte sonora, nas
quais os participantes produzem sons inspirados no nevoeiro, refletindo sobre a
coexistência e a impermanência.
⸻
7. Referência Estrutural da Matriz MILK
Na Matriz Escultórica MILK – Série Folclore Vivo, a Mãe  das Brumas apresenta:
– Corpo: compacto, mas envolto por camadas difusas de resina translúcida;
– Cores: branco-opalescente, cinza-prateado, nuances azuladas;
– Materiais: resina translúcida com pigmento perolado e vapor interno encapsulado;
– Expressão:  calma, olhos semicerrados;
– Base: circular, ligeiramente côncava, simulando poça de neblina.
Integra o eixo “Corpos de Ar e Invisibilidade” do projeto Folclore Vivo, dedicado às entidades
atmosféricas e elementares.
⸻
Localização  específica: Campo do Gerês, Pitões das Júnias, Cabril, S. Bento da Porta Aberta
(distritos de Braga e Vila Real).
Primeiro relato documentado: Vasconcelos, Etnografia Portuguesa, vol. X, 1926.
Sistematização  contemporânea:  Eduardo Mauer, A Mãe  das Brumas: Respiração  e Mistério  no
Gerês , Associação MILK, 2025.
Fontes primárias:  Braga (1885); Vasconcelos (1926); Parafita (2008); Vilela (2019); Mauer (2025).
