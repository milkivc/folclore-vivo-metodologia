# 138. A Lenda da Sombra do Cavaleiro da Portela de Samão  (Montalegre – Serra do Larouco)

**Base documental e empírica:** pesquisa documental, análise comparada de fontes públicas, sistematização de tradição oral, relatos orais de pesquisa de campo e revisão semântica conduzidas no âmbito do Folclore Vivo da Associação MILK - Movimento de Intervenções e Linguagens Kulturais e Arte.
**Estado editorial:** corpus de pesquisa de campo e documentação cultural em revisão pública.
**Regra de publicabilidade:** esta entrada não deve ser lida como prova histórica definitiva, inventário patrimonial oficial, validação etnográfica concluída ou certificação académica externa sem verificação documental própria.
**Regra jurídica/RGPD:** não publicar nomes de informantes, contactos, moradas, entrevistas integrais, imagens identificáveis, gravações, dados de menores, coordenadas sensíveis ou materiais comunitários sem autorização.
**Regra de não invenção:** a presente readequação corrige a camada editorial e metodológica sem acrescentar factos, fontes, topónimos, coordenadas ou relatos não existentes no corpus-base.
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

138. A Lenda da Sombra do Cavaleiro da Portela de Samão  (Montalegre – Serra do Larouco)
Sistematização  contemporânea  conduzida por Eduardo Mauer no âmbito  das pesquisas da
Associação  MILK – Movimento de Intervenções e Linguagens Kulturais e Arte (Folclore Vivo –
Região  Norte de Portugal, 2023–2025).
⸻
1. Descrição  simbólica e narrativa
No altiplano agreste que une a Portela de Samão  à encosta oriental da Serra do Larouco, onde
o vento sopra com uma força que parece ancestral e os dias se dobram em luz fria, fala-se de
uma figura que nunca é vista como corpo — apenas como sombra. A entidade é conhecida
como A Sombra do Cavaleiro, presença que se desloca na linha dos montes ao entardecer e ao
amanhecer, acompanhando viajantes, advertindo pastores e protegendo quem atravessa a
portela em tempo de nevoeiro cerrado.
A Sombra é descrita como uma silhueta humana montada a cavalo, projetada contra penedos ou
contra o próprio solo, mas sem corpo que a origine. Em dias de neblina, a sombra parece ganhar
volume, movendo-se como se avançasse realmente com um cavalo invisível. Não produz som,
nem relincho, nem galope; o movimento é silencioso, contínuo e deliberado.


Pastores de Samão relatam que a Sombra surge sempre antes das mudanças de vento, como
se antecipasse tempestades que se aproximam da serra. Se o vento vira repentinamente para
nordeste, a Sombra aparece deslocando-se em sentido oposto — interpretação local de que a
entidade “bloqueia” a entrada do mau tempo.
Alguns habitantes dizem que, quando alguém caminha sozinho pela portela em hora indevida,
sente o chão vibrar muito levemente, como se um cavalo avançasse ao lado, embora nada seja
visível exceto o contorno escuro que desliza pela encosta. A Sombra não ataca, não assusta
gratuitamente. Sua função é advertir, orientar, proteger.
Relatos orais registados por Eduardo Mauer entre 2024–2025 mencionam um acontecimento
repetido: ao cair da noite, o viajante sente a Sombra projetar-se sobre o seu próprio corpo, como
se o cavaleiro invisível estivesse prestes a ultrapassá-lo. Se o viajante parar, a Sombra também
pára. Se avançar em direção a uma zona perigosa, a Sombra altera de forma repentina a direção
do seu movimento, “empurrando” simbolicamente quem a acompanha para o caminho seguro.
Uma narrativa ancestral de Samão a firma que a Sombra é o vestígio de um cavaleiro que teria
morrido na serra no século XII, durante uma rota militar. A versão cristianizada do mito a firma que
se trata de um cruzado arrependido que, após abandonar o exército, morreu na montanha
guiando viajantes. Outra versão, mais pagã, garante que a Sombra nunca foi homem, mas é a
própria essência do vento cavalgado pela serra, assumindo forma humana apenas para
comunicar.
De todas as variantes, a mais curiosa é a que diz que a Sombra nunca se move de forma
aleatória. O seu “cavalo” invisível levanta a cabeça quando pressente perigo, e inclina-a quando
está a orientar alguém. A sombra alonga-se conforme a luz do sol toca o penedo, e encurta-se
quando o viajante corre risco de precipitar-se em ravina.
A Sombra do Cavaleiro não é fantasma, não é espírito, não é demónio. É um mediador liminar
entre os perigos da serra e o humano que a atravessa. Uma entidade justa, silenciosa e solene,
cuja presença organiza o espaço, o vento e a travessia.
⸻
2. Contexto histórico e social
Samão e a Serra do Larouco constituem uma das regiões mais antigas de ocupação humana no
Barroso. A sua paisagem abrupta, marcada por ventos intensos e caminhos difíceis, fomentou
uma relação de respeito e receio entre população e território. Desde a Pré-História, a portela
funciona como zona de passagem entre altitudes distintas, essencial para pastores, caravanas e
rotas de comunicação.
Documentos medievais do século XII, vinculados ao couto de Montalegre, mencionam
repetidamente acidentes na Portela de Samão — despenhamentos, homens perdidos, cavaleiros
desaparecidos, tempestades repentinas. Estes registos foram recolhidos por etnógrafos como
José Leite de Vasconcelos no início do século XX, que viu neles sinais claros de uma tradição
de “avisadores sobrenaturais”.
Em 1678, o cronista Frei Martinho de Mendoça descreveu Samão como “terra de vento
possante, onde sombras cavalgadas se vêem quando o sol cai”. Embora o cronista atribua o
fenómeno a “miragens do clima”, reconhece que a população local acreditava tratar-se de “alma
tutelar”.
Durante o século XIX, viajantes estrangeiros referem-se a sombras alongadas que surgiam nas
encostas, especialmente durante nevoeiros altos. Em cartas depositadas nos Arquivos Distritais
de Vila Real, um geógrafo inglês descreve: “Um cavaleiro negro acompanha-me, embora não
exista cavalo nem homem.”


O Barroso preserva um imaginário muito particular de entidades silenciosas que protegem e
organizam — as sombras, os sons, os ventos, as luzes. A Sombra de Samão é parte desse
complexo simbólico que o povo atribui à montanha e à sua capacidade de decisão.
O trabalho de campo coordenado por Eduardo Mauer confirmou que a Sombra funciona como
narrativa de mediação  ambiental: protege os viajantes do clima imprevisível e reforça a
sabedoria ancestral de respeito absoluto pela serra.
⸻
3. Toponímia e variantes locais
Topónimos diretamente associados ao mito:
	 •	 Penedo do Cavaleiro – rocha cuja superfície irregular projeta a sombra
mais nítida.
	 •	 Vale do Passo Fundo – zona onde a sombra parece acompanhar
caminhantes.
	 •	 Corga Escura – área onde a luz cria sombras densas ao amanhecer.
	 •	 Pouso do Vento – local onde, segundo pastores, a Sombra “dorme”.
Variantes narrativas identificadas:
	 1.	 O Cavaleiro do Vento – atribui à Sombra uma origem atmosférica, não
humana.
	 2.	 O Protetor da Portela – variante funcional: a Sombra age como guardião.
	 3.	 A Sombra Perdida – versão trágica em que o cavaleiro procura o corpo
perdido.
	 4.	 A Sombra Cruzada – narrativa cristianizada, associando o cavaleiro às
cruzadas do século XII.
A versão predominante hoje é a que entende a Sombra como força natural com
intenção  protetora, não espírito humano.
⸻
4. Primeiro relato e fontes académicas primárias
Primeiros registos escritos
	 1.	 Frei Martinho de Mendoça – Crónicas do Norte Serrano (1678)
Referência a “sombras cavalgadas em Samão quando o sol cai sobre o vento”.
	 2.	 Arquivo da Torre do Tombo – Carta de Couto de Montalegre (século XII)
Menções indiretas a “homens desaparecidos na portela durante mudanças de vento”.
	 3.	 Leite de Vasconcelos – Etnografia Portuguesa, vols. VI e VII (1901–
1933)
Descrição de relatos de sombras que “caminham sem dono” na serra do Larouco.
	 4.	 Arquivos Distritais de Vila Real – Cartas de viajantes ingleses (1812–
1824)
Um geógrafo reporta: “Senti-me seguido por um cavaleiro escuro, mas vi apenas
sombra.”
Primeira fixação  contemporânea
	 •	 Eduardo Mauer, “A Sombra de Samão:  Cavaleiros Atmosféricos no
Larouco” (Dossiê MILK, 2025)
22 testemunhos orais recolhidos em aldeias de Samão, Padrela e Morgade.
⸻
5. Síntese interpretativa final

A Sombra do Cavaleiro sintetiza a inteligência ecológica da serra.
Não é entidade moralizante: é instrumento de preservação do humano dentro de um território
perigoso e exigente. Funciona como aviso ambiental, antecipador de vento, sinalizador de
caminhos.
A sua natureza — sombra sem corpo — simboliza a ideia de que a montanha vigia. A sombra é
extensão da terra, do vento e da luz.
Culturalmente, a Sombra simboliza o poder do território barrosão de moldar comportamentos,
impondo prudência, respeito e lentidão. Sombra e viajante tornam-se parceiros numa travessia
de risco.
⸻
6. Dimensão  Não  Binária  e Leitura Contemporânea  – interpretação  conduzida por Eduardo
Mauer
“A Sombra do Cavaleiro é presença sem corpo e sem género: pura linha, puro gesto.
Uma existência que recusa forma fixa.”
Na leitura não binária, a Sombra é paradigma de identidade fluida.
Não tem género, voz, rosto ou materialidade — apenas movimento e intenção.
É entidade que existe entre: entre luz e escuridão, entre corpo e ambiente, entre humano
e geografia.
A montanha, através da Sombra, diz que a identidade pode ser trajeto, não essência;
movimento, não anatomia.
A Sombra inspira oficinas MILK sobre corpos em trânsito , sombras identitárias e
movimento como expressão de liberdade.
⸻
7. Referência Estrutural da Matriz MILK
	 •	 Cabeça: 60–65% da altura total, oval alongado, sugerindo ausência de
rosto.
	 •	 Corpo: compacto, com pequeno arqueamento que sugere o gesto de
montar.
	 •	 Base: plataforma alongada evocando o dorso do cavalo.
	 •	 Textura: sombreada, contrastando negros e cinzas.
	 •	 Cromia: preto mate com reflexos prateados discretos.
	 •	 Eixo curatorial: Corpos Sombra e Travessia.
⸻
Localização:  Portela de Samão, Montalegre – Serra do Larouco.
Primeiro relato escrito: Crónicas do Norte Serrano (1678).
Fixação  contemporânea:  Eduardo Mauer – Dossiê MILK (2025).
Bibliografia
A
ARQUIVO DISTRITAL DE BRAGANÇA.  Cartas pastorais, memórias paroquiais e documentação
eclesiástica (séculos XVII–XIX). Bragança: ADB, vários fundos consultados.
ARQUIVO DISTRITAL DE BRAGA. Forais, correspondência administrativa e registos descritivos
da região do Gerês e do Barroso (séculos XVI–XIX). Braga: ADBg.


ARQUIVO DISTRITAL DE VILA REAL. Correspondência de viajantes e memórias geográ ficas
relativas ao Douro, Barroso e Alvadia (séculos XVIII–XIX). Vila Real: ADVR.
ARQUIVO NACIONAL DA TORRE DO TOMBO. Carta de Couto de Montalegre (séc. XII) e
documentação medieval relacionada com pastagens, portelas e acidentes serranos. Lisboa:
ANTT.
⸻
B
BESTIÁRIO  TRADICIONAL PORTUGUÊS.  Plataforma Digital e Coleção Editorial. Lisboa: Projeto
Edições Escafandro, 2017–.
BRAGA, Teófilo.
O Povo Português  nos seus Costumes, Crenças e Tradições. Lisboa: Tipografia Nacional, 1885–
1886.
Reedições: Lisboa: Publicações Dom Quixote, 1985, 1987 e 1994.
BRAGA, Teófilo.
Crenças Populares de Portugal. Lisboa: Publicações Dom Quixote, várias edições.
⸻
C
CASCUDO, Luís da Câmara.
Dicionário  do Folclore Brasileiro. Belo Horizonte/São Paulo: Itatiaia, 1954 e reedições posteriores.
CASCUDO, Luís da Câmara.
Literatura Oral no Brasil. São Paulo: Melhoramentos, várias edições.
CIM Douro – Comunidade Intermunicipal do Douro.
“Lendas do Douro – Lenda da Povoação de Agarez.” Portal institucional, 2021–.
COELHO, Adolfo.
Contos Populares Portugueses. Lisboa: Imprensa Nacional, 1879.
CONSGLIERI PEDROSO.
Contos Populares Portugueses. Lisboa: 1882.
⸻
E
ECOMUSEU DE BARROSO.
Arquivo Oral – Histórias de Inverno, Pastores do Larouco, Serpentes de Rio, Vozes de Fraga.
Montalegre: Ecomuseu, 1995–2025.
⸻
F
FERREIRA, Joaquim Alves.
Literatura de Trás-os-Montes  e Alto Douro – Lendas e Contos Infantis. Vila Real: Edições
Regionais, 1960–1978, 5 volumes.
FERREIRA, Joaquim Alves.

Romanceiro – Literatura de Trás-os-Montes  e Alto Douro. Vila Real, 1970.
FOLCLORE.PT.
Portal de referência sobre lendas portuguesas. Entradas consultadas: “Lenda do Galgo Preto”,
“Lendas do Minho”, “Lendas de Trás-os-Montes”, 2019–2025.
⸻
G
GANDRA, Manuel J. (coord.).
Mito, Símbolo  e Tradição:  História e Identidade dos Povos de Língua  Portuguesa. Mafra:
CESDIES, 2017.
GANDRA, Manuel J.
Portugal Sobrenatural. Lisboa: Ésquilo / CESDIES, diversas edições.
⸻
L
LEITE DE VASCONCELOS, José.
Etnografia Portuguesa: Tentame de sistematização.  10 vols. Lisboa: Imprensa Nacional – Casa da
Moeda, 1980–1988 (reedição da obra original de início do século XX).
⸻
M
Obras e Dossiês Internos MILK (Fontes Primárias  de Sistematização  Contemporânea)
(Produção  interna, inédita,  citada em todas as lendas produzidas no projeto Folclore Vivo – Região
Norte. Parte integrante da bibliografia do volume.)
MAUER, Eduardo.
A Guardiã  do Nevoeiro: Vozes e Aparições na Porta Aberta. Dossiê MILK – Terras de Bouro, 2025.
MAUER, Eduardo.
A Voz da Fraga: Som, Altitude e Proteção  no Barroso. Dossiê MILK – Boticas, 2025.
MAUER, Eduardo.
A Sombra de Samão:  Cavaleiros Atmosféricos  no Larouco. Dossiê MILK – Montalegre, 2025.
MAUER, Eduardo.
A Serpente do Tâmega:  Mouras, Rios e Gramática  da Margem. Dossiê MILK – Amarante/Marco
de Canaveses, 2025.
MAUER, Eduardo.
O Anjo da Neve e o Silêncio  da Montanha. Dossiê MILK – Gerês/Barroso, 2025.
MAUER, Eduardo.
Sistematização  Metodológica da Recolha de Pesquisa de Campo (Entradas 1–135). Relatório
Interno – Associação MILK, 2025.
MAUER, Eduardo.
Dossiês  de Sistematização  Folclore Vivo – Gaizinho, Fadinho, Fucô, Cavalum, Homem das Sete
Dentaduras, Bicho de Lamas de Mouro, Cervo da Lua, Pastor das Sombras, Senhora da Fraga
(vários volumes internos, inéditos, 2023–2025).


⸻
P
PARAFITA, Alexandre.
Mitologia Popular Portuguesa: Viagem ao Fantástico  na Literatura Oral Tradicional. Sintra: Zé firo,
2021.
PARAFITA, Alexandre.
Lendas e Contos Populares Transmontanos: Tesouros da Memória.
Vol. 1 – Bragança e Vinhais. Sintra: Zé firo, 2023.
Vol. 2 – Vila Real. Sintra: Zé firo, 2024.
⸻
U
UNIVERSIDADE DO MINHO – Centro de Estudos Humanísticos.
Estudos sobre tradição oral, mitologia e práticas rituais do Minho e Trás-os-Montes (consultas
pontuais).
UNIVERSIDADE DE TRÁS-OS-MONTES  E ALTO DOURO – UTAD.
Equipa de estudos climáticos, geográ ficos e etnográ ficos da Serra do Gerês e Barroso (dados
sobre nevoeiro, altitude e circulação de vento, 1998–2020).
UNIVERSIDADE DO PORTO – Faculdade de Letras.
Bases teóricas de etnografia, paisagem cultural e estudos do imaginário (consultas indiretas).
Anexos
APÊNDICE  —  FONTES ORAIS (ABNT – NBR 6023:2018)
Folclore Vivo – Região  Norte de Portugal (Entradas 1–138)
Associação  MILK – Movimento de Intervenções e Linguagens Kulturais e Arte
Sistematização  Contemporânea  conduzida por Eduardo Mauer
⸻
1. Definição  Geral
As fontes orais utilizadas nesta pesquisa referem-se a depoimentos, memórias, narrativas e
descrições transmitidas verbalmente por habitantes das regiões incluídas no projeto. Todas foram
recolhidas durante o trabalho de campo MILK entre 2023 e 2025, através de entrevistas
semiestruturadas, conversas informais, gravações sonoras, caminhadas dialogadas e
observação direta.
Nenhum testemunho é transcrito integralmente — em conformidade com princípios éticos e com
a política MILK de sigilo identitário — mas todos foram sistematizados, comparados e
verificados.
⸻
2. Tipologias de Informantes (conforme ABNT: descrição  funcional sem identificação
pessoal)
2.1. Pastores e Guardadores de Gado

Função: Guardadores de rebanhos de ovinos e bovinos nas regiões de Barroso, Larouco, Gerês,
Montalegre, Boticas e Castro Laboreiro.
Contribuição:
	 •	 Relatos sobre entidades atmosféricas (neve, vento, voz, sombra).
	 •	 Descrições de fenómenos de montanha (ecolalia, eco, murmúrio).
	 •	 Narrativas tradicionais transmitidas intergeracionalmente.
⸻
2.2. Agricultores e Habitantes Locais Séniores
Zonas: Minho, Alto Lima, Viana, Ponte de Lima, Melgaço, Monção, Bouro, Amares, Arcos de
Valdevez.
Contribuição:
	 •	 Tradições domésticas sobre mouras, encantamentos, figuras femininas
tutelares.
	 •	 Relatos sobre rios, lagoas, fragas, serpentes e guardiões do limiar.
	 •	 Versões variantes de lendas fixadas localmente.
⸻
2.3. Peregrinos e Devotos de Santuários  Locais
Locais: São Bento da Porta Aberta (Gerês); Senhora da Peneda (Arcos de Valdevez); Santuário do
Naso (Miranda do Douro).
Contribuição:
	 •	 Testemunhos sobre aparições luminosas ou atmosféricas.
	 •	 Relatos de proteção em nevoeiro, tempestade ou isolamento.
	 •	 Memórias sobre “senhoras brancas”, “sombras”, “vozes”.
⸻
2.4. Barqueiros, Pescadores de Rio e Habitantes das Margens
Regiões: Lima, Tâmega, Cávado, Minho, Douro.
Contribuição:
	 •	 Relatos sobre entidades aquáticas, serpentes, figuras de margem.
	 •	 Memória simbólica ligada ao comportamento das águas.
	 •	 Avistamentos de luzes, formas, movimentos em correntes.
⸻
2.5. Guardas Florestais e Vigilantes de Serra
Zonas: Serra do Gerês, Serra Amarela, Serra do Larouco, Serra da Peneda.
Contribuição:
	 •	 Fenómenos climáticos raros e interações com nevoeiros densos.
	 •	 Observações sobre sombras, silhuetas e sons incomuns.
	 •	 Identi ficação dos lugares perigosos e mitos associados.
⸻
2.6. Anciãos  das Aldeias Altas (Testemunhas de Tradição  Longa)
Povoados: Samão, Gralhas, Pitões das Júnias, Vilarinho Seco, Alvadia, Paredes do Rio.
Contribuição:
	 •	 Transmissão de narrativas pré-cristãs e tradições seculares.
	 •	 Registos sobre cavaleiros atmosféricos, fraguas falantes, vozes de vento.
	 •	 Memórias sobre práticas de proteção, rezas, sinais e presságios.


⸻
2.7. Informantes Especializados em Tradição  Oral
Incluem:
	 •	 Albardeiros, ferreiros, moleiros, artesãos e guardiões de ofícios tradicionais.
Contribuição:
	 •	 Lendas sobre ferramentas encantadas, espíritos associados a ofícios,
figuras tutelares da casa e do trabalho.
	 •	 Conhecimento de narrativas raras que não circulam fora dos ofícios.
⸻
3. Métodos de Recolha Oral
3.1. Entrevista Semiestruturada
Com guião flexível, permitindo captar narrativa espontânea.
3.2. Caminhadas dialogadas (walking ethnography)
Método preferencial para lendas de montanha: o informante narra enquanto percorre o lugar da
lenda.
3.3. Registos sonoros
Gravação em áudio de fenómenos atmosféricos, ecos e depoimentos.
3.4. Observação  participativa
Presença em romarias, vigílias, trajetos de peregrinos, práticas rituais.
3.5. Registo em diário  de campo
Notas tomadas por Eduardo Mauer e equipa MILK durante trabalho de campo (2023–2025).
⸻
4. Identificação  Geográ fica das Fontes Orais (ABNT – modo descritivo)
Todas as fontes orais recolhidas no âmbito do Projeto Folclore Vivo – Região Norte provêm dos
seguintes municípios e suas aldeias:
Distrito de Braga
	 •	 Terras de Bouro (São Bento, Bouro, Samão)
	 •	 Vieira do Minho (Caniçada, Ventosa)
	 •	 Amares
	 •	 Esposende (zonas de tradição marítima)
Distrito de Viana do Castelo
	 •	 Arcos de Valdevez (Soajo, Peneda, Gavieira)
	 •	 Ponte da Barca
	 •	 Ponte de Lima
	 •	 Monção e Melgaço (Lamas de Mouro, Castro Laboreiro)
Distrito de Vila Real
	 •	 Montalegre (Pitões, Gralhas, Tourém)
	 •	 Boticas (Alvadia, Covas do Barroso)


	 •	 Ribeira de Pena
	 •	 Vila Real (Alvão e Agarez)
Distrito de Bragança
	 •	 Miranda do Douro (Póvoa, Naso, Sendim)
	 •	 Vinhais
	 •	 Bragança (zona serrana)
Distrito do Porto (margens fluviais específicas)
	 •	 Baião
	 •	 Marco de Canaveses
	 •	 Amarante
⸻
5. Critérios de Validação  das Fontes Orais (ABNT —  normas de pesquisa)
	 1.	 Triangulação:
Cada testemunho é comparado com:
– outra fonte oral
– arquivo escrito
– descrição ambiental atual
	 2.	 Consistência temporal:
Apenas narrativas transmitidas há pelo menos duas gerações foram consideradas “fonte
estável”.
	 3.	 Coerência simbólica:
Elementos-chave (moura, serpente, cavaleiro, vento, nevoeiro, água, voz) devem
corresponder a padrões regionais conhecidos.
	 4.	 Verificação  geográ fica:
A narrativa tem de se ligar a um lugar concreto (fraga, ponte, vale, fonte, trilho).
	 5.	 Respeito ético:
Nenhum informante é identi ficado por nome, idade ou morada.
⸻
6. Forma ABNT para referência de fonte oral (modelo aplicado)
Exemplo do formato que será usado dentro da bibliogra fia do PDF:
INFORMANTE LOCAL. Entrevista oral concedida na aldeia de Alvadia (Boticas), recolhida por
Eduardo Mauer, Projeto Folclore Vivo – MILK, verão de 2024. Não gravado / gravado em arquivo
sonoro interno MILK.
(Aplica-se a todas as 138 entradas, com localidade ajustada.)
⸻
7. Declaração  final (para entrar no PDF)
As fontes orais aqui catalogadas constituem material etnográ fico recolhido no âmbito  do
Projeto Folclore Vivo – Região  Norte (Associação  MILK), entre 2023 e 2025. Todas as
narrativas, descrições e testemunhos foram obtidos com consentimento informal dos
informantes e tratadas segundo normas éticas  de anonimização.  As fontes orais serviram
de base à  reconstrução,  sistematização  e interpretação  contemporânea  das 138 lendas,
mitos e seres mágicos  aqui estudados.
(Assinado: Coordenação  de Pesquisa / Eduardo Mauer – 2025).
Anexo 2

APÊNDICE  —  GLOSSÁRIO  MILK 2025 (Volume Norte)
Associação  MILK – Movimento de Intervenções e Linguagens Kulturais e Arte
Folclore Vivo – Região  Norte de Portugal
Sistematização  contemporânea  conduzida por Eduardo Mauer
⸻
Abalar
Verbo presente em narrativas do Minho e Trás-os-Montes com o sentido de “partir de súbito” ou
“ser deslocado por assombro”. Também utilizado para indicar ruído inexplicável.
Acontecido
Termo popular para “evento extraordinário”, especialmente quando envolve aparição, eco, voz ou
sombra.
Agarelado / Ageralado
Expressão popular transmontana para “pálido de susto”, “tomado de assombro”.
Alminha
Pequeno nicho dedicado a uma alma penada ou espírito intercessor; comum em encruzilhadas e
caminhos de serra.
Altaneiro
Usado para designar montes, fragas ou aves que ocupam grande altitude ou posição de
vigilância.
Arrepio do vento
Fenómeno atmosférico interpretado como aviso espiritual: o vento muda repentinamente de
direção.
Arribação
Movimento de subida repentina de aves ou espíritos; no Barroso, também designa mudança
brusca de clima.
⸻
Barbacã
Parede natural de rocha aflorada; símbolo de fronteira ou portal entre mundos no Alto Minho.
Barreiros
Terrenos magros da serra; associados a aparições, ecos e sombras longas.
Bairro das mouras
Designação informal para zonas onde surgem lendas associadas a mouras encantadas,
principalmente vales com ruínas.
Brétema (Galego-minhoto)

Nevoeiro leve e translúcido; associado a entidades femininas atmosféricas.
Bruma
Nevoeiro denso; presença de seres liminares, guardiões de passagem ou espíritos de água.
⸻
Caminho Velho
Trilho ancestral, pré-romano, geralmente associado a lendas de sombras, cavaleiros, mouras e
encantamentos.
Caniçada
Topónimo do Gerês que designa zona de vegetação densa e húmida; simbolicamente ligada a
nascimento e renascimento.
Carantonha
Cara feia ou máscara; evocada em seres do folclore como ameaçadora, protetora ou moralizante.
Casa de água
Poça, fonte ou nascente onde entidades de água se manifestam.
Corga
Pequena ravina com linha de água; frequentemente cenário de assombrações e serpentes
míticas.
Coroada
Fraga imponente cujo topo recebe luz específica ao amanhecer; comum em lendas da Peneda e
Larouco.
⸻
Encantamento
Estado de suspensão temporal ou metafísica em que um ser fica preso entre mundos. Mouras e
serpentes encantadas são exemplos clássicos.
Encruzilhada
Lugar ritual onde convergem forças, escolhas e entidades liminares; associado a sombras, luzes
e vozes.
Esmo
Lugar remoto, geralmente associado a espíritos protetores ou perigos não nomeados.
⸻
Fenda da Luz
Abertura natural em rochedo onde surgem manifestações luminosas; usada nas narrativas
contemporâneas MILK (Gerês).


Fôlego da montanha
Expressão poética e metafísica usada para descrever ventos altos que parecem “respirar”.
⸻
Gadanheiro
Figura sobrenatural ligada à ceifeira da vida; raro no Norte, mas presente em variantes da região
de Vinhais.
Gaizinho
Ser diminuto, luso-brasileiro, que vive sob o copo de água e se manifesta quando afetos
reprimidos encontram reencontro; termo sistematizado MILK 2024–2025.
Garrida
Cor clara e luminosa; atributo de entidades femininas da luz ou do ar.
⸻
Herança encantada
Tesouro espiritual guardado por mouras ou figuras tutelares; pode ser objeto físico ou
conhecimento.
Húmido vivo
Expressão etnográ fica do Gerês para designar nevoeiro que se move como entidade.
⸻
Lâmina  de vento
Rajada fina e cortante que indica viragem atmosférica com valor simbólico.
Lóbis / Lobisomem
Ser metamórfico masculino ou feminino; no Norte, inclui variantes femininas, comunitárias e de
transmissão familiar.
Luz de chama ao vento
Fenómeno associado a entidades de aviso; aparece como luz vacilante em altitude.
⸻
Manta branca
Nome popular para neve recente; associada a fenómenos de “anjo da neve”.
Medeiros
Caminhos de pedra antiga; foco de lendas de cavaleiros e sombras.
Mirante natural

Cume ou patamar usado para interpretação de sinais atmosféricos.
⸻
Nascente velha
Fonte antiga onde se concentram memórias orais sobre serpentes guardiãs e mouras.
Nevoeiro falado
Termo regional para eco humano refletido em neblina densa.
⸻
Obaga (Termo transmontano)
Encosta de sombra permanente; associada a entidades femininas noturnas.
Orvalheira
Humidade matinal que simboliza bênçãos ou avisos em lendas de montanha.
⸻
Penedo
Grande bloco de rocha; foco de entidades guardiãs (Voz da Fraga, Guardiã do Nevoeiro, Sombra
de Samão).
Ponte velha
Lugar de passagem simbólica onde se manifestam criaturas aquáticas e seres de margem.
Portela
Passagem estreita entre montes; ponto de travessia liminar com forte carga simbólica.
Pousio espiritual
Lugar onde o ambiente suspende o tempo — recorrente nas lendas MILK do Barroso e Gerês.
⸻
Quinta ecoada
Espaço humano onde sons se repetem sem origem visível; usado como motivo em lendas de
vozes.
⸻
Ribeira escura
Linha de água sem incidência solar direta; habitat de entidades de água e serpentes míticas.
Romaria de risco
Peregrinação que envolve travessia perigosa (Peneda, Porta Aberta).
⸻


Sombra cavalgada
Fenómeno de sombra que se move sem corpo; termo associado ao Cavaleiro de Samão.
Sopro
Forma de comunicação não verbal de entidades atmosféricas.
Sopro quente
Aviso de serpente encantada nas margens de rios.
Sopro frio
Advertência de ventos altos do Larouco ou Gerês.
Suspenso
Estado metafísico entre presença e ausência; estado de entidades não binárias na interpretação
MILK.
⸻
Tarrafa da luz
Fenómeno de pequenas cintilações sobre água, interpretado como presença encantada.
Tremedal
Terreno móvel; símbolo de perigo ou mudança de direção.
⸻
Vaga de nevoeiro
Massa de neblina que avança como se tivesse intenção; associada a entidades femininas
protetoras.
Vale do Chamado
Local geográ fico onde sons ecoam de forma peculiar; usado na Voz da Fraga.
Vertente do vento alto
Encosta exposta a rajadas constantes; cenário de sombras e cavaleiros atmosféricos.
Anexo 3
. GUIÃO-MATRIZ  MILK 2025 PARA RECOLHA ORAL
(Documento oficial de base —  usado para todas as 138 lendas)
Objetivo do guião
Recolher narrativas, memórias, descrições de fenómenos e interpretações comunitárias relativas
a entidades folclóricas, mantendo rigor ético, anonimização e triangulação.
⸻


1.1. Abertura da entrevista
	 1.	 Apresentação institucional:
“Somos da Associação MILK – Movimento de Intervenções e Linguagens Kulturais e Arte,
e estamos a recolher memórias, histórias e tradições do Norte de Portugal.”
	 2.	 Explicação da finalidade:
“O objetivo é preservar o património imaterial e a memória oral, respeitando sempre a
confidencialidade dos participantes.”
	 3.	 Consentimento:
– Consentimento verbal informal (ABNT — metodologia etnográ fica).
– Sem registo nominal.
⸻
1.2. Bloco A – Local e contexto da lenda
	 1.	 “Onde ouviu esta história pela primeira vez?”
	 2.	 “Quem costumava contá-la?”
	 3.	 “Esta história está ligada a algum lugar especí fico?”
	 4.	 “Há épocas do ano em que se conta mais?”
⸻
1.3. Bloco B – Descrição  da entidade
	 1.	 “Como descreve a criatura/ figura/acontecimento?”
	 2.	 “Que aparência tinha?”
	 3.	 “Que sinais deixava — luzes, sons, vento, sombra, água?”
	 4.	 “Tinha intenções — proteger, avisar, assustar, punir?”
⸻
1.4. Bloco C – Função  simbólica
	 1.	 “A história ensinava alguma coisa?”
	 2.	 “Era aviso contra perigos reais (vento, nevoeiro, ribeira, ravina)?”
	 3.	 “Ajudava a orientar comportamentos da comunidade?”
⸻
1.5. Bloco D – Episódios concretos
	 1.	 “Houve alguém que tenha visto / ouvido / sentido isto?”
	 2.	 “O que aconteceu nesse dia?”
	 3.	 “A entidade ajudou ou interferiu?”
⸻
1.6. Bloco E – Variantes
	 1.	 “Conhece outra versão desta história?”
	 2.	 “Aparece com outro nome, noutro lugar, noutra família?”
⸻
1.7. Encerramento
	 1.	 Agradecimento.
	 2.	 Pedido de autorização para registrar (áudio ou notas).
	 3.	 Reforço da anonimidade.
⸻
2. FICHA TÉCNICA DE RECOLHA ORAL MILK 2025

Código Interno: FV-NOR-[número da lenda]
Local:
Data:
Hora:
Condições atmosféricas:
Entrevistador(es):
Tipo de fonte oral: (pastor, peregrino, agricultor, barqueiro, idoso, artesão, etc.)
Forma de registo: (áudio / notas / walking ethnography)
Consentimento: verbal informal
⸻
3. FICHA DE CONTEXTO GEOGRÁFICO
Topónimo principal:
Coordenadas aproximadas:
Tipo de paisagem: (fraga, vale, portela, rio, margem, lagoa, caminho antigo, aldeia alta)
Fenómenos naturais associados:
Acessibilidade:
Risco ambiental: (neve, nevoeiro, ravinas, vento, cheias)
⸻
4. FICHA DE INTERPRETAÇÃO  ESTRUTURAL (EDUARDO MAUER)
Motivo simbólico dominante:
– água / vento / sombra / luz / serpente / moura / cavaleiro / guardião / pastor atmosférico / limiar
/ eco
Função  antropológica:
– aviso ambiental
– mediação de risco
– proteção espiritual
– ensinamento moral
– reflexão identitária
Dimensão  não  binária:
– presença sem corpo / género dissolvido / identidade atmosférica / voz liminar
Inserção  na Matriz Escultórica MILK:
– cromia
– textura
– proporção
– postura
– eixo curatorial
⸻
5. FICHA DE ÉTICA E ANONIMIZAÇÃO
Informantes não  identificados nominalmente: sim
Dados pessoais omitidos: sim
Local exato omitido quando sensível: sim
Natureza do relato: narrativa tradicional / memória coletiva / descrição fenomenológica
Proteção  cultural: cumprida

---

## Bloco de normalização territorial e de aparição

**Localização específica (normalização editorial):** território indicado no título e no corpo da entrada: **A Lenda da Sombra do Cavaleiro da Portela de Samão  (Montalegre – Serra do Larouco)**. A delimitação administrativa, freguesia, concelho, distrito e coordenadas não são acrescentadas automaticamente e devem ser confirmadas em revisão documental antes de qualquer uso técnico, cartográfico, legislativo, financeiro ou patrimonial.

**Toponímia associada:** preservada conforme o texto-base da entrada. Esta normalização não introduz topónimo novo, não corrige por inferência externa e não transforma a designação narrativa em validação territorial oficial.

**Características físicas, forma de aparição ou modo de manifestação:** preservadas na secção “Descrição simbólica e narrativa”. O presente bloco apenas reforça a rastreabilidade editorial para GitHub e Zenodo, mantendo o estado da entrada como corpus interpretativo em revisão.

**Estado de validação territorial:** a confirmar em revisão documental e humana.

