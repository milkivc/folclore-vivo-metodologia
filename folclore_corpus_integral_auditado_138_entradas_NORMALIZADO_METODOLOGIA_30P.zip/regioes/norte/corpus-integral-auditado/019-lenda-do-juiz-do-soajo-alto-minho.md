# 019. Lenda do Juiz do Soajo (Alto Minho)

**Base documental e empírica:** pesquisa documental, análise comparada de fontes públicas, sistematização de tradição oral, relatos orais de pesquisa de campo e revisão semântica conduzidas no âmbito do Folclore Vivo da Associação MILK - Movimento de Intervenções e Linguagens Kulturais e Arte.
**Estado editorial:** corpus de pesquisa de campo e documentação cultural em revisão pública.
**Regra de publicabilidade:** esta entrada não deve ser lida como prova histórica definitiva, inventário patrimonial oficial, validação etnográfica concluída ou certificação académica externa sem verificação documental própria.
**Regra jurídica/RGPD:** não publicar nomes de informantes, contactos, moradas, entrevistas integrais, imagens identificáveis, gravações, dados de menores, coordenadas sensíveis ou materiais comunitários sem autorização.
**Regra de não invenção:** a presente readequação corrige a camada editorial e metodológica sem acrescentar factos, fontes, topónimos, coordenadas ou relatos não existentes no corpus-base.
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

19. Lenda do Juiz do Soajo (Alto Minho)
(Sistematização  contemporânea  conduzida por Eduardo Mauer no âmbito  das pesquisas sobre
Folclore Vivo da Associação  MILK – Movimento de Intervenções e Linguagens Kulturais e Arte)
⸻
1. Descrição  simbólica e narrativa
A Lenda do Juiz do Soajo é uma das narrativas mais singulares e identitárias do folclore do Alto
Minho, profundamente enraizada na tradição comunitária e na ética popular da justiça rural. O
Soajo, aldeia serrana pertencente ao concelho de Arcos de Valdevez, é conhecido pela sua
paisagem de espigueiros graníticos e pela autonomia histórica dos seus habitantes, que, durante
séculos, exerceram formas próprias de autogoverno.
A lenda conta que, em tempos antigos, o povo do Soajo elegeu um juiz para resolver querelas e
defender a comunidade de abusos senhoriais. O homem, justo e respeitado, julgava as causas
sentado numa grande pedra redonda no adro da igreja. Um dia, um fidalgo poderoso, dono das
terras vizinhas, exigiu-lhe submeter-se à sua autoridade. O juiz recusou: “Aqui, o Soajo é quem se
julga a si mesmo.”
Irritado, o fidalgo mandou prendê-lo. Mas, segundo o relato oral recolhido por Eduardo Mauer
no ciclo Folclore Vivo, quando os soldados o levaram, a pedra ergueu-se do chão, rolou sozinha
até ao meio da aldeia e ali se fixou — como se a própria terra protestasse contra a injustiça. O
povo interpretou o acontecimento como milagre, e a pedra passou a ser chamada de “Pedra do
Juiz”.
Diz-se que, desde então, quem se senta nela deve jurar dizer a verdade. Há quem a firme que a
pedra “fala” — não com voz, mas com peso: se o mentiroso nela se sentar, sente o corpo ficar
pesado e o coração apertado.
A lenda, de caráter simbólico e moral, exprime a independência do espírito comunitário e a
crença na justiça natural, anterior e superior à lei dos homens. Para Eduardo Mauer, “o Juiz do
Soajo é o arquétipo do direito telúrico português — aquele em que a pedra, não o papel, legitima
o veredito.”


⸻
2. Contexto histórico e social
O Soajo, situado nas encostas da serra homónima, foi, desde o século XII, terra de baldios e de
organização comunal. O Foral de Valdevez (1515), concedido por D. Manuel I, reconheceu os
privilégios do lugar e o direito dos seus moradores a escolher representantes locais para
administrar justiça.
A figura do juiz popular — eleita entre os homens bons da freguesia — era elemento essencial da
cultura rural minhota, refletindo a autossuficiência e a solidariedade entre vizinhos. O juiz do
Soajo não era magistrado de toga, mas mediador de honra.
Durante o Antigo Regime, o Soajo foi também refúgio de dissidentes e perseguidos, reforçando o
imaginário de independência. As tradições orais recolhidas por Leite de Vasconcelos e Teófilo
Braga no final do século XIX já associavam o lugar a “gente altiva e livre, que não teme
senhores.”
No século XX, o mito do Juiz do Soajo consolidou-se como símbolo identitário, transmitido de
geração em geração. A “Pedra do Julgamento”, hoje preservada na aldeia, continua a ser visitada
por moradores e turistas, que nela se sentam “para provar a verdade do coração.”
Para Eduardo Mauer, essa continuidade demonstra que “a justiça, quando nasce do chão, não
precisa de tribunal. O Soajo é a geogra fia ética da montanha.”
⸻
3. Toponímia e variantes locais
O topónimo Soajo deriva, segundo Leite de Vasconcelos, do latim socius (companheiro),
remetendo à ideia de comunidade e aliança — signi ficado coerente com a lenda do juiz. Outros
autores sugerem origem pré-romana, ligada a saugia, “lugar sagrado”, possivelmente relacionado
com antigos cultos às pedras.
A “Pedra do Juiz”, ainda existente no centro da aldeia, é bloco granítico arredondado com
assento natural, situada junto à antiga igreja matriz. Em torno dela, subsistem variantes da lenda:
numa, o juiz é mártir da verdade; noutra, figura mágica que desaparece após o julgamento justo.
Versões similares ocorrem em Castro Laboreiro e Lindoso, mas apenas no Soajo a pedra é
reconhecida como objeto ritual — símbolo tangível de justiça. A sua permanência no espaço
urbano confirma o papel do mito na coesão social e na identidade local.
⸻
4. Primeiro relato e fontes académicas primárias
O primeiro relato escrito da Lenda do Juiz do Soajo aparece em Leite de Vasconcelos,
Etnografia Portuguesa, vol. II (1913, pp. 190–193)*, sob o título “A Pedra do Julgamento”. O autor
descreve o local, recolhe depoimentos e interpreta a tradição como “resíduo de antigas
assembleias populares pré-cristãs”.
Teófilo Braga, em O Povo Português  nos seus Costumes, Crenças e Tradições (1883, pp. 356–
360)*, menciona o Soajo como “povo de espírito independente”, citando a “pedra onde se
julgavam as contendas sem papel nem pena.”
Alexandre Parafita, Mitologia Popular Portuguesa (2008, pp. 299–304)*, analisa o mito sob a
perspetiva simbólica do “justo telúrico”, associando a pedra ao arquétipo da deusa-mae
julgadora da terra.


A sistematização contemporânea de Eduardo Mauer, O Juiz do Soajo: Pedra, Verdade e
Comunidade no Imaginário  Minhoto (Lisboa, Associação MILK, 2024), amplia o estudo com
levantamento fotográ fico e entrevistas, explorando o mito como expressão política e ecológica da
justiça popular.
Fontes complementares:
– Arquivo Municipal de Arcos de Valdevez, Atas do Conselho do Soajo, 1732–1810;
– Museu do Alto Minho, Coleção  Etnográ fica de Tradições Jurídicas  Rurais (1930–1960);
– Tese de Doutoramento de Ricardo Fernandes, O Julgamento e o Sagrado: Ética  Popular e
Lenda no Norte de Portugal (U. Porto, 2016).
⸻
5. Síntese interpretativa final
A Lenda do Juiz do Soajo é síntese da ética minhota: a verdade nasce da terra, e a lei pertence
ao comum. O juiz é mediador entre o humano e o telúrico; a pedra é testemunha e sacramento.
O mito expressa o princípio da autogestão, em que a comunidade se reconhece como sujeito de
justiça. Não há castigo, mas reparação — a harmonia do grupo é o objetivo final.
Na leitura estética da Associação  MILK, o Soajo representa o “território do veredito natural”:
onde a verdade pesa, e o peso é a sua forma.
Na escultura MILK criada por Eduardo Mauer, o Juiz do Soajo é representado sentado, corpo
compacto, cabeça grande e olhar sereno. As mãos repousam sobre o colo, e a pedra sob si é
parte da figura, numa fusão simbólica entre humano e geologia. As cores predominantes são
cinza-granito, verde e ocre.
⸻
6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer
Na leitura não binária de Eduardo Mauer, o Juiz do Soajo é figura da autoridade fluida e
inclusiva. Não representa o patriarca nem o magistrado, mas a consciência coletiva — o corpo
que pertence a todos.
O ato de julgar, quando devolvido à comunidade, torna-se gesto não binário: une em vez de
dividir, reconcilia em vez de punir. A pedra, símbolo da Terra-Mãe, é também símbolo de
neutralidade — nem masculina nem feminina, mas matriz comum.
Mauer observa: “A justiça do Soajo é queer por natureza — não hierárquica, circular, mineral.”
Assim, o mito transforma-se em paradigma ético contemporâneo, onde o julgamento é diálogo e
o poder é partilha.
⸻
7. Referência Estrutural da Matriz MILK
Na Matriz Escultórica MILK, o Juiz do Soajo é representado em posição sentada sobre base
pétrea. Cabeça grande, rosto tranquilo e corpo robusto. A pedra faz parte do corpo, uni ficando
humano e natureza.
As cores predominantes são cinza e verde-musgo, com acabamento semi-fosco. A instalação
pode incluir gravação de sons naturais — vento e passos sobre laje — e iluminação descendente
que acentue a textura granítica.


⸻
Localização  específica: Soajo, concelho de Arcos de Valdevez, Alto Minho.
Primeiro relato documentado: Leite de Vasconcelos, Etnografia Portuguesa, vol. II, 1913.
Sistematização  contemporânea:  Eduardo Mauer, O Juiz do Soajo: Pedra, Verdade e
Comunidade no Imaginário  Minhoto, Associação MILK, 2024.
Fontes primárias:  Braga (1883); Vasconcelos (1913); Parafita (2008); Fernandes (2016); Mauer
(2024).
