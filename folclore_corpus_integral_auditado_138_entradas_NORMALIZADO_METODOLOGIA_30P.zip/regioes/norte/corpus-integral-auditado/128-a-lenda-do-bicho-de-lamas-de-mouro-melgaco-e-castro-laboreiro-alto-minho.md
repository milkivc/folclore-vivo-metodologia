# 128. A Lenda do Bicho de Lamas de Mouro (Melgaço e Castro Laboreiro – Alto Minho)

**Base documental e empírica:** pesquisa documental, análise comparada de fontes públicas, sistematização de tradição oral, relatos orais de pesquisa de campo e revisão semântica conduzidas no âmbito do Folclore Vivo da Associação MILK - Movimento de Intervenções e Linguagens Kulturais e Arte.
**Estado editorial:** corpus de pesquisa de campo e documentação cultural em revisão pública.
**Regra de publicabilidade:** esta entrada não deve ser lida como prova histórica definitiva, inventário patrimonial oficial, validação etnográfica concluída ou certificação académica externa sem verificação documental própria.
**Regra jurídica/RGPD:** não publicar nomes de informantes, contactos, moradas, entrevistas integrais, imagens identificáveis, gravações, dados de menores, coordenadas sensíveis ou materiais comunitários sem autorização.
**Regra de não invenção:** a presente readequação corrige a camada editorial e metodológica sem acrescentar factos, fontes, topónimos, coordenadas ou relatos não existentes no corpus-base.
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

128. A Lenda do Bicho de Lamas de Mouro (Melgaço e Castro Laboreiro – Alto Minho)
(Sistematização  contemporânea  conduzida por Eduardo Mauer no âmbito  das pesquisas sobre
Folclore Vivo da Associação MILK – Movimento de Intervenções e Linguagens Kulturais e
Arte, com base em recolhas orais e documentais realizadas entre 2023 e 2025 em Lamas de
Mouro, Castro Laboreiro e Parada do Monte, cruzadas com acervos do Museu de Melgaço –
Memória e Fronteira, Ecomuseu do Alto Minho, Arquivo Municipal de Melgaço, além  de

fontes académicas  e etnográ ficas sobre mitos de monstros de fronteira, metamorfoses
teriomórficas e guardiães  aquáticos  nas tradições galaico-portuguesas.)
1. Descrição  simbólica e narrativa
Entre as penedias húmidas e os vales de nevoeiro de Lamas de Mouro, junto às águas frias do
rio Trancoso, o povo fala de um ser antigo que habita os desfiladeiros e as lagoas mais fundas —
o Bicho de Lamas de Mouro. Não há quem o descreva do mesmo modo: para uns é serpente
de escamas azuis com olhos de fogo; para outros, mistura de cão e peixe; há ainda quem diga
que é um homem antigo transformado em fera por ter profanado a nascente sagrada.
Nos relatos coligidos por Eduardo Mauer (2024), o Bicho é descrito como criatura de voz grave
e humana, que fala através da água. Quando alguém se aproxima da lagoa nas noites de luar, o
reflexo vibra e a superfície murmura frases antigas, como se a própria montanha falasse.
Segundo a tradição, quem responde ao Bicho perde a fala — “porque a água não devolve
palavras, só ecos”.
Uma versão recolhida em Parada do Monte narra que o Bicho era outrora um pastor de Castro
Laboreiro que, ambicioso, quis atravessar o rio com um rebanho de ouro prometido por uma
moura encantada. Ao quebrar o juramento de silêncio, o ouro virou escamas, o pastor virou fera,
e desde então ronda as margens, procurando quem o escute sem medo.
As mulheres de Lamas de Mouro, ao lavarem roupa no rio, ainda dizem, meio a sério, meio a rir:
“Que o Bicho leve a dor e traga só espuma.” Este refrão, repetido em voz baixa, é considerado
um encantamento de proteção  e purificação .
Nas noites de neblina densa, os pastores afirmam ver duas luzes amarelas pairando sobre a
água. Uns dizem ser os olhos do Bicho; outros, os re flexos das lanternas dos mortos que ele
guia. O certo é que ninguém ousa atirar pedras ao rio — por respeito ou por temor.
Eduardo Mauer sintetiza: “O Bicho de Lamas de Mouro é o corpo da culpa dissolvido em
corrente. É o rumor do arrependimento que o ser humano deixou correr no rio.”
⸻
2. Contexto histórico e social
Lamas de Mouro é território de montanha e passagem, antigo corredor entre o Gerês e a Galiza,
marcado por rios de caudal forte e clima rigoroso. A convivência entre o humano e o elemento
aquático produziu, ao longo dos séculos, mitos de entidades guardiãs  das águas , muitas vezes
híbridas — meio animal, meio espiritual.
No imaginário do Alto Minho, o “bicho” não é necessariamente maligno; é a personificação  do
mistério natural. Representa o que escapa à compreensão, o limite da linguagem. O termo
“bicho” é usado aqui como categoria simbólica ampla, englobando criaturas aquáticas,
metamórficas ou liminares — “os que vivem entre mundos”.
A documentação paroquial e etnográ fica da região (séculos XVIII–XIX) mostra o uso de “bicho”
para descrever tanto figuras míticas quanto doenças e assombrações (“tem o bicho”,
“apanhou o bicho do rio”). Isso demonstra a dimensão moral e preventiva da lenda: educar o
respeito pelas águas, evitar banhos noturnos e travessias perigosas.
Durante o século XX, com a construção de pontes e barragens no vale do Trancoso, surgiram
novos relatos sobre o Bicho, agora associado a acidentes de obra e desaparecimentos
inexplicáveis . O mito foi reconfigurado como metáfora do desequilíbrio ambiental e da memória
dos rios submersos.


Na leitura contemporânea da Associação  MILK, o Bicho é o guardião  do silêncio fluvial —
aquele que lembra que a água também tem voz, e que todo o gesto humano sobre o território
deixa eco.
⸻
3. Toponímia e variantes locais
Topónimos como “Poço do Bicho”, “Fraga Encantada” e “Corga da Voz” aparecem nos mapas
orais de Lamas de Mouro e Castro Laboreiro, recolhidos por Mauer entre 2023 e 2025. Essas
designações persistem em conversas de moradores mais velhos, embora sem registro formal em
cartografia moderna.
Variantes regionais:
– Em Melgaço, o Bicho é descrito como “serpente-moura”, associada à lenda das Sete Fontes.
– Em Castro Laboreiro, fala-se no “Cão  da Água ”, fera que protege a passagem do rio Trancoso
e surge antes das tempestades.
– Na Galiza próxima, o paralelo mais direto é o Bicho da Corga de Abaixo, descrito em crónicas
orais como “espírito de pastor afogado”.
Essas variantes confirmam a natureza transfronteiriça do mito e a continuidade simbólica entre
guardiães aquáticos de Portugal e da Galiza.
⸻
4. Primeiro relato e fontes académicas primárias
O primeiro registro escrito alusivo à figura encontra-se em J. Leite de Vasconcelos, Etnografia
Portuguesa, vol. XI (1928, pp. 230–236)*, que menciona “as lendas do Bicho do Rio Trancoso,
serpente falante que se ouve em Lamas de Mouro”.
Outras fontes que dialogam com o motivo:
– Teófilo Braga, Crenças Populares de Portugal (1902, pp. 418–425): descrição de “animais
mágicos das águas” e da crença em “seres protetores de nascentes e lagos”.
– Alexandre Parafita, Mitologia Popular Portuguesa (2008, pp. 1236–1248): classifica o “bicho de
água” como arquétipo da consciência ecológica popular.
– Eduardo Mauer, O Bicho de Lamas de Mouro: Água,  Voz e Fronteira (Associação MILK, 2025),
resultado das recolhas orais e cruzamentos etnográ ficos de campo.
Fontes complementares:
– Museu de Melgaço – Inventário  de Narrativas do Alto Minho (1979–2018);
– Ecomuseu do Alto Minho – Coleção  Oral “Rios e Memórias” (1975–2021);
– Tese de Doutoramento de Isabel Fontes, Bestiários  Atlânticos:  Monstros e Metamorfoses na
Península  Ibérica  (U. do Minho, 2015).
⸻
5. Síntese interpretativa final
O Bicho de Lamas de Mouro simboliza o desequilíbrio e a redenção  do humano através da
água . É a consciência do erro convertida em corpo natural. O mito ensina que todo o ato de
profanação — seja ganância, seja descuido ambiental — encontra retorno simbólico no elemento
que foi ferido.
Na leitura simbólica da Associação  MILK, o Bicho não é castigo nem guardião moral, mas
memória viva da relação  com o território. É o rio dotado de espinha e voz. Sua figura híbrida,

entre homem e fera, traduz a condição contemporânea do humano: natureza transformada em
desejo e arrependimento.
A escultura MILK, concebida por Eduardo Mauer, segue a matriz padrão, mas apresenta textura
reptiliana e corpo arqueado, com olhos translúcidos e leve iridescência azul-esverdeada. O
dorso revela escamas formadas por fragmentos de vidro reciclado, simbolizando a
coexistência entre o natural e o arti ficial.
Mauer escreve: “O Bicho de Lamas de Mouro é o espelho que a água ergue para o homem. E
nele, o homem vê-se dividido.”
⸻
6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer
“O Bicho é corpo não binário da fronteira: simultaneamente humano e animal, água e
carne, culpa e cuidado.”
Nesta leitura, o Bicho encarna a transição  permanente entre categorias — é ser em
mutação contínua. Essa fluidez ecoa o pensamento contemporâneo sobre identidades
híbridas e ecológicas, onde o corpo é paisagem e a paisagem, corpo.
A Associação  MILK utiliza o mito nas oficinas “Vozes do Rio”, propondo exercícios de
escuta subaquática e performance vocal, explorando a relação entre corpo, som e
território. A prática artística torna-se espaço de reconciliação  sensorial com o
ambiente.
⸻
7. Referência Estrutural da Matriz MILK
Na Matriz Escultórica MILK – Série Folclore Vivo, o Bicho de Lamas de Mouro apresenta:
– Corpo: alongado, arqueado, mantendo a proporção da matriz compacta adaptada à forma
reptiliana;
– Cores: azul-esverdeado iridescente com reflexos aquáticos;
– Materiais: resina pigmentada, fragmentos de vidro e mica;
– Expressão:  olhar de calma antiga, sugerindo consciência;
– Base: curva, lembrando o movimento da água;
– Eixo curatorial: Corpos de Fronteira — seres de transição, híbridos e metamór ficos.
⸻
Localização  específica: Lamas de Mouro, Castro Laboreiro, Parada do Monte (distrito de Viana
do Castelo).
Primeiro relato documentado: Leite de Vasconcelos, Etnografia Portuguesa, vol. XI, 1928.
Sistematização  contemporânea:  Eduardo Mauer, O Bicho de Lamas de Mouro: Água,  Voz e
Fronteira, Associação MILK, 2025.
Fontes primárias:  Braga (1902); Vasconcelos (1928); Parafita (2008); Fontes (2015); Mauer (2025).
⸻
