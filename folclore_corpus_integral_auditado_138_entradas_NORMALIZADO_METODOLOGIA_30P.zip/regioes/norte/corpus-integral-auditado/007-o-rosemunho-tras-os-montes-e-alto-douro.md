# 007. O Rosemunho (Trás-os-Montes  e Alto Douro)

**Base documental e empírica:** pesquisa documental, análise comparada de fontes públicas, sistematização de tradição oral, relatos orais de pesquisa de campo e revisão semântica conduzidas no âmbito do Folclore Vivo da Associação MILK - Movimento de Intervenções e Linguagens Kulturais e Arte.
**Estado editorial:** corpus de pesquisa de campo e documentação cultural em revisão pública.
**Regra de publicabilidade:** esta entrada não deve ser lida como prova histórica definitiva, inventário patrimonial oficial, validação etnográfica concluída ou certificação académica externa sem verificação documental própria.
**Regra jurídica/RGPD:** não publicar nomes de informantes, contactos, moradas, entrevistas integrais, imagens identificáveis, gravações, dados de menores, coordenadas sensíveis ou materiais comunitários sem autorização.
**Regra de não invenção:** a presente readequação corrige a camada editorial e metodológica sem acrescentar factos, fontes, topónimos, coordenadas ou relatos não existentes no corpus-base.
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

7. O Rosemunho (Trás-os-Montes  e Alto Douro)
(Sistematização  contemporânea  conduzida por Eduardo Mauer e Nuno Araújo no âmbito  das
pesquisas sobre Folclore Vivo da Associação  MILK – Movimento de Intervenções e Linguagens
Kulturais e Arte)
⸻
1. Descrição  simbólica e narrativa
O Rosemunho é uma das entidades mais antigas e persistentes do imaginário transmontano e
duriense, conhecido também como Rasmoinho, Redemoinho ou Espírito  do Vento. A designação

deriva de “redemoinho de vento” ou “remoinho de pó”, mas, na tradição oral, este fenómeno
meteorológico é entendido como manifestação de um ser invisível, dotado de poder
sobrenatural.
Nas aldeias de Vila Real, Mirandela, Bragança e Carrazeda de Ansiães , conta-se que, ao
meio-dia, quando o sol está a pino e a terra silencia, um pequeno redemoinho de vento ergue-se
de repente no caminho. O pó gira em espiral, folhas e gravetos dançam em torno, e o povo diz:
“Lá vai o Rosemunho!” Ninguém deve atravessar o seu trajeto, pois se alguém o interromper ou o
tocar será castigado — levado pelo ar, atordoado ou “virado do avesso”.
As descrições recolhidas por Eduardo Mauer e Nuno Araújo, durante o projeto Folclore Vivo
revelam que o Rosemunho é temido mas também respeitado. Ele não é o vento comum: é a
encarnação  do espírito em movimento, o sinal de que as fronteiras entre os mundos se abrem
por instantes. O remoinho, fenómeno físico e simbólico, é a forma visível do invisível — a
passagem das almas, o sopro dos encantados, o rasto das mouras ou a ira dos santos.
Muitos camponeses antigos faziam o sinal da cruz ao ver um redemoinho e diziam “Deus te leve
e não me leves”, reconhecendo a presença do sagrado. Noutras versões, gritava-se
“Rosemunho, leva o mal e deixa o bem”, atribuindo-lhe papel purificador. Assim, o mito funde o
medo e a esperança: o mesmo vento que pode roubar também cura.
Há relatos de que o Rosemunho fala — uma voz sussurrante no centro do ar. Alguns dizem que é
a voz de um anjo castigado; outros, que é o riso dos mortos. Para Mauer e Araújo, esta
polissemia é essencial: o Rosemunho é o “som do entre”, o ruído do mundo quando se dobra
sobre si mesmo.
Em algumas aldeias do Douro, acredita-se que dentro do redemoinho dançam seres minúsculos,
os “trasguinhos do ar”, ou que é o espírito das crianças não batizadas. Já em certas zonas de
Trás-os-Montes, diz-se que é o próprio diabo a correr o campo, “porque só o demónio anda em
círculo”. Mas há também versões femininas: a “Rosemunha”, fada ou moura que se transforma
em vento para escapar à captura.
Essa oscilação entre o bem e o mal, o masculino e o feminino, o físico e o espiritual, revela a
função arquetípica do mito: o Rosemunho é a metáfora  viva do movimento eterno, a
impossibilidade de fixar a essência.
⸻
2. Contexto histórico e social
O mito do Rosemunho encontra raízes nos cultos pré-cristãos dos ventos e das forças naturais.
O vento, nas culturas agrícolas do Norte, era considerado agente divino, responsável pela
fecundidade e pela destruição. As comunidades rurais, dependentes do clima, desenvolveram
uma relação ambivalente com ele — venerando-o e temendo-o.
Em Trás-os-Montes, onde o isolamento geográ fico manteve tradições arcaicas, o vento foi
personificado em múltiplas entidades: a “Mãe dos Ventos”, o “Homem do Ar”, o “Sopro Santo”.
O Rosemunho representa a síntese dessas crenças, o espírito que move o mundo. A Igreja,
incapaz de erradicar completamente tais práticas, assimilou-as parcialmente. Assim, nas
procissões, os padres aspergiam água benta nos locais onde se formavam redemoinhos, para
“acalmar os ventos maus”.
Documentos inquisitoriais do século XVII mencionam mulheres acusadas de “falar com o vento”
ou de “soprar rezas contrárias”. Essas feiticeiras, mediadoras entre a natureza e o humano,
provavelmente mantinham rituais antigos de comunicação com o ar. O Rosemunho, portanto, é
também o eco dessas práticas femininas condenadas.
Durante o século XIX, etnógrafos como Teófilo Braga e Leite de Vasconcelos registraram a
crença viva no Rosemunho, especialmente em regiões vinícolas do Douro, onde o vento podia

destruir colheitas inteiras. Era, ao mesmo tempo, força meteorológica e moral: castigava os
soberbos e recompensava os humildes.
O mito persistiu como explicação para acidentes inexplicáveis — quedas súbitas, desmaios,
vertigens. No discurso popular, dizia-se que a pessoa “foi apanhada pelo Rosemunho”. Ainda
hoje, em aldeias do Barroso, o termo designa estados de tontura ou confusão espiritual.
Eduardo Mauer e Nuno Araújo, propõe que o Rosemunho exprime o inconsciente coletivo de
uma cultura que vivia em constante negociação com as forças da natureza. A espiral do vento é,
segundo ele, “a forma geométrica da alma transmontana: circular, contínua, inquieta”.
⸻
3. Toponímia e variantes locais
A presença do Rosemunho está documentada em topónimos como Fonte do Rosemunho
(Carrazeda de Ansiães), Poço dos Ventos (Vila Real), Vale da Espiral (Mirandela) e Lomba do
Sopro (Bragança). Em certas regiões, o termo é pronunciado Rasmoinho ou Rosmunho, e usado
para designar redemoinhos de água ou vento.
No Douro Superior, fala-se do “Rosemunho do Meio-Dia”, espírito solar que ronda as vinhas. Já
em Trás-os-Montes , o “Rosemunho das Almas” é vento noturno que transporta vozes de
mortos. Há ainda a “Rosemunha”, versão feminina ligada às mouras encantadas, descrita como
mulher de cabelos em turbilhão.
Essas variantes reforçam a natureza mutável e poliédrica do mito — ele adapta-se ao terreno, à
época, à emoção. O Rosemunho é o nome que o povo dá ao que não pode ser nomeado.
⸻
4. Primeiro relato e fontes académicas primárias
O primeiro registo literário do Rosemunho aparece em Teófilo Braga, O Povo Português  nos seus
Costumes, Crenças e Tradições (1883, p. 402), onde é descrito como “o redemoinho do meio-dia,
demónio em forma de vento, que suga a alma dos imprudentes”.
Leite de Vasconcelos, Etnografia Portuguesa, vol. II (1913), menciona o “Rosemunho” entre as
“entidades aéreas”, comparando-o ao vórtice demoníaco  do folclore eslavo.
Consiglieri Pedroso, Contribuições para uma Mitologia Popular Portuguesa (1897), relaciona o
mito com o “vento da meia-noite” das tradições galegas, sugerindo que o termo português é
tradução oral de antigas designações célticas para o “vento vivo”.
Alexandre Parafita, Mitologia Popular Portuguesa (2008), atualiza o conceito, descrevendo o
Rosemunho como “energia espiritual que gira entre mundos, representação da instabilidade da
alma humana”.
A sistematização contemporânea foi conduzida por Eduardo Mauer e Nuno Araújo recolhendo
testemunhos orais em 17 aldeias, correlacionando-os com estudos meteorológicos e simbólicos.
Para eles, o Rosemunho é “metáfora do inconsciente coletivo: o ponto em que o medo, o riso e o
sagrado giram no mesmo eixo”.
Fontes complementares incluem o Museu de Etnografia de Barroso, o Arquivo Distrital de Vila
Real (séries 1862–1910), e a tese de Mestrado de Carla Brito, Fenomenologia do Vento e
Religiosidade Popular no Norte de Portugal (U. Porto, 2018).
⸻


5. Síntese interpretativa final
O Rosemunho é a imagem perfeita do imprevisível: movimento sem corpo, corpo sem forma.
Representa a energia da transformação, o instante em que o estático se dissolve. O seu poder
está no giro — metáfora universal do tempo e da consciência.
Na leitura da Associação  MILK, o Rosemunho é figura do fluxo criativo, símbolo das forças
invisíveis que moldam a arte e a vida. O redemoinho, tal como o processo artístico, nasce do
caos e organiza-se em ritmo.
A escultura MILK do Rosemunho, concebida por Eduardo Mauer e Nuno Araújo traduz esse
princípio em forma compacta e dinâmica: corpo em espiral ascendente, cabeça grande inclinada,
sorriso aberto. As cores — amarelo, branco e cinza-prateado — representam luz, ar e movimento.
O acabamento em resina translúcida e verniz de alto brilho sugere vento solidificado.
⸻
6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer
Na abordagem não binária, o Rosemunho é a própria imagem da fluidez identitária . Não tem
rosto nem corpo fixo; ora é ele, ora ela, ora ambos. É energia que se recusa a ser contida.
Para Eduardo Mauer e Nuno Araújo, o Rosemunho é o mito queer primordial, porque dissolve
todas as oposições — masculino/feminino, bem/mal, corpo/alma. No giro do vento, tudo se
mistura e renasce. O centro vazio do redemoinho é o símbolo perfeito do “entre-lugar” não
binário: o vazio que não é ausência, mas potência.
A sua voz, descrita como murmúrio indistinto, é linguagem sem gramática, semelhante às
expressões do corpo queer na arte contemporânea — linguagem que cria sentido pela
intensidade, não pela norma.
O Rosemunho, ao girar, incorpora também a ideia de movimento político e existencial: o corpo
que se afirma na oscilação, a identidade que resiste ao aprisionamento. No contexto do Folclore
Vivo da Associação  MILK, torna-se alegoria do processo criativo não linear, onde o erro e o
acaso são gestos de liberdade.
Assim, o Rosemunho deixa de ser espírito do medo para se tornar símbolo da alegria não
binária : o vento que ri, que transforma a queda em dança e o espanto em criação.
⸻
7. Referência Estrutural da Matriz MILK
Na Matriz Escultórica MILK, o Rosemunho é representado como corpo em rotação suave,
cabeça grande e sorriso aberto, com extremidades que se prolongam em linhas espiraladas. As
cores predominantes são branco, cinza e amarelo-luz, evocando o sol e o ar. O acabamento deve
ser brilhante, refletindo o movimento contínuo.
A peça pode ser instalada suspensa, permitindo que o público caminhe sob ela — experiência
imersiva que transforma o vento em presença.
⸻
Localização  específica: Trás-os-Montes e Alto Douro (Vila Real, Mirandela, Bragança, Carrazeda
de Ansiães).
Primeiro relato documentado: Teófilo Braga, O Povo Português  nos seus Costumes, Crenças e
Tradições, 1883.


Fontes primárias:  Braga (1883); Vasconcelos (1913); Pedroso (1897); Parafita (2008); Brito (2018);
Mauer (2024).
