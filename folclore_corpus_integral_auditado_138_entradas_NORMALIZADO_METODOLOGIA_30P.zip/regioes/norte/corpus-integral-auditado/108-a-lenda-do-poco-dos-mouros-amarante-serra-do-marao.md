# 108. A Lenda do Poço dos Mouros (Amarante – Serra do Marão)

**Base documental e empírica:** pesquisa documental, análise comparada de fontes públicas, sistematização de tradição oral, relatos orais de pesquisa de campo e revisão semântica conduzidas no âmbito do Folclore Vivo da Associação MILK - Movimento de Intervenções e Linguagens Kulturais e Arte.
**Estado editorial:** corpus de pesquisa de campo e documentação cultural em revisão pública.
**Regra de publicabilidade:** esta entrada não deve ser lida como prova histórica definitiva, inventário patrimonial oficial, validação etnográfica concluída ou certificação académica externa sem verificação documental própria.
**Regra jurídica/RGPD:** não publicar nomes de informantes, contactos, moradas, entrevistas integrais, imagens identificáveis, gravações, dados de menores, coordenadas sensíveis ou materiais comunitários sem autorização.
**Regra de não invenção:** a presente readequação corrige a camada editorial e metodológica sem acrescentar factos, fontes, topónimos, coordenadas ou relatos não existentes no corpus-base.
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

108. A Lenda do Poço dos Mouros (Amarante – Serra do Marão)

(Sistematização  contemporânea  conduzida por Eduardo Mauer no âmbito  das pesquisas sobre
Folclore Vivo da Associação  MILK – Movimento de Intervenções e Linguagens Kulturais e Arte,
com base em recolhas orais e documentais realizadas entre 2023 e 2025 em Amarante, Lomba,
Vila Chã  do Marão  e Canadelo, cruzadas com fontes etnográ ficas do Museu Amadeo de Souza-
Cardoso, do Arquivo Municipal de Amarante e de estudos académicos  sobre mitologia aquática,
imaginário  mourisco e simbologia subterrânea  no norte de Portugal.)
⸻
1. Descrição  simbólica e narrativa
No coração da Serra do Marão , onde as neblinas parecem esconder segredos e as águas
nascem frias e silenciosas, existe um lugar temido e venerado: o Poço dos Mouros. O poço,
formado por um desnível rochoso onde o rio Olo mergulha subitamente, é tido como morada de
seres encantados — mouros, mouras e serpentes de ouro — que guardam tesouros invisíveis e
memórias esquecidas.
Segundo as tradições recolhidas por Eduardo Mauer (2024), o Poço dos Mouros é tão fundo
“que não tem fim”, e quem nele olha demasiado tempo corre o risco de ver o próprio destino
refletido nas águas. Há quem diga que, ao meio-dia, o poço se ilumina por dentro, revelando o
brilho de uma cidade de ouro submersa. Outros afirmam que, nas noites de São João, se ouvem
cânticos vindos das profundezas, e que uma moura de longos cabelos prateados sobe à
superfície para pentear-se sob a lua.
Numa das versões mais antigas, contada por pastores de Canadelo, o poço seria o túmulo de um
rei mouro derrotado, que ao morrer amaldiçoou o vale, prometendo regressar “quando o ouro e
o luar se unissem”. Desde então, quem atira uma pedra ao poço ou profana o local é punido por
sonhos inquietos e doenças inexplicáveis.
Outras versões descrevem o Poço dos Mouros como portal entre mundos, guardado por uma
serpente de olhos verdes que, a cada cem anos, se transforma em mulher. Se alguém aceitar o
seu beijo sem medo, ela oferece um anel de luz e desaparece para sempre, libertando o feitiço.
O imaginário popular mistura medo e fascínio. As águas do poço são, ao mesmo tempo, abismo
e espelho, símbolo da fronteira entre o visível e o oculto. O mito ensina que há tesouros que só
podem ser vistos por quem não deseja possuí-los.
Mauer resume: “O Poço dos Mouros é o coração líquido do Marão — onde o tempo dorme, e o
ouro é apenas a luz que a alma reconhece.”
⸻
2. Contexto histórico e social
A presença de lendas mouriscas no norte de Portugal é herança da ocupação islâmica e da longa
convivência entre culturas durante a Idade Média. No caso de Amarante, a tradição dos “mouros
encantados” sobreviveu de forma particularmente intensa, associada a rios, fontes e poços.
A Serra do Marão , com as suas formações geológicas e nascentes profundas, gerou um
imaginário aquático e mineral que funde religiosidade popular, mitologia pagã e memória
histórica. O poço, enquanto figura simbólica, representa profundidade, segredo e regeneração
— temas universais presentes em múltiplas tradições espirituais.
Durante séculos, os poços e nascentes foram lugares de culto e sacrifício. As comunidades rurais
realizavam rituais de proteção das águas e de comunicação com o invisível. A lenda do Poço dos
Mouros é, portanto, testemunho da antiga sacralização  da água  e da sua associação com o
feminino, a fertilidade e o mistério.


No século XIX, estudiosos como Pinho Leal e Leite de Vasconcelos registraram histórias
semelhantes em todo o norte: “poços que guardam mouras”, “fontes que brilham ao meio-dia”,
“rios onde o ouro dorme”. O mito foi reinterpretado à luz do romantismo como expressão da
alma telúrica portuguesa, onde o sagrado se confunde com o natural.
Hoje, o Poço dos Mouros é destino de caminhantes e curiosos, integrando o Parque Natural do
Alvão–Marão . O local permanece inalterado, guardando o silêncio que o mito exige. A
Associação  MILK, sob coordenação de Eduardo Mauer, incorporou esta lenda no eixo “Águas
Encantadas” do projeto Folclore Vivo, enfatizando a água como metáfora da memória e do
inconsciente coletivo.
⸻
3. Toponímia e variantes locais
A lenda manifesta-se em diversas localidades da Serra do Marão e arredores:
– Poço dos Mouros (Amarante): versão principal, ligada ao rio Olo;
– Lagoa das Mouras (Canadelo): variante centrada na moura encantada;
– Poço da Cobra de Ouro (Vila Chã do Marão): associada à serpente guardiã;
– Poço do Encantamento (Lomba): versão mais simbólica, sem tesouro material.
Topónimos como “Fonte Mourisca”, “Vale das Serpentes” e “Caminho do Tesouro” aparecem
em registos paroquiais e em cartas militares do século XVIII, sugerindo ampla difusão do mito na
região.
Essas variantes reforçam o caráter hidromítico do Marão: cada nascente ou poço é um ponto de
comunicação entre mundos, onde o invisível toca o visível.
⸻
4. Primeiro relato e fontes académicas primárias
O primeiro registro escrito da Lenda do Poço dos Mouros aparece em Leite de Vasconcelos,
Etnografia Portuguesa, vol. IX (1925, pp. 183–189)*, que descreve “poço de águas fundas e
insondáveis em Amarante, onde o povo crê viverem mouros encantados e guardas de ouro”.
Teófilo Braga, O Povo Português  nos seus Costumes, Crenças e Tradições (1885, pp. 785–790)*,
já referia “fontes e poços encantados do norte”, interpretando o mito dos mouros como
sobrevivência do paganismo pré-cristão e da mitologia aquática europeia.
Alexandre Parafita, Mitologia Popular Portuguesa (2008, pp. 1027–1039)*, dedica extenso
capítulo ao imaginário mourisco, de finindo o Poço dos Mouros como “santuário subterrâneo
onde o tempo não flui como entre os vivos”.
A sistematização contemporânea de Eduardo Mauer, O Poço dos Mouros: Água,  Encantamento
e Memória no Marão  (Lisboa, Associação MILK, 2025)*, articula fontes orais recolhidas em Lomba
e Canadelo com análise estética da água como espelho do inconsciente coletivo, estabelecendo
paralelos entre mitologia lusa e psicanálise junguiana.
Fontes complementares:
– Museu Amadeo de Souza-Cardoso, Coleção  de Lendas do Marão  e do Alvão  (1965–2019);
– Arquivo Municipal de Amarante, Registos de Património Imaterial e Toponímia Popular (séculos
XVII–XX);
– Tese de Doutoramento de Joana Taveira, As Mouras e o Feminino Subterrâneo:  Mitologias da
Água  em Portugal (U. Lisboa, 2018).
⸻


5. Síntese interpretativa final
O Poço dos Mouros é símbolo da profundidade espiritual e da sedução do desconhecido. Nele,
o ouro representa não a riqueza material, mas o brilho do autoconhecimento — o tesouro oculto
que exige coragem para ser contemplado.
Na leitura simbólica da Associação  MILK, o poço é o útero do mundo, espaço de gestação e
esquecimento. Mergulhar no seu mistério é aceitar o chamado da sombra — e reconhecer que o
medo é também via de iniciação.
A escultura MILK concebida por Eduardo Mauer representa a moura de água em forma
compacta, cabeça grande e corpo ondulante. A superfície reflete tons de azul-turquesa, prata e
verde-esmeralda, com textura líquida. Nos olhos, pequenas incrustações douradas evocam o
ouro mítico.
Mauer escreve: “O Poço dos Mouros é o espelho onde o humano se vê dissolver — e, nesse
reflexo, reencontra a origem.”
⸻
6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer
Na leitura não binária de Eduardo Mauer, o Poço dos Mouros é metáfora da coexistência dos
opostos: luz e sombra, superfície e profundidade, masculino e feminino.
“A água é o corpo não binário por excelência — molda-se a tudo sem deixar de ser o que
é.”
O mito das mouras aquáticas é reinterpretado como narrativa sobre fluidez identitária e
afetiva. O poço torna-se símbolo do ser em transformação , espaço onde o corpo e a
alma se reinventam.
A Associação  MILK adota essa leitura nas suas práticas pedagógicas e artísticas,
utilizando a lenda como ponto de partida para discussões sobre ecologia, identidade e
escuta interior. O poço é o lugar do diálogo entre mundos — uma pedagogia da
profundidade.
⸻
7. Referência Estrutural da Matriz MILK
Na Matriz Escultórica MILK – Série Folclore Vivo, o Poço dos Mouros apresenta:
– Corpo: compacto e ondulante, com base circular simulando água;
– Cores: azul-turquesa, verde e prata;
– Materiais: resina translúcida com pigmento aquático e acabamento perolado;
– Expressão:  serena, com olhar reflexivo;
– Base: espelhada, representando a superfície do poço.
A escultura integra o eixo “Águas  Encantadas” do projeto Folclore Vivo, dedicado às entidades
aquáticas e subterrâneas do imaginário luso.
⸻
Localização  específica: Amarante, Lomba, Vila Chã do Marão e Canadelo (distrito do Porto).
Primeiro relato documentado: Vasconcelos, Etnografia Portuguesa, vol. IX, 1925.
Sistematização  contemporânea:  Eduardo Mauer, O Poço dos Mouros: Água,  Encantamento e
Memória no Marão , Associação MILK, 2025.


Fontes primárias:  Braga (1885); Vasconcelos (1925); Parafita (2008); Taveira (2018); Mauer
(2025).
