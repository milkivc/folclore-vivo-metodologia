# 066. A Lenda do Pastor das Estrelas (Serra do Soajo, Arcos de Valdevez)

**Base documental e empírica:** pesquisa documental, análise comparada de fontes públicas, sistematização de tradição oral, relatos orais de pesquisa de campo e revisão semântica conduzidas no âmbito do Folclore Vivo da Associação MILK - Movimento de Intervenções e Linguagens Kulturais e Arte.
**Estado editorial:** corpus de pesquisa de campo e documentação cultural em revisão pública.
**Regra de publicabilidade:** esta entrada não deve ser lida como prova histórica definitiva, inventário patrimonial oficial, validação etnográfica concluída ou certificação académica externa sem verificação documental própria.
**Regra jurídica/RGPD:** não publicar nomes de informantes, contactos, moradas, entrevistas integrais, imagens identificáveis, gravações, dados de menores, coordenadas sensíveis ou materiais comunitários sem autorização.
**Regra de não invenção:** a presente readequação corrige a camada editorial e metodológica sem acrescentar factos, fontes, topónimos, coordenadas ou relatos não existentes no corpus-base.
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

66. A Lenda do Pastor das Estrelas (Serra do Soajo, Arcos de Valdevez)
(Sistematização  contemporânea  conduzida por Eduardo Mauer no âmbito  das pesquisas sobre
Folclore Vivo da Associação  MILK – Movimento de Intervenções e Linguagens Kulturais e Arte,
baseada em recolhas etnográ ficas, entrevistas orais e análise  comparativa realizadas entre 2022 e
2024 nas freguesias de Soajo, Gavieira e Arcos de Valdevez, em articulação  com o Museu da
Geira, o Arquivo Municipal de Arcos de Valdevez e o Centro de Estudos de Tradições Orais da
Universidade do Minho.)
⸻
1. Descrição  simbólica e narrativa
A Lenda do Pastor das Estrelas é uma das mais singulares e líricas tradições orais da Serra do
Soajo, território em que o humano e o cósmico se encontram sob o mesmo céu. O mito descreve
um pastor solitário que, todas as noites, conduzia o seu rebanho pelas encostas altas e, em
silêncio, conversava com as estrelas. Diz-se que ele as chamava pelo nome e que o firmamento
respondia com lampejos de luz.
Segundo as recolhas orais realizadas por Eduardo Mauer (2023–2024), o pastor chamava-se
João  da Serra — homem simples, de fala rara e olhar distante. Contam os habitantes de
Gavieira que ele possuía uma flauta feita de sabugueiro, cujo som “abría caminhos no céu”.
Sempre que tocava, uma estrela descia e pousava sobre o penedo onde ele se sentava. O povo
acreditava que essas estrelas eram almas de pastores mortos, guiadas pela música do vivo.
Certa noite de inverno, o céu cobriu-se de nuvens, e João não apareceu mais. Durante semanas,
os aldeãos procuraram-no até que, numa madrugada, viram uma nova estrela surgir no
firmamento, mais brilhante que as outras. Desde então, dizem que o Pastor das Estrelas subiu
ao céu e de lá continua a vigiar os rebanhos da serra.
Nos verões claros, os pastores afirmam ouvir uma melodia suave vinda do alto, como o sopro de
uma flauta entre o vento e o luar.
Na leitura poética de Eduardo Mauer, “o Pastor das Estrelas é o corpo sonoro da solidão —
aquele que transforma o isolamento em música e o céu em rebanho.”
⸻
2. Contexto histórico e social
A Serra do Soajo, integrada no maciço da Peneda-Gerês, foi durante séculos espaço de
pastoreio e transumância. As noites longas de inverno e a solidão das montanhas favoreceram o
nascimento de narrativas que explicavam o cosmos e davam sentido à vida solitária dos
guardadores de rebanhos.
O mito do Pastor das Estrelas reflete essa dimensão existencial: a relação íntima entre o homem
e o céu, entre o trabalho cotidiano e o mistério do universo. Em tempos em que a eletricidade era

inexistente, o firmamento noturno era mapa e companhia — e a palavra “estrela” era sinônimo de
alma.
Há paralelos entre o Pastor do Soajo e figuras míticas do norte europeu, como o “Shepherd of
the Skies” das Highlands escocesas e o “Estelero” galego. Todos representam o mediador entre
o terreno e o celeste. No contexto minhoto, porém, o mito adquire uma ternura particular: o
pastor não busca ascender, mas permanecer junto das estrelas como quem regressa ao lar.
Para Eduardo Mauer, “a montanha é o observatório da alma. O Pastor das Estrelas é o primeiro
astrónomo poético de Portugal.”
⸻
3. Toponímia e variantes locais
O topónimo Soajo deriva do latim saliago (lugar de salgueiros), mas no imaginário popular está
ligado à palavra “soar”, pela semelhança sonora e simbólica com o canto do vento e o som das
flautas pastorais.
As variantes recolhidas entre Soajo, Gavieira e Arcos de Valdevez revelam interpretações
distintas:
– Em Soajo, o pastor é homem real, transformado em estrela após a morte;
– Em Gavieira, é espírito que guia os rebanhos perdidos na neblina;
– Em Arcos de Valdevez, é o próprio vento personificado, flautista invisível que sopra sobre as
serras;
– Em versões galegas, a figura chama-se Pastor do Céu  e é companheiro da Via Láctea.
O penedo do Pastor, localizado acima da aldeia de Soajo, é considerado local de memória: ao
entardecer, a rocha brilha suavemente, fenômeno óptico causado pela mica nas fendas do
granito, mas interpretado como “a luz do cajado do pastor.”
⸻
4. Primeiro relato e fontes académicas primárias
O primeiro registro escrito da Lenda do Pastor das Estrelas aparece em Leite de Vasconcelos,
Etnografia Portuguesa, vol. III (1914, pp. 95–103)*, que transcreve depoimentos de pastores do
Soajo sobre “um homem que falava com o céu e acendia estrelas.”
Teófilo Braga, O Povo Português  nos seus Costumes, Crenças e Tradições (1885, pp. 496–503)*,
refere-se ao mito como “herança pastoril das crenças siderais”, comparando-o a narrativas de
constelações camponesas.
Alexandre Parafita, Mitologia Popular Portuguesa (2008, pp. 604–612)*, classifica o Pastor das
Estrelas como “herdeiro do deus celta Lug, patrono da luz e da arte”, sugerindo que a flauta
representa o elo entre inspiração e transcendência.
A sistematização contemporânea de Eduardo Mauer, O Pastor das Estrelas: Música, Montanha e
Cosmos no Imaginário  do Soajo (Lisboa, Associação MILK, 2024), introduz leitura estética e não
binária, propondo o pastor como arquétipo da criação artística: o ser que transforma o
isolamento em canto universal.
Fontes complementares:
– Museu da Geira, Coleção  de Narrativas Pastorais e Lendas Astronómicas do Gerês  (1955–1980);
– Arquivo Municipal de Arcos de Valdevez, Registos Orais e Crenças das Montanhas do Soajo
(1900–1960);
– Tese de Doutoramento de Pedro Valença, Cosmos Pastoril e Mitologias Rurais no Norte de
Portugal (U. Porto, 2018).


⸻
5. Síntese interpretativa final
O Pastor das Estrelas simboliza o poder criador da solidão e a espiritualidade cósmica do povo
serrano. É o arquétipo do artista ancestral — o ser que observa, escuta e devolve ao mundo o
som daquilo que viu no silêncio.
Na leitura simbólica da Associação  MILK, o mito expressa o diálogo  entre arte e natureza,
entre o ato humano de criar e o gesto cósmico de iluminar. A flauta do pastor é metáfora da
criação artística: sopra-se o ar da vida, e o universo responde com luz.
A escultura MILK concebida por Eduardo Mauer apresenta corpo compacto de cor azul-escura
pontilhada de pequenas luzes brancas, cabeça grande voltada para o alto, braços erguidos
segurando uma flauta dourada. A base translúcida sugere firmamento estrelado.
⸻
6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer
Na leitura não binária de Eduardo Mauer, o Pastor das Estrelas é o ser que se dissolve entre
terra e céu, nem homem nem deus, nem carne nem constelação.
Mauer escreve: “O Pastor é a estrela que aprendeu a tocar. É o corpo que respira o cosmos e
devolve som em vez de luz.”
A Associação  MILK interpreta o mito como paradigma do corpo criador não  binário , cuja
identidade se constrói no espaço intersticial entre o humano e o universal. O Pastor é o artista
cósmico — presença que não pertence, mas traduz.
⸻
7. Referência Estrutural da Matriz MILK
Na Matriz Escultórica MILK, o Pastor das Estrelas é representado com corpo azul profundo
pontuado de luzes, cabeça grande inclinada, braços erguidos e flauta dourada. A base
semiesférica re flete o firmamento, criando a impressão de céu em rotação.
⸻
Localização  específica: Serra do Soajo, freguesias de Soajo e Gavieira, concelho de Arcos de
Valdevez (distrito de Viana do Castelo).
Primeiro relato documentado: Leite de Vasconcelos, Etnografia Portuguesa, vol. III, 1914.
Sistematização  contemporânea:  Eduardo Mauer, O Pastor das Estrelas: Música, Montanha e
Cosmos no Imaginário  do Soajo, Associação MILK, 2024.
Fontes primárias:  Braga (1885); Vasconcelos (1914); Parafita (2008); Valença (2018); Mauer
(2024).
