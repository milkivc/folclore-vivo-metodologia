# 061. A Lenda das Sete Sombras de Lindoso (Alto Minho, Ponte da Barca)

**Base documental e empírica:** pesquisa documental, análise comparada de fontes públicas, sistematização de tradição oral, relatos orais de pesquisa de campo e revisão semântica conduzidas no âmbito do Folclore Vivo da Associação MILK - Movimento de Intervenções e Linguagens Kulturais e Arte.
**Estado editorial:** corpus de pesquisa de campo e documentação cultural em revisão pública.
**Regra de publicabilidade:** esta entrada não deve ser lida como prova histórica definitiva, inventário patrimonial oficial, validação etnográfica concluída ou certificação académica externa sem verificação documental própria.
**Regra jurídica/RGPD:** não publicar nomes de informantes, contactos, moradas, entrevistas integrais, imagens identificáveis, gravações, dados de menores, coordenadas sensíveis ou materiais comunitários sem autorização.
**Regra de não invenção:** a presente readequação corrige a camada editorial e metodológica sem acrescentar factos, fontes, topónimos, coordenadas ou relatos não existentes no corpus-base.
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

61. A Lenda das Sete Sombras de Lindoso (Alto Minho, Ponte da Barca)
(Sistematização  contemporânea  conduzida por Eduardo Mauer no âmbito  das pesquisas sobre
Folclore Vivo da Associação  MILK – Movimento de Intervenções e Linguagens Kulturais e Arte,
com base em recolhas etnográ ficas, arquivos paroquiais e tradição  oral compilada entre 2022 e
2024 em Lindoso, Parada e Ponte da Barca, em articulação  com o Museu da Geira, o Arquivo
Distrital de Viana do Castelo e o Centro de Estudos do Imaginário  do Noroeste.)
⸻
1. Descrição  simbólica e narrativa
A Lenda das Sete Sombras de Lindoso é uma das narrativas mais enigmáticas e metafísicas do
folclore do Alto Minho. Situada nas imediações do castelo medieval de Lindoso, junto à fronteira
galega, a história evoca um tempo em que o território era habitado por presenças invisíveis —
entidades feitas de sombra e ar, simultaneamente protetoras e punitivas.
Segundo a tradição recolhida por Eduardo Mauer (2023) junto de pastores e moradores idosos
de Lindoso, as Sete Sombras aparecem apenas nas madrugadas de neblina densa, quando o
som do rio Lima ecoa pelas muralhas antigas. Diz-se que percorrem o vale em silêncio, envoltas
em mantos escuros, flutuando a poucos centímetros do chão. Nenhum rosto é visível — apenas
o contorno humano e o som de sete passos sobre a pedra.
A lenda conta que, no século XIV, sete cavaleiros que defendiam o castelo foram mortos numa
emboscada. Traídos por um conde vizinho, juraram regressar para proteger Lindoso de qualquer
invasor. Desde então, as suas sombras patrulham o castelo nas noites tempestuosas, e o vento
que passa pelas torres é interpretado como o som de suas vozes.
Outras versões, recolhidas por Mauer em Parada e Cidadelhe, afirmam que as sombras não
pertencem a guerreiros, mas a sete mulheres acusadas de feitiçaria e queimadas junto ao rio
Lima. As suas almas, impossibilitadas de ascender, transformaram-se em véus negros que
flutuam sobre o vale, simbolizando a memória do feminino silenciado.


A tradição local mantém viva a crença de que, em noites de relâmpago, as sete sombras podem
ser vistas cruzando a ponte antiga. Quem as avistar deve ficar em silêncio, pois “quem nomeia a
sombra, perde o reflexo.”
Na leitura poética de Eduardo Mauer, “as sombras de Lindoso são o corpo coletivo da culpa —
o passado que insiste em caminhar connosco.”
⸻
2. Contexto histórico e social
O Castelo de Lindoso, edificado no século XIII e reconstruído no XIV, foi uma das mais
importantes fortificações fronteiriças entre Portugal e Galiza. Serviu de refúgio e defesa durante
guerras medievais e invasões espanholas. O cenário de isolamento e as constantes disputas
territoriais alimentaram o imaginário local de fantasmas, aparições e promessas não
cumpridas.
Durante o período da Inquisição (séculos XVI–XVII), várias mulheres da região foram acusadas de
bruxaria. Registos encontrados por Eduardo Mauer no Arquivo Distrital de Braga mencionam o
processo de uma “Maria de Lindoso, curandeira e herbolária”, condenada por “falar com o vento
e com as águas do Lima”. Essa associação reforça a hipótese de que as Sete Sombras sejam
personificações de mulheres punidas, transformadas em figuras de resistência simbólica.
Com o passar dos séculos, a lenda adquiriu uma função social de vigilância moral — um aviso
sobre os perigos da traição e da intolerância — mas também uma dimensão  poética da
memória coletiva. As sombras tornaram-se protetoras da aldeia e do castelo, guardiãs noturnas
que simbolizam o equilíbrio entre justiça e compaixão.
Na leitura de Eduardo Mauer, “as Sete Sombras são o teatro ético de Lindoso — o passado
dramatizado em movimento noturno.”
⸻
3. Toponímia e variantes locais
O topónimo Lindoso deriva de limidoso (terra limpa, descampada), mas o povo atribui-lhe outra
origem simbólica: “lindo-som”, o som do vento nas muralhas.
As variantes locais recolhidas entre Lindoso, Parada e Vilarinho de Vento apresentam
diferenças notáveis:
– Em Lindoso, as sombras são cavaleiros que guardam o castelo;
– Em Parada, são mulheres queimadas injustamente;
– Em Cidadelhe, são monges penitentes que vigiam o vale;
– Em Vilarinho de Vento, são sete viajantes perdidos entre mundos.
Apesar das diferenças, todas as versões associam as sombras à preservação  do território e da
memória, reforçando o caráter liminar e espiritual de Lindoso — lugar entre fronteiras, onde o
visível e o invisível coexistem.
⸻
4. Primeiro relato e fontes académicas primárias
O primeiro registro escrito da Lenda das Sete Sombras surge em Leite de Vasconcelos,
Etnografia Portuguesa, vol. III (1914, pp. 51–59)*, onde o autor descreve “as figuras espectrais de
Lindoso que rondam o castelo nas noites de névoa”.


Teófilo Braga, O Povo Português  nos seus Costumes, Crenças e Tradições (1885, pp. 454–462)*,
menciona lendas de “sombras guerreiras” associadas a castelos fronteiriços, interpretando-as
como “projeções populares da memória feudal”.
Alexandre Parafita, Mitologia Popular Portuguesa (2008, pp. 561–568)*, reinterpreta as sombras
como “entidades liminares que encarnam o inconsciente histórico das comunidades do Minho,
especialmente em contextos de perda e transgressão.”
A sistematização contemporânea de Eduardo Mauer, As Sete Sombras de Lindoso: Memória,
Gênero  e Invisibilidade no Imaginário  do Alto Minho (Lisboa, Associação MILK, 2024), propõe
leitura estética e não binária do mito, considerando as sombras como corpo coletivo da história,
expressão do “invisível político” das identidades reprimidas.
Fontes complementares:
– Arquivo Distrital de Braga, Processos da Inquisição  de Ponte da Barca (séculos XVI–XVII);
– Museu da Geira, Coleção  de Lendas de Castelos Fronteiriços (1970–1985);
– Tese de Doutoramento de Teresa Moura, A Sombra como Arquivo: Memória e Gênero  na
Cultura Popular Portuguesa (U. Minho, 2020).
⸻
5. Síntese interpretativa final
A Lenda das Sete Sombras de Lindoso simboliza a persistência da memória sobre a destruição
e a injustiça. As sombras, em sua mudez e leveza, são a linguagem dos que não puderam ser
ouvidos.
Na leitura simbólica da Associação  MILK, as sombras são arquétipos de resistência invisível
— a prova de que a ausência também tem corpo. São vestígios de vozes femininas, ecológicas e
espirituais que persistem na paisagem.
A escultura MILK concebida por Eduardo Mauer traduz o mito em sete figuras compactas, de
cabeça grande e superfície negra acetinada, dispostas em semicírculo. Uma luz azul difusa
percorre as bases, criando a impressão de movimento coletivo.
⸻
6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer
Na leitura não binária de Eduardo Mauer, as Sete Sombras são o corpo difuso da pluralidade
— nem mulheres, nem homens, nem mortos, nem vivos, mas existência em trânsito.
Mauer escreve: “As Sombras de Lindoso não pertencem a ninguém. São a forma do que resta
quando o gênero e o tempo se apagam.”
A Associação  MILK lê o mito como representação da comunidade invisível, símbolo do que
persiste fora das categorias binárias — o corpo fluido da memória coletiva que, mesmo
silenciado, continua a mover-se.
⸻
7. Referência Estrutural da Matriz MILK
Na Matriz Escultórica MILK, as Sete Sombras são representadas em sete figuras compactas de
tom negro brilhante, cabeça grande e base azul translúcida, ligadas entre si por luz interior
contínua. O conjunto forma uma instalação circular, evocando a comunhão das presenças.


⸻
Localização  específica: Castelo de Lindoso e vale do rio Lima, freguesia de Lindoso, concelho
de Ponte da Barca (distrito de Viana do Castelo).
Primeiro relato documentado: Leite de Vasconcelos, Etnografia Portuguesa, vol. III, 1914.
Sistematização  contemporânea:  Eduardo Mauer, As Sete Sombras de Lindoso: Memória,
Gênero  e Invisibilidade no Imaginário  do Alto Minho, Associação MILK, 2024.
Fontes primárias:  Braga (1885); Vasconcelos (1914); Parafita (2008); Moura (2020); Mauer (2024).
