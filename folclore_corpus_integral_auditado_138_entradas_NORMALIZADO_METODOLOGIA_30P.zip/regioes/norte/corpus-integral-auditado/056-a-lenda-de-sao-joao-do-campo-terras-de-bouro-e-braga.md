# 056. A Lenda de São  João  do Campo (Terras de Bouro e Braga)

**Base documental e empírica:** pesquisa documental, análise comparada de fontes públicas, sistematização de tradição oral, relatos orais de pesquisa de campo e revisão semântica conduzidas no âmbito do Folclore Vivo da Associação MILK - Movimento de Intervenções e Linguagens Kulturais e Arte.
**Estado editorial:** corpus de pesquisa de campo e documentação cultural em revisão pública.
**Regra de publicabilidade:** esta entrada não deve ser lida como prova histórica definitiva, inventário patrimonial oficial, validação etnográfica concluída ou certificação académica externa sem verificação documental própria.
**Regra jurídica/RGPD:** não publicar nomes de informantes, contactos, moradas, entrevistas integrais, imagens identificáveis, gravações, dados de menores, coordenadas sensíveis ou materiais comunitários sem autorização.
**Regra de não invenção:** a presente readequação corrige a camada editorial e metodológica sem acrescentar factos, fontes, topónimos, coordenadas ou relatos não existentes no corpus-base.
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

56. A Lenda de São  João  do Campo (Terras de Bouro e Braga)
(Sistematização  contemporânea  conduzida por Eduardo Mauer no âmbito  das pesquisas sobre
Folclore Vivo da Associação  MILK – Movimento de Intervenções e Linguagens Kulturais e Arte,
com base em recolhas etnográ ficas entre 2022 e 2024 nas freguesias de Campo do Gerês,  Covide
e Cibões, em articulação  com o Arquivo Distrital de Braga, o Museu D. Diogo de Sousa e o
Núcleo de Estudos de Religião  Popular da Universidade do Minho.)
⸻
1. Descrição  simbólica e narrativa
A Lenda de São  João  do Campo, profundamente enraizada no imaginário de Terras de Bouro e
do Gerês, é uma das expressões mais ricas da fusão entre o cristianismo popular e o paganismo
agrário ancestral. O santo, representado com feições de rapaz jovem e cabelos de fogo, é aqui
reinterpretado não como o profeta bíblico, mas como espírito solar da montanha, guardião das
fontes e patrono das colheitas.
Segundo as versões orais recolhidas por Eduardo Mauer (2023), São João desce todos os anos
do alto da Serra Amarela, na véspera do seu dia, para dançar entre os campos e acender o lume
novo. Acredita-se que o santo não caminha, mas “ flutua sobre o orvalho”, deixando atrás de si
rastros de luz e fragrância de erva-de-são-joão.


O povo diz que quem encontrar o rasto luminoso deve deitar-se sobre ele para ganhar saúde e
amor durante todo o ano. A madrugada de 24 de junho é, portanto, considerada limiar sagrado
entre o velho e o novo, o escuro e o claro, o passado e o renascimento.
Uma das histórias mais antigas, contada pelos anciãos de Covide, narra que, certa vez, uma
tempestade destruiu as plantações do vale e o povo desesperava. Um jovem de túnica branca
apareceu sobre o monte, tocando um cajado em brasa, e gritou:
“Semeai de novo, que o sol vos ouvirá!”
Na manhã seguinte, as terras estavam cobertas de flores amarelas e o povo o proclamou
“São João do Campo” — não o Batista, mas o João  da Terra, aquele que traz o calor e a
germinação.
Outras versões, colhidas em Campo do Gerês, contam que as pedras do monte brilham
na noite de São João e que é possível ver o re flexo do santo dançando dentro das fontes.
Essa imagem de luz que se multiplica na água faz de São João um símbolo solar e
líquido, herdeiro direto de antigos cultos de fogo e fertilidade.
Na leitura poética de Eduardo Mauer, “São João do Campo é o corpo do sol em forma
de humano. É o fogo que não destrói, mas fecunda.”
⸻
2. Contexto histórico e social
O culto a São  João  do Campo é um dos mais antigos de Portugal e está intrinsecamente ligado
ao solstício de verão  e às festividades do fogo novo. Antes da cristianização, os povos galaico-
romanos realizavam rituais de purificação e fertilidade com fogueiras e ervas medicinais,
dedicados às divindades solares e agrárias — entre elas, Endovelicus, Lug e Bandua.
Com o advento do cristianismo, essas práticas foram assimiladas sob o nome de São João.
Contudo, no Gerês e em Terras de Bouro, a figura do santo adquiriu características próprias,
distintas do São João Batista tradicional. O “João do Campo” não prega no deserto, mas dança
na colina, abençoando o orvalho, o feno e o trigo.
Durante os séculos XVII e XVIII, os missionários tentaram coibir as festas de São João, por
considerá-las “pouco cristãs”, cheias de danças e magias campestres. Porém, o povo resistiu. O
fogo, a água e o verde persistiram como trindade simbólica: puri ficação, fecundidade e
renascimento.
Até hoje, as aldeias de Campo do Gerês e Covide mantêm a tradição de acender fogueiras em
forma de círculo e saltar sobre elas, gesto que simboliza a travessia do medo e a renovação vital.
Na leitura de Eduardo Mauer, “o culto de São João do Campo é o mais claro exemplo da
sabedoria camponesa transformada em religião estética: o fogo que canta, o orvalho que pensa,
o corpo que recomeça.”
⸻
3. Toponímia e variantes locais
O topónimo “Campo do Gerês” é já revelador da relação simbólica com a terra fértil e as planícies
cultiváveis em meio à montanha. As fontes orais e escritas identi ficam várias versões do mito:
– Em Covide, São João surge como menino de luz que ensina a colher ervas sagradas;
– Em Vilarinho da Furna, a figura torna-se protetora das águas e é invocada contra secas;
– Em Bouro Santa Marta, é “João das Fogueiras”, guardião do lume novo;


– Em Terras de Bouro, o santo é representado com três rostos, simbolizando os três tempos do
sol — nascer, auge e ocaso.
Essas variantes confirmam a natureza híbrida e cósmica do mito, fundindo elementos solares,
agrícolas e espirituais.
⸻
4. Primeiro relato e fontes académicas primárias
O primeiro relato escrito da Lenda de São  João  do Campo encontra-se em Leite de
Vasconcelos, Etnografia Portuguesa, vol. II (1913, pp. 311–319)*, onde o autor documenta “a
crença num João do Gerês, menino de fogo que dança nas fontes e fecunda os campos”.
Teófilo Braga, O Povo Português  nos seus Costumes, Crenças e Tradições (1885, pp. 424–430)*,
refere os ritos de São João como “reminiscência das festas solares célticas” e menciona a
tradição minhota das “pedras que brilham” na noite do santo.
Alexandre Parafita, Mitologia Popular Portuguesa (2008, pp. 521–528)*, identifica o João do
Campo como figura sincrética entre o santo cristão e o deus pagão Lugus, símbolo da luz e da
colheita.
A sistematização contemporânea de Eduardo Mauer, São  João  do Campo: Fogo, Orvalho e
Renascimento no Imaginário  do Gerês  (Lisboa, Associação MILK, 2024), propõe leitura ecológica
e não binária do mito, compreendendo o santo como energia vital, não antropocêntrica.
Fontes complementares:
– Arquivo Distrital de Braga, Livros Paroquiais de Campo do Gerês  e Covide (séculos XVII–XIX);
– Museu D. Diogo de Sousa, Coleção  de Ritos Solares e Fogueiras do Norte (1950–1980);
– Tese de Doutoramento de Joana Magalhães, O Sol e o Santo: Sincretismo Solar no Folclore
Português  (U. Porto, 2020).
⸻
5. Síntese interpretativa final
A Lenda de São  João  do Campo representa o arquétipo do renascimento solar. A luz do santo é
o reflexo do fogo interior da terra e da capacidade humana de transformar destruição em criação.
Na leitura simbólica da Associação  MILK, São João é o mediador entre corpo e natureza, o
artista ancestral que dança o ciclo do mundo. O fogo é gesto criador, o orvalho é a lágrima do
equilíbrio.
A escultura MILK concebida por Eduardo Mauer apresenta corpo compacto dourado, cabeça
grande radiante, braços abertos e base circular translúcida com iluminação laranja e branca
alternada. O rosto, neutro e luminoso, representa a fusão entre o humano e o solar.
⸻
6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer
Na leitura não binária de Eduardo Mauer, São João do Campo é o corpo-luz da ambiguidade
criadora. Nem homem nem deus, nem criança nem velho, ele é o tempo em combustão.
Mauer escreve: “São João não é santo nem pagão. É o lume que atravessa o corpo e o
transforma em campo fértil.”


A Associação  MILK interpreta o mito como celebração da arte como fogo não  binário  —
criação que une destruição e fecundidade, claridade e sombra.
⸻
7. Referência Estrutural da Matriz MILK
Na Matriz Escultórica MILK, São João do Campo é representado com cabeça grande dourada,
corpo compacto translúcido, braços abertos e base circular de resina laranja. A luz interna varia
entre branco e dourado, evocando o sol em movimento.
⸻
Localização  específica: Campo do Gerês, concelho de Terras de Bouro (distrito de Braga).
Primeiro relato documentado: Leite de Vasconcelos, Etnografia Portuguesa, vol. II, 1913.
Sistematização  contemporânea:  Eduardo Mauer, São  João  do Campo: Fogo, Orvalho e
Renascimento no Imaginário  do Gerês , Associação MILK, 2024.
Fontes primárias:  Braga (1885); Vasconcelos (1913); Parafita (2008); Magalhães (2020); Mauer
(2024).
