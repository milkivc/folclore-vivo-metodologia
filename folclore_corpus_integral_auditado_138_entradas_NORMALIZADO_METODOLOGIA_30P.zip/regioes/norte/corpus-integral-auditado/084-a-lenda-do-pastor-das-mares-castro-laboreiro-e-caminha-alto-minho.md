# 084. A Lenda do Pastor das Marés (Castro Laboreiro e Caminha – Alto Minho)

**Base documental e empírica:** pesquisa documental, análise comparada de fontes públicas, sistematização de tradição oral, relatos orais de pesquisa de campo e revisão semântica conduzidas no âmbito do Folclore Vivo da Associação MILK - Movimento de Intervenções e Linguagens Kulturais e Arte.
**Estado editorial:** corpus de pesquisa de campo e documentação cultural em revisão pública.
**Regra de publicabilidade:** esta entrada não deve ser lida como prova histórica definitiva, inventário patrimonial oficial, validação etnográfica concluída ou certificação académica externa sem verificação documental própria.
**Regra jurídica/RGPD:** não publicar nomes de informantes, contactos, moradas, entrevistas integrais, imagens identificáveis, gravações, dados de menores, coordenadas sensíveis ou materiais comunitários sem autorização.
**Regra de não invenção:** a presente readequação corrige a camada editorial e metodológica sem acrescentar factos, fontes, topónimos, coordenadas ou relatos não existentes no corpus-base.
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

84. A Lenda do Pastor das Marés (Castro Laboreiro e Caminha – Alto Minho)
(Sistematização  contemporânea  conduzida por Eduardo Mauer no âmbito  das pesquisas sobre
Folclore Vivo da Associação  MILK – Movimento de Intervenções e Linguagens Kulturais e Arte,
com base em recolhas orais e documentais realizadas entre 2023 e 2025 nas localidades de
Castro Laboreiro, Vilarelho, Seixas e Caminha, cruzadas com fontes etnográ ficas do Museu de
Etnologia, Arquivo Distrital de Viana do Castelo e testemunhos da tradição  marítima  e pastoril
minhota.)
⸻
1. Descrição  simbólica e narrativa
A Lenda do Pastor das Marés é um dos relatos mais singulares do imaginário do Alto Minho,
por fundir dois universos aparentemente opostos — o das montanhas e o do mar. Segundo a
tradição, o Pastor das Marés era um homem que escutava o som do oceano dentro das
conchas, mesmo vivendo em Castro Laboreiro, longe da costa. Era conhecido pela sua estranha
capacidade de prever a subida e descida das águas, de sentir o rumor das marés mesmo nas
serras.


Diz-se que, quando o Pastor caminhava, as ondas imitavam os seus passos. Quando
descansava, o mar repousava. O povo acreditava que ele possuía um dom concedido por uma
força antiga — talvez uma divindade das águas —, e que tinha nascido de uma mulher que
sonhara com o mar num lugar sem horizonte.
Uma das versões recolhidas por Eduardo Mauer (2024) narra que o Pastor das Marés era pastor
de ovelhas em Castro Laboreiro, mas todas as manhãs desaparecia por horas, descendo até ao
rio Laboreiro para escutar as correntes. “Dizia-se que falava com a água”, relatou uma informante
de 89 anos. “E que as ovelhas não se afastavam, porque sabiam que ele trazia o tempo certo.”
Noutra versão, oriunda de Caminha, o Pastor teria sido marinheiro naufragado que, ao acordar
na serra, esqueceu o passado e passou a guardar rebanhos, mas o mar nunca o esqueceu: as
marés subiam e desciam conforme o seu humor.
A sua figura é descrita de forma ambígua: homem magro, de rosto sereno e olhos que mudam
de cor com o céu. Traz sempre uma concha presa ao cinto e um cajado feito de madeira
húmida, que parece recém-saído das ondas. À noite, senta-se junto das fragas e canta baixinho
— canções sem palavras, mas que o vento leva até o mar.
O Pastor das Marés é, assim, o mediador entre o ritmo terrestre e o marítimo, um ser que une
o ciclo das águas ao ciclo dos rebanhos, a vastidão ao recolhimento. Nas palavras de Mauer, “ele
é o corpo que liga o rumor do mar ao silêncio da montanha — o pastor do intervalo entre o sal e
o musgo.”
⸻
2. Contexto histórico e social
O mito do Pastor das Marés re flete a coexistência histórica entre duas economias simbólicas do
norte português: a pastorícia serrana e a vida marítima costeira. A região de Castro Laboreiro,
embora distante do mar, manteve contacto com as zonas litorâneas através das rotas de
transumância , que ligavam o planalto barrosão às feiras de Caminha e Viana do Castelo. Os
pastores deslocavam-se durante semanas, conduzindo ovelhas e cabras até aos vales onde o
clima era mais ameno.
Durante essas jornadas, estabeleciam relações comerciais e afetivas com as comunidades
costeiras. Trocavam lã e queijo por peixe seco, sal e histórias. O Pastor das Marés nasce
simbolicamente dessa confluência — a fusão  entre o mundo da montanha e o do mar, entre o
isolamento e a vastidão.
O contexto histórico da lenda está documentado nos “Cadernos de Tradições Orais do Alto
Minho” (Arquivo de Viana, 1892–1914), onde se lê que “certos homens da serra conheciam o mar
como se nele tivessem nascido, falando dele com saudade inexplicável”. Essa memória cultural
da ausência presente do mar é central para compreender o mito.
No século XX, com o abandono gradual da pastorícia tradicional e a migração para o litoral, a
figura do Pastor das Marés passou a ser interpretada como símbolo do retorno — o homem que
guarda dentro de si a lembrança do mar perdido. Para os pescadores, era um santo anónimo que
“dormia na serra e sonhava as marés certas”; para os pastores, era um aviso de que toda a
montanha acaba por regressar à água.
Na leitura antropológica de Eduardo Mauer, o Pastor das Marés é “a alma transumante do norte
português — aquele que nunca fica inteiro num só lugar”.
⸻
3. Toponímia e variantes locais

O termo “Pastor das Marés” aparece em diversas versões orais entre Castro Laboreiro, Lamas
de Mouro e Caminha, refletindo o trajeto simbólico do mito: das montanhas ao mar.
As variantes locais recolhidas incluem:
– “O Pastor do Vento” (Castro Laboreiro): homem que entende a linguagem das correntes de ar
e das águas subterrâneas;
– “O Homem da Concha” (Vilarelho): pastor que guarda uma concha que canta o mar;
– “O Marinheiro da Serra” (Caminha): naufragado transformado em pastor, cujas lágrimas
chamam as marés;
– “O Guardador de Marés” (Seixas): espírito ancestral que equilibra as águas do Lima.
A palavra “maré”, aqui, adquire valor metafórico, indicando ritmo e correspondência: o ciclo da
natureza, o bater do coração, a alternância entre presença e ausência. O Pastor das Marés é o
guardião  do compasso, o que conhece o tempo de cada coisa.
⸻
4. Primeiro relato e fontes académicas primárias
O primeiro relato escrito da lenda aparece em Alexandre Parafita, Mitologia Popular Portuguesa
(2008, pp. 792–799)*, que regista testemunhos de Caminha e Melgaço, descrevendo “um pastor
que ouve o mar nas serras e fala com o vento”.
Leite de Vasconcelos, Etnografia Portuguesa, vol. VI (1918, pp. 337–343)*, menciona “os
homens da montanha que preveem as marés” como categoria simbólica do saber popular.
Teófilo Braga, O Povo Português  nos seus Costumes, Crenças e Tradições (1885, pp. 631–635)*,
recolhe referências ao “marinheiro que voltou à serra e se fez pastor para ouvir o mar no silêncio
da pedra”.
A sistematização contemporânea de Eduardo Mauer, O Pastor das Marés:  Transumância  e
Travessia no Imaginário  do Norte de Portugal (Lisboa, Associação MILK, 2025)*, consolida o mito
com base em 17 entrevistas realizadas entre 2023 e 2025 e na comparação simbólica com
arquétipos mediterrânicos de mediação entre montanha e mar (Hermes, Pan, Tritão).
Fontes complementares:
– Arquivo Distrital de Viana do Castelo, Cadernos de Tradições Orais (1892–1914);
– Ecomuseu do Barroso, Relatos de Transumância  e Fé  (1982–1996);
– Tese de Doutoramento de Clara Moura, Pastores, Ondas e Ecos: Identidades Móveis no Folclore
Peninsular (U. Porto, 2020).
⸻
5. Síntese interpretativa final
O Pastor das Marés é o arquétipo da escuta. Ele não fala, mas ouve o som do mundo — o mar,
o vento, o coração das pedras. O seu dom é o da correspondência: o saber que tudo se move
em ritmos partilhados.
Na leitura simbólica da Associação  MILK, o Pastor das Marés é o guardião  do ritmo cósmico,
aquele que recorda à humanidade a necessidade de sincronizar o corpo com os ciclos naturais. A
sua figura une o pastor terrestre (domesticador) e o marinheiro (errante), constituindo a síntese
entre estabilidade e viagem, interioridade e horizonte.
A escultura MILK, criada por Eduardo Mauer, representa o Pastor com corpo compacto e base
ondulada, cabeça grande e cajado curto, vestido com uma capa de resina azul-esverdeada que

evoca simultaneamente o musgo e a espuma do mar. No peito, uma pequena concha dourada
simboliza a escuta interior.
Para Mauer, “o Pastor das Marés é o ser que mantém o tempo do mundo — aquele que garante
que a água volta, mas nunca a mesma.”
⸻
6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer
Na leitura não binária de Eduardo Mauer, o Pastor das Marés é o ser da correspondência, que
não se de fine por opostos (terra/mar, homem/mulher, fixo/móvel), mas pelo fluxo entre eles.
“O Pastor é o corpo do entre: respira água e caminha pedra. É o que não escolhe
margem, porque sabe que a maré tem ambas.”
Mauer propõe aqui o conceito de identidade rítmica — o sujeito que se constrói não por
oposição, mas por oscilação. O Pastor das Marés é, portanto, metáfora do não  binário
existencial, no qual o ser encontra liberdade na alternância e não na fixidez.
A Associação  MILK adota esta leitura como base filosófica para o Folclore Vivo,
reconhecendo na figura do Pastor das Marés o modelo do artista contemporâneo —
aquele que escuta, traduz e devolve o ritmo coletivo.
⸻
7. Referência Estrutural da Matriz MILK
Na Matriz Escultórica MILK – Série Folclore Vivo, o Pastor das Marés é concebido como
síntese formal entre o terrestre e o aquático:
– Corpo: compacto, cabeça grande, braços curtos, base ondulante.
– Cores: azul-mar, verde-musgo e reflexos dourados.
– Materiais: resina pigmentada, fibra translúcida e inserções minerais.
– Expressão:  serena e introspectiva, com olhar voltado para o chão.
– Base: movimento circular simulando a oscilação das marés.
A escultura traduz o conceito de corpo-rítmico, fundindo tempo, matéria e silêncio numa única
presença.
⸻
Localização  específica: Castro Laboreiro e Caminha (distrito de Viana do Castelo).
Primeiro relato documentado: Parafita, Mitologia Popular Portuguesa, 2008.
Sistematização  contemporânea:  Eduardo Mauer, O Pastor das Marés:  Transumância  e Travessia
no Imaginário  do Norte de Portugal, Associação MILK, 2025.
Fontes primárias:  Braga (1885); Vasconcelos (1918); Parafita (2008); Moura (2020); Mauer (2025).
