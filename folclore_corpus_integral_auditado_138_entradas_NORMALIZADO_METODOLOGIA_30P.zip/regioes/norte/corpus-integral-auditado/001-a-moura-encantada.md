# 001. A Moura Encantada

**Base documental e empírica:** pesquisa documental, análise comparada de fontes públicas, sistematização de tradição oral, relatos orais de pesquisa de campo e revisão semântica conduzidas no âmbito do Folclore Vivo da Associação MILK - Movimento de Intervenções e Linguagens Kulturais e Arte.
**Estado editorial:** corpus de pesquisa de campo e documentação cultural em revisão pública.
**Regra de publicabilidade:** esta entrada não deve ser lida como prova histórica definitiva, inventário patrimonial oficial, validação etnográfica concluída ou certificação académica externa sem verificação documental própria.
**Regra jurídica/RGPD:** não publicar nomes de informantes, contactos, moradas, entrevistas integrais, imagens identificáveis, gravações, dados de menores, coordenadas sensíveis ou materiais comunitários sem autorização.
**Regra de não invenção:** a presente readequação corrige a camada editorial e metodológica sem acrescentar factos, fontes, topónimos, coordenadas ou relatos não existentes no corpus-base.
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

1. A Moura Encantada
(Sistematização  contemporânea  conduzida por Eduardo Mauer e Nuno Araújo no âmbito  das
pesquisas sobre Folclore Vivo da Associação  MILK – Movimento de Intervenções e Linguagens
Kulturais e Arte)
1. Descrição  simbólica e narrativa
Entre as figuras mais antigas e persistentes do imaginário português, a Moura Encantada ocupa
o centro de um vasto sistema simbólico que atravessa o tempo, as geografias e as fronteiras
culturais. Nas lendas recolhidas no Norte de Portugal — especialmente em Trás-os-Montes , Alto
Minho e Douro Litoral — a Moura surge como mulher de beleza sobrenatural, habitante de
grutas, penedos, fontes e castros, guardiã de tesouros ocultos e portadora de saberes antigos. É
simultaneamente figura de desejo e de perigo, de promessa e de ruína, símbolo da continuidade
entre o mundo visível e o mundo subterrâneo.
Na tradição oral, a Moura Encantada é descrita como mulher alta, de longos cabelos negros ou
dourados, vestida com mantos translúcidos, que surge ao amanhecer ou ao crepúsculo. Em
algumas versões, penteia-se com pentes de ouro à beira de fontes, deixando cair uma lágrima
que se transforma em pedra preciosa. Noutras, aparece envolta em fumo, metade mulher,
metade serpente. O seu olhar hipnótico fascina quem o encontra — e o encontro nunca é casual.
Quem a vê é escolhido, e esse encontro marca um destino: o da libertação ou da perdição.
Os contos mais antigos narram que as Mouras foram antigas deusas ou sacerdotisas pagãs ,
transformadas em encantadas quando o cristianismo se impôs sobre os cultos locais da terra e
da água. Por isso permanecem presas aos montes, às pedras e aos rios, guardando riquezas que
só poderão ser libertadas quando alguém quebrar o encanto. Mas esse ritual exige pureza e
coragem: o mortal deve beijar a Moura, suportar o seu olhar, ou resistir ao medo quando ela se
transforma em animal — serpente, cabra ou peixe. Quase sempre, o humano falha. A lenda
repete o fracasso: o encantamento perpetua-se, e o tesouro continua escondido.
O ciclo narrativo das Mouras é vasto. As versões transmontanas falam das Mouras do Castro de
Avelãs , das Mouras do Alvão , das Mouras de Lamas de Orelhão , enquanto no Minho
persistem as Mouras da Senhora da Peneda e as Mouras do Monte da Cividade. Cada região
atribui-lhes funções específicas: ora protetoras das colheitas, ora sentinelas dos mortos, ora
amantes traídas pelo tempo. Todas, porém, partilham a condição de liminaridade — seres entre
mundos, nem vivos nem mortos, nem humanas nem divinas.
A Moura Encantada é também símbolo da memória subterrânea da terra portuguesa:
representação mítica dos povos pré-romanos e das civilizações esquecidas. O ouro que guarda é
metáfora do saber ancestral que se perdeu com a cristianização. Na leitura contemporânea
proposta por Eduardo Mauer e Nuno Araujo, a Moura é “a guardiã do inconsciente coletivo
português”, o espelho que devolve à comunidade a consciência da sua origem múltipla.
2. Contexto histórico e social
Historicamente, o mito da Moura Encantada nasce do sincretismo entre as antigas divindades
femininas das águas e dos montes — como Nábia , Trebaruna e Ataecina — e a memória popular
das ocupações árabes. O termo “moura” surge, etimologicamente, associado a maura, “mulher
do sul”, mas a sua carga simbólica vai muito além da etnicidade. Desde a Idade Média, o
imaginário cristão transformou as antigas deusas locais em figuras ambíguas: pagãs
amaldiçoadas, ora demonizadas, ora santificadas.
Nos séculos XV e XVI, com a expansão marítima e a recon figuração das identidades ibéricas, a
figura da Moura consolidou-se como símbolo da alteridade interna — o “outro” dentro de

Portugal. As crónicas e romances de cavalaria mencionam “mouras encantadas” que aparecem a
cavaleiros cristãos, oferecendo-lhes amor e tesouros em troca da quebra de um voto. A lenda
funcionava como advertência moral, mas também como memória difusa da convivência cultural
entre cristãos, judeus e muçulmanos.
Durante o século XIX, a recolha etnográ fica de Teófilo Braga e José Leite de Vasconcelos fixou
a Moura Encantada como figura central do folclore português. Para Braga, ela representava a
sobrevivência do “paganismo popular” nas camadas rurais; para Vasconcelos, era manifestação
do espírito telúrico da terra, prova de que o povo preservava, sob o verniz cristão, uma
cosmologia antiga baseada no ciclo da fertilidade e da morte.
Socialmente, a Moura foi também mecanismo de transmissão moral: ensinava o respeito pelos
lugares sagrados, a prudência no desejo, a reverência à natureza. Ao mesmo tempo,
representava uma forma de resistência feminina dentro de sociedades patriarcais. A mulher
encantada, inacessível e poderosa, era imagem invertida da mulher submissa do quotidiano rural.
O mito servia, assim, de válvula simbólica para o inconsciente coletivo feminino.
Nas comunidades transmontanas e minhotesas, a Moura continua a marcar o calendário:
celebra-se nas festas da Peneda, em romarias onde as mulheres sobem montanhas para pedir
amor, fertilidade e proteção. Esses rituais, estudados por Alexandre Parafita, revelam a
permanência da dimensão ritual da lenda, mesmo sob roupagem católica.
3. Toponímia e variantes locais
A presença da Moura Encantada é topogra ficamente densa no Norte:
– Trás-os-Montes:  Moura de Lamas de Orelhão (Mirandela), Moura do Castelo de Algoso
(Mogadouro), Moura do Alvão (Vila Real).
– Minho: Moura da Senhora da Peneda (Arcos de Valdevez), Moura de Giela (Ponte da Barca),
Moura de S. Bento (Terras de Bouro).
– Douro Litoral: Moura da Cividade (Guimarães), Moura do Castelo de Lanhoso, Moura da Serra
de Montemuro.
Esses topónimos estão frequentemente ligados a sítios arqueológicos: castros, penedos
gravados, fontes e ruínas pré-romanas. Em muitos casos, o próprio relevo natural recebe o nome
de “Penedo da Moura”, “Fraga da Moura”, “Fonte da Moura”. Essa persistência toponímica
demonstra a fusão entre território e mito.
As variantes linguísticas incluem “moura-serpente”, “moura-de-ouro” e “moura-fiandeira”, cada
qual representando um aspecto do mesmo arquétipo: a serpente como poder subterrâneo, o
ouro como sabedoria, a roca como destino.
4. Primeiro relato e fontes académicas primárias
O primeiro relato literário identi ficável da Moura Encantada em território nortenho aparece em
Teófilo Braga, Contos Tradicionais do Povo Português , vol. I (Lisboa, 1883), na narrativa “A
Moura do Castelo de Lanhoso”. Braga recolheu o conto em Guimarães e interpretou-o como
“eco das divindades aquáticas e ctónicas da Lusitânia antiga”.
José Leite de Vasconcelos, em Etnografia Portuguesa, vol. II (1913), dedicou extenso capítulo
às Mouras, classi ficando-as como “entes telúricos femininos”, analogáveis às fées  francesas e
lamias mediterrânicas.
Consiglieri Pedroso, em Contribuições para uma Mitologia Popular Portuguesa (1897), sublinhou
a relação entre as Mouras e os cultos solares, vendo nelas “deusas decadentes transformadas
em fantasmas”.


Alexandre Parafita, em Mitologia Popular Portuguesa (2008), mapeou mais de 300 variantes da
lenda em Portugal, das quais cerca de 80 no Norte, com especial incidência em Vila Real,
Bragança e Viana do Castelo.
Eduardo Mauer e Nuno Araujo propõem ler a Moura como símbolo arquetípico da memória
feminina não  domesticada, reinterpretando o encantamento como metáfora da exclusão
histórica do feminino e da sua persistência subterrânea.
Fontes complementares:
– Arquivo Nacional da Torre do Tombo, cód. “Superstitiones Lusitaniae” (séc. XVII).
– Museu Nacional de Arqueologia, coleção “Cultos Pré-Românicos”.
– Tese de Doutoramento de Ana R. Figueiredo, A Moura Encantada: Representações do
Feminino e da Alteridade na Tradição  Oral Portuguesa (U. do Minho, 2015).
– DGPC, Inventário Nacional do Património Imaterial, registo “As Mouras Encantadas do Norte”
(2019).
5. Síntese interpretativa final
A Moura Encantada é o eixo simbólico da identidade mítica portuguesa: síntese entre paganismo
e cristianismo, entre o feminino e o sagrado, entre o medo e o desejo. Representa o país
subterrâneo — aquele que resiste, escondido, à superfície racional da história.
Na leitura do Folclore Vivo / Associação  MILK, a Moura não é apenas relíquia do passado, mas
agente contemporâneo  de ressignificação . As suas múltiplas formas — mulher, serpente,
sombra — re fletem as transformações sociais e culturais do feminino. O encantamento perpetua-
se enquanto houver silêncio sobre as vozes antigas; quebrá-lo é escutá-las novamente.
A escultura concebida por Eduardo Mauer e Nuno Araújo segundo a Matriz MILK retrata a Moura
com corpo compacto, cabeça expressiva, olhar sereno e sorriso sarcástico; as cores rosa, lilás,
vermelho e amarelo evocam o ouro, o sangue, o feitiço e o despertar.
6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer
A leitura não binária proposta por Eduardo Mauer e Nuno Araujo no contexto do Núcleo
Bússola de Não  Binarismo e Folclore Vivo da Associação MILK amplia o campo simbólico da
Moura Encantada. Ela deixa de ser apenas representação da mulher mítica e passa a figurar o
corpo liminar — aquele que habita entre estados e categorias, recusando a fixação de género,
moral e forma.
O encantamento da Moura é, nesta ótica, metáfora da não conformidade: uma existência que
não cabe no binarismo entre sagrado e profano, masculino e feminino, humano e natural. O seu
poder de metamorfose — mulher que vira serpente, sombra, fumaça, estrela — é a própria
expressão do corpo fluido e da identidade em trânsito.
Ao ser lida como entidade não binária, a Moura revela o papel do mito como espaço de
libertação simbólica. O “encantamento” torna-se dispositivo de resistência — o feitiço que
preserva o ser fora das categorias opressivas. Para Mauer, “a Moura é o corpo interdito que
persiste: é a voz que não pôde ser dita, mas que nunca se calou”.
Esta leitura é coerente com o princípio do Folclore Vivo como território fluido: o mito é um
organismo em mutação constante. A Moura, ao resistir à decifração, ensina a multiplicidade
como condição da existência.


7. Referência Estrutural da Matriz MILK
Na Matriz Escultórica MILK, a Moura Encantada é representada segundo o cânone visual da
série Folclore Vivo: cabeça grande e expressiva, corpo compacto e robusto, braços curtos e
gesto simbólico de oferenda. As cores predominantes — rosa, lilás, vermelho e amarelo —
dialogam com a tradição simbólica do ouro e do amor interdito. A ausência de asas e chifres
preserva a neutralidade formal da matriz, enquanto o brilho do verniz remete ao “encantamento”
que oculta e revela.
Na instalação proposta para o ciclo Mitos do Norte, a Moura deverá surgir em ambiente de
penumbra, com fundo negro fosco e luz dourada difusa, criando o efeito de aparição.
⸻
Localização  específica: Trás-os-Montes (Mirandela, Mogadouro, Vila Real), Minho (Arcos de
Valdevez, Ponte da Barca, Terras de Bouro), Douro Litoral (Guimarães, Póvoa de Lanhoso).
Primeiro relato documentado: Teófilo Braga, Contos Tradicionais do Povo Português , vol. I,
1883.
Fontes primárias:  Braga (1883); Vasconcelos (1913); Pedroso (1897); Parafita (2008); Figueiredo
(2015); DGPC (2019);
