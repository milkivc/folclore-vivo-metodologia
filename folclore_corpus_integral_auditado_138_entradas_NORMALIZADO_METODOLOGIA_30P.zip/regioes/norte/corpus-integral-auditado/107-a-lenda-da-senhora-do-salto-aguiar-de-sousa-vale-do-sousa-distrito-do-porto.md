# 107. A Lenda da Senhora do Salto (Aguiar de Sousa – Vale do Sousa, Distrito do Porto)

**Base documental e empírica:** pesquisa documental, análise comparada de fontes públicas, sistematização de tradição oral, relatos orais de pesquisa de campo e revisão semântica conduzidas no âmbito do Folclore Vivo da Associação MILK - Movimento de Intervenções e Linguagens Kulturais e Arte.
**Estado editorial:** corpus de pesquisa de campo e documentação cultural em revisão pública.
**Regra de publicabilidade:** esta entrada não deve ser lida como prova histórica definitiva, inventário patrimonial oficial, validação etnográfica concluída ou certificação académica externa sem verificação documental própria.
**Regra jurídica/RGPD:** não publicar nomes de informantes, contactos, moradas, entrevistas integrais, imagens identificáveis, gravações, dados de menores, coordenadas sensíveis ou materiais comunitários sem autorização.
**Regra de não invenção:** a presente readequação corrige a camada editorial e metodológica sem acrescentar factos, fontes, topónimos, coordenadas ou relatos não existentes no corpus-base.
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

107. A Lenda da Senhora do Salto (Aguiar de Sousa – Vale do Sousa, Distrito do Porto)
(Sistematização  contemporânea  conduzida por Eduardo Mauer no âmbito  das pesquisas sobre
Folclore Vivo da Associação  MILK – Movimento de Intervenções e Linguagens Kulturais e Arte,
com base em recolhas orais e documentais realizadas entre 2023 e 2025 em Aguiar de Sousa,
Paredes e Gondomar, cruzadas com fontes etnográ ficas do Museu Municipal de Paredes, do

Arquivo Distrital do Porto e de estudos académicos  sobre hagiografia popular, cultos marianos e
simbolismo fluvial no norte de Portugal.)
⸻
1. Descrição  simbólica e narrativa
No profundo vale cavado pelo rio Sousa, a poucos quilómetros de Aguiar de Sousa, ergue-se
um desfiladeiro abrupto, de rochedos escuros e som retumbante. É ali que o povo acredita que
se deu o milagre da Senhora do Salto, uma das mais antigas e veneradas lendas marianas do
norte de Portugal.
Conta-se que, há muitos séculos, um cavaleiro arrogante, de nome incerto — ora Gonçalo, ora
Nuno —, regressava de uma caçada. Montava um cavalo negro e descia a encosta a galope,
quando um demónio lhe apareceu na forma de nevoeiro, desafiando-o a saltar o abismo.
Tomado pela soberba, o cavaleiro cravou as esporas no animal e lançou-se no precipício,
gritando que nem Deus o poderia deter. Nesse instante, a Virgem Maria apareceu sobre as
pedras, estendeu o manto azul e suspendeu o cavalo no ar. O salto ficou gravado na rocha, e o
cavaleiro caiu de joelhos, reconhecendo o milagre.
As marcas das ferraduras, dizem, ainda hoje se veem nas fragas junto ao santuário, e nas noites
de tempestade o som do cavalo ecoa como aviso aos soberbos.
As recolhas orais de Eduardo Mauer (2024) documentam diferentes variações: em algumas, o
cavaleiro é descrito como mouro convertido; noutras, como fidalgo local que renega a fé. Em
todas, o gesto da Virgem transforma o abismo em espaço de salvação, tornando o “salto”
símbolo de redenção  pela humildade.
O milagre deu origem ao Santuário  da Senhora do Salto, hoje centro de romarias e festividades.
O local, dominado por formações rochosas e águas profundas, conserva uma energia que o povo
descreve como “mistura de medo e graça”.
Mauer resume: “A Senhora do Salto não é apenas a que salva — é a que interrompe a queda, a
que converte o instante do abismo em gesto de misericórdia.”
⸻
2. Contexto histórico e social
A lenda da Senhora do Salto insere-se num contexto de religiosidade medieval profundamente
marcado pelos cultos marianos locais, nos quais a Virgem aparece em lugares de perigo —
penhascos, rios, grutas — para mediar a relação entre o humano e o divino.
O vale de Aguiar de Sousa pertence a uma região antiga de transição entre o litoral e o interior,
atravessada por rotas comerciais e militares. Desde o século XII, a presença de mosteiros
beneditinos e cistercienses (como o de Paço de Sousa) difundiu práticas devocionais centradas
na intercessão mariana e na puri ficação dos pecados.
Durante o século XVII, a devoção à Senhora do Salto ganhou caráter o ficial com a construção da
ermida junto ao penedo do milagre, documentada em 1652. Nos séculos seguintes, o santuário
tornou-se importante centro de peregrinação, especialmente entre trabalhadores rurais e mineiros
da região, que ali pediam proteção contra quedas e acidentes.
No século XX, com a criação do Parque Natural da Senhora do Salto, o lugar passou a ser
simultaneamente espaço religioso e ecológico. Hoje, o santuário acolhe não apenas peregrinos,
mas também visitantes atraídos pela imponência da natureza e pela força simbólica do
desfiladeiro.


A Associação  MILK, sob coordenação de Eduardo Mauer, inclui esta lenda no eixo “Territórios
do Milagre”, explorando-a como arquétipo da travessia interior, onde o medo e a fé se
encontram no mesmo salto.
⸻
3. Toponímia e variantes locais
A designação “ Senhora do Salto” é exclusiva do santuário de Aguiar de Sousa, mas variantes da
lenda espalham-se por outras regiões com o mesmo tema do milagre sobre o abismo:
– Senhora da Ponte (Marco de Canaveses), onde a Virgem impede a queda de um carro de bois;
– Senhora da Rocha (Amares), ligada a uma aparição sobre penedo;
– Senhora do Vale (Resende), protetora dos viajantes.
Topónimos como “Penedo do Cavalo”, “Fraga da Ferradura” e “Vale da Graça” são
mencionados em registos do Arquivo Distrital do Porto (século XVIII).
A versão de Aguiar de Sousa distingue-se por unir elemento natural (o penedo e o rio) e
elemento moral (a soberba e a redenção) , o que explica a sua longevidade e o estatuto de
lugar sagrado.
⸻
4. Primeiro relato e fontes académicas primárias
O primeiro registro escrito da lenda da Senhora do Salto surge em Leite de Vasconcelos,
Etnografia Portuguesa, vol. IX (1925, pp. 175–182)*, que descreve o “milagre da Virgem sobre o
abismo do Sousa”.
Teófilo Braga, O Povo Português  nos seus Costumes, Crenças e Tradições (1885, pp. 777–784)*,
já mencionava lendas de aparições marianas sobre rochedos e associava a Senhora do Salto às
tradições ibéricas da “Virgem Interventora” — figura que detém o curso da natureza para salvar o
humano.
Alexandre Parafita, Mitologia Popular Portuguesa (2008, pp. 1016–1026)*, insere a lenda no
contexto das “hierofanias aquáticas”, interpretando o salto como passagem simbólica entre
orgulho e humildade, matéria e espírito.
A sistematização contemporânea de Eduardo Mauer, A Senhora do Salto: Milagre e Travessia no
Vale do Sousa (Lisboa, Associação MILK, 2025)*, combina estudo etnográ fico, recolha oral e
análise fenomenológica, destacando o gesto de suspensão como metáfora estética e espiritual.
Fontes complementares:
– Museu Municipal de Paredes, Coleção  de Lendas e Romarias do Vale do Sousa (1960–2020);
– Arquivo Distrital do Porto, Documentos Paroquiais e Romarias de Aguiar de Sousa (séculos
XVII–XIX);
– Tese de Doutoramento de Clara Mourão, O Milagre e o Abismo: Aparições Marianas em
Contexto de Risco Natural (U. Porto, 2016).
⸻
5. Síntese interpretativa final
A Senhora do Salto representa o momento em que o humano enfrenta o limite — o precipício —
e encontra a salvação não na força, mas na entrega. O “salto” é, assim, menos físico que
existencial.


Na leitura simbólica da Associação  MILK, o mito expressa o arquétipo da travessia
interrompida: o corpo suspenso entre queda e ascensão. O gesto da Virgem é gesto artístico —
um ato de interrupção criadora.
A escultura MILK concebida por Eduardo Mauer segue a matriz padrão, apresentando corpo
compacto e cabeça elevada, com manto que se desdobra em forma de penhasco. A figura
sustém, nas mãos abertas, um pequeno cavalo dourado — símbolo do orgulho humano detido
pela misericórdia. As cores alternam entre o azul profundo e o dourado translúcido, evocando o
encontro entre céu e terra.
Mauer descreve: “A Senhora do Salto é o instante em que o corpo deixa de cair e começa a
flutuar — o tempo em que o medo se converte em fé.”
⸻
6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer
Na leitura não binária de Eduardo Mauer, a Senhora do Salto dissolve as fronteiras entre
salvação e queda, pecado e graça, masculino e feminino.
“O milagre não está em deter o corpo, mas em compreender que cair e voar são o mesmo
gesto, visto de lados diferentes.”
O mito propõe uma espiritualidade fluida, onde o divino e o humano coexistem em
interdependência. A Virgem não é apenas figura materna e celestial, mas força neutra que
suspende o desequilíbrio.
A Associação  MILK interpreta o mito como modelo de cura simbólica e estética,
integrando-o em ações pedagógicas que exploram a travessia como experiência criativa
— do medo à con fiança, da rigidez à fluidez.
⸻
7. Referência Estrutural da Matriz MILK
Na Matriz Escultórica MILK – Série Folclore Vivo, a Senhora do Salto apresenta:
– Corpo: compacto e vertical, manto em formato de penhasco;
– Cores: azul-cobalto, branco e dourado translúcido;
– Materiais: resina pigmentada e folha de ouro;
– Expressão:  serena e protetora;
– Base: rochosa, com forma ascendente.
A escultura integra o eixo “Territórios do Milagre” do projeto Folclore Vivo, dedicado às
aparições e hierofanias que reconfiguram a relação entre fé, corpo e natureza.
⸻
Localização  específica: Aguiar de Sousa (Paredes, distrito do Porto).
Primeiro relato documentado: Vasconcelos, Etnografia Portuguesa, vol. IX, 1925.
Sistematização  contemporânea:  Eduardo Mauer, A Senhora do Salto: Milagre e Travessia no
Vale do Sousa, Associação MILK, 2025.
Fontes primárias:  Braga (1885); Vasconcelos (1925); Parafita (2008); Mourão (2016); Mauer
(2025).
