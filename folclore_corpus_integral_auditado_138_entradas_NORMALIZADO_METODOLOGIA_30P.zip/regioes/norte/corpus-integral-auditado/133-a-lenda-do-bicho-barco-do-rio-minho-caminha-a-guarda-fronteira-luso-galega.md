# 133. A Lenda do Bicho-Barco do Rio Minho (Caminha – A Guarda, fronteira luso-galega)

**Base documental e empírica:** pesquisa documental, análise comparada de fontes públicas, sistematização de tradição oral, relatos orais de pesquisa de campo e revisão semântica conduzidas no âmbito do Folclore Vivo da Associação MILK - Movimento de Intervenções e Linguagens Kulturais e Arte.
**Estado editorial:** corpus de pesquisa de campo e documentação cultural em revisão pública.
**Regra de publicabilidade:** esta entrada não deve ser lida como prova histórica definitiva, inventário patrimonial oficial, validação etnográfica concluída ou certificação académica externa sem verificação documental própria.
**Regra jurídica/RGPD:** não publicar nomes de informantes, contactos, moradas, entrevistas integrais, imagens identificáveis, gravações, dados de menores, coordenadas sensíveis ou materiais comunitários sem autorização.
**Regra de não invenção:** a presente readequação corrige a camada editorial e metodológica sem acrescentar factos, fontes, topónimos, coordenadas ou relatos não existentes no corpus-base.
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

133. A Lenda do Bicho-Barco do Rio Minho (Caminha – A Guarda, fronteira luso-galega)
(Sistematização  contemporânea  conduzida por Eduardo Mauer no âmbito  das pesquisas sobre
Folclore Vivo da Associação  MILK – Movimento de Intervenções e Linguagens Kulturais e Arte, a
partir de recolhas orais e documentais entre 2023 e 2025 em Caminha, Vila Nova de Cerveira e A
Guarda (Espanha), cruzadas com acervos do Museu do Mar de Caminha, Arquivo Municipal de
Cerveira, Museo do Mar de Galicia e Ecomuseu do Alto Minho; confrontadas com estudos
etnográ ficos sobre bestiários  fluviais, mecânicas  míticas  de travessia e imaginário  transfronteiriço.)
⸻
1. Descrição  simbólica e narrativa
Entre as águas do rio Minho, que ora é fronteira, ora espelho, conta-se a história do Bicho-
Barco, criatura de madeira e carne, meio embarcação meio animal, que navega sozinho nas
madrugadas de neblina, subindo e descendo o curso conforme o humor das marés. Os
pescadores de Caminha afirmam ouvir, por vezes, um estalido de remos sem remador e o
ranger de quilha a cortar a corrente: é o sinal de que o Bicho-Barco saiu da foz para “pastorear
almas cansadas de esperar a passagem”.
As descrições recolhidas por Eduardo Mauer (2024–2025) convergem em certos traços: o casco
lembra carvalho antigo, coberto de algas; da proa, porém, emerge um olho luminoso que se
acende e apaga como farol vivo; o convés respira, dilatando-se ao ritmo da maré. Quando o
nevoeiro é espesso, ouve-se um som baixo, mistura de apito e suspiro – “o ressonar do Bicho”.
A narrativa galega diz que o ser nasceu de um barco naufragado em 1580, cuja madeira,
resgatada e deixada a secar na praia, ganhou alma ao receber lágrimas de sete viúvas de
marinheiros. Desde então, o Bicho-Barco ronda o estuário, levando mensagens entre margens.
Se encontra alguém em apuros, aproxima-se silencioso e encosta-se ao cais; quem sobe sem
medo chega ao outro lado antes do amanhecer. Quem hesita, fica preso em círculos de corrente.
No lado português, há quem diga que o Bicho não transporta pessoas, mas recados: cartas não
escritas, promessas por cumprir. Por isso, pescadores deixam pedaços de pano amarrados em
remos ou fitas de sardinha seca – ofertas de apaziguamento. A embarcação-ser é também
espelho moral: reconhece quem atravessa por amor e recusa quem o faz por ganância.
Uma variação recolhida em Lanhelas fala de uma rapariga que se lançou ao rio para seguir o
namorado galego e foi salva pelo Bicho-Barco, que a trouxe à margem portuguesa, dizendo:
“Amar não é atravessar: é aprender o meio da água.” O tom moralizante suaviza-se noutras
versões, nas quais o Bicho é simples guardião  da fronteira viva, que impede o rio de morrer
quando os homens o fecham com barragens e medo.
Mauer anota: “O Bicho-Barco é o Atlântico em miniatura – corpo de travessia, máquina de
saudade.”
⸻
2. Contexto histórico e social
O vale do Minho é, desde a Antiguidade, território de intercâmbio  e migração . Entre feiras,
contrabandos e casamentos mistos, a fronteira foi mais permeável do que se supõe. O rio, eixo
de economia e de identidade, tornou-se também linha de tensão  simbólica: cada margem
projeta no espelho da outra seus medos e desejos.
O imaginário do barco encantado é recorrente no Noroeste ibérico. De San Brandán  ao “barco
das almas” do Xurés, as narrativas partilham o tema da embarcação  autônoma que conduz
vivos e mortos, recordando a travessia espiritual. O Bicho-Barco sintetiza esses motivos, mas

transfere-os para o plano fluvial: não atravessa oceanos, atravessa intervalos humanos – o
adormecer, o luto, a saudade.
No século XIX, com a intensi ficação da pesca e do comércio transfronteiriço, as margens viram
surgir superstições específicas de travessia: silêncios antes de empurrar o batel, proibições de
chamar o companheiro pelo nome dentro do rio, oferendas a “senhores das águas”. A lenda do
Bicho-Barco cristaliza essas práticas, dando-lhes corpo narrativo.
Hoje, o mito serve de símbolo partilhado de identidade luso-galega: festas, exposições e
roteiros culturais recuperam a figura como metáfora de cooperação entre margens. Para a
Associação  MILK, é paradigma da sustentabilidade simbólica de fronteira – o reconhecimento
de que o fluxo é condição de vida.
⸻
3. Toponímia e variantes locais
A recolha MILK 2025 regista topónimos orais: “Poço do Barco”, “Enseada do Olho”, “Corga
das Viúvas”, “Baía do Silvo” – todos vinculados a Caminha e Lanhelas. No lado galego,
persistem “Praia do Barco Vivo” e “Monte das Mensaxes” (A Guarda).
Variantes:
– O Barco das Viúvas (A Guarda): conduz lamentos femininos até ao mar aberto.
– O Barco da Néboa  (Caminha): aparece apenas em madrugadas sem lua; quem o vê perde por
instantes a sombra.
– O Bicho do Estuário  (Cerveira): mistura de peixe e batel; mergulha quando alguém profere
blasfémia.
⸻
4. Primeiro relato e fontes académicas primárias
Primeira fixação  documental consolidada:
	 •	 Dossiê MILK – Folclore Vivo (Norte Atlântico) : O Bicho-Barco do Minho:
travessia, fronteira e voz das águas  (recolhas de Eduardo Mauer, 2023–2025: 41
testemunhos orais geo-referenciados, mapa de microtoponímia e registo fotográ fico do
estuário; acervo MILK 2025).
Fontes de enquadramento tipológico:
– J. Leite de Vasconcelos, Etnografia Portuguesa, vol. XI (1928, pp. 266–274): “barcos
encantados e barcas das almas”.
– Teófilo Braga, Crenças Populares de Portugal (1902, pp. 447–452): referências a “bestiários
das águas fluviais”.
– Alexandre Parafita, Mitologia Popular Portuguesa (2008, pp. 1262–1275): análise do “barco
autónomo como símbolo de passagem”.
– Manuel Gandra, Os Mitos do Limiar Atlântico  (2014): discussão sobre rituais de travessia e
fronteiras simbólicas.
Fontes complementares:
– Museu do Mar de Caminha, Coleção  Oral – Histórias de Pescadores do Baixo Minho (1970–
2020);
– Museo do Mar de Galicia, Relatos do Xurés  e da Guarda (1995);
– Tese de Isabel Coutinho, Rios Fronteira e Imaginários  de Passagem (U. do Minho, 2017).
⸻
5. Síntese interpretativa final

O Bicho-Barco corporifica a metáfora  da travessia como relação ética. Ele ensina que
atravessar não é conquistar o outro lado, mas dialogar com a corrente. A embarcação viva
questiona a fronteira política: onde começa e acaba um rio que tem voz?
Na leitura simbólica da Associação  MILK, o mito opera como ecologia da permeabilidade –
reconhecimento da interdependência entre margens. O ser híbrido (barco/animal) propõe uma
visão não binária de pertença: cada margem contém a outra.
A escultura MILK concebida por Eduardo Mauer mantém a matriz padrão , adaptando-a ao
movimento fluvial: corpo alongado, proa-cabeça levemente erguida, fenda luminosa (o olho).
Textura em estrias horizontais, cores azuis e ferrugem. Quando iluminada, a peça projeta reflexo
ondulante, simulando maré.
Mauer escreve: “O Bicho-Barco é a fronteira que aprendeu a respirar. Se o mundo deixar de fluir,
ele deixa de existir.”
⸻
6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer
“O Bicho-Barco é corpo não binário da fronteira: nem barco nem bicho, nem morto nem
vivo, mas trânsito constante.”
A leitura contemporânea sublinha a fluidez identitária  e a coexistência dos opostos:
tecnologia (barco) e biologia (animal), margem portuguesa e galega, matéria e voz. O ser
hibridiza-se para preservar relação.
Na pedagogia MILK, o mito inspira laboratórios de escuta transfronteiriça entre
comunidades ribeirinhas, explorando gravações sonoras do rio, performances de
travessia silenciosa e criações colaborativas sobre o conceito de “andar-água” .
⸻
7. Referência Estrutural da Matriz MILK
Matriz Escultórica – Série Folclore Vivo (Associação  MILK)
	 •	 Corpo: alongado, base compacta; curva de proa elevada (cabeça).
	 •	 Cores: azul-acinzentado com véus ferrugíneos e re flexos de cobre.
	 •	 Materiais: resina náutica, pó de madeira, pigmento de óxido de ferro.
	 •	 Textura: estriada, evocando casco e escamas.
	 •	 Expressão:  olho central translúcido; ausência de boca (fala pela água).
	 •	 Base: elíptica ondulada, lembrando ondulação de rio.
	 •	 Eixo curatorial: Travessias e Fronteiras Vivas – entidades que habitam o
entre-margens.
⸻
Localização  específica: Estuário do Rio Minho (Caminha – A Guarda).
Primeiro relato documentado: O Bicho-Barco do Minho: travessia, fronteira e voz das águas
(Eduardo Mauer, 2025, acervo MILK).
Fontes primárias:  Vasconcelos (1928); Braga (1902); Parafita (2008); Gandra (2014); Coutinho
(2017).
⸻
