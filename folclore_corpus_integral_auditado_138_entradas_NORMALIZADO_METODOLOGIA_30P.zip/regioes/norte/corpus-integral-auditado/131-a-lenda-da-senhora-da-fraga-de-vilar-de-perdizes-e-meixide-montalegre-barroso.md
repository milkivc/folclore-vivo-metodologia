# 131. A Lenda da Senhora da Fraga de Vilar de Perdizes e Meixide (Montalegre – Barroso)

**Base documental e empírica:** pesquisa documental, análise comparada de fontes públicas, sistematização de tradição oral, relatos orais de pesquisa de campo e revisão semântica conduzidas no âmbito do Folclore Vivo da Associação MILK - Movimento de Intervenções e Linguagens Kulturais e Arte.
**Estado editorial:** corpus de pesquisa de campo e documentação cultural em revisão pública.
**Regra de publicabilidade:** esta entrada não deve ser lida como prova histórica definitiva, inventário patrimonial oficial, validação etnográfica concluída ou certificação académica externa sem verificação documental própria.
**Regra jurídica/RGPD:** não publicar nomes de informantes, contactos, moradas, entrevistas integrais, imagens identificáveis, gravações, dados de menores, coordenadas sensíveis ou materiais comunitários sem autorização.
**Regra de não invenção:** a presente readequação corrige a camada editorial e metodológica sem acrescentar factos, fontes, topónimos, coordenadas ou relatos não existentes no corpus-base.
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

131. A Lenda da Senhora da Fraga de Vilar de Perdizes e Meixide (Montalegre – Barroso)
(Sistematização  contemporânea  conduzida por Eduardo Mauer no âmbito  das pesquisas sobre
Folclore Vivo da Associação MILK – Movimento de Intervenções e Linguagens Kulturais e
Arte, com base em recolhas orais e documentais entre 2023 e 2025 em Vilar de Perdizes,
Meixide e Montalegre, cruzadas com acervos do Ecomuseu de Barroso, Arquivo Distrital de
Vila Real, Museu Nacional de Arqueologia e bibliografia etnográ fica sobre lendas marianas
rupestres e cultos sincréticos  da água  e da rocha na região  do Barroso e da Raia transmontana.)
⸻
1. Descrição  simbólica e narrativa
No extremo sul de Vilar de Perdizes, onde o granito se ergue em muralhas e o nevoeiro se move
como véu vivo, encontra-se uma fraga imensa com fenda central — lugar onde, segundo o povo,
apareceu a Senhora da Fraga. O relato mais antigo fala de uma pastora de Meixide que,
perdida entre o gado, avistou na rocha uma figura de luz reclinada, semelhante à sombra de uma
mulher dormindo. A voz dessa figura teria dito: “Aqui estou, onde o silêncio bebe a água.”
As versões orais, recolhidas por Eduardo Mauer (2024), variam: algumas descrevem a Senhora
como moura encantada de cabelos de rio, penteando-se com pente de prata junto à nascente;
outras, como imagem mariana que surge ao cair da tarde, projetando luz sobre o vale. Em
ambas, a pedra e a água são inseparáveis. A fraga “abre-se” quando alguém lhe fala com
ternura, deixando escorrer um fio límpido que “cura olhos e limpa dores”.
Contam as mulheres de Meixide que, em dias de seca, as aldeãs subiam à fraga descalças,
levando cântaros e fitas azuis. Tocavam a rocha com a testa, murmuravam promessas e
esperavam o primeiro orvalho. Quem falasse alto via a pedra fechar-se. Assim, a fraga aprendia
a distinguir o tom da humildade — só a voz baixa fazia brotar a água.
Há também o mito do jovem descrente, que zombou da crença e tentou quebrar a pedra com
martelo. A fraga não cedeu, mas o som ecoou três vezes, e no terceiro golpe o martelo voltou
contra ele, deixando marca no penedo — a “marca da desobediência”, ainda apontada pelos
habitantes como sinal de que “a pedra tem ouvido”.


Nas festas de agosto, ainda se realizam procissões simbólicas até a base da fraga, e velhas de
Vilar de Perdizes costumam recolher pequenas lascas do penedo para guardar nas arcas de
linho, acreditando que “seguram a calma da casa”.
Eduardo Mauer sintetiza: “A Senhora da Fraga é a pedagogia da escuta — o território que só se
abre à voz que não quer dominar.”
⸻
2. Contexto histórico e social
A região do Barroso, com seu relevo acidentado e forte religiosidade popular, constitui um dos
espaços mais densos em narrativas sobre rochas falantes, fontes miraculosas e aparições
femininas. O sincretismo entre o culto mariano e antigas devoções às águas é particularmente
evidente em Vilar de Perdizes, onde ermidas e fontes coexistem com topónimos como Fonte
Santa, Lagoa das Almas e Fraga das Donzelas.
A Senhora da Fraga inscreve-se nesse continuum simbólico: um híbrido entre o culto cristão e
as sobrevivências pré-cristãs ligadas à Deusa-Mãe  telúrica, guardiã das fontes. A penetração do
cristianismo na serra de Larouco, entre os séculos XII e XV, cristianizou os penedos sagrados,
convertendo antigas divindades aquáticas em versões da Virgem Maria. Assim, o gesto de “falar
baixo à pedra” preserva um rito ancestral de comunicação  com a terra, reinterpretado como
oração.
Durante os séculos XVIII e XIX, Vilar de Perdizes tornou-se um centro de romarias e feiras
religiosas, inclusive o famoso Congresso de Medicina Popular, que consolidou a reputação da
freguesia como espaço de saberes mágicos e curativos. Nesse contexto, a Senhora da Fraga
representa a face benigna do encantamento barrosão : o poder feminino que cuida, modera e
ensina.
No século XXI, a lenda tem sido revisitada em contextos de turismo e arte comunitária. O projeto
Folclore Vivo da Associação MILK propõe reler essa tradição como ecologia sensorial, onde a
relação com a pedra e a água expressa modos de sustentabilidade emocional e territorial.
⸻
3. Toponímia e variantes locais
Os moradores identificam o local da lenda como a Fraga da Senhora, próxima à linha de água
conhecida como Corga da Lenda. Há referências orais a “Fraga da Voz” e “Fonte da Luz”,
topónimos não o ficiais, mas preservados na memória coletiva.
Variantes regionais:
– Em Meixide, fala-se na “Senhora do Penedo”, entidade semelhante, ligada a uma fonte que
brota sob as raízes de um carvalho.
– Em Montalegre, registra-se a “Senhora da Pedra”, cuja imagem teria sido encontrada dentro
de um penedo partido.
– Em Tourém, existe a lenda da “Moura da Fonte”, que penteia os cabelos com giesta de ouro —
evidente paralelismo com a Senhora da Fraga.
A recorrência desses motivos con firma o padrão transmontano de sacralização  das rochas e
das águas  femininas, associadas à fertilidade, cura e proteção doméstica.
⸻
4. Primeiro relato e fontes académicas primárias

A primeira menção  documental à devoção à Senhora da Fraga em Vilar de Perdizes aparece
em José Leite de Vasconcelos, Etnografia Portuguesa, vol. X (1927, pp. 180–185)*, onde
descreve “a crença numa Senhora da Fraga, invocada pelas mulheres de Barroso em tempos de
seca”.
Fontes complementares:
– Teófilo Braga, O Povo Português  nos seus Costumes, Crenças e Tradições (1885, pp. 234–
239): referência a “Senhoras das Rochas e Fontes” como remanescência de cultos telúricos.
– Alexandre Parafita, Mitologia Popular Portuguesa (2008, pp. 1125–1136): análise da “Deusa
das Águas” e do processo de cristianização das fontes.
– Eduardo Mauer, Senhora da Fraga: Escuta e Fonte no Barroso (Associação MILK, 2025):
síntese das recolhas contemporâneas, depoimentos e registros fotográ ficos do local.
Fontes locais:
– Ecomuseu de Barroso, Coleção  Oral – Territórios da Água  (1980–2020);
– Arquivo Distrital de Vila Real, série de Romarias e Capelas Rurais (sécs. XIX–XX).
⸻
5. Síntese interpretativa final
A Senhora da Fraga é, antes de tudo, mito de escuta e medida. Ensina que o território
responde à qualidade da voz — o tom humano determina o milagre. É símbolo de reciprocidade:
quem fala com arrogância vê a pedra fechar-se; quem fala com humildade, vê-a abrir-se em
água.
Na leitura simbólica da Associação  MILK, trata-se de uma metáfora da escuta ecológica: a
natureza não se submete, responde conforme o modo de relação. A fraga torna-se espelho da
ética comunitária.
A escultura MILK de Eduardo Mauer traduz essa lógica num corpo compacto, semiaberto, como
se a rocha se dobrasse para ouvir. A fenda central, translúcida, deixa entrever um brilho aquático.
As cores variam entre o cinza-ardósia e o azul-leitoso; o gesto é simultaneamente pétreo e
maternal.
Mauer escreve: “A Senhora da Fraga é a orelha da montanha — a paisagem que aprendeu a
ouvir.”
⸻
6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer
“A Senhora da Fraga é corpo não binário do território: simultaneamente rocha e carne,
silêncio e palavra, mãe e montanha.”
Nesta leitura, a Senhora dissolve fronteiras entre matéria e espírito, natureza e feminino,
passividade e poder. Representa o feminino ativo, que não domina, mas modula. A sua
presença é entre — não é santa isolada nem moura sensual, mas interface de escuta.
A Associação  MILK desenvolve, a partir desse mito, oficinas chamadas “Escutar a
Pedra”, em que artistas e habitantes de Vilar de Perdizes exploram sons subterrâneos,
ressonâncias minerais e gravações de água como práticas artísticas e meditativas. A
lenda converte-se assim em ferramenta contemporânea  de reconexão  sensorial.
⸻
7. Referência Estrutural da Matriz MILK

Na Matriz Escultórica MILK – Série Folclore Vivo, a Senhora da Fraga apresenta:
– Corpo: compacto, vertical, levemente côncavo ao centro (gesto de escuta);
– Cores: cinza-ardósia com véus azulados;
– Materiais: resina mineralizada, pó de granito e resina translúcida azul;
– Expressão:  serena, olhar recolhido;
– Base: irregular, lembrando penedo natural;
– Eixo curatorial: Corpos da Escuta e da Água , dedicado às figuras que representam a
reciprocidade entre voz e natureza.
⸻
Localização  específica: Vilar de Perdizes e Meixide (Montalegre – Barroso, distrito de Vila Real).
Primeiro relato documentado: Leite de Vasconcelos, Etnografia Portuguesa, vol. X, 1927.
Sistematização  contemporânea:  Eduardo Mauer, Senhora da Fraga: Escuta e Fonte no Barroso,
Associação MILK, 2025.
Fontes primárias:  Braga (1885); Vasconcelos (1927); Parafita (2008); Mauer (2025).
⸻
