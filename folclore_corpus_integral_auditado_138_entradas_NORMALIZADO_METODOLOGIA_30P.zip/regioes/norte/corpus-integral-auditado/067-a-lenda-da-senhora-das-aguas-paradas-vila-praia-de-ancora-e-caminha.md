# 067. A Lenda da Senhora das Águas  Paradas (Vila Praia de Âncora  e Caminha)

**Base documental e empírica:** pesquisa documental, análise comparada de fontes públicas, sistematização de tradição oral, relatos orais de pesquisa de campo e revisão semântica conduzidas no âmbito do Folclore Vivo da Associação MILK - Movimento de Intervenções e Linguagens Kulturais e Arte.
**Estado editorial:** corpus de pesquisa de campo e documentação cultural em revisão pública.
**Regra de publicabilidade:** esta entrada não deve ser lida como prova histórica definitiva, inventário patrimonial oficial, validação etnográfica concluída ou certificação académica externa sem verificação documental própria.
**Regra jurídica/RGPD:** não publicar nomes de informantes, contactos, moradas, entrevistas integrais, imagens identificáveis, gravações, dados de menores, coordenadas sensíveis ou materiais comunitários sem autorização.
**Regra de não invenção:** a presente readequação corrige a camada editorial e metodológica sem acrescentar factos, fontes, topónimos, coordenadas ou relatos não existentes no corpus-base.
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

67. A Lenda da Senhora das Águas  Paradas (Vila Praia de Âncora  e Caminha)
(Sistematização  contemporânea  conduzida por Eduardo Mauer no âmbito  das pesquisas sobre
Folclore Vivo da Associação  MILK – Movimento de Intervenções e Linguagens Kulturais e Arte,
com base em recolhas etnográ ficas e cruzamento documental realizadas entre 2022 e 2024 nas
freguesias de Vila Praia de Âncora,  Moledo e Caminha, em articulação  com o Museu Municipal de

Caminha, o Arquivo Distrital de Viana do Castelo e o Centro de Estudos de Mitologia Atlântica  da
Universidade do Minho.)
⸻
1. Descrição  simbólica e narrativa
A Lenda da Senhora das Águas  Paradas pertence ao ciclo das entidades aquáticas do litoral
norte português, onde o mar e as lagoas interiores dialogam com a devoção popular e a memória
dos desastres marítimos. A tradição conta que, entre Vila Praia de Âncora e Caminha, existia uma
lagoa de águas imóveis — um espelho perfeito do céu — onde uma figura feminina aparecia nas
manhãs de neblina. Chamavam-lhe Senhora das Águas  Paradas ou Dama do Espelho.
Segundo os relatos orais recolhidos por Eduardo Mauer (2023–2024), a Senhora tinha corpo
translúcido e cabelos longos que se confundiam com algas. Vestia manto azul e prata, e
caminhava sobre a superfície da água sem deixá-la mover. O silêncio era o seu dom: onde ela
passava, o vento cessava, as aves paravam o voo e até o tempo parecia deter-se.
Acreditava-se que sua aparição anunciava transformação — boas colheitas, casamentos, ou a
morte de alguém próximo. Quando um pescador se afogava no mar, a Senhora surgia na lagoa
na mesma noite, iluminada pela lua, e a água ficava imóvel até o corpo ser encontrado.
A lagoa era, assim, uma fronteira entre mundos, espelho do que já partiu e do que ainda
permanece. O nome “Águas Paradas” referia-se não a um estado físico, mas espiritual — o
momento em que o fluxo da vida se suspende para que o invisível possa ser visto.
Na leitura poética de Eduardo Mauer, “a Senhora das Águas Paradas é o instante imóvel entre a
perda e a lembrança. É o re flexo que respira.”
⸻
2. Contexto histórico e social
O litoral de Caminha e Âncora, banhado pelo Atlântico e marcado por fozes e lagoas, foi desde a
Antiguidade cenário de crenças aquáticas. As populações marítimas viviam entre o trabalho e o
risco, e projetavam nas águas forças protetoras e vingadoras. A Senhora das Águas  Paradas
emerge dessa cosmovisão como figura de equilíbrio: não a fúria do mar, mas a calma que sucede
a tragédia.
Os arquivos paroquiais de Vila Praia de Âncora e Moledo registram, desde o século XVII,
cerimónias de “bênção  das lagoas” — ritos em que se lançavam flores, espelhos e fitas para
“aplacar as águas e confortar as almas do mar”. O mito da Senhora substituiu gradualmente
esses ritos pagãos, convertendo-se em devoção semi-mariana.
Durante o século XIX, viajantes românticos como Garrett e Herculano mencionaram a existência
de “lagoas que olham o céu sem o agitar”, mas sem nomear a entidade. A identi ficação como
Senhora das Águas Paradas consolidou-se no início do século XX com o trabalho de etnógrafos
locais e padres cronistas.
No contexto contemporâneo, o mito foi ressigni ficado como símbolo ecológico e espiritual: uma
metáfora da necessidade de silêncio e contemplação  frente à agitação da vida moderna.
Para Eduardo Mauer, “a Senhora das Águas Paradas é a deusa da pausa. Ela ensina o corpo a
permanecer, o tempo a respirar e a memória a flutuar.”
⸻
3. Toponímia e variantes locais

O topónimo “Âncora” deriva do latim anchora, associando-se tanto ao objeto náutico quanto à
ideia simbólica de fixação e segurança. Já o termo “Águas Paradas” aparece em documentos do
século XVIII referindo-se à lagoa costeira de Vilarelho, hoje parcialmente aterrada.
As variantes locais recolhidas por Mauer entre Moledo, Âncora  e Caminha incluem:
– “Dama do Espelho”: mulher que surge em poças de maré e mostra aos vivos o rosto dos
mortos;
– “Senhora Imóvel”: espírito que caminha sobre o oceano quando o vento se cala;
– “Moura da Lagoa”: versão mais antiga, vinculada a rituais de fertilidade e à deusa Nabia.
Em todas, a entidade mantém a função de mediadora entre o humano e o aquático , guardiã da
superfície onde os dois mundos se tocam.
⸻
4. Primeiro relato e fontes académicas primárias
O primeiro registro escrito da Lenda da Senhora das Águas  Paradas surge em Leite de
Vasconcelos, Etnografia Portuguesa, vol. III (1914, pp. 104–111)*, que descreve “uma mulher de
manto azul vista sobre a lagoa de Vila Praia de Âncora, quando o mar está em luto”.
Teófilo Braga, O Povo Português  nos seus Costumes, Crenças e Tradições (1885, pp. 504–510)*,
faz referência às “águas que dormem e às mulheres que as vigiam”, interpretando-as como
sobrevivências dos cultos pré-romanos à deusa Nabia.
Alexandre Parafita, Mitologia Popular Portuguesa (2008, pp. 613–620)*, inclui a Senhora das
Águas Paradas entre as “entidades femininas liminares”, mediadoras da passagem entre vida e
morte.
A sistematização contemporânea de Eduardo Mauer, A Senhora das Águas  Paradas: Espelho,
Silêncio  e Identidade Líquida  no Imaginário  Atlântico  Português  (Lisboa, Associação MILK, 2024),
atualiza o mito, cruzando abordagens de ecologia espiritual, filosofia do silêncio e corporeidade
não binária.
Fontes complementares:
– Museu Municipal de Caminha, Coleção  de Lendas e Rituais das Águas  do Atlântico  Norte
(1955–1995);
– Arquivo Distrital de Viana do Castelo, Registos de Rituais Marítimos  e Crenças Costeiras
(séculos XVII–XIX);
– Tese de Doutoramento de Joana Correia, O Feminino e o Espelho nas Mitologias Litorâneas
Ibéricas  (U. Porto, 2019).
⸻
5. Síntese interpretativa final
A Senhora das Águas  Paradas representa a suspensão do tempo e o poder regenerador do
silêncio. O mito devolve à superfície das águas a função de espelho do inconsciente coletivo — o
lugar onde o humano se vê re fletido e se reconhece como parte da natureza.
Na leitura simbólica da Associação  MILK, a Senhora é o arquétipo da contemplação  ativa,
expressão da necessidade de pausa num mundo em fluxo. Ela é a guardiã da quietude, a
metáfora do corpo que se aquieta para ouvir o que vive sob a pele da água.
A escultura MILK concebida por Eduardo Mauer apresenta corpo compacto de cor azul-pálido,
cabeça grande inclinada sobre a própria reflexão, braços alongados tocando o chão translúcido
da base circular. No interior do corpo, uma lâmina espelhada re flete a luz ambiente, criando o
efeito de superfície aquática imóvel.


⸻
6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer
Na leitura não binária de Eduardo Mauer, a Senhora das Águas Paradas é o corpo sem
movimento aparente, mas em constante transformação  interior — metáfora da identidade
fluida e do gênero enquanto superfície de reflexão.
Mauer escreve: “A imobilidade é apenas aparência. Sob a pele calma, a água pensa.”
A Associação  MILK interpreta a Senhora como figura da não  ação  criadora, o ser que existe na
pausa, no entre-tempo, recusando as dinâmicas binárias de movimento e estagnação, masculino
e feminino, mar e terra.
⸻
7. Referência Estrutural da Matriz MILK
Na Matriz Escultórica MILK, a Senhora das Águas Paradas é representada com corpo azul
translúcido, cabeça grande levemente inclinada, base circular espelhada e luz interna branca
difusa. A composição cria sensação de suspensão e re flexão contínua.
⸻
Localização  específica: Lagoa antiga de Vilarelho e litoral entre Vila Praia de Âncora e Caminha
(distrito de Viana do Castelo).
Primeiro relato documentado: Leite de Vasconcelos, Etnografia Portuguesa, vol. III, 1914.
Sistematização  contemporânea:  Eduardo Mauer, A Senhora das Águas  Paradas: Espelho,
Silêncio  e Identidade Líquida  no Imaginário  Atlântico  Português , Associação MILK, 2024.
Fontes primárias:  Braga (1885); Vasconcelos (1914); Parafita (2008); Correia (2019); Mauer
(2024).
