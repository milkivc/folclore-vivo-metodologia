# 115. A Lenda do Fuso de Pedra de Vila Verde (Baixa do Cávado  – Alto Minho)

**Base documental e empírica:** pesquisa documental, análise comparada de fontes públicas, sistematização de tradição oral, relatos orais de pesquisa de campo e revisão semântica conduzidas no âmbito do Folclore Vivo da Associação MILK - Movimento de Intervenções e Linguagens Kulturais e Arte.
**Estado editorial:** corpus de pesquisa de campo e documentação cultural em revisão pública.
**Regra de publicabilidade:** esta entrada não deve ser lida como prova histórica definitiva, inventário patrimonial oficial, validação etnográfica concluída ou certificação académica externa sem verificação documental própria.
**Regra jurídica/RGPD:** não publicar nomes de informantes, contactos, moradas, entrevistas integrais, imagens identificáveis, gravações, dados de menores, coordenadas sensíveis ou materiais comunitários sem autorização.
**Regra de não invenção:** a presente readequação corrige a camada editorial e metodológica sem acrescentar factos, fontes, topónimos, coordenadas ou relatos não existentes no corpus-base.
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

115. A Lenda do Fuso de Pedra de Vila Verde (Baixa do Cávado  – Alto Minho)
(Sistematização  contemporânea  conduzida por Eduardo Mauer no âmbito  das pesquisas sobre
Folclore Vivo da Associação  MILK – Movimento de Intervenções e Linguagens Kulturais e Arte,
com base em recolhas orais e documentais realizadas entre 2023 e 2025 em Vila Verde, Prado,

Ribeira do Neiva e Atiães,  cruzadas com fontes etnográ ficas do Museu D. Diogo de Sousa, do
Arquivo Distrital de Braga e de estudos sobre mitologia agrícola  e petrificação  simbólica no
noroeste português.)
⸻
1. Descrição  simbólica e narrativa
Em Vila Verde, região de campos férteis e fiadeiras habilidosas, ergue-se entre vinhedos e
carvalhais um penedo singular a que o povo chama Fuso de Pedra. É uma rocha esguia, a filada
na ponta, com cerca de três metros, que parece emergir da terra como um fuso gigantesco a fiar
o ar.
Conta o povo que ali vivia, há séculos, uma moça fiandeira conhecida por Mariana das Linhas,
de destreza notável e orgulho excessivo. Fiava ao luar e gabava-se de ser mais rápida que todas
as mulheres da freguesia — e até que as próprias santas. Certa noite de Sábado, durante a ceia,
ouviu uma voz que a desafiava: “Se és tão veloz, fia até o toque da missa.” A moça, vaidosa,
aceitou.
Quando o sino tocou, a roca tremia-lhe nas mãos, mas ela não parou. No momento em que a
Ave-Maria soou, o fuso, incandescente, ergueu-se e solidificou-se em pedra. A fiandeira
desapareceu; em seu lugar, ficou o penedo afilado — memória do gesto interrompido.
Dizem as mulheres da aldeia que, ao luar, o vento ainda faz o fuso girar; e quem tocar nele sem
pedir licença fica com as mãos dormentes. As crianças aprendem desde cedo: “Não se fia entre
badaladas, nem se desafia o tempo.”
Versões mais antigas contam que o fuso foi lançado por uma moura encantada, tentando
escapar à maldição do sol; outras, que ali se petri ficou o cajado de uma pastora. Em todas, o
tema é petrificação  por excesso de orgulho ou por desobediência ao tempo sagrado.
Eduardo Mauer (2024) observa: “O Fuso de Pedra é o instante em que o trabalho ultrapassa o
seu ritmo e se torna matéria — a arte esquecida de parar.”
⸻
2. Contexto histórico e social
O fuso e a roca são símbolos centrais da economia e da cosmovisão feminina rural no norte
português. O fiar representava tanto a produção material (linho, lã) quanto o domínio do tempo: a
mulher que fiava controlava o ritmo do lar e da comunidade.
O fuso petrificado insere-se no ciclo de narrativas europeias de petrificação  punitiva ou
consagradora, onde gestos cotidianos (fiar, dançar, cantar) se eternizam em pedra para ensinar
prudência. No contexto minhoto, combina elementos pagãos (magia da pedra e do linho) e
cristãos (respeito pelo descanso e pelo sagrado).
A lenda servia de instrumento pedagógico: recordava que o trabalho excessivo, sem medida ou
devoção, podia ser castigo — não virtude. Também expressava, sob forma simbólica, a tensão
entre devoção  e autonomia feminina. A fiandeira ousa medir-se com o divino e é petri ficada —
mas perpetuada: o penedo ergue-se como monumento ao gesto criador.
O território de Vila Verde, entre o Cávado e o Homem, conserva tradição têxtil antiquíssima,
com abundância de linho e ofícios associados. O mito do Fuso de Pedra re flete essa herança: a
ligação entre trabalho, terra e mito.
A Associação  MILK, no âmbito do eixo “Trabalhos e Encantamentos”, articula essa lenda com
oficinas de reinterpretação contemporânea do fiar como gesto meditativo, explorando o equilíbrio
entre ação e pausa.


⸻
3. Toponímia e variantes locais
Topónimos como “Penedo do Fuso”, “Couto da Roca” e “Fonte da Fiandeira” figuram em
registros cartográ ficos do século XVIII. Versões próximas aparecem em Atiães  (petrificação de
roca), Ribeira do Neiva (a moça do fuso de ouro) e Prado (a moura que fiava luz).
Nas memórias orais recolhidas por Mauer, as idosas associam o penedo a “tempo que não volta”
e “trabalho que se esquece”. Algumas relatam rituais de passagem: moças deixavam fitas de
linho ao redor do penedo na véspera de São João, pedindo boas mãos para o tear.
⸻
4. Primeiro relato e fontes académicas primárias
O primeiro registo textual do Fuso de Pedra de Vila Verde surge em Leite de Vasconcelos,
Etnografia Portuguesa, vol. IX (1925, pp. 230–236)*, que refere: “Em Vila Verde há penedo alto e
delgado, tido como fuso petrificado duma fiandeira castigada.”
Teófilo Braga, O Povo Português  nos seus Costumes, Crenças e Tradições (1885, pp. 822–826)*,
menciona histórias de mulheres transformadas em pedra por fiar ao luar, “gesto de desafio ao
descanso da terra”.
Alexandre Parafita, Mitologia Popular Portuguesa (2008, pp. 1098–1107)*, analisa a narrativa
como “metáfora da permanência do gesto feminino criador no tempo mineral”.
A sistematização contemporânea de Eduardo Mauer, O Fuso e o Tempo: Trabalho, Pedra e
Feminino em Vila Verde (Lisboa, Associação MILK, 2025)*, reinterpreta o mito sob perspectiva
antropológica e performativa, propondo-o como “poética da interrupção”.
Fontes complementares:
– Museu D. Diogo de Sousa, Coleção  de Etnografia Minhotas (1950–2010);
– Arquivo Distrital de Braga, Documentos Toponímicos e Lendas do Cávado  (sécs. XVIII–XX);
– Tese de Doutoramento de Filipa Serra, Pedras que Falam: Metamorfose e Gesto na Mitologia
Ibérica  (U. Lisboa, 2019).
⸻
5. Síntese interpretativa final
O Fuso de Pedra é metáfora da passagem do movimento à forma, do tempo vivo à eternidade
imóvel. O gesto humano, ao exceder a sua medida, cristaliza-se.
Na leitura simbólica da Associação  MILK, a fiandeira petrificada não é apenas advertência
moral, mas símbolo de resistência criadora: o corpo feminino torna-se pedra, permanecendo
como memória do gesto que tece o mundo.
A escultura MILK concebida por Eduardo Mauer segue a matriz padrão, mas verticalizada. O
corpo compacto torna-se eixo ascendente, evocando fuso. As cores — branco de linho, cinza-
pedra e reflexos dourados — fundem trabalho e luz. As mãos unem-se à frente, fiando o invisível.
Mauer escreve: “O fuso petrificado é o silêncio do gesto que ainda fia.”
⸻


6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer
“O Fuso de Pedra é corpo não binário do tempo produtivo e do contemplativo: nem
trabalho nem repouso, mas o intervalo onde o gesto se suspende.”
A lenda, reinterpretada, propõe uma ética da pausa, questionando o produtivismo
contemporâneo. O mito convoca também uma leitura de identidade além do gênero: o
fiar é ato universal de ligação, não atributo feminino exclusivo.
A Associação  MILK transforma o mito em prática pedagógica de “ fiar coletivo”, onde
artistas e comunidade tecem fios simbólicos, discutindo ritmo, excesso e cuidado.
⸻
7. Referência Estrutural da Matriz MILK
Na Matriz Escultórica MILK – Série Folclore Vivo, o Fuso de Pedra de Vila Verde apresenta:
– Corpo: vertical e compacto, ligeiramente afilado para o topo;
– Cores: branco-linho, cinza e dourado suave;
– Materiais: resina pigmentada e pó de pedra calcária;
– Expressão:  calma e concentrada;
– Base: circular, evocando a roca ou carretel.
Integra o eixo “Trabalhos e Encantamentos” do projeto Folclore Vivo, dedicado às narrativas
sobre ofício, criação e tempo.
⸻
Localização  específica: Vila Verde, Prado, Ribeira do Neiva e Atiães (distrito de Braga).
Primeiro relato documentado: Vasconcelos, Etnografia Portuguesa, vol. IX, 1925.
Sistematização  contemporânea:  Eduardo Mauer, O Fuso e o Tempo: Trabalho, Pedra e
Feminino em Vila Verde, Associação MILK, 2025.
Fontes primárias:  Braga (1885); Vasconcelos (1925); Parafita (2008); Serra (2019); Mauer (2025).
