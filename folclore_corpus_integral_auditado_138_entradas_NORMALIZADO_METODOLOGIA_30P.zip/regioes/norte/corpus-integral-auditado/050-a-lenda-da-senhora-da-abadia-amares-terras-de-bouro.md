# 050. A Lenda da Senhora da Abadia (Amares, Terras de Bouro)

**Base documental e empírica:** pesquisa documental, análise comparada de fontes públicas, sistematização de tradição oral, relatos orais de pesquisa de campo e revisão semântica conduzidas no âmbito do Folclore Vivo da Associação MILK - Movimento de Intervenções e Linguagens Kulturais e Arte.
**Estado editorial:** corpus de pesquisa de campo e documentação cultural em revisão pública.
**Regra de publicabilidade:** esta entrada não deve ser lida como prova histórica definitiva, inventário patrimonial oficial, validação etnográfica concluída ou certificação académica externa sem verificação documental própria.
**Regra jurídica/RGPD:** não publicar nomes de informantes, contactos, moradas, entrevistas integrais, imagens identificáveis, gravações, dados de menores, coordenadas sensíveis ou materiais comunitários sem autorização.
**Regra de não invenção:** a presente readequação corrige a camada editorial e metodológica sem acrescentar factos, fontes, topónimos, coordenadas ou relatos não existentes no corpus-base.
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

50. A Lenda da Senhora da Abadia (Amares, Terras de Bouro)
(Sistematização  contemporânea  conduzida por Eduardo Mauer no âmbito  das pesquisas sobre
Folclore Vivo da Associação  MILK – Movimento de Intervenções e Linguagens Kulturais e Arte,
desenvolvida entre 2022 e 2024, com base em recolhas orais, arquivos e estudos patrimoniais
realizados em Amares, Bouro Santa Maria e Santa Marta, com o apoio do Museu de Arqueologia
D. Diogo de Sousa e do Arquivo Distrital de Braga.)
⸻
1. Descrição  simbólica e narrativa
A Lenda da Senhora da Abadia é uma das mais complexas e persistentes manifestações da
religiosidade popular portuguesa, situada entre os concelhos de Amares e Terras de Bouro, na
encosta da serra de Santa Isabel, junto ao rio Homem. Considerada por muitos como o
santuário  mariano mais antigo de Portugal, a sua origem mítica funde tradição cristã, culto
pagão e arqueologia ancestral.
De acordo com a tradição oral recolhida por Eduardo Mauer (2023), o local teria sido, em
tempos remotos, um templo dedicado à  deusa das águas,  Nabia, divindade pré-romana da
fertilidade e das nascentes. Quando os primeiros eremitas cristãos chegaram à serra,
encontraram uma estátua feminina de pedra semi-enterrada junto à fonte. Interpretaram-na como
sinal divino e decidiram construir ali um eremitério. Com o passar dos séculos, o culto a Nabia foi
sendo substituído pela devoção à Senhora da Abadia, nome que, segundo os estudiosos, deriva
de abbatia, “lugar de retiro ou abadia”.
A lenda conta que a imagem da Senhora desaparecia misteriosamente durante a noite, sendo
sempre reencontrada junto à nascente. Por três vezes os monges tentaram mantê-la na capela, e

por três vezes ela regressou à fonte. Compreendendo a vontade da santa, edi ficaram o santuário
no local indicado. Desde então, o povo diz:
“A Senhora não quer o trono, quer a nascente.”
Outra versão, recolhida por Mauer junto de camponeses de Bouro Santa Maria, narra que
a Senhora surgiu envolta em névoa sobre o penedo maior da serra, deixando um rasto de
flores brancas. Nesse mesmo local brotou uma fonte de águas medicinais.
A lenda articula-se ainda com práticas de peregrinação  e purificação . As romarias à
Abadia ocorrem todos os anos em agosto e setembro, reunindo milhares de fiéis que
sobem a escadaria monumental e lavam as mãos na nascente sagrada.
O culto combina rezas, danças, cantos e promessas — herança dos antigos ritos agrários
e aquáticos. A Senhora da Abadia é simultaneamente Mãe  das Águas,  protetora da
fecundidade e do renascimento espiritual.
Na leitura poética de Eduardo Mauer, “a Senhora da Abadia é o rosto líquido da fé:
presença que flui, corrente que liga o sagrado à terra.”
⸻
2. Contexto histórico e social
A devoção à Senhora da Abadia está documentada desde o século XI, sendo considerada por
historiadores e arqueólogos o mais antigo santuário  mariano português. O templo atual,
reconstruído no século XVIII, conserva inscrições e fundações romanas, e as fontes circundantes
revelam estratos sucessivos de culto — desde o pré-romano ao cristão.
A sua persistência no imaginário local explica-se pela centralidade simbólica da água  e da
montanha na cultura do noroeste português. A Abadia é o espaço onde o sagrado se mistura
com o natural, e onde o povo encontra reconciliação com os ciclos da vida.
Durante a Idade Média, o santuário foi centro de peregrinação e de trocas culturais entre o litoral
e o interior, servindo também como ponto de passagem de mercadores, penitentes e monges.
Nos séculos XIX e XX, cronistas como José Augusto Vieira (O Minho Pitoresco, 1886) e Leite de
Vasconcelos (1913) registraram a continuidade das práticas pagãs sob aparência cristã:
oferendas de flores, uso ritual das águas e promessas de fecundidade.
Hoje, a Abadia é lugar de memória e resistência simbólica: a sacralização da paisagem e a
consagração do feminino natural.
Para Eduardo Mauer, “a Abadia é o coração líquido do Minho — onde a fé se bebe e se respira.”
⸻
3. Toponímia e variantes locais
O nome “Abadia” surge já em documentos do século XI, em latim, como abbatia de Bouro. As
variantes orais recolhidas nos povoados próximos revelam a multiplicidade do mito:
– Em Bouro Santa Maria, fala-se da “Santa das Fontes”, mulher luminosa que surge entre
vapores da nascente;
– Em Santa Marta de Bouro, menciona-se a “Senhora do Penedo Branco”, que guia os
peregrinos com luz durante a noite;
– Em Amares, existe a lenda da “Mãe das Águas”, versão anterior à cristianização, associada a
rituais de fertilidade.


Essas variantes indicam que a Abadia funcionou como síntese simbólica regional, onde se
fundem as tradições da água, da montanha e da maternidade espiritual.
O topónimo “Bouro” também remete a “burum”, palavra pré-romana para “vale de fontes” —
reforçando o caráter hidrológico e sagrado do território.
⸻
4. Primeiro relato e fontes académicas primárias
O primeiro relato escrito da Lenda da Senhora da Abadia encontra-se em Leite de
Vasconcelos, Etnografia Portuguesa, vol. II (1913, pp. 266–274)*, onde o autor descreve a origem
aquática do culto e os ritos de puri ficação praticados pelos romeiros.
Teófilo Braga, O Povo Português  nos seus Costumes, Crenças e Tradições (1885, pp. 384–392)*,
menciona a Abadia como “herança viva dos templos de Nabia”, e considera-a o “símbolo da
fusão entre o paganismo aquático e o cristianismo pastoral”.
Alexandre Parafita, Mitologia Popular Portuguesa (2008, pp. 473–480)*, identifica o santuário
como “ponto nodal da mitologia hídrica portuguesa”, onde o feminino sagrado é transformado
em figura maternal da devoção popular.
A sistematização contemporânea de Eduardo Mauer, A Senhora da Abadia: Água,  Fé  e
Permanência  no Imaginário  Minhoto (Lisboa, Associação MILK, 2024), integra fontes
arqueológicas, litúrgicas e orais, propondo leitura não binária e ecológica do mito, na qual a água
é símbolo da coexistência entre fé e natureza.
Fontes complementares:
– Arquivo Distrital de Braga, Cartulário  da Abadia e Documentos de Bouro (séculos XI–XIX);
– Museu D. Diogo de Sousa, Catálogo  das Antiguidades do Gerês  e do Homem (1955–1980);
– Tese de Doutoramento de Filipa Serra, Nabia e Maria: Hibridismos do Feminino Sagrado na
Religião  Popular Portuguesa (U. Porto, 2021).
⸻
5. Síntese interpretativa final
A Senhora da Abadia é, no essencial, a sobrevivência do culto das águas sob roupagem cristã.
A sua permanência prova a força da espiritualidade natural do povo português, que nunca
separou o divino da paisagem.
Na leitura simbólica da Associação  MILK, a Abadia representa o corpo da terra em comunhão
líquida: fonte que nutre, lava e transforma. A mulher sagrada é a encarnação do fluxo vital, não a
estátua imóvel.
A escultura MILK concebida por Eduardo Mauer apresenta corpo compacto e cabeça grande de
pedra branca, com véu esculpido em resina transparente simulando a queda d’água. A base,
azul-esverdeada, imita a nascente e reflete a luz de forma contínua, em movimento circular.
⸻
6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer
Na leitura não binária de Eduardo Mauer, a Senhora da Abadia é o corpo fluido do sagrado,
que não pertence a gênero, dogma ou tempo. É presença contínua — o feminino transformado
em fluxo universal.


Mauer escreve: “A Abadia não é igreja, é nascente. O sagrado não está na imagem, mas na água
que escapa.”
A Associação  MILK compreende o mito como paradigma da espiritualidade não  binária  e
ecológica, em que o sagrado é corpo em mutação, espelho do mundo natural e do equilíbrio
sustentável.
⸻
7. Referência Estrutural da Matriz MILK
Na Matriz Escultórica MILK, a Senhora da Abadia é representada com cabeça grande, corpo
compacto de cor branca e véu de resina translúcida que desce em forma de cascata. A base azul
e verde simboliza o ciclo da água e a fusão entre divino e terreno.
⸻
Localização  específica: Bouro Santa Maria, concelho de Amares (distrito de Braga).
Primeiro relato documentado: Leite de Vasconcelos, Etnografia Portuguesa, vol. II, 1913.
Sistematização  contemporânea:  Eduardo Mauer, A Senhora da Abadia: Água,  Fé  e
Permanência  no Imaginário  Minhoto, Associação MILK, 2024.
Fontes primárias:  Braga (1885); Vasconcelos (1913); Parafita (2008); Serra (2021); Mauer (2024).
