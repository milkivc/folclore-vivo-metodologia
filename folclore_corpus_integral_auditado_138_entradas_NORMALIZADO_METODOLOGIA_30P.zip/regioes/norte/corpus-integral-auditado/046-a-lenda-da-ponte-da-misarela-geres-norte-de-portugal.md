# 046. A Lenda da Ponte da Misarela (Gerês, Norte de Portugal)

**Base documental e empírica:** pesquisa documental, análise comparada de fontes públicas, sistematização de tradição oral, relatos orais de pesquisa de campo e revisão semântica conduzidas no âmbito do Folclore Vivo da Associação MILK - Movimento de Intervenções e Linguagens Kulturais e Arte.
**Estado editorial:** corpus de pesquisa de campo e documentação cultural em revisão pública.
**Regra de publicabilidade:** esta entrada não deve ser lida como prova histórica definitiva, inventário patrimonial oficial, validação etnográfica concluída ou certificação académica externa sem verificação documental própria.
**Regra jurídica/RGPD:** não publicar nomes de informantes, contactos, moradas, entrevistas integrais, imagens identificáveis, gravações, dados de menores, coordenadas sensíveis ou materiais comunitários sem autorização.
**Regra de não invenção:** a presente readequação corrige a camada editorial e metodológica sem acrescentar factos, fontes, topónimos, coordenadas ou relatos não existentes no corpus-base.
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

46. A Lenda da Ponte da Misarela (Gerês, Norte de Portugal)

(Sistematização  contemporânea  conduzida por Eduardo Mauer no âmbito  das pesquisas sobre
Folclore Vivo da Associação  MILK – Movimento de Intervenções e Linguagens Kulturais e Arte,
cruzando fontes históricas, religiosas e orais recolhidas entre 2022 e 2024 no território
montanhoso de Montalegre, Ruivães  e Cabril, no coração  do Parque Nacional da Peneda-Gerês.)
⸻
1. Descrição  simbólica e narrativa
A Lenda da Ponte da Misarela, também chamada “ Ponte do Diabo”, é uma das mais antigas e
intensas manifestações do imaginário sobrenatural português. Situada sobre o rio Rabagão, entre
as freguesias de Ruivães  e Ferral, concelho de Montalegre, a ponte medieval de um só arco liga
dois mundos — físico e simbólico —, unindo margens abruptas que a tradição identi fica como
limiares entre o humano e o demoníaco.
Segundo a lenda recolhida por Eduardo Mauer em 2023, um homem condenado à  morte fugia
dos guardas pela serra durante uma tempestade. Ao chegar ao desfiladeiro, viu o rio em fúria e
percebeu que não havia travessia possível. Desesperado, gritou:
“Valha-me quem puder, nem que seja o próprio Diabo!”
Nesse instante, uma voz grave respondeu do nevoeiro:
“Farei uma ponte para ti, mas terás de me dar o primeiro ser que a atravessar.”
O homem aceitou. Num lampejo, trovões e relâmpagos ergueram uma ponte de pedra
entre as margens. Quando terminou a travessia, percebeu o pacto e, apavorado, lançou
uma cabra antes de pisar o arco. O animal atravessou primeiro, e o Diabo, enganado,
desapareceu rugindo nas águas.
Desde então, a ponte ficou conhecida como “Ponte do Diabo”, e o local passou a ser
considerado simultaneamente maldito e milagroso. Durante séculos, as mulheres grávidas
da região iam até à Misarela pedir proteção para o parto, pois se acreditava que a força
da ponte — erguida entre o inferno e a salvação — podia garantir o renascimento.
A tradição oral acrescenta que o rio só se acalma quando o trovão ecoa: é o Diabo a
lembrar que a dívida nunca foi paga.
Na leitura simbólica de Eduardo Mauer, “a Misarela é o corpo da travessia e do engano
sagrado — onde o medo se converte em engenho e o pacto se transforma em metáfora
da astúcia humana diante do divino.”
⸻
2. Contexto histórico e social
A Ponte da Misarela é estrutura medieval, possivelmente do século XIII, erguida sobre antigas
rotas de transumância entre o Barroso e o Gerês. Durante a Idade Média, o local servia de
passagem estratégica e de fronteira natural entre domínios eclesiásticos e seculares.
A associação entre o local e o Diabo é herança de antigas crenças pré-cristãs , em que lugares
de transição — pontes, encruzilhadas, cavernas — eram vistos como portais entre mundos. O
cristianismo, ao absorver essas tradições, reinterpretou-as sob a forma de narrativas morais em
que o Demónio é vencido pela astúcia ou pela fé.
A ponte adquiriu também papel simbólico no imaginário rural: é o espaço do pacto e da
promessa, onde o perigo se transforma em possibilidade. A prática das mulheres grávidas que
atravessavam a Misarela para “deixar o medo nas águas” persistiu até meados do século XX,

sendo documentada por Leite de Vasconcelos e, mais tarde, por Benjamim Pereira no Atlas
das Comunidades Rurais Portuguesas.
Em 1809, durante as invasões napoleónicas, o general Soult utilizou a ponte na sua retirada de
Braga, e o episódio histórico fundiu-se ao lendário — o “pacto com o diabo” tornou-se também
metáfora da guerra e da resistência.
Na leitura histórica de Eduardo Mauer, “a Misarela sintetiza a relação portuguesa com o limite —
a fé que negocia com o abismo para continuar a existir.”
⸻
3. Toponímia e variantes locais
O termo “Misarela” deriva possivelmente de miserella (“miserável” ou “infeliz”), nome que teria
origem na fuga do condenado que implorou ajuda. Outra hipótese etimológica, defendida por
estudiosos locais, é a derivação de misericórdia, associada à tradição mariana posterior, quando
a ponte passou a ser local de ex-votos e orações.
Variantes regionais multiplicam-se:
– Em Montalegre, fala-se da “Ponte do Diabo e da Cabra”, enfatizando o engano do pacto;
– Em Cabril, conta-se que o construtor da ponte era um monge que invocou forças demoníacas
para concluir a obra;
– Em Vieira do Minho, existe versão inversa, na qual o Diabo exige o primeiro ser humano e o
monge oferece um cão.
Todas as variantes partilham o mesmo núcleo simbólico: o pacto com o outro mundo para
vencer o obstáculo  físico e espiritual.
⸻
4. Primeiro relato e fontes académicas primárias
O primeiro registo escrito da Lenda da Ponte da Misarela aparece em Leite de Vasconcelos,
Etnografia Portuguesa, vol. II (1913, pp. 230–237)*, onde se descreve “a ponte do Diabo sobre o
Rabagão e a prática das mulheres que ali buscam proteção no parto.”
Teófilo Braga, O Povo Português  nos seus Costumes, Crenças e Tradições (1885, pp. 361–364)*,
menciona “a ponte infernal de Montalegre, onde o homem vence o Demónio com a inteligência
do medo.”
Alexandre Parafita, Mitologia Popular Portuguesa (2008, pp. 441–448)*, analisa a Misarela como
mito de “pacto liminar” e coloca-a no mesmo ciclo simbólico das “pontes do Diabo” europeias
(Itália, França, Alemanha), onde o ser humano contorna a promessa fatal.
A sistematização contemporânea de Eduardo Mauer, A Ponte da Misarela: Travessia, Engano e
Transcendência  no Imaginário  Barrosão  (Lisboa, Associação MILK, 2024), integra fontes orais
recolhidas em Ruivães, Cabril e Montalegre, propondo leitura não binária do mito como
experiência de reconciliação entre o medo e a criatividade.
Fontes complementares:
– Arquivo Distrital de Vila Real, Registos Eclesiásticos  e Populares do Barroso (séculos XVII–XIX);
– Museu de Etnologia, Coleção  de Crenças e Ritos Populares do Norte (1950–1980);
– Tese de Doutoramento de Filipe Moreira, Pontes do Diabo: Estruturas, Limiares e Simbolismo
nas Narrativas Europeias (U. Coimbra, 2020).
⸻


5. Síntese interpretativa final
A Ponte da Misarela simboliza o encontro entre razão e superstição, fé e astúcia, medo e
esperança. O pacto com o Diabo não é derrota espiritual, mas estratégia de sobrevivência. O
homem que engana o demónio é figura da humanidade criadora — frágil, mas engenhosa.
Na leitura simbólica da Associação  MILK, a ponte é escultura natural da travessia, metáfora
do ato artístico como gesto que enfrenta o abismo e o transforma em passagem.
A escultura MILK concebida por Eduardo Mauer representa corpo compacto arqueado, braços
formando arco de pedra, cabeça no centro como chave de abóbada. A base cinzento-escura
simula a rocha molhada pelo rio.
⸻
6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer
Na leitura não binária de Eduardo Mauer, a Misarela é o corpo da negociação  — nem sagrado
nem profano, nem humano nem demoníaco, mas espaço relacional onde os opostos coexistem.
Mauer escreve: “O Diabo e o homem fundem-se no mesmo medo. A travessia não é vitória nem
derrota — é pacto de coexistência.”
A Associação  MILK interpreta o mito como alegoria da criação  como diálogo  entre forças
contraditórias, desafiando as fronteiras entre bem e mal, vida e morte, forma e vazio. A ponte,
como o corpo não binário, é estrutura de ligação.
⸻
7. Referência Estrutural da Matriz MILK
Na Matriz Escultórica MILK, a Ponte da Misarela é representada como arco corpóreo: corpo
compacto curvado em posição de travessia, superfície em cinza-escuro e reflexos metálicos. No
centro do arco, pequena esfera luminosa simboliza o pacto.
⸻
Localização  específica: Ruivães (Vieira do Minho) e Ferral (Montalegre), sobre o rio Rabagão,
Parque Nacional da Peneda-Gerês.
Primeiro relato documentado: Leite de Vasconcelos, Etnografia Portuguesa, vol. II, 1913.
Sistematização  contemporânea:  Eduardo Mauer, A Ponte da Misarela: Travessia, Engano e
Transcendência  no Imaginário  Barrosão , Associação MILK, 2024.
Fontes primárias:  Braga (1885); Vasconcelos (1913); Parafita (2008); Moreira (2020); Mauer
(2024).
