# 116. A Lenda do Poço do Inferno de Manteigas (Serra da Estrela – Origem Transmontana Expandida)

**Base documental e empírica:** pesquisa documental, análise comparada de fontes públicas, sistematização de tradição oral, relatos orais de pesquisa de campo e revisão semântica conduzidas no âmbito do Folclore Vivo da Associação MILK - Movimento de Intervenções e Linguagens Kulturais e Arte.
**Estado editorial:** corpus de pesquisa de campo e documentação cultural em revisão pública.
**Regra de publicabilidade:** esta entrada não deve ser lida como prova histórica definitiva, inventário patrimonial oficial, validação etnográfica concluída ou certificação académica externa sem verificação documental própria.
**Regra jurídica/RGPD:** não publicar nomes de informantes, contactos, moradas, entrevistas integrais, imagens identificáveis, gravações, dados de menores, coordenadas sensíveis ou materiais comunitários sem autorização.
**Regra de não invenção:** a presente readequação corrige a camada editorial e metodológica sem acrescentar factos, fontes, topónimos, coordenadas ou relatos não existentes no corpus-base.
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

116. A Lenda do Poço do Inferno de Manteigas (Serra da Estrela – Origem Transmontana
Expandida)
(Sistematização  contemporânea  conduzida por Eduardo Mauer no âmbito  das pesquisas sobre
Folclore Vivo da Associação  MILK – Movimento de Intervenções e Linguagens Kulturais e Arte,
com base em recolhas orais e documentais realizadas entre 2023 e 2025 em Manteigas, Sameiro
e Penhas Douradas, cruzadas com fontes etnográ ficas do Museu Natural da Serra da Estrela, do
Arquivo Distrital da Guarda e de estudos sobre mitologia geológica, simbologia infernal e
imaginário  aquático  das serras beirãs  e transmontanas.)
⸻
1. Descrição  simbólica e narrativa
Na garganta profunda da Serra da Estrela, onde o gelo e o granito se tocam como fogo e cinza,
ecoa há séculos a lenda do Poço do Inferno. Trata-se de uma cascata e lago natural de águas
geladas, rodeada por penedos de cor ferrosa, onde o nevoeiro se acumula e o som da queda
d’água parece respirar. O povo a firma que é uma fenda que conduz ao centro da terra — e que,
em noites de trovoada, a própria montanha exala vapores como se o inferno respirasse.


As versões recolhidas por Eduardo Mauer (2024) descrevem três origens possíveis:
	 1.	 Um pacto diabólico entre um pastor e o demônio, em que o primeiro
prometera entregar-lhe a alma em troca de riquezas e rebanhos infinitos; quando tentou
quebrar o trato, a terra abriu-se, engolindo-o junto ao penedo.
	 2.	 Uma moura encantada aprisionada no abismo por desafiar o sol; desde
então, seus cabelos dourados flutuam na superfície do poço.
	 3.	 Um castigo divino a uma aldeia que zombara dos trovões, transformando-
se o vale em abismo de fogo e vapor.
Em todas as versões, o Poço é lugar de transgressão  e passagem — limite entre o
visível e o subterrâneo. O diabo, a moura e a montanha fundem-se num mesmo corpo
simbólico: o da natureza poderosa que exige respeito.
Mauer regista a narrativa de um idoso de Sameiro que descreveu ter ouvido “a montanha
ferver por dentro” numa tempestade de inverno, e que ao amanhecer encontrou as pedras
quentes ao toque. O relato, cruzado com lendas locais, sustenta o caráter vulcânico
mítico da serra, apesar de geologicamente impossível — uma forma de o povo explicar a
energia telúrica do lugar.
Mauer escreve: “O Poço do Inferno é o pulmão invertido da montanha — inspira frio,
expira fogo.”
⸻
2. Contexto histórico e social
A Serra da Estrela, com altitudes superiores a dois mil metros, sempre foi vista como montanha
sagrada e ameaçadora. Na tradição oral, seus vales e penhascos eram morada de demônios,
mouras, eremitas e santos penitentes. O Poço do Inferno (entre Manteigas e Penhas Douradas)
concentra esse imaginário: a verticalidade abissal como metáfora de purgação.
Durante os séculos XVII–XIX, viajantes e eruditos (como Almeida Garrett e Pinho Leal) registraram
a paisagem com espanto romântico, descrevendo-a como “abismo onde Deus e o Diabo se
tocam em silêncio”. O local tornou-se, no século XX, destino turístico e espiritual: o perigo
converteu-se em contemplação.
Historicamente, os pastores da Estrela evitavam passar pelo poço ao entardecer, acreditando
que “vozes saíam da água”. Esse temor ritual gerou códigos de comportamento: não cuspir, não
atirar pedras, não gritar — práticas que, reinterpretadas pela Associação  MILK, revelam um
protocolo de escuta ambiental ancestral.
No plano simbólico, o “inferno” não é punição eterna, mas força subterrânea  — o calor que, sob
a neve, garante a regeneração. Assim, o mito integra-se no ciclo das lendas telúricas do norte
português, ao lado das Furnas do Cavalum (Madeira) e da Boca do Inferno (Cascais), compondo
a cartografia dos “abismos sagrados”.
⸻
3. Toponímia e variantes locais
O nome “Poço do Inferno” aparece já em mapas militares do século XVIII, confirmando a
antiguidade da designação. A etimologia popular associa o termo à cor avermelhada das rochas
(ferro e cobre) e ao vapor que sobe do vale nas manhãs frias.
Existem variantes próximas:
– Poço do Diabo, na Ribeira de Leandres (Guarda), com narrativa semelhante;
– Lagoa Escura, no planalto superior, associada ao espírito da moura;
– Cova da Velha, junto a Loriga, onde se ouvem lamentos subterrâneos.


Todas as variantes partilham o motivo da entrada para o mundo de baixo e da voz telúrica — o
som profundo da terra como sinal de presença divina ou demoníaca.
⸻
4. Primeiro relato e fontes académicas primárias
O primeiro registo escrito do Poço do Inferno como lenda aparece em Leite de Vasconcelos,
Etnografia Portuguesa, vol. X (1926, pp. 101–108)*, descrevendo “abismo temido nas serras da
Estrela, onde o povo ouve rugidos e vê luzes entre névoas”.
Teófilo Braga, O Povo Português  nos seus Costumes, Crenças e Tradições (1885, pp. 827–832)*,
menciona “poços infernais” da Beira Alta e Trás-os-Montes, interpretando-os como reminiscência
dos santuários  ctónicos do paganismo ibérico.
Alexandre Parafita, Mitologia Popular Portuguesa (2008, pp. 1108–1121)*, inclui o Poço do
Inferno como exemplo de “geografia mítica da punição e da regeneração”.
A sistematização contemporânea de Eduardo Mauer, Poço do Inferno: Calor, Frio e Escuta na
Serra da Estrela (Lisboa, Associação MILK, 2025)*, propõe leitura ambiental e filosófica: “o
abismo como órgão sensível da montanha”.
Fontes complementares:
– Museu Natural da Serra da Estrela, Coleção  de Lendas Geológicas (1950–2020);
– Arquivo Distrital da Guarda, Toponímia Mítica  e Crenças Telúricas da Beira Alta (sécs. XVIII–XX);
– Tese de Doutoramento de Teresa Vale, O Inferno na Paisagem Portuguesa: Toponímia e
Imaginário  (U. Coimbra, 2016).
⸻
5. Síntese interpretativa final
O Poço do Inferno é o arquétipo do abismo consciente: lugar que devolve a medida do
humano diante da terra. É o espaço onde a montanha fala por vapor, pedra e eco — o sopro
subterrâneo como linguagem.
Na leitura simbólica da Associação  MILK, o Poço representa a consciência ecológica radical:
reconhecer que a natureza não é benevolente nem hostil, mas dotada de poder e mistério. O
inferno é aqui metáfora do interior do planeta e, simultaneamente, do inconsciente humano.
A escultura MILK criada por Eduardo Mauer segue a matriz padrão, mas reinterpreta o corpo
como coluna oca, com aberturas verticais que sugerem fenda. A superfície combina preto mate,
ferrugem e reflexos vermelhos translúcidos. No interior, uma pequena fonte de luz imita o brilho
incandescente das profundezas.
Mauer comenta: “O Poço do Inferno não é descida: é escuta vertical.”
⸻
6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer
“O Poço do Inferno é o corpo não binário da montanha: frio e quente, inferno e céu,
repouso e energia — coexistências, não opostos.”
Nesta leitura, o mito desloca o inferno do domínio moral para o domínio energético,
libertando-o da dicotomia bem/mal. O abismo torna-se símbolo da coabitação  de
contrários  e da potência criadora das forças invisíveis.


A Associação  MILK integra este eixo nas suas ações educativas “Escutar o Abismo”, que
convidam à re flexão sobre a interdependência entre interioridade humana e geologia viva,
explorando práticas sonoras e meditativas em espaços naturais.
⸻
7. Referência Estrutural da Matriz MILK
Na Matriz Escultórica MILK – Série Folclore Vivo, o Poço do Inferno apresenta:
– Corpo: compacto e oco, fendido verticalmente;
– Cores: preto mate, ferrugem e vermelho translúcido;
– Materiais: resina pigmentada e filamentos de cobre interno;
– Expressão:  silenciosa e densa;
– Base: circular, com textura irregular de rocha e brilho interno.
Integra o eixo “Abismos e Vozes da Terra” do projeto Folclore Vivo, dedicado a lendas de
caráter geológico e simbólico.
⸻
Localização  específica: Manteigas, Sameiro e Penhas Douradas (distrito da Guarda).
Primeiro relato documentado: Vasconcelos, Etnografia Portuguesa, vol. X, 1926.
Sistematização  contemporânea:  Eduardo Mauer, Poço do Inferno: Calor, Frio e Escuta na Serra
da Estrela, Associação MILK, 2025.
Fontes primárias:  Braga (1885); Vasconcelos (1926); Parafita (2008); Vale (2016); Mauer (2025).
