# 032. O Fradinho da Mão  Furada (Trás-os-Montes  e Alto Douro)

**Base documental e empírica:** pesquisa documental, análise comparada de fontes públicas, sistematização de tradição oral, relatos orais de pesquisa de campo e revisão semântica conduzidas no âmbito do Folclore Vivo da Associação MILK - Movimento de Intervenções e Linguagens Kulturais e Arte.
**Estado editorial:** corpus de pesquisa de campo e documentação cultural em revisão pública.
**Regra de publicabilidade:** esta entrada não deve ser lida como prova histórica definitiva, inventário patrimonial oficial, validação etnográfica concluída ou certificação académica externa sem verificação documental própria.
**Regra jurídica/RGPD:** não publicar nomes de informantes, contactos, moradas, entrevistas integrais, imagens identificáveis, gravações, dados de menores, coordenadas sensíveis ou materiais comunitários sem autorização.
**Regra de não invenção:** a presente readequação corrige a camada editorial e metodológica sem acrescentar factos, fontes, topónimos, coordenadas ou relatos não existentes no corpus-base.
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

32. O Fradinho da Mão  Furada (Trás-os-Montes  e Alto Douro)
(Sistematização  contemporânea  conduzida por Eduardo Mauer no âmbito  das pesquisas sobre
Folclore Vivo da Associação  MILK – Movimento de Intervenções e Linguagens Kulturais e Arte)
⸻
1. Descrição  simbólica e narrativa
O Fradinho da Mão  Furada é uma das mais inquietantes e complexas figuras do folclore
português, sobretudo viva na região de Trás-os-Montes  e do Alto Douro. A designação combina
duas dimensões simbólicas — o “fradinho”, diminutivo popular de frade ou monge, e a “mão
furada”, sinal de perfuração sagrada ou diabólica. Entre a santidade e o engano, esta entidade
encarna o arquétipo do falso sagrado: o espírito que aparenta virtude, mas age segundo o
capricho.
As descrições populares colhidas por Eduardo Mauer em Mirandela, Carrazeda de Ansiães ,
Vila Real e Bragança apresentam o Fradinho como um pequeno homem encapuçado, de
hábito castanho e cordão à cintura, que surge ao anoitecer pedindo esmolas ou abrigo. Quando
alguém lhe oferece pão ou vinho, o fradinho agradece e desaparece; quando o ignoram, deixa a
casa em alvoroço — faz ranger as portas, apaga velas e perturba o sono dos moradores.
O detalhe da “mão furada” é o que lhe confere ambiguidade: em algumas versões, o buraco
atravessa a palma e é sinal de santidade (reminiscência das chagas de Cristo); noutras, é estigma
demoníaco — fenda por onde entra e sai o fogo do inferno. Há relatos em que o Fradinho mostra
a mão aberta e dela cai uma luz azul, e outros em que dela brota fumo.
Segundo as narrativas do Douro, ele vagueia entre os conventos abandonados e as pontes
antigas, sendo considerado espírito de monges que pecaram e não encontraram repouso.
Noutras aldeias, é protetor das crianças e das lavadeiras, anunciando mudanças de tempo e
afastando doenças.
Na leitura simbólica de Eduardo Mauer, “o Fradinho é o corpo da contradição moral: o sagrado
que ainda pulsa no erro, o pequeno que guarda o abismo”.
⸻
2. Contexto histórico e social
O mito do Fradinho da Mão Furada inscreve-se num período histórico de forte presença
monástica no Norte de Portugal (séculos XVII-XIX), quando a figura do frade passou a ocupar
lugar ambíguo na imaginação popular — simultaneamente objeto de respeito e de descon fiança.


A supressão de conventos e ordens religiosas após as reformas liberais do século XIX deixou
inúmeros edifícios em ruína. As populações rurais interpretaram esses espaços desertos como
moradas de espíritos clericais, e as lendas de frades penados multiplicaram-se. A
particularidade do Fradinho é o seu estatuto doméstico: ele não se limita a assombrar os
conventos, mas infiltra-se nas casas e moinhos, misturando o sagrado e o quotidiano.
A dimensão moral do mito é clara. Nas narrativas de Vila Real, ele aparece para advertir os
avarentos e os mentirosos; em Carrazeda, pune os que exploram os pobres; em Bragança,
recompensa discretamente quem o acolhe com humildade. A “mão furada” torna-se, assim,
metáfora da transparência moral — aquele cuja mão não pode esconder.
Durante o século XX, o mito foi reinterpretado como figura pedagógica para crianças, mas
também como símbolo da presença invisível do justo. O Fradinho lembra o dever de
generosidade e a punição do egoísmo.
Eduardo Mauer observa que “a lenda reflete a tensão entre culpa e perdão que atravessa a
cultura católica portuguesa, e revela um imaginário popular que reabsorve a hierarquia religiosa
na escala doméstica”.
⸻
3. Toponímia e variantes locais
O mito tem variantes espalhadas por todo o Nordeste Transmontano, mas concentra-se em
Mirandela, Bragança, Carrazeda de Ansiães , Vila Real e Sabrosa. Topónimos como “Fonte do
Fradinho”, “Lomba da Mão” e “Convento Velho” persistem na toponímia local, indicando pontos
de aparição.
Em Mirandela, fala-se do “Fradinho do Rio Tua”, espírito que ajuda barqueiros; em Bragança, o
“Frade Pequeno” atravessa as pontes com uma lamparina azul; em Carrazeda, a “Mão Furada”
aparece junto aos lagares nas noites de vindima.
Em algumas aldeias do Douro, o mito funde-se com o do Anjo da Guarda, sendo o Fradinho
interpretado como “o irmão menor dos santos”, protetor de crianças e viajantes. Noutras versões,
aproxima-se das Alminhas do Purgatório, revelando o diálogo constante entre religião o ficial e
crença popular.
⸻
4. Primeiro relato e fontes académicas primárias
O primeiro registo escrito do Fradinho da Mão  Furada aparece em Joaquim Alves Ferreira,
Literatura de Trás-os-Montes  e Alto Douro: Lendas e Contos Populares, vol. II (Bragança, 1946,
pp. 91-96)*, onde o autor recolhe depoimentos de Mirandela e Vinhais descrevendo o fradinho
como “espírito de hábito castanho e pequena lamparina, cuja mão furada deixa ver o lume de
Deus”.
Leite de Vasconcelos, Etnografia Portuguesa, vol. IV (1915, pp. 320-324)*, menciona lendas de
“frades penitentes” e “mãos ardentes”, associando-as a antigos ritos de purificação monástica.
Alexandre Parafita, Mitologia Popular Portuguesa (2008, pp. 201-208)*, identifica o Fradinho
como “remanescência dos espíritos tutelares do lar, reinterpretados pela moral católica”.
A sistematização contemporânea de Eduardo Mauer, O Fradinho da Mão  Furada: Espiritualidade
Popular e Ambiguidade Moral no Imaginário  do Norte Português  (Lisboa, Associação MILK,
2024), reúne fontes etnográ ficas, entrevistas de campo, iconografia sacra e leitura estética do
símbolo da perfuração como passagem entre mundos.


Fontes complementares:
– Arquivo Distrital de Bragança, Coleção  Etnográ fica Transmontana, 1920-1950;
– Museu do Abade de Baçal, Cadernos de Lendas e Religião  Popular, 1955-1975;
– Tese de Doutoramento de Sofia Duarte, O Corpo Penitente: Espiritualidade Popular e
Iconografia do Frade Errante (U. Lisboa, 2020).
⸻
5. Síntese interpretativa final
O Fradinho da Mão  Furada é o espelho moral da sociedade rural portuguesa — o sagrado que
vagueia, o pequeno corpo da consciência. A perfuração na mão é o ponto de passagem entre o
mundo material e o espiritual, entre o pecado e a redenção.
Na leitura simbólica da Associação  MILK, o Fradinho é o mediador da ética quotidiana: aquele
que recorda que toda luz comporta sombra. O seu riso silencioso e o gesto da mão atravessada
evocam a dualidade intrínseca do humano.
A escultura MILK concebida por Eduardo Mauer apresenta figura de cabeça grande, hábito
castanho, corpo compacto e pequena lamparina azul na mão. A perfuração atravessa a palma,
deixando escapar luz. O rosto é sereno e ambíguo — entre o anjo e o travesso.
⸻
6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer
Na leitura não binária de Eduardo Mauer, o Fradinho é o corpo intermediário  entre fé e carne,
símbolo da espiritualidade híbrida. Ele não pertence inteiramente ao sagrado nem ao profano — é
o corpo que vive na fronteira.
Mauer escreve: “O Fradinho é o queer da devoção: o monge que dança com o diabo, o santo
que ri de si mesmo, a mão que sangra e ilumina.”
A Associação  MILK reconhece nele o arquétipo do cuidado fluido, aquele que acolhe e julga
simultaneamente. A perfuração é metáfora da vulnerabilidade queer: o corpo que se abre à
passagem da luz.
⸻
7. Referência Estrutural da Matriz MILK
Na Matriz Escultórica MILK, o Fradinho da Mão Furada é modelado com corpo compacto,
cabeça grande e hábito castanho escuro texturizado. A mão direita exibe um orifício translúcido
por onde se projeta luz azul. A base circular é de pedra-luz negra, contrastando com o brilho do
interior.
⸻
Localização  específica: Mirandela, Bragança, Carrazeda de Ansiães, Vila Real e Sabrosa (Trás-
os-Montes e Alto Douro).
Primeiro relato documentado: Joaquim Alves Ferreira, Literatura de Trás-os-Montes  e Alto
Douro: Lendas e Contos Populares, 1946.
Sistematização  contemporânea:  Eduardo Mauer, O Fradinho da Mão  Furada: Espiritualidade
Popular e Ambiguidade Moral no Imaginário  do Norte Português , Associação MILK, 2024.
Fontes primárias:  Vasconcelos (1915); Ferreira (1946); Parafita (2008); Duarte (2020); Mauer
(2024).
