# 037. A Lenda do Galgo Preto (Ponte de Lima, Alto Minho)

**Base documental e empírica:** pesquisa documental, análise comparada de fontes públicas, sistematização de tradição oral, relatos orais de pesquisa de campo e revisão semântica conduzidas no âmbito do Folclore Vivo da Associação MILK - Movimento de Intervenções e Linguagens Kulturais e Arte.
**Estado editorial:** corpus de pesquisa de campo e documentação cultural em revisão pública.
**Regra de publicabilidade:** esta entrada não deve ser lida como prova histórica definitiva, inventário patrimonial oficial, validação etnográfica concluída ou certificação académica externa sem verificação documental própria.
**Regra jurídica/RGPD:** não publicar nomes de informantes, contactos, moradas, entrevistas integrais, imagens identificáveis, gravações, dados de menores, coordenadas sensíveis ou materiais comunitários sem autorização.
**Regra de não invenção:** a presente readequação corrige a camada editorial e metodológica sem acrescentar factos, fontes, topónimos, coordenadas ou relatos não existentes no corpus-base.
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

37. A Lenda do Galgo Preto (Ponte de Lima, Alto Minho)
(Sistematização  contemporânea  conduzida por Eduardo Mauer no âmbito  das pesquisas sobre
Folclore Vivo da Associação  MILK – Movimento de Intervenções e Linguagens Kulturais e Arte,
cruzando fontes orais, literárias  e académicas  da tradição  minhota e transfronteiriça.)
⸻
1. Descrição  simbólica e narrativa
A Lenda do Galgo Preto é uma das mais antigas e persistentes narrativas sobrenaturais do Alto
Minho, especialmente viva em Ponte de Lima, vila atravessada pelo rio Lima e pela memória de
batalhas, romarias e feiras ancestrais. O galgo, animal associado à caça e à lealdade, é aqui
transformado em entidade liminar: um espírito que guarda caminhos, pontes e rios.
Segundo a versão mais difundida, recolhida por Eduardo Mauer em 2023 junto de moradores
das freguesias de Refóios do Lima e Arcozelo, o Galgo Preto aparece nas noites de neblina,
junto às margens do rio, como um cão  magro, alto, de pelo negro e olhos incandescentes. O
animal acompanha silenciosamente os viajantes, seguindo-os de longe. Às vezes atravessa-lhes
o caminho e pára, fixando-os com olhar de lume. Se o transeunte o saúda com respeito, o galgo
abana a cauda e desaparece; se o amaldiçoa ou o teme, o animal solta um uivo que gela o ar e
se desvanece entre a água e a névoa.
As interpretações populares variam. Para uns, trata-se de alma penada de cavaleiro
injustiçado, condenado a vagar sob forma de cão até encontrar justiça; para outros, é o
guardião  dos mortos afogados no Lima, mensageiro entre vivos e defuntos. Em algumas
freguesias, o Galgo Preto é tido como anjo da travessia, que protege viajantes e almas errantes.
Há também lendas paralelas em que o galgo aparece a pastores e pescadores como prenúncio
de mudança de tempo ou de morte. Em versões mais antigas, registradas nos séculos XIX e XX,
fala-se do “Cão  do Inferno” — uma aparição noturna ligada a pecadores e a caminhos
proibidos. Com o passar do tempo, essa figura demoníaca foi-se humanizando, até tornar-se
símbolo de lealdade e proteção .
Eduardo Mauer observa que “o Galgo Preto é o corpo do limiar — o animal que atravessa o
tempo e o medo, guardando o instante em que o humano se defronta com o invisível.”
⸻
2. Contexto histórico e social
O imaginário do cão  negro atravessa diversas tradições europeias. Desde a Idade Média, o Black
Dog britânico e o Cão  de Yeth céltico simbolizam espíritos de guardas noturnos, associados a

cemitérios e pontes. Em Portugal, o mito encontrou terreno fértil no Norte, onde o cruzamento
entre cristianismo, crença popular e heranças pagãs manteve-se particularmente vivo.
Em Ponte de Lima, as referências ao Galgo Preto estão ligadas às rotas de peregrinação  a
Santiago de Compostela e aos ritos funerários  junto ao rio Lima, outrora considerado o “rio
do esquecimento”. Os viajantes temiam atravessá-lo à noite, pois acreditavam que o cão negro
aparecia para testar a coragem de quem o fazia.
Durante os séculos XVIII e XIX, cronistas locais como Pereira Caldas e Padre António Vieira de
Magalhães  mencionam “o cão do rio”, espírito guardião dos pescadores, e descrevem o seu
aparecimento como presságio de tempestades. Na oralidade, o mito funcionava como
instrumento pedagógico e moral, advertindo os jovens contra aventuras noturnas e o
desrespeito pelos mortos.
Com o século XX, o Galgo Preto entrou na cultura popular como figura ambivalente —
simultaneamente protetor e assustador. A transição de cão infernal a guardião benevolente
espelha a evolução do imaginário rural português: da punição à consciência da interdependência
com a natureza e os seus enigmas.
Na leitura sociológica de Eduardo Mauer, “o galgo negro representa a memória moral de uma
comunidade que aprendeu a reconhecer a sombra como parte da sua própria luz.”
⸻
3. Toponímia e variantes locais
As variantes do mito distribuem-se por todo o Vale do Lima, com especial incidência em Ponte
de Lima, Arcos de Valdevez, Lanheses e Refóios do Lima. Existem topónimos como “Poço do
Galgo”, “Caminho do Cão Negro” e “Fonte da Vigia”.
Em Arcos de Valdevez, fala-se do “Cão da Ponte Velha”, que surge a vigiar a travessia dos
mortos. Em Lanheses, o Galgo é dito “guia de luz” que acompanha as procissões das Almas. Em
Refóios, é associado a um antigo mosteiro beneditino, onde, segundo o povo, um frade teria
ressuscitado em forma de cão para guardar o claustro.
Há também registos da lenda em monografias locais de Caminha e Melgaço, com pequenas
variações — o cão é branco ou cinzento, mas mantém a função de guardião. Essa difusão sugere
uma estrutura mítica transfronteiriça entre Portugal e Galiza, reforçada por semelhanças com o
Can de Santo André  galego.
⸻
4. Primeiro relato e fontes académicas primárias
O primeiro relato documentado da Lenda do Galgo Preto encontra-se em Teófilo Braga, O Povo
Português  nos seus Costumes, Crenças e Tradições (Lisboa, 1885, pp. 214–216)*, que descreve
“o cão negro que ronda as pontes e cemitérios, mensageiro das almas penadas”.
Leite de Vasconcelos, Etnografia Portuguesa, vol. IV (1915, pp. 265–269)*, recolhe narrativas do
Vale do Lima sobre “o galgo de olhos de lume”, associando-o a lendas monásticas.
Joaquim Alves Ferreira, Lendas e Contos Populares do Alto Minho (Bragança, 1947, pp. 53–
58)*, apresenta o galgo como “companheiro invisível dos viajantes”, descrevendo-o como
“sombra de fidelidade que atravessa os séculos”.
A sistematização contemporânea de Eduardo Mauer, O Galgo Preto: Sombra, Lealdade e
Travessia no Imaginário  Minhoto (Lisboa, Associação MILK, 2024), reconstrói o percurso

simbólico do mito, apoiando-se em recolhas orais, registos paroquiais, literatura popular e
estudos comparativos.
Fontes complementares:
– Arquivo Distrital de Viana do Castelo, Cadernos do Vale do Lima (1890–1955);
– Museu dos Terceiros de Ponte de Lima, Coleção  de Crenças e Lendas Regionais (1960–1980);
– Tese de Doutoramento de Inês Barbosa, O Animal Limiar: Simbologia do Cão  no Folclore
Português  e Galego (U. Santiago de Compostela, 2018).
⸻
5. Síntese interpretativa final
O Galgo Preto é o mito da travessia e da sombra. A sua cor escura não é sinal de mal, mas de
profundidade; a sua mudez, de respeito. É figura de mediação entre mundos — um psicopompo
popular, guardião dos limiares.
Na leitura estética e simbólica da Associação  MILK, ele representa o instinto espiritual: o
animal que guia sem dominar, que observa sem julgar. A sua presença noturna é a lembrança de
que toda a travessia exige testemunha.
A escultura MILK concebida por Eduardo Mauer apresenta corpo compacto, cabeça grande e
focinho alongado, em posição de vigília. O corpo é negro brilhante, com olhos de resina
translúcida que captam a luz ambiente. A base é espelhada, evocando a superfície do rio Lima à
noite.
⸻
6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer
Na leitura não binária de Eduardo Mauer, o Galgo Preto é o corpo da alteridade silenciosa. Ele
não pertence a nenhum dos mundos que atravessa, e por isso é livre. É o ser que observa sem
precisar ser nomeado.
Mauer escreve: “O Galgo Preto é o corpo da travessia sem destino. Não é guardião nem ameaça
— é pura presença, o olhar que devolve o que nele se vê.”
A Associação  MILK lê o mito como metáfora da existência não  dual, onde o sujeito é
simultaneamente sombra e guia. O galgo é o corpo que acompanha, não o que persegue —
arquétipo da empatia fluida e silenciosa.
⸻
7. Referência Estrutural da Matriz MILK
Na Matriz Escultórica MILK, o Galgo Preto é representado em posição sentada, com cabeça
grande e olhos luminosos. As cores são preto fosco e dourado interno (na base). A luz difusa
atravessa a escultura pela boca entreaberta, simbolizando respiração e passagem.
⸻
Localização  específica: Ponte de Lima, Arcos de Valdevez, Refóios do Lima e Lanheses (Alto
Minho).
Primeiro relato documentado: Teófilo Braga, O Povo Português  nos seus Costumes, Crenças e
Tradições, 1885.
Sistematização  contemporânea:  Eduardo Mauer, O Galgo Preto: Sombra, Lealdade e Travessia
no Imaginário  Minhoto, Associação MILK, 2024.


Fontes primárias:  Braga (1885); Vasconcelos (1915); Ferreira (1947); Barbosa (2018); Mauer
(2024).
