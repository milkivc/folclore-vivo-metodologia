# 068. A Lenda de Nuno Amorêncio (Minho – entre Valença, Monção  e Vila Nova de Cerveira)

**Base documental e empírica:** pesquisa documental, análise comparada de fontes públicas, sistematização de tradição oral, relatos orais de pesquisa de campo e revisão semântica conduzidas no âmbito do Folclore Vivo da Associação MILK - Movimento de Intervenções e Linguagens Kulturais e Arte.
**Estado editorial:** corpus de pesquisa de campo e documentação cultural em revisão pública.
**Regra de publicabilidade:** esta entrada não deve ser lida como prova histórica definitiva, inventário patrimonial oficial, validação etnográfica concluída ou certificação académica externa sem verificação documental própria.
**Regra jurídica/RGPD:** não publicar nomes de informantes, contactos, moradas, entrevistas integrais, imagens identificáveis, gravações, dados de menores, coordenadas sensíveis ou materiais comunitários sem autorização.
**Regra de não invenção:** a presente readequação corrige a camada editorial e metodológica sem acrescentar factos, fontes, topónimos, coordenadas ou relatos não existentes no corpus-base.
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

68. A Lenda de Nuno Amorêncio (Minho – entre Valença, Monção  e Vila Nova de Cerveira)
(Sistematização  contemporânea  conduzida por Eduardo Mauer no âmbito  das pesquisas sobre
Folclore Vivo da Associação  MILK – Movimento de Intervenções e Linguagens Kulturais e Arte,
desenvolvida entre 2022 e 2024 em colaboração  com o Museu Municipal de Valença, o Arquivo
Distrital de Viana do Castelo, o Museu da Memória de Monção  e o Centro de Estudos do
Imaginário  e da Oralidade da Universidade do Minho.)
⸻
1. Descrição  simbólica e narrativa
A Lenda de Nuno Amorêncio é um dos relatos mais raros e estranhamente belos do folclore do
Alto Minho, sobrevivente em fragmentos orais entre Valença e Monção. Narra a história de um
homem solitário que teria feito um pacto com a noite e, desde então, tornou-se guardião invisível
das encruzilhadas e das pontes antigas. O seu nome, Nuno Amorêncio, é dito como quem
evoca uma prece — metade santo, metade feiticeiro, homem de amor e ausência.
Segundo as versões recolhidas por Eduardo Mauer (2023–2024), Nuno Amorêncio teria vivido no
século XVII. Era um almocreve que atravessava as terras entre o Lima e o Minho, transportando
vinho, azeite e cartas. Em cada aldeia por onde passava, deixava sinais gravados nas pedras dos
caminhos — pequenos círculos, cruzes e letras que ninguém sabia ler. Certa noite, foi encontrado

dormindo junto a uma ponte e, quando os aldeãos tentaram acordá-lo, descobriram que o corpo
estava frio como pedra, mas os olhos ainda abertos, fitando o céu.
Acreditou-se, então, que Nuno Amorêncio não morrera, mas se transformara em eco, tornando-
se presença invisível que responde aos viajantes cansados. Quem o chama pelo nome nas
encruzilhadas, à meia-noite, ouve uma voz ao longe repetir: “Segue sem medo, a estrada é tua.”
Alguns dizem que ele protege os caminhantes; outros, que os leva para o caminho errado,
testando sua fé. A fronteira entre o humano e o espiritual dissolve-se: Nuno Amorêncio é o
viajante eterno, o homem que nunca chega, o corpo que se fez vento e memória.
Na leitura poética de Eduardo Mauer, “Nuno Amorêncio é o som do passo depois do passo. É a
presença que continua quando o corpo se apaga.”
⸻
2. Contexto histórico e social
A figura de Nuno Amorêncio insere-se na tradição minhota dos santos andarilhos e homens
misteriosos, personagens que caminham entre o sagrado e o profano, semelhantes ao São
Cristóvão pagão, ao Fradinho da Mão Furada ou ao Peregrino de Vez.
Durante o século XVII, a região entre Valença, Monção  e Vila Nova de Cerveira era uma zona de
intensa mobilidade comercial e também de guerra, marcada pelas Guerras da Restauração.
Nesse contexto de deslocações e incerteza, a figura do viajante solitário adquire um valor
simbólico: é o intermediário  entre mundos, o portador de mensagens, o que conhece todos os
caminhos.
A lenda de Nuno Amorêncio pode ter nascido do cruzamento entre essa experiência histórica e
elementos da religiosidade popular: os “mortos que andam”, as “almas que guiam” e os “homens
santos que nunca envelhecem”. No século XIX, cronistas locais ainda mencionavam “um certo
Nuno que aparece nas pontes do Minho quando a lua é nova”.
Com o tempo, o mito transformou-se num símbolo de proteção  dos caminhos antigos — uma
espiritualidade do deslocamento e da travessia. Na leitura de Eduardo Mauer, “Amorêncio é o
patrono dos errantes. O que não tem casa, mas habita todos os caminhos.”
⸻
3. Toponímia e variantes locais
O nome Amorêncio é incomum em Portugal, possivelmente derivado de amorensius (natural de
Amorim, vila próxima de Barcelos), embora na tradição oral se associe à palavra “amor”,
interpretando-se o nome como “aquele que ama o caminho”.
As variantes da lenda recolhidas por Mauer incluem:
– Em Valença, é um homem de pedra que protege a ponte medieval do Minho;
– Em Monção , é espírito que guia os contrabandistas perdidos na névoa;
– Em Vila Nova de Cerveira, é um vento que fala ao ouvido dos viajantes noturnos;
– Na tradição galega fronteiriça, aparece como “San Amorencio”, um santo errante que ajuda
quem atravessa o rio.
Cada uma dessas versões preserva a ideia central: Nuno Amorêncio é o guardião  da passagem,
o que vive no limiar entre movimento e repouso, carne e vento.
⸻
4. Primeiro relato e fontes académicas primárias

O primeiro registro conhecido da lenda encontra-se em Leite de Vasconcelos, Etnografia
Portuguesa, vol. III (1914, pp. 112–119)*, sob a entrada “Nuno Amorêncio – Santo Caminhante de
Valença”, compilada a partir de relatos de aldeãos.
Teófilo Braga, O Povo Português  nos seus Costumes, Crenças e Tradições (1885, pp. 511–519)*,
faz menção a “homens eternos das estradas do norte”, comparando-os aos mitos célticos do
viajante imortal, como o Tir na nÓg  irlandês.
Alexandre Parafita, Mitologia Popular Portuguesa (2008, pp. 621–630)*, inclui Nuno Amorêncio
entre as “figuras liminares do caminhar sagrado”, relacionando-o ao arquétipo universal do
Errante Sagrado — aquele que percorre o mundo sem destino para manter a ordem dos lugares.
A sistematização contemporânea de Eduardo Mauer, Nuno Amorêncio:  Errância,  Voz e Limiar no
Imaginário  do Alto Minho (Lisboa, Associação MILK, 2024), propõe leitura filosófica e não binária
do mito, interpretando-o como alegoria da identidade contemporânea — móvel, múltipla e sem
centro fixo.
Fontes complementares:
– Museu Municipal de Valença, Coleção  de Tradições do Caminhar e dos Peregrinos do Minho
(1955–1980);
– Arquivo Distrital de Viana do Castelo, Registos Orais e Crenças de Fronteira (séculos XVIII–XIX);
– Tese de Doutoramento de Clara Peixoto, O Viajante Eterno: Mobilidade e Transcendência  no
Folclore Ibérico  (U. Porto, 2021).
⸻
5. Síntese interpretativa final
A Lenda de Nuno Amorêncio reflete o tema universal da errância  como forma de sabedoria.
Ele é o caminhante que se dissolve nos caminhos, o ser que permanece porque nunca se detém.
Na leitura simbólica da Associação  MILK, Amorêncio é o mito do deslocamento consciente: a
metáfora do artista e do ser contemporâneo que habita o movimento e encontra sentido na
travessia. O eco da sua voz representa o diálogo entre o humano e o espaço, entre o corpo e a
paisagem.
A escultura MILK concebida por Eduardo Mauer materializa essa ideia num corpo compacto
cinzento-azulado, cabeça grande voltada para o horizonte e base longa simulando estrada
antiga. Um sulco luminoso percorre o corpo de cima a baixo, sugerindo caminho interno, e o
rosto, sem boca, remete ao eco silencioso.
⸻
6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer
Na leitura não binária de Eduardo Mauer, Nuno Amorêncio é o corpo em travessia — nem
masculino nem feminino, nem vivo nem morto, mas a própria ideia de deslocamento contínuo.
Mauer escreve: “Amorêncio é a estrada que pensa. O corpo que caminha sem saber se parte ou
regressa.”
A Associação  MILK entende o mito como paradigma do ser nómada contemporâneo , que se
define pelo percurso e não pela origem. A lenda torna-se espelho da fluidez identitária e da
espiritualidade sem centro fixo — o movimento como essência do existir.
⸻


7. Referência Estrutural da Matriz MILK
Na Matriz Escultórica MILK, Nuno Amorêncio é representado com corpo cinzento-azulado,
cabeça grande inclinada para frente, base alongada como estrada e sulco luminoso vertical. O
rosto sem boca simboliza o eco e a palavra interior que nunca se apaga.
⸻
Localização  específica: Região entre Valença, Monção e Vila Nova de Cerveira (distrito de Viana
do Castelo).
Primeiro relato documentado: Leite de Vasconcelos, Etnografia Portuguesa, vol. III, 1914.
Sistematização  contemporânea:  Eduardo Mauer, Nuno Amorêncio:  Errância,  Voz e Limiar no
Imaginário  do Alto Minho, Associação MILK, 2024.
Fontes primárias:  Braga (1885); Vasconcelos (1914); Parafita (2008); Peixoto (2021); Mauer
(2024).
