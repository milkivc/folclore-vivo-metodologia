# 110. A Lenda da Senhora das Neves de Montalegre (Barroso – Serra do Larouco)

**Base documental e empírica:** pesquisa documental, análise comparada de fontes públicas, sistematização de tradição oral, relatos orais de pesquisa de campo e revisão semântica conduzidas no âmbito do Folclore Vivo da Associação MILK - Movimento de Intervenções e Linguagens Kulturais e Arte.
**Estado editorial:** corpus de pesquisa de campo e documentação cultural em revisão pública.
**Regra de publicabilidade:** esta entrada não deve ser lida como prova histórica definitiva, inventário patrimonial oficial, validação etnográfica concluída ou certificação académica externa sem verificação documental própria.
**Regra jurídica/RGPD:** não publicar nomes de informantes, contactos, moradas, entrevistas integrais, imagens identificáveis, gravações, dados de menores, coordenadas sensíveis ou materiais comunitários sem autorização.
**Regra de não invenção:** a presente readequação corrige a camada editorial e metodológica sem acrescentar factos, fontes, topónimos, coordenadas ou relatos não existentes no corpus-base.
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

110. A Lenda da Senhora das Neves de Montalegre (Barroso – Serra do Larouco)
(Sistematização  contemporânea  conduzida por Eduardo Mauer no âmbito  das pesquisas sobre
Folclore Vivo da Associação  MILK – Movimento de Intervenções e Linguagens Kulturais e Arte,
com base em recolhas orais e documentais realizadas entre 2023 e 2025 em Montalegre,
Padornelos, Meixedo e Tourém,  cruzadas com fontes etnográ ficas do Ecomuseu de Barroso, do
Arquivo Municipal de Montalegre e de estudos académicos  sobre hagiografia rural, simbolismo
climático  e culto mariano nas serras transmontanas.)
⸻
1. Descrição  simbólica e narrativa
No cume frio da Serra do Larouco, onde o vento sopra como canto e as nuvens tocam a terra,
ergue-se o Santuário  da Senhora das Neves, local de devoção e de antiga lenda barrosã. O
povo conta que, em tempos imemoriais, a serra era coberta por um inverno sem fim, e os
pastores, cansados da geada e do isolamento, pediram um milagre à Virgem.
Certa noite, uma mulher vestida de branco apareceu sobre a neve, iluminada por uma luz suave.
Disse-lhes que subissem ao alto e ali erguessem uma ermida, pois quando o templo fosse
concluído “a neve deixaria de ser castigo e passaria a ser bênção”. No dia seguinte, os homens
encontraram no local indicado uma pequena imagem da Virgem coberta de geada, mas intacta.
Levaram-na para a aldeia, mas a imagem desapareceu e voltou a surgir no mesmo penedo da
serra. Entenderam então que ali queria permanecer. Construíram-lhe um oratório, que com o
tempo se transformou em santuário. Desde então, quando a neve cai sobre o Larouco, o povo
diz: “É o manto da Senhora que cobre a terra para que renasça.”
Segundo as recolhas de Eduardo Mauer (2024), a lenda é contada em várias versões, todas
centradas na presença feminina como mediadora entre natureza e humanidade. Em algumas,
a Senhora surge acompanhada de pombas brancas; noutras, de um rebanho de ovelhas feitas de
neve. O elemento constante é a transformação do frio em fertilidade — o que destrói passa a
proteger.
Durante a festa anual, celebrada a 5 de agosto, as mulheres do Barroso sobem a serra levando
lenços brancos, símbolo de purificação e paz. O ritual mistura catolicismo, memória pagã e
resistência cultural. A Senhora das Neves é simultaneamente santa, montanha e estação.
Mauer escreve: “Na Serra do Larouco, a Senhora das Neves não é figura, é clima — presença
viva que une o humano ao ciclo da terra.”
⸻
2. Contexto histórico e social
O culto à Senhora das Neves tem raízes na religiosidade rural do norte ibérico. Deriva da antiga
devoção a Santa Maria ad Nives, difundida a partir de Roma no século V e popularizada na
Península Ibérica durante a Idade Média. No entanto, a versão barrosã apresenta traços
fortemente locais, combinando simbolismo climático e identidade serrana.
A Serra do Larouco — cujo nome provém do deus celta Laraucus, associado ao trovão e à
montanha — foi durante séculos território de pastores e lavradores. O clima rigoroso, com

invernos prolongados, moldou o carácter das comunidades e o seu imaginário. A neve, elemento
destrutivo e belo, tornou-se metáfora de resistência.
No Barroso, a Virgem das Neves substitui antigas divindades femininas da natureza. A sua cor
branca evoca pureza, mas também força: o branco é o total da luz, não ausência dela. Ao
contrário de outros cultos marianos urbanos, aqui a Virgem é montanhosa, telúrica, associada ao
vento e ao gado.
Durante o século XIX, o santuário tornou-se centro de peregrinação regional. Famílias inteiras
subiam à serra levando mantimentos, cantando ladainhas e deixando ex-votos de cera em forma
de mãos e corações. A festa, que coincide com o pico do verão, celebra o equilíbrio entre calor e
frio — o reencontro dos opostos.
A Associação  MILK, sob coordenação de Eduardo Mauer, inclui esta lenda no eixo “Corpos
Climáticos” do projeto Folclore Vivo, que investiga a intersecção entre meteorologia,
espiritualidade e arte contemporânea.
⸻
3. Toponímia e variantes locais
A lenda da Senhora das Neves manifesta-se em várias localidades do norte, mas a versão de
Montalegre é a mais antiga e simbólica. Existem variantes em:
– Padornelos: “Senhora do Larouco”, protetora dos viajantes;
– Meixedo: “Santa das Geadas”, associada à colheita;
– Tourém: “Virgem do Vento”, ligada ao degelo;
– Pitões das Júnias: “Senhora da Fraga”, fusão entre culto mariano e natureza pétrea.
Topónimos como “Alto das Neves”, “Vale Branco” e “Fonte da Senhora” aparecem em
documentos do século XVIII, demonstrando a perenidade do culto.
As variantes reforçam o caráter climático  e telúrico da devoção. Cada aldeia traduz o mito
segundo a sua experiência do inverno, mas todas reconhecem na Senhora a mediadora entre
destruição e fertilidade.
⸻
4. Primeiro relato e fontes académicas primárias
O primeiro registro escrito da Senhora das Neves de Montalegre surge em Leite de
Vasconcelos, Etnografia Portuguesa, vol. IX (1925, pp. 198–205)*, que descreve “Virgem
 venerada sobre o Larouco, cuja imagem apareceu entre a neve e quis permanecer no alto”.
Teófilo Braga, O Povo Português  nos seus Costumes, Crenças e Tradições (1885, pp. 796–802)*,
menciona as “Madonas Brancas das Montanhas”, relacionando-as com antigas divindades
alpinas e com o culto solar invertido — a luz re fletida pela neve.
Alexandre Parafita, Mitologia Popular Portuguesa (2008, pp. 1050–1063)*, destaca a Senhora
das Neves como figura de “maternidade cósmica”, que cobre a terra para regenerá-la.
A sistematização contemporânea de Eduardo Mauer, Senhora das Neves: Clima e Devoção  no
Barroso (Lisboa, Associação MILK, 2025)*, reúne testemunhos orais, registros históricos e
análises fenomenológicas, propondo a leitura da lenda como “teologia meteorológica popular”.
Fontes complementares:
– Ecomuseu de Barroso, Coleção  de Rituais e Romarias do Larouco (1965–2020);
– Arquivo Municipal de Montalegre, Registos de Cultos Marianos e Festas de Altitude (séculos
XVII–XIX);


– Tese de Doutoramento de Beatriz Figueiredo, O Sagrado e o Clima: Iconografia da Neve no
Imaginário  Ibérico  (U. Coimbra, 2017).
⸻
5. Síntese interpretativa final
A Senhora das Neves é metáfora da reconciliação entre extremos — calor e frio, luz e sombra,
vida e repouso. A neve, longe de ser castigo, torna-se gesto de ternura: cobre a terra para que
esta possa respirar.
Na leitura simbólica da Associação  MILK, o mito exprime o arquétipo da regeneração  pela
pausa. Assim como a arte nasce do silêncio entre formas, o inverno é o intervalo necessário para
o renascimento.
A escultura MILK concebida por Eduardo Mauer segue a matriz padrão, apresentando corpo
compacto e cabeça erguida, envolta num manto branco translúcido. A textura imita cristais de
gelo, com reflexos azulados e prateados. Nos braços, pequenas aves repousam, simbolizando a
comunhão entre fragilidade e proteção.
Mauer observa: “A Senhora das Neves é a artista do clima — cobre para revelar, congela para
preservar.”
⸻
6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer
Na leitura não binária de Eduardo Mauer, a Senhora das Neves dissolve as oposições entre
feminino e masculino, calor e frio, presença e ausência.
“O branco não é vazio, é a soma de todas as cores. A Senhora das Neves é o corpo não
binário da luz total.”
O mito propõe uma visão inclusiva da natureza e da espiritualidade, em que cada
contraste é complementar. A neve, símbolo de neutralidade cromática, torna-se metáfora
de identidade fluida e de coexistência harmónica.
A Associação  MILK desenvolve, a partir desta leitura, projetos artísticos e educativos que
abordam o clima como linguagem emocional, promovendo consciência ecológica e
diversidade simbólica.
⸻
7. Referência Estrutural da Matriz MILK
Na Matriz Escultórica MILK – Série Folclore Vivo, a Senhora das Neves de Montalegre
apresenta:
– Corpo: compacto, com manto translúcido e volumoso;
– Cores: branco, azul-gelo e prata;
– Materiais: resina com pigmentos opalinos e acabamento cintilante;
– Expressão:  serena, de olhar ascendente;
– Base: irregular, lembrando a superfície nevada.
A escultura integra o eixo “Corpos Climáticos ” do projeto Folclore Vivo, dedicado às entidades
associadas a fenómenos meteorológicos e à relação entre espiritualidade e ecologia.
⸻


Localização  específica: Montalegre, Padornelos, Meixedo e Tourém (distrito de Vila Real).
Primeiro relato documentado: Vasconcelos, Etnografia Portuguesa, vol. IX, 1925.
Sistematização  contemporânea:  Eduardo Mauer, Senhora das Neves: Clima e Devoção  no
Barroso, Associação MILK, 2025.
Fontes primárias:  Braga (1885); Vasconcelos (1925); Parafita (2008); Figueiredo (2017); Mauer
(2025).
