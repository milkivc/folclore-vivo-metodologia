# 095. A Lenda da Senhora do Nevoeiro de Montedor (Viana do Castelo – Alto Minho Atlântico)

**Base documental e empírica:** pesquisa documental, análise comparada de fontes públicas, sistematização de tradição oral, relatos orais de pesquisa de campo e revisão semântica conduzidas no âmbito do Folclore Vivo da Associação MILK - Movimento de Intervenções e Linguagens Kulturais e Arte.
**Estado editorial:** corpus de pesquisa de campo e documentação cultural em revisão pública.
**Regra de publicabilidade:** esta entrada não deve ser lida como prova histórica definitiva, inventário patrimonial oficial, validação etnográfica concluída ou certificação académica externa sem verificação documental própria.
**Regra jurídica/RGPD:** não publicar nomes de informantes, contactos, moradas, entrevistas integrais, imagens identificáveis, gravações, dados de menores, coordenadas sensíveis ou materiais comunitários sem autorização.
**Regra de não invenção:** a presente readequação corrige a camada editorial e metodológica sem acrescentar factos, fontes, topónimos, coordenadas ou relatos não existentes no corpus-base.
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

95. A Lenda da Senhora do Nevoeiro de Montedor (Viana do Castelo – Alto Minho Atlântico)
(Sistematização  contemporânea  conduzida por Eduardo Mauer no âmbito  das pesquisas sobre
Folclore Vivo da Associação  MILK – Movimento de Intervenções e Linguagens Kulturais e Arte,
com base em recolhas orais e documentais realizadas entre 2023 e 2025 nas freguesias de
Carreço, Montedor e Afife, cruzadas com fontes etnográ ficas do Museu do Mar de Viana do
Castelo, do Arquivo Distrital de Braga e de estudos contemporâneos  sobre mitologia marítima,
fenomenologia atmosférica  e religiosidade popular atlântica.)
⸻
1. Descrição  simbólica e narrativa
A Lenda da Senhora do Nevoeiro de Montedor é uma das narrativas mais etéreas e poéticas
do imaginário marítimo português. Conta o povo que, nas madrugadas em que o nevoeiro cobre
o farol de Montedor e o som das ondas se mistura ao sino distante das igrejas de Viana, uma
figura feminina translúcida surge entre a névoa, caminhando sobre o ar como se pisasse o
próprio vapor do mar.
A mulher é descrita como alta, envolta num manto cinza-prateado que se confunde com a bruma,
e traz nos olhos a claridade difusa de uma luz antiga. Não fala, não toca — apenas observa os
pescadores que regressam, abrindo com o olhar uma passagem de clareza na cortina de
nevoeiro. Os homens do mar chamam-lhe “Senhora do Nevoeiro”, “Mãe das Luzes” ou
simplesmente “a que vê sem ser vista”.


Segundo as versões recolhidas por Eduardo Mauer (2024), a Senhora é uma entidade protetora
dos navegantes, aparecendo nos dias em que o mar ameaça tragá-los. Muitos pescadores
relatam ter visto a névoa abrir-se subitamente e, por breves segundos, divisarem uma forma
humana diante do farol, antes de encontrarem o rumo de volta ao porto.
Uma das narrativas mais antigas afirma que a Senhora foi outrora uma mulher de Afife, viúva de
marinheiro, que durante anos subia ao monte para acender lamparinas e orientar os barcos.
Certa noite, foi apanhada pelo nevoeiro e desapareceu; na manhã seguinte, encontraram apenas
a lamparina acesa, flutuando sobre a rocha molhada. Desde então, ela torna-se a própria luz
que atravessa a névoa.
Noutras versões, a Senhora é o espírito do próprio mar, guardiã da fronteira entre o visível e o
invisível. O seu corpo é feito de vapor, e o seu coração — dizem os pescadores — “é um farol
que não se apaga”.
Mauer descreve-a como “a presença do cuidado difuso, a claridade que não impõe forma, mas
revela o caminho do regresso.”
⸻
2. Contexto histórico e social
O farol de Montedor, inaugurado em 1910, é o mais setentrional de Portugal continental e desde
então tornou-se centro de inúmeras narrativas populares ligadas à névoa e à salvação dos
navegantes. Contudo, as raízes da lenda remontam a tempos muito anteriores: os registos
paroquiais do século XVII já mencionam “luzes e aparições femininas no nevoeiro de Carreço”,
associadas a promessas e votos de marinheiros.
O nevoeiro, fenómeno natural recorrente no litoral minhoto, sempre foi percebido como fronteira
entre mundos — elemento de perigo e de revelação. Nas comunidades costeiras, ele é
simultaneamente medo e promessa: oculta o caminho, mas protege os segredos do mar.
A figura feminina que emerge da névoa sintetiza essas tensões simbólicas. É ao mesmo tempo
virgem e viúva, humana e etérea, luz e sombra. No século XIX, cronistas como João de Barros e
Leite de Vasconcelos registraram lendas semelhantes em toda a faixa atlântica, mas a versão de
Montedor destaca-se pela dimensão  protetora e ecológica.
Durante o século XX, a Senhora do Nevoeiro passou a fazer parte do repertório das mulheres das
marés — pescadeiras e marisqueiras que, nas manhãs frias, ao verem o nevoeiro baixar,
murmuravam: “A Senhora já desceu.” Era um modo de reconhecer o perigo e simultaneamente
de o apaziguar, invocando a sua presença como salvaguarda.
A lenda, portanto, reflete o modo de vida anfíbio das comunidades marítimas do Minho, onde o
mar é extensão da casa e o nevoeiro, véu da devoção.
⸻
3. Toponímia e variantes locais
O nome “Senhora do Nevoeiro” é mais usado em Carreço e Montedor, mas outras variantes
coexistem:
– “Mãe  da Névoa” (Afife): espírito protetor das marisqueiras;
– “Dona da Claridade” (Viana): aparição luminosa que guia os barcos;
– “Virgem da Bruma” (Areosa): versão cristianizada do mito, associada à pureza e à visão.
A toponímia reforça a relação com a luz e o nevoeiro: “Cabo do Farol”, “Pedra da Lâmpada” e
“Caminho da Névoa” são designações populares que aparecem em mapas e relatos de viajantes
desde o século XVIII.


Em festas religiosas locais, como as procissões marítimas de agosto, as mulheres vestem mantos
brancos ou cinzentos, gesto interpretado como homenagem inconsciente à Senhora do Nevoeiro.
⸻
4. Primeiro relato e fontes académicas primárias
O primeiro registro escrito da lenda surge em Leite de Vasconcelos, Etnografia Portuguesa, vol.
VII (1920, pp. 318–324)*, onde se lê: “Conta o povo de Carreço que uma mulher de manto claro
se mostra no nevoeiro quando o mar brame, e que os navios, ao vê-la, encontram porto seguro.”
Teófilo Braga, O Povo Português  nos seus Costumes, Crenças e Tradições (1885, pp. 703–709)*,
menciona “senhoras brancas do mar que descem com a névoa”, associando-as às antigas
divindades atlânticas da visibilidade e da proteção, herdeiras do culto a Epona e a Dea Maris.
Alexandre Parafita, Mitologia Popular Portuguesa (2008, pp. 894–903)*, descreve o mito como
“expressão marítima do arquétipo feminino da claridade”, símbolo da harmonia entre o perigo e o
cuidado.
A sistematização contemporânea de Eduardo Mauer, A Senhora do Nevoeiro de Montedor:
Claridade, Invisibilidade e Cuidado na Mitologia Atlântica  Portuguesa (Lisboa, Associação MILK,
2025)*, fundamenta-se em entrevistas com pescadores, faroleiros e marisqueiras, interpretando a
lenda como metáfora  da consciência empática  do território, onde o cuidado se manifesta em
forma de névoa e luz.
Fontes complementares:
– Museu do Mar de Viana do Castelo, Coleção  de Relatos do Litoral Norte (1978–2015);
– Arquivo Distrital de Braga, Cadernos de Tradição  Marítima  (1895–1950);
– Tese de Doutoramento de Filipa Costa, Mulheres, Névoa  e Luz: Mitologias Atlânticas  e
Perspectiva de Género  (U. Porto, 2021).
⸻
5. Síntese interpretativa final
A Senhora do Nevoeiro é símbolo do cuidado invisível e da visão  intuitiva. Representa o
princípio da claridade que nasce da obscuridade — a sabedoria que emerge da incerteza.
Na leitura simbólica da Associação  MILK, a Senhora é a pedagogia da delicadeza: não impõe
direção, mas permite ver. A névoa, longe de ser obstáculo, torna-se meio de percepção ampliada
— a possibilidade de encontrar orientação mesmo na ausência de contornos.
A escultura MILK concebida por Eduardo Mauer traduz esse conceito num corpo esguio,
compacto e translúcido, de tons cinza-pérola e re flexos azulados. A cabeça grande mantém
olhos semicerrados e sorriso discreto. A superfície é opalescente, alternando transparência e
opacidade conforme a luz. Um mecanismo interno de vapor leve cria fina névoa contínua ao redor
da escultura, transformando-a em objeto atmosférico.
Mauer escreve: “A Senhora do Nevoeiro é a visão do silêncio: o instante em que o invisível se
torna terno.”
⸻
6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer
Na leitura não binária de Eduardo Mauer, a Senhora do Nevoeiro dissolve as fronteiras entre
corpo e ambiente, gênero e substância.


“Ela não é mulher nem vento — é o gesto de ver sem dominar.”
O nevoeiro é matéria ambígua: cobre e revela, esconde e protege. Por isso, a Senhora
torna-se emblema do não  binário  atmosférico, ser feito de presença difusa, sem limites
definidos.
A Associação  MILK lê o mito como paradigma da visibilidade fluida, conceito central do
Folclore Vivo, em que o reconhecimento do outro se dá pela empatia, não pela de finição.
A Senhora do Nevoeiro ensina o olhar da inclusão — ver o que não  se vê, acolher o que
não  se distingue.
⸻
7. Referência Estrutural da Matriz MILK
Na Matriz Escultórica MILK – Série Folclore Vivo, a Senhora do Nevoeiro de Montedor
apresenta:
– Corpo: esguio e compacto, cabeça grande e inclinação suave;
– Cores: cinza-pérola, azul-neblina e re flexos prateados;
– Materiais: resina translúcida, difusor de vapor interno e verniz opalescente;
– Expressão:  serena, com olhos semicerrados e sorriso leve;
– Base: circular, imitando ondulação de ar e mar.
A escultura integra o eixo “Luzes Atlânticas  e Corpos Difusos” do projeto Folclore Vivo, sendo
apresentada como símbolo da empatia atmosférica — o corpo que acolhe o invisível.
⸻
Localização  específica: Carreço, Montedor e Afife (distrito de Viana do Castelo).
Primeiro relato documentado: Vasconcelos, Etnografia Portuguesa, vol. VII, 1920.
Sistematização  contemporânea:  Eduardo Mauer, A Senhora do Nevoeiro de Montedor:
Claridade, Invisibilidade e Cuidado na Mitologia Atlântica  Portuguesa, Associação MILK, 2025.
Fontes primárias:  Braga (1885); Vasconcelos (1920); Parafita (2008); Costa (2021); Mauer (2025).
