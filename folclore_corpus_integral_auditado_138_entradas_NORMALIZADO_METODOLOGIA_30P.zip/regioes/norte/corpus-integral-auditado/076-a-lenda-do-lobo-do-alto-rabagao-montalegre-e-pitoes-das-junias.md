# 076. A Lenda do Lobo do Alto Rabagão  (Montalegre e Pitões das Júnias)

**Base documental e empírica:** pesquisa documental, análise comparada de fontes públicas, sistematização de tradição oral, relatos orais de pesquisa de campo e revisão semântica conduzidas no âmbito do Folclore Vivo da Associação MILK - Movimento de Intervenções e Linguagens Kulturais e Arte.
**Estado editorial:** corpus de pesquisa de campo e documentação cultural em revisão pública.
**Regra de publicabilidade:** esta entrada não deve ser lida como prova histórica definitiva, inventário patrimonial oficial, validação etnográfica concluída ou certificação académica externa sem verificação documental própria.
**Regra jurídica/RGPD:** não publicar nomes de informantes, contactos, moradas, entrevistas integrais, imagens identificáveis, gravações, dados de menores, coordenadas sensíveis ou materiais comunitários sem autorização.
**Regra de não invenção:** a presente readequação corrige a camada editorial e metodológica sem acrescentar factos, fontes, topónimos, coordenadas ou relatos não existentes no corpus-base.
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

76. A Lenda do Lobo do Alto Rabagão  (Montalegre e Pitões das Júnias)
(Sistematização  contemporânea  conduzida por Eduardo Mauer no âmbito  das pesquisas sobre
Folclore Vivo da Associação  MILK – Movimento de Intervenções e Linguagens Kulturais e Arte,
com base em recolhas orais, arquivos paroquiais e documentação  do Ecomuseu de Barroso,
cruzadas com estudos etnográ ficos e zoológicos contemporâneos.  Pesquisa desenvolvida entre
2022 e 2024 em colaboração  com a Universidade de Trás-os-Montes  e Alto Douro e o Centro de
Estudos Rurais do Alto Tâmega.)
⸻
1. Descrição  simbólica e narrativa
A Lenda do Lobo do Alto Rabagão  nasce nas montanhas agrestes entre Montalegre e Pitões
das Júnias, território onde o vento e o silêncio moldam a paisagem e o imaginário. Nas aldeias
do planalto barrosão, o lobo é simultaneamente criatura temida e reverenciada — símbolo do
perigo e da liberdade. Contudo, o Lobo do Alto Rabagão  não é um animal comum: é o espírito
antigo da montanha, guardião do equilíbrio entre os homens e a natureza.
As narrativas recolhidas por Eduardo Mauer (2023–2024) descrevem-no como um lobo negro
de olhos âmbar , de tamanho descomunal, que caminha sozinho pelas serras. Diz-se que a sua
sombra é mais longa que o corpo e que, onde ela passa, os ventos mudam de direção. O seu
uivo não provoca medo — desperta lembrança. “Quando o Lobo do Alto Rabagão uiva”, dizem
os pastores, “a montanha responde.”
O mito conta que, durante um inverno de neve cerrada, um caçador de Pitões perseguiu o lobo
durante três dias. Ao alcançá-lo, reparou que o animal o fitava com olhos humanos. O caçador
disparou, mas a bala atravessou o ar e feriu-lhe a própria mão. O lobo aproximou-se, lambeu o
ferimento e desapareceu. Desde então, o homem passou a curar os animais feridos das aldeias,
dizendo que “a montanha lhe ensinara o perdão”.
Noutras versões, o lobo é protetor das almas dos mortos, conduzindo-as pelas serras até o
nascer do sol. Em noites de lua cheia, os viajantes afirmam ver duas luzes caminhando paralelas
— os olhos do lobo — e ouvir passos ritmados acompanhados de respiração lenta. Em certas
aldeias, o mito é lembrado como bênção: o lobo, quando aparece, antecipa boas colheitas, neve
farta e nascimentos saudáveis.
Na leitura poética de Eduardo Mauer, “o Lobo do Alto Rabagão é o coração da montanha,
batendo entre o medo e o amor. Ele não caça: recorda o homem de que tudo o que vive tem
voz.”
⸻


2. Contexto histórico e social
O planalto barrosão foi, durante séculos, território de coexistência entre o homem e o lobo. A
pastorícia extensiva, as invernias prolongadas e o isolamento geográ fico criaram uma relação
ambígua: o lobo era adversário e espelho. A sua figura foi central em cantigas, contos e rezas de
proteção, nas quais o animal se confundia com força espiritual e ancestral.
Desde a Idade Média, o lobo ibérico (Canis lupus signatus) habitava estas serras em grande
número. Os mosteiros, como o de Pitões das Júnias, referiam-se a ele em crónicas e sermões,
não apenas como fera, mas como criatura divina da solidão. O lobo era entendido como “vigia
das fronteiras invisíveis”, símbolo de coragem e consciência.
No século XIX, o Estado e as autoridades municipais promoveram campanhas de extermínio. As
caçadas ao lobo tornaram-se rituais coletivos: aldeias inteiras reuniam-se em torno da “fojassa”,
armadilha de pedras e espinhos. Contudo, o mito resistiu. Enquanto o corpo do animal
desaparecia, a sua imagem espiritual crescia — o lobo transformava-se em fantasma de
liberdade, em voz do território.
Na leitura sociocultural de Eduardo Mauer, o Lobo do Alto Rabagão representa “a ética da
montanha — o pacto não escrito entre o humano e o selvagem”. O mito, portanto, é uma
resposta poética à extinção, uma memória coletiva do equilíbrio perdido.
⸻
3. Toponímia e variantes locais
O topónimo Rabagão  deriva do termo pré-romano Ravacone (curso de água impetuoso),
designando o rio que nasce nas encostas do Larouco e percorre as freguesias de Montalegre. O
Alto Rabagão  é território de planaltos elevados, onde ventos e neves modelam o som e o
horizonte.
As variantes da lenda recolhidas por Mauer e em fontes orais incluem:
– O Lobo do Nevoeiro: em Pitões, surge envolto em névoa, guiando rebanhos perdidos;
– O Cão  do Larouco: versão que o transforma em espírito guardião da montanha;
– O Uivo Branco: de Tourém, onde o lobo uiva apenas uma vez por ano, na noite de São João;
– O Amigo da Noite: versão moderna, contada às crianças, onde o lobo protege quem anda
sozinho.
Em todas as variantes, a figura mantém o mesmo arquétipo: guardião  liminar, símbolo da
convivência entre natureza e humanidade, entre força e ternura.
⸻
4. Primeiro relato e fontes académicas primárias
O primeiro registro escrito da Lenda do Lobo do Alto Rabagão  surge em Leite de Vasconcelos,
Etnografia Portuguesa, vol. IV (1915, pp. 55–63)*, que descreve relatos de pastores de Montalegre
sobre “um lobo que não morde, mas ensina a escutar”.
Teófilo Braga, O Povo Português  nos seus Costumes, Crenças e Tradições (1885, pp. 571–578)*,
menciona “lobos de alma pura” nas montanhas transmontanas, vinculando o mito a antigas
crenças de metamorfose e penitência.
Alexandre Parafita, Mitologia Popular Portuguesa (2008, pp. 695–703)*, identifica o lobo como
“figura de mediação entre o instinto e o sagrado, arquétipo do poder que protege”.


A sistematização contemporânea de Eduardo Mauer, O Lobo do Alto Rabagão:  Voz, Silêncio  e
Fronteira no Imaginário  Barrosão  (Lisboa, Associação MILK, 2024), propõe leitura ecológica e
espiritual, unindo antropologia, filosofia ambiental e estética da escuta.
Fontes complementares:
– Arquivo Municipal de Montalegre, Registos de Caçadas e Lendas de Barroso (séculos XVIII–XX);
– Ecomuseu de Barroso, Coleção  de Mitos Pastorís  e Fauna Encantada (1960–1990);
– Tese de Doutoramento de Luís R. Pinto, O Lobo Ibérico  e o Imaginário  Rural Português  (UTAD,
2017).
⸻
5. Síntese interpretativa final
O Lobo do Alto Rabagão  é símbolo do equilíbrio entre força e serenidade. Representa a alma
que caminha só, mas em harmonia com o mundo. No contexto barrosão, o mito atua como
alegoria do respeito pela natureza e da consciência ecológica ancestral.
Na leitura simbólica da Associação  MILK, o lobo é o corpo da escuta, o ser que ensina o
homem a ouvir a montanha. O seu uivo é linguagem — vibração do território e do tempo. Ele
encarna o retorno à ética natural, onde cada gesto humano encontra eco na terra.
A escultura MILK concebida por Eduardo Mauer traduz o mito num corpo compacto, negro-
acinzentado, de cabeça erguida e boca semiaberta. Os olhos, em resina âmbar translúcida,
refletem luz quente. A base possui relevos ondulantes que remetem ao vento da serra. O corpo
brilha com verniz fosco e respiração luminosa interna, sugerindo vida sob a superfície.
⸻
6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer
Na leitura não binária de Eduardo Mauer, o Lobo do Alto Rabagão é o corpo andrógino do
instinto — simultaneamente selvagem e terno, predador e guardião, animal e espírito.
Mauer escreve:
“O lobo não conhece fronteiras de gênero. Ele é a forma fluida da força, o corpo que
protege porque sente, o que mata porque compreende.”
Para a Associação  MILK, o mito expressa o não  binário  ecológico — identidade que
não separa natureza e cultura, humano e animal, luz e sombra. O lobo é metáfora da
coexistência e da empatia radical com o mundo vivo.
Na contemporaneidade, o Lobo do Alto Rabagão  é também símbolo político e artístico:
representa o direito à diferença, à liberdade e ao território poético. Ele uiva por todos os
corpos que a sociedade quis domesticar.
⸻
7. Referência Estrutural da Matriz MILK
Na Matriz Escultórica MILK, o Lobo do Alto Rabagão é representado com corpo robusto e
compacto, superfície texturizada em tons cinza-escuro, olhos âmbar translúcidos e luz interna
suave. A base irregular evoca o relevo das serras barrosãs, enquanto o brilho discreto do verniz
remete à névoa fria do amanhecer.
⸻


Localização  específica: Montalegre, Pitões das Júnias e margens do rio Rabagão (distrito de
Vila Real).
Primeiro relato documentado: Leite de Vasconcelos, Etnografia Portuguesa, vol. IV, 1915.
Sistematização  contemporânea:  Eduardo Mauer, O Lobo do Alto Rabagão:  Voz, Silêncio  e
Fronteira no Imaginário  Barrosão , Associação MILK, 2024.
Fontes primárias:  Braga (1885); Vasconcelos (1915); Parafita (2008); Pinto (2017); Mauer (2024).
