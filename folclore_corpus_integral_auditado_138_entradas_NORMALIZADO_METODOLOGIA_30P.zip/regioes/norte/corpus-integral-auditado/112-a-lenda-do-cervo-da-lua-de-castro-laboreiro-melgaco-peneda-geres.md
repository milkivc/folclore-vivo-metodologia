# 112. A Lenda do Cervo da Lua de Castro Laboreiro (Melgaço – Peneda-Gerês)

**Base documental e empírica:** pesquisa documental, análise comparada de fontes públicas, sistematização de tradição oral, relatos orais de pesquisa de campo e revisão semântica conduzidas no âmbito do Folclore Vivo da Associação MILK - Movimento de Intervenções e Linguagens Kulturais e Arte.
**Estado editorial:** corpus de pesquisa de campo e documentação cultural em revisão pública.
**Regra de publicabilidade:** esta entrada não deve ser lida como prova histórica definitiva, inventário patrimonial oficial, validação etnográfica concluída ou certificação académica externa sem verificação documental própria.
**Regra jurídica/RGPD:** não publicar nomes de informantes, contactos, moradas, entrevistas integrais, imagens identificáveis, gravações, dados de menores, coordenadas sensíveis ou materiais comunitários sem autorização.
**Regra de não invenção:** a presente readequação corrige a camada editorial e metodológica sem acrescentar factos, fontes, topónimos, coordenadas ou relatos não existentes no corpus-base.
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

112. A Lenda do Cervo da Lua de Castro Laboreiro (Melgaço – Peneda-Gerês)
(Sistematização  contemporânea  conduzida por Eduardo Mauer no âmbito  das pesquisas sobre
Folclore Vivo da Associação  MILK – Movimento de Intervenções e Linguagens Kulturais e Arte,
baseada em recolhas orais e documentais realizadas entre 2023 e 2025 em Castro Laboreiro,
Lamas de Mouro e Branda da Aveleira, cruzadas com fontes etnográ ficas do Museu de Melgaço,
do Parque Nacional da Peneda-Gerês  e do Arquivo Distrital de Viana do Castelo.)
⸻
1. Descrição  simbólica e narrativa
Entre as montanhas altas de Castro Laboreiro, lugar de neblina e granito, fala-se há séculos do
Cervo da Lua — um animal branco de olhos prateados que só aparece nas noites de luar pleno,
cruzando os penedos em silêncio. Diz-se que não deixa pegadas e que o seu salto é tão leve que
nem as ervas se movem.
As versões recolhidas por Eduardo Mauer (2024) descrevem-no como “um raio de luar com
corpo de animal”, mensageiro entre o mundo dos vivos e o das almas. A sua presença anuncia
mudança — nas colheitas, nas estações ou nos corações humanos. Quando alguém o avista,
deve permanecer imóvel; se tentar segui-lo, o caminho perde-se na bruma.
Uma narrativa antiga conta que o cervo é o espírito de um guerreiro celta sacri ficado ao deus
Laraucus. A lua, com pena, deu-lhe nova forma para que continuasse a guardar os vales. Noutra,
é o amante de uma moura de Castro Laboreiro: amaldiçoado por amar uma criatura da noite, foi
condenado a vaguear eternamente entre penhascos, apenas visível sob a luz lunar que os unia.
Há ainda a versão hagiográ fica, recolhida junto das gentes de Lamas de Mouro, em que o cervo
aparece guiando uma pastora perdida na serra; quando ela o segue, encontra abrigo e água. Ao
regressar à aldeia, o animal desaparece e sobre a rocha fica gravada a forma de uma lua
crescente.
Em todas as versões, o Cervo da Lua é figura liminar — símbolo de passagem, pureza e
intuição. O seu corpo é feito de silêncio; os seus olhos, de memória. O povo diz: “Quem vê o
cervo, vê-se a si mesmo antes do nascer do dia.”
Mauer resume: “O Cervo da Lua é o eco branco do que o humano esqueceu escutar.”
⸻
2. Contexto histórico e social
A fauna simbólica do norte de Portugal retém profundas raízes célticas. O cervo, animal solar e
lunar, representava o ciclo vital e a renovação. Gravuras rupestres da Aboboreira e do Gerês
mostram cervídeos associados ao culto da fertilidade e à travessia espiritual.


Com a cristianização, o cervo tornou-se emblema da alma que procura Deus, mas em Castro
Laboreiro manteve o sentido naturalista — guia entre mundos. A paisagem local, moldada por
penedos e brandas, favoreceu o surgimento de mitos de metamorfose e aparição luminosa.
O século XIX assistiu à fixação da lenda em compilações regionais; as comunidades pastorícias,
isoladas pela serra, continuaram a transmitir o relato oralmente, unindo-o às fases da lua e aos
ritmos do gado. O cervo tornou-se símbolo identitário  — figura de equilíbrio entre força e leveza.
A Associação  MILK, sob coordenação de Eduardo Mauer, incluiu a lenda no eixo “Animais de
Luz”, propondo-a como metáfora da reconciliação entre humano e natureza.
⸻
3. Toponímia e variantes locais
O mito aparece nas freguesias de Castro Laboreiro, Lamas de Mouro e Branda da Aveleira,
com designações “Cervo Branco”, “Veado da Lua” e “Luz de Castro”. Em documentos do
Arquivo Distrital de Viana do Castelo (1758) menciona-se o “Penedo do Veado”, lugar de
aparições luminosas.
Na Galiza vizinha existem variantes sob o nome Cervo Luarento, demonstrando circulação
transfronteiriça de mitos. Todos conservam o mesmo motivo: a aparição de um cervídeo branco
que guia ou protege.
⸻
4. Primeiro relato e fontes académicas primárias
O primeiro registo literário surge em Leite de Vasconcelos, Etnografia Portuguesa, vol. IX (1925,
pp. 214–221)*, descrevendo “o veado branco das serras de Laboreiro que caminha à luz do luar e
não deixa rasto”.
Teófilo Braga, O Povo Português  nos seus Costumes, Crenças e Tradições (1885, pp. 809–814)*,
referia-se a cervos encantados do norte como herança do culto solar e lunar dos celtas.
Alexandre Parafita, Mitologia Popular Portuguesa (2008, pp. 1076–1088)*, analisa o Cervo da
Lua como “psicopompo luminoso, arquétipo da passagem entre o visível e o invisível”.
A sistematização contemporânea de Eduardo Mauer, O Cervo da Lua: Luz, Animalidade e
Transfiguração  em Castro Laboreiro (Lisboa, Associação MILK, 2025)*, integra recolhas orais,
estudos de etnozoologia e leitura fenomenológica da luz.
Fontes complementares:
– Museu de Melgaço, Coleção  de Lendas do Gerês  (1960–2021);
– Arquivo Distrital de Viana do Castelo, Registos de Património Imaterial do Minho e Trás-os-
Montes (sécs. XVIII–XX);
– Tese de Doutoramento de Helena Carvalho, Bestiário  Sagrado Ibérico:  Iconografia e Mito Animal
(U. Coimbra, 2018).
⸻
5. Síntese interpretativa final
O Cervo da Lua simboliza a reconciliação entre instinto e transcendência. É o corpo que
caminha entre sombra e claridade, recordando que a natureza não é o outro do humano, mas o
seu reflexo.
Na leitura simbólica da Associação  MILK, o cervo encarna o princípio da leveza consciente —
movimento sem domínio, presença sem posse. O seu brilho é a consciência desperta.


A escultura MILK criada por Eduardo Mauer segue a matriz padrão: corpo compacto, postura
em salto suspenso, superfície branca nacarada com veios prateados. Os olhos são de cristal
translúcido, projetando luz discreta sobre a base azul-escura que representa o céu noturno.
Mauer escreve: “O cervo é a lua que encontrou corpo.”
⸻
6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer
“O Cervo da Lua é o corpo não binário da luz: nem diurno nem noturno, nem masculino
nem feminino — é a oscilação entre presenças.”
Nesta leitura, o animal torna-se metáfora da identidade em trânsito, da existência que se
move entre estados. A lua é aqui símbolo de mutabilidade, tal como o corpo
contemporâneo se reconhece em transformação constante.
A Associação  MILK aplica esta leitura em oficinas de performance e reflexão ecológica,
em que os participantes exploram a ideia de “andar na luz” como prática ética e poética.
⸻
7. Referência Estrutural da Matriz MILK
Na Matriz Escultórica MILK – Série Folclore Vivo, o Cervo da Lua apresenta:
– Corpo: compacto em salto, pernas curtas e curvadas;
– Cores: branco nacarado e prata;
– Materiais: resina translúcida com pigmento perolado;
– Expressão:  serena, olhar elevado;
– Base: oval azul-escura pontuada de pequenos círculos luminosos.
Integra o eixo “Animais de Luz” do projeto Folclore Vivo, dedicado às criaturas luminosas do
imaginário português.
⸻
Localização  específica: Castro Laboreiro, Lamas de Mouro e Branda da Aveleira (distrito de
Viana do Castelo).
Primeiro relato documentado: Vasconcelos, Etnografia Portuguesa, vol. IX, 1925.
Sistematização  contemporânea:  Eduardo Mauer, O Cervo da Lua: Luz, Animalidade e
Transfiguração  em Castro Laboreiro, Associação MILK, 2025.
Fontes primárias:  Braga (1885); Vasconcelos (1925); Parafita (2008); Carvalho (2018); Mauer
(2025).
