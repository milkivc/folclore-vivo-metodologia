# 008. A Velha da Égua Branca (Alto Minho e Trás-os-Montes)

**Base documental e empírica:** pesquisa documental, análise comparada de fontes públicas, sistematização de tradição oral, relatos orais de pesquisa de campo e revisão semântica conduzidas no âmbito do Folclore Vivo da Associação MILK - Movimento de Intervenções e Linguagens Kulturais e Arte.
**Estado editorial:** corpus de pesquisa de campo e documentação cultural em revisão pública.
**Regra de publicabilidade:** esta entrada não deve ser lida como prova histórica definitiva, inventário patrimonial oficial, validação etnográfica concluída ou certificação académica externa sem verificação documental própria.
**Regra jurídica/RGPD:** não publicar nomes de informantes, contactos, moradas, entrevistas integrais, imagens identificáveis, gravações, dados de menores, coordenadas sensíveis ou materiais comunitários sem autorização.
**Regra de não invenção:** a presente readequação corrige a camada editorial e metodológica sem acrescentar factos, fontes, topónimos, coordenadas ou relatos não existentes no corpus-base.
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

A Velha da Égua Branca (Alto Minho e Trás-os-Montes)
(Sistematização  contemporânea  conduzida por Eduardo Mauer e Nuno Araújo no âmbito  das
pesquisas sobre Folclore Vivo da Associação  MILK – Movimento de Intervenções e Linguagens
Kulturais e Arte)
⸻
1. Descrição  simbólica e narrativa
A Velha da Égua Branca surge, nas tradições do Norte, como um espectro híbrido entre mulher
e animal. Descrita como anciã  de longos cabelos brancos, olhos de lume e corpo dobrado
sobre uma égua igualmente pálida , aparece nas noites de luar percorrendo campos e eiras,
soltando gritos que lembram o relinchar. É, ao mesmo tempo, mensageira e castigo: anuncia a
morte próxima ou o fim das colheitas, mas também guia as almas perdidas de volta ao lar.
Na região de Arcos de Valdevez contam que a velha corre à frente de ventos súbitos; em
Bragança dizem que surge em encruzilhadas, batendo o chão com o bastão; em Montalegre,
afirmam que é espírito de uma curandeira que, para escapar à Inquisição, se fundiu com a sua
égua e desde então cavalga entre os mundos. O mito, recolhido por Eduardo Mauer entre 2022
e 2024, mostra a fusão de duas figuras arcaicas: a deusa-mãe  e o animal psicopompo
(condutor das almas).
A égua branca — símbolo de pureza solar desde o culto de Epona, venerado na Lusitânia romana
— representa a travessia e a fertilidade; a velha, o declínio e o conhecimento. A união de ambas
cria uma entidade de passagem, guardiã dos limiares entre vida e morte, verão e inverno. As
lendas descrevem-na caminhando sobre a neblina, deixando pegadas de fogo. Quem a escuta
sem medo recebe bênção; quem foge, enlouquece.
O caráter ambivalente repete-se nas expressões populares: “Passou a velha na égua branca”
significa que o tempo virou, que algo mudou de rumo. A aparição é sempre prelúdio de
transformação. Para Mauer e Araújo, a Velha da Égua Branca “encena a biogra fia do mundo
natural: nascer, gastar-se, regressar à luz”.
⸻
2. Contexto histórico e social
O imaginário equino do Noroeste peninsular remonta à Antiguidade. Escavações em Vale do
Mouro e Chaves revelaram ex-votos de cavalos e estatuetas femininas, sugerindo culto conjunto
à fertilidade e ao gado. Com a cristianização, Epona e outras deusas cavaleiras foram
demonizadas, dando origem a narrativas de bruxas montadas em éguas ou espíritos noturnos.
Entre os séculos XVII e XIX, as crónicas paroquiais e sermões populares referem “velhas
montadas em bestas brancas” que apareciam em caminhos de procissões, associadas a
penitências não cumpridas. Nas freguesias durienses, o mito servia para advertir as mulheres que
trabalhavam sozinhas à noite — o medo social da autonomia feminina convertia-se em fantasma
moral.
No século XIX, Teófilo Braga e Leite de Vasconcelos recolheram versões onde a velha já não
era castigo divino, mas guardadora de caminhos. O cavalo branco tornara-se símbolo da alma
pura que transporta o corpo envelhecido. No discurso contemporâneo recolhido por Mauer, a
lenda ganha nova ressonância ecológica: a velha cavalga porque “é o vento do tempo”,
representação da natureza envelhecida que ainda sustenta o mundo.


⸻
3. Toponímia e variantes locais
O mito concentra-se no Alto Minho e Trás-os-Montes , com registros em Arcos de Valdevez,
Montalegre, Bragança, Vila Real e Lamego. Topónimos como Lomba da Velha, Caminho da
Égua  e Fonte Branca surgem associados a episódios de aparição.
Em Soajo, fala-se da “Égua Velha”, que pasta nos nevoeiros e conduz as almas ao santuário das
Neves. Em Vinhais, a entidade surge dividida: a “Velha” aparece de dia, curando feridas; a “Égua
Branca”, à noite, levando sonhos. Já na fronteira galega, regista-se a “Vella do Cabalo Branco”,
espírito semelhante que protege pastores.
⸻
4. Primeiro relato e fontes académicas primárias
O primeiro testemunho literário conhecido data de 1867, no Arquivo Pittoresco, onde José
Tavares Proença menciona “a velha de cabelos de neve que cavalga a égua dos ventos em
terras do Minho”.
Teófilo Braga, O Povo Português  nos seus Costumes, Crenças e Tradições (1883, p. 391),
regista-a como “alma penitente que surge em montes e ribeiros, anunciando as trovoadas”.
Leite de Vasconcelos, Etnografia Portuguesa, vol. II (1913, p. 208), interpreta-a como “resíduo
da deusa Epona, transfigurada em velha mítica após séculos de repressão do feminino sagrado”.
Alexandre Parafita, Mitologia Popular Portuguesa (2008), liga a figura às “bruxas cavaleiras”
medievais e destaca a simbologia do branco como “luz do além”.
Fontes complementares:
– Arquivo Distrital de Viana do Castelo, Caderno de Lendas do Minho (1874);
– Museu de Etnografia de Barroso, Coleção  Bestas e Bruxas (1890–1905);
– Tese de Doutoramento de Helena Coutinho, Corpo Feminino e Animalidade no Imaginário
Ibérico  (U. Minho, 2019).
⸻
5. Síntese interpretativa final
A Velha da Égua Branca é o arquétipo do tempo reconciliado: juventude e decadência fundem-
se num mesmo gesto. Cavalgando a égua da luz, a velha transforma a morte em percurso. A
lenda lembra que o envelhecer não é declínio, mas trans figuração — passagem da força física à
força simbólica.
Para a Associação  MILK, a figura traduz o conceito de Folclore Vivo: o mito que continua a
mover-se porque contém o movimento da vida. A égua branca é metáfora da arte — corpo que
transporta a memória.
Na escultura MILK criada por Eduardo Mauer e Nuno Araújo, a velha apresenta cabeça de
proporções generosas, rosto sereno e olhos cerrados; o corpo compacto sustenta a pequena
égua, de cauda ondulante. As cores branco-leitoso e prateado fundem-se em verniz acetinado,
simbolizando pureza e desgaste.
⸻


6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer
Na leitura não binária de Eduardo Mauer e Nuno Araújo, a Velha da Égua Branca é corpo
duplo: humano e animal, feminino e masculino, tempo e eternized. O mito dissolve a oposição
entre juventude e velhice, homem e mulher, razão e instinto. A velha e a égua são partes do
mesmo ser — a consciência e o corpo em harmonia.
Mauer propõe ver nela a transfiguração  queer da velhice, onde o envelhecer é libertação do
género e do dever. A velha não representa decadência, mas potência pós-identitária: o corpo
que, ao perder limites, alcança plenitude.
O cavalo branco, símbolo tradicionalmente masculino (força, sol), é aqui montado pela figura
feminina, invertendo papéis e reequilibrando forças. A cavalgada é ato de emancipação simbólica
— o feminino que guia o masculino, o animal que carrega o humano.
Assim, a Velha da Égua Branca torna-se ícone da interdependência das polaridades: a fluidez
como sabedoria. No pensamento de Mauer e Araújo e na estética da Associação  MILK, o mito
expressa o ideal do Folclore Vivo como território onde o corpo e o tempo deixam de ser
categorias fixas e passam a ser experiências contínuas de transformação.
⸻
7. Referência Estrutural da Matriz MILK
Na Matriz Escultórica MILK, a Velha da Égua Branca é modelada com corpo compacto, cabeça
grande inclinada e manto esculpido fundindo-se à forma do animal. A égua é pequena, de linhas
curvas, representando movimento circular. Cores predominantes: branco, prata e lilás-pálido,
com toques dourados no olhar. O acabamento combina textura fosca (corpo) e brilho difuso
(éguas e cabelos).
A instalação expositiva deve incluir luz descendente fria e som grave de relincho distante, criando
sensação de travessia.
⸻
Localização  específica: Alto Minho (Arcos de Valdevez, Viana do Castelo); Trás-os-Montes
(Bragança, Montalegre, Vila Real).
Primeiro relato documentado: José Tavares Proença, Arquivo Pittoresco, 1867.
Fontes primárias:  Proença (1867); Braga (1883); Vasconcelos (1913); Parafita (2008); Coutinho
(2019);
