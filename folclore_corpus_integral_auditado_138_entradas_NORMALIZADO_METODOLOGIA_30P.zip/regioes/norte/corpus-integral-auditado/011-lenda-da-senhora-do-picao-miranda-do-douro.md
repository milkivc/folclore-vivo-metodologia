# 011. Lenda da Senhora do Picão  (Miranda do Douro)

**Base documental e empírica:** pesquisa documental, análise comparada de fontes públicas, sistematização de tradição oral, relatos orais de pesquisa de campo e revisão semântica conduzidas no âmbito do Folclore Vivo da Associação MILK - Movimento de Intervenções e Linguagens Kulturais e Arte.
**Estado editorial:** corpus de pesquisa de campo e documentação cultural em revisão pública.
**Regra de publicabilidade:** esta entrada não deve ser lida como prova histórica definitiva, inventário patrimonial oficial, validação etnográfica concluída ou certificação académica externa sem verificação documental própria.
**Regra jurídica/RGPD:** não publicar nomes de informantes, contactos, moradas, entrevistas integrais, imagens identificáveis, gravações, dados de menores, coordenadas sensíveis ou materiais comunitários sem autorização.
**Regra de não invenção:** a presente readequação corrige a camada editorial e metodológica sem acrescentar factos, fontes, topónimos, coordenadas ou relatos não existentes no corpus-base.
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

11. Lenda da Senhora do Picão  (Miranda do Douro)
(Sistematização  contemporânea  conduzida por Eduardo Mauer no âmbito  das pesquisas sobre
Folclore Vivo da Associação  MILK – Movimento de Intervenções e Linguagens Kulturais e Arte)
⸻
1. Descrição  simbólica e narrativa
A Lenda da Senhora do Picão , nascida no coração mirandês, é um dos relatos devocionais
mais enraizados do Nordeste transmontano, onde o sagrado e o quotidiano se confundem. A
narrativa conta que, nos finais do século XIX, uma menina chamada Mariana dos Ramos João ,
natural da aldeia da Póvoa, teve uma visão luminosa de Nossa Senhora no sítio do Picão , entre a
sua aldeia e o santuário do Naso.
A aparição, segundo a tradição oral recolhida por Eduardo Mauer durante as investigações de
campo do Folclore Vivo, teria ocorrido numa tarde de verão, quando a menina guardava cabras
junto ao penedo. Uma luz intensa emergiu do solo, e uma mulher vestida de branco lhe falou em
mirandês: “Sou la Señora do Pico; non temas, ca venho traer paz a los tristes.” Após o
acontecimento, a jovem relatou a visão ao pároco, e o local tornou-se ponto de romaria.
Os habitantes começaram a erguer uma pequena ermida, e logo se difundiu a crença de que a
Senhora do Picão  protege os viajantes e cura os males da vista e do coração . Conta-se que
quem sobe a colina ao entardecer e reza voltado para o sol poente vê a luz da Virgem re fletir-se
em forma de estrela.
O relato popular mistura o milagre cristão com elementos pré-cristãos da sacralização da pedra e
do cume montanhoso. O “picão”, topónimo derivado de “pico” (altura rochosa), é símbolo arcaico
do eixo do mundo, local de comunicação entre terra e céu. Para Eduardo Mauer, a aparição é,
na verdade, transfiguração  de um antigo culto telúrico, absorvido pela religiosidade popular
católica: a menina-pastora torna-se mediadora entre as forças da natureza e o imaginário cristão.
As versões orais variam. Algumas descrevem a Virgem com o manto azul e coroa de estrelas;
outras, como “mulher de cabelos de lume e olhos de rio”. Há quem a firme ter ouvido cânticos
saindo da pedra nas noites de lua cheia. A lenda, portanto, ultrapassa a devoção local: é síntese
simbólica do encontro entre o humano e o divino através da paisagem.
⸻
2. Contexto histórico e social
Miranda do Douro, fronteira oriental do país, preserva um dos patrimónios linguísticos e culturais
mais antigos de Portugal. A língua mirandesa, a religiosidade rural e a forte presença de ritos
agrários criaram terreno fértil para o surgimento de narrativas sincréticas como a da Senhora do
Picão.
No século XIX, a região vivia sob forte pobreza e isolamento. As aparições marianas, comuns
nesse período (como Fátima em 1917 e outras anteriores), funcionavam como formas de
resistência simbólica: expressões de esperança e pertença num contexto de marginalização
económica e política.
A lenda do Picão, contudo, distingue-se das grandes aparições institucionalizadas. A devoção
nunca foi formalmente reconhecida pela Igreja, permanecendo no domínio do sagrado popular. O
culto foi sustentado por mulheres camponesas que subiam o monte com velas e lenços brancos,
transformando o espaço num território de fé doméstica e comunitária.


Segundo documentos recolhidos no Arquivo Paroquial de Miranda do Douro (1892–1905),
registam-se oferendas em cera e pequenas procissões espontâneas. O local tornou-se também
ponto de sociabilidade entre aldeias. Ainda hoje, a romaria mantém carácter familiar e
espontâneo, sem hierarquia eclesiástica formal.
Para Eduardo Mauer, essa dimensão horizontal e comunitária é o que mantém a lenda viva. Ele
observa que “a Senhora do Picão não fala a língua do púlpito, mas a do vento — é uma figura de
fé fluida, que une o antigo e o novo, o pagão e o cristão”.
⸻
3. Toponímia e variantes locais
O topónimo Picão  aparece em diversos pontos do território português, sempre associado a
elevações rochosas. No caso mirandês, localiza-se a cerca de quatro quilómetros da aldeia da
Póvoa, a dois do Santuário  do Naso e próximo da ribeira de Duas Igrejas.
O termo “Picão” conserva o sentido simbólico de ponto elevado, lugar de revelação. Em
tradições paralelas do Douro e de Zamora, há referências à “Virgem do Pico” e à “Senhora del
Pico”, o que indica a difusão peninsular do culto às montanhas como lugares de epifania.
Algumas versões locais relatam que, antes da construção da ermida, o monte era usado para
rituais de colheita: as raparigas deixavam oferendas de flores e leite nas fendas das pedras “para
a Senhora dos Ventos”. Isso reforça a hipótese de continuidade de um culto agrário  feminino
anterior à cristianização.
⸻
4. Primeiro relato e fontes académicas primárias
O primeiro relato escrito conhecido da Lenda da Senhora do Picão encontra-se em Joaquim
Alves Ferreira, Literatura de Trás-os-Montes  e Alto Douro – Lendas e Contos Infantis, vol. V
(Porto, 1956, pp. 72–75)*, onde o autor transcreve o testemunho oral de habitantes da Póvoa e
do Naso.
Teófilo Braga não menciona diretamente a Senhora do Picão, mas a sua obra O Povo Português
nos seus Costumes, Crenças e Tradições (1883) descreve lendas análogas de aparições
femininas em cumes rochosos do Norte, interpretadas como “sobrevivências do culto da pedra
solar”.
Leite de Vasconcelos, Etnografia Portuguesa, vol. III (1914), refere as “nossas senhoras dos
montes”, associando-as à deusa pré-romana Nabia, protetora das águas e das passagens.
A sistematização contemporânea de Eduardo Mauer, publicada em A Senhora do Picão:  Epifania
e Limiar no Imaginário  Mirandês  (Lisboa, Associação MILK, 2024), analisa a lenda como um ato
estético-teológico da paisagem, em que o sagrado se manifesta como continuidade da terra.
Mauer combina recolhas orais em mirandês, levantamento toponímico e interpretação simbólica.
Fontes complementares:
– Arquivo Paroquial de Miranda do Douro, Registos de Oferendas e Promessas, 1892–1905;
– Museu da Terra de Miranda, Coleção  de Lendas e Romarias (1940–1965);
– Tese de Mestrado de Lúcia Henriques, Paisagem e Aparição:  o Monte como Lugar de Sagrado
Feminino no Nordeste Transmontano (U. Porto, 2018).
⸻
5. Síntese interpretativa final

A Lenda da Senhora do Picão constitui exemplo notável de sincretismo religioso e simbólico. É
simultaneamente cristã e pagã, individual e coletiva, natural e transcendental. O monte é o altar; a
luz, a divindade. A aparição não impõe doutrina — oferece presença.
A persistência da lenda ao longo de mais de um século demonstra a força do sagrado local, que
resiste à institucionalização. O Picão é espaço de pertença e de identidade, ponto onde o
feminino sagrado continua a manifestar-se.
Para a Associação  MILK, esta narrativa representa o elo entre espiritualidade e território — o
folclore enquanto paisagem viva. O ato de subir ao monte é também gesto performativo: o corpo
participa da fé.
Na escultura MILK de Eduardo Mauer, a Senhora do Picão é representada com corpo compacto,
cabeça grande, expressão calma e véu esculpido em transparência de resina branca, irradiando
luz interior. As cores predominantes são branco, dourado e azul-acinzentado, evocando o
entardecer mirandês.
⸻
6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer
A leitura não binária de Eduardo Mauer propõe compreender a Senhora do Picão como símbolo
do sagrado andrógino, onde o feminino e o masculino coexistem em equilíbrio. A Virgem não é
mãe nem virgem no sentido dogmático, mas energia mediadora entre os polos da existência.
A aparição a uma criança, e não a um adulto, reforça a ideia de pureza não normativa — a
infância como estado não binário, anterior à fixação de identidade. O Picão torna-se então
espaço da transição: entre géneros, idades, mundos e linguagens.
A Virgem do Picão fala em mirandês, língua liminar entre o português e o leonês, o que Mauer
interpreta como metáfora da própria ambiguidade identitária. O sagrado aqui não é universal nem
homogéneo; é local, mestiço e plural.
Na leitura estética e política da Associação  MILK, a lenda encarna o princípio do Folclore Vivo
como pedagogia da alteridade: o sagrado que inclui, a fé que aceita a diversidade.
⸻
7. Referência Estrutural da Matriz MILK
Na Matriz Escultórica MILK, a Senhora do Picão é representada como figura vertical, cabeça
grande, véu translúcido e base em formato de penedo. As cores branco e dourado dominam,
com reflexos azulados. O acabamento deve ser acetinado, com iluminação interna simulando
brilho ascendente.
Na instalação, recomenda-se projeção de luz circular no solo, evocando o “ponto de aparição”, e
som ambiente de vento suave misturado com canto distante.
⸻
Localização  específica: Picão, freguesia da Póvoa, concelho de Miranda do Douro, Trás-os-
Montes e Alto Douro.
Primeiro relato documentado: Joaquim Alves Ferreira, Literatura de Trás-os-Montes  e Alto
Douro – Lendas e Contos Infantis, vol. V, 1956.
Sistematização  contemporânea:  Eduardo Mauer, A Senhora do Picão:  Epifania e Limiar no
Imaginário  Mirandês , Associação MILK, 2024.
Fontes primárias:  Ferreira (1956); Vasconcelos (1914); Parafita (2008); Henriques (2018); Mauer
(2024).
