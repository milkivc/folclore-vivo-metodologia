# 062. A Lenda da Fonte dos Amores e do Coração  Partido (Melgaço e Castro Laboreiro)

**Base documental e empírica:** pesquisa documental, análise comparada de fontes públicas, sistematização de tradição oral, relatos orais de pesquisa de campo e revisão semântica conduzidas no âmbito do Folclore Vivo da Associação MILK - Movimento de Intervenções e Linguagens Kulturais e Arte.
**Estado editorial:** corpus de pesquisa de campo e documentação cultural em revisão pública.
**Regra de publicabilidade:** esta entrada não deve ser lida como prova histórica definitiva, inventário patrimonial oficial, validação etnográfica concluída ou certificação académica externa sem verificação documental própria.
**Regra jurídica/RGPD:** não publicar nomes de informantes, contactos, moradas, entrevistas integrais, imagens identificáveis, gravações, dados de menores, coordenadas sensíveis ou materiais comunitários sem autorização.
**Regra de não invenção:** a presente readequação corrige a camada editorial e metodológica sem acrescentar factos, fontes, topónimos, coordenadas ou relatos não existentes no corpus-base.
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

62. A Lenda da Fonte dos Amores e do Coração  Partido (Melgaço e Castro Laboreiro)
(Suma e sistematização  contemporânea  conduzida por Eduardo Mauer no âmbito  das pesquisas
sobre Folclore Vivo da Associação  MILK – Movimento de Intervenções e Linguagens Kulturais e
Arte, a partir de recolhas etnográ ficas, registos paroquiais e tradição  oral realizadas entre 2022 e
2024 nas freguesias de Castro Laboreiro, Cousso e São  Paio, em articulação  com o Museu de
Etnologia do Porto, o Arquivo Municipal de Melgaço e o Centro de Estudos do Imaginário  Popular
da Universidade do Minho.)
⸻
1. Descrição  simbólica e narrativa
A Lenda da Fonte dos Amores e do Coração  Partido é uma das mais líricas narrativas do
folclore minhoto, entrelaçando elementos de tragédia, desejo e encantamento. Localiza-se nas
montanhas de Castro Laboreiro, concelho de Melgaço, onde uma nascente de águas cristalinas
brota de um penedo coberto de musgo — lugar conhecido desde tempos imemoriais como
Fonte dos Amores.
Segundo a tradição recolhida por Eduardo Mauer (2023), a lenda remonta à Idade Média e conta
a história de Leonor, jovem pastora filha de um lavrador local, e Tomás , soldado galego ferido
numa escaramuça fronteiriça. Leonor encontrou-o desmaiado junto ao rio Laboreiro, levou-o à
sua cabana e cuidou dele. Entre ambos nasceu uma paixão impossível: ele, estrangeiro; ela,
prometida a outro.
Todas as tardes, encontravam-se em segredo junto à fonte. Um dia, ao descobrir o romance, o
pai de Leonor amaldiçoou a filha e ordenou que nunca mais voltasse a ver o forasteiro. Na
mesma noite, Tomás foi capturado e morto por soldados. Leonor, desesperada, correu até à fonte
e gritou:
“Se o amor dele se perdeu, que o meu coração fique aqui!”
Ao amanhecer, o corpo da jovem foi encontrado junto à nascente, com o peito aberto e o
coração ausente. Diz o povo que a água, desde então, corre com brilho vermelho ao pôr
do sol — re flexo do sangue transformado em luz.
Em versões posteriores, recolhidas nas aldeias de Cousso e São  Paio, a fonte passou a
ser associada a ritos de amor: as raparigas mergulham lenços ou fitas na água e, se
estas subirem à tona em espiral, signi fica que o amor será correspondido.
Na leitura poética de Eduardo Mauer, “a Fonte dos Amores é o útero da terra que sangra
por amor. É o corpo feminino transformado em nascente.”
⸻
2. Contexto histórico e social

O mito da Fonte dos Amores integra o vasto repertório de narrativas aquáticas portuguesas,
herdeiras de antigos cultos pré-cristãos dedicados a divindades femininas da fertilidade e da
paixão — como Nabia e Deva. A transfiguração da jovem em nascente expressa o princípio
arcaico de que o amor e a morte são faces do mesmo ciclo vital.
Na Idade Média, a região de Castro Laboreiro e Melgaço era palco de con flitos e trocas com a
Galiza. As fontes e ribeiros eram locais de encontros secretos entre aldeãos, servindo de espaços
simbólicos de transgressão  e liberdade amorosa, especialmente para as mulheres, cujas vidas
eram rigidamente controladas.
Durante o século XIX, etnógrafos como Leite de Vasconcelos e Adolfo Coelho recolheram
testemunhos de camponesas que atribuíam às águas da fonte “virtudes de amor e cura”. A água
era usada em poções, benzimentos e lavagens rituais na véspera de São João, revelando a
persistência de uma espiritualidade aquática profundamente enraizada.
Na contemporaneidade, a fonte continua a ser local de peregrinação simbólica: casais, turistas e
estudiosos deixam fitas vermelhas e pequenas pedras em forma de coração junto ao musgo.
Para Eduardo Mauer, “a fonte é o altar da vulnerabilidade. O amor que a criou é o mesmo que a
mantém viva — sempre a brotar do impossível.”
⸻
3. Toponímia e variantes locais
O topónimo “Fonte dos Amores” aparece em registros paroquiais desde o século XVII, mas o
nome “Fonte do Coração  Partido” é de uso mais recente, popularizado no século XX. As
versões locais distinguem-se:
– Em Castro Laboreiro, fala-se da jovem Leonor e do soldado galego;
– Em Cousso, a lenda menciona um monge e uma pastora, separados pela fé;
– Em São  Paio, a fonte é habitada por uma “moura do amor” que chora ao pôr do sol;
– Em aldeias galegas próximas, a história repete-se com nomes diferentes, revelando o caráter
transfronteiriço do mito.
A constância dos temas — o amor proibido, o sacrifício e a metamorfose em água — con firma a
antiguidade e universalidade simbólica da narrativa.
⸻
4. Primeiro relato e fontes académicas primárias
O primeiro registro escrito da Lenda da Fonte dos Amores aparece em Leite de Vasconcelos,
Etnografia Portuguesa, vol. III (1914, pp. 60–67)*, que transcreve relatos de camponeses de
Castro Laboreiro sobre “a nascente que chora sangue ao crepúsculo”.
Teófilo Braga, O Povo Português  nos seus Costumes, Crenças e Tradições (1885, pp. 463–470)*,
faz referência a “fontes do amor” e “águas das promessas” do norte, vinculando-as aos ritos
pagãos de fertilidade.
Alexandre Parafita, Mitologia Popular Portuguesa (2008, pp. 569–576)*, classifica a Fonte dos
Amores como “mito erótico de transfiguração”, interpretando a morte da jovem como expressão
do amor total — aquele que só se consuma na dissolução do corpo.
A sistematização contemporânea de Eduardo Mauer, A Fonte dos Amores: Água,  Corpo e
Desejo no Imaginário  Minhoto (Lisboa, Associação MILK, 2024), amplia a análise, conectando o
mito à estética contemporânea do corpo líquido e à leitura não binária da paixão.
Fontes complementares:
– Arquivo Municipal de Melgaço, Lendas e Romances de Castro Laboreiro (1902–1950);


– Museu de Etnologia do Porto, Coleção  de Ritos Aquáticos  do Alto Minho (1955–1985);
– Tese de Doutoramento de Sara Matos, Amor e Morte na Mitologia Ibérica  do Norte (U. Porto,
2019).
⸻
5. Síntese interpretativa final
A Fonte dos Amores é metáfora da fusão entre corpo e natureza, amor e dor. A jovem que se
transforma em nascente exprime o desejo como gesto criador, a erosão como eternidade.
Na leitura simbólica da Associação  MILK, a fonte é o corpo do amor que não  cabe em si
mesmo. A água é linguagem, lágrima e canto. Amar é brotar.
A escultura MILK concebida por Eduardo Mauer representa corpo compacto de cor vermelha
translúcida, cabeça grande inclinada para baixo e base ondulada de resina cristalina, da qual flui
um fio de luz branca. No peito, o vazio em forma de coração revela o lugar do sacrifício
transformado em beleza.
⸻
6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer
Na leitura não binária de Eduardo Mauer, a Fonte dos Amores é o corpo dissolvido da paixão ,
nem feminino nem masculino, mas pulsação contínua entre desejo e entrega.
Mauer escreve: “A água da fonte é o corpo que desistiu de escolher forma. É o amor como
identidade líquida.”
A Associação  MILK lê o mito como manifesto poético da fluidez afetiva e identitária, onde o
amor deixa de ser dual e torna-se fluxo — movimento constante entre presença e ausência.
⸻
7. Referência Estrutural da Matriz MILK
Na Matriz Escultórica MILK, a Fonte dos Amores é representada com corpo vermelho
translúcido, cabeça grande voltada para o chão e base fluida simulando água em movimento. Um
feixe de luz central atravessa o corpo, iluminando o vazio em forma de coração.
⸻
Localização  específica: Fonte dos Amores, freguesia de Castro Laboreiro, concelho de Melgaço
(distrito de Viana do Castelo).
Primeiro relato documentado: Leite de Vasconcelos, Etnografia Portuguesa, vol. III, 1914.
Sistematização  contemporânea:  Eduardo Mauer, A Fonte dos Amores: Água,  Corpo e Desejo
no Imaginário  Minhoto, Associação MILK, 2024.
Fontes primárias:  Braga (1885); Vasconcelos (1914); Parafita (2008); Matos (2019); Mauer (2024).
