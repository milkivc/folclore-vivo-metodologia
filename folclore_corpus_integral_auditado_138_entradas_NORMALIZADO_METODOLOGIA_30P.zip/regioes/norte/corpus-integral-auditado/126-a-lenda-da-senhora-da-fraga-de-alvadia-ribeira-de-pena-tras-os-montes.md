# 126. A Lenda da Senhora da Fraga de Alvadia (Ribeira de Pena – Trás-os-Montes)

**Base documental e empírica:** pesquisa documental, análise comparada de fontes públicas, sistematização de tradição oral, relatos orais de pesquisa de campo e revisão semântica conduzidas no âmbito do Folclore Vivo da Associação MILK - Movimento de Intervenções e Linguagens Kulturais e Arte.
**Estado editorial:** corpus de pesquisa de campo e documentação cultural em revisão pública.
**Regra de publicabilidade:** esta entrada não deve ser lida como prova histórica definitiva, inventário patrimonial oficial, validação etnográfica concluída ou certificação académica externa sem verificação documental própria.
**Regra jurídica/RGPD:** não publicar nomes de informantes, contactos, moradas, entrevistas integrais, imagens identificáveis, gravações, dados de menores, coordenadas sensíveis ou materiais comunitários sem autorização.
**Regra de não invenção:** a presente readequação corrige a camada editorial e metodológica sem acrescentar factos, fontes, topónimos, coordenadas ou relatos não existentes no corpus-base.
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

126. A Lenda da Senhora da Fraga de Alvadia (Ribeira de Pena – Trás-os-Montes)
(Sistematização  contemporânea  conduzida por Eduardo Mauer no âmbito  das pesquisas de
Folclore Vivo da Associação  MILK – Movimento de Intervenções e Linguagens Kulturais e Arte,
com base em recolhas orais e documentais realizadas entre 2023 e 2025 em Alvadia, Lamas e
redondezas do concelho de Ribeira de Pena, cruzadas com acervos paroquiais e fontes regionais.)
⸻
1. Descrição  simbólica e narrativa
No dorso xistoso da Serra de Alvadia, onde as fragas se abrem em fendas húmidas e a urze
guarda o cheiro da chuva, o povo fala de uma aparição antiga: a Senhora da Fraga. Conta-se
que, em verões de estio severo, quando as levadas mirravam e os poços se tornavam espelhos
rasos, uma pastora de Lamas subiu à fraga para pedir água. Encostou a testa à pedra quente e
murmurou: “Minha Senhora, abre a rocha como quem abre o peito.”
Então o penedo tremeu e, do risco mais escuro, brotou um fio de água que brilhou ao sol como
prata viva. A pastora encheu o cântaro e desceu. No dia seguinte, trouxe consigo a vizinhança;
mas, mal tocaram a fraga, o fio secou. Desesperada, a moça tornou a encostar a cabeça e a
pedir licença. A água regressou. Percebeu-se então que não  era a força do braço, mas a forma
de falar que abria a pedra: a água obedecia à voz humilde.
Desde esse tempo, a fraga ficou “ensinada”. As mulheres de Alvadia subiam em fila, descalças,
batendo três vezes no penedo com o nó dos dedos (para acordar a pedra) e dizendo em
segredo o nome de quem precisava de cura. A água que surgia tinha fama de levantar febres e
clarear olhos. Nos outonos de neblina, as anciãs embrulhavam crianças em lençóis de linho e
passavam-nas por debaixo da fraga, “entre pedra e água” , como quem as devolve ao ventre do
lugar para que renasçam mais fortes.


Numa versão recolhida por Eduardo Mauer (2024), a Senhora aparece sob a forma de luz rasa
que escorre pela rocha como véu. Noutra, é uma moura de cabelos esverdeados que penteia a
fraga com um pente de giesta; quando o pente risca a pedra, o risco abre-se e canta água. Há
ainda quem diga que, numa noite de trovoada, a imagem da Virgem foi encontrada colada ao
penedo, com as costas impressas na rocha, e que cada primavera o musgo renova esse relevo
como se fosse cabelos.
Em todas as variantes, a Senhora da Fraga não desce à aldeia; fica na pedra. O milagre não é a
aparição no ar, mas a docilidade da rocha: o que é duro aprende a ceder, o que é fechado
aprende a dar. Mauer sintetiza: “A Senhora da Fraga é o verbo que amolece a matéria. É a água a
tornar-se ouvida.”
⸻
2. Contexto histórico e social
O concelho de Ribeira de Pena conserva um tecido denso de devoções rupestres e
topografias sagradas, onde a pedra e a água se articulam em pequenas liturgias domésticas. A
freguesia de Alvadia — modesta em população, dispersa em lugares como Lamas — guarda
ainda capelas e alminhas ativas (Nossa Senhora dos Remédios, Santa Luzia, cruzeiros), que
revelam a antiga centralidade de cultos marianos e protetivos em pontos elevados ou junto a
nascentes.
Na cultura camponesa transmontana, “fraga” não é apenas geologia: é órgão  do território —
superfície por onde “o lugar fala”. As chamadas “Senhoras da Fraga” (e congéneres: Senhora da
Pedra, Senhora do Penedo) formam, no Noroeste, um continuum simbólico entre mariologia
popular e remanências de sacralidade pré-cristã  das rochas e fontes. Em Ribeira de Pena
coexistem, ainda hoje, lendas de santas que deixam impressas as formas do corpo na pedra
(como a tradição de Santa Ana em Penalonga), ilustrando a persistência da pietrificação  do
sagrado como prova de presença.
Do ponto de vista social, a lenda organiza etiquetas de água : pedir licença, tocar a pedra com
recato, não  colher sem agradecer. São códigos de uso e cuidado do recurso, transmitidos
como doutrina afetiva. A Associação  MILK, no eixo “Corpos de Pedra e Água”, lê estes rituais
como ecologia vernacular: pedagogias de sustentação hídrica que a comunidade converteu em
gesto devocional.
⸻
3. Toponímia e variantes locais
Os narradores de Alvadia referem microtopónimos como “A Fraga da Senhora”, “Fonte da Voz”
e “Penedo da Marca” (onde “a marca do manto” seria visível nos anos de muito musgo). Embora
a toponímia administrativa registe sobretudo capelas formais (Remédios, Santa Luzia) e cruzeiros,
a cartografia oral conserva a rede de marcos devocionais na pedra — prática coerente com a
paisagem religiosa do concelho.
Variantes regionais próximas, recolhidas por Mauer e cotejadas com repertórios do Noroeste:
	 •	 “Moura da Fraga d’Água”  (Alvadia, versão de Lamas): moura penteando a
rocha; água brota no risco do pente.
	 •	 “Senhora do Véu da Pedra” (Ribeira de Pena, via narradores de Cerva e
Canedo): véu luminoso que “desce” após ladainha.
	 •	 Paralelos no concelho (tipológicos): santa que “marca a pedra” em
Penalonga, exemplo claro de impressão  hagiográ fica na rocha.


No plano mais amplo ibérico, o motivo da entidade feminina que abre água  na rocha
encontra sustentação em tipologias de mouras encantadas ligadas a fragas, túneis e
teares de ouro — uma semântica de “abrir/tecer” aplicada à pedra e ao subsolo.
⸻
4. Primeiro relato e fontes académicas primárias
Rigor académico e estado da arte: não se localizou, até ao momento, registo impresso
canónico sob a designação exata “Senhora da Fraga de Alvadia” nas grandes coletâneas
oitocentistas/novecentistas (Braga, Vasconcelos) ou em repertórios regionais disponíveis on-line.
As evidências documentais acessíveis para Alvadia apontam:
	 •	 Presença e continuidade de património religioso paroquial (capelas,
cruzeiros, alminhas) e uma malha devocional ativa, conforme documentação da Junta de
Freguesia de Alvadia.
	 •	 No concelho, lenda de figura sagrada que imprime o corpo na rocha
(Santa Ana em Penalonga), que fornece paralelo tipológico local para sacralização da
fraga.
Primeira fixação  documental consolidada desta variante (Alvadia):
	 •	 Dossiê MILK – Folclore Vivo (Ribeira de Pena/Alvadia): Senhora da
Fraga: pedra, voz e água  na Serra de Alvadia (recolhas de Eduardo Mauer, 2023–2025: 33
depoimentos orais geo-referenciados, caderno de campo, transcrições e fotografias de
marcas na rocha; acervo interno MILK 2025).
Fontes primárias/analíticas  de contexto (não  específicas de Alvadia, mas relevantes para o
motivo):
	 •	 Amália  Marques, Mouras, Mouros e Mourinhos Encantados em Lendas do
Noroeste Peninsular (UAb, 2013) – anexos tipológicos: fragas, túneis, teares de ouro
como matrizes do encantamento.
	 •	 Repositórios locais e paroquiais de Ribeira de Pena; inventários turísticos/
culturais regionais (para toponímia e património religioso ativo).
Nota metodológica: Dada a inexistência, até agora, de referência impressa
inequívoca para “Senhora da Fraga de Alvadia”, esta entrada apresenta a
sistematização  crítica do material oral recolhido em 2023–2025, articulado com
fontes documentais de contexto e paralelos tipológicos comprovados no
mesmo concelho e no Noroeste peninsular.
⸻
5. Síntese interpretativa final
A Senhora da Fraga condensa o arquétipo da docilidade da matéria: a dureza que aprende a
ceder. A pedra não se opõe à vida; guarda-a e abre-a quando a palavra certa a convoca. O
milagre não está na suspensão das leis naturais, mas na alfabetização  afetiva do território:
saber bater, saber pedir, saber agradecer.
Na leitura simbólica da Associação  MILK, a lenda opera como gramática  de cuidado hídrico:
ensina modos de relação com água e rocha — pedir licença, tomar só o necessário, devolver à
fraga um fio (fitas, giestas). O gesto de “passar a criança entre pedra e água ” reconcilia o corpo
com a maternidade do lugar.
A proposta escultórica MILK de Eduardo Mauer (matriz padrão) modela um corpo compacto
que se abre por um risco vertical translúcido (a “fenda-fonte”). A superfície alterna textura
pétrea e velatura aquosa; no rasgo, um brilho discreto sugere água  que nasce.


Mauer anota: “Não é a fraga que dá água — é a relação  que a faz brotar.”
⸻
6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer
“A Senhora da Fraga é corpo não  binário  da matéria: nem duro nem líquido, nem
feminino nem mineral; entre pedra e água.”
A leitura não binária desloca o foco de identidades fixas para estados de
passagem. A fraga é membrana: acolhe o seco e o húmido, o fechado e o aberto.
Na prática de mediação cultural da Associação  MILK, isto traduz-se em oficinas
de ecologia sensível (“pedra que ouve, água que responde”), onde a comunidade
reencena os gestos tradicionais (três toques, palavra de licença, devolução
simbólica) como rituais de governança local da água .
⸻
7. Referência Estrutural da Matriz MILK
Matriz Escultórica – Série Folclore Vivo (Associação  MILK)
	 •	 Corpo: compacto, vertical, com fenda translúcida central (nascente).
	 •	 Cromia: ardósia mate (exterior) e azul-prata no interior da fenda (água).
	 •	 Materiais: resina mineralizada com pó de xisto; inserção de resina
translúcida perolada na “fenda-fonte”.
	 •	 Expressão:  serena; “rosto” sugerido por saliência mínima que toca a fenda
(gesto de encostar a testa).
	 •	 Base: laje irregular, com micro-canais que conduzem a luz (metáfora das
levadas).
	 •	 Eixo curatorial: Corpos de Pedra e Água  (docilidade da matéria, fontes
rituais, governança vernacular).
⸻
Localização  específica: Freguesia de Alvadia (lugares de Lamas e encostas da serra), concelho
de Ribeira de Pena (Vila Real).
Primeira fixação  documental desta variante: Senhora da Fraga: pedra, voz e água  na Serra de
Alvadia (Recolhas de Eduardo Mauer, 2023–2025; acervo MILK 2025).
Fontes de contexto e paralelos: Junta de Freguesia de Alvadia (património religioso ativo); lenda
de Santa Ana (Penalonga) como modelo local de impressão  do sagrado na rocha; estudos
tipológicos sobre mouras/frag as no Noroeste peninsular.
