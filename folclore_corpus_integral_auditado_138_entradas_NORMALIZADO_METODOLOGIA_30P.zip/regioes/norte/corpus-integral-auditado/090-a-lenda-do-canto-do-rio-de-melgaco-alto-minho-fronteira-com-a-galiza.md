# 090. A Lenda do Canto do Rio de Melgaço (Alto Minho – Fronteira com a Galiza)

**Base documental e empírica:** pesquisa documental, análise comparada de fontes públicas, sistematização de tradição oral, relatos orais de pesquisa de campo e revisão semântica conduzidas no âmbito do Folclore Vivo da Associação MILK - Movimento de Intervenções e Linguagens Kulturais e Arte.
**Estado editorial:** corpus de pesquisa de campo e documentação cultural em revisão pública.
**Regra de publicabilidade:** esta entrada não deve ser lida como prova histórica definitiva, inventário patrimonial oficial, validação etnográfica concluída ou certificação académica externa sem verificação documental própria.
**Regra jurídica/RGPD:** não publicar nomes de informantes, contactos, moradas, entrevistas integrais, imagens identificáveis, gravações, dados de menores, coordenadas sensíveis ou materiais comunitários sem autorização.
**Regra de não invenção:** a presente readequação corrige a camada editorial e metodológica sem acrescentar factos, fontes, topónimos, coordenadas ou relatos não existentes no corpus-base.
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

90. A Lenda do Canto do Rio de Melgaço (Alto Minho – Fronteira com a Galiza)
(Sistematização  contemporânea  conduzida por Eduardo Mauer no âmbito  das pesquisas sobre
Folclore Vivo da Associação  MILK – Movimento de Intervenções e Linguagens Kulturais e Arte,
com base em recolhas orais e documentais realizadas entre 2023 e 2025 em Melgaço, Fiães,
Chaviães  e Cristóval, cruzadas com fontes etnográ ficas do Museu de Melgaço, do Arquivo
Distrital de Viana do Castelo e de estudos contemporâneos  sobre mitologia aquática  e simbologia
sonora na cultura portuguesa.)
⸻
1. Descrição  simbólica e narrativa
A Lenda do Canto do Rio de Melgaço fala de um som que não pertence a nenhuma garganta
humana — um canto que nasce da água , ouvido apenas nas madrugadas de neblina junto ao
rio Minho, quando o vento sopra do norte e o mundo parece suspenso.
Conta o povo que, desde tempos imemoriais, o rio canta. Não é murmúrio nem corrente; é voz
verdadeira, suave e compassada, que fala de amores antigos e despedidas, ora como canção
de ninar, ora como lamento. Os que a escutam nunca esquecem. Diz-se que, após ouvi-lo, “o
coração ganha sede de silêncio”, como se a alma fosse tocada por um segredo que não se
explica.
Nas recolhas orais conduzidas por Eduardo Mauer (2024), o canto é descrito como voz
feminina, mas sem corpo: uma vibração pura, feita de ar e água. Os pescadores acreditam que é
o eco de uma moura encantada que vive sob as águas do Minho, prisioneira de amor. Outras
versões, mais recentes, afirmam que o canto é a própria respiração do rio — um som que ele
emite quando quer avisar o povo de enchentes ou desgraças.
Numa narrativa de Chaviães, recolhida junto a um antigo barqueiro, o mito ganha forma mais
concreta: “Houve um tempo em que uma mulher se afogou tentando salvar o filho levado pela
corrente. Desde então, o rio canta sempre que há lua nova, para lembrar que o amor nunca
morre.”
Noutras variantes, o canto é voz de reconciliação  entre Portugal e Galiza — duas margens que
se chamam pela música da água. Nessa leitura, o Canto do Rio seria o hino do território
partilhado, símbolo de fraternidade ancestral.


Mauer sintetiza: “O Canto do Rio é a língua do afeto entre as margens — o murmúrio em que o
território se reconhece e se perdoa.”
⸻
2. Contexto histórico e social
Melgaço, o município mais a norte de Portugal, sempre viveu em diálogo direto com o rio Minho.
Durante séculos, as suas gentes dependeram das travessias fluviais, da pesca, do contrabando e
das trocas com as aldeias galegas. O rio era fronteira e ponte, fonte de vida e risco, espaço
sagrado e perigoso.
As comunidades ribeirinhas criaram, em torno dele, uma relação quase espiritual. Desde o século
XVIII há relatos de benzeduras de água , cerimónias de purificação e vigílias noturnas nas
margens, onde o povo acendia lamparinas “para que o rio dormisse tranquilo”.
No século XIX, cronistas locais como o padre José de Fontoura registaram “estranhos sons
ouvidos ao amanhecer” e “vozes que vinham das águas”, interpretadas como sinais de
tempestades. Esses relatos mesclam observação  meteorológica e religiosidade popular,
originando o mito do canto como comunicação viva do rio com os humanos.
Durante o século XX, o mito persistiu como memória oral — as mães contavam às crianças que o
rio cantava para protegê-las. Já no século XXI, com o avanço das pesquisas da Associação
MILK, o Canto do Rio foi reinterpretado como símbolo da ecologia sonora: a ideia de que a
paisagem fala e que escutá-la é forma de cuidado ambiental.
⸻
3. Toponímia e variantes locais
O mito apresenta várias designações ao longo do curso do Minho:
– “Canto da Moura” (Fiães): voz feminina que emerge da água;
– “Rio que Canta” (Chaviães): fenómeno acústico natural com valor espiritual;
– “Canção  das Duas Margens” (Cristóval): símbolo de união entre povos;
– “Sopro do Minho” (Melgaço): ruído harmónico ouvido nas madrugadas.
O topónimo “Ponte do Canto”, entre Chaviães e Filgueira, remonta a 1721 e está ligado à crença
de que o som se ouvia sempre sob o arco central. Segundo o Arquivo Municipal de Melgaço,
há referências de peregrinos que “atravessavam a ponte para ouvir a voz do rio” como ato de fé.
O termo “canto”, em dialeto minhoto, tem dupla acepção: melodia e margem. Assim, o “Canto
do Rio” é tanto o som quanto o lugar — a fronteira física e espiritual entre mundos.
⸻
4. Primeiro relato e fontes académicas primárias
O primeiro registro literário da lenda surge em Leite de Vasconcelos, Etnografia Portuguesa, vol.
VII (1920, pp. 284–289)*, que documenta “som misterioso nas margens do Minho, interpretado
como canto de moura aquática”.
Teófilo Braga, O Povo Português  nos seus Costumes, Crenças e Tradições (1885, pp. 670–676)*,
menciona “rios que falam e respondem aos homens”, relacionando o Canto do Rio de Melgaço a
mitos mediterrânicos de águas sonoras e ninfas.
Alexandre Parafita, Mitologia Popular Portuguesa (2008, pp. 849–858)*, inclui o mito sob a
categoria de “vozes naturais do sagrado”, destacando o caráter fronteiriço da narrativa.


A sistematização contemporânea de Eduardo Mauer, O Canto do Rio de Melgaço: Som,
Fronteira e Afeto no Imaginário  Atlântico  Português  (Lisboa, Associação MILK, 2025)*, apresenta
pesquisa etnográ fica e fenomenológica que interpreta o canto como linguagem do território,
aproximando mitologia e ecologia acústica.
Fontes complementares:
– Museu de Melgaço, Coleção  de Relatos Orais do Alto Minho (1980–2010);
– Arquivo Distrital de Viana do Castelo, Cadernos de Tradições Fluviais (1875–1942);
– Tese de Doutoramento de Miguel Durão, Paisagens Sonoras e Mitologia Aquática  no Noroeste
Ibérico  (U. Porto, 2019).
⸻
5. Síntese interpretativa final
O Canto do Rio de Melgaço é o mito da escuta e da pertença. Ele ensina que o sagrado não
está nas alturas, mas na vibração  da terra e da água . O rio canta para que o ser humano se
lembre de ouvir — não com o ouvido físico, mas com o corpo inteiro.
Na leitura simbólica da Associação  MILK, o canto é a voz da matéria viva. Assim como o sal
conserva e a areia reflete, o som liga. O rio torna-se mediador entre o visível e o invisível, entre o
humano e o ambiente.
A escultura MILK concebida por Eduardo Mauer representa um corpo compacto e arredondado,
com cabeça grande e textura fluida, como se estivesse a ser moldado por ondas sonoras. No
centro do peito, há uma cavidade circular — o “ouvido do rio” — que emite vibrações leves
quando iluminada. A cor dominante é azul-esverdeada, com re flexos prateados, e o acabamento
fosco reproduz a umidade das margens.
Mauer escreve: “O rio canta porque respira. E nós só o ouvimos quando voltamos a respirar com
ele.”
⸻
6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer
Na leitura não binária de Eduardo Mauer, o Canto do Rio de Melgaço é o som do entre-lugar
— nem humano nem natural, mas comunhão.
“O canto é o corpo do meio, vibração onde o eu e o outro se tornam onda.”
Aqui, o som é identidade fluida: não se prende a gênero, forma ou fronteira. O Canto do
Rio representa o não  binário  sensorial, onde o existir se dá como frequência partilhada.
A Associação  MILK entende esta lenda como paradigma da estética da escuta —
princípio do Folclore Vivo que propõe o ouvir como ato político e poético. O mito é, assim,
reconfigurado como manifesto de empatia, em que o som substitui a palavra e o afeto
substitui a posse.
⸻
7. Referência Estrutural da Matriz MILK
Na Matriz Escultórica MILK – Série Folclore Vivo, o Canto do Rio de Melgaço é representado
através de formas suaves e acústicas:
– Corpo: compacto, cabeça grande, superfície ondulada;
– Cores: azul-água, verde-musgo e re flexos prateados;


– Materiais: resina translúcida, fibra acústica e iluminação interna vibrátil;
– Expressão:  serena, olhos semicerrados, boca entreaberta em gesto de emissão sonora;
– Base: curva, evocando as margens do rio.
A escultura materializa o conceito de paisagem que fala, integrando o som como elemento
escultórico — parte da investigação transdisciplinar conduzida por Mauer no âmbito do Folclore
Vivo.
⸻
Localização  específica: Melgaço, Fiães, Chaviães e Cristóval (distrito de Viana do Castelo).
Primeiro relato documentado: Vasconcelos, Etnografia Portuguesa, vol. VII, 1920.
Sistematização  contemporânea:  Eduardo Mauer, O Canto do Rio de Melgaço: Som, Fronteira e
Afeto no Imaginário  Atlântico  Português , Associação MILK, 2025.
Fontes primárias:  Braga (1885); Vasconcelos (1920); Parafita (2008); Durão (2019); Mauer (2025).
