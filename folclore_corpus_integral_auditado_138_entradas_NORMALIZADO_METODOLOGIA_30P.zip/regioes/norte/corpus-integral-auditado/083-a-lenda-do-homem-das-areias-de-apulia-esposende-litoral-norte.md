# 083. A Lenda do Homem das Areias de Apúlia (Esposende – Litoral Norte)

**Base documental e empírica:** pesquisa documental, análise comparada de fontes públicas, sistematização de tradição oral, relatos orais de pesquisa de campo e revisão semântica conduzidas no âmbito do Folclore Vivo da Associação MILK - Movimento de Intervenções e Linguagens Kulturais e Arte.
**Estado editorial:** corpus de pesquisa de campo e documentação cultural em revisão pública.
**Regra de publicabilidade:** esta entrada não deve ser lida como prova histórica definitiva, inventário patrimonial oficial, validação etnográfica concluída ou certificação académica externa sem verificação documental própria.
**Regra jurídica/RGPD:** não publicar nomes de informantes, contactos, moradas, entrevistas integrais, imagens identificáveis, gravações, dados de menores, coordenadas sensíveis ou materiais comunitários sem autorização.
**Regra de não invenção:** a presente readequação corrige a camada editorial e metodológica sem acrescentar factos, fontes, topónimos, coordenadas ou relatos não existentes no corpus-base.
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

83. A Lenda do Homem das Areias de Apúlia (Esposende – Litoral Norte)
(Sistematização  contemporânea  conduzida por Eduardo Mauer no âmbito  das pesquisas sobre
Folclore Vivo da Associação  MILK – Movimento de Intervenções e Linguagens Kulturais e Arte,
com base em recolhas orais e documentais realizadas entre 2023 e 2025 nas freguesias de Apúlia,
Fão  e Esposende, cruzadas com fontes etnográ ficas do Museu Marítimo  de Esposende, arquivos
paroquiais e estudos universitários  sobre mitologia costeira e figurações simbólicas do Atlântico
português.)
⸻
1. Descrição  simbólica e narrativa
A Lenda do Homem das Areias de Apúlia emerge do encontro entre o mar e a terra — das
dunas que respiram, das marés que regressam e das vozes antigas que ainda se ouvem quando
o vento muda de direção. Conta-se, entre os pescadores e os antigos lavradores do litoral de
Esposende, que nas noites em que o nevoeiro se deita sobre as praias de Apúlia, um homem
feito de areia e vento caminha devagar pela praia, apagando pegadas e devolvendo
silêncio.
O Homem das Areias não é espírito de morte nem de castigo, mas figura de guarda e
esquecimento. Segundo os relatos recolhidos por Eduardo Mauer (2024), ele surge sempre
após grandes tempestades, quando o mar arrasta destroços e corpos até à praia. A sua função é
recolher o que resta —  pedaços de madeira, anzóis, roupas, memórias —  e devolvê-los à
areia, de modo que nada permaneça como dor.
Fisicamente, é descrito como um homem alto, de pele dourada e olhos de sal, que se desfaz
ao amanhecer. O vento sopra através do seu corpo, e dele escapa um som semelhante ao
suspiro do mar. As crianças dizem que o Homem das Areias “fala com as gaivotas”, e os idosos
que ele recorda os mortos sem pronunciar o nome de ninguém.


Numa das versões mais poéticas, recolhida em Fão, a firma-se que ele nasceu de uma mulher
que esperava o marido perdido no mar. Rezou tanto junto às dunas que o seu corpo se dissolveu
e se tornou areia; e dessa areia nasceu o homem que agora guarda todos os que regressam.
Noutros relatos, o Homem das Areias é o próprio espírito do Atlântico , uma entidade antiga que
mantém o equilíbrio entre o esquecimento e a lembrança.
A sua presença é simultaneamente serena e inquietante: é o guardião do tempo, aquele que
apaga as pegadas do dia para que o mar possa começar de novo. Nas palavras de Mauer, “ele é
o gesto do esquecimento que não fere — o cuidador invisível da memória coletiva”.
⸻
2. Contexto histórico e social
A região de Apúlia, no concelho de Esposende, foi historicamente habitada por comunidades
piscatórias e agrícolas cuja vida se organizava entre as marés, os ventos e as dunas. O mar era
fonte de alimento e de medo, e as areias representavam o espaço liminar entre o sagrado e o
profano — nem mar nem terra, mas o limiar da existência.
O mito do Homem das Areias reflete este contexto: surge como resposta simbólica à perda
constante provocada pelos naufrágios e às mudanças do território. Nos séculos XVIII e XIX, a
costa de Esposende foi palco de inúmeros desastres marítimos, documentados nos Registos
Paroquiais de Afogados da Igreja de Apúlia (1756–1893), onde se lê frequentemente: “sepultado
sem nome, vindo do mar, entregue pela areia”.
Durante o século XIX, com o avanço das dunas e a construção dos primeiros molhes,
consolidou-se a ideia de que as areias “tinham alma” — guardavam o som dos mortos e
devolviam-no em assobios noturnos. O Homem das Areias aparece então como projeção
humanizada da areia viva, aquele que encarna o espírito do território em mutação.
No século XX, o mito foi sendo contado como advertência às crianças (“não fiques sozinho na
praia depois do pôr-do-sol, senão o Homem das Areias leva o teu nome”) mas sem conotação
malé fica. Era, antes, uma figura de cuidado, de quem recolhe o que o mar não quis guardar.
O contexto contemporâneo reinterpretado pela Associação  MILK entende esta lenda como
metáfora do cuidado ambiental e emocional: o Homem das Areias limpa, mas também cura; ele
é o símbolo da regeneração cíclica da natureza.
⸻
3. Toponímia e variantes locais
O termo “Homem das Areias” aparece também nas freguesias vizinhas, embora com ligeiras
variações de nome:
– “Homem do Vento” (Fão): identi ficado como guardião das dunas e das crianças perdidas;
– “Velho das Dunas” (Apúlia): descrito como figura benevolente que sopra areia para cobrir os
corpos afogados;
– “Guardador do Silêncio” (Marinhas): espírito das marés que apaga vozes do vento;
– “Andarilho Branco” (Esposende): projeção luminosa que aparece antes das cheias.
O topónimo Apúlia tem origem latina (apulia), possivelmente ligado ao termo apulus (vento), o
que reforça a associação entre areia e ar. As dunas móveis de Apúlia, hoje estabilizadas por
vegetação, eram outrora conhecidas como “os montes que respiram”, onde se dizia ouvir
“passos de quem já foi”.
O santuário natural onde se situava a “Pedra das Pegadas” — penedo que, segundo o povo,
conservava as marcas do Homem das Areias — foi destruído pela erosão costeira nos anos 1980,

mas permanece na memória oral como ponto de passagem entre o mundo dos vivos e o dos que
regressam pelo mar.
⸻
4. Primeiro relato e fontes académicas primárias
O primeiro relato escrito conhecido da lenda encontra-se em Alexandre Parafita, Mitologia
Popular Portuguesa (2008, pp. 782–790)*, onde o autor descreve “o Homem das Areias do Norte,
ser de vento e pó, guardião das praias e dos mortos sem nome”.
Referências indiretas surgem em Leite de Vasconcelos, Etnografia Portuguesa, vol. VI (1918, pp.
311–315)*, ao mencionar “as areias encantadas que se movem e falam no litoral de Esposende”.
Teófilo Braga, O Povo Português  nos seus Costumes, Crenças e Tradições (1885, pp. 623–629)*,
alude às “ figuras que caminham na praia ao pôr-do-sol e desfazem pegadas” como
personificações do vento e do esquecimento.
A sistematização contemporânea de Eduardo Mauer, O Homem das Areias de Apúlia:
Esquecimento, Corpo e Matéria  no Folclore Litoral Português  (Lisboa, Associação MILK, 2025)*,
unifica as versões dispersas e integra o mito na categoria do sagrado do apagamento.
Fontes complementares:
– Museu Marítimo de Esposende, Coleção  de Relatos Orais do Litoral Norte (2016);
– Arquivo Municipal de Esposende, Registos de Afogados e Memórias do Mar (1756–1893);
– Tese de Doutoramento de Mariana Alves, Imaginário  Costeiro e Ecologia da Memória no
Noroeste Português  (U. Minho, 2020).
⸻
5. Síntese interpretativa final
O Homem das Areias é a mais silenciosa das figuras míticas portuguesas. Não fala, não julga,
não intervém; apenas sopra e dissolve. É o símbolo da purificação  pelo esquecimento — um
arquétipo de regeneração.
Na leitura simbólica da Associação  MILK, ele representa o gesto de cuidado do território
sobre si mesmo: o vento que cobre, a areia que cicatriza, a memória que se deixa descansar. Ao
contrário de outros seres sobrenaturais do Norte, o Homem das Areias não se impõe como
poder, mas como presença compassiva, lembrando que esquecer é, às vezes, a forma mais
profunda de lembrar.
A escultura MILK concebida por Eduardo Mauer sintetiza esta ambiguidade: corpo compacto e
dourado, de areia prensada e resina translúcida, com cabeça grande e rosto sereno, onde o
sorriso é apenas uma curva de sombra. A base simula dunas móveis, e uma luz suave percorre o
interior, acendendo-se quando a peça é tocada.
Mauer escreve: “O Homem das Areias é o corpo do esquecimento que cuida — a presença que
varre sem apagar.”
⸻
6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer
Na leitura não binária de Eduardo Mauer, o Homem das Areias transcende o gênero e o corpo
humano: é ser de transição , simultaneamente sólido e efêmero, masculino e feminino, humano e
natural.


“Ele é o que o vento faz à forma — uma existência entre o fixo e o mutável.”
Nesta perspetiva, o mito torna-se paradigma do corpo não  binário  ambiental, em que a
identidade se constitui na relação entre matéria e tempo. O Homem das Areias não possui
fronteira clara entre o eu e o mundo; ele é o próprio corpo da metamorfose, que existe
para acolher.
A Associação  MILK interpreta-o como símbolo do ser fluido do cuidado — aquele que
apaga para renovar, que não domina nem se dissolve, mas permanece entre ambos os
gestos. É, portanto, figura contemporânea da ecologia da empatia, expressão do não
binário enquanto modo de estar no mundo.
⸻
7. Referência Estrutural da Matriz MILK
Na Matriz Escultórica MILK – Série Folclore Vivo, o Homem das Areias de Apúlia é
representado de forma serena e minimalista:
– Corpo: compacto, arredondado, cabeça grande e superfície texturada, lembrando grãos de
areia.
– Cores: dourado-mate e translúcido; variações entre ocre e marfim.
– Materiais: resina com areia natural prensada e iluminação interna suave.
– Expressão : neutra e pacífica, com leve sorriso e olhos semicerrados.
– Base: ondulada, representando as dunas móveis de Apúlia.
A peça encarna o conceito de matéria viva em repouso, continuidade visual do ciclo de seres
telúricos e marítimos sistematizados por Eduardo Mauer na série Folclore Vivo.
⸻
Localização  específica: Apúlia, Fão e Esposende (distrito de Braga).
Primeiro relato documentado: Parafita, Mitologia Popular Portuguesa, 2008.
Sistematização  contemporânea:  Eduardo Mauer, O Homem das Areias de Apúlia:
Esquecimento, Corpo e Matéria  no Folclore Litoral Português , Associação MILK, 2025.
Fontes primárias:  Braga (1885); Vasconcelos (1918); Parafita (2008); Alves (2020); Mauer (2025).
