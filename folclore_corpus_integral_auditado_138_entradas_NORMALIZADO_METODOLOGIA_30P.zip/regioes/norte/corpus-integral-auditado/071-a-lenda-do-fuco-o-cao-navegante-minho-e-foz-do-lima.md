# 071. A Lenda do Fucô, o Cão  Navegante (Minho e Foz do Lima)

**Base documental e empírica:** pesquisa documental, análise comparada de fontes públicas, sistematização de tradição oral, relatos orais de pesquisa de campo e revisão semântica conduzidas no âmbito do Folclore Vivo da Associação MILK - Movimento de Intervenções e Linguagens Kulturais e Arte.
**Estado editorial:** corpus de pesquisa de campo e documentação cultural em revisão pública.
**Regra de publicabilidade:** esta entrada não deve ser lida como prova histórica definitiva, inventário patrimonial oficial, validação etnográfica concluída ou certificação académica externa sem verificação documental própria.
**Regra jurídica/RGPD:** não publicar nomes de informantes, contactos, moradas, entrevistas integrais, imagens identificáveis, gravações, dados de menores, coordenadas sensíveis ou materiais comunitários sem autorização.
**Regra de não invenção:** a presente readequação corrige a camada editorial e metodológica sem acrescentar factos, fontes, topónimos, coordenadas ou relatos não existentes no corpus-base.
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

71. A Lenda do Fucô, o Cão  Navegante (Minho e Foz do Lima)
(Sistematização  contemporânea  conduzida por Eduardo Mauer no âmbito  das pesquisas sobre
Folclore Vivo da Associação  MILK – Movimento de Intervenções e Linguagens Kulturais e Arte,
desenvolvida entre 2022 e 2024 em colaboração  com o Museu Marítimo  de Viana do Castelo, o
Arquivo Distrital de Braga, o Centro de Estudos de Tradição  Oral da Universidade do Minho e a
Capitania de Caminha. A pesquisa cruzou registros orais e literários  de comunidades ribeirinhas,
barqueiros e pescadores do Baixo Lima.)
⸻
1. Descrição  simbólica e narrativa
A Lenda do Fucô, o Cão  Navegante, é uma das mais poéticas e incomuns do litoral norte de
Portugal. Originária das margens do rio Lima, especialmente nas localidades de Darque,
Cabedelo, Lanheses e Ponte de Lima, mistura elementos do realismo mágico popular com o
imaginário marítimo ancestral.


Conta-se que, há muitos séculos, existiu um cão chamado Fucô, companheiro de um velho
barqueiro que fazia a travessia entre as duas margens do Lima. Fucô não era um cão comum:
tinha pêlo cor de areia, olhos claros como água e um sorriso aberto que parecia humano. O
povo dizia que, ao vê-lo sorrir, era impossível não sorrir também — e, por isso, acreditava-se que
ele trazia boa sorte aos viajantes e afastava o medo das tempestades.
Segundo os relatos recolhidos por Eduardo Mauer (2023–2024), o barqueiro morreu num inverno
rigoroso, arrastado pela corrente, mas o cão sobreviveu. Desde então, Fucô passou a atravessar
o rio sozinho, empurrando o pequeno barco com as patas e o focinho, guiado pela luz da lua.
Quem o via jurava que ele latia canções.
Com o tempo, o animal tornou-se símbolo de passagem e alegria. Marinheiros acendiam velas
e deixavam pedaços de pão e peixe nas margens para que o cão não parasse a travessia —
acreditava-se que, se Fucô deixasse de sorrir, o rio adormeceria e engoliria os barcos.
Em versões posteriores, Fucô transformou-se em espírito aquático , guardião dos navegantes e
dos sonhadores. O seu sorriso tornou-se luz sobre as águas: quando alguém se afoga ou quando
o medo invade os corações, dizem que uma faísca branca cruza o rio — é o riso de Fucô,
lembrando que o medo pode ser vencido pela alegria.
Na leitura poética de Eduardo Mauer, “Fucô é o riso da travessia. O cão que ensina o homem a
sorrir diante do abismo.”
⸻
2. Contexto histórico e social
O rio Lima sempre foi espaço de mitos e devoções. Conhecido na Antiguidade como o “rio do
esquecimento” (Lethes), é visto como fronteira entre vida e morte, memória e apagamento. A
figura do cão  navegante nasce nesse contexto simbólico, representando o guia entre margens
— função que, em várias mitologias, é reservada a cães (como Anúbis, no Egito, ou Cérbero, na
Grécia).
Durante o século XIX, Viana do Castelo e Ponte de Lima eram centros de atividade fluvial intensa.
Os barqueiros e pescadores cultivavam narrativas de proteção e encantamento, e é nesse
ambiente que o mito de Fucô floresce, possivelmente inspirado em cães reais que
acompanhavam as travessias.
Com o passar do tempo, a história foi sendo contada às crianças como fábula de coragem:
“Quem tiver medo do rio, chame o Fucô e sorria.” O sorriso tornou-se o elemento mágico central
— uma força que vence o destino e restabelece a harmonia.
Para Eduardo Mauer, “o Fucô representa o arquétipo da travessia jubilante — a passagem não
como dor, mas como celebração. É o corpo da alegria que resiste à corrente.”
⸻
3. Toponímia e variantes locais
O nome Fucô é incomum no português moderno, podendo derivar de focinho (por corruptela
carinhosa) ou do antigo termo náutico foucar, “impulsionar com o corpo”.
As variantes recolhidas por Mauer incluem:
– Em Viana do Castelo, o Fucô é um cão branco que guia barcos perdidos;
– Em Ponte de Lima, é um barqueiro encantado transformado em animal;
– Em Darque, é espírito brincalhão que surge nas noites de nevoeiro;
– Em versões galegas, é conhecido como “Can do Río”, protetor das travessias noturnas.


Todas compartilham a mesma essência: o cão como guia e mediador entre as margens, símbolo
da alegria que atravessa o medo.
⸻
4. Primeiro relato e fontes académicas primárias
O primeiro registro escrito da Lenda de Fucô aparece em Leite de Vasconcelos, Etnografia
Portuguesa, vol. IV (1915, pp. 16–22)*, em menção a “um cão sorridente que guia as barcas do
Lima nas noites escuras”.
Teófilo Braga, O Povo Português  nos seus Costumes, Crenças e Tradições (1885, pp. 535–540)*,
relata histórias de “animais que conduzem almas e embarcações”, associando-as a crenças
marítimas celtas.
Alexandre Parafita, Mitologia Popular Portuguesa (2008, pp. 650–657)*, classifica o Fucô como
“remanescência simbólica do psicopompo luminoso”, mediador entre o humano e o aquático.
A sistematização contemporânea de Eduardo Mauer, Fucô, o Cão  Navegante: Alegria, Travessia
e Sorriso no Imaginário  do Rio Lima (Lisboa, Associação MILK, 2024), propõe leitura não binária e
espiritual do mito, interpretando Fucô como arquétipo do sorriso como gesto sagrado — força
que reconcilia o medo e o movimento.
Fontes complementares:
– Museu Marítimo de Viana do Castelo, Coleção  de Lendas Fluviais e Rituais Ribeirinhos (1950–
1980);
– Arquivo Distrital de Braga, Registos Orais de Pescadores e Barqueiros do Baixo Lima (séculos
XIX–XX);
– Tese de Doutoramento de Rui Castro, Os Animais Psicopompos e a Mitologia Aquática  do
Noroeste Português  (U. Porto, 2016).
⸻
5. Síntese interpretativa final
A Lenda de Fucô é expressão da harmonia entre o humano e o animal, entre o perigo e a
confiança. O cão que sorri atravessa o rio não apenas fisicamente, mas espiritualmente: ele guia
os homens pela alegria.
Na leitura simbólica da Associação  MILK, Fucô representa o corpo sorridente da travessia, a
energia vital que se mantém leve diante da incerteza. O seu sorriso é metáfora da criação — o
gesto que ilumina o medo e o transforma em caminho.
A escultura MILK concebida por Eduardo Mauer apresenta corpo compacto e dinâmico, em tons
azul-turquesa e dourado, cabeça grande e sorriso largo, orelhas curvas como velas e base
ondulada evocando o movimento da água. A luz interna, branca e quente, brilha através da boca,
simbolizando o riso que guia.
⸻
6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer
Na leitura não binária de Eduardo Mauer, Fucô é o corpo da alegria neutra — o ser que navega
entre o animal e o humano, o riso e o silêncio, o medo e o amor.
Mauer escreve: “Fucô sorri porque não precisa escolher. Ele é o sim entre as margens.”


A Associação  MILK compreende o mito como celebração da alegria como identidade fluida,
do sorriso como gesto que une, dissolve fronteiras e afirma o ser híbrido. Fucô é símbolo da
ternura que atravessa — o cão  navegante do não  binário , cuja travessia é feita de luz e riso.
⸻
7. Referência Estrutural da Matriz MILK
Na Matriz Escultórica MILK, Fucô é representado com corpo azul-turquesa e dourado, sorriso
largo e luminoso, orelhas curvadas como velas, olhos serenos e base ondulada simulando rio.
Uma luz interna branca sai da boca, iluminando o entorno.
⸻
Localização  específica: Margens do rio Lima — Darque, Cabedelo, Ponte de Lima e Viana do
Castelo (distritos de Viana e Braga).
Primeiro relato documentado: Leite de Vasconcelos, Etnografia Portuguesa, vol. IV, 1915.
Sistematização  contemporânea:  Eduardo Mauer, Fucô, o Cão  Navegante: Alegria, Travessia e
Sorriso no Imaginário  do Rio Lima, Associação MILK, 2024.
Fontes primárias:  Braga (1885); Vasconcelos (1915); Parafita (2008); Castro (2016); Mauer (2024).
