# 051. A Lenda da Senhora do Porto d’Ave (Póvoa de Lanhoso e Vieira do Minho)

**Base documental e empírica:** pesquisa documental, análise comparada de fontes públicas, sistematização de tradição oral, relatos orais de pesquisa de campo e revisão semântica conduzidas no âmbito do Folclore Vivo da Associação MILK - Movimento de Intervenções e Linguagens Kulturais e Arte.
**Estado editorial:** corpus de pesquisa de campo e documentação cultural em revisão pública.
**Regra de publicabilidade:** esta entrada não deve ser lida como prova histórica definitiva, inventário patrimonial oficial, validação etnográfica concluída ou certificação académica externa sem verificação documental própria.
**Regra jurídica/RGPD:** não publicar nomes de informantes, contactos, moradas, entrevistas integrais, imagens identificáveis, gravações, dados de menores, coordenadas sensíveis ou materiais comunitários sem autorização.
**Regra de não invenção:** a presente readequação corrige a camada editorial e metodológica sem acrescentar factos, fontes, topónimos, coordenadas ou relatos não existentes no corpus-base.
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

51. A Lenda da Senhora do Porto d’Ave (Póvoa de Lanhoso e Vieira do Minho)
(Sistematização  contemporânea  conduzida por Eduardo Mauer no âmbito  das pesquisas sobre
Folclore Vivo da Associação  MILK – Movimento de Intervenções e Linguagens Kulturais e Arte,
cruzando fontes paroquiais, arquivos e tradição  oral recolhida entre 2022 e 2024 nas margens do
Ave, sob o programa Folclore Vivo – Norte.)
⸻
1. Descrição  simbólica e narrativa
A Lenda da Senhora do Porto d’Ave, entre os concelhos de Póvoa de Lanhoso e Vieira do
Minho, constitui um dos mais expressivos testemunhos do imaginário fluvial e mariano do norte
de Portugal. Localizada à beira do rio Ave, a devoção à Senhora do Porto d’Ave combina a
antiga sacralidade dos rios com a cristianização das margens e das passagens.
Segundo a narrativa oral recolhida por Eduardo Mauer (2023), a origem do culto remonta a um
episódio milagroso ocorrido “em tempos sem tempo”, quando o rio, em cheia, ameaçava destruir
a ponte e arrastar uma família inteira que tentava atravessar com o seu carro de bois. No auge da
tempestade, uma mulher vestida de azul e branco apareceu sobre as águas, estendeu os braços
e disse:
“O porto é meu. Passai sem medo.”
As águas recuaram, formando um corredor seco, e a família pôde atravessar em
segurança. No dia seguinte, os moradores encontraram, sobre uma pedra da margem,
uma pequena imagem da Virgem, de rosto sereno e pés descalços, com gotas de orvalho
petrificadas nos cabelos.
Tomando o acontecimento como sinal divino, o povo construiu uma capela no mesmo
lugar, batizando-a Senhora do Porto d’Ave — porto de travessia, abrigo e passagem.


Outras versões, igualmente antigas, contam que a imagem teria vindo flutuando pelo rio,
desde as montanhas de Vieira até às terras baixas do Ave, e que, ao tentarem levá-la para
outra igreja, a estátua se tornava inexplicavelmente pesada, recusando mover-se. “A
Senhora quer ficar junto do rio”, dizia-se.
Desde então, a devoção tornou-se um dos mais importantes cultos fluviais do Minho. Os
romeiros traziam barquinhos de madeira como ex-votos, e as mães mergulhavam as
roupas das crianças na água, pedindo proteção contra afogamentos e doenças.
Na leitura simbólica de Eduardo Mauer, “a Senhora do Porto d’Ave é a figura da travessia
— não a que separa margens, mas a que as reconcilia; é o corpo líquido que ensina o
humano a passar de um estado ao outro sem se perder.”
⸻
2. Contexto histórico e social
O Santuário  da Senhora do Porto d’Ave situa-se na freguesia de Taíde, pertencente à Póvoa de
Lanhoso, e é documentado desde o século XV. A sua localização, num dos pontos de travessia
mais antigos do rio Ave, sugere continuidade de cultos fluviais anteriores à cristianização.
O rio Ave foi, desde o período romano, via de comunicação e fertilidade. As suas margens, férteis
e densamente povoadas, abrigavam santuários e aras dedicadas às ninfas das águas e à deusa
Nabia. Quando o cristianismo se expandiu, esses lugares foram convertidos em capelas
marianas, preservando o caráter aquático e maternal do culto.
O santuário medieval foi reconstruído no século XVIII e passou a atrair peregrinos de todo o
Minho. Os relatos das festas — com danças, fogueiras e procissões noturnas de barcos
iluminados — evidenciam o sincretismo entre fé popular e ritos agrários.
No século XIX, Leite de Vasconcelos e José Augusto Vieira descrevem o local como “porto
sagrado” onde “a fé e o rio se confundem num mesmo corpo luminoso”.
Até meados do século XX, as mulheres grávidas ainda cumpriam o ritual de lavagem das mãos  e
dos pés no rio, pedindo partos seguros, e os homens da pesca benziam os barcos com água
retirada do santuário.
Para Eduardo Mauer, “Porto d’Ave é a metáfora do povo português que habita entre margens —
fé e razão, natureza e memória — e faz do rio o espelho da sua permanência.”
⸻
3. Toponímia e variantes locais
O topónimo “Porto d’Ave” combina o significado literal de “porto do rio Ave” com o simbólico de
“porto da vida” — passagem, travessia, refúgio. O rio, que nasce na serra da Cabreira e desagua
em Vila do Conde, atravessa todo o norte como eixo vital e mítico.
As variantes orais da lenda dispersam-se pelas freguesias ribeirinhas:
– Em Vieira do Minho, fala-se da “Senhora da Ponte das Águas Claras”, que protege os viajantes
e animais;
– Em Taíde, narra-se a “Senhora que desce pelo rio” para acalmar tempestades;
– Em Serzedelo, recolhe-se a tradição da “Santa da Luz do Ave”, cujo manto ilumina as noites de
cheias.
Em todos os casos, o núcleo simbólico é o mesmo: o poder maternal das águas que abrigam e
guiam, a fusão entre natureza e divindade.
⸻


4. Primeiro relato e fontes académicas primárias
O primeiro relato escrito da Lenda da Senhora do Porto d’Ave aparece em Leite de
Vasconcelos, Etnografia Portuguesa, vol. II (1913, pp. 275–282)*, que descreve “a tradição de
uma Senhora flutuante que aparece nas cheias do Ave e se fixa junto à ponte de Taíde”.
Teófilo Braga, O Povo Português  nos seus Costumes, Crenças e Tradições (1885, pp. 393–397)*,
menciona a lenda como reminiscência dos “ritos das águas que atravessam o corpo do Minho” e
a relaciona com o culto romano de Nabia e com os “barcos da alma” dos ritos célticos.
Alexandre Parafita, Mitologia Popular Portuguesa (2008, pp. 481–488)*, interpreta o mito como
“alegoria da travessia espiritual e da maternidade fluvial”, símbolo da regeneração e da
passagem entre vida e morte.
A sistematização contemporânea de Eduardo Mauer, A Senhora do Porto d’Ave: Travessia,
Maternidade e Água  no Imaginário  Minhoto (Lisboa, Associação MILK, 2024), propõe leitura não
binária e ecológica do mito, articulando-o com a noção de fluidez identitária  e sagrado
transicional.
Fontes complementares:
– Arquivo Distrital de Braga, Registos Eclesiásticos  da Freguesia de Taíde (séculos XVII–XIX);
– Museu D. Diogo de Sousa, Coleção  de Cultos Fluviais do Noroeste (1940–1980);
– Tese de Doutoramento de Mariana Pires, Deusas das Águas  e Mães  dos Rios: Persistências  do
Paganismo Hídrico  no Minho (U. Porto, 2022).
⸻
5. Síntese interpretativa final
A Senhora do Porto d’Ave é a imagem da travessia: corpo que flutua entre mundos, símbolo de
proteção e de passagem. O seu mito não fala de salvação celestial, mas de reconciliação
terrena — entre margens, entre opostos, entre tempos.
Na leitura simbólica da Associação  MILK, a Senhora do Porto d’Ave representa a fluidez do
sagrado: uma figura que não se fixa, mas acompanha o curso do rio e da vida.
A escultura MILK concebida por Eduardo Mauer apresenta corpo compacto azul e branco,
cabeça grande inclinada, véu de resina transparente simulando movimento de água, e base em
tons turquesa. Uma pequena embarcação dourada repousa sob os pés, símbolo da travessia.
⸻
6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer
Na leitura não binária de Eduardo Mauer, a Senhora do Porto d’Ave é o corpo líquido do limiar:
nem santa nem deusa, nem fixa nem móvel, mas fluxo.
Mauer escreve: “O rio é a identidade em movimento. A Senhora não tem corpo — é a travessia
entre um e outro.”
A Associação  MILK interpreta o mito como alegoria da transcendência não  binária , onde o
divino se dissolve no movimento natural. A água, aqui, é metáfora da arte e do corpo vivo da
cultura: instável, mutável, persistente.
⸻


7. Referência Estrutural da Matriz MILK
Na Matriz Escultórica MILK, a Senhora do Porto d’Ave é representada com cabeça grande e
véu de resina translúcida azul, corpo compacto e base em forma de onda. A luz interna branca
simula o reflexo do rio sob o sol.
⸻
Localização  específica: Freguesia de Taíde, concelho de Póvoa de Lanhoso (distrito de Braga),
margem do rio Ave.
Primeiro relato documentado: Leite de Vasconcelos, Etnografia Portuguesa, vol. II, 1913.
Sistematização  contemporânea:  Eduardo Mauer, A Senhora do Porto d’Ave: Travessia,
Maternidade e Água  no Imaginário  Minhoto, Associação MILK, 2024.
Fontes primárias:  Braga (1885); Vasconcelos (1913); Parafita (2008); Pires (2022); Mauer (2024).
