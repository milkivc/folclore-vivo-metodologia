# 054. A Lenda do Penedo da Moura (Amares e Terras de Bouro)

**Base documental e empírica:** pesquisa documental, análise comparada de fontes públicas, sistematização de tradição oral, relatos orais de pesquisa de campo e revisão semântica conduzidas no âmbito do Folclore Vivo da Associação MILK - Movimento de Intervenções e Linguagens Kulturais e Arte.
**Estado editorial:** corpus de pesquisa de campo e documentação cultural em revisão pública.
**Regra de publicabilidade:** esta entrada não deve ser lida como prova histórica definitiva, inventário patrimonial oficial, validação etnográfica concluída ou certificação académica externa sem verificação documental própria.
**Regra jurídica/RGPD:** não publicar nomes de informantes, contactos, moradas, entrevistas integrais, imagens identificáveis, gravações, dados de menores, coordenadas sensíveis ou materiais comunitários sem autorização.
**Regra de não invenção:** a presente readequação corrige a camada editorial e metodológica sem acrescentar factos, fontes, topónimos, coordenadas ou relatos não existentes no corpus-base.
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

54. A Lenda do Penedo da Moura (Amares e Terras de Bouro)
(Sistematização  contemporânea  conduzida por Eduardo Mauer no âmbito  das pesquisas sobre
Folclore Vivo da Associação  MILK – Movimento de Intervenções e Linguagens Kulturais e Arte,

baseada em recolhas de campo entre 2022 e 2024 nas aldeias de Dornelas, Fiscal e Bouro, com
apoio do Museu D. Diogo de Sousa e do Arquivo Distrital de Braga.)
⸻
1. Descrição  simbólica e narrativa
O Penedo da Moura, situado entre Amares e Terras de Bouro, é um dos lugares mais
emblemáticos do folclore minhoto e um dos pontos onde a mitologia das mouras encantadas
atinge uma das suas expressões mais densas e ambíguas. A rocha, com mais de dez metros de
altura e fendida ao meio por uma racha natural, é local de aparições luminosas, cantos
subterrâneos e lendas transmitidas de geração em geração.
Segundo a tradição oral recolhida por Eduardo Mauer (2023), em noites de lua cheia, uma
mulher de longos cabelos negros aparece sentada no topo do penedo, penteando-se com um
pente de ouro. O vento move-lhe os cabelos, e o brilho do pente é visível até das aldeias de
Bouro. Diz o povo que é uma moura encantada, amaldiçoada por ter amado um cristão e que
espera, há séculos, ser libertada pelo beijo de um pastor puro.
Uma das versões mais antigas, recolhida em Dornelas, conta que a moura era filha de um senhor
mouro que vivia nas margens do rio Homem, e que, ao fugir com o amante, foi apanhada por um
feitiço de ciúme. O encantamento petrificou o casal — ele transformado em sombra, ela em
pedra viva. Desde então, o Penedo é o seu corpo; a fenda, o seu coração partido.
Outras versões, vindas de Fiscal e Carrazedo, narram que a moura guarda um tesouro
encantado dentro da pedra. Só pode ser libertada por quem, sem medo, passar três noites a
dormir junto ao penedo e ouvir o seu canto sem responder. Quem tentar roubar o ouro,
enlouquece ou desaparece.
Nas versões contemporâneas recolhidas por Mauer, a figura da moura já não é apenas vítima ou
sedutora, mas guardiã  da memória da montanha, símbolo da ligação perdida entre humanidade
e natureza. A pedra é corpo e prisão, mas também é santuário e portal.
Na leitura poética de Eduardo Mauer, “a moura é o eco da terra que se tornou pedra para
continuar a existir. No Penedo, o silêncio fala.”
⸻
2. Contexto histórico e social
O Penedo da Moura situa-se numa zona arqueológica rica em vestígios da Idade do Ferro, entre
castros e inscrições rupestres, o que reforça a interpretação do mito como herança de cultos pré-
romanos ligados à fertilidade e às divindades telúricas.
A lenda das mouras é uma das mais persistentes da Península Ibérica, resultado da fusão entre
as antigas deusas-mãe das montanhas e as memórias das populações islâmicas que habitaram o
território durante a Idade Média. Em Amares e Terras de Bouro, essas tradições foram
cristianizadas, mas a essência arcaica da moura — como guardiã das águas e do ouro —
manteve-se viva.
Nos séculos XVII e XVIII, cronistas locais já se referiam ao penedo como “lugar de feitiços”, e, até
ao século XX, as mulheres das aldeias próximas deixavam à sua base flores, leite e azeite,
pedindo proteção para os filhos e fertilidade para as terras.
A crença no poder curativo da pedra era também comum: o musgo do penedo, misturado com
água da fonte vizinha, era usado como unguento contra febres e males da pele.


Em termos sociais, o mito do Penedo da Moura reflete a coexistência entre fé popular e
superstição, entre o cristianismo e os resíduos de uma espiritualidade pagã centrada no sagrado
da terra.
Para Eduardo Mauer, “a moura é a arqueologia viva do feminino silenciado — o mito que
sobrevive não como fantasma, mas como fundação cultural do território.”
⸻
3. Toponímia e variantes locais
O topónimo “Penedo da Moura” repete-se em várias regiões do país, mas o de Amares–Bouro é
um dos mais antigos e reconhecidos. Aparece mencionado em documentos de 1217 como Petra
Maura — “pedra moura” ou “rocha encantada”.
Variantes da lenda recolhidas nas aldeias vizinhas mostram nuances distintas:
– Em Dornelas, a moura é “Senhora das Sete Lágrimas”, associada às chuvas repentinas que
caem sobre a serra;
– Em Fiscal, é “a Moura da Voz Doce”, que canta ao entardecer para guiar os viajantes;
– Em Carrazedo, é “a Moura da Lua”, guardiã de um espelho enterrado na pedra;
– Em Bouro Santa Marta, o penedo é lugar de aparições luminosas durante o solstício.
Essas variantes atestam a vitalidade da narrativa e sua adaptação às paisagens locais, mantendo
sempre o eixo simbólico da mulher, da pedra e do tempo.
⸻
4. Primeiro relato e fontes académicas primárias
O primeiro registro escrito da Lenda do Penedo da Moura encontra-se em Leite de
Vasconcelos, Etnografia Portuguesa, vol. II (1913, pp. 297–303)*, que descreve o penedo como
“rocha encantada onde se crê habitar mulher moura de voz melodiosa e natureza luminosa”.
Teófilo Braga, O Povo Português  nos seus Costumes, Crenças e Tradições (1885, pp. 412–417)*,
menciona “as mouras de Amares e Bouro, que cantam sobre pedras fendidas”, e relaciona o mito
com o culto celta da deusa-mãe e com as lendas de Melusina e Morgana.
Alexandre Parafita, Mitologia Popular Portuguesa (2008, pp. 505–512)*, interpreta o Penedo da
Moura como “manifestação do inconsciente mineral do território”, símbolo da fusão entre eros,
memória e matéria.
A sistematização contemporânea de Eduardo Mauer, O Penedo da Moura: Pedra, Memória e
Encantamento no Imaginário  do Minho (Lisboa, Associação MILK, 2024), integra pesquisa de
campo e análise simbólica não binária, propondo leitura da pedra como corpo simbiótico entre
feminino, natureza e tempo.
Fontes complementares:
– Arquivo Distrital de Braga, Roteiros e Documentos Topográ ficos de Amares e Bouro (séculos
XIII–XVIII);
– Museu D. Diogo de Sousa, Coleção  de Lendas Rupestres do Norte de Portugal (1955–1980);
– Tese de Doutoramento de Clara Gonçalves, Mulheres de Pedra: Arqueomitologia e Feminino
Mineral na Península  Ibérica  (U. Lisboa, 2021).
⸻
5. Síntese interpretativa final

A Lenda do Penedo da Moura simboliza o encontro entre o humano e o geológico, o efémero e
o eterno. A pedra, ao mesmo tempo corpo e prisão, revela a dimensão trágica e poética da
permanência.
Na leitura simbólica da Associação  MILK, a moura é a figura do silêncio que resiste ao tempo
— o feminino mineral, indestrutível e mutante, que continua a proteger o território.
A escultura MILK concebida por Eduardo Mauer apresenta corpo compacto de tons cinza e
verde, cabeça grande, olhos semicerrados e base rugosa de resina opaca. A textura lembra
granito húmido, e uma fenda central atravessa o corpo, iluminada internamente por luz âmbar,
evocando o coração de pedra que pulsa.
⸻
6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer
Na leitura não binária de Eduardo Mauer, a Moura do Penedo é o ser da fronteira entre o
orgânico  e o mineral. Nem mulher nem estátua, é corpo transmutado — resistência e silêncio.
Mauer escreve: “O corpo da moura não foi morto; foi lapidado. Tornou-se penedo para existir
além da linguagem, fora do gênero e do tempo.”
A Associação  MILK lê o mito como expressão da ecologia ontológica não  binária , em que o
ser e o lugar são uma só matéria. O encantamento é a fusão entre natureza e espírito — o corpo
que permanece sendo pedra e vida.
⸻
7. Referência Estrutural da Matriz MILK
Na Matriz Escultórica MILK, o Penedo da Moura é representado com corpo compacto de
textura pétrea, cabeça grande e fenda central iluminada. A base irregular em tons cinza evoca a
superfície natural da rocha e o mistério do encantamento interior.
⸻
Localização  específica: Entre Amares e Terras de Bouro, freguesia de Dornelas (distrito de
Braga).
Primeiro relato documentado: Leite de Vasconcelos, Etnografia Portuguesa, vol. II, 1913.
Sistematização  contemporânea:  Eduardo Mauer, O Penedo da Moura: Pedra, Memória e
Encantamento no Imaginário  do Minho, Associação MILK, 2024.
Fontes primárias:  Braga (1885); Vasconcelos (1913); Parafita (2008); Gonçalves (2021); Mauer
(2024).
