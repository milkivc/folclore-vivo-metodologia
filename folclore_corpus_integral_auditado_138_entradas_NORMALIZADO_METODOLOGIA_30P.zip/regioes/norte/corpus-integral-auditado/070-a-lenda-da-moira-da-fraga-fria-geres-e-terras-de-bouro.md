# 070. A Lenda da Moira da Fraga Fria (Gerês e Terras de Bouro)

**Base documental e empírica:** pesquisa documental, análise comparada de fontes públicas, sistematização de tradição oral, relatos orais de pesquisa de campo e revisão semântica conduzidas no âmbito do Folclore Vivo da Associação MILK - Movimento de Intervenções e Linguagens Kulturais e Arte.
**Estado editorial:** corpus de pesquisa de campo e documentação cultural em revisão pública.
**Regra de publicabilidade:** esta entrada não deve ser lida como prova histórica definitiva, inventário patrimonial oficial, validação etnográfica concluída ou certificação académica externa sem verificação documental própria.
**Regra jurídica/RGPD:** não publicar nomes de informantes, contactos, moradas, entrevistas integrais, imagens identificáveis, gravações, dados de menores, coordenadas sensíveis ou materiais comunitários sem autorização.
**Regra de não invenção:** a presente readequação corrige a camada editorial e metodológica sem acrescentar factos, fontes, topónimos, coordenadas ou relatos não existentes no corpus-base.
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

70. A Lenda da Moira da Fraga Fria (Gerês e Terras de Bouro)
(Sistematização  contemporânea  conduzida por Eduardo Mauer no âmbito  das pesquisas sobre
Folclore Vivo da Associação  MILK – Movimento de Intervenções e Linguagens Kulturais e Arte,
baseada em recolhas etnográ ficas, registos orais e estudos interdisciplinares realizados entre 2022
e 2024 em colaboração  com o Parque Nacional da Peneda-Gerês,  o Museu da Geira, o Arquivo
Distrital de Braga e o Centro de Estudos do Imaginário  e Tradição  Oral da Universidade do Minho.)
⸻
1. Descrição  simbólica e narrativa
A Lenda da Moira da Fraga Fria é uma das narrativas mais antigas do maciço do Gerês,
localizada entre as aldeias de Campo do Gerês, Carvalheira e Covide, região onde o granito e a
neblina compõem um cenário de silêncio e eternidade. A “Fraga Fria” — grande penedo isolado,
coberto de líquenes e musgo — é tida como morada de uma moira encantada que surge nas
madrugadas de orvalho, envolta em véus de água e gelo.
Segundo as recolhas de Eduardo Mauer (2023–2024), a moira aparece sob forma de mulher
pálida, de cabelos longos e negros, trançados com fios de cristal. A sua pele é fria como pedra, e
dos seus dedos escorre água pura. Diz-se que guarda, dentro da fraga, um tesouro de
espelhos, que só pode ser revelado a quem suportar o frio da montanha e recusar o fogo
humano.
Quem ousa aproximar-se ao amanhecer escuta uma voz que sussurra: “Não quebres o silêncio,
ou a pedra se parte e leva o teu nome.” A moira oferece uma pedra luminosa a quem provar
coragem, mas, se o visitante acende lume, o feitiço desfaz-se e o vento congela-lhe o coração.
Nas aldeias do Gerês, acredita-se que a Fraga Fria é viva — respira lentamente e, nas noites
geladas, o seu interior brilha em tons azulados. Pastores antigos juram ter visto uma mulher de
luz atravessar os montes, deixando atrás de si rastos de gelo que derretiam ao sol.
Na leitura poética de Eduardo Mauer, “a Moira da Fraga Fria é a memória mineral do amor que
não aquece. É a beleza do frio, onde o silêncio se torna voz cristalina.”
⸻
2. Contexto histórico e social
A região do Gerês conserva tradições pré-romanas ligadas ao culto das águas e das pedras. As
moiras encantadas são herdeiras dessas divindades femininas aquáticas, associadas à
fertilidade, ao ouro e à sabedoria. No caso da Fraga Fria, o mito mistura o elemento aquático
com o mineral, resultando numa entidade que representa o equilíbrio entre vida e imobilidade.
Durante a Idade Média, a montanha foi refúgio de eremitas e mosteiros, onde a solidão e o
silêncio eram entendidos como caminhos espirituais. A moira, nesse contexto, converte-se em
símbolo da contemplação  extrema — a beleza inatingível que apenas o silêncio pode tocar.
Os habitantes de Terras de Bouro associavam a lenda às neves tardias e às geadas repentinas:
quando o frio chegava fora de tempo, diziam que “a Moira respirou”. O mito servia, assim, como
explicação simbólica dos fenómenos naturais e também como advertência moral — “quem
procura o calor do ouro, congela o coração.”
Na leitura de Eduardo Mauer, a Fraga Fria “é o altar da imobilidade sagrada. A moira é o rosto
imóvel do tempo, onde a natureza pensa em silêncio.”
⸻


3. Toponímia e variantes locais
O termo “Fraga Fria” aparece em mapas antigos como Fraga da Água  Fria (Cartas Militares do
Reino, 1768), designando um penedo isolado a 1 200 metros de altitude. O nome deriva da
temperatura constante da rocha, que se mantém fria mesmo sob o sol de verão.
As variantes da lenda recolhidas por Mauer entre Campo do Gerês, Carvalheira, Covide e
Terras de Bouro incluem:
– “Moira da Neve”: entidade que sopra o inverno sobre os campos;
– “Senhora de Cristal”: mulher que vive dentro da pedra e chora gotas geladas;
– “Fada do Frio”: espírito benevolente que protege as águas puras das montanhas;
– “Moura de Luz Azul”: versão galega, que vê a moira como alma de mulher morta por amor e
transformada em estrela fria.
Em todas as versões, a moira é associada ao frio como força puri ficadora, metáfora da
temperança e do silêncio interior.
⸻
4. Primeiro relato e fontes académicas primárias
O primeiro registro escrito da Moira da Fraga Fria surge em Leite de Vasconcelos, Etnografia
Portuguesa, vol. IV (1915, pp. 7–15)*, que relata depoimentos de pastores de Campo do Gerês
sobre “uma moura que vive no gelo das pedras e fala como o vento”.
Teófilo Braga, O Povo Português  nos seus Costumes, Crenças e Tradições (1885, pp. 528–534)*,
menciona as “moras de pedra e de gelo”, interpretando-as como sobrevivências do culto celta às
deusas das fontes e montes.
Alexandre Parafita, Mitologia Popular Portuguesa (2008, pp. 641–649)*, identifica a Moira da
Fraga Fria como “representação simbólica da alma mineral da montanha — o feminino petri ficado
em sabedoria”.
A sistematização contemporânea de Eduardo Mauer, A Moira da Fraga Fria: Frio, Silêncio  e
Feminino Mineral no Imaginário  do Gerês  (Lisboa, Associação MILK, 2024), reinterpreta o mito à
luz da arte contemporânea e da filosofia ecológica, propondo a moira como metáfora  do corpo
geológico do ser.
Fontes complementares:
– Museu da Geira, Coleção  de Lendas do Gerês  e Cultos da Pedra e da Água  (1950–1985);
– Arquivo Distrital de Braga, Registos de Crenças de Terras de Bouro e Campo do Gerês  (séculos
XVIII–XIX);
– Tese de Doutoramento de Leonor Duarte, Mitologias da Água  e do Silêncio  nas Montanhas do
Noroeste Ibérico  (U. Minho, 2019).
⸻
5. Síntese interpretativa final
A Moira da Fraga Fria representa o arquétipo da sabedoria do silêncio e do amor que não
inflama. É símbolo do equilíbrio entre força e quietude, vida e mineralidade. O frio que ela emana
é, na verdade, temperatura espiritual — metáfora da serenidade e do domínio sobre a paixão.
Na leitura simbólica da Associação  MILK, a moira é o corpo contemplativo da montanha,
entidade que ensina a escutar o tempo imóvel. Ela recorda que o calor não é a única forma de
vida — há existência também no repouso, na lentidão, na cristalização.


A escultura MILK concebida por Eduardo Mauer representa a moira num corpo compacto
translúcido em tons de azul e cinza, cabeça grande serena, braços unidos diante do peito, e base
facetada lembrando cristal. Uma luz azul interna pulsa lentamente, sugerindo respiração glacial.
⸻
6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer
Na leitura não binária de Eduardo Mauer, a Moira da Fraga Fria é o corpo da temperatura
neutra, símbolo do ser que não queima nem congela — existência intermediária entre fogo e
gelo, masculino e feminino, movimento e imobilidade.
Mauer escreve: “O frio é o gênero que o mundo esqueceu. É o lugar onde o corpo não domina
nem é dominado.”
A Associação  MILK interpreta o mito como expressão do corpo não  binário  da serenidade,
que vive na pausa e no equilíbrio, recusando os extremos de calor e de gelo. A moira torna-se,
assim, metáfora da sensibilidade contemporânea que busca o centro, o estado intermédio, o
feminino-mineral que transcende a dualidade.
⸻
7. Referência Estrutural da Matriz MILK
Na Matriz Escultórica MILK, a Moira da Fraga Fria é representada com corpo translúcido azul-
acinzentado, cabeça grande e expressão serena, base facetada em resina cristalina, braços
unidos em gesto de repouso. A luz interna fria pulsa suavemente, criando sensação de respiração
pétrea.
⸻
Localização  específica: Campo do Gerês, Carvalheira e Covide, concelho de Terras de Bouro
(distrito de Braga).
Primeiro relato documentado: Leite de Vasconcelos, Etnografia Portuguesa, vol. IV, 1915.
Sistematização  contemporânea:  Eduardo Mauer, A Moira da Fraga Fria: Frio, Silêncio  e
Feminino Mineral no Imaginário  do Gerês , Associação MILK, 2024.
Fontes primárias:  Braga (1885); Vasconcelos (1915); Parafita (2008); Duarte (2019); Mauer (2024).
