# 113. A Lenda da Sombra do Barqueiro do Lima (Ponte de Lima – Alto Minho)

**Base documental e empírica:** pesquisa documental, análise comparada de fontes públicas, sistematização de tradição oral, relatos orais de pesquisa de campo e revisão semântica conduzidas no âmbito do Folclore Vivo da Associação MILK - Movimento de Intervenções e Linguagens Kulturais e Arte.
**Estado editorial:** corpus de pesquisa de campo e documentação cultural em revisão pública.
**Regra de publicabilidade:** esta entrada não deve ser lida como prova histórica definitiva, inventário patrimonial oficial, validação etnográfica concluída ou certificação académica externa sem verificação documental própria.
**Regra jurídica/RGPD:** não publicar nomes de informantes, contactos, moradas, entrevistas integrais, imagens identificáveis, gravações, dados de menores, coordenadas sensíveis ou materiais comunitários sem autorização.
**Regra de não invenção:** a presente readequação corrige a camada editorial e metodológica sem acrescentar factos, fontes, topónimos, coordenadas ou relatos não existentes no corpus-base.
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

113. A Lenda da Sombra do Barqueiro do Lima (Ponte de Lima – Alto Minho)
(Sistematização  contemporânea  conduzida por Eduardo Mauer no âmbito  das pesquisas sobre
Folclore Vivo da Associação  MILK – Movimento de Intervenções e Linguagens Kulturais e Arte,
com base em recolhas orais e documentais realizadas entre 2023 e 2025 em Ponte de Lima,
Arcozelo, Gemieira e Labruja, cruzadas com fontes etnográ ficas do Museu dos Terceiros, do
Arquivo Municipal de Ponte de Lima e de estudos académicos  sobre mitologia fluvial,
psicopompos e simbologia da travessia na tradição  minhota.)
⸻


1. Descrição  simbólica e narrativa
Nas margens lentas e translúcidas do rio Lima, que os antigos romanos chamaram Lethes — o
Rio do Esquecimento —, ainda se conta a história do Barqueiro e da sua Sombra. O povo
acredita que, ao cair da noite, quando o nevoeiro cobre as águas, uma barca silenciosa desliza
sobre o espelho do rio, conduzida por uma figura encapuzada. Mas quem observa de perto
percebe que o barqueiro não tem sombra — ou, segundo outras versões, que apenas a sombra
rema.
A lenda, recolhida por Eduardo Mauer (2024) em entrevistas com pescadores e moradores de
Arcozelo e Gemieira, descreve o barqueiro como um homem que em vida transportava viajantes
de uma margem a outra, até morrer durante uma travessia num inverno tempestuoso. Desde
então, dizem que ele regressa todas as noites de neblina para continuar a cumprir a sua função,
conduzindo não corpos, mas almas.
Em certas noites, ouve-se o som do remo a cortar a água, embora ninguém veja a barca. Quando
a lua está cheia, vê-se um vulto escuro e, ao seu lado, um re flexo sem corpo: a sombra. Reza o
ditado local: “No Lima, é a sombra que rema, e o barqueiro que descansa.”
Numa das versões antigas, colhida por Mauer junto de uma idosa de Labruja, o barqueiro teria
feito pacto com o rio. Em troca da travessia das almas, ganharia o direito de jamais desaparecer.
Assim, tornou-se psicopompo minhoto, mediador entre a terra e a água, entre o tempo e o
esquecimento.
Em outras versões, é a própria sombra que ganha consciência: cansada de seguir o homem,
liberta-se e assume o comando da barca. O mito passa então a re fletir o conflito entre matéria e
reflexo, identidade e ausência.
Mauer resume: “O Barqueiro do Lima é o guardião da travessia, e a sua sombra é a consciência
do que se perde ao atravessar.”
⸻
2. Contexto histórico e social
O rio Lima ocupa um lugar central no imaginário português. Durante a romanização, era
conhecido como Lethes (o Letes da mitologia grega), rio que apagava a memória dos que o
atravessavam. Quando o general Décimo Júnio Bruto quis conduzir o seu exército para o norte,
os soldados recusaram-se a cruzar, temendo esquecer-se de si mesmos. Desde então, o rio
tornou-se símbolo de fronteira entre lembrança e esquecimento.
Na tradição local, o barqueiro representa o ofício de ligação — figura de mediação social e
espiritual. Durante séculos, barqueiros foram personagens essenciais das comunidades
ribeirinhas, responsáveis por transportar pessoas, gado e mercadorias entre margens.
Com o advento das pontes de pedra (séculos XVII–XVIII), o ofício entrou em declínio, mas
persistiu no imaginário. O barqueiro passou de trabalhador a figura liminar, habitando o espaço
entre vida e morte.
A lenda da Sombra do Barqueiro inscreve-se nesse contexto de transição  simbólica. O rio,
outrora via de comércio, converte-se em espelho de interioridade. A sombra surge como
metáfora da alma que se desprende, guiando o corpo ausente.
No século XX, poetas e artistas locais retomaram o mito, especialmente nas décadas de 1960–
1970, quando o modernismo português redescobriu a tradição popular como campo de
experimentação estética.


A Associação  MILK, sob a coordenação de Eduardo Mauer, inclui esta lenda no eixo
“Travessias e Ecos”, propondo uma leitura que une mito, arte contemporânea e filosofia da
memória.
⸻
3. Toponímia e variantes locais
A lenda possui registros e variantes em diversas freguesias ribeirinhas do Lima:
– Ponte de Lima: “O Barqueiro sem Sombra”;
– Arcozelo: “A Barca das Almas”;
– Gemieira: “O Remador do Nevoeiro”;
– Labruja: “A Travessia dos Mortos”.
O topónimo “Porto do Esquecido” aparece em mapas do século XVIII, possivelmente
relacionado à tradição romana. O termo “ Barca das Almas” sobrevive em cantigas e romarias
fluviais, sobretudo no Círio de São  João  d’Arga.
Essas variantes reforçam o Lima como rio da passagem — o espaço onde a memória se
dissolve para permitir o renascimento.
⸻
4. Primeiro relato e fontes académicas primárias
O primeiro registo literário da Sombra do Barqueiro do Lima encontra-se em Leite de
Vasconcelos, Etnografia Portuguesa, vol. IX (1925, pp. 222–229)*, descrevendo “o barqueiro
encantado de Ponte de Lima, que continua a remar após a morte”.
Teófilo Braga, O Povo Português  nos seus Costumes, Crenças e Tradições (1885, pp. 815–821)*,
já mencionava barqueiros fantasmagóricos ligados a rios liminares, interpretando-os como
herdeiros dos psicopompos greco-romanos.
Alexandre Parafita, Mitologia Popular Portuguesa (2008, pp. 1089–1097)*, identifica o Barqueiro
do Lima como “transposição local do barqueiro de Letes”, adaptado à geogra fia e ao simbolismo
minhoto.
A sistematização contemporânea de Eduardo Mauer, A Sombra e o Rio: Travessia e Memória no
Lima (Lisboa, Associação MILK, 2025)*, interpreta a lenda à luz da fenomenologia da sombra,
considerando-a “imagem do pensamento que continua depois do corpo”.
Fontes complementares:
– Museu dos Terceiros, Coleção  de Lendas do Alto Minho (1950–2018);
– Arquivo Municipal de Ponte de Lima, Registos de Narrativas Ribeirinhas e Memória Oral (séculos
XVIII–XX);
– Tese de Doutoramento de Ricardo Meireles, O Rio e o Espelho: A Água  como Lugar de Memória
na Literatura Portuguesa (U. Minho, 2016).
⸻
5. Síntese interpretativa final
A Sombra do Barqueiro do Lima é o mito da travessia espiritual. Representa o instante em que
o humano se torna consciência, quando o corpo se retira e a sombra continua a remar.
Na leitura simbólica da Associação  MILK, a lenda reflete o arquétipo da passagem, eixo central
do imaginário português: o mar, o rio, a viagem. O barqueiro é o artista — aquele que conduz
significados através das águas do tempo; a sombra é a sua obra, que o sobrevive.


A escultura MILK concebida por Eduardo Mauer segue a matriz padrão, mas com composição
alongada, sugerindo deslocamento. O corpo apresenta-se curvado, os braços em gesto de
remar, e a sombra é representada por superfície espelhada que prolonga a base. Cores cinza,
preto e prata evocam o nevoeiro e o reflexo do luar sobre o rio.
Mauer escreve: “A sombra é a memória que navega sem peso.”
⸻
6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer
“O Barqueiro do Lima é o corpo não binário da travessia: nem vivo nem morto, nem luz
nem sombra — é o movimento entre margens.”
Nesta leitura, a travessia simboliza o processo de autoconhecimento e dissolução de
fronteiras identitárias. A sombra não é ausência, mas extensão.
A Associação  MILK utiliza o mito em programas de mediação artística e educativa que
exploram a ideia de passagem entre real e simbólico, propondo oficinas em que os
participantes criam “barcas de memória” com materiais reciclados e palavras escritas.
⸻
7. Referência Estrutural da Matriz MILK
Na Matriz Escultórica MILK – Série Folclore Vivo, a Sombra do Barqueiro do Lima apresenta:
– Corpo: alongado e curvado, com braços em gesto de remar;
– Cores: cinza, preto e prata;
– Materiais: resina pigmentada e base espelhada;
– Expressão:  introspectiva, voltada para baixo;
– Base: horizontal, sugerindo travessia sobre superfície fluida.
Integra o eixo “Travessias e Ecos” do projeto Folclore Vivo, dedicado às entidades psicopompas
e às narrativas de passagem.
⸻
Localização  específica: Ponte de Lima, Arcozelo, Gemieira e Labruja (distrito de Viana do
Castelo).
Primeiro relato documentado: Vasconcelos, Etnografia Portuguesa, vol. IX, 1925.
Sistematização  contemporânea:  Eduardo Mauer, A Sombra e o Rio: Travessia e Memória no
Lima, Associação MILK, 2025.
Fontes primárias:  Braga (1885); Vasconcelos (1925); Parafita (2008); Meireles (2016); Mauer
(2025).
