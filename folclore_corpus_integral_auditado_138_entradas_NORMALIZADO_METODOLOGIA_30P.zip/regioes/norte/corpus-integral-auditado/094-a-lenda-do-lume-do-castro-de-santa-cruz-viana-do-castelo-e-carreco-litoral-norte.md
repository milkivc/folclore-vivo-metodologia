# 094. A Lenda do Lume do Castro de Santa Cruz (Viana do Castelo e Carreço – Litoral Norte)

**Base documental e empírica:** pesquisa documental, análise comparada de fontes públicas, sistematização de tradição oral, relatos orais de pesquisa de campo e revisão semântica conduzidas no âmbito do Folclore Vivo da Associação MILK - Movimento de Intervenções e Linguagens Kulturais e Arte.
**Estado editorial:** corpus de pesquisa de campo e documentação cultural em revisão pública.
**Regra de publicabilidade:** esta entrada não deve ser lida como prova histórica definitiva, inventário patrimonial oficial, validação etnográfica concluída ou certificação académica externa sem verificação documental própria.
**Regra jurídica/RGPD:** não publicar nomes de informantes, contactos, moradas, entrevistas integrais, imagens identificáveis, gravações, dados de menores, coordenadas sensíveis ou materiais comunitários sem autorização.
**Regra de não invenção:** a presente readequação corrige a camada editorial e metodológica sem acrescentar factos, fontes, topónimos, coordenadas ou relatos não existentes no corpus-base.
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

94. A Lenda do Lume do Castro de Santa Cruz (Viana do Castelo e Carreço – Litoral Norte)
(Sistematização  contemporânea  conduzida por Eduardo Mauer no âmbito  das pesquisas sobre
Folclore Vivo da Associação  MILK – Movimento de Intervenções e Linguagens Kulturais e Arte,
com base em recolhas orais e documentais realizadas entre 2023 e 2025 nas freguesias de
Carreço, Areosa e Santa Marta de Portuzelo, cruzadas com fontes etnográ ficas do Museu de
Viana do Castelo, do Arquivo Distrital de Braga e de estudos sobre mitologia ígnea,  arqueologia
castreja e religiosidade popular atlântica.)
⸻
1. Descrição  simbólica e narrativa
A Lenda do Lume do Castro de Santa Cruz é uma das mais luminosas e persistentes narrativas
do litoral norte português. Conta-se que, nas noites mais escuras, quando a maré baixa e o vento
vem do mar, surge no alto do monte de Santa Cruz um pequeno fogo azul e silencioso,
conhecido pelo povo como o lume do Castro.
Dizem os antigos que esse fogo aparece para revelar o lugar de um tesouro, enterrado nas
ruínas do antigo castro pré-romano que coroa o monte, mas também para avisar os navegantes
de que o mar se aproxima em fúria. O lume brilha e desaparece sem deixar rastro — nem fumo,
nem cheiro, apenas um brilho suspenso entre a terra e o ar.


As recolhas orais de Eduardo Mauer (2024) descrevem o lume como chama viva de cor azul-
esverdeada, que “não aquece, mas ilumina”. Segundo os moradores de Carreço, o lume surge
sempre em silêncio, movendo-se como se respirasse. Há quem diga que é a alma dos antigos
guerreiros do castro, vigiando as suas muralhas, e quem jure tratar-se da moura encantada de
Santa Cruz, que acende o lume para proteger o monte e o mar.
Uma das versões mais poéticas, recolhida junto a um pescador de Areosa, narra que o lume é o
último pensamento do sol antes de dormir. Quando o sol se põe, deixa no monte uma
centelha que o vento do mar conserva até o dia seguinte — um pacto entre o fogo e o oceano.
Mauer descreve o fenómeno como “o mais puro símbolo da consciência luminosa: fogo que
pensa, luz que escuta”.
⸻
2. Contexto histórico e social
O Castro de Santa Cruz, situado em Carreço, é um dos sítios arqueológicos mais antigos de
Viana do Castelo, com ocupação datada do século VIII a.C. até ao período romano. As
escavações revelaram vestígios de habitações circulares, cerâmicas e objetos metálicos, muitos
deles com marcas de fogo ritual.
Na Antiguidade, o fogo tinha valor sagrado: elemento purificador, mediador entre os mundos. Os
habitantes do castro praticavam cultos solares e ritos de transição associados à chama,
acendendo fogueiras nos equinócios e solstícios. Com a romanização, esses rituais foram
assimilados pelas festas cristãs, e o monte passou a ser identi ficado como Monte de Santa
Cruz, símbolo de iluminação espiritual.
Durante a Idade Média, o lume passou a ser visto como sinal divino ou diabólico, conforme o
olhar de cada época. Registos de 1598 referem “fogos ardendo sem se consumir” e “clarões de
luz sobre o monte”, interpretados ora como milagre, ora como presença infernal.
Nos séculos XVIII e XIX, o monte tornou-se ponto de peregrinação. As mulheres de Viana subiam
ao alto nas noites de São João para “ver o lume do destino” — acreditava-se que, quem
avistasse o clarão, casaria antes do ano findar.
Com o tempo, o lume passou a ser metáfora  do espírito da cidade, símbolo da persistência e
da luz interior dos vianenses. No século XXI, a Associação  MILK recuperou o mito como
narrativa ecológica e artística, integrando-o no eixo “Luzes Atlânticas ” do projeto Folclore Vivo.
⸻
3. Toponímia e variantes locais
O nome “Lume do Castro” é comum em Carreço e Areosa, mas a lenda possui variantes:
– “Lume da Moura” (Santa Marta de Portuzelo): chama que protege tesouro subterrâneo;
– “Fogo dos Antigos” (Areosa): luz que marca o local das ruínas sagradas;
– “Luz de Santa Cruz” (Viana do Castelo): interpretação cristianizada da aparição;
– “Olho do Mar” (Montedor): clarão que se acende nas noites de tempestade.
O topónimo “Santa Cruz” aparece pela primeira vez em documentos do século XII, em latim,
como Monte Sanctae Crucis, e já associado à presença de luzes misteriosas. O próprio farol de
Montedor, construído em 1910, herdou o simbolismo do lume, funcionando como “fogo
civilizado” que prolonga a tradição mítica da claridade noturna.
⸻
4. Primeiro relato e fontes académicas primárias

O primeiro relato escrito do Lume do Castro de Santa Cruz surge em Leite de Vasconcelos,
Etnografia Portuguesa, vol. VII (1920, pp. 311–317)*, onde se refere a “luz azulada que arde sobre
o monte de Carreço, reputada pelo povo como fogo sagrado e aviso dos mares”.
Teófilo Braga, O Povo Português  nos seus Costumes, Crenças e Tradições (1885, pp. 697–702)*,
menciona “os fogos das serras do Minho” e interpreta-os como resquício dos antigos cultos ao
deus Lugh, divindade celta da luz.
Alexandre Parafita, Mitologia Popular Portuguesa (2008, pp. 886–893)*, classifica o lume como
manifestação da “energia telúrica luminosa”, típica das lendas atlânticas que unem fogo, vento e
memória.
A sistematização contemporânea de Eduardo Mauer, O Lume do Castro de Santa Cruz: Luz,
Memória e Mar no Imaginário  Atlântico  Português  (Lisboa, Associação MILK, 2025)*, propõe
leitura simbólica em que o lume é compreendido como consciência ecológica luminosa,
expressão material do diálogo entre território e imaginação.
Fontes complementares:
– Museu de Viana do Castelo, Coleção  de Lendas e Tradições de Luz (1970–2018);
– Arquivo Distrital de Braga, Cadernos de Tradição  Atlântica  (1890–1955);
– Tese de Doutoramento de Ricardo Lourenço, Fogo e Mar na Mitologia Atlântica  Portuguesa (U.
Porto, 2020).
⸻
5. Síntese interpretativa final
O Lume do Castro de Santa Cruz representa a presença luminosa do pensamento natural, o
fogo que não destrói, mas revela. É o símbolo da continuidade entre passado e futuro — uma
chama que acende a memória.
Na leitura simbólica da Associação  MILK, o lume é a voz do território: não um milagre, mas a
forma como o mundo comunica a sua própria vitalidade. Ele expressa a fusão entre
conhecimento ancestral e sensibilidade ecológica.
A escultura MILK concebida por Eduardo Mauer apresenta corpo compacto, cabeça grande e
superfície translúcida em tons azul e âmbar. No centro do peito, um núcleo luminoso pulsa
lentamente, representando o lume que respira. A base, de formato irregular, evoca o perfil do
monte. A luz interna é programada para acender e apagar suavemente, simulando o ritmo de um
coração.
Mauer escreve: “O lume é o pensamento da terra ao cair da noite. Quando o sol se apaga, a
montanha pensa em voz baixa.”
⸻
6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer
Na leitura não binária de Eduardo Mauer, o Lume do Castro é energia em transição : fogo e
água, matéria e sopro, luz que pertence a tudo e a nada.
“O lume é corpo de fronteira — nem chama nem sombra, mas relação.”
O fogo, tradicionalmente associado ao masculino, e o mar, ao feminino, encontram aqui
equilíbrio simbiótico, dissolvendo o binarismo dos elementos. A chama azul, fria e
translúcida, é o próprio emblema do não  binário  luminoso: arde sem consumir, ilumina
sem possuir.


A Associação  MILK lê o mito como manifesta ecológica da harmonia energética,
propondo-o como símbolo da convivência entre contrários. O lume torna-se, assim, figura
pedagógica da coexistência e do cuidado, inspirando práticas artísticas que transformam
a luz em ética da presença.
⸻
7. Referência Estrutural da Matriz MILK
Na Matriz Escultórica MILK – Série Folclore Vivo, o Lume do Castro de Santa Cruz
apresenta:
– Corpo: compacto, cabeça grande e tronco ligeiramente arqueado;
– Cores: azul translúcido, âmbar e re flexos verdes;
– Materiais: resina com fibra ótica, pó de quartzo e luz interna programável;
– Expressão:  serena, com olhos semicerrados e sorriso subtil;
– Base: irregular, evocando o monte e o mar.
A escultura integra o eixo “Luzes Atlânticas ” do projeto Folclore Vivo, representando a união
entre território, mito e consciência luminosa.
⸻
Localização  específica: Carreço, Areosa e Santa Marta de Portuzelo (distrito de Viana do
Castelo).
Primeiro relato documentado: Vasconcelos, Etnografia Portuguesa, vol. VII, 1920.
Sistematização  contemporânea:  Eduardo Mauer, O Lume do Castro de Santa Cruz: Luz,
Memória e Mar no Imaginário  Atlântico  Português , Associação MILK, 2025.
Fontes primárias:  Braga (1885); Vasconcelos (1920); Parafita (2008); Lourenço (2020); Mauer
(2025).
