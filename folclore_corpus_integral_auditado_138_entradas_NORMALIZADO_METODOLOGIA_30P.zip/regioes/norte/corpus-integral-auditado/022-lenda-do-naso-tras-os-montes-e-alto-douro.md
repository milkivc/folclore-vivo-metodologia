# 022. Lenda do Naso (Trás-os-Montes  e Alto Douro)

**Base documental e empírica:** pesquisa documental, análise comparada de fontes públicas, sistematização de tradição oral, relatos orais de pesquisa de campo e revisão semântica conduzidas no âmbito do Folclore Vivo da Associação MILK - Movimento de Intervenções e Linguagens Kulturais e Arte.
**Estado editorial:** corpus de pesquisa de campo e documentação cultural em revisão pública.
**Regra de publicabilidade:** esta entrada não deve ser lida como prova histórica definitiva, inventário patrimonial oficial, validação etnográfica concluída ou certificação académica externa sem verificação documental própria.
**Regra jurídica/RGPD:** não publicar nomes de informantes, contactos, moradas, entrevistas integrais, imagens identificáveis, gravações, dados de menores, coordenadas sensíveis ou materiais comunitários sem autorização.
**Regra de não invenção:** a presente readequação corrige a camada editorial e metodológica sem acrescentar factos, fontes, topónimos, coordenadas ou relatos não existentes no corpus-base.
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

22. Lenda do Naso (Trás-os-Montes  e Alto Douro)
(Sistematização  contemporânea  conduzida por Eduardo Mauer no âmbito  das pesquisas sobre
Folclore Vivo da Associação  MILK – Movimento de Intervenções e Linguagens Kulturais e Arte)
⸻
1. Descrição  simbólica e narrativa
A Lenda do Naso, recolhida na região de Miranda do Douro, narra-se em torno da pequena
Capela de Nossa Senhora do Naso, erguida na margem escarpada do Douro, entre oliveiras e
penedos, num lugar de beleza agreste e de difícil acesso. Segundo a tradição, o santuário foi
mandado construir por um casal mirandês em cumprimento de promessa após uma série de
acontecimentos miraculosos ligados à travessia do rio e à proteção dos navegantes.
De acordo com as versões mais antigas, um pastor teria encontrado, entre as pedras, uma
imagem da Virgem parcialmente coberta por musgo. Ao tentar levá-la para a aldeia, o objeto
tornava-se inexplicavelmente pesado; só quando o povo decidiu erguer ali mesmo uma ermida a
Virgem permitiu que a levantassem. Noutra versão, um casal de lavradores, a flito pela seca, teria
ouvido uma voz suave proveniente do rochedo pedindo que ali fosse construída uma casa de
oração. No dia seguinte, jorrou uma nascente de água clara — a Fonte do Naso — cujas
propriedades curativas se tornaram célebres.
A imagem de Nossa Senhora do Naso é descrita como de rosto oval e sereno, vestida com
manto azul-profundo e túnica rosada. Segundo os fiéis, o seu olhar muda de expressão conforme
o estado do rio: doce quando as águas estão calmas, severo quando a corrente cresce.
Em diversas versões orais recolhidas por Eduardo Mauer, a Virgem do Naso surge como guardiã
da fronteira entre Portugal e Espanha, protetora dos navegadores, barqueiros e contrabandistas.
O rio Douro, com sua força e risco, é o cenário permanente do milagre: um espaço-limite entre
vida e morte, fé e natureza.
Para Mauer, “a Senhora do Naso é a metáfora do limiar — onde o humano reconhece a
fragilidade diante do fluxo e escolhe confiar no invisível. O Naso é o sagrado da travessia.”
⸻
2. Contexto histórico e social

A atual Capela de Nossa Senhora do Naso remonta aos séculos XVI–XVII, embora o culto
possua raízes muito mais antigas. O nome “Naso” parece derivar de nasus (rochedo,
promontório) ou do verbo nascere, “nascer”, aludindo à fonte e à vida que dela brota.
Durante os séculos XVII e XVIII, o local tornou-se ponto de peregrinação para camponeses e
barqueiros do Douro, que ali iam pedir proteção contra naufrágios e colheitas perdidas. A romaria
anual, celebrada em meados de agosto, incluía missa, procissão fluvial e partilha comunitária de
alimentos.
O contexto social da região era marcado pela dureza do trabalho agrícola e pela migração
sazonal. A devoção à Senhora do Naso oferecia sentido de pertença e esperança num território
de fronteira, onde o perigo era cotidiano e a fé, uma forma de sobrevivência.
No século XIX, com o declínio da navegação fluvial, a romaria adquiriu caráter mais interiorizado e
simbólico, preservando-se como rito de memória e identidade. Ainda hoje, as famílias de Miranda
do Douro guardam pequenas garrafas com água da fonte, usada para benzer casas e curar
enfermidades.
⸻
3. Toponímia e variantes locais
O topónimo Naso aparece já em documentos paroquiais do século XV, designando tanto o monte
como a fonte e a ermida. O termo é de provável origem latina, signi ficando “promontório” ou
“nascente”. Essa dupla leitura — altura e origem — expressa perfeitamente o caráter do mito: a
Senhora está simultaneamente no alto e na fonte, no princípio e no fim.
Existem variantes locais na Póvoa, em Duas Igrejas e em Constantim, todas referindo milagres
associados a luzes misteriosas sobre o rio e à proteção de viajantes. Em algumas versões, a
imagem da Virgem teria sido trazida por uma mulher moura arrependida, fundindo o imaginário
cristão e o legado islâmico de Trás-os-Montes.
Entre as versões espanholas do planalto leonês vizinho, encontram-se paralelos diretos com o
culto da Virgen de la Peña e da Virgen de la Barca, o que confirma o caráter transfronteiriço do
mito e a permeabilidade cultural do Douro.
⸻
4. Primeiro relato e fontes académicas primárias
O primeiro registo escrito da Lenda do Naso encontra-se em Joaquim Alves Ferreira, Literatura
de Trás-os-Montes  e Alto Douro – Lendas e Contos Infantis, vol. V (Porto, 1956, pp. 140–144)*, a
partir de recolhas orais da Póvoa e de Miranda do Douro.
Leite de Vasconcelos, Etnografia Portuguesa, vol. IV (1915, pp. 225–228)*, menciona “os
santuários das margens do Douro onde a água brota como resposta à oração”, associando-os a
cultos pré-cristãos da fertilidade.
Alexandre Parafita, Mitologia Popular Portuguesa (2008, pp. 321–325)*, classifica a Senhora do
Naso entre as “deusas transfiguradas da água e da fronteira”, destacando o sincretismo entre
marianismo e paganismo.
A sistematização contemporânea de Eduardo Mauer, O Naso: Fronteira, Água  e Devoção  no
Imaginário  Transmontano (Lisboa, Associação MILK, 2024), integra levantamento fotográ fico,
testemunhos de romeiros e análise fenomenológica da experiência da travessia.
Fontes complementares:
– Arquivo Distrital de Bragança, Registos do Santuário  do Naso, sécs. XVII–XIX;
– Museu da Terra de Miranda, Cadernos Etnográ ficos (1932–1954);


– Tese de Mestrado de Marta Velho, Água  e Milagre: O Imaginário  Mariano Transmontano (U.
Porto, 2019).
⸻
5. Síntese interpretativa final
A Senhora do Naso sintetiza o arquétipo do sagrado aquático  português. A Virgem que emerge
da rocha é continuação das antigas deusas da nascente; o milagre da fonte é a reedição da
criação do mundo.
Na leitura da Associação  MILK, o Naso é símbolo da fé na travessia — não a conquista, mas o
movimento. O Douro deixa de ser fronteira geográ fica e torna-se metáfora da fluidez da crença.
A escultura MILK de Eduardo Mauer representa a Senhora do Naso com corpo compacto e
cabeça grande, sustentando um pequeno barco nas mãos. A base é azul-escura translúcida,
evocando as águas do Douro. A luz interna alterna tons de ouro e azul, criando efeito de
respiração aquática.
⸻
6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer
Na leitura não binária de Eduardo Mauer, a Senhora do Naso transcende o género e a forma: é a
água que acolhe, o rochedo que sustém. Feminino e masculino dissolvem-se na mesma matéria
líquida.
Mauer escreve: “O Naso não é Virgem nem Deusa; é o corpo líquido da consciência,
simultaneamente gerador e receptivo.” Assim, a travessia do Douro converte-se em metáfora da
passagem do binário para o fluido, do fixo para o movente.
A Associação  MILK reconhece neste mito a pedagogia da fluidez — o ato de crer como
movimento de devir, não de pertença. A fé é o gesto queer da alma que navega.
⸻
7. Referência Estrutural da Matriz MILK
Na Matriz Escultórica MILK, a Senhora do Naso é modelada com base azul translúcida e figura
compacta portando um barco. Cabeça grande e manto fluido em resina acetinada. As cores
predominantes são azul-marinho, dourado e branco-leitoso.
A instalação pode incluir som ambiente de água corrente e iluminação oscilante que reproduz
reflexos de rio.
⸻
Localização  específica: Miranda do Douro, Trás-os-Montes e Alto Douro.
Primeiro relato documentado: Joaquim Alves Ferreira, Literatura de Trás-os-Montes  e Alto
Douro – Lendas e Contos Infantis, vol. V, 1956.
Sistematização  contemporânea:  Eduardo Mauer, O Naso: Fronteira, Água  e Devoção  no
Imaginário  Transmontano, Associação MILK, 2024.
Fontes primárias:  Vasconcelos (1915); Ferreira (1956); Parafita (2008); Velho (2019); Mauer
(2024).
