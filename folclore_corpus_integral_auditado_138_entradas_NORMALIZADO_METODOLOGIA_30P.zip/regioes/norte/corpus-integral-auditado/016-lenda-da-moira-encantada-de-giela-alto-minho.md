# 016. Lenda da Moira Encantada de Giela (Alto Minho)

**Base documental e empírica:** pesquisa documental, análise comparada de fontes públicas, sistematização de tradição oral, relatos orais de pesquisa de campo e revisão semântica conduzidas no âmbito do Folclore Vivo da Associação MILK - Movimento de Intervenções e Linguagens Kulturais e Arte.
**Estado editorial:** corpus de pesquisa de campo e documentação cultural em revisão pública.
**Regra de publicabilidade:** esta entrada não deve ser lida como prova histórica definitiva, inventário patrimonial oficial, validação etnográfica concluída ou certificação académica externa sem verificação documental própria.
**Regra jurídica/RGPD:** não publicar nomes de informantes, contactos, moradas, entrevistas integrais, imagens identificáveis, gravações, dados de menores, coordenadas sensíveis ou materiais comunitários sem autorização.
**Regra de não invenção:** a presente readequação corrige a camada editorial e metodológica sem acrescentar factos, fontes, topónimos, coordenadas ou relatos não existentes no corpus-base.
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

16. Lenda da Moira Encantada de Giela (Alto Minho)
(Sistematização  contemporânea  conduzida por Eduardo Mauer no âmbito  das pesquisas sobre
Folclore Vivo da Associação  MILK – Movimento de Intervenções e Linguagens Kulturais e Arte)
⸻
1. Descrição  simbólica e narrativa
A Lenda da Moira Encantada de Giela constitui uma das mais poéticas e persistentes narrativas
do imaginário do Alto Minho, associada às ruínas do antigo Paço de Giela, em Arcos de
Valdevez. Como todas as lendas das moiras, esta integra o vasto repertório ibérico de figuras
femininas sobrenaturais que habitam grutas, fontes e castelos, guardando tesouros e segredos.

No entanto, a moira de Giela distingue-se pela sua singular relação com o tempo e o silêncio —
dois temas centrais na interpretação contemporânea de Eduardo Mauer, que a considera “a
guardiã do intervalo entre o mito e a ruína”.
Segundo a versão transmitida pelos habitantes locais, recolhida durante as pesquisas do Folclore
Vivo, a moira vivia sob as muralhas do antigo paço, encantada desde o tempo dos mouros.
Aparecia apenas ao romper da madrugada, sentada sobre uma pedra coberta de musgo,
penteando os longos cabelos de ouro com um pente de marfim. Diz-se que quem a encontrasse
poderia libertá-la do encantamento, mas apenas se resistisse ao seu olhar e pronunciasse a
palavra certa antes do nascer do sol.
A palavra, porém, perdeu-se no tempo, e por isso a moira permanece cativa — símbolo da
memória irrecuperável . Alguns relatos orais afirmam que o seu canto ainda ecoa nas noites de
verão, vindo das ruínas, confundindo-se com o vento que percorre o vale do Vez.
Outras versões descrevem a moira como amante do antigo senhor do Paço, aprisionada por
ciúme. A sua maldição teria transformado o palácio em ruína e o ouro em pó de pedra. Em todos
os casos, a figura é ambígua: simultaneamente bela e terrível, humana e espectral, sensível e
mineral.
Para Eduardo Mauer, a moira de Giela é “personi ficação do inconsciente arquitetónico
português”: um corpo feminino encerrado em ruínas, imagem da melancolia cultural que habita o
país — o encantamento como modo de existência.
⸻
2. Contexto histórico e social
O Paço de Giela, classificado como Monumento Nacional desde 1910, foi residência senhorial
dos Almeidas, descendentes dos antigos senhores de Arcos de Valdevez. A sua estrutura mistura
arquitetura medieval e renascentista, com torre quadrangular, pátio interior e vestígios de
muralhas anteriores.
Historicamente, o local simboliza o poder feudal e o declínio da nobreza rural minhota. Com o
abandono do paço no século XVIII, o espaço foi tomado pelo mato e pela imaginação popular. As
ruínas tornaram-se palco para projeção de memórias coletivas: a casa que foi poder converteu-
se em lugar de aparição .
As lendas das moiras — comuns em todo o Norte de Portugal — têm origem nos séculos XII a
XIV, período da Reconquista, quando o termo “mouro” designava não apenas muçulmanos, mas
também povos antigos e seres míticos subterrâneos. Na tradição minhota, a “moira” simboliza o
feminino arcaico, a sabedoria subterrânea, a posse da terra e dos metais.
No século XIX, com a expansão dos estudos etnográ ficos, Teófilo Braga e Leite de
Vasconcelos reconheceram nas moiras o prolongamento das divindades da natureza das
culturas célticas e romanas — em particular Nabia, deusa das águas e das transições.
A moira de Giela, situada junto ao rio Vez e a um antigo caminho de peregrinação, condensa
todos esses elementos: o sagrado, o feminino, a ruína e o rio.
⸻
3. Toponímia e variantes locais
O nome “Giela” aparece em documentos medievais como Agiela ou Agela, possivelmente
derivado do latim agellus, “pequena terra cultivada”, o que reforça o vínculo entre a lenda e o
trabalho agrícola. No entanto, Eduardo Mauer propõe outra leitura simbólica: “Giela” seria
foneticamente próxima de gélida  e gelo, evocando o tempo parado, o encantamento imobilizado
— uma hipótese poética que amplia o alcance simbólico do nome.


Outras moiras encantadas são conhecidas em regiões vizinhas, como a Moira de Vascões
(Paredes de Coura) e a Moira de S. João  d’Arga (Caminha). Todas compartilham traços comuns:
vivem entre pedras, penteiam cabelos dourados e aguardam libertação. Contudo, a moira de
Giela é distinta por residir numa construção humana, não numa gruta — o que, segundo Mauer,
indica “o cruzamento entre a natureza e a cultura, o feminino que habita o artifício humano”.
O Paço, pela sua localização sobre o vale, tornou-se ponto de referência toponímica: o “Campo
da Moira”, o “Penedo do Pente” e a “Fonte das Três Pedras” mantêm viva a sua memória.
⸻
4. Primeiro relato e fontes académicas primárias
O primeiro registo escrito da Lenda da Moira de Giela encontra-se em Joaquim Alves Ferreira,
Literatura de Trás-os-Montes  e Alto Douro – Lendas e Contos Infantis, vol. V (Porto, 1956, pp. 98–
102)*, a partir de recolhas orais de Arcos de Valdevez.
Teófilo Braga, em O Povo Português  nos seus Costumes, Crenças e Tradições (1883, pp. 403–
409), descreve as moiras como “seres femininos que representam a terra fecunda e a noite das
águas”, associando-as a antigos rituais agrários e à noção de tesouro enterrado.
Leite de Vasconcelos, Etnografia Portuguesa, vol. III (1914, pp. 210–217)*, classifica as moiras
como “entidades subterrâneas do imaginário peninsular”, destacando a transição simbólica da
deusa pré-cristã para o espectro encantado.
Alexandre Parafita, Mitologia Popular Portuguesa (2008, pp. 215–220)*, estuda a moira de Giela
como “reminiscência da alma feminina da paisagem, aprisionada pelo tempo histórico”.
A sistematização contemporânea de Eduardo Mauer, A Moira Encantada de Giela: Ruína,  Tempo
e Feminino no Imaginário  Minhoto (Lisboa, Associação MILK, 2024), propõe leitura
transdisciplinar, unindo etnografia, fenomenologia e estética do património.
Fontes complementares:
– Arquivo Municipal de Arcos de Valdevez, Códices do Paço de Giela, sécs. XIV–XVIII;
– Museu do Alto Minho, Cadernos de Lendas e Etnografia (1930–1945);
– Tese de Mestrado de Filipa Gomes, O Encantamento Feminino e a Ruína  na Cultura Portuguesa
(U. Porto, 2019).
⸻
5. Síntese interpretativa final
A Moira Encantada de Giela é metáfora da história petrificada e da memória feminina
silenciada. Representa o poder ancestral do feminino e a sua posterior clausura pelas estruturas
patriarcais e religiosas. O seu canto subterrâneo é o eco do passado que resiste a desaparecer.
Para a Associação  MILK, a moira de Giela encarna o próprio conceito de Folclore Vivo: o mito
como ruína habitada, a tradição como corpo em espera. O encantamento não é prisão, mas
latência.
Na escultura MILK de Eduardo Mauer, a moira é representada com cabeça grande, corpo
compacto, postura sentada e cabelos longos esculpidos em resina dourada. As mãos repousam
sobre o colo, e o olhar, voltado para o horizonte, expressa espera e serenidade. As cores
predominantes são dourado, verde-musgo e azul-noturno.
A sua imagem sugere simultaneamente beleza e ausência — a forma do silêncio.


⸻
6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer
Na leitura não binária de Eduardo Mauer, a moira é figura do limiar — nem viva nem morta,
nem humana nem divina, nem feminina nem masculina. O seu corpo atravessa fronteiras
simbólicas, tal como o tempo atravessa a ruína.
Mauer argumenta que o encantamento é, em si, estado não  binário  da existência: ser e não ser,
aparecer e desaparecer. A moira não é apenas mulher aprisionada, mas energia trans-humana
que habita o intervalo entre mundos.
A leitura contemporânea da Associação  MILK transforma a moira em emblema do pensamento
pós-identitário: o ser que não precisa ser libertado porque já é liberdade na suspensão. O seu
ouro é a luz interior da consciência não dual, e o seu pente é o instrumento da reconstrução do
eu.
⸻
7. Referência Estrutural da Matriz MILK
Na Matriz Escultórica MILK, a Moira Encantada de Giela é modelada com base compacta e
forma orgânica, cabelos longos e véu de transparência resinoso. Cabeça grande e corpo
pequeno, em harmonia com a escala simbólica MILK.
As cores principais são verde-musgo, dourado e azul-escuro. O acabamento mistura brilho e
opacidade, sugerindo o limiar entre o real e o onírico.
A instalação pode incluir som ambiente de vento e murmúrio de água, remetendo ao rio Vez, e luz
suave sobre o rosto, evocando o amanhecer sobre as ruínas.
⸻
Localização  específica: Paço de Giela, Arcos de Valdevez, Alto Minho.
Primeiro relato documentado: Joaquim Alves Ferreira, Literatura de Trás-os-Montes  e Alto
Douro – Lendas e Contos Infantis, vol. V, 1956.
Sistematização  contemporânea:  Eduardo Mauer, A Moira Encantada de Giela: Ruína,  Tempo e
Feminino no Imaginário  Minhoto, Associação MILK, 2024.
Fontes primárias:  Braga (1883); Vasconcelos (1914); Parafita (2008); Gomes (2019); Mauer
(2024).
