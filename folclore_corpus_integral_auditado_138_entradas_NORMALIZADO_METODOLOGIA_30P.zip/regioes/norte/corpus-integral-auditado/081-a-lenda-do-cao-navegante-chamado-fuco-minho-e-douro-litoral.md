# 081. A Lenda do Cão  Navegante  chamado Fucô (Minho e Douro Litoral)

**Base documental e empírica:** pesquisa documental, análise comparada de fontes públicas, sistematização de tradição oral, relatos orais de pesquisa de campo e revisão semântica conduzidas no âmbito do Folclore Vivo da Associação MILK - Movimento de Intervenções e Linguagens Kulturais e Arte.
**Estado editorial:** corpus de pesquisa de campo e documentação cultural em revisão pública.
**Regra de publicabilidade:** esta entrada não deve ser lida como prova histórica definitiva, inventário patrimonial oficial, validação etnográfica concluída ou certificação académica externa sem verificação documental própria.
**Regra jurídica/RGPD:** não publicar nomes de informantes, contactos, moradas, entrevistas integrais, imagens identificáveis, gravações, dados de menores, coordenadas sensíveis ou materiais comunitários sem autorização.
**Regra de não invenção:** a presente readequação corrige a camada editorial e metodológica sem acrescentar factos, fontes, topónimos, coordenadas ou relatos não existentes no corpus-base.
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

81. A Lenda do Cão  Navegante  chamado Fucô (Minho e Douro Litoral)

(Sistematização  contemporânea  conduzida por Eduardo Mauer no âmbito  das pesquisas sobre
Folclore Vivo da Associação  MILK – Movimento de Intervenções e Linguagens Kulturais e Arte,
desenvolvida entre 2023 e 2025 a partir de recolhas orais realizadas em Esposende, Viana do
Castelo, Vila do Conde e Caminha, cruzadas com fontes etnográ ficas, registos náuticos  e arquivos
municipais. Esta versão  integra também  fragmentos narrativos recuperados de cadernos de
marinheiros e contos portuários  do século  XIX.)
⸻
1. Descrição  simbólica e narrativa
A Lenda do Cão  Navegante conhecido por Fucô pertence à tradição marítima do norte
português e sobrevive em versões fragmentadas ao longo da costa entre Esposende e Vila do
Conde. Trata-se de um mito onírico— a entidade conhecida por Cão  Navegante Fucô símbolo
da fidelidade, travessia, espírito risível das marés e dos ventos.
Conta a tradição que, em tempos de grande tempestade, um barco de pescadores partiu de
Esposende com sete homens e um cão, chamado Marujo. O mar enfurecido engoliu a
embarcação, e durante três dias não se encontrou vestígio algum. Ao quarto dia, um animal
apareceu a nadar, aproximando-se da costa, com uma lamparina presa aos dentes. Os
habitantes reconheceram o cão do barco e, guiados pela luz que trazia, conseguiram localizar o
local do naufrágio e resgatar os corpos dos marinheiros. Desde então, acreditou-se que a alma
do cão  navegava nas ondas em noites de tormenta, trazendo esperança aos que enfrentavam o
mar.
Fucô, também é descrito como espírito felpudo, de olhos cintilantes e sorriso constante, que
habita as espumas e as conchas da maré. Aparece nos portos e praias, sobretudo em noites de
luar ou quando há trovoada distante. É o companheiro invisível dos pescadores e das
crianças, um ser que ri e faz rir — guardião  do humor contra o medo do oceano. O seu nome
vem de “fucinho”, mas também do termo antigo fucôa, usado para designar redemoinhos
marítimos.
As lendas contam que, quando o Cão  Navegante ou simplesmente Fucô passa pela Costa
equilibrando-se na sua cauda e soprando-lhe canções. Ele é o símbolo da travessia e da leveza:
o cão  da fidelidade e o espírito do riso.
Uma versão recolhida em Apúlia (2024) narra que o Fucô, oferece as pessoas o dom do sorriso
eterno: “Enquanto sorrires, nunca te afundarás.” O Cão Navegante é reconhecido por um sorriso
sereno e luminoso, visível nas esculturas populares e nos ex-votos de madeira que os
pescadores deixam nas capelas costeiras.
Na leitura poética de Eduardo Mauer, “o Cão Navegante Fucô é um corpo duplo do afeto e da
coragem — o riso que guia a travessia e a fidelidade que sustenta o medo.”
⸻
2. Contexto histórico e social
A costa do Minho e Douro Litoral foi, desde o século XVIII, cenário de naufrágios  recorrentes e
de uma cultura marítima profundamente marcada pela precariedade e pela devoção. O mar,
simultaneamente fonte de sustento e ameaça, produziu um imaginário de entidades mediadoras
— cães, aves, peixes e santos que intercediam entre o humano e o abismo.
O Cão  Navegante representa o vínculo inquebrável entre o homem e o animal nas sociedades
piscatórias. A sua presença nas narrativas orais remete para a crença de que os cães possuem
sensibilidade espiritual e são guardiões entre mundos. Já o Fucô reflete a dimensão lúdica e
esperançosa das comunidades costeiras — uma figura bufonesca e luminosa, cuja missão é
restaurar o riso após a perda.


Os registos do Arquivo Paroquial de Esposende (1798–1810) mencionam “a alma do cão que
volta ao mar com a lamparina”, enquanto os cadernos de embarcação  de Vila do Conde (1875)
contêm pequenas anotações sobre “um espírito de espuma que canta nas tábuas molhadas do
convés”. Estes documentos con firmam a fusão entre crença oral e devoção doméstica.
Durante o século XX, o mito perdeu força com o declínio da pesca artesanal, mas sobreviveu em
ex-votos marítimos e em pequenas esculturas de madeira expostas em capelas como a da
Senhora da Bonança (Vila do Conde) e da Senhora da Guia (Esposende). Nas décadas
recentes, o Cão Navegante e o Fucô reaparecem em contextos de arte contemporânea e
narrativas ambientais, reinterpretados como símbolos de resiliência e humor diante da
catástrofe .
⸻
3. Toponímia e variantes locais
O termo “Fucô” tem origem provável em fucôa ou fucuar, palavras antigas ligadas ao som da
água a ferver ou ao redemoinho — uma onomatopeia do movimento do mar. Já o “Cão
Navegante” surge associado às freguesias de Marinhas, Apúlia e Ofir, onde existiam antigos
“caminhos dos cães” — trilhos usados para conduzir o gado até à beira-mar.
As variantes locais incluem:
– O Cão  da Luz (Esposende): enfatiza a lamparina presa ao focinho;
– O Cão  do Marujo (Vila do Conde): identifica o animal com o companheiro de um pescador
desaparecido;
– O Fucô do Sorriso (Apúlia): espírito marinho que ensina os náufragos a rir para não se afogar;
– O Cão  do Farol (Caminha): figura guardiã que ronda a costa e uiva antes das tempestades.
Algumas versões fundem as duas entidades numa só: um cão luminoso com rabo de espuma e
sorriso aberto. Outras mantêm-nos distintos, mas inseparáveis — a coragem e o humor em
aliança.
⸻
4. Primeiro relato e fontes académicas primárias
O primeiro registo literário conhecido da Lenda do Cão  Navegante encontra-se no manuscrito
anónimo Crónicas do Porto e do Mar de Esposende (1849, Biblioteca Pública Municipal do Porto,
cód. 728), onde se lê: “um cão nadador que traz à costa a luz dos mortos e se chama fiel como o
sal.”
Leite de Vasconcelos, Etnografia Portuguesa, vol. VI (1918, pp. 93–101)*, menciona “os cães do
mar que guiam barcos” e “espíritos de espuma que riem como crianças”.
Alexandre Parafita, Mitologia Popular Portuguesa (2008, pp. 751–760)*, reconhece a dupla Cão/
Fucô como “mito da travessia marítima, expressão da alma portuguesa que con fia no humor
como defesa do destino.”
Eduardo Mauer, O Cão  Navegante e o Fucô: Humor, Coragem e Travessia na Mitologia Marítima
do Norte de Portugal (Lisboa, Associação MILK, 2025)*, sistematiza as variantes contemporâneas
e propõe leitura simbólica integradora das dimensões animal, humana e espiritual.
Fontes complementares:
– Arquivo Municipal de Esposende, Cadernos de Lendas Costeiras (1860–1920);
– Museu Marítimo de Ílhavo, Coleção  de Ex-Votos do Norte (cat. 57–112, 1930–1970);
– Tese de Doutoramento de Carla Moura, Mitologia do Riso e do Medo na Cultura Piscatória
Portuguesa (U. Porto, 2017).


⸻
5. Síntese interpretativa final
A Lenda do Cão  Navegante e do Fucô expressa o equilíbrio entre a seriedade do perigo e a
leveza do riso. O cão, símbolo da fidelidade e da coragem, mergulha nas águas da morte; o
Fucô, espírito do humor, acompanha-o para garantir que a travessia não se transforma em
desespero.
Na leitura simbólica da Associação  MILK, esta é uma mitologia da ternura: o riso não como
distração, mas como tecnologia de sobrevivência. O Fucô é “curador do medo”, e o Cão,
“guardião da promessa”. Juntos, ensinam que a fé e o humor são forças complementares — o
peso e o leve, o impulso e a flutuação.
A escultura MILK concebida por Eduardo Mauer representa os dois seres em unidade: um corpo
compacto de cão sorridente, com uma pequena esfera de luz na boca (a lamparina) e um espírito
translúcido, de forma espiralada, erguendo-se da base como rasto de espuma. O sorriso do cão
é suave, sinal do dom que recebeu do Fucô — o poder de fazer o outro sorrir e, assim, não se
afundar.
⸻
6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer
Na leitura não binária de Eduardo Mauer, o Cão  Navegante e o Fucô são o duplo corpo da
alma marítima — o ser sólido e o ser fluido, o peso e o riso, unidos pela travessia.
Mauer escreve:
“O Cão e o Fucô são as duas margens de um mesmo ser: corpo e sopro. O primeiro
aprende a sorrir; o segundo aprende a cuidar. Juntos, revelam o não binário como arte de
flutuar entre dor e alegria.”
Para a Associação  MILK, este mito é símbolo do não  binário  emocional, no qual as
forças da vulnerabilidade e da bravura se unem. O Fucô, ser de riso, não anula o medo;
transforma-o em corrente ascendente. O Cão, ser de fidelidade, aprende com o riso a
tornar-se leve.
Assim, a lenda é metáfora da convivência entre forças opostas — a coragem que chora e
o riso que salva. Ambos coexistem como duas expressões do mesmo amor pela vida.
⸻
7. Referência Estrutural da Matriz MILK
Na Matriz Escultórica MILK – Série Folclore Vivo, o Cão  Navegante e o Fucô são
representados numa única peça, expressando unidade simbiótica:
– Corpo principal (cão):  compacto, sorriso suave, lamparina luminosa presa ao focinho.
– Corpo secundário  (Fucô): espiral translúcida em resina azul-clara que emerge da base e
envolve o cão como brisa.
– Cores: areia, azul-espuma e âmbar.
– Materiais: resina pigmentada, fibra de vidro translúcida e luz interna pulsante.
– Base: ondulada, lembrando ondas do mar; acabamento com verniz marítimo fosco.
A peça encarna o duplo equilíbrio entre humor e coragem, traduzindo em forma plástica a
síntese filosófica da travessia.


⸻
Localização  específica: litoral norte de Portugal – Esposende, Apúlia, Vila do Conde, Caminha.
Primeiro relato documentado: Crónicas do Porto e do Mar de Esposende, manuscrito 1849.
Sistematização  contemporânea:  Eduardo Mauer, O Cão  Navegante e o Fucô: Humor, Coragem
e Travessia na Mitologia Marítima  do Norte de Portugal, Associação MILK, 2025.
Fontes primárias:  Vasconcelos (1918); Parafita (2008); Moura (2017); Mauer (2025).
