# 035. A Lenda do Naso (Miranda do Douro, Trás-os-Montes  e Alto Douro)

**Base documental e empírica:** pesquisa documental, análise comparada de fontes públicas, sistematização de tradição oral, relatos orais de pesquisa de campo e revisão semântica conduzidas no âmbito do Folclore Vivo da Associação MILK - Movimento de Intervenções e Linguagens Kulturais e Arte.
**Estado editorial:** corpus de pesquisa de campo e documentação cultural em revisão pública.
**Regra de publicabilidade:** esta entrada não deve ser lida como prova histórica definitiva, inventário patrimonial oficial, validação etnográfica concluída ou certificação académica externa sem verificação documental própria.
**Regra jurídica/RGPD:** não publicar nomes de informantes, contactos, moradas, entrevistas integrais, imagens identificáveis, gravações, dados de menores, coordenadas sensíveis ou materiais comunitários sem autorização.
**Regra de não invenção:** a presente readequação corrige a camada editorial e metodológica sem acrescentar factos, fontes, topónimos, coordenadas ou relatos não existentes no corpus-base.
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

35. A Lenda do Naso (Miranda do Douro, Trás-os-Montes  e Alto Douro)
(Sistematização  contemporânea  conduzida por Eduardo Mauer no âmbito  das pesquisas sobre
Folclore Vivo da Associação  MILK – Movimento de Intervenções e Linguagens Kulturais e Arte,
integrando cruzamento de fontes orais, eclesiásticas  e académicas  da tradição  mirandesa.)
⸻
1. Descrição  simbólica e narrativa
A Lenda do Naso, uma das mais enraizadas manifestações de religiosidade popular
transmontana, nasce em torno da Capela de Nossa Senhora do Naso, situada na encosta do
vale profundo de Miranda do Douro. O termo Naso, derivado de nasus (promontório, penhasco),
designa o lugar em si — uma saliência rochosa voltada para o rio, onde se diz ter ocorrido o
milagre fundador.
Segundo o relato tradicional, recolhido por Eduardo Mauer entre 2022 e 2024, a lenda conta que
um casal mirandês, pastor e lavradeira, de nome Domingos e Rosa, transportava uma pequena
imagem da Virgem em procissão doméstica, pedindo chuva para as sementeiras. Ao passarem

pelo penedo do Naso, a imagem tornou-se subitamente pesada — tão pesada que não
puderam mover-la. Interpretando o fenómeno como sinal divino, deixaram-na ali, e nesse mesmo
instante começou a chover.
A população vizinha construiu então uma pequena ermida no local, onde se instituiu a devoção à
Nossa Senhora do Naso, invocada contra secas, pragas e doenças. A imagem, de pedra
calcária, exibe feições singelas e infantis, com o manto pintado de azul e dourado.
Versões paralelas, transmitidas oralmente nas aldeias de Ifanes, Póvoa e Sendim, atribuem o
acontecimento a uma aparição  luminosa sobre o penedo, em que a Virgem teria surgido envolta
em névoa branca, olhando para o Douro. Em outras, a própria rocha teria “aberto em flor” no
momento da chuva — imagem simbólica que sobrevive em cânticos e romances de romaria.
A história do Naso inscreve-se, assim, na tipologia ibérica das Virgens Imóveis, imagens que
escolhem o seu lugar por milagre, como a Senhora da Lapa (Sernancelhe) ou a Senhora da
Abadia (Amares). No caso mirandês, a particularidade está na fusão entre milagre
meteorológico e paisagem geológica, onde o sagrado se manifesta na densidade da pedra.
Para Eduardo Mauer, “o Naso é o ventre mineral da fé. A pedra que se torna corpo, o peso que
se converte em permanência.”
⸻
2. Contexto histórico e social
O culto da Senhora do Naso remonta, segundo fontes eclesiásticas locais, ao século XVII,
período de grande instabilidade climática e social na região transmontana. As sucessivas secas e
fomes favoreceram a proliferação de cultos pluviométricos marianos, nos quais a Virgem era
invocada como intercessora da chuva e da fertilidade da terra.
A lenda reflete um modelo de religiosidade profundamente agrária  e comunitária , em que o
sagrado se mede pela sua eficácia natural. A relação direta entre a aparição e a chuva inscreve a
Senhora do Naso na lógica ancestral do sagrado climático  — continuidade dos antigos ritos
pré-cristãos de invocação da água e da fecundidade.
No século XIX, o santuário tornou-se um dos polos espirituais mais visitados do nordeste
português. Documentos do Arquivo Distrital de Bragança referem romarias com mais de dois
mil peregrinos anuais, provenientes inclusive de Zamora (Espanha). O evento central da festa é a
Procissão  das Promessas, em que mulheres sobem o penedo descalças, levando fitas
coloridas, garrafas de água e pedaços de terra para abençoar.
A iconografia da Senhora do Naso, de fisionomia austera, contrasta com a delicadeza dos ex-
votos depositados à sua volta — corações, mãos e pés em cera, pequenas fotogra fias e cartas
de agradecimento. O lugar é, até hoje, espaço de cura e escuta, visitado por famílias inteiras em
busca de bênçãos.
Na leitura sociocultural de Eduardo Mauer, “o Naso sintetiza o inconsciente ecológico do povo
mirandês: o entendimento da paisagem como interlocutora espiritual, onde a fé é inseparável da
pedra e da chuva.”
⸻
3. Toponímia e variantes locais
O Monte do Naso, também chamado “Serra da Senhora”, ergue-se cerca de dois quilómetros a
sul de Miranda do Douro, dominando o vale do Ribeiro da Póvoa. O nome aparece já em
documentos paroquiais de 1652, e em mapas de 1713 como Mons Naso.


A lenda apresenta pequenas variantes locais. Em Ifanes, a Virgem é chamada “Senhora da
Rocha Pesada”; em Duas Igrejas, “Senhora da Chuva”; e em Póvoa, “Senhora do Milagre da
Pedra”. Todas remetem à mesma estrutura narrativa: imagem que recusa mover-se, sinalizando o
seu lugar definitivo.
Topónimos vizinhos — “Vale das Promessas”, “Fonte da Senhora”, “Caminho das Velas” —
reforçam o caráter ritual da geogra fia. Cada um desses pontos integra o percurso da Romaria do
Naso, documentada desde o século XIX.
Há também paralelos galegos e leoneses (Espanha), como a Virxe do Cebreiro ou a Nuestra
Señora del Valle, revelando uma matriz peninsular partilhada de Virgens telúricas.
⸻
4. Primeiro relato e fontes académicas primárias
O primeiro relato escrito da Lenda do Naso encontra-se em Leite de Vasconcelos, Etnografia
Portuguesa, vol. IV (1915, pp. 401–405)*, onde o autor descreve “a Senhora que se deteve no
penedo do Naso, escolhendo morada e provocando chuva”.
Joaquim Alves Ferreira, Literatura de Trás-os-Montes  e Alto Douro – Lendas e Contos Infantis,
vol. V (Bragança, 1950, pp. 41–45)*, recolhe a versão oral completa, com o testemunho dos
habitantes da Póvoa, destacando a frase tradicional: “Onde a Senhora parou, aí  ficou o Céu.”
Alexandre Parafita, Mitologia Popular Portuguesa (2008, pp. 327–331)*, analisa o mito do Naso à
luz das teorias da cristianização dos lugares de culto natural, considerando-o “um dos mais
claros exemplos de metamorfose simbólica da Mãe Terra em Mãe de Deus”.
A sistematização contemporânea de Eduardo Mauer, O Naso: Pedra, Água  e Permanência  no
Imaginário  Mirandês  (Lisboa, Associação MILK, 2024), combina levantamento arqueográ fico,
recolha oral e análise fenomenológica da paisagem, propondo que o Naso funcione como
arquivo natural da fé.
Fontes complementares:
– Arquivo Distrital de Bragança, Registos Paroquiais e Festivos de Miranda do Douro (1650–1960);
– Museu da Terra de Miranda, Coleção  Iconográ fica Mariana do Nordeste (1940–1980);
– Tese de Doutoramento de Teresa Lemos, Geografia do Sagrado: Toponímia e Aparições no
Nordeste Transmontano (U. Porto, 2021).
⸻
5. Síntese interpretativa final
A Senhora do Naso é a imagem da permanência. O seu milagre não é a aparição, mas o peso: o
gesto de ficar. Representa o encontro entre o efémero (a chuva) e o duradouro (a pedra).
Na leitura da Associação  MILK, o Naso é o mito da imanência — o sagrado que não desce do
céu, mas emerge da terra. O fenómeno do peso miraculoso transforma-se em metáfora do
pertencimento e da raiz: o corpo espiritual que encontra lugar no corpo mineral.
A escultura MILK concebida por Eduardo Mauer traduz essa ideia através de forma compacta,
de cabeça grande e corpo de pedra translúcida, com fissura central iluminada em azul e branco.
A base irregular imita o penedo real do Naso, e a luz interna pulsa lentamente, evocando
respiração telúrica.
⸻


6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer
Na leitura não binária de Eduardo Mauer, a Senhora do Naso é a entidade do peso e da leveza.
O seu corpo é simultaneamente duro e fluido, fixo e mutável.
Mauer escreve: “O Naso é o corpo que não escolhe — é escolhido. É o género da permanência,
o sagrado que aceita ser chão.”
A Associação  MILK interpreta o mito como celebração da identidade-raiz, em contraponto à
mobilidade contemporânea. O peso da pedra simboliza o corpo não binário enquanto corpo-
lugar: não o que foge, mas o que fica — ser que ocupa o mundo sem pedir permissão.
⸻
7. Referência Estrutural da Matriz MILK
Na Matriz Escultórica MILK, a Senhora do Naso é representada em corpo compacto, de textura
pétrea e cabeça grande, com fissura vertical luminosa no centro do peito. As cores
predominantes são branco, azul-claro e cinza-pedra. A base imita a topogra fia do penedo do
Naso, com iluminação interna subtil.
⸻
Localização  específica: Miranda do Douro e Póvoa (Trás-os-Montes e Alto Douro).
Primeiro relato documentado: Leite de Vasconcelos, Etnografia Portuguesa, vol. IV, 1915.
Sistematização  contemporânea:  Eduardo Mauer, O Naso: Pedra, Água  e Permanência  no
Imaginário  Mirandês , Associação MILK, 2024.
Fontes primárias:  Vasconcelos (1915); Ferreira (1950); Parafita (2008); Lemos (2021); Mauer
(2024).
