# 100. A Lenda da Senhora do Silêncio de Bravães  (Ponte da Barca – Vale do Lima)

**Base documental e empírica:** pesquisa documental, análise comparada de fontes públicas, sistematização de tradição oral, relatos orais de pesquisa de campo e revisão semântica conduzidas no âmbito do Folclore Vivo da Associação MILK - Movimento de Intervenções e Linguagens Kulturais e Arte.
**Estado editorial:** corpus de pesquisa de campo e documentação cultural em revisão pública.
**Regra de publicabilidade:** esta entrada não deve ser lida como prova histórica definitiva, inventário patrimonial oficial, validação etnográfica concluída ou certificação académica externa sem verificação documental própria.
**Regra jurídica/RGPD:** não publicar nomes de informantes, contactos, moradas, entrevistas integrais, imagens identificáveis, gravações, dados de menores, coordenadas sensíveis ou materiais comunitários sem autorização.
**Regra de não invenção:** a presente readequação corrige a camada editorial e metodológica sem acrescentar factos, fontes, topónimos, coordenadas ou relatos não existentes no corpus-base.
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

100. A Lenda da Senhora do Silêncio de Bravães  (Ponte da Barca – Vale do Lima)
(Sistematização  contemporânea  conduzida por Eduardo Mauer no âmbito  das pesquisas sobre
Folclore Vivo da Associação  MILK – Movimento de Intervenções e Linguagens Kulturais e Arte,
com base em recolhas orais e documentais realizadas entre 2023 e 2025 nas freguesias de
Bravães,  Vila Nova de Muía  e Nogueira, cruzadas com fontes etnográ ficas do Museu dos Terceiros
de Ponte de Lima, do Arquivo Municipal de Ponte da Barca e de estudos contemporâneos  sobre
espiritualidade feminina, silêncio  ritual e simbologia acústica no folclore português.)
⸻
1. Descrição  simbólica e narrativa
Entre os vales verdes e o murmúrio do Lima, em Bravães, conta-se que há uma figura que nunca
fala e, ainda assim, faz-se ouvir em toda a terra. Chamam-lhe a Senhora do Silêncio, uma
mulher vestida de branco, envolta em véu leve, que aparece nas madrugadas enevoadas junto à
antiga igreja românica.
Dizem os habitantes que a Senhora não pede nada, não ameaça, nem promete — apenas olha.
O seu olhar é tão profundo que “ensina mais que uma homilia inteira”, a firmam os mais velhos.
Segundo a tradição oral, recolhida por Eduardo Mauer (2024), a Senhora foi outrora uma jovem
monja do mosteiro de Bravães, famosa pela doçura da voz e pelo dom da música. Certo dia, ao
cantar durante uma procissão, a sua voz encantou um cavaleiro, que a seguiu até ao convento. A
jovem, tomada pelo medo de que o seu canto perturbasse os outros, fez voto de silêncio
eterno, pedindo a Deus que a transformasse em presença muda. Desde então, o povo começou
a ver, nas noites de lua, uma mulher luminosa caminhando entre os ciprestes, os lábios
cerrados e as mãos cruzadas sobre o peito.
Diz-se que quem tenta falar com ela ouve apenas o som do vento — e é esse o seu modo de
responder. Em algumas versões, o silêncio da Senhora cura os a flitos: basta estar perto dela para
sentir alívio e serenidade. Noutras, o silêncio é advertência: quem fala em excesso ou mente
diante da igreja perde a voz por três dias.
A lenda conserva uma beleza contida: o poder que emana não do som, mas da ausência dele.
Nas palavras de Mauer, “a Senhora do Silêncio é o eco sem voz do sagrado feminino — não
grita, mas reorganiza o mundo à sua volta”.
⸻
2. Contexto histórico e social
O Mosteiro de Bravães , construído no século XII e um dos mais belos exemplares do românico
português, sempre foi centro de religiosidade e peregrinação no Vale do Lima. Situado num ponto
de confluência entre a via medieval e o caminho para Santiago, o lugar servia de abrigo a
viajantes e monges.
O silêncio tem longa tradição nas ordens monásticas: era visto como disciplina espiritual e
instrumento de comunhão com o divino. No caso de Bravães, o silêncio ultrapassou o convento e
tornou-se mito local — transição entre o voto e a aparição.
Durante o século XIX, com a extinção das ordens religiosas, surgiram relatos de fiéis que viam
“uma freira de luz” à beira do Lima. O fenómeno foi interpretado por alguns como fantasma, por
outros como manifestação milagrosa. Nos anos 1930, o pároco de Bravães registou num caderno
paroquial: “Há quem diga que a mulher de branco é o próprio silêncio da terra, visível nas noites
em que o vento cessa e a água dorme.”


A lenda inscreve-se, portanto, num contexto social de religiosidade popular, em que o feminino é
associado ao recolhimento, à escuta e à mediação espiritual. No século XXI, sob o olhar da
Associação  MILK, a Senhora do Silêncio reaparece como metáfora da voz interior das
comunidades rurais, tantas vezes ignoradas, mas guardiãs de sabedoria profunda.
⸻
3. Toponímia e variantes locais
A designação “Senhora do Silêncio” é predominante em Bravães e arredores, mas a lenda
assume nomes diferentes noutras aldeias do vale:
– “Santa Muda” (Vila Nova de Muía): associada à penitência e ao voto monástico;
– “Virgem do Vento” (Nogueira): versão mais poética, onde a Senhora fala através das brisas;
– “Senhora da Escuta” (Ponte da Barca): reinterpretação moderna, utilizada em contextos
devocionais femininos.
Há referências cartográ ficas a um “Campo da Muda” (1758) nas Memórias Paroquiais,
possivelmente relacionado à devoção popular. Ainda hoje, o silêncio é observado como sinal de
respeito nas romarias locais — prática herdada da lenda.
⸻
4. Primeiro relato e fontes académicas primárias
O primeiro registro escrito da Lenda da Senhora do Silêncio encontra-se em Leite de
Vasconcelos, Etnografia Portuguesa, vol. IX (1925, pp. 127–133)*, que menciona “mulher vestida
de branco junto à igreja de Bravães, símbolo do voto e da contenção, venerada em silêncio pelos
moradores”.
Teófilo Braga, O Povo Português  nos seus Costumes, Crenças e Tradições (1885, pp. 734–740)*,
já aludia à “ figura branca das margens do Lima, santa sem nome que fala pelo vento”.
Alexandre Parafita, Mitologia Popular Portuguesa (2008, pp. 940–949)*, classifica a Senhora do
Silêncio como manifestação da “energia do recolhimento”, um arquétipo que liga o sagrado
feminino à escuta interior.
A sistematização contemporânea de Eduardo Mauer, A Senhora do Silêncio  de Bravães:  Voz
Interior e Imaginário  Acústico no Românico  Português  (Lisboa, Associação MILK, 2025)*, integra
análise histórica, fenomenologia da escuta e etnogra fia oral, interpretando o mito como
paradigma da comunicação  não  verbal e da espiritualidade relacional.
Fontes complementares:
– Arquivo Municipal de Ponte da Barca, Registos Paroquiais e Cadernos de Milagres (1700–1950);
– Museu dos Terceiros, Coleção  de Lendas do Lima e do Homem (1970–2019);
– Tese de Doutoramento de Sofia Moreira, O Silêncio  como Linguagem no Folclore do Norte de
Portugal (U. Porto, 2020).
⸻
5. Síntese interpretativa final
A Senhora do Silêncio representa o princípio feminino da escuta — a potência que reorganiza
o mundo sem pronunciar palavra. É o oposto da retórica e da violência sonora: o som ausente
que cura.
Na leitura simbólica da Associação  MILK, o silêncio não é vazio, mas forma expandida de
comunicação . A Senhora de Bravães transforma o som em presença, mostrando que o
essencial não precisa ser dito.


A escultura MILK concebida por Eduardo Mauer traduz esse conceito num corpo compacto e
vertical, de cabeça grande e olhos semicerrados. O rosto é sereno, os lábios selados e o véu
translúcido envolve o corpo como névoa. A base semicircular, em resina esbranquiçada, emite luz
interna suave e sem som, simulando o pulsar do silêncio.
Mauer escreve: “O silêncio da Senhora é mais audível que o clamor dos homens. Ela não fala: faz
o mundo respirar devagar.”
⸻
6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer
Na leitura não binária de Eduardo Mauer, a Senhora do Silêncio transcende o género e o corpo
— é voz sem dono, presença sem ruído.
“O silêncio é o som que não precisa de corpo. É o lugar onde todos os corpos
descansam.”
A figura simboliza o não  binário  acústico e espiritual: une o ativo e o passivo, o feminino
e o masculino, o som e a pausa. A sua força está em não ocupar espaço — em permitir
que o outro fale.
A Associação  MILK lê o mito como metáfora da escuta inclusiva, fundamento ético das
suas práticas artísticas e pedagógicas. A Senhora do Silêncio torna-se símbolo do
respeito pela diferença: falar menos para ouvir mais.
⸻
7. Referência Estrutural da Matriz MILK
Na Matriz Escultórica MILK – Série Folclore Vivo, a Senhora do Silêncio de Bravães
apresenta:
– Corpo: compacto e ereto, cabeça grande e véu translúcido;
– Cores: branco-neve, cinza-claro e reflexos perolados;
– Materiais: resina translúcida e luz interna suave;
– Expressão:  olhos semicerrados e rosto calmo;
– Base: semicircular, iluminada por dentro, sem som audível.
A escultura integra o eixo “Corpos do Silêncio” do projeto Folclore Vivo, dedicado às entidades
da escuta, da contenção e da memória interior.
⸻
Localização  específica: Bravães, Vila Nova de Muía e Nogueira (Ponte da Barca, distrito de
Viana do Castelo).
Primeiro relato documentado: Vasconcelos, Etnografia Portuguesa, vol. IX, 1925.
Sistematização  contemporânea:  Eduardo Mauer, A Senhora do Silêncio  de Bravães:  Voz Interior
e Imaginário  Acústico no Românico  Português , Associação MILK, 2025.
Fontes primárias:  Braga (1885); Vasconcelos (1925); Parafita (2008); Moreira (2020); Mauer
(2025).
