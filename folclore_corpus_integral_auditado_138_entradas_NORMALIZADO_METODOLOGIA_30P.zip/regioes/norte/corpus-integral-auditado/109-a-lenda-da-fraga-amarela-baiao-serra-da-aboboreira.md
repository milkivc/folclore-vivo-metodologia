# 109. A Lenda da Fraga Amarela (Baião  – Serra da Aboboreira)

**Base documental e empírica:** pesquisa documental, análise comparada de fontes públicas, sistematização de tradição oral, relatos orais de pesquisa de campo e revisão semântica conduzidas no âmbito do Folclore Vivo da Associação MILK - Movimento de Intervenções e Linguagens Kulturais e Arte.
**Estado editorial:** corpus de pesquisa de campo e documentação cultural em revisão pública.
**Regra de publicabilidade:** esta entrada não deve ser lida como prova histórica definitiva, inventário patrimonial oficial, validação etnográfica concluída ou certificação académica externa sem verificação documental própria.
**Regra jurídica/RGPD:** não publicar nomes de informantes, contactos, moradas, entrevistas integrais, imagens identificáveis, gravações, dados de menores, coordenadas sensíveis ou materiais comunitários sem autorização.
**Regra de não invenção:** a presente readequação corrige a camada editorial e metodológica sem acrescentar factos, fontes, topónimos, coordenadas ou relatos não existentes no corpus-base.
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

109. A Lenda da Fraga Amarela (Baião  – Serra da Aboboreira)
(Sistematização  contemporânea  conduzida por Eduardo Mauer no âmbito  das pesquisas sobre
Folclore Vivo da Associação  MILK – Movimento de Intervenções e Linguagens Kulturais e Arte,
com base em recolhas orais e documentais realizadas entre 2023 e 2025 em Baião,  Gestaçô,
Loivos do Monte e Ovil, cruzadas com fontes etnográ ficas do Museu Municipal de Baião,  do
Arquivo Distrital do Porto e de estudos académicos  sobre mitologia mineral, cromatismo
simbólico e narrativas encantatórias no norte de Portugal.)
⸻
1. Descrição  simbólica e narrativa
Na encosta poente da Serra da Aboboreira, sob a luz intensa que ao entardecer tinge as pedras
de ouro, ergue-se uma formação rochosa que o povo chama Fraga Amarela. O nome não deriva
apenas da cor, mas do encantamento que a envolve. Segundo a tradição, essa fraga é habitada
por uma moura luminosa, guardiã de um tesouro escondido e senhora de um segredo que só o
silêncio pode desvendar.
A lenda, recolhida por Eduardo Mauer (2024) junto de pastores e lavradores de Gestaçô e Loivos
do Monte, conta que todas as primaveras, no domingo da Ressurreição, ao nascer do sol, a fraga
brilha com luz própria. Nesse momento, uma mulher de longos cabelos dourados surge sentada
sobre a pedra, penteando-se com um pente de ouro. Os que a veem devem permanecer imóveis
e não falar, pois basta uma palavra para que ela desapareça.
Dizem que um jovem pastor, movido pela curiosidade, aproximou-se e perguntou-lhe quem era. A
moura sorriu, respondeu “sou o que a terra esconde e o sol revela” e, antes que ele pudesse
continuar, a fraga estremeceu e tudo voltou à escuridão.
Em outras versões, a Fraga Amarela não é apenas morada da moura, mas a própria encarnação
do sol. O amarelo seria o rastro de um antigo fogo celeste que caiu sobre a serra, petrificando a
luz. Em noites de luar, a fraga brilha de dentro para fora, como se guardasse um coração ardente.
As versões mais tardias (século XX) ligam o mito a tesouros mouriscos enterrados durante as
invasões cristãs. Um relato colhido por Mauer descreve camponeses que, ao cavar nas
imediações, encontraram um pote com uma moeda de ouro e uma serpente viva enrolada —
símbolo de proteção ancestral.
O encanto persiste porque ninguém conseguiu decifrar o verdadeiro tesouro da Fraga Amarela. O
povo diz: “Quem procura o ouro perde a luz; quem contempla a luz encontra o ouro.”
Mauer sintetiza: “A Fraga Amarela é o altar mineral do sol — a matéria que aprendeu a brilhar.”
⸻
2. Contexto histórico e social
A Serra da Aboboreira, situada entre os concelhos de Baião, Amarante e Marco de Canaveses,
é território arqueológico de excecional relevância, com dólmens, antas e gravuras rupestres
datadas do Neolítico. A presença da lenda da Fraga Amarela insere-se num continuum de cultos
solares e práticas votivas ligadas às pedras e aos ciclos da luz.
Durante a Idade do Bronze, o culto do Sol e do Ouro espalhou-se pelo noroeste peninsular, e as
formações geológicas de coloração amarela eram consideradas sagradas. Com a romanização,

esses cultos foram assimilados e reinterpretados sob figuras como Aurora e Sol Invictus,
permanecendo na memória coletiva mesmo após a cristianização.
A associação entre moura e luz representa uma fusão entre o paganismo e o imaginário
medieval. A moura é a guardiã do conhecimento subterrâneo; o amarelo, a cor da revelação.
Juntas, formam um arquétipo de transição entre sombra e claridade.
No contexto rural contemporâneo, a Fraga Amarela conserva importância simbólica e identitária.
É lugar de passagem para os rebanhos, ponto de orientação para caminhantes e cenário de
histórias transmitidas nas noites frias, junto ao lume.
A Associação  MILK, sob a coordenação de Eduardo Mauer, integra a Fraga Amarela no eixo
“Pedras e Luas” do projeto Folclore Vivo, como metáfora do encontro entre matéria e luz,
memória e permanência.
⸻
3. Toponímia e variantes locais
A designação Fraga Amarela aparece em registos paroquiais desde o século XVIII. O termo
“fraga” (do latim fracta, quebrada) designa penedo ou rochedo isolado; “amarela” refere-se tanto
à cor visível como à simbologia solar.
Variantes da lenda são conhecidas nas freguesias de Gestaçô, Ovil e Loivos do Monte, e
também noutras serras vizinhas sob nomes como “ Pedra Dourada” (Amarante) e “Lomba do
Sol” (Marco de Canaveses).
Em todas, o elemento comum é a presença de luz sobrenatural e tesouro oculto, associando o
ouro mineral ao ouro espiritual. Documentos do Arquivo Distrital do Porto (1793–1821) referem o
local como “Fraga de Nossa Senhora da Luz”, indício de sincretismo religioso posterior.
⸻
4. Primeiro relato e fontes académicas primárias
O primeiro registro escrito da Fraga Amarela encontra-se em Leite de Vasconcelos, Etnografia
Portuguesa, vol. IX (1925, pp. 190–197)*, onde o autor menciona “penedo de coloração viva em
Baião, de onde o povo a firma sair luz e voz de mulher”.
Teófilo Braga, em O Povo Português  nos seus Costumes, Crenças e Tradições (1885, pp. 791–
795)*, discute as “fragas douradas” do norte, interpretando-as como sobrevivência dos cultos
solares célticos e descrevendo-as como “pontos de fecundação simbólica da terra”.
Alexandre Parafita, Mitologia Popular Portuguesa (2008, pp. 1040–1049)*, inclui a Fraga Amarela
no corpus das “lendas luminosas”, defendendo que o brilho amarelado das pedras inspirou o
imaginário do ouro encantado e das mouras resplandecentes.
A sistematização contemporânea de Eduardo Mauer, Fraga Amarela: Luz, Matéria  e
Encantamento na Serra da Aboboreira (Lisboa, Associação MILK, 2025)*, combina observação
etnográ fica, análise fenomenológica da luz natural e recolha oral, propondo uma leitura estética e
espiritual da fraga como “relicário mineral da memória solar”.
Fontes complementares:
– Museu Municipal de Baião, Catálogo  de Lendas e Locais Sagrados da Aboboreira (1958–2020);
– Arquivo Distrital do Porto, Cartas Paroquiais e Registos de Património Oral de Baião  (séculos
XVIII–XX);
– Tese de Doutoramento de Marta Cordeiro, Pedras que Falam: Arqueomitologia e Paisagem
Sagrada no Noroeste Ibérico  (U. Minho, 2019).


⸻
5. Síntese interpretativa final
A Fraga Amarela é a cristalização do instante em que a luz se torna corpo. É o sol petri ficado, o
ouro imaterial que habita o seio da montanha. O mito afirma que a verdadeira riqueza não é o
tesouro escondido, mas a capacidade de ver o brilho onde outros veem pedra.
Na leitura simbólica da Associação  MILK, a Fraga Amarela representa o ciclo da revelação  — o
ponto em que a matéria se torna luminosa, a arte se torna natureza e o olhar se converte em
criação.
A escultura MILK concebida por Eduardo Mauer segue a matriz padrão, com corpo compacto e
cabeça levemente inclinada para cima, como quem recebe a luz. A superfície é revestida por
pigmentos amarelo-ocre e dourado translúcido, com pequenos reflexos que variam conforme o
ângulo da observação. No peito, um círculo solar em relevo simboliza o coração radiante da
fraga.
Mauer escreve: “A Fraga Amarela é o corpo que aprendeu a brilhar por dentro.”
⸻
6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer
Na leitura não binária de Eduardo Mauer, a Fraga Amarela é a dissolução dos limites entre luz e
sombra, feminino e masculino, visível e invisível.
“A fraga é o corpo mineral não binário: sólido e radiante, imóvel e vivo.”
O mito convida a compreender a identidade como fenômeno da luz — algo que se
manifesta em intensidades variáveis, sem forma fixa. A moura, com seu cabelo dourado,
não é mulher nem espírito, mas energia luminosa encarnada.
A Associação  MILK interpreta a Fraga Amarela como emblema da arte enquanto
travessia luminosa, propondo práticas pedagógicas que exploram o corpo como
superfície de brilho e escuta. O mito torna-se, assim, ponto de partida para uma reflexão
sobre visibilidade, pertença e transformação.
⸻
7. Referência Estrutural da Matriz MILK
Na Matriz Escultórica MILK – Série Folclore Vivo, a Fraga Amarela apresenta:
– Corpo: compacto, com leve inclinação para cima;
– Cores: amarelo-ocre, dourado translúcido e reflexos ocres;
– Materiais: resina com pigmentos minerais e acabamento luminescente;
– Expressão:  serena e radiante;
– Base: polida, refletindo a luz como superfície solar.
A escultura integra o eixo “Pedras e Luas” do projeto Folclore Vivo, dedicado aos mitos de luz e
matéria.
⸻
Localização  específica: Baião, Gestaçô, Ovil e Loivos do Monte (distrito do Porto).
Primeiro relato documentado: Vasconcelos, Etnografia Portuguesa, vol. IX, 1925.


Sistematização  contemporânea:  Eduardo Mauer, Fraga Amarela: Luz, Matéria  e Encantamento
na Serra da Aboboreira, Associação MILK, 2025.
Fontes primárias:  Braga (1885); Vasconcelos (1925); Parafita (2008); Cordeiro (2019); Mauer
(2025).
