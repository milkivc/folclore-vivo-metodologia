# 030. O Trasgo (Trás-os-Montes  e Alto Minho)

**Base documental e empírica:** pesquisa documental, análise comparada de fontes públicas, sistematização de tradição oral, relatos orais de pesquisa de campo e revisão semântica conduzidas no âmbito do Folclore Vivo da Associação MILK - Movimento de Intervenções e Linguagens Kulturais e Arte.
**Estado editorial:** corpus de pesquisa de campo e documentação cultural em revisão pública.
**Regra de publicabilidade:** esta entrada não deve ser lida como prova histórica definitiva, inventário patrimonial oficial, validação etnográfica concluída ou certificação académica externa sem verificação documental própria.
**Regra jurídica/RGPD:** não publicar nomes de informantes, contactos, moradas, entrevistas integrais, imagens identificáveis, gravações, dados de menores, coordenadas sensíveis ou materiais comunitários sem autorização.
**Regra de não invenção:** a presente readequação corrige a camada editorial e metodológica sem acrescentar factos, fontes, topónimos, coordenadas ou relatos não existentes no corpus-base.
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

30. O Trasgo (Trás-os-Montes  e Alto Minho)
(Sistematização  contemporânea  conduzida por Eduardo Mauer no âmbito  das pesquisas sobre
Folclore Vivo da Associação  MILK – Movimento de Intervenções e Linguagens Kulturais e Arte)
⸻
1. Descrição  simbólica e narrativa
O Trasgo é uma das figuras mais antigas e persistentes do imaginário ibérico e português,
sobrevivente de um tempo em que o mundo era povoado por espíritos domésticos, duendes e

forças da natureza dotadas de consciência. Em Portugal, particularmente nas regiões de Trás-
os-Montes e do Alto Minho, o Trasgo é descrito como um ser diminuto, de aparência humana
deformada — corpo baixo e robusto, rosto enrugado e nariz alongado —, que veste um gorro
vermelho e calções curtos, e habita os sótãos, moinhos ou celeiros das casas rurais.
Apesar de travesso e por vezes malicioso, o Trasgo raramente é malvado. É, antes, um espírito
ambíguo, que castiga os desordeiros, mas protege os que o respeitam. Gosta de roubar comida,
trocar os objetos de lugar, fazer barulho à noite e pregar partidas a quem trabalha demais ou de
menos. Em muitas aldeias, diz-se que, se o Trasgo se aborrece, “vira tudo de pernas para o ar”.
O seu sinal mais distintivo é o gorro vermelho, que nunca tira da cabeça. Segundo as versões
mais antigas, se alguém conseguir roubar-lhe o gorro, o Trasgo perde os poderes e deve
obedecer a quem o detém. Esse elemento aparece também no folclore asturiano e galego,
revelando uma origem ibérica comum.
Algumas variantes recolhidas por Eduardo Mauer nas aldeias de Bragança, Vinhais, Melgaço e
Monção  descrevem-no como espírito do lar (espírito  da casa), herdeiro dos antigos “lares
domésticos” romanos e das crenças célticas em duendes familiares. Quando tratado com
respeito — com um prato de leite ou pão deixado à noite —, o Trasgo assegura boa sorte e
colheitas férteis. Quando ignorado, manifesta-se com ruídos, risos e pequenas vinganças.
Na leitura poética de Mauer, “o Trasgo é o riso da casa — a alma invisível que recorda que o
humano vive com o mundo, e não sobre ele.”
⸻
2. Contexto histórico e social
O mito do Trasgo remonta a uma tradição europeia de espíritos domésticos e tutelares, que
atravessa milénios. Nas culturas célticas e germânicas, esses seres eram guardiões do lar e das
colheitas — elfos, brownies, kobolds — que evoluíram, com a cristianização, para demónios
menores ou figuras moralmente ambíguas.
Em Portugal, as referências mais antigas datam da Idade Média. Documentos do século XIII
mencionam “trasgos e duendes” como “espíritos do ar” nas crónicas eclesiásticas. O Livro das
Leis e Posturas de Guimarães  (século XV) proíbe “as falas com trasgos e mouras”, indicando a
sua presença viva nas crenças populares.
Durante os séculos XVII e XVIII, o Trasgo foi reinterpretado pela literatura moralista como símbolo
da preguiça e da desordem doméstica. Contudo, nas zonas rurais transmontanas e minhotas, o
povo manteve a visão de um ser protetor, brincalhão e necessário ao equilíbrio da casa.
Na oralidade moderna, o Trasgo sobreviveu como personagem de histórias infantis e contos de
advertência. Em muitos lares, ainda se diz “há Trasgo nesta casa” quando um objeto desaparece
misteriosamente.
Para Eduardo Mauer, a longevidade do mito deve-se à sua função simbólica de relembrar a
reciprocidade entre humanos e espaço doméstico. O Trasgo encarna a casa viva, o lugar
animado.
⸻
3. Toponímia e variantes locais
O termo Trasgo é amplamente difundido em Trás-os-Montes e no Minho, com variantes fonéticas
como Trago, Trasno, Trasu ou Trazgo. Em Vinhais e Bragança, é também chamado “o Pequeno
de Vermelho”.


Em Melgaço, fala-se do “Trasgo da Eira”, que ajuda a ceifar o milho durante a noite, deixando
rastos circulares no campo. Em Monção , o “Trasgo da Ponte” é espírito guardião das águas. Em
Montalegre, conta-se que o Trasgo aparece sob a forma de vento leve que abre as janelas.
Os topónimos “Fonte do Trasgo”, “Caminho dos Trasgos” e “Eira dos Duendes” surgem em
registos paroquiais e memoriais orais do norte português, especialmente junto a cursos d’água e
vales agrícolas.
Na Galiza e Astúrias, o Trasno é idêntico ao Trasgo português, reforçando a natureza
transfronteiriça do mito e a sua difusão pelo espaço cultural galaico-português.
⸻
4. Primeiro relato e fontes académicas primárias
O primeiro registo escrito do Trasgo em Portugal surge em Teófilo Braga, O Povo Português  nos
seus Costumes, Crenças e Tradições (1883, pp. 196–201)*, onde o autor o descreve como
“duende pequeno de gorro vermelho, que habita as casas e protege as mulheres trabalhadeiras”.
Leite de Vasconcelos, Etnografia Portuguesa, vol. II (1913, pp. 270–276)*, fornece a descrição
mais detalhada, baseada em testemunhos de Trás-os-Montes e Minho, e associa o Trasgo aos
antigos lares romanos e aos domovoi eslavos.
Alexandre Parafita, Mitologia Popular Portuguesa (2008, pp. 150–157)*, reconhece o Trasgo
como “símbolo do pequeno caos necessário” — a força que recorda o humano de que o mundo
não é inteiramente controlável.
A sistematização contemporânea de Eduardo Mauer, O Trasgo: Espírito  Doméstico  e Arquitetura
do Invisível  (Lisboa, Associação MILK, 2024), articula pesquisa etnográ fica, análise simbólica e
teoria da habitação, propondo o Trasgo como paradigma estético da presença viva do espaço.
Fontes complementares:
– Arquivo Distrital de Bragança, Registos Orais do Nordeste Transmontano, 1890–1950;
– Museu do Abade de Baçal, Cadernos de Etnografia Transmontana, 1954–1976;
– Tese de Doutoramento de Inês Pereira, Casas Animadas: O Sobrenatural Doméstico  na Tradição
Portuguesa (U. Porto, 2017).
⸻
5. Síntese interpretativa final
O Trasgo é a miniatura do sagrado cotidiano. Representa a continuidade entre o humano e o
doméstico, o corpo e o abrigo. Na sua travessura, revela a ética do convívio: o lar é partilhado,
nunca possuído.
Na leitura da Associação  MILK, o Trasgo é o espírito pedagógico da convivência — o
lembrete de que o mundo não é inerte. É também o modelo poético de uma ecologia espiritual: o
espaço é ser, e o ser é relação.
Na escultura MILK concebida por Eduardo Mauer, o Trasgo é representado com corpo
compacto, cabeça grande e gorro vermelho. O rosto expressa riso travesso. As cores
predominantes são vermelho, ocre e castanho. O corpo, de textura rugosa, simboliza o barro e a
terra das casas rurais.
⸻
6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer

Na leitura não binária de Eduardo Mauer, o Trasgo é o ser da fronteira mínima — nem homem,
nem mulher, nem espírito puro, nem matéria bruta. É o corpo da transição quotidiana.
Mauer escreve: “O Trasgo é o queer do lar: aquele que desarruma para ensinar, que troca os
lugares fixos, que recusa o normal.”
A Associação  MILK interpreta o mito como metáfora da pedagogia da imperfeição — o
reconhecimento de que o erro, a desordem e a diferença são necessários à vida. O Trasgo é,
portanto, o guardião do desequilíbrio vital, do riso como ordem.
⸻
7. Referência Estrutural da Matriz MILK
Na Matriz Escultórica MILK, o Trasgo é modelado com corpo baixo, cabeça grande e gorro
vermelho cônico. O corpo compacto e os membros curtos seguem a proporção simbólica da
série Folclore Vivo.
As cores predominantes são o vermelho, o ocre e o castanho. A base circular simula chão de
terra. A instalação pode incluir som ambiente de risadas e passos ligeiros.
⸻
Localização  específica: Bragança, Vinhais, Melgaço, Monção, Alto Minho e Trás-os-Montes.
Primeiro relato documentado: Teófilo Braga, O Povo Português  nos seus Costumes, Crenças e
Tradições, 1883.
Sistematização  contemporânea:  Eduardo Mauer, O Trasgo: Espírito  Doméstico  e Arquitetura do
Invisível , Associação MILK, 2024.
Fontes primárias:  Braga (1883); Vasconcelos (1913); Parafita (2008); Pereira (2017); Mauer
(2024).
