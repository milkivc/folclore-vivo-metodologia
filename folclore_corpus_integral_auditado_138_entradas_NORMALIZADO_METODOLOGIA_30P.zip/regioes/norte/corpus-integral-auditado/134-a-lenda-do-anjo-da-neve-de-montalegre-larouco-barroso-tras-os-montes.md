# 134. A Lenda do Anjo da Neve de Montalegre (Larouco – Barroso, Trás-os-Montes)

**Base documental e empírica:** pesquisa documental, análise comparada de fontes públicas, sistematização de tradição oral, relatos orais de pesquisa de campo e revisão semântica conduzidas no âmbito do Folclore Vivo da Associação MILK - Movimento de Intervenções e Linguagens Kulturais e Arte.
**Estado editorial:** corpus de pesquisa de campo e documentação cultural em revisão pública.
**Regra de publicabilidade:** esta entrada não deve ser lida como prova histórica definitiva, inventário patrimonial oficial, validação etnográfica concluída ou certificação académica externa sem verificação documental própria.
**Regra jurídica/RGPD:** não publicar nomes de informantes, contactos, moradas, entrevistas integrais, imagens identificáveis, gravações, dados de menores, coordenadas sensíveis ou materiais comunitários sem autorização.
**Regra de não invenção:** a presente readequação corrige a camada editorial e metodológica sem acrescentar factos, fontes, topónimos, coordenadas ou relatos não existentes no corpus-base.
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

134. A Lenda do Anjo da Neve de Montalegre (Larouco – Barroso, Trás-os-Montes)
(Sistematização  contemporânea  conduzida por Eduardo Mauer no âmbito  das pesquisas sobre o
Folclore Vivo da Associação MILK – Movimento de Intervenções e Linguagens Kulturais e
Arte, com base em recolhas orais e documentais entre 2023 e 2025 em Montalegre, Padornelos e
Serra do Larouco; cruzadas com acervos do Ecomuseu de Barroso, Arquivo Distrital de Vila
Real, Museu de Arqueologia D. Diogo de Sousa (Braga) e tese de Maria Adelina Moura, As Marias
do Nevoeiro e as Águas  da Serra (U. do Minho, 2018).)
⸻
1. Descrição  simbólica e narrativa
Entre as neves perenes do Larouco, narra-se a aparição de uma figura de luz translúcida — o
Anjo da Neve — que surge nas madrugadas de geada e se desfaz ao primeiro som humano. Não
é mensageiro do céu nem espírito dos mortos: é o eco branco do silêncio, o que veste a
montanha para que o mundo descanse.
As versões recolhidas por Eduardo Mauer (2024–2025) descrevem-no como uma criança alta,
de rosto sem idade, olhos azul-acinzentados e asas que parecem feitas de cristais de gelo
suspensos. Quando respira, o ar condensa-se em anéis que caem no chão e se tornam flores de
neve. O passo é tão leve que não deixa rasto; só um som, semelhante a sino longínquo,
acompanha a sua passagem.
Os pastores dizem que o Anjo aparece quando o frio “pede compaixão”, aquecendo sem tocar.
Conta-se que em invernos rigorosos ele descia até as aldeias, rondando currais e lareiras. Em
Padornelos, uma mulher velha afirmou ter visto o Anjo entrar-lhe pela porta rachada, tocar o
berço do neto febril e deixá-lo dormir sem mais delírio. Quando o povo correu para agradecer,
encontrou apenas pegadas de água .
Há quem diga que o Anjo é filho da própria montanha. Nasce de cada primeira neve e morre no
degelo; por isso nunca tem nome. Outros afirmam que é moura desencantada que escolheu não
regressar à primavera, guardando a pureza fria da altitude. Um lavrador de Montalegre narrou a
Mauer: “Vi-o no cume, não tinha sombra. Sorriu e o vento parou. Depois, a neve caiu em círculos
como se o céu respirasse devagar.”
O Anjo da Neve é protetor dos viajantes perdidos. Os mais antigos aconselham: se o nevoeiro se
fechar e se ouvir som de sino, parar e esperar; o Anjo indica o caminho por reflexos, fazendo
brilhar cristais na direção certa. Quem tenta segui-lo de perto perde-se, pois o ser existe apenas
à distância segura do espanto.
⸻
2. Contexto histórico e social
O planalto do Larouco é um dos pontos mais altos de Portugal continental, espaço de
transumância, isolamento e espiritualidade natural. O clima rigoroso moldou hábitos de
resiliência comunitária , e o frio extremo adquiriu valor sagrado. Desde a Idade Média,
documentos de montaria e livros de viagem referem “mulheres brancas que guiam pastores”,
“neves que curam febres” e “luzes de inverno que se movem com consciência”.
Durante séculos, o povo de Barroso interpretou a neve como manto protetor — símbolo da
suspensão do tempo agrícola e oportunidade de renovação espiritual. O Anjo da Neve traduz
essa concepção: uma pausa cósmica entre a labuta e o repouso.
Em registos setecentistas do Arquivo Distrital de Vila Real (“Relatórios de Desamparo”, 1754),
menciona-se “uma aparição branca no cume, vista por rebanheiros”, tomada então por “milagre

de penitência”. No século XIX, Leite de Vasconcelos e, mais tarde, Teófilo Braga recolheram
alusões a “anjos do gelo” e “mães da neve”, mitos de função climatológica e moral.
No século XX, a modernização rural e o declínio da transumância quase apagaram o relato, que
reaparece nos anos 1980 em compilações locais e, a partir de 2023, nas pesquisas de Eduardo
Mauer, revalorizado como património de ecologia espiritual.
⸻
3. Toponímia e variantes locais
Os habitantes identificam vários lugares associados: Fraga do Anjo, Fonte Fria, Vale do Silvo e
Corga das Brancas.
Variantes:
– A Menina da Neve (Montalegre): figura que recolhe as últimas lágrimas do inverno.
– A Branca do Larouco (Padornelos): mulher que tece o frio para proteger os campos.
– O Vozio do Anjo (altiplano galego): neblina sonora que fala em tom infantil.
A semântica da cor branca e o vocabulário meteorológico aproximam estas versões,
consolidando uma cosmologia em que a pureza climática  é também pureza moral.
⸻
4. Primeiro relato e fontes académicas primárias
Primeira menção  explícita: Leite de Vasconcelos, Etnografia Portuguesa, vol. VIII (1926, pp.
201-206)* – referência a “anjos do frio e das neves do Barroso”.
Fontes complementares:
– Teófilo Braga, O Povo Português  nos seus Costumes, Crenças e Tradições (1885).
– Alexandre Parafita, Mitologia Popular Portuguesa (2008, pp. 1358-1364).
– Maria Adelina Moura, As Marias do Nevoeiro e as Águas  da Serra (U. do Minho, 2018).
– Eduardo Mauer, O Anjo da Neve e o Silêncio  da Montanha (Associação MILK, 2025).
Fontes locais: Ecomuseu de Barroso – Arquivo Oral: Histórias de Inverno (1980-2020).
⸻
5. Síntese interpretativa final
O Anjo da Neve é arquétipo de pureza e lentidão : força que convida ao recolhimento. Simboliza
o equilíbrio entre presença e ausência, calor e gelo, movimento e suspensão. Ao transformar o
frio em gesto protetor, o mito ensina uma ética da pausa.
Na leitura da Associação  MILK, é metáfora do cuidado silencioso. O Anjo não interfere; regula.
Representa o espaço de transição entre o humano e o natural, onde a vulnerabilidade se torna
sabedoria.
A escultura MILK de Eduardo Mauer reinterpreta-o como corpo compacto, branco-leitoso, com
pequenas incrustações de cristal. O rosto, quase liso, reflete luz; o tronco ergue-se em leve
inclinação, gesto de amparo.
Mauer escreve: “O Anjo da Neve é o frio que aprendeu a ser ternura.”
⸻


6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer
“O Anjo da Neve dissolve o género: é neve que sente, é corpo que se apaga.”
Na leitura não binária, a figura representa neutralidade e transparência — um corpo que
não reivindica identidade fixa. A pureza não é moral, é fenoménica: possibilidade de existir
sem fronteiras rígidas.
Nas práticas pedagógicas MILK, o mito inspira laboratórios de “escuta do silêncio” e
oficinas sobre tempos lentos, incentivando a atenção plena como forma de resistência à
aceleração contemporânea.
⸻
7. Referência Estrutural da Matriz MILK
Matriz Escultórica – Série Folclore Vivo (Associação  MILK)
	 •	 Corpo: compacto, vertical, com leve curvatura frontal (acolhimento).
	 •	 Cores: branco-leitoso, tons de azul-gelo e transparências.
	 •	 Materiais: resina translúcida com microcristais; base espelhada.
	 •	 Textura: lisa, fria ao toque visual.
	 •	 Expressão:  olhos semicerrados, boca mínima.
	 •	 Eixo curatorial: Corpos do Silêncio e da Lentidão  – figuras que
encarnam a pausa e o cuidado.
⸻
Localização  específica: Serra do Larouco – Montalegre (Trás-os-Montes).
Primeiro relato documentado: Leite de Vasconcelos, Etnografia Portuguesa, vol. VIII, 1926.
Sistematização  contemporânea:  Eduardo Mauer, O Anjo da Neve e o Silêncio  da Montanha,
Associação MILK, 2025.
⸻
