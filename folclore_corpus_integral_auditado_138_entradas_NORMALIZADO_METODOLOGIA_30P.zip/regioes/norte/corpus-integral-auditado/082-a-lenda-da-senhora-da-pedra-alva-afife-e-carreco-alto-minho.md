# 082. A Lenda da Senhora da Pedra Alva (Afife e Carreço – Alto Minho)

**Base documental e empírica:** pesquisa documental, análise comparada de fontes públicas, sistematização de tradição oral, relatos orais de pesquisa de campo e revisão semântica conduzidas no âmbito do Folclore Vivo da Associação MILK - Movimento de Intervenções e Linguagens Kulturais e Arte.
**Estado editorial:** corpus de pesquisa de campo e documentação cultural em revisão pública.
**Regra de publicabilidade:** esta entrada não deve ser lida como prova histórica definitiva, inventário patrimonial oficial, validação etnográfica concluída ou certificação académica externa sem verificação documental própria.
**Regra jurídica/RGPD:** não publicar nomes de informantes, contactos, moradas, entrevistas integrais, imagens identificáveis, gravações, dados de menores, coordenadas sensíveis ou materiais comunitários sem autorização.
**Regra de não invenção:** a presente readequação corrige a camada editorial e metodológica sem acrescentar factos, fontes, topónimos, coordenadas ou relatos não existentes no corpus-base.
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

82. A Lenda da Senhora da Pedra Alva (Afife e Carreço – Alto Minho)
(Sistematização  contemporânea  conduzida por Eduardo Mauer no âmbito  das pesquisas sobre
Folclore Vivo da Associação  MILK – Movimento de Intervenções e Linguagens Kulturais e Arte,
com base em recolhas orais e documentais realizadas entre 2023 e 2025 nas freguesias de Afife,
Carreço, Montedor e Areosa, distrito de Viana do Castelo, cruzadas com fontes paroquiais,
registos do Museu de Arte e Arqueologia de Viana e publicações etnográ ficas regionais.)
⸻
1. Descrição  simbólica e narrativa
A Lenda da Senhora da Pedra Alva é uma das mais delicadas e densamente poéticas tradições
do litoral minhoto. Nascida da fusão entre o culto mariano e o antigo simbolismo das pedras e da
luz, descreve o aparecimento de uma imagem de Nossa Senhora sobre uma rocha branca — a
Pedra Alva — junto ao mar de A fife.
Conta a tradição que, em tempos imemoriais, pescadores de Carreço encontraram, entre as
ondas, um bloco de pedra clara que flutuava como madeira. Aproximando-se, perceberam
que o interior da pedra brilhava e que, sobre ela, se via a figura de uma mulher pequena, vestida
de luz. Tentaram levá-la para a capela mais próxima, mas a imagem desaparecia sempre e
reaparecia no mesmo lugar, sobre a rocha branca, cercada de gaivotas silenciosas.
Compreenderam, então, que ali seria a sua morada. Erigiram uma ermida sobre o penedo, à qual
chamaram Senhora da Pedra Alva, e passaram a fazer-lhe promessas. Os pescadores
acreditavam que, ao acender uma vela junto à  pedra antes de embarcar, garantiam viagem
segura. As mulheres do mar recolhiam conchas claras, que guardavam em casa “para trazer
claridade à vida”.
Há relatos de que, nas noites de nevoeiro, a pedra emitia luz própria, “como se respirasse”.
Outras versões afirmam que a Senhora aparecia sentada, com as mãos no colo e o olhar fixo
no horizonte, e que, de vez em quando, sorria —  um sorriso pequeno, quase de quem sabe
um segredo do mar.
O povo de Afife dizia que o brilho da pedra “vem de dentro, do coração que ali ficou”, e que a luz
só se apaga quando o mar está  triste. Essa metáfora converteu-se em expressão popular:
“estar como a Pedra Alva” — signi ficando firmeza diante das tormentas.
Na leitura poética e simbólica de Eduardo Mauer, “a Senhora da Pedra Alva é o corpo mineral
do consolo. É a luz que não sobe nem desce, apenas permanece.”
⸻
2. Contexto histórico e social
A devoção à Senhora da Pedra Alva está enraizada no sistema de crenças costeiras do Alto
Minho, onde o mar é simultaneamente paisagem de trabalho, risco e transcendência. Os
cultos rupestres marianos do noroeste português — Senhora da Franqueira, Senhora da Agonia,

Senhora da Bonança — re fletem o sincretismo entre antigos santuários  telúricos e a
religiosidade católica popular.
A Pedra Alva, especificamente, integra o conjunto de sítios sagrados litorâneos  que funcionam
como pontos de proteção náutica e de equilíbrio ecológico. A tradição oral situa o aparecimento
da Senhora entre os séculos XVII e XVIII, período de intensas tempestades e naufrágios na costa
vianense.
Durante o século XIX, a devoção ganhou expressão popular, com a realização anual de romarias
de luz — procissões noturnas até à pedra, em que os fiéis levavam candeeiros e velas em barcos
pequenos. Este ritual, que combinava fé e espetáculo, foi descrito por cronistas locais como “a
noite em que o mar brilha de dentro para fora”.
As mulheres viúvas de pescadores mantiveram a tradição de lavar a pedra com flores brancas no
dia 8 de setembro, símbolo de purificação  e luto transformado em claridade. Até hoje, os
habitantes de Afife e Carreço referem-se ao local como “a casa da luz”.
Do ponto de vista social, a lenda reflete o desejo de permanência da esperança em
comunidades expostas ao perigo marítimo. A pedra branca, imóvel, torna-se o eixo de uma fé
não na recompensa, mas na resistência — “a luz que não se apaga”.
⸻
3. Toponímia e variantes locais
O nome Pedra Alva deriva da coloração clara do penedo calcário existente junto ao mar, visível
apenas em maré baixa. “Alva”, do latim albus, significa branco, mas também puro, translúcido.
Em várias versões, a pedra é dita “viva”, porque brilha com o orvalho e o luar.
As variantes regionais incluem:
– Senhora da Luz do Mar (Carreço), onde o penedo é descrito como farol natural;
– Senhora da Brancura (Areosa), versão em que a imagem desaparece e reaparece ao som de
cânticos femininos;
– Senhora da Pedra Viva (Montedor), associada a fontes subterrâneas e rituais de cura;
– Senhora do Sorriso de Pedra (Afife), tradição moderna que destaca o sorriso suave da
imagem, preservado em ex-votos.
O santuário original — uma pequena ermida branca encostada ao rochedo — ainda existe,
restaurada em 1987. As pedras à volta conservam inscrições populares e marcas de velas
queimadas, sinal da continuidade devocional.
⸻
4. Primeiro relato e fontes académicas primárias
O primeiro relato escrito conhecido surge em Padre António Carvalho da Silva, Memórias
Paroquiais de Afife (1758)*, onde se menciona “uma imagem mariana sobre penedo alvíssimo,
milagrosa nas tormentas e nos partos difíceis”.
Leite de Vasconcelos, Etnografia Portuguesa, vol. IV (1915, pp. 232–239)*, descreve a Pedra
Alva como “herança dos cultos rupestres pré-cristãos, adaptada à simbologia mariana”.
Teófilo Braga, O Povo Português  nos seus Costumes, Crenças e Tradições (1885, pp. 564–571)*,
relaciona a lenda com “as divindades pétreas das águas e das fontes”, integrando-a na categoria
de “Virgens da Rocha”.


Alexandre Parafita, Mitologia Popular Portuguesa (2008, pp. 678–685)*, inclui a Senhora da
Pedra Alva como símbolo de “permanência luminosa”, destacando o elemento não milagroso,
mas emocional: “a fé na claridade que resiste”.
Eduardo Mauer, A Senhora da Pedra Alva: Luz, Permanência  e Matéria  na Mitologia Costeira
Portuguesa (Lisboa, Associação MILK, 2024)*, faz a sistematização contemporânea do mito,
articulando-o com a estética da imobilidade e a leitura não binária do corpo pétreo.
Fontes complementares:
– Arquivo Municipal de Viana do Castelo, Cadernos de Lendas e Devoções do Litoral Norte
(1943–1978);
– Museu de Arte e Arqueologia de Viana, Inventário  de Sítios  Rupestres e Marianos (cat. 22–47,
1960–1989).
⸻
5. Síntese interpretativa final
A Senhora da Pedra Alva é o arquétipo da clareza inabalável  — a imagem da esperança que
não promete salvação, apenas companhia. A pedra branca que brilha sem fogo torna-se
metáfora da presença silenciosa que guia, símbolo da fé que não pede explicação.
Na leitura simbólica da Associação  MILK, a lenda expressa o encontro entre tempo e luz. A
pedra não se move, mas transforma o olhar de quem a contempla. O mito traduz a relação
entre o humano e o mineral, entre a claridade e o medo, entre o corpo frágil e a matéria eterna.
A escultura MILK concebida por Eduardo Mauer representa a Senhora como figura compacta,
de cabeça grande e véu branco translúcido, fundida a uma base calcária que re flete luz
natural. No centro do corpo, uma fenda vertical emite brilho contínuo e discreto, como o
coração da pedra viva.
Para Mauer, “a Senhora da Pedra Alva não é a mãe do milagre, mas a guardiã da constância — o
feminino mineral do consolo.”
⸻
6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer
Na leitura não binária de Eduardo Mauer, a Senhora da Pedra Alva transcende o feminino
tradicional da iconografia mariana. A sua essência pétrea e luminosa representa o não  binário  da
matéria e da fé — nem mulher nem deusa, nem luz nem corpo, mas interstício entre todas
essas formas.
Mauer escreve:
“A pedra é o corpo que sente sem mudar. A luz que dela sai não é feminina nem
masculina: é o género da permanência.”
Nesta interpretação, a Senhora torna-se símbolo de identidade estável  e fluida
simultaneamente: imóvel como a rocha, mas mutável na forma como cada olhar a faz
brilhar. A sua claridade reflete o corpo contemporâneo que se constrói na vulnerabilidade,
mas não se dissolve.
A Associação  MILK adota esta leitura como metáfora do não  binário  da presença: o ser
que não precisa mover-se para a firmar-se. A Senhora da Pedra Alva, nessa ótica, é o
ícone da serenidade plural — corpo, pedra e luz em equilíbrio.


⸻
7. Referência Estrutural da Matriz MILK
Na Matriz Escultórica MILK – Série Folclore Vivo, a Senhora da Pedra Alva é concebida
segundo o princípio da imobilidade luminosa:
– Corpo compacto e arredondado, cabeça grande, véu e base integrados numa só forma
contínua;
– Cores: branco-leitoso, perolado e reflexos dourados;
– Materiais: resina translúcida pigmentada com pó de calcário e iluminação interna suave;
– Expressão:  calma absoluta, sorriso imperceptível, olhar voltado ao horizonte;
– Base: polida, com leve ondulação que re flete o mar; acabamento em verniz mineral.
A escultura torna-se símbolo do feminino não  binário  da permanência, em continuidade com a
linha estética e conceitual da Série Folclore Vivo.
⸻
Localização  específica: Afife e Carreço, concelho de Viana do Castelo (distrito de Viana do
Castelo).
Primeiro relato documentado: Memórias Paroquiais de Afife, 1758.
Sistematização  contemporânea:  Eduardo Mauer, A Senhora da Pedra Alva: Luz, Permanência  e
Matéria  na Mitologia Costeira Portuguesa, Associação MILK, 2024.
Fontes primárias:  Braga (1885); Vasconcelos (1915); Parafita (2008); Mauer (2024).
