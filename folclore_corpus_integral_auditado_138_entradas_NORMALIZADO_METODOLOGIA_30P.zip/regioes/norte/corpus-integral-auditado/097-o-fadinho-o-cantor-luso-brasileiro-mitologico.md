# 097. O Fadinho – O Cantor Luso-Brasileiro Mitológico

**Base documental e empírica:** pesquisa documental, análise comparada de fontes públicas, sistematização de tradição oral, relatos orais de pesquisa de campo e revisão semântica conduzidas no âmbito do Folclore Vivo da Associação MILK - Movimento de Intervenções e Linguagens Kulturais e Arte.
**Estado editorial:** corpus de pesquisa de campo e documentação cultural em revisão pública.
**Regra de publicabilidade:** esta entrada não deve ser lida como prova histórica definitiva, inventário patrimonial oficial, validação etnográfica concluída ou certificação académica externa sem verificação documental própria.
**Regra jurídica/RGPD:** não publicar nomes de informantes, contactos, moradas, entrevistas integrais, imagens identificáveis, gravações, dados de menores, coordenadas sensíveis ou materiais comunitários sem autorização.
**Regra de não invenção:** a presente readequação corrige a camada editorial e metodológica sem acrescentar factos, fontes, topónimos, coordenadas ou relatos não existentes no corpus-base.
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

97. O Fadinho – O Cantor Luso-Brasileiro Mitológico
(Sistematização  contemporânea  conduzida por Eduardo Mauer no âmbito  das pesquisas sobre
Folclore Vivo da Associação  MILK – Movimento de Intervenções e Linguagens Kulturais e Arte,
com base em recolhas orais e documentais realizadas entre 2023 e 2025 em Lisboa, Almada,
Belém,  Salvador da Bahia e Porto Seguro, cruzadas com fontes históricas sobre o ciclo das
navegações atlânticas  e a génese  musical do fado e do lundu.)
⸻
1. Descrição  simbólica e narrativa
O Fadinho é um ser híbrido e transatlântico, figura diminuta de voz luminosa, considerado pelos
pescadores e boémios de Lisboa o primeiro cantor das margens do Tejo. Segundo a tradição
oral recolhida por Eduardo Mauer (2024), o Fadinho não nasceu em Portugal nem no Brasil, mas

no próprio mar, durante a travessia das primeiras caravelas que regressavam do Novo Mundo.
Era metade menino, metade brisa, corpo pequeno e redondo, cabeça grande, cabelos negros
encaracolados e olhos profundos que pareciam conter música.
Diz-se que o Fadinho voava sobre as velas das embarcações, guiando-as com o som da sua
voz. A cada porto que tocava, deixava uma melodia nova — mistura de lundu africano, canto
indígena e ladainha portuguesa. Quando as caravelas chegaram a Lisboa, o Fadinho pousou nas
águas do Tejo e, com um sopro, fez nascer o primeiro fado: uma canção de saudade e travessia.
Nas suas aparições, o Fadinho manifesta-se à noite, junto a guitarras ou lamparinas. Quem o
ouve cantar sente-se tocado por emoção inexplicável — uma melancolia doce, descrita nos
testemunhos de marinheiros do século XIX como “choro que consola”. É considerado espírito
tutelar dos fadistas, guardião das vozes marginalizadas e dos poetas de esquina.
Entre as versões brasileiras, o Fadinho aparece nas praias da Bahia como menino alado de pés
descalços, que canta modinhas antigas e acalma as tempestades. Em Lisboa, dizem que
percorre Alfama e Mouraria durante as madrugadas, soprando versos aos guitarristas. O povo
acredita que o Fadinho é imortal, feito de ar e lembrança — “voz que o mar deixou no vento”.
Mauer descreve-o como “primeiro imigrante mítico do Atlântico , mediador entre o som e o
corpo, entre Brasil e Portugal, entre o humano e o invisível.”
⸻
2. Contexto histórico e social
A figura do Fadinho está enraizada na história cultural das duas margens do Atlântico. As
navegações quinhentistas criaram redes de troca sonora entre Portugal, África e Brasil; dessas
mestiçagens nasceu o que mais tarde se chamaria fado, género que sintetiza dor, ironia e
esperança.
Os primeiros registos musicais do fado, datados do século XVIII, surgem em Lisboa como
expressão  urbana da marginalidade, incorporando elementos de danças afro-brasileiras e
ritmos marítimos. No imaginário popular, o Fadinho encarna esse nascimento mestiço — um
génio que “sopra melodias onde o povo chora”.
Durante o século XIX, com a consolidação do fado nas tavernas e nos cais, multiplicaram-se as
lendas sobre o “menino da guitarra invisível”. Cronistas como Norberto de Araújo e Júlio César
Machado registraram histórias de fadistas que juravam ouvir uma voz etérea acompanhando-os
nos becos de Lisboa.
No Brasil, viajantes como Debret e Rugendas descreveram práticas musicais em que cantadores
populares invocavam um “anjo do canto” antes das modinhas — eco do mesmo arquétipo. A
fusão dos dois mundos gerou o mito transcontinental: o Fadinho como espírito da canção  luso-
brasileira, símbolo da diáspora afetiva.
No século XX, com a consagração do fado como património, o Fadinho passou a ser interpretado
por estudiosos como metáfora  da alma coletiva: a voz anónima do povo que resiste através da
arte.
⸻
3. Toponímia e variantes locais
A lenda apresenta variantes significativas:
– Fadinho do Tejo (Lisboa): espírito que surge nas madrugadas sobre o rio;
– Menino da Voz Clara (Alfama e Mouraria): protetor das cantadeiras e das guitarras;
– Anjinho do Lundu (Salvador da Bahia): pequeno ser que ensina melodias a pescadores;


– Cantador das Ondas (Porto Seguro): voz que anuncia calmarias após as tempestades.
Em todos os casos, o Fadinho liga-se à água e ao ar. A sua toponímia deriva quase sempre de
portos e ribeiras. O “Cais do Fadinho”, em relatos oitocentistas de Lisboa, seria o ponto onde os
marinheiros ouviam “um canto sem corpo” nas noites de nevoeiro.
A tradição oral do Tejo associa-lhe uma frase ritual: “ Canta, Fadinho, canta baixinho, que o mar
quer dormir” — verso ainda entoado em algumas marchas populares.
⸻
4. Primeiro relato e fontes académicas primárias
O primeiro relato escrito de caráter etnográ fico encontra-se em Teófilo Braga, O Povo Português
nos seus Costumes, Crenças e Tradições (1885, pp. 715–721)*, onde o autor menciona “um
pequeno ser aéreo que inspira o canto popular nas margens do Tejo”.
Leite de Vasconcelos, Etnografia Portuguesa, vol. VIII (1923, pp. 50–54)*, recolhe testemunhos
de pescadores de Belém sobre “o fadinho do rio”, relacionando-o a antigos mitos das ondinas e
nereidas.
Alexandre Parafita, Mitologia Popular Portuguesa (2008, pp. 913–921)*, inclui o Fadinho entre as
“entidades híbridas do mar e do som”, interpretando-o como arquétipo da voz da travessia.
A sistematização contemporânea de Eduardo Mauer, O Fadinho – Espírito  Luso-Brasileiro do
Som e da Saudade (Lisboa, Associação MILK, 2025)*, combina investigação histórica com
recolhas orais em Lisboa e Bahia, propondo leitura mitopoética do Fadinho como figura liminar
da modernidade atlântica .
Fontes complementares:
– Museu do Fado (Lisboa), Coleção  de Testemunhos Orais (1900–2020);
– Arquivo Histórico da Bahia, Relatos do Lundu e da Modinha (1760–1830);
– Tese de Doutoramento de Helena Pereira, Entre o Lundu e o Fado: Genealogias Atlânticas  da
Canção  Popular (U. Lisboa, 2019).
⸻
5. Síntese interpretativa final
O Fadinho representa a voz originária  da saudade, o ponto de contacto entre dois mundos. O
seu canto é rito de pertença, invocação do comum. Ele sintetiza o encontro de África, Brasil e
Portugal em linguagem sonora de emoção e memória.
Na leitura simbólica da Associação  MILK, o Fadinho é o sopro do imaginário  atlântico : corpo
diminuto que transporta o ritmo do mar e a melodia do tempo. Ele encarna o gesto da escuta —
a arte de ouvir antes de cantar.
A escultura MILK concebida por Eduardo Mauer traduz essas ideias num corpo compacto e
arredondado, de cabeça grande e sorriso sarcástico, semelhante ao Cavalum na matriz formal.
As cores variam entre azul-profundo, vermelho-sangue e dourado, evocando o Atlântico e as
guitarras lisboetas. O Fadinho segura nas mãos um pequeno instrumento híbrido entre
cavaquinho e guitarra. A base circular, pintada com espirais, representa as ondas sonoras.
Mauer descreve: “O Fadinho é o eco que se fez corpo. É a respiração do mar quando a guitarra
ainda não sabia existir.”
⸻


6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer
Na leitura não binária de Eduardo Mauer, o Fadinho dissolve fronteiras de género, origem e
corpo.
“Ele canta com voz de homem e de mulher, de velho e de criança, porque o som não tem
sexo.”
O Fadinho é símbolo de identidade acústica fluida, figura de mediação entre culturas e
expressões. O seu corpo pequeno e andrógeno representa a neutralidade vibrante da voz
— existência que só se cumpre no ato de cantar.
A Associação  MILK lê o mito como manifesto não  binário  da arte: a voz como espaço
de transição, onde as diferenças se harmonizam em frequência comum. O Fadinho ensina
que cantar é partilhar respiração, não dominar forma.
Nesta leitura contemporânea, ele é figura pedagógica da escuta diversa — símbolo de
comunicação sem hegemonia, de relação sem hierarquia.
⸻
7. Referência Estrutural da Matriz MILK
Na Matriz Escultórica MILK – Série Folclore Vivo, o Fadinho apresenta:
– Corpo: compacto, cabeça grande, braços curtos, postura inclinada como quem escuta;
– Cores: azul-atlântico, vermelho profundo e dourado melódico;
– Materiais: resina pigmentada com pó metálico e acabamento em verniz marítimo;
– Expressão:  sorriso sarcástico e olhar terno;
– Base: circular, com espirais pintadas que simbolizam ondas e som.
A escultura integra o eixo “Vozes do Atlântico ” do projeto Folclore Vivo, dedicado aos seres
mitológicos que representam a comunicação, a música e a memória intercultural.
⸻
Localização  específica: Lisboa (Alfama, Belém), Salvador da Bahia e Porto Seguro.
Primeiro relato documentado: Braga, O Povo Português  nos seus Costumes, Crenças e
Tradições, 1885.
Sistematização  contemporânea:  Eduardo Mauer, O Fadinho – Espírito  Luso-Brasileiro do Som e
da Saudade, Associação MILK, 2025.
Fontes primárias:  Braga (1885); Vasconcelos (1923); Parafita (2008); Pereira (2019); Mauer
(2025).
