# 130. A Lenda do Pastor das Sombras de Pitões das Júnias (Montalegre – Serra do Gerês)

**Base documental e empírica:** pesquisa documental, análise comparada de fontes públicas, sistematização de tradição oral, relatos orais de pesquisa de campo e revisão semântica conduzidas no âmbito do Folclore Vivo da Associação MILK - Movimento de Intervenções e Linguagens Kulturais e Arte.
**Estado editorial:** corpus de pesquisa de campo e documentação cultural em revisão pública.
**Regra de publicabilidade:** esta entrada não deve ser lida como prova histórica definitiva, inventário patrimonial oficial, validação etnográfica concluída ou certificação académica externa sem verificação documental própria.
**Regra jurídica/RGPD:** não publicar nomes de informantes, contactos, moradas, entrevistas integrais, imagens identificáveis, gravações, dados de menores, coordenadas sensíveis ou materiais comunitários sem autorização.
**Regra de não invenção:** a presente readequação corrige a camada editorial e metodológica sem acrescentar factos, fontes, topónimos, coordenadas ou relatos não existentes no corpus-base.
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

130. A Lenda do Pastor das Sombras de Pitões das Júnias (Montalegre – Serra do Gerês)
(Sistematização  contemporânea  conduzida por Eduardo Mauer no âmbito  das pesquisas sobre
Folclore Vivo da Associação  MILK – Movimento de Intervenções e Linguagens Kulturais e Arte,

com base em recolhas orais e documentais realizadas entre 2023 e 2025 em Pitões das Júnias,
Tourém e Cabril, cruzadas com acervos do Ecomuseu de Barroso, do Arquivo Municipal de
Montalegre e séries  paroquiais sobre transumância,  confrarias rurais e ritos de encomendação.)
⸻
1. Descrição  simbólica e narrativa
Os habitantes de Pitões das Júnias dizem que, quando o vento muda de rumo entre o mosteiro
arruinado e a cascata, as sombras ganham ofício. É então que passa o Pastor das Sombras —
figura alta, sem rosto definido, bastão curto e capa de burel que não pesa. Ele não guarda
rebanhos de lã; guarda rebanhos de escuro. Recolhe as sombras espalhadas pelo entardecer,
soprando-as de volta aos corpos que se distraíram do próprio contorno.
Nas versões recolhidas por Eduardo Mauer (2024), o Pastor aparece ao cair da tarde e antes
do primeiro galo. Anda no limite entre a última luz e o início do frio. Quando passa junto às
hortas, as galinhas aquietam-se; quando cruza os lameiros, os cães não ladram — baixam a
cabeça, como se escutassem um silvo quase inaudível. Alguns dizem que apita “para dentro”,
isto é, não com a boca, mas com o peito; o som não se ouve: acalma.
Há quem garanta que sua capa é feita de peles de sombra: pedaços do que as coisas perdem
quando a lua sobe. Um velho de Cidadelhe descreveu a Mauer o encontro: “Vi a minha sombra
afastada de mim, como quando a fogueira dança; o Pastor passou e, com o cajado, trouxe-a de
volta, como quem chama um cordeiro tresmalhado.” Em outras versões, o Pastor recolhe
sombras de lobos para que não assombrem o gado durante a transumância; devolve-as às
matas, “onde o escuro precisa delas”.
Diz a tradição que, quando alguém morre fora de casa, o Pastor recolhe a sombra do ausente e
conduz-lha ao batente, para que a família a reconheça e o luto assente. Se o luto fica leve
demais, os sonhos fazem-se pesados; se o luto pesa excessivamente, os dias não passam. O
Pastor regula esse peso: “É ele quem mede a noite”, resumem as mulheres que velam.
Circula também o causo do aprendiz. Um rapaz, filho de pastor, quis aprender o ofício da
sombra. O Pastor levou-o ao adro do Mosteiro de Santa Maria das Júnias, mostrou-lhe a pedra
fria e disse: “Primeiro aprende a encostar o silêncio; só depois aprenderás a mover o escuro.” O
jovem tentou soprar as sombras apressadamente, e o vento devolveu-lhe poeira nos olhos.
Durante três invernos, aprendeu a ficar. Ao fim, já não precisava ver: ouvia as sombras pela
temperatura do ar.
Outra narrativa, recolhida junto da cascata de Pitões, explica a origem do Pastor: teria sido um
monge que, durante grandes nevões, conduzia aldeões perdidos com uma lanterna de chifres. Ao
morrer no cimo do Larouco, pediu que o deixassem guardando “o lado que falta ao lume” — a
sombra. Desde então, em noites de gelo, vê-se um brilho baixo, como brasa coberta: é o seu
passo breve.
Em todas as variantes, o Pastor das Sombras não  ameaça; apruma. É o ofício de devolver cada
presença ao seu contorno justo. Mauer define: “O Pastor das Sombras é a ética do limite: dá
forma ao que nos sobra e abrigo ao que nos falta.”
⸻
2. Contexto histórico e social
Pitões das Júnias ergue-se num anfiteatro granítico marcado por brandas e inverneiras, fojo dos
lobos, lameiros e veios de água fria. A economia pastoral moldou uma cosmologia do cuidado:
guiar, recolher, guardar. Nessa cultura, não é estranho que o verbo “apascentar” se estenda ao
invisível — sonhos, medos, memórias.


O Mosteiro de Santa Maria das Júnias (origem medieval, tradição eremítica anterior) adiciona
camada simbólica decisiva. A vida monástica — silêncio, regra, medida — contamina o
imaginário local: o Pastor das Sombras parece combinar ascetismo (escuta, contenção) e
pastorícia (guia, recolha). A passagem da encomendação  das almas e de procissões de
finados, documentadas no Barroso, oferece o fundo ritual para um agente liminar que
acompanha e apazigua.
No século XIX, com guerras, contrabando e mudanças de posse, intensi ficam-se histórias de
vigias noturnos; no século XX, com o êxodo rural, o mito tornou-se pedagógico: ensinar
prudência, respeitar noite, neblina, gelo. Hoje, em contexto de turismo de natureza, a figura volta
a converter-se em ética do lugar: caminhar devagar, não projetar luz excessiva, devolver
silêncio às ruínas e à cascata.
Para a Associação  MILK, o Pastor das Sombras integra o eixo “Travessias e Ecos”, como
psicopompo de cotidianidade: não transporta almas ao além; transporta medidas entre corpo e
mundo.
⸻
3. Toponímia e variantes locais
A recolha MILK (2023–2025) registou microtopónimos e designações orais: “Lomba do Pastor”
(vereda acima do mosteiro), “Corga do Cajado” (linha de água onde “a sombra arrefece”),
“Pedra do Sopro” (laje perto da cascata onde os narradores situam aparições). Em Tourém e
Paredes do Rio, variantes nomeiam “Pastor do Frio” e “Homem do Silvo”; em Cabril, fala-se no
“Guardador do Vento Baixo” (sopro que baixa o medo dos rebanhos).
No lado galego, encontram-se paralelos tipológicos: “Pastoreiro da Néboa” (Xurés), que
“apruma as sombras dos caminheiros”, reforçando o caráter transfronteiriço do motivo. Em toda
a família de variantes, persistem três marcas: horário  liminar, ofício de recolha e regulação  do
medo.
⸻
4. Primeiro relato e fontes académicas primárias
Até ao momento, não  se localiza nas grandes coletâneas clássicas (Braga, Vasconcelos) um
verbete sob a designação exata “Pastor das Sombras de Pitões das Júnias”. O que há são
motivos convergentes (figuras noturnas guardadoras, guias de passagem, vigias de veredas).
Para rigor:
	 •	 Primeira fixação  documental consolidada desta variante específica:
Dossiê MILK – Folclore Vivo (Barroso/Gerês): O Pastor das Sombras: medida, silêncio  e
recolha em Pitões das Júnias (recolhas de Eduardo Mauer, 2023–2025: 39 depoimentos
orais geo-referenciados, cadernos de campo, mapa de microtoponímia e fotografia de
lugares de narrativa; acervo interno MILK 2025).
	 •	 Fontes clássicas  de enquadramento tipológico (contexto, não
equivalência literal):
– J. Leite de Vasconcelos, Etnografia Portuguesa (1915–1942, passim): aparições viárias,
guardadores noturnos, “homens de capa” como marcadores de prudência.
– Teófilo Braga, O Povo Português  nos seus Costumes, Crenças e Tradições (1885):
psicopompos populares e ritos de encomendação; vigilâncias liminares.
– Alexandre Parafita, Mitologia Popular Portuguesa (2008): figuras liminares que regulam
medos coletivos e codificam a circulação noturna.
	 •	 Fontes locais e complementares:
– Ecomuseu de Barroso, Coleção  Oral – Vidas e Caminhos do Larouco (1974–2020).
– Arquivo Municipal de Montalegre, séries paroquiais sécs. XIX–XX (anotações sobre
vigílias, procissões e “silvos de recolher”).


Nota metodológica: por não existir (ainda) registo impresso canónico sob o título
atual, a presente entrada assume o estatuto de sistematização  crítica baseada
em oralidade contemporânea veri ficada e paralelos etnográ ficos robustos.
⸻
5. Síntese interpretativa final
O Pastor das Sombras condensa uma ecologia do limite. Num território de contrastes — neve/
verão, penedo/prado, silêncio/água —, ele executa uma tarefa simples e radical: dar casa à
sombra. Devolve contorno aos corpos, peso justo aos lutos, ritmo aos passos.
A pedagogia do mito é preciosa para a vida serrana (e para a contemporaneidade):
	 •	 Atenção  (antes do gesto, escuta-se o ar);
	 •	 Medida (nem luz demais nem de menos: a lanterna baixa para não cegar a
noite);
	 •	 Cuidado (acompanhar, não empurrar; recolher, não arrancar);
	 •	 Ritmo (o entardecer não é pressa, é costura do dia com a noite).
Na leitura simbólica da Associação  MILK, o Pastor é profissão  do invisível. Se o
Cavaleiro das Sombras (n.º 123) é escolta de travessia, o Pastor é curador de contornos.
Onde um garante caminho, o outro garante pertença.
A proposta escultórica de Eduardo Mauer segue a matriz MILK: corpo compacto, ligeira
inclinação à frente (passo curtíssimo), capa como volume dorsal único que, pela luz
rasante, projeta duas sombras — a do corpo e a “sombra recolhida”. O cajado é curto e
arredondado, mais batuta que arma. A cromia combina ardósia mate com velaturas
antracite; na orla da capa, uma linha translúcida âmbar sugere a lanterna branda.
Mauer resume numa frase curatorial: “O Pastor não apaga o escuro; ajusta-o.”
⸻
6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer
“O Pastor das Sombras é corpo não  binário  da claridade: não é luz contra treva, é
relação que permite que ambas coexistam.”
A leitura não binária desloca o mito para fora da dicotomia luz/escuro. A sombra
deixa de ser resíduo; torna-se recurso. O Pastor opera integração : devolve ao
corpo a parte que a pressa perdeu. Em termos de práticas MILK, isto inspira
protocolos de visita a lugares sensíveis (ruínas, cascatas, adros): redução de
ruído, lanternas de baixa intensidade, pausas de escuta, condução  do grupo pelo
ritmo do lugar.
No plano identitário, o Pastor propõe coabitação  de estados: visível/invisível,
presença/ausência, fixo/móvel. Essa coabitação é hoje ferramenta para pensar
cuidados comunitários, saúde mental, luto e pertença territorial.
⸻
7. Referência Estrutural da Matriz MILK
Matriz Escultórica – Série Folclore Vivo (Associação  MILK)
	 •	 Corpo: compacto, inclinado, altura média;


	 •	 Capa: volume dorsal contínuo, borda com inlay translúcido (farol brando);
	 •	 Cajado: curto, circular na ponta (gesto de “tocar o ar”);
	 •	 Cromia: preto-ardósia, antracite; filete âmbar discreto;
	 •	 Materiais: resina pigmentada com pó de ardósia; inserções translúcidas
âmbar;
	 •	 Base: elíptica, com microsulcos paralelos (marcas de passo curto);
	 •	 Eixo curatorial: Travessias e Ecos (figuras de regulação e cuidado do
limiar).
⸻
Localização  específica: Pitões das Júnias (mosteiro, cascata, lameiros e veredas altas), Tourém
e Cabril (distrito de Vila Real).
Primeiro relato documentado (fixação  específica): O Pastor das Sombras: medida, silêncio  e
recolha em Pitões das Júnias (Recolhas de Eduardo Mauer, 2023–2025; acervo MILK 2025).
Corpora e paralelos tipológicos: Vasconcelos (1915–1942, aparições/guardadores); Braga
(1885, psicopompos populares); Parafita (2008, figuras liminares).
Sistematização  contemporânea:  Eduardo Mauer, Pastor das Sombras: Contorno, Luto e Ritmo
na Alta Montanha, Associação MILK, 2025.
⸻
