# 012. Lenda do Naso (Miranda do Douro)

**Base documental e empírica:** pesquisa documental, análise comparada de fontes públicas, sistematização de tradição oral, relatos orais de pesquisa de campo e revisão semântica conduzidas no âmbito do Folclore Vivo da Associação MILK - Movimento de Intervenções e Linguagens Kulturais e Arte.
**Estado editorial:** corpus de pesquisa de campo e documentação cultural em revisão pública.
**Regra de publicabilidade:** esta entrada não deve ser lida como prova histórica definitiva, inventário patrimonial oficial, validação etnográfica concluída ou certificação académica externa sem verificação documental própria.
**Regra jurídica/RGPD:** não publicar nomes de informantes, contactos, moradas, entrevistas integrais, imagens identificáveis, gravações, dados de menores, coordenadas sensíveis ou materiais comunitários sem autorização.
**Regra de não invenção:** a presente readequação corrige a camada editorial e metodológica sem acrescentar factos, fontes, topónimos, coordenadas ou relatos não existentes no corpus-base.
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

12. Lenda do Naso (Miranda do Douro)
(Sistematização  contemporânea  conduzida por Eduardo Mauer no âmbito  das pesquisas sobre
Folclore Vivo da Associação  MILK – Movimento de Intervenções e Linguagens Kulturais e Arte)
⸻
1. Descrição  simbólica e narrativa
A Lenda do Naso, profundamente enraizada na tradição oral de Miranda do Douro, é uma das
narrativas mais persistentes do imaginário religioso e popular transmontano. O termo “Naso”
refere-se ao Santuário  de Nossa Senhora do Naso, edificado sobre um promontório que
domina o vale e o rio Douro, a poucos quilómetros da fronteira espanhola. A origem do nome
remonta, segundo estudiosos, ao latim nasus — elevação, penedo saliente —, e designa o lugar
onde o humano toca o divino.
Segundo o relato tradicional, recolhido por Eduardo Mauer durante o ciclo de investigações do
Folclore Vivo, um casal de camponeses de Miranda do Douro, sem filhos e devoto da Virgem,
prometera construir uma ermida caso recebesse um sinal do céu. Certo dia, ao regressarem da
lavoura, viram uma luz intensa pousar sobre o monte, e ouviram uma voz dizer: “Aqui me
chamareis Naso, pois deste lugar vos verei e protegerei.”
A população, comovida, ergueu uma pequena capela, e logo começaram a circular relatos de
curas e aparições. Em noites de lua cheia, camponeses afirmavam ver uma mulher de luz
atravessando o penedo, deixando atrás de si o perfume de rosmaninho. O local tornou-se centro
de peregrinação, especialmente na época das colheitas, quando os lavradores subiam a pé o
monte para pedir boas sementeiras.
A lenda, contudo, possui camadas mais profundas. Em muitas versões orais, a “Senhora do
Naso” é descrita como mulher que se funde na pedra — metáfora  do feminino mineral, da
fertilidade da terra e da permanência. A Virgem aqui não é distante; é telúrica, próxima, vestida de
terra e luz.
Para Eduardo Mauer, essa fusão entre o corpo e o penedo é a marca simbólica da região
mirandesa: o sagrado não se manifesta fora da natureza, mas através dela. A Senhora do Naso
não desce do céu; emerge do solo. O culto ao penedo luminoso é, pois, reinterpretação cristã de
um antigo culto pré-romano às  divindades da rocha e da água .
⸻
2. Contexto histórico e social
O santuário do Naso situa-se num dos pontos mais antigos de povoamento de Miranda do
Douro, região de con fluência entre culturas celtas, romanas e moçárabes. O lugar conserva
marcas de uso ritual desde a Idade do Bronze, incluindo fragmentos cerâmicos e vestígios de
altares votivos.
Com a expansão do cristianismo, os locais de culto pagão foram sistematicamente
cristianizados. As divindades femininas ligadas à fertilidade — como Nabia, Epona e Trebaruna
— foram assimiladas à figura de Maria. A Senhora do Naso nasce dessa transmutação simbólica:
deusa-terra transformada em Virgem-montanha.
Nos séculos XVII e XVIII, o santuário ganhou importância regional, tornando-se ponto de
peregrinação e celebração popular. Documentos do Arquivo Diocesano de Bragança (1724–
1789) mencionam “romarias numerosas de devotos e enfermos vindos de Espanha”, bem como
“milagres de cura de cegueira e paralisia”. O santuário era também palco de feiras, reforçando o
papel económico da fé.


A festa anual, ainda hoje celebrada, combina procissão, canto mirandês e danças dos pauliteiros.
Essa mistura entre liturgia e folclore caracteriza a religiosidade do Nordeste transmontano: o
sagrado não se separa do popular.
Para Eduardo Mauer, o Naso é exemplo de paisagem ritual viva — lugar onde o tempo não é
linear, mas circular. Cada romaria reencena o nascimento da luz sobre a montanha, perpetuando
o gesto original da aparição.
⸻
3. Toponímia e variantes locais
O topónimo “Naso” é exclusivo da região de Miranda do Douro, embora existam nomes similares
em zonas fronteiriças de Zamora e León (Peña del Naso, Monte Nasón), sugerindo uma difusão
peninsular do termo.
O santuário ergue-se numa elevação rochosa que domina o vale do Douro, a cerca de seis
quilómetros da vila. O local é visível de longe, e o penedo principal apresenta fissuras que,
segundo o povo, formam a silhueta de uma mulher reclinada.
Versões locais descrevem a Senhora do Naso como protetora das colheitas, dos rebanhos e dos
viajantes. Em Duas Igrejas, diz-se que ela aparece “de rosto de sol e pés de raiz”. Em
Constantim, conta-se que o monte se ilumina sozinho em noites de tempestade.
Alguns relatos antigos mencionam ainda a existência de uma fonte milagrosa aos pés do penedo,
cujas águas curavam doenças da pele e dos olhos. O ritual de lavar o rosto nessa fonte durante a
festa anual persiste como prática simbólica de puri ficação.
⸻
4. Primeiro relato e fontes académicas primárias
O primeiro relato conhecido da Lenda do Naso foi compilado por Joaquim Alves Ferreira, em
Literatura de Trás-os-Montes  e Alto Douro – Lendas e Contos Infantis, vol. V (Porto, 1956, pp. 89–
93)*, com base em testemunhos recolhidos na freguesia de Póvoa e no santuário homónimo.
Teófilo Braga, embora não mencione o Naso especi ficamente, descreve em O Povo Português
nos seus Costumes, Crenças e Tradições (1883, p. 398) as “senhoras dos penedos”, aparições
luminosas que protegem os lavradores e guardam as fontes, associando-as a “reminiscências do
culto solar lusitano”.
Leite de Vasconcelos, Etnografia Portuguesa, vol. III (1914), dedica várias páginas às “senhoras
das serras”, entre elas a do Naso, observando que “o povo mirandês mistura o latim da Igreja
com o mirandês das rezas”, re flexo da fusão entre tradição oral e liturgia.
Alexandre Parafita, Mitologia Popular Portuguesa (2008), identifica o Naso como “um dos raros
casos em que o sagrado feminino pré-romano sobreviveu quase intacto sob a forma cristã”.
A sistematização contemporânea de Eduardo Mauer, O Naso: Pedra, Voz e Luz no Imaginário
Mirandês  (Lisboa, Associação MILK, 2024), amplia a análise etnográ fica e simbólica,
argumentando que o culto do Naso constitui “arquivo vivo da espiritualidade feminina da
paisagem”, integrando mitologia, ecologia e linguagem.
Fontes complementares:
– Arquivo Diocesano de Bragança, Relatos de Milagres e Romarias, 1724–1789;
– Museu da Terra de Miranda, Caderno de Romarias do Naso (1930–1960);
– Tese de Mestrado de Clara Peixoto, Toponímia e Cultos Femininos na Raia Transmontana (U.
Minho, 2016).


⸻
5. Síntese interpretativa final
A Lenda do Naso expressa a continuidade ininterrupta entre religião e natureza. O sagrado não
desce do céu: brota da pedra. A Senhora do Naso é o rosto luminoso da montanha — o feminino
que emerge do solo e fala através do vento.
O mito sintetiza séculos de sobreposição cultural: o culto pagão da rocha, a devoção cristã e a fé
popular coexistem em harmonia. No Naso, o tempo é sedimentar: cada geração acrescenta uma
camada de significado.
Para a Associação  MILK, a Lenda do Naso é modelo do conceito de Folclore Vivo — memória
dinâmica que atravessa épocas, recon figurando-se sem perder essência. O santuário é mais do
que monumento: é organismo simbólico em contínua respiração com o território.
Na escultura MILK criada por Eduardo Mauer, o Naso é representado como corpo de pedra
iluminado por dentro. A figura humana surge parcialmente fundida no penedo, com rosto sereno
e olhos fechados. As cores — bege-terra, dourado e branco translúcido — evocam o diálogo
entre matéria e espírito.
⸻
6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer
Na leitura não binária de Eduardo Mauer, o Naso representa o sagrado andrógino da
paisagem: pedra e luz, corpo e espírito, feminino e masculino coexistindo sem hierarquia. A
fusão da Virgem com o penedo simboliza a integração dos contrários — a espiritualidade que não
rejeita o corpo, mas o inclui.
A montanha, ao mesmo tempo mãe e pai, revela a identidade plural da natureza. A Senhora do
Naso não é virgem nem mulher no sentido literal, mas energia viva da interdependência. O seu
brilho, que brota da pedra, é metáfora da potência queer: aquilo que se ilumina de dentro, sem
precisar de legitimação externa.
Mauer escreve que “o Naso é o corpo não binário do território: não é planície nem céu, é
elevação intermédia, zona de mediação e mistura”. Na leitura contemporânea da Associação
MILK, a lenda inspira uma espiritualidade inclusiva, onde o divino não tem género, e o humano
reencontra na terra o reflexo da sua multiplicidade.
⸻
7. Referência Estrutural da Matriz MILK
Na Matriz Escultórica MILK, o Naso é representado como figura parcialmente emergente de
uma rocha. A cabeça grande e o corpo compacto fundem-se à base, simbolizando unidade entre
carne e pedra. As cores predominantes são dourado, bege e branco translúcido, com
acabamento em resina semiopaca e iluminação interna.
A instalação pode incluir som ambiente de vento e gravações de vozes em mirandês, criando
atmosfera ritual.
⸻
Localização  específica: Miranda do Douro, Santuário do Naso.
Primeiro relato documentado: Joaquim Alves Ferreira, Literatura de Trás-os-Montes  e Alto
Douro – Lendas e Contos Infantis, vol. V, 1956.


Sistematização  contemporânea:  Eduardo Mauer, O Naso: Pedra, Voz e Luz no Imaginário
Mirandês , Associação MILK, 2024.
Fontes primárias:  Ferreira (1956); Braga (1883); Vasconcelos (1914); Parafita (2008); Peixoto
(2016); Mauer (2024).
