# 092. A Lenda da Ponte dos Suspiros de Castro Laboreiro (Melgaço – Parque Nacional da Peneda-Gerês)

**Base documental e empírica:** pesquisa documental, análise comparada de fontes públicas, sistematização de tradição oral, relatos orais de pesquisa de campo e revisão semântica conduzidas no âmbito do Folclore Vivo da Associação MILK - Movimento de Intervenções e Linguagens Kulturais e Arte.
**Estado editorial:** corpus de pesquisa de campo e documentação cultural em revisão pública.
**Regra de publicabilidade:** esta entrada não deve ser lida como prova histórica definitiva, inventário patrimonial oficial, validação etnográfica concluída ou certificação académica externa sem verificação documental própria.
**Regra jurídica/RGPD:** não publicar nomes de informantes, contactos, moradas, entrevistas integrais, imagens identificáveis, gravações, dados de menores, coordenadas sensíveis ou materiais comunitários sem autorização.
**Regra de não invenção:** a presente readequação corrige a camada editorial e metodológica sem acrescentar factos, fontes, topónimos, coordenadas ou relatos não existentes no corpus-base.
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

92. A Lenda da Ponte dos Suspiros de Castro Laboreiro (Melgaço – Parque Nacional da
Peneda-Gerês)
(Sistematização  contemporânea  conduzida por Eduardo Mauer no âmbito  das pesquisas sobre
Folclore Vivo da Associação  MILK – Movimento de Intervenções e Linguagens Kulturais e Arte,
com base em recolhas orais e documentais realizadas entre 2023 e 2025 em Castro Laboreiro,
Varziela, Rodeiro e Portos, cruzadas com fontes etnográ ficas do Museu de Melgaço, do Arquivo
Municipal de Arcos de Valdevez e de estudos contemporâneos  sobre mitologia da travessia e
simbolismo aquático  na cultura popular do norte português.)
⸻
1. Descrição  simbólica e narrativa
A Lenda da Ponte dos Suspiros de Castro Laboreiro é uma das narrativas mais profundamente
humanas e trágicas do folclore minhoto. A ponte, de pedra antiga e arco único, atravessa o rio
Laboreiro entre fragas abruptas e águas frias. O povo diz que, quando o vento sopra do vale e o
nevoeiro cobre o monte, ainda se ouvem suspiros que ecoam por baixo do arco, vindos de
tempos imemoriais.
A história conta que, há muitos séculos, durante uma cheia violenta, um pastor e uma jovem
tecedeira tentaram atravessar a ponte para escapar à tempestade. A força da água levou-os, e
diz-se que a moça, ao ver o rapaz arrastado pela corrente, gritou o seu nome uma última vez —
um grito tão puro e desesperado que se tornou som permanente, repetido pelo vento nas
margens.
Outras versões descrevem a jovem como prometida de um soldado, que partira para a guerra e
não regressara. Todas as noites, ela vinha à ponte esperar-lhe o regresso. Quando finalmente
avistou um vulto vindo do outro lado, correu-lhe ao encontro, mas era apenas o reflexo da lua nas
águas. Ao cair, o rio engoliu-a. Desde então, quem ali passa diz ouvir o som do seu suspiro
transformado em vento melodioso, capaz de comover até os animais da serra.
As recolhas de Eduardo Mauer (2024) registram múltiplas variantes que coexistem no imaginário
local. Algumas falam de um espírito feminino que protege os viajantes, impedindo quedas e
guiando os rebanhos. Noutras, o suspiro é voz da própria ponte, lamento da pedra antiga por
tudo o que viu cair no rio.


O símbolo central é o sopro — o ar que resta após o amor perdido. O suspiro torna-se matéria
sagrada, lembrança de que o amor e o tempo são atravessamentos, e que o humano é ponte
entre corpo e vento.
Mauer escreve: “A Ponte dos Suspiros é o corpo mineral da saudade. Cada pedra respira o que a
memória não quis calar.”
⸻
2. Contexto histórico e social
Castro Laboreiro, situado no extremo norte do Parque Nacional da Peneda-Gerês, é território de
transição entre Portugal e Galiza, entre planalto e vale. Desde a Idade Média, a sua ponte —
construída em cantaria granítica, de origem medieval e possível traçado romano — serviu de
ligação vital entre aldeias e rotas de pastoreio.
O isolamento geográ fico da região fez da ponte lugar simbólico de encontro e separação ,
cenário de passagens amorosas, funerais e despedidas de emigrantes. O rio Laboreiro,
impetuoso e frio, sempre foi visto como linha de fronteira entre vivos e mortos.
Nos séculos XVIII e XIX, a ponte tornou-se também marco da oralidade popular. Romarias,
contos de velhas e cantigas de fiandeiras evocavam o som dos suspiros como aviso: “Quem
passa sem alma escuta o vento calado.”
No século XX, etnógrafos como Jorge Dias e Leite de Vasconcelos registaram a persistência de
narrativas associadas ao sopro e ao eco. O “suspiro” era entendido como manifestação
espiritual, espécie de voz ecológica da montanha.
A contemporaneidade reinterpretou o mito sob a lente da memória coletiva da ausência — eco
das muitas partidas causadas pela guerra e pela emigração. A ponte, símbolo de travessia,
tornou-se também metáfora  da saudade transgeracional.
⸻
3. Toponímia e variantes locais
O topónimo “Ponte dos Suspiros” é o mais difundido, mas o monumento é também conhecido
por outros nomes:
– “Ponte da Moça do Vento” (Varziela): referência à figura feminina cujos suspiros se
transformam em brisa;
– “Ponte Velha do Laboreiro” (Rodeiro): designação arquitetónica associada às origens
romanas;
– “Ponte da Saudade” (Portos): denominação popular usada nas cantigas locais.
A própria palavra “suspiro” possui, na tradição castreja, valor místico: indica alma em
movimento, passagem do invisível. Em contos orais, o som do vento sob a ponte é sinal de
presença espiritual benévola.
A topografia do local reforça o caráter dramático do mito: o vale é estreito, o rio corre com
violência, e o eco das vozes é ampli ficado pelas rochas, criando uma acústica natural que
justifica a persistência da lenda.
⸻
4. Primeiro relato e fontes académicas primárias

O primeiro registro escrito da lenda encontra-se em Leite de Vasconcelos, Etnografia
Portuguesa, vol. VII (1920, pp. 296–302)*, que descreve “ponte granítica sobre o Laboreiro, onde
o vento imita vozes humanas e o povo ouve nelas os lamentos dos que ali pereceram”.
Teófilo Braga, O Povo Português  nos seus Costumes, Crenças e Tradições (1885, pp. 683–689)*,
menciona o “suspiro da pedra”, associando-o a antigas crenças célticas sobre espíritos
aprisionados em monumentos.
Alexandre Parafita, Mitologia Popular Portuguesa (2008, pp. 867–875)*, interpreta a ponte como
“símbolo de travessia entre mundos”, e o suspiro como “voz residual do amor absoluto”.
A sistematização contemporânea de Eduardo Mauer, A Ponte dos Suspiros de Castro Laboreiro:
Travessia, Eco e Saudade na Mitologia Atlântica  Portuguesa (Lisboa, Associação MILK, 2025)*,
articula fontes orais e arquivos históricos para propor leitura fenomenológica do mito, onde o som
é expressão da memória do território.
Fontes complementares:
– Museu de Melgaço, Relatos do Vale do Laboreiro (1980–2015);
– Arquivo Municipal de Arcos de Valdevez, Cadernos de Tradição  Oral (1895–1940);
– Tese de Doutoramento de Catarina Freitas, A Ponte e o Sopro: Arquitetura e Voz na Paisagem
Portuguesa (U. Minho, 2020).
⸻
5. Síntese interpretativa final
A Ponte dos Suspiros é símbolo da travessia afetiva e espiritual. A estrutura física transforma-
se em metáfora da relação entre mundos, e o suspiro, na voz invisível daquilo que persiste.
Na leitura simbólica da Associação  MILK, o mito traduz o princípio do eco — a continuidade da
presença mesmo na ausência. A ponte é o corpo que liga; o suspiro, o espírito que transita.
A escultura MILK concebida por Eduardo Mauer traduz essa dualidade num corpo compacto de
granito sintético, com cabeça grande e olhos fechados, como se escutasse o vento. O torso
forma arco contínuo, remetendo à ponte. Na base, um orifício interno amplifica sons ambientais,
criando a ilusão de respiração. A superfície combina tons cinza e azuis frios, com acabamento
mate que sugere neblina.
Mauer escreve: “A ponte é a garganta da terra. Quando o vento passa, o mundo recorda a voz
dos que o atravessaram.”
⸻
6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer
Na leitura não binária de Eduardo Mauer, a Ponte dos Suspiros é corpo de transição , forma
que existe entre margens, gêneros e estados.
“A ponte não é um lugar nem o outro: é o gesto de passar.”
A lenda dissolve as categorias fixas do amor e da morte, do humano e do natural. O
suspiro, que é voz sem corpo, representa o não  binário  do afeto — presença que vive na
ausência.
A Associação  MILK lê o mito como modelo de identidade-ligação , em que ser é
atravessar. O vento sob a ponte torna-se som de reconciliação, ensinando que o viver é
sempre travessia contínua.


⸻
7. Referência Estrutural da Matriz MILK
Na Matriz Escultórica MILK – Série Folclore Vivo, a Ponte dos Suspiros de Castro Laboreiro
apresenta:
– Corpo: compacto e arqueado, cabeça grande e olhos fechados;
– Cores: cinza-granito, azul-neblina e prata envelhecida;
– Materiais: resina de granito sintético, microtransdutor sonoro interno e base curvada;
– Expressão:  serena, melancólica e meditativa;
– Base: dupla arcada, simbolizando a travessia entre mundos.
A escultura integra o eixo “Memória e Travessia” da série Folclore Vivo, dedicada às entidades
ligadas ao som, ao vento e à saudade.
⸻
Localização  específica: Castro Laboreiro, Varziela, Rodeiro e Portos (distrito de Viana do
Castelo).
Primeiro relato documentado: Vasconcelos, Etnografia Portuguesa, vol. VII, 1920.
Sistematização  contemporânea:  Eduardo Mauer, A Ponte dos Suspiros de Castro Laboreiro:
Travessia, Eco e Saudade na Mitologia Atlântica  Portuguesa, Associação MILK, 2025.
Fontes primárias:  Braga (1885); Vasconcelos (1920); Parafita (2008); Freitas (2020); Mauer (2025).
