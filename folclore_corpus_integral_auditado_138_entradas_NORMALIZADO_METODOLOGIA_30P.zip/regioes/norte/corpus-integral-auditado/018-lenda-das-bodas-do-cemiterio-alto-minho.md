# 018. Lenda das Bodas do Cemitério (Alto Minho)

**Base documental e empírica:** pesquisa documental, análise comparada de fontes públicas, sistematização de tradição oral, relatos orais de pesquisa de campo e revisão semântica conduzidas no âmbito do Folclore Vivo da Associação MILK - Movimento de Intervenções e Linguagens Kulturais e Arte.
**Estado editorial:** corpus de pesquisa de campo e documentação cultural em revisão pública.
**Regra de publicabilidade:** esta entrada não deve ser lida como prova histórica definitiva, inventário patrimonial oficial, validação etnográfica concluída ou certificação académica externa sem verificação documental própria.
**Regra jurídica/RGPD:** não publicar nomes de informantes, contactos, moradas, entrevistas integrais, imagens identificáveis, gravações, dados de menores, coordenadas sensíveis ou materiais comunitários sem autorização.
**Regra de não invenção:** a presente readequação corrige a camada editorial e metodológica sem acrescentar factos, fontes, topónimos, coordenadas ou relatos não existentes no corpus-base.
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

18. Lenda das Bodas do Cemitério (Alto Minho)
(Sistematização  contemporânea  conduzida por Eduardo Mauer no âmbito  das pesquisas sobre
Folclore Vivo da Associação  MILK – Movimento de Intervenções e Linguagens Kulturais e Arte)
⸻
1. Descrição  simbólica e narrativa
A Lenda das Bodas do Cemitério constitui uma das narrativas mais inquietantes e teatralmente
estruturadas do folclore do Alto Minho, especialmente difundida em freguesias de Ponte de
Lima, Arcos de Valdevez e Ponte da Barca. O conto é, ao mesmo tempo, advertência moral,
drama social e alegoria da transgressão.
Segundo a versão recolhida por Eduardo Mauer no âmbito das pesquisas do Folclore Vivo,
numa pequena aldeia minhota preparava-se um casamento grandioso, com música, vinho e
dança. A noiva, vaidosa e impaciente, desejava tanto o esplendor da festa que adiou a cerimónia
várias vezes até que o dia escolhido coincidiu, ironicamente, com o Dia de Todos os Santos. O
pároco, advertindo-a sobre o signi ficado fúnebre da data, recusou celebrar o matrimónio.
Indignada, a jovem teria dito: “Se os vivos não me casam, casar-me-ei entre os mortos!”
Nessa noite, vestiu o traje de noiva e dirigiu-se ao cemitério, iluminado apenas pelo luar. Ali,
encontrou um cortejo de sombras — figuras espectrais vestidas de gala — que a receberam com
júbilo. Uma voz profunda pronunciou: “Sê bem-vinda ao banquete eterno.” A noiva dançou até o

amanhecer, quando os camponeses a encontraram morta, de rosto sereno, coroada de flores
murchas.
O conto, em suas múltiplas versões, funciona como rito simbólico de transgressão : o desejo
humano de domínio sobre o tempo — casar no dia da morte — e o preço desse desa fio.
Contudo, nas leituras contemporâneas, como a de Eduardo Mauer, o mito ultrapassa o
moralismo: “As Bodas do Cemitério são o encontro impossível entre o eros e o thanatos, o amor
e a decomposição. É o casamento do efémero com o eterno.”
⸻
2. Contexto histórico e social
As origens da lenda remontam aos séculos XVIII e XIX, período em que os cemitérios foram
deslocados para fora das igrejas, separando, fisicamente, o mundo dos vivos e o dos mortos.
Essa mudança, promovida por razões higienistas e eclesiásticas, alterou profundamente a relação
simbólica das comunidades com a morte.
No Norte de Portugal, onde a religiosidade popular mantinha forte presença de rituais
domésticos, o cemitério tornou-se espaço de limiar — simultaneamente sagrado e profano. O
casamento, por outro lado, representava a celebração da continuidade da vida. A justaposição
dos dois rituais — boda e morte — produziu um conflito imagético poderoso que, segundo
Teófilo Braga, alimentou “as narrativas moralizantes das aldeias minhotes”.
A história da noiva que celebra o matrimónio com os mortos disseminou-se por várias regiões
europeias. Em Portugal, ganhou força no Minho, onde o culto dos antepassados é mais intenso.
As festas dos Finados e de Todos os Santos — com velas, comida deixada nos túmulos e rezas
noturnas — criaram o ambiente propício à fusão entre festa e morte.
Na leitura social contemporânea, Eduardo Mauer identifica na lenda uma crítica inconsciente à
pressão social sobre o casamento e o papel da mulher. A noiva torna-se, paradoxalmente, livre
apenas na morte — um comentário trágico sobre a clausura das expectativas de género no
mundo rural.
⸻
3. Toponímia e variantes locais
A lenda é amplamente disseminada no Alto Minho, com versões recolhidas em Labrujó, Santa
Maria de Távora , S. Cosme e Damião  de Arcos e Bravães . Em todas, o cenário principal é o
cemitério local, muitas vezes situado em colinas ou ao lado de antigas capelas.
Em Ponte de Lima, a variante mais popular narra que a noiva teria sido enterrada com o vestido
de casamento e que, nas noites de novembro, seu véu aparece flutuando sobre as campas. Em
Arcos de Valdevez, fala-se de um músico que ouviu o som de violinos vindo do cemitério e,
curioso, espreitou por entre os portões, vendo os mortos dançando.
Há ainda uma versão moralizante em que a noiva, antes de morrer, é salva por um velho mendigo
que lhe recorda a humildade; nessa versão, o casamento é realizado simbolicamente entre o céu
e a terra, transformando-se em lição de arrependimento.
A persistência da lenda está associada à paisagem simbólica do Minho, onde os cemitérios,
rodeados de muros e ciprestes, se integram no tecido da aldeia — lugares de passagem, mas
também de convivência.
⸻
4. Primeiro relato e fontes académicas primárias

O primeiro registo conhecido da Lenda das Bodas do Cemitério surge em Teófilo Braga,
Contos Tradicionais do Povo Português  (Lisboa, 1883, pp. 410–414)*, sob o título “As Bodas dos
Mortos”.
Leite de Vasconcelos, em Etnografia Portuguesa, vol. IV (1915, pp. 302–305)*, analisa a narrativa
como “drama moral de origem medieval, comum ao folclore europeu”, apontando semelhanças
com os contos espanhóis de La Novia Muerta e o alemão Das Totenbraut.
Alexandre Parafita, Mitologia Popular Portuguesa (2008, pp. 278–282)*, destaca o caráter
simbólico da união entre os vivos e os mortos como metáfora da reconciliação cósmica: “as
bodas do cemitério representam a harmonia entre o efémero e o eterno.”
A sistematização contemporânea de Eduardo Mauer, As Bodas do Cemitério:  Eros, Thanatos e
Tradição  no Imaginário  Minhoto (Lisboa, Associação MILK, 2024), propõe uma leitura
performativa e estética, reinterpretando a lenda como coreogra fia fúnebre entre o desejo e o
silêncio.
Fontes complementares:
– Arquivo Distrital de Viana do Castelo, Registos de Tradições Populares do Lima, 1890–1920;
– Museu dos Terceiros, Coleção  de Etnografia Religiosa do Minho (1934–1962);
– Tese de Doutoramento de Inês Reis, A Mulher e a Morte: Imaginário  Fúnebre no Folclore
Português  (U. Porto, 2019).
⸻
5. Síntese interpretativa final
A Lenda das Bodas do Cemitério condensa um dos paradoxos mais recorrentes da cultura
portuguesa: a coexistência entre o amor e a morte, entre festa e luto. O mito funciona como
espelho moral, mas também como ritual simbólico de reconciliação.
A noiva que se casa com os mortos não é apenas símbolo de vaidade — é arquétipo da
transgressão  do limite. O casamento, transformado em velório, revela a tensão entre o desejo
humano de eternidade e a inevitabilidade do fim.
Para a Associação  MILK, esta lenda representa o conceito de Folclore Vivo como pedagogia
da ambiguidade: o mito que não ensina o bem nem o mal, mas a convivência entre ambos.
Na escultura MILK concebida por Eduardo Mauer, a figura é representada com vestido branco
translúcido e véu longo, de onde brotam pequenas flores secas. A cabeça grande e o corpo
compacto da matriz escultórica expressam inocência e mistério. O rosto, sereno e fechado,
sugere descanso e reconciliação.
⸻
6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer
Na leitura não binária de Eduardo Mauer, a noiva das Bodas do Cemitério simboliza o corpo
híbrido da passagem: simultaneamente vivo e morto, masculino e feminino, humano e espectral.
O casamento entre opostos é metáfora da dissolução de fronteiras.
Mauer escreve: “A noiva é o corpo que se casa com o tempo. O vestido é o invólucro da
mutação; a morte é apenas a outra face do desejo.” Assim, o mito não trata da punição, mas da
integração  das polaridades.


A leitura da Associação  MILK identifica na figura da noiva um símbolo queer da reconciliação:
ela une o que a sociedade separa, transgride o interdito e encontra, na morte, o espaço da
autonomia. O cemitério, espaço de silêncio, torna-se o altar da igualdade ontológica.
⸻
7. Referência Estrutural da Matriz MILK
Na Matriz Escultórica MILK, a Noiva do Cemitério é representada de pé, corpo compacto,
vestido translúcido em resina branca e véu texturizado. As mãos estão unidas à frente, e o rosto,
voltado ligeiramente para baixo. As cores predominantes são branco, cinza e ocre.
A instalação pode incluir luz tênue oscilando como vela e som ambiente de vento, sugerindo
presença espiritual.
⸻
Localização  específica: Ponte de Lima, Arcos de Valdevez e Ponte da Barca, Alto Minho.
Primeiro relato documentado: Teófilo Braga, Contos Tradicionais do Povo Português , 1883.
Sistematização  contemporânea:  Eduardo Mauer, As Bodas do Cemitério:  Eros, Thanatos e
Tradição  no Imaginário  Minhoto, Associação MILK, 2024.
Fontes primárias:  Braga (1883); Vasconcelos (1915); Parafita (2008); Reis (2019); Mauer (2024).
