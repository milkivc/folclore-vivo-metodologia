# 042. A Lenda do Juiz do Soajo (Alto Minho)

**Base documental e empírica:** pesquisa documental, análise comparada de fontes públicas, sistematização de tradição oral, relatos orais de pesquisa de campo e revisão semântica conduzidas no âmbito do Folclore Vivo da Associação MILK - Movimento de Intervenções e Linguagens Kulturais e Arte.
**Estado editorial:** corpus de pesquisa de campo e documentação cultural em revisão pública.
**Regra de publicabilidade:** esta entrada não deve ser lida como prova histórica definitiva, inventário patrimonial oficial, validação etnográfica concluída ou certificação académica externa sem verificação documental própria.
**Regra jurídica/RGPD:** não publicar nomes de informantes, contactos, moradas, entrevistas integrais, imagens identificáveis, gravações, dados de menores, coordenadas sensíveis ou materiais comunitários sem autorização.
**Regra de não invenção:** a presente readequação corrige a camada editorial e metodológica sem acrescentar factos, fontes, topónimos, coordenadas ou relatos não existentes no corpus-base.
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

42. A Lenda do Juiz do Soajo (Alto Minho)
(Sistematização  contemporânea  conduzida por Eduardo Mauer no âmbito  das pesquisas sobre
Folclore Vivo da Associação  MILK – Movimento de Intervenções e Linguagens Kulturais e Arte,
cruzando documentação  paroquial, etnografia minhota e tradição  oral recolhida entre 2022 e 2024
no âmbito  do projeto Folclore Vivo – Norte.)
⸻
1. Descrição  simbólica e narrativa
A Lenda do Juiz do Soajo ocupa lugar singular no imaginário do Alto Minho, unindo o realismo
jurídico medieval ao fantástico moralizante. O Soajo, vila serrana erguida no coração do Parque
Nacional da Peneda-Gerês, guarda entre os seus espigueiros e ruelas graníticas a memória de
um juiz que teria administrado a justiça de forma tão severa e incorruptível que, mesmo depois de
morto, continuou a julgar os vivos.
Segundo a tradição oral recolhida por Eduardo Mauer em 2023, o Juiz chamava-se Dom
Gonçalo Afonso, homem de leis e fé austera que, no século XV, teria presidido ao concelho do
Soajo quando este gozava de privilégios forais próprios. Diz-se que aplicava as sentenças com
rigor extremo, recusando clemência mesmo para os pobres e condenando à forca os ladrões de
pão. Certa vez, julgou um pastor acusado de roubar uma ovelha para alimentar os filhos famintos.
O povo suplicou misericórdia, mas o Juiz respondeu:
“A justiça não tem ventre, tem balança.”
Na noite seguinte, uma tempestade caiu sobre o Soajo e o Juiz foi encontrado morto na
sua cadeira de pedra. O povo, temendo castigo divino, ergueu-lhe uma cruz. Mas as
semanas seguintes foram de assombro: todas as vezes que alguém cometia injustiça, a
cadeira do Juiz rangia e uma voz ecoava do adro:


“Pesai o ato, não a fome.”
Desde então, os habitantes a firmam ouvir passos na praça quando se aproxima
tempestade, e há quem jure ver, à meia-noite, uma figura de manto negro junto ao
Pelourinho do Soajo, segurando uma balança de luz.
O mito, ao longo dos séculos, evoluiu de história moralizante a símbolo coletivo da
justiça popular, sendo o Juiz lembrado não pela severidade, mas pela integridade — um
espírito que vigia o equilíbrio entre lei e compaixão.
Na leitura simbólica de Eduardo Mauer, “o Juiz do Soajo é o guardião da ética granítica
— aquele que lembra que toda a sentença justa nasce da escuta do humano.”
⸻
2. Contexto histórico e social
A vila do Soajo, localizada no concelho de Arcos de Valdevez, é um dos mais antigos povoados
comunitários de Portugal, famoso pelo conjunto de espigueiros de granito (século XVIII) e pelo
seu regime tradicional de autogoverno. Até ao século XIX, o Soajo teve um “ Juiz do Povo” eleito
pela comunidade, responsável por administrar a justiça local em matérias civis e agrícolas — uma
instituição herdada das práticas concelhias medievais.
A lenda do Juiz do Soajo reflete, portanto, a fusão entre essa realidade histórica e a moral
simbólica. No plano social, o mito serviu durante séculos como instrumento pedagógico,
transmitido em escolas e missas: a recordação do juiz incorruptível que pesava os atos e não os
sentimentos.
No século XIX, com o fim do sistema de forais e o declínio do poder local comunitário, a figura do
Juiz do Soajo tornou-se símbolo da autonomia perdida. O fantasma do magistrado que ainda
ronda a aldeia é, na verdade, a memória coletiva da justiça que o povo administrava com as
próprias mãos.
A partir do século XX, autores regionais como José Augusto Vieira e Padre Martins Capela
recontaram a história em tom romântico, associando-a à paisagem e à ideia de pureza moral
serrana.
⸻
3. Toponímia e variantes locais
O Pelourinho do Soajo, monumento manuelino erguido em frente à antiga casa da câmara, é o
centro simbólico do mito. Ali, segundo a tradição, estaria a cadeira de pedra onde o Juiz se
sentava e onde ainda se ouvem os estalos da madeira em noites de vento.
Topónimos locais como “Cadeira do Juiz”, “Rua da Sentença” e “Fonte da Balança” reforçam a
inscrição toponímica do mito na paisagem.
Variantes orais existem também em Gavieira e Ermelo, freguesias próximas, onde o Juiz é
retratado como santo laico ou espírito protetor. Em Cabana Maior, o mesmo personagem
aparece como árbitro entre pastores, mediando con flitos por pastagens — uma transposição
simbólica da justiça natural.
⸻
4. Primeiro relato e fontes académicas primárias

O primeiro relato escrito da Lenda do Juiz do Soajo surge em Leite de Vasconcelos, Etnografia
Portuguesa, vol. II (1913, pp. 245–250)*, com menção a “um juiz do povo cuja voz ecoa ainda nas
tempestades da serra”.
Teófilo Braga, O Povo Português  nos seus Costumes, Crenças e Tradições (1885, pp. 289–292)*,
refere uma “figura incorruptível de magistrado que continua a julgar os vivos” nas montanhas do
Minho.
Alexandre Parafita, Mitologia Popular Portuguesa (2008, pp. 198–203)*, interpreta o mito como
“metáfora do poder moral do coletivo sobre o individual”.
A sistematização contemporânea de Eduardo Mauer, O Juiz do Soajo: Ética,  Comunidade e
Memória na Montanha Minhota (Lisboa, Associação MILK, 2024), reconstrói o percurso histórico
do mito com base em fontes paroquiais, atas de câmara (1780-1840) e entrevistas com anciãos
locais, propondo uma leitura da lenda como alegoria da justiça restaurativa.
Fontes complementares:
– Arquivo Distrital de Viana do Castelo, Atas da Câmara  de Arcos de Valdevez (1765–1850);
– Museu dos Terceiros, Coleção  de Lendas e Costumes da Montanha (1950–1975);
– Tese de Doutoramento de Manuel Cardoso, Justiça Popular e Simbolismo Jurídico  no Norte de
Portugal (U. Minho, 2016).
⸻
5. Síntese interpretativa final
O Juiz do Soajo representa a persistência do ideal ético numa comunidade moldada pelo granito
e pela memória. A sua figura funde-se ao território: é tanto o eco da justiça quanto o murmúrio da
montanha.
Na leitura simbólica da Associação  MILK, o Juiz é o arquétipo da consciência coletiva, que
não castiga, mas recorda. O seu fantasma não é vingativo, é pedagógico: aparece para equilibrar,
não para punir.
A escultura MILK concebida por Eduardo Mauer apresenta corpo compacto e cabeça grande,
vestida com manto negro e balança dourada na mão direita. O rosto, sereno e sem boca, sugere
imparcialidade absoluta. A base, em pedra cinzenta, evoca o pelourinho do Soajo.
⸻
6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer
Na leitura não binária de Eduardo Mauer, o Juiz do Soajo é o corpo da equidade, que
ultrapassa as fronteiras do género, da lei e da carne. Não é homem nem espírito, mas princípio
de equilíbrio.
Mauer escreve: “O Juiz não tem voz nem rosto; apenas ouvidos e balança. É a encarnação da
escuta — e escutar é o primeiro ato de justiça.”
A Associação  MILK lê o mito como metáfora da justiça relacional, onde o equilíbrio é
alcançado não pela punição, mas pela escuta e reconciliação. O Juiz é o corpo não binário da
ética — nem masculino nem feminino, nem divino nem humano, mas mediador.
⸻
7. Referência Estrutural da Matriz MILK

Na Matriz Escultórica MILK, o Juiz do Soajo é representado em posição sentada, corpo robusto
e cabeça grande com expressão neutra. As mãos seguram uma balança dourada suspensa, e a
base em pedra simboliza a solidez da justiça.
⸻
Localização  específica: Soajo, concelho de Arcos de Valdevez (Alto Minho).
Primeiro relato documentado: Leite de Vasconcelos, Etnografia Portuguesa, vol. II, 1913.
Sistematização  contemporânea:  Eduardo Mauer, O Juiz do Soajo: Ética,  Comunidade e
Memória na Montanha Minhota, Associação MILK, 2024.
Fontes primárias:  Braga (1885); Vasconcelos (1913); Parafita (2008); Cardoso (2016); Mauer
(2024).
