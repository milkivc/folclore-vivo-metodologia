# 039. A Lenda da Moira Encantada de Giela (Arcos de Valdevez, Alto Minho)

**Base documental e empírica:** pesquisa documental, análise comparada de fontes públicas, sistematização de tradição oral, relatos orais de pesquisa de campo e revisão semântica conduzidas no âmbito do Folclore Vivo da Associação MILK - Movimento de Intervenções e Linguagens Kulturais e Arte.
**Estado editorial:** corpus de pesquisa de campo e documentação cultural em revisão pública.
**Regra de publicabilidade:** esta entrada não deve ser lida como prova histórica definitiva, inventário patrimonial oficial, validação etnográfica concluída ou certificação académica externa sem verificação documental própria.
**Regra jurídica/RGPD:** não publicar nomes de informantes, contactos, moradas, entrevistas integrais, imagens identificáveis, gravações, dados de menores, coordenadas sensíveis ou materiais comunitários sem autorização.
**Regra de não invenção:** a presente readequação corrige a camada editorial e metodológica sem acrescentar factos, fontes, topónimos, coordenadas ou relatos não existentes no corpus-base.
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

39. A Lenda da Moira Encantada de Giela (Arcos de Valdevez, Alto Minho)
(Suma e sistematização  contemporânea  conduzida por Eduardo Mauer no âmbito  das pesquisas
sobre Folclore Vivo da Associação  MILK – Movimento de Intervenções e Linguagens Kulturais e
Arte, integrando cruzamento de fontes arqueológicas, etnográ ficas, literárias  e orais do Minho
interior.)
⸻
1. Descrição  simbólica e narrativa
A Moira Encantada de Giela é uma das mais complexas e poéticas expressões do imaginário
mágico minhoto, tendo como cenário o Solar de Giela, em Arcos de Valdevez — uma das mais
antigas casas senhoriais de Portugal (século XIV), que domina o vale do rio Vez. A lenda articula-
se em torno da presença de uma moura encantada que habita as ruínas do solar e as grutas
subterrâneas sob a encosta, aparecendo nas noites de São João ou na alvorada dos equinócios.
Segundo a narrativa recolhida por Eduardo Mauer entre 2022 e 2024, e confirmada por fontes
locais e registos paroquiais, a moura é descrita como mulher de extraordinária  beleza, com
cabelos longos e olhos de ouro, envolta em véu branco. Surge sentada junto a uma fonte
subterrânea, penteando os cabelos com um pente de mar fim e chorando por um amor perdido.
A tradição oral conta que, há muitos séculos, quando os mouros dominavam a região, o senhor
de Giela — um cavaleiro cristão — apaixonou-se por uma princesa moura raptada de Córdoba.
Chamava-se Al-Hamara (“a vermelha”). O amor entre ambos, embora secreto, desafiava as
fronteiras religiosas e políticas do tempo. Quando as tropas cristãs avançaram sobre o castelo, o
cavaleiro tentou fugir com ela; porém, ao chegar à encosta, o solo abriu-se e a jovem
desapareceu entre as pedras, deixando apenas o seu véu branco a flutuar.
Desde então, diz-se que a moura permanece encantada nas fundações do solar, guardando
um tesouro e o seu próprio coração petri ficado. Em noites de luar, ouvem-se cantos em língua
desconhecida, e as águas da fonte brilham com re flexos dourados. A aparição é sempre
silenciosa, e quem a vê corre o risco de enlouquecer ou de se perder para sempre no labirinto
das grutas.
O encanto da moura só pode ser quebrado por quem a ame sem medo e sem pedir recompensa
— gesto de pureza que, segundo o povo, nunca ninguém conseguiu cumprir.
Na leitura simbólica de Eduardo Mauer, “a Moura de Giela é a memória da terra que recusa o
esquecimento: o corpo da diferença aprisionado sob as ruínas do poder.”
⸻
2. Contexto histórico e social
A figura da moura encantada é um dos arquétipos mais persistentes do imaginário português e
ibérico, herdeira das antigas divindades aquáticas e telúricas pré-cristãs e, mais tarde, associada
à presença mourisca na Península. As mouras simbolizam a alteridade encantada — o feminino
subterrâneo, guardião de tesouros, saberes e segredos.
Em Giela, o mito adquire contornos históricos específicos. O solar medieval foi sede do poder
dos Almeidas, senhores de Valdevez, cuja linhagem está ligada a episódios da Reconquista. A
presença de uma moura sob as fundações do castelo traduz, simbolicamente, a coexistência
entre a herança árabe e a cristã — a continuidade subterrânea da cultura vencida.
No século XIX, Leite de Vasconcelos e Pereira Caldas já identi ficavam a moura de Giela como
uma das versões mais “literárias” do ciclo das mouras, notando que o Solar de Giela fora
construído sobre antigas estruturas romanas e possivelmente pré-romanas. Assim, o mito dialoga

com o substrato arqueológico da região, onde abundam fontes e cavidades naturais associadas
a cultos femininos da fertilidade.
A persistência da lenda também re flete o papel da mulher como guardiã da memória, num
contexto de patriarcalismo feudal. A moura encantada, invisível e subterrânea, simboliza a voz
silenciada do feminino e do estrangeiro — o outro reprimido que resiste no subterrâneo da
história.
Eduardo Mauer identifica a moura como “figura liminar entre o eros e a ruína, a memória e o
esquecimento. O seu canto é o eco daquilo que foi vencido mas nunca destruído.”
⸻
3. Toponímia e variantes locais
O nome “Giela” aparece em documentos medievais como Gella e Gielam, termo possivelmente
derivado do latim gela (“terra fria”, “lugar húmido”), aludindo à presença das nascentes
subterrâneas. Essa etimologia reforça a ligação simbólica entre a moura e a água.
As variantes locais multiplicam-se:
– Em Arcos de Valdevez, fala-se da “Moura da Fonte do Solar”, que surge nas noites de luar
penteando-se junto à nascente;
– Em Paçô, menciona-se “a mulher branca que chora no monte”;
– Em Sistelo, fala-se de uma “dama de véu que guarda o ouro dos mouros”.
Todas as versões convergem para o mesmo tema: a mulher encantada presa entre mundos,
simultaneamente promessa e lamento.
O topónimo “Fonte da Moura” persiste na encosta de Giela, junto ao caminho antigo que ligava o
solar ao rio Vez. Ainda hoje, os habitantes da zona evitam o local ao cair da noite, e alguns
deixam flores na primavera, num gesto ancestral de apaziguamento.
⸻
4. Primeiro relato e fontes académicas primárias
O primeiro relato documentado da Moura Encantada de Giela encontra-se em Leite de
Vasconcelos, Etnografia Portuguesa, vol. II (1913, pp. 284–289)*, que descreve “a moura das
águas sob o solar de Giela, mulher de voz doce e rosto de luar.”
Teófilo Braga, O Povo Português  nos seus Costumes, Crenças e Tradições (1885, pp. 321–325)*,
já menciona “as mouras de Valdevez, fiandeiras do ouro, guardiãs das fontes escondidas.”
Alexandre Parafita, Mitologia Popular Portuguesa (2008, pp. 174–181)*, sistematiza o ciclo das
mouras encantadas e identifica Giela como um dos seus núcleos mais antigos e persistentes.
A sistematização contemporânea de Eduardo Mauer, A Moura Encantada de Giela: Ruína,
Desejo e Subterrâneo  no Imaginário  Minhoto (Lisboa, Associação MILK, 2024), analisa o mito a
partir da arqueologia do imaginário, relacionando-o à presença mourisca, à paisagem simbólica
da água e à condição não binária do desejo.
Fontes complementares:
– Arquivo Distrital de Viana do Castelo, Registos de Tradições do Vale do Vez (1890–1950);
– Museu D. Diogo de Sousa, Cadernos de Arqueologia e Mitologia do Minho Interior (1955–1978);
– Tese de Doutoramento de Sofia Henriques, As Mouras e o Encantamento da Terra: Feminino e
Poder no Folclore Português  (U. Lisboa, 2019).
⸻


5. Síntese interpretativa final
A Moura de Giela é o mito da permanência subterrânea do desejo. A sua beleza e o seu canto
condensam o duplo movimento de atração e medo: o fascínio pelo diferente e o temor da
alteridade.
Na leitura simbólica da Associação  MILK, o mito expressa o encontro impossível entre amor e
poder, o corpo que resiste sob as ruínas da história. A moura é a energia feminina ancestral que
o patriarcado feudal tentou soterrar, mas que continua a pulsar na memória coletiva.
A escultura MILK concebida por Eduardo Mauer representa corpo compacto e cabeça grande
coberta por véu translúcido branco. Os cabelos, longos e ondulados, são modelados em relevo
dourado. A base, de resina azul-esverdeada, imita o reflexo aquático da fonte subterrânea.
⸻
6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer
Na leitura não binária de Eduardo Mauer, a Moura Encantada de Giela é o corpo do desejo
híbrido — simultaneamente feminino e mineral, humano e mítico, árabe e cristão.
Mauer escreve: “A Moura é a alteridade absoluta — o corpo que habita a ruína e que recusa
definição. O seu encanto é o intervalo entre identidades.”
A Associação  MILK interpreta o mito como símbolo do corpo fluido e subterrâneo  da cultura,
onde as fronteiras do género, da fé e da origem se dissolvem na mesma água encantada. O
encantamento torna-se metáfora da sobrevivência queer: existir é resistir sob as ruínas do poder.
⸻
7. Referência Estrutural da Matriz MILK
Na Matriz Escultórica MILK, a Moura Encantada de Giela é representada com cabeça grande,
véu translúcido branco e base azul turquesa luminosa. O corpo compacto funde-se à pedra, e
uma pequena abertura circular no peito emite luz dourada, simbolizando o coração encantado.
⸻
Localização  específica: Solar de Giela, Arcos de Valdevez (Alto Minho).
Primeiro relato documentado: Leite de Vasconcelos, Etnografia Portuguesa, vol. II, 1913.
Sistematização  contemporânea:  Eduardo Mauer, A Moura Encantada de Giela: Ruína,  Desejo e
Subterrâneo  no Imaginário  Minhoto, Associação MILK, 2024.
Fontes primárias:  Braga (1885); Vasconcelos (1913); Parafita (2008); Henriques (2019); Mauer
(2024).
