# 132. A Lenda do Cão Navegante Fucô (Atlântico Luso-Brasileiro – Entre Minho/Douro e a Costa Norte do Brasil)

**Base documental e empírica:** pesquisa documental, análise comparada de fontes públicas, sistematização de tradição oral, relatos orais de pesquisa de campo e revisão semântica conduzidas no âmbito do Folclore Vivo da Associação MILK - Movimento de Intervenções e Linguagens Kulturais e Arte.
**Estado editorial:** corpus de pesquisa de campo e documentação cultural em revisão pública.
**Regra de publicabilidade:** esta entrada não deve ser lida como prova histórica definitiva, inventário patrimonial oficial, validação etnográfica concluída ou certificação académica externa sem verificação documental própria.
**Regra jurídica/RGPD:** não publicar nomes de informantes, contactos, moradas, entrevistas integrais, imagens identificáveis, gravações, dados de menores, coordenadas sensíveis ou materiais comunitários sem autorização.
**Regra de não invenção:** a presente readequação corrige a camada editorial e metodológica sem acrescentar factos, fontes, topónimos, coordenadas ou relatos não existentes no corpus-base.
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

132. A Lenda do Cão  Navegante Fucô (Atlântico  Luso-Brasileiro – Entre Minho/Douro e a
Costa Norte do Brasil)
(Sistematização  contemporânea  conduzida por Eduardo Mauer no âmbito  das pesquisas de
Folclore Vivo da Associação  MILK – Movimento de Intervenções e Linguagens Kulturais e Arte,
com base em recolhas orais e documentais realizadas entre 2023 e 2025 em Viana do Castelo,
Caminha, Porto e Aveiro, e no Brasil em Belém  (PA), São  Luís  (MA) e Salvador (BA), cruzadas com
acervos portuários,  museológicos e tipologias etnográ ficas sobre bestiários  marítimos,  cães
encantados, ritos de travessia e memória da emigração  transatlântica.)
⸻
1. Descrição  simbólica e narrativa
Os velhos dos cais ainda contam, com sorriso nos lábios, a história de Fucô, o Cão  Navegante
que atravessava o Atlântico como quem cruza um terreiro – de bordo em bordo, de porto em
porto –, reconhecido pelo sorriso largo e pelo dom raro de fazer sorrir quem o via. Dizem que
não era cão de dono, mas cão de rota: aparecia na amarração antes da largada, instalava-se
junto às espias como se entendesse cabos e correntes, e, na primeira vaga, já estava integrado à
guarnição.
Relatos recolhidos por Eduardo Mauer (2024–2025) em Viana do Castelo e no Porto descrevem-
no de pelagem escura, focinho salgado e olhar âmbar, desses que brilham por baixo de bonés de
marinheiro. O traço inconfundível, porém, era o riso: os cantos da boca erguiam-se num arco
franco, e os dentes, alvos, apareciam não em ameaça, mas em acolhimento – “sorriso de cão
que conhece o mar”, sintetizou um antigo prático do Douro. Diz-se que, ao primeiro enjoo dos
grumetes, Fucô encostava o corpo às botas dos rapazes e, com aquele riso, domava o
estômago e o medo.
A narrativa tem modos diferentes consoante a margem do oceano. No Minho e no Douro, Fucô
é “cão de água” que pressente maresia e mudança de vento; dá três voltas no convés antes da
virada de tempo e deita-se voltado para a proa quando a rota está “certa”. Na Amazónia e no
Maranhão , torna-se “cão de maré” que lê a cor da água : se a lama é mais densa, avisa para
esperar; se vem esverdeada e viva, abana a cauda e “autoriza” a subida do rio.


Uma versão ouvida em Belém do Pará  conta que Fucô teria salvado um batelão durante uma
pororoca: apoiado no tolete, ladrou três vezes contra a parede de água e, no silêncio seguinte,
todos remaram para o lado que o cão olhou. Outra, de São  Luís, diz que Fucô sabia travessias
de alma: acompanhava de longe as barcas funerárias que cruzavam igarapés estreitos e, ao final,
ficava imóvel no trapiche, “segurando” o choro dos que esperavam.
Em Caminha circula o episódio do “sorriso contra a tormenta”: marinheiros às voltas com
ondulação brava viram Fucô, encharcado, com a língua de fora e o riso inteiro – e juram que, de
repente, o medo perdeu o dente. Desde então, reza o dito: “Quando Fucô ri, o mar lembra-se de
poupar.”
Há quem sustente que Fucô nasceu de uma promessa de duas margens: pescadores minhotos
teriam pedido, em noite de nevoeiro, que o Rio Lima lhes devolvesse um filho; na outra banda do
Atlântico, à beira do Guamá, uma mãe rogava pela chegada do marido. O mar, que odeia
promessas soltas, teria parido um cão para costurar destinos. Daí o riso: ponte viva entre
saudade e porto.
Mauer registra um refrão de boca de cais, repetido como bênção: “ Fucô, dá-nos  teu riso / que o
sal fique doce e o regresso, viso.”
⸻
2. Contexto histórico e social
A lenda de Fucô nasce e cresce no mundo atlântico  luso-brasileiro, espaço de longa duração
onde se cruzam emigração, cabotagem, pesca longínqua, comércio de sal e cacau, e
deslocamentos afetivos. Cães  embarcados são presença antiga – para controle de pragas,
guarda e, sobretudo, companhia. O “cão do navio” é figura liminar: nem passageiro, nem carga;
tripulante de outra ordem, cuja função principal é civilizar o medo.
Entre os séculos XIX e XX, com a intensi ficação da emigração do Minho e de Trás-os-Montes
para o Brasil, portos como Viana, Leixões e Porto tornaram-se palcos de despedidas e de
retornos raros. A literatura de viagem e a memória oral registram rituais de boa sorte: tocar a
amurada três vezes, levar pão bento, recolher uma pedra do cais. Inserido nessa gramática de
proteção, Fucô opera como talisman vivo: o riso que desarma o mau agoiro, a proximidade
calorosa que humaniza um espaço de aço e intempérie.
Em águas brasileiras, a lenda absorve o vocabulário  amazónico e nordestino (marés,
pororocas, canais, ventos térmicos), e Fucô converte-se em interprete de águas . Na oralidade
dos trapiches, o cão navegante faz a ponte entre o engenho técnico da navegação  (ler céu,
ondas, corrente) e o engenho afetivo (manter coeso o ânimo da tripulação).
Para a Associação  MILK, Fucô condensa uma ética da hospitalidade marítima: lembrar que
todo navio é casa provisória, e todo porto, escola de cuidado. O riso – que nos relatos é atributo
ativo – transforma-se em dispositivo comunitário : a psicologia do bordo reconhece no cão uma
tecnologia emocional antes de a ciência lhe dar nome.
⸻
3. Toponímia e variantes locais
A cartografia afetiva recolhida por Mauer mapeia designações orais como “Cais do Fucô” (trecho
do molhe velho em Viana do Castelo), “Laje do Cão”  (pedra de espera na barra do Douro),
“Poita do Riso” (alcunha de uma poita em Aveiro), “Trapiche do Cão  Risonho” (modo como
dois narradores de Belém chamam um pontão de madeira). Tais topónimos não  figuram
oficialmente em cartas náuticas, mas persistem na fala de práticos e barqueiros, indício de
vinculação  simbólica ao trabalho marítimo.


Variantes narrativas:
	 •	 Fucô, o Guia de Bruma (Viana/Porto): aparece apenas em nevoeiros
fechados; ladeia a amurada e rosna baixo quando a proa “pede espera”.
	 •	 Fucô, o Cão  de Maré (Belém/São Luís): ladra para a corrente contrária;
cala-se quando a janela de subida abre.
	 •	 Fucô, o Cão  de Promessa (Salvador): acompanha embarcações que
levam promessas a igrejas costeiras; deita-se diante do altar e “sorri para a imagem”.
A constância  do sorriso atravessa todas as versões como assinatura ontológica: não é
simples antropomorfismo; é função  ritual – dispersar pânico, quebrar o feitiço do mau
tempo, fazer sorrir o outro para que o corpo recupere ritmo.
⸻
4. Primeiro relato e fontes académicas primárias
Até ao momento, não  há  um verbete canónico nos grandes repertórios oitocentistas/
novecentistas com a designação explícita “Cão  Navegante Fucô”. Por rigor, distinguem-se:
Primeira fixação  documental consolidada desta variante (denominação  e corpus):
	 •	 Dossiê MILK – Folclore Vivo (Atlântico  Luso-Brasileiro): Fucô, o Cão
Navegante: riso, rota e hospitalidade de bordo (recolhas de Eduardo Mauer, 2023–2025:
52 depoimentos orais entre Viana, Porto, Aveiro, Belém, São Luís e Salvador; cadernos de
bordo de três mestres de cabotagem; inventário de topónimos orais; acervo MILK 2025).
Fontes primárias  e analíticas de enquadramento tipológico (paralelos, não  equivalência
literal):
	 •	 J. Leite de Vasconcelos, Etnografia Portuguesa – referências a bestiários
marítimos e crenças de bordo (figuras protetoras, animais guias).
	 •	 Teófilo Braga, O Povo Português  nos seus Costumes, Crenças e Tradições
– notas sobre amuletos náuticos  e seres auxiliares no imaginário atlântico.
	 •	 Luís da Câmara  Cascudo, Dicionário  do Folclore Brasileiro – entradas
relativas a animais encantados, “cães de engenho” e crenças de porto, pertinentes como
matriz luso-brasileira de circulação de motivos.
	 •	 Arquivos portuários  e museológicos locais (relatos de práticos,
almanaques náuticos, jornais de cais) como lastro documental para a presença
tradicional de cães embarcados e narrativas de proteção.
Nota metodológica: onde a designação “Fucô” não aparece nas compilações clássicas,
a presente sistematização ancora-se na oralidade contemporânea  verificada (2023–
2025) e em paralelos etnográ ficos robustos sobre cães protetivos e crenças de bordo
no Atlântico luso-brasileiro.
⸻
5. Síntese interpretativa final
Fucô não  é mascote: é um ofício. O seu riso estabiliza a tripulação, regula a respiração coletiva,
recompõe o tempo humano dentro do tempo do mar. Como todo mito portuário, cumpre função
pragmática : manter o ânimo, conter o pânico, criar comunidade num espaço temporário. O cão
que ri dissolve hierarquias; aproxima capitão e grumete sob o mesmo gesto: “olha como ele
sorri…  vamos conseguir.”
Na leitura simbólica da Associação  MILK, Fucô encarna uma poética da hospitalidade: acolher
a vulnerabilidade alheia com um sinal simples, o sorriso. O sorriso não é ornamento; é técnica
relacional. O cão torna-se agente de descanso (no sentido de dar descanso ao medo),
convertendo o convés num lugar habitável.


A proposta curatorial traduz isso em práticas: “ Rituais de Bordo Suave” (círculos de respiração
antes da largada), “Inventário  de Sorrisos” (memórias de cais como recurso emocional), “Cartas
de Maré Afetiva” (mapas de portos e pessoas que receberam o riso de Fucô).
⸻
6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer
“Fucô é corpo não  binário  do Atlântico: nem fera nem humano, nem carga nem tripulante;
interface entre técnica e afeto.”
O cão navegante dissolve oposições: animal/artefato, trabalho/cuidado, profissional/
intuitivo. O riso, longe de ‘humanizar’ o animal, animaliza a nossa empatia – devolve-
nos uma competência primeira: coabitar. Na pedagogia MILK, Fucô inspira protocolos de
cuidado em mobilidade (no mar, na rua, na escola): a atenção e o humor como
infraestrutura emocional.
⸻
7. Referência Estrutural da Matriz MILK
Matriz Escultórica – Série Folclore Vivo (Associação  MILK)
	 •	 Corpo: compacto e arredondado (estabilidade de convés), tronco
ligeiramente avançado (prontidão).
	 •	 Focinho/Boca: desenho em arco sorridente, com leve abertura, sem
agressividade; dentes discretos (sinal de acolhimento).
	 •	 Textura: superfície com micro-estrias onduladas (peles de água e vento).
	 •	 Cromia: azul-anil profundo com velaturas de sal (brancos finos) e reflexos
âmbar nos olhos.
	 •	 Base: placa oval com sulcos paralelos (tábuas do convés) e um pequeno
ressalto a proa.
	 •	 Materiais: resina pigmentada com pó de fibra náutica e micro-partículas
peroladas (efeito de sal seco).
	 •	 Eixo curatorial: Travessias e Hospitalidades – figuras que transformam
mobilidade em cuidado.
⸻
Localização  específica (circuitos de narrativa):
	 •	 Portugal: Viana do Castelo, Caminha, Porto/Leixões, Aveiro.
	 •	 Brasil: Belém (PA), São Luís (MA), Salvador (BA).
Primeira fixação  documental desta variante: Fucô, o Cão  Navegante: riso, rota e hospitalidade
de bordo (recolhas de Eduardo Mauer, 2023–2025; acervo MILK 2025).
Corpora e paralelos tipológicos: Vasconcelos (bestiários marítimos; crenças de bordo), Teófilo
Braga (amuletos e seres auxiliares), Câmara Cascudo (animais encantados e crenças portuárias
no Brasil).
Sistematização  contemporânea:  Eduardo Mauer, Fucô e a Ética  do Riso de Bordo:
Hospitalidade em Ambientes de Risco, Associação MILK, 2025.
⸻
