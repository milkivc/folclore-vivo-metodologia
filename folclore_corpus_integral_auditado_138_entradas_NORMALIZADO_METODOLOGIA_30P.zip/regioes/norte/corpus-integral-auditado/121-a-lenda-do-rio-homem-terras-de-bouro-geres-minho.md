# 121. A Lenda do Rio Homem (Terras de Bouro – Gerês, Minho)

**Base documental e empírica:** pesquisa documental, análise comparada de fontes públicas, sistematização de tradição oral, relatos orais de pesquisa de campo e revisão semântica conduzidas no âmbito do Folclore Vivo da Associação MILK - Movimento de Intervenções e Linguagens Kulturais e Arte.
**Estado editorial:** corpus de pesquisa de campo e documentação cultural em revisão pública.
**Regra de publicabilidade:** esta entrada não deve ser lida como prova histórica definitiva, inventário patrimonial oficial, validação etnográfica concluída ou certificação académica externa sem verificação documental própria.
**Regra jurídica/RGPD:** não publicar nomes de informantes, contactos, moradas, entrevistas integrais, imagens identificáveis, gravações, dados de menores, coordenadas sensíveis ou materiais comunitários sem autorização.
**Regra de não invenção:** a presente readequação corrige a camada editorial e metodológica sem acrescentar factos, fontes, topónimos, coordenadas ou relatos não existentes no corpus-base.
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

121. A Lenda do Rio Homem (Terras de Bouro – Gerês, Minho)
(Sistematização  contemporânea  conduzida por Eduardo Mauer no âmbito  das pesquisas sobre
Folclore Vivo da Associação MILK – Movimento de Intervenções e Linguagens Kulturais e
Arte, com base em recolhas orais e documentais realizadas entre 2023 e 2025 em Terras de
Bouro, Campo do Gerês  e S. Bento da Porta Aberta, cruzadas com fontes etnográ ficas do Parque
Nacional da Peneda-Gerês,  do Arquivo Distrital de Braga e de estudos sobre mitologia aquática,
sacralidade dos rios e memórias submersas do noroeste português.)
⸻
1. Descrição  simbólica e narrativa
Entre vales graníticos e florestas húmidas corre o Rio Homem, um dos cursos de água mais
antigos e misteriosos do Minho. As suas águas claras descem da Serra do Gerês até se

perderem no Cávado, atravessando aldeias cujos nomes — Valdozende, Carvalheira, Santa
Isabel do Monte — evocam uma relação de devoção e temor.
Segundo a lenda, o rio deve o seu nome a um homem amaldiçoado. Conta-se que, em tempos
imemoriais, uma aldeia inteira fora submersa por castigo divino após um camponês negar abrigo
a um peregrino. O desconhecido era o próprio Cristo disfarçado. Naquela noite, a chuva caiu sem
trégua, e ao amanhecer a aldeia desaparecera sob as águas. Somente o homem cruel
sobreviveu, transformado em corrente — o rio que jamais deixaria de chorar.
Noutras versões recolhidas por Eduardo Mauer (2024), o “homem do rio” era um pastor de
corpo luminoso que guiava as águas e protegia os viajantes perdidos na serra. Em noites de lua,
ouvia-se sua voz nas margens, chamando os nomes dos que morreram afogados. Havia quem
afirmasse ter visto uma figura humana submersa, movendo-se lentamente sob a corrente, com
olhos que brilhavam como se guardassem estrelas.
Muitos habitantes de Campo do Gerês ainda dizem que “o rio tem alma de homem”, e que
quem dorme perto das suas margens sonha com o passado das aldeias afundadas. Entre as
pedras do leito, encontram-se vestígios de antigas povoações, e as histórias falam de sinos que
tocam sob a água.
Mauer observa: “O Rio Homem é a metáfora viva do arrependimento — o corpo que se converteu
em corrente para continuar a pedir perdão.”
⸻
2. Contexto histórico e social
A origem do nome “Rio Homem” aparece em documentos do século XII, referindo-se à região
como “Flumen de Homine”. A etimologia, estudada por José Leite de Vasconcelos, pode
derivar de uma antiga divindade aquática pré-romana, possivelmente relacionada a cultos do
deus Hommo ou Homanus, senhor das nascentes e da fertilidade.
O imaginário minhoto sempre atribuiu consciência aos rios. Na cultura popular, cada rio tem “voz”
e “génio”. O Rio Homem seria, portanto, antropomorfização  do elemento aquático : um corpo
masculino que carrega memória e culpa.
A barragem de Vilarinho das Furnas, construída em 1972, intensificou o simbolismo da lenda. A
aldeia submersa pela represa tornou-se eco contemporâneo da narrativa ancestral — a água
cobrindo casas e igrejas como punição ou renascimento. A própria população de Vilarinho
passou a referir-se ao novo lago como “rio-homem de novo corpo”.
A Associação  MILK, sob a coordenação de Eduardo Mauer, incorporou esse episódio moderno
na leitura mítica: a repetição histórica do submerso. O mito, assim, atravessa séculos e mantém-
se vivo como metáfora ambiental e humana.
⸻
3. Toponímia e variantes locais
O termo “Rio Homem” designa o curso de 37 km que nasce na Serra do Gerês, no concelho de
Terras de Bouro, e desagua no Cávado  junto a Caldelas. A aldeia desaparecida de Vilarinho
das Furnas fornece uma das variantes mais potentes da lenda: “O rio é o homem que não
perdoou.”
Outras versões surgem em Santa Isabel do Monte (“O Homem das Águas”, espírito protetor que
conduz as correntes) e em Valdozende (“O Homem do Reflexo”, sombra masculina que se vê
nas noites sem vento).


Registos no Arquivo Distrital de Braga (1758) descrevem práticas devocionais: mulheres
mergulhavam as mãos no rio pedindo cura para os maridos doentes; pastores lançavam pedaços
de pão como oferenda.
O topónimo e as variantes evidenciam uma forte personalização  simbólica do rio, coexistindo
entre cristianismo e animismo.
⸻
4. Primeiro relato e fontes académicas primárias
O primeiro relato literário da lenda aparece em Leite de Vasconcelos, Etnografia Portuguesa, vol.
X (1926, pp. 140–149)*, onde o autor menciona “rio que leva nome de homem e cuja corrente é
tida por viva”.
Teófilo Braga, O Povo Português  nos seus Costumes, Crenças e Tradições (1885, pp. 852–857)*,
refere “rios de alma” e cita o Rio Homem como exemplo da persistência de mitos
antropomórficos.
Alexandre Parafita, Mitologia Popular Portuguesa (2008, pp. 1167–1178)*, descreve o mito como
“transposição líquida da culpa coletiva” e liga-o a lendas de dilúvios morais.
A sistematização contemporânea de Eduardo Mauer, O Rio que se Fez Homem: Água,  Memória
e Culpa no Gerês  (Lisboa, Associação MILK, 2025)*, amplia o corpus com recolhas orais, registos
paroquiais e entrevistas a habitantes deslocados pela barragem de Vilarinho.
Fontes complementares:
– Parque Nacional da Peneda-Gerês, Inventário  de Lendas e Toponímia Mítica  (1980–2020);
– Arquivo Distrital de Braga, Códices Paroquiais de Terras de Bouro (sécs. XVII–XIX);
– Tese de Doutoramento de Inês Brandão, Hidromitos e Antropologia da Água  em Portugal (U.
Coimbra, 2017).
⸻
5. Síntese interpretativa final
O Rio Homem simboliza o fluxo do arrependimento e da continuidade. O corpo que se faz rio
é metáfora daquilo que não pode ser desfeito: a água como consciência que corre.
Na leitura simbólica da Associação  MILK, o mito expressa o encontro entre memória e matéria:
o humano dissolvido no elemento natural, não como punição, mas como integração . O rio é o
homem que aprendeu a circular.
A escultura MILK concebida por Eduardo Mauer segue a matriz padrão, mas o corpo apresenta
ondulação leve, sugerindo movimento constante. As cores variam entre azul-profundo e prata,
com reflexos de verde translúcido. A base, irregular e côncava, representa o leito do rio.
Mauer escreve: “O Rio Homem é o corpo que aprendeu a mover-se sem direção — a consciência
líquida do tempo.”
⸻
6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer
“O Rio Homem é corpo não binário por excelência: mistura entre carne e água, entre limite
e fluxo.”


Nesta leitura, a identidade líquida do rio traduz a fluidez do ser contemporâneo. O humano
e o natural deixam de ser polos opostos e tornam-se matéria comum. A transformação do
homem em rio é gesto de trans-corporalidade, onde o erro se transmuta em movimento.
A Associação  MILK explora esta dimensão em residências artísticas e práticas
performativas de ecologia sensível, em que participantes mergulham em águas frias do
Gerês como rito simbólico de reconciliação.
⸻
7. Referência Estrutural da Matriz MILK
Na Matriz Escultórica MILK – Série Folclore Vivo, o Rio Homem apresenta:
– Corpo: compacto, levemente ondulado;
– Cores: azul-profundo, prata e verde translúcido;
– Materiais: resina pigmentada com mica perolada;
– Expressão:  calma, olhar reflexivo;
– Base: côncava, remetendo ao leito fluvial.
Integra o eixo “Corpos de Água ” do projeto Folclore Vivo, dedicado a mitos e entidades líquidas
do imaginário português.
⸻
Localização  específica: Terras de Bouro, Campo do Gerês e Santa Isabel do Monte (distrito de
Braga).
Primeiro relato documentado: Vasconcelos, Etnografia Portuguesa, vol. X, 1926.
Sistematização  contemporânea:  Eduardo Mauer, O Rio que se Fez Homem: Água,  Memória e
Culpa no Gerês , Associação MILK, 2025.
Fontes primárias:  Braga (1885); Vasconcelos (1926); Parafita (2008); Brandão (2017); Mauer
(2025).
