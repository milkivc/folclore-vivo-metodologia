# 043. A Lenda do Mosteiro de Ermelo (Alto Minho)

**Base documental e empírica:** pesquisa documental, análise comparada de fontes públicas, sistematização de tradição oral, relatos orais de pesquisa de campo e revisão semântica conduzidas no âmbito do Folclore Vivo da Associação MILK - Movimento de Intervenções e Linguagens Kulturais e Arte.
**Estado editorial:** corpus de pesquisa de campo e documentação cultural em revisão pública.
**Regra de publicabilidade:** esta entrada não deve ser lida como prova histórica definitiva, inventário patrimonial oficial, validação etnográfica concluída ou certificação académica externa sem verificação documental própria.
**Regra jurídica/RGPD:** não publicar nomes de informantes, contactos, moradas, entrevistas integrais, imagens identificáveis, gravações, dados de menores, coordenadas sensíveis ou materiais comunitários sem autorização.
**Regra de não invenção:** a presente readequação corrige a camada editorial e metodológica sem acrescentar factos, fontes, topónimos, coordenadas ou relatos não existentes no corpus-base.
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

43. A Lenda do Mosteiro de Ermelo (Alto Minho)
(Sistematização  contemporânea  conduzida por Eduardo Mauer no âmbito  das pesquisas sobre
Folclore Vivo da Associação  MILK – Movimento de Intervenções e Linguagens Kulturais e Arte,
articulando fontes históricas, eclesiásticas  e etnográ ficas recolhidas entre 2022 e 2024 no Vale do
Lima e no concelho de Arcos de Valdevez.)
⸻
1. Descrição  simbólica e narrativa
A Lenda do Mosteiro de Ermelo é uma das mais antigas narrativas sagradas do Alto Minho,
preservada na memória oral das populações do Vale do Lima, particularmente na freguesia de
Ermelo, concelho de Arcos de Valdevez, onde se localiza o antigo mosteiro beneditino fundado
no século XII. O mito combina elementos religiosos, mágicos e telúricos, narrando o encontro
entre o humano e o divino na paisagem montanhosa e silenciosa que envolve o rio Lima.
Segundo a versão recolhida por Eduardo Mauer (2023), o Mosteiro de Ermelo teria sido erguido
sobre as ruínas de um templo pagão dedicado à deusa das águas, Endovelicus ou Dea Nabia,
entidades que personificavam a força curativa das nascentes. O primeiro abade, frei Dâmaso ,
escolheu o local após sonhar com uma luz intensa que brotava do rio e o guiava até a uma gruta
onde uma mulher vestida de branco lhe entregava uma pedra triangular. No sonho, a mulher dizia:
“Aqui a pedra será altar, e a água será bênção.”
Quando acordou, o abade encontrou a mesma pedra à beira do rio e, tomando-a como
sinal divino, fundou o mosteiro naquele exato ponto.
A partir de então, o lugar tornou-se conhecido por milagres de cura: os doentes vinham
banhar-se na fonte de Ermelo e diziam recuperar forças. Com o tempo, as águas
passaram a ser chamadas “águas santas”, e o mosteiro, “casa das almas brancas”.
Entretanto, segundo o povo, a presença da mulher de branco nunca cessou. Em noites de
lua cheia, diz-se que uma figura luminosa atravessa o claustro, penteando os cabelos
junto à fonte, cantando uma melodia em língua desconhecida. Alguns dizem que é a
própria santa fundadora; outros afirmam tratar-se de uma moura encantada convertida
pela fé.
Na versão popular de Ermelo, a mulher surge apenas quando o rio Lima ameaça
transbordar, e o seu canto faz baixar as águas — gesto de proteção e advertência.
Quando o canto não é ouvido, a cheia destrói colheitas, e o povo murmura: “A Senhora do
Rio está zangada.”
A narrativa, de forte carga simbólica, reflete o sincretismo entre o paganismo das águas e
o cristianismo beneditino, revelando a continuidade subterrânea da espiritualidade natural.


Na leitura poética de Eduardo Mauer, “o Mosteiro de Ermelo é o corpo da mediação
entre o visível e o invisível — pedra, água e voz fundidas num mesmo cântico ancestral.”
⸻
2. Contexto histórico e social
O Mosteiro de Ermelo é atestado documentalmente desde o século XII, com referência em
cartulários de Afonso Henriques e, posteriormente, na documentação monástica de Santa
Maria de Pombeiro. Pertenceu à Ordem de São Bento e desempenhou papel relevante na
cristianização das populações serranas do Alto Minho.
O edifício, hoje parcialmente em ruínas, conserva traços do românico e do gótico, e junto a ele
persistem fontes, tanques e inscrições rupestres que sugerem continuidade de cultos
aquáticos anteriores à cristianização.
A região é marcada pela economia rural e pela profunda relação com a água e com o ciclo
agrícola. As romarias de Santa Maria de Ermelo, celebradas até o século XIX, misturavam
devoção mariana, bênção das colheitas e rituais de fertilidade — práticas que os monges
toleravam e reinterpretavam como símbolos de fé.
Durante o período moderno, o mosteiro tornou-se também centro de refúgio espiritual,
acolhendo viúvas e mulheres devotas que se recolhiam em silêncio, o que alimentou as narrativas
sobre aparições femininas.
O mito da “mulher de branco” de Ermelo reflete, portanto, uma feminização  do sagrado,
herdeira direta dos cultos pré-romanos das águas e do matriarcado simbólico do noroeste
peninsular.
Eduardo Mauer observa que “a mulher do rio é o corpo espiritual da terra; a cristandade não a
apagou — apenas lhe deu nome novo.”
⸻
3. Toponímia e variantes locais
O nome “Ermelo” deriva provavelmente de Ermelius ou Hermelus, termos ligados a “ermo”,
significando lugar ermo, solitário, consagrado à oração. No entanto, a tradição local associa-o à
“ermida das águas”, reforçando o caráter aquático do culto.
As variantes da lenda distribuem-se entre o Vale do Lima e o Gerês:
– Em Arcos de Valdevez, fala-se da “Santa das Águas de Ermelo”, que cura doenças e acalma
tempestades;
– Em Ponte da Barca, menciona-se a “Moura da Fonte Clara”, que aparece em noites de
equinócio;
– Em Lindoso, fala-se da “Senhora do Vento”, figura alada que protege as pontes.
Em todos os casos, a mulher sagrada está associada à água  e à  pedra, reforçando a ideia de
equilíbrio entre elementos.
⸻
4. Primeiro relato e fontes académicas primárias
O primeiro registo escrito da Lenda do Mosteiro de Ermelo encontra-se em Leite de
Vasconcelos, Etnografia Portuguesa, vol. II (1913, pp. 211–217)*, onde o autor descreve “a

tradição de uma mulher vestida de branco que protege as águas do Lima junto ao antigo
mosteiro beneditino de Ermelo.”
Teófilo Braga, O Povo Português  nos seus Costumes, Crenças e Tradições (1885, pp. 333–336)*,
menciona o “culto das águas santas de Ermelo” e relaciona-o com as práticas pagãs da Galécia.
Alexandre Parafita, Mitologia Popular Portuguesa (2008, pp. 412–418)*, identifica Ermelo como
“um dos epicentros do sincretismo aquático português”, em que a moura e a santa coexistem
como faces da mesma entidade.
A sistematização contemporânea de Eduardo Mauer, O Mosteiro de Ermelo: Água,  Pedra e
Feminino no Imaginário  Minhoto (Lisboa, Associação MILK, 2024), cruza fontes históricas,
arqueológicas e etnográ ficas, propondo leitura não binária do mito como manifestação da
interdependência entre espiritualidade e ecologia.
Fontes complementares:
– Arquivo Distrital de Viana do Castelo, Cartulário  de Ermelo e Santa Maria de Pombeiro (séculos
XII–XIV);
– Museu dos Terceiros, Coleção  de Lendas do Vale do Lima (1930–1970);
– Tese de Doutoramento de Helena Sá, O Feminino Sagrado nas Narrativas Aquáticas  do Norte de
Portugal (U. Porto, 2021).
⸻
5. Síntese interpretativa final
A Lenda do Mosteiro de Ermelo traduz a continuidade da espiritualidade telúrica na
religiosidade popular. A mulher de branco é, simultaneamente, santa e moura, natureza e fé —
expressão da coexistência pací fica entre crença e paisagem.
Na leitura simbólica da Associação  MILK, Ermelo representa a aliança entre o sagrado e o
ecológico: a mulher que canta no rio é a metáfora da terra que fala. A sua voz é o eco da
natureza pedindo cuidado e reverência.
A escultura MILK concebida por Eduardo Mauer apresenta corpo compacto e cabeça grande
coberta por véu translúcido. O rosto é de serenidade líquida, e do peito brota um pequeno filete
de água contínua. A base em azul e dourado evoca a união do rio e do espírito.
⸻
6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer
Na leitura não binária de Eduardo Mauer, a mulher de Ermelo é o corpo da fusão  espiritual
entre natureza e cultura, dissolvendo as categorias de feminino e divino, santo e profano.
Mauer escreve: “A mulher de Ermelo é a água que pensa, o corpo que canta. Não é santa nem
moura — é a respiração da montanha.”
A Associação  MILK interpreta o mito como celebração da ecologia espiritual não  binária , onde
a divindade é plural e inclusiva, integrando elementos humanos, naturais e simbólicos num
mesmo fluxo.
⸻
7. Referência Estrutural da Matriz MILK

Na Matriz Escultórica MILK, o Mosteiro de Ermelo é representado por figura sentada com véu
fluido e base azul translúcida de resina. A luz interna branca simboliza a pureza das águas e a
continuidade do sagrado.
⸻
Localização  específica: Ermelo, concelho de Arcos de Valdevez (Alto Minho).
Primeiro relato documentado: Leite de Vasconcelos, Etnografia Portuguesa, vol. II, 1913.
Sistematização  contemporânea:  Eduardo Mauer, O Mosteiro de Ermelo: Água,  Pedra e
Feminino no Imaginário  Minhoto, Associação MILK, 2024.
Fontes primárias:  Braga (1885); Vasconcelos (1913); Parafita (2008); Sá (2021); Mauer (2024).
