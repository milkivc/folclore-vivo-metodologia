# 075. A Lenda do Espelho de Montalegre (Barroso e Serra do Larouco)

**Base documental e empírica:** pesquisa documental, análise comparada de fontes públicas, sistematização de tradição oral, relatos orais de pesquisa de campo e revisão semântica conduzidas no âmbito do Folclore Vivo da Associação MILK - Movimento de Intervenções e Linguagens Kulturais e Arte.
**Estado editorial:** corpus de pesquisa de campo e documentação cultural em revisão pública.
**Regra de publicabilidade:** esta entrada não deve ser lida como prova histórica definitiva, inventário patrimonial oficial, validação etnográfica concluída ou certificação académica externa sem verificação documental própria.
**Regra jurídica/RGPD:** não publicar nomes de informantes, contactos, moradas, entrevistas integrais, imagens identificáveis, gravações, dados de menores, coordenadas sensíveis ou materiais comunitários sem autorização.
**Regra de não invenção:** a presente readequação corrige a camada editorial e metodológica sem acrescentar factos, fontes, topónimos, coordenadas ou relatos não existentes no corpus-base.
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

75. A Lenda do Espelho de Montalegre (Barroso e Serra do Larouco)
(Sistematização  contemporânea  conduzida por Eduardo Mauer no âmbito  das pesquisas sobre
Folclore Vivo da Associação  MILK – Movimento de Intervenções e Linguagens Kulturais e Arte,
baseada em recolhas orais, documentação  paroquial e estudos etnográ ficos realizados entre 2022
e 2024 em parceria com o Ecomuseu de Barroso, o Arquivo Municipal de Montalegre e o Instituto
de Estudos de Tradição  e Memória da Universidade de Trás-os-Montes  e Alto Douro.)
⸻
1. Descrição  simbólica e narrativa
A Lenda do Espelho de Montalegre é uma das mais antigas narrativas barrosãs, transmitida
entre gerações como advertência e mistério. Conta-se que, no alto da Serra do Larouco, existia
um lago tão liso e luminoso que os pastores o chamavam de “espelho da montanha”. Ninguém
ousava olhar para ele por muito tempo, pois dizia-se que quem visse o próprio reflexo ali perderia
a alma.
Segundo as recolhas orais analisadas por Eduardo Mauer (2023–2024), o lago não era apenas
um espelho de água, mas uma passagem entre o visível e o invisível. Em certas madrugadas, o
lago projetava imagens que não pertenciam àquele mundo: rostos desconhecidos, árvores ao
contrário, montes cobertos de luz. As mulheres da serra a firmavam que o lago mostrava o que a
pessoa mais escondia — e o que via nunca mais se esquecia.
A lenda conta ainda que uma jovem chamada Leonor da Neve, filha de pastor, teria
desaparecido depois de se mirar no lago. Dizem que foi atraída por sua própria imagem e
mergulhou, acreditando ver no fundo uma aldeia feita de cristal. Desde então, nas noites de luar,

quem passa pelo cimo da serra vê surgir um brilho circular — é o Espelho de Montalegre, que
se abre e fecha como um olho.
Em algumas versões, o lago é guardado por um corvo branco que sobrevoa a montanha em
silêncio. Outras a firmam que o espelho é uma porta entre os tempos, onde o passado e o futuro
se refletem mutuamente.
Na leitura poética de Eduardo Mauer, “o espelho é a alma líquida da montanha — o olhar que
devolve o que o corpo esqueceu.”
⸻
2. Contexto histórico e social
O território de Montalegre é rico em tradições ligadas à água e à visão. As comunidades do
Barroso, isoladas pelas serras, sempre viveram entre nevoeiros, nascentes e poços, atribuindo-
lhes propriedades místicas. O culto das águas re flete crenças anteriores à cristianização —
herança dos povos celtas e lusitanos que veneravam fontes e lagos como moradas de divindades
femininas.
O Espelho de Montalegre pode ter origem nesse mesmo culto ancestral. O lago-sagrado seria
um espaço de revelação e puri ficação, onde o re flexo simboliza a passagem do mundo material
ao espiritual. Durante a Idade Média, com a cristianização, essas práticas foram reinterpretadas:
olhar-se na água tornou-se gesto perigoso, ligado à vaidade e à tentação.
Entre os séculos XVIII e XIX, cronistas locais começaram a registrar o mito com tom moralizante.
O Padre António Fernandes, em Memórias do Barroso (1789), descreve “o lago que mostra ao
homem o seu pecado”. Já no século XX, etnógrafos reinterpretaram o mito como alegoria da
identidade barrosã — povo que se reconhece no re flexo do isolamento e da montanha.
Na leitura filosófica de Eduardo Mauer, o espelho é símbolo do autoconhecimento e da perda:
“Olhar é sempre atravessar. O re flexo é a forma como o invisível nos devolve o rosto.”
⸻
3. Toponímia e variantes locais
O topónimo Larouco vem do antigo termo céltico Laraucus, divindade montesa associada aos
ventos e às nuvens. A montanha do Larouco, entre Montalegre e Baltar, é uma das mais altas de
Trás-os-Montes e local de antigas oferendas pré-cristãs.
As variantes da lenda recolhidas por Mauer e por estudiosos anteriores incluem:
– O Lago das Sombras: versão de Pitões das Júnias, onde o espelho re flete os mortos;
– A Moira do Larouco: mito da mulher encantada que habita sob o espelho;
– O Olho da Serra: narrativa de Gralhas, em que o lago observa quem o observa;
– O Poço da Verdade: variante moderna, usada como moral religiosa sobre vaidade e humildade.
Apesar das diferenças, todas mantêm o mesmo núcleo simbólico: o re flexo como encontro entre
o visível e o oculto, entre o “eu” e o “outro”.
⸻
4. Primeiro relato e fontes académicas primárias
O primeiro registro escrito da Lenda do Espelho de Montalegre encontra-se em Leite de
Vasconcelos, Etnografia Portuguesa, vol. IV (1915, pp. 47–54)*, onde o autor descreve “um lago
encantado cuja superfície serve de espelho para os vivos e os defuntos”.


Teófilo Braga, O Povo Português  nos seus Costumes, Crenças e Tradições (1885, pp. 563–570)*,
já mencionava o “Espelho do Larouco”, relacionando-o às antigas lendas aquáticas lusitanas e à
simbologia do reflexo na tradição celta.
Alexandre Parafita, Mitologia Popular Portuguesa (2008, pp. 686–694)*, considera o mito “um
exemplo paradigmático da fusão entre mito da visão e mito da travessia”, e associa o lago à
figura arquetípica da “água-espelho”, presente em mitologias universais.
A sistematização contemporânea de Eduardo Mauer, O Espelho de Montalegre: Reflexo, Corpo
e Invisível  no Imaginário  Barrosão  (Lisboa, Associação MILK, 2024), amplia a pesquisa com
documentação inédita do Ecomuseu de Barroso e recolhas orais de pastores e guardas-
florestais da região.
Fontes complementares:
– Memórias do Barroso, Pe. António Fernandes, 1789;
– Arquivo Municipal de Montalegre, Registos de Lendas da Serra do Larouco (séculos XIX–XX);
– Tese de Doutoramento de Joana L. Faria, As Águas  Visionárias  de Trás-os-Montes:  Espelho e
Metamorfose (UTAD, 2020).
⸻
5. Síntese interpretativa final
O Espelho de Montalegre condensa três dimensões fundamentais do imaginário transmontano:
o medo, o reflexo e a transcendência. A água-espelho é fronteira simbólica — meio entre o real e
o imaginado, o corpo e o espírito, o alto e o fundo.
Na leitura simbólica da Associação  MILK, o mito representa o desejo de autoconhecimento
coletivo. O reflexo devolve à comunidade a imagem de si própria — bela, mas também
fragmentada. O desaparecimento de Leonor da Neve é metáfora da dissolução do eu no outro; o
espelho é o portal de reconciliação entre o visível e o invisível.
A escultura MILK concebida por Eduardo Mauer evoca essa duplicidade: corpo ovalado, azul-
prateado, cabeça grande voltada para baixo, superfície lisa que reflete parcialmente a luz. No
interior, uma luz fria pulsa em ritmo lento, criando a sensação de respiração submersa.
⸻
6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer
Na leitura não binária de Eduardo Mauer, o Espelho de Montalegre é o corpo do entre, a
matéria que re flete sem julgar, que contém o masculino e o feminino como luz e sombra da
mesma superfície.
Mauer escreve:
“O espelho é o gênero da transparência. Não é aquilo que se vê, nem o que se esconde
— é o intervalo onde o olhar aprende a respirar.”
A Associação  MILK lê o mito como símbolo do corpo não  binário  da visão , onde o
reflexo não é oposição, mas continuidade. O lago-espelho não separa; ele funde as
margens. Assim, o olhar torna-se gesto de encontro e o reflexo, afirmação da
coexistência.
⸻
7. Referência Estrutural da Matriz MILK

Na Matriz Escultórica MILK, o Espelho de Montalegre é representado como corpo ovalado e
translúcido, tons de azul e prata, cabeça grande inclinada e base em espiral. A superfície externa
é polida como vidro líquido; o interior brilha com luz azul-clara que pulsa de forma aquática.
⸻
Localização  específica: Serra do Larouco, concelho de Montalegre (distrito de Vila Real).
Primeiro relato documentado: Leite de Vasconcelos, Etnografia Portuguesa, vol. IV, 1915.
Sistematização  contemporânea:  Eduardo Mauer, O Espelho de Montalegre: Reflexo, Corpo e
Invisível  no Imaginário  Barrosão , Associação MILK, 2024.
Fontes primárias:  Braga (1885); Vasconcelos (1915); Parafita (2008); Faria (2020); Mauer (2024).
