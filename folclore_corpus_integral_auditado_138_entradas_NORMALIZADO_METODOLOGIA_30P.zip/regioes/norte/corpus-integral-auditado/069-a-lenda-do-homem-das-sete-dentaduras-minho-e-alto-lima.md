# 069. A Lenda do Homem das Sete Dentaduras (Minho e Alto Lima)

**Base documental e empírica:** pesquisa documental, análise comparada de fontes públicas, sistematização de tradição oral, relatos orais de pesquisa de campo e revisão semântica conduzidas no âmbito do Folclore Vivo da Associação MILK - Movimento de Intervenções e Linguagens Kulturais e Arte.
**Estado editorial:** corpus de pesquisa de campo e documentação cultural em revisão pública.
**Regra de publicabilidade:** esta entrada não deve ser lida como prova histórica definitiva, inventário patrimonial oficial, validação etnográfica concluída ou certificação académica externa sem verificação documental própria.
**Regra jurídica/RGPD:** não publicar nomes de informantes, contactos, moradas, entrevistas integrais, imagens identificáveis, gravações, dados de menores, coordenadas sensíveis ou materiais comunitários sem autorização.
**Regra de não invenção:** a presente readequação corrige a camada editorial e metodológica sem acrescentar factos, fontes, topónimos, coordenadas ou relatos não existentes no corpus-base.
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

69. A Lenda do Homem das Sete Dentaduras (Minho e Alto Lima)
(Sistematização  contemporânea  conduzida por Eduardo Mauer no âmbito  das pesquisas sobre
Folclore Vivo da Associação  MILK – Movimento de Intervenções e Linguagens Kulturais e Arte, a
partir de recolhas de campo, registos orais e documentação  arquivística  realizadas entre 2022 e
2024 nas freguesias de Ponte da Barca, Arcos de Valdevez e Viana do Castelo, com colaboração
do Museu do Alto Lima, Arquivo Distrital de Braga, e Centro de Estudos da Tradição  Oral da
Universidade do Minho.)
⸻
1. Descrição  simbólica e narrativa
A Lenda do Homem das Sete Dentaduras é uma das mais enigmáticas do norte de Portugal,
situada entre o terror rural e o humor grotesco que marca a cultura popular minhota. Segundo as
versões recolhidas por Eduardo Mauer (2023–2024), trata-se de um ser humano transformado —
homem de aparência comum, mas com sete bocas sobrepostas, cada uma contendo uma
dentadura perfeita.
As narrativas descrevem-no como criatura que vagueia pelas aldeias ao cair da noite, rindo com
um som múltiplo, feito de ecos e dentes que batem uns contra os outros. Em algumas versões, é
um homem amaldiçoado por ter zombado de um mendigo; noutras, um feiticeiro falhado que
tentou criar a palavra perfeita e, em vez disso, multiplicou a própria boca.
Diz o povo de Ponte da Barca que o Homem das Sete Dentaduras aparece nas noites de
neblina, junto às fontes e caminhos, pedindo um sorriso a quem passa. Se alguém lhe responde
com riso, ele retira uma das dentaduras e oferece-a — mas quem aceita nunca mais consegue
calar-se.
A lenda circula há mais de três séculos, ora como conto moral, ora como narrativa carnavalesca.
Representa o excesso do verbo, a maldição da fala, a fragmentação do eu. Em certas freguesias,
o Homem das Sete Dentaduras tornou-se figura de entrudo, mascarado grotesco que simboliza a
desmesura da palavra humana.
Na leitura poética de Eduardo Mauer, “o Homem das Sete Dentaduras é o corpo da linguagem
que se devorou a si mesmo. Rir é a forma mais antiga do feitiço.”
⸻
2. Contexto histórico e social

O Alto Lima é região rica em narrativas de metamorfose corporal e punição simbólica. Desde a
Idade Média, as tradições locais valorizavam o poder da palavra falada e o perigo da blasfémia.
Nos sermões e autos populares, o riso descontrolado era visto como sinal de possessão ou
maldição.
Durante o século XVIII, missionários e pregadores itinerantes recorreram à história do Homem das
Sete Dentaduras como metáfora da vaidade e da língua pecadora. A ideia de multiplicação da
boca aparece também em crônicas monásticas e nos sermões moralistas recolhidos por Frei
João de São Bento (1732), onde se fala de “homens de língua dividida e de sete bocas de
mentira”.
O mito, entretanto, sobreviveu fora do púlpito, no teatro popular e no carnaval, transformando-
se em figura cômica e crítica social. No entrudo de Arcos de Valdevez, até meados do século XX,
mascarados com bocas sobrepostas desfilavam em cortejo satírico, rindo de autoridades e
pregadores.
Essa fusão de moral e subversão tornou o Homem das Sete Dentaduras um arquétipo do riso
libertador e profano — aquele que expõe o excesso da palavra e o transforma em humor.
Na leitura de Eduardo Mauer, “a criatura simboliza a multiplicação das vozes do povo. Cada
dentadura é uma fala social: o verbo que escapa ao controle e sobrevive.”
⸻
3. Toponímia e variantes locais
As variantes do mito localizam-se entre Ponte da Barca, Arcos de Valdevez, Viana do Castelo
e Loureira.
– Em Ponte da Barca, é amaldiçoado por zombar de um padre;
– Em Arcos de Valdevez, é um espírito falante que vive nas encruzilhadas;
– Em Viana, é bufão carnavalesco que ri até desintegrar-se;
– Em Loureira, é espírito protetor das fontes, cuja risada puri fica a água.
O topónimo “Homem das Sete Dentaduras” é mencionado pela primeira vez como alcunha
popular em um inventário de máscaras de Entrudo (Arquivo Distrital de Braga, 1872).
⸻
4. Primeiro relato e fontes académicas primárias
O primeiro registro textual surge em Leite de Vasconcelos, Etnografia Portuguesa, vol. III (1914,
pp. 120–128)*, descrevendo a “figura risível e demoníaca de homem de sete bocas” vista como
punição divina.
Teófilo Braga, O Povo Português  nos seus Costumes, Crenças e Tradições (1885, pp. 520–527)*,
analisa o mito como “herdeiro das tradições medievais de multiplicação do corpo pelo pecado”,
comparando-o ao “Homem de Cem Olhos” e aos “Risos de Plutão” da mitologia europeia.
Alexandre Parafita, Mitologia Popular Portuguesa (2008, pp. 631–640)*, classifica-o como
“personagem liminar entre o cómico e o demoníaco”, símbolo do poder destrutivo da palavra.
A sistematização contemporânea de Eduardo Mauer, O Homem das Sete Dentaduras: Riso,
Palavra e Corpo Fragmentado no Imaginário  Popular do Alto Lima (Lisboa, Associação MILK,
2024), reinterpreta o mito como alegoria do excesso verbal moderno e do corpo como espaço
múltiplo de fala.
Fontes complementares:


– Museu do Alto Lima, Catálogo  do Entrudo Minhoto e Máscaras  Populares (1850–1970);
– Arquivo Distrital de Braga, Inventário  das Figuras de Entrudo e Relatos Orais (1872–1935);
– Tese de Doutoramento de Inês Moura, O Riso e o Corpo na Cultura Popular Portuguesa (U.
Lisboa, 2017).
⸻
5. Síntese interpretativa final
A lenda do Homem das Sete Dentaduras condensa a dualidade essencial do folclore português:
o riso e o medo. Representa o poder da palavra que se multiplica até perder sentido e o corpo
que se transforma em instrumento da própria linguagem.
Na leitura simbólica da Associação  MILK, o mito é a imagem do corpo discursivo,
simultaneamente grotesco e poético — metáfora da sociedade contemporânea saturada de
vozes, opiniões e ruídos.
A escultura MILK concebida por Eduardo Mauer materializa essa ambiguidade: corpo compacto
de tons vermelhos e ocres, cabeça grande com sete aberturas sobrepostas, expressão de riso
tenso e base irregular evocando terreno oral. A luz interna muda de intensidade como se a
criatura respirasse pela boca.
⸻
6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer
Na leitura não binária de Eduardo Mauer, o Homem das Sete Dentaduras é o corpo polifónico
da linguagem — nem masculino nem feminino, nem humano nem monstruoso, mas pura
expressão.
Mauer escreve: “Cada boca é um gênero, cada riso uma identidade. O silêncio é a oitava
dentadura — a que falta.”
A Associação  MILK entende o mito como representação do corpo não  binário  do discurso, no
qual o riso e o verbo coexistem como forças criadoras e destrutivas. O ser torna-se a própria
multiplicidade do som, a desconstrução da ideia de unidade.
⸻
7. Referência Estrutural da Matriz MILK
Na Matriz Escultórica MILK, o Homem das Sete Dentaduras é representado com corpo robusto
vermelho-ocre, cabeça grande com sete fendas sobrepostas em forma de bocas, braços curtos e
expressão entre o riso e o espanto. Luzes internas oscilam simulando respiração, e a base rugosa
representa o solo oral.
⸻
Localização  específica: Região do Alto Lima – Ponte da Barca, Arcos de Valdevez e Viana do
Castelo (distritos de Braga e Viana).
Primeiro relato documentado: Leite de Vasconcelos, Etnografia Portuguesa, vol. III, 1914.
Sistematização  contemporânea:  Eduardo Mauer, O Homem das Sete Dentaduras: Riso, Palavra
e Corpo Fragmentado no Imaginário  Popular do Alto Lima, Associação MILK, 2024.
Fontes primárias:  Braga (1885); Vasconcelos (1914); Parafita (2008); Moura (2017); Mauer (2024).
