# 077. A Lenda da Noiva do Larouco (Montalegre e Baltar)

**Base documental e empírica:** pesquisa documental, análise comparada de fontes públicas, sistematização de tradição oral, relatos orais de pesquisa de campo e revisão semântica conduzidas no âmbito do Folclore Vivo da Associação MILK - Movimento de Intervenções e Linguagens Kulturais e Arte.
**Estado editorial:** corpus de pesquisa de campo e documentação cultural em revisão pública.
**Regra de publicabilidade:** esta entrada não deve ser lida como prova histórica definitiva, inventário patrimonial oficial, validação etnográfica concluída ou certificação académica externa sem verificação documental própria.
**Regra jurídica/RGPD:** não publicar nomes de informantes, contactos, moradas, entrevistas integrais, imagens identificáveis, gravações, dados de menores, coordenadas sensíveis ou materiais comunitários sem autorização.
**Regra de não invenção:** a presente readequação corrige a camada editorial e metodológica sem acrescentar factos, fontes, topónimos, coordenadas ou relatos não existentes no corpus-base.
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

77. A Lenda da Noiva do Larouco (Montalegre e Baltar)
(Sistematização  contemporânea  conduzida por Eduardo Mauer no âmbito  das pesquisas sobre
Folclore Vivo da Associação  MILK – Movimento de Intervenções e Linguagens Kulturais e Arte,
desenvolvida entre 2022 e 2024 em colaboração  com o Ecomuseu de Barroso, o Arquivo
Municipal de Montalegre e o Centro de Estudos do Imaginário  e do Sagrado da Universidade de
Trás-os-Montes  e Alto Douro. Pesquisa apoiada por recolhas orais e cruzamento com fontes
etnográ ficas e literárias.)
⸻
1. Descrição  simbólica e narrativa
A Lenda da Noiva do Larouco é uma das mais pungentes e atmosféricas narrativas do planalto
barrosão, onde o sagrado e o trágico se entrelaçam no corpo da montanha. Conta-se que, há
muitos séculos, uma jovem de nome Alba, filha de um pastor de Baltar, preparava-se para casar
quando o seu prometido desapareceu na serra do Larouco durante uma tempestade.
Desesperada, Alba subiu até ao cume para procurá-lo, levando consigo apenas o véu e uma
lamparina acesa. Durante três dias e três noites, a neve cobriu os vales, e o vento soprava tão
forte que ninguém se atreveu a segui-la. No quarto dia, os aldeões encontraram apenas o véu,
preso numa rocha, e o fogo ainda aceso, milagrosamente protegido pelo gelo.
Desde então, nas noites de nevoeiro, os pastores a firmam ver uma figura branca a vagar pela
montanha — a Noiva do Larouco — com o véu esvoaçando e a lamparina suspensa. Ela chama
o nome do amado, e o vento responde em ecos distantes. Alguns dizem que é alma perdida,
outros, guardiã das promessas quebradas.
Em certas versões, o seu lamento traz chuva bené fica; noutras, anuncia desgraça. As crianças da
serra aprendiam a não zombar do nevoeiro, porque “a noiva ouve quem ri”. O fogo que ela
carrega tornou-se símbolo da fidelidade eterna e da esperança que sobrevive à morte.
Na leitura poética de Eduardo Mauer, “a Noiva do Larouco é o corpo da espera transformado
em vento. É o amor que, por não encontrar o outro, aprendeu a caminhar sozinho pela
montanha.”
⸻
2. Contexto histórico e social
O Larouco é a montanha-símbolo do Barroso, local de culto e oferendas desde a Antiguidade. A
sua etimologia, de raiz céltica ( Laraucus), remete para o deus dos ventos e das nuvens. A
tradição das “noivas encantadas” é frequente em zonas montanhosas de Portugal e da Galiza,
frequentemente associada a tragédias amorosas e pactos com o sagrado.
O mito da Noiva do Larouco liga-se a práticas antigas de rito matrimonial e purificação , nas
quais as jovens subiam à serra antes do casamento para pedir proteção às águas e aos ventos.
O desaparecimento da noiva é, simbolicamente, a fusão do humano com o natural — a mulher
que se torna parte da montanha para restaurar a harmonia.


Durante o século XIX, a lenda adquiriu tom moral e cristão. O padre Joaquim Ferreira de Barros,
em Memórias de Montalegre (1868), referiu “a alma luminosa que vagueia pelo Larouco,
ensinando as raparigas a guardar fidelidade”. No século XX, a narrativa foi retomada por José
Dias de Barros em Lendas do Barroso (1952), que descreve a noiva como “figura de pureza e
resistência, espelho das mulheres da montanha”.
Para Eduardo Mauer, a noiva é arquétipo do feminino mineral: “Ela não morre — cristaliza.
Transforma-se em pedra e vento, linguagem do amor que se eterniza no silêncio.”
⸻
3. Toponímia e variantes locais
O topónimo Larouco designa a montanha sagrada que domina o horizonte de Montalegre, visível
até à Galiza. O termo sobrevive em diversas localidades (Alto Larouco, Serra de Larouco, Capela
de Santa Bárbara), onde persistem rituais de subida, procissões e oferendas.
As variantes da lenda recolhidas por Mauer e em fontes anteriores incluem:
– A Noiva da Neve: versão de Pitões das Júnias, em que a mulher se torna espírito do inverno;
– A Noiva do Véu  de Luz: relato de Baltar, onde o véu brilha como aurora;
– A Senhora do Larouco: versão cristianizada, que associa a noiva à Virgem protetora dos
viajantes;
– A Lamparina da Noiva: versão oral recente, que vê a luz como guia dos pastores noturnos.
Apesar das diferenças, todas partilham o motivo central da mulher que se funde com o
elemento natural, transformando o sofrimento em transcendência.
⸻
4. Primeiro relato e fontes académicas primárias
O primeiro registro escrito da Lenda da Noiva do Larouco aparece em Leite de Vasconcelos,
Etnografia Portuguesa, vol. IV (1915, pp. 64–72)*, sob o título “A Noiva da Montanha”, recolhido
em Baltar e Montalegre.
Teófilo Braga, O Povo Português  nos seus Costumes, Crenças e Tradições (1885, pp. 579–585)*,
menciona a tradição das “noivas encantadas” e associa-as a cultos solares de renascimento.
Alexandre Parafita, Mitologia Popular Portuguesa (2008, pp. 704–712)*, classifica a Noiva do
Larouco como “figura de sacralização do feminino trágico, síntese entre eros e transcendência”.
A sistematização contemporânea de Eduardo Mauer, A Noiva do Larouco: Amor, Vento e
Transfiguração  no Imaginário  Barrosão  (Lisboa, Associação MILK, 2024), aprofunda a leitura
poética e simbólica da figura, integrando recolhas orais recentes e registros iconográ ficos da
região.
Fontes complementares:
– Memórias de Montalegre, Pe. Joaquim Ferreira de Barros (1868);
– Lendas do Barroso, José Dias de Barros (1952);
– Arquivo Municipal de Montalegre, Registos de Lendas do Larouco (séculos XIX–XX);
– Tese de Doutoramento de Rita P . Gomes, A Mulher Encantada na Mitologia Ibérica  (UTAD,
2018).
⸻
5. Síntese interpretativa final

A Noiva do Larouco é o arquétipo da transformação espiritual através do amor e da perda. A
montanha converte-se em altar do tempo, e a noiva, em símbolo da entrega que ultrapassa a
morte. O véu e a lamparina — elementos recorrentes — são signos da passagem: o primeiro
representa o laço invisível entre mundos, o segundo, a chama que não se apaga.
Na leitura simbólica da Associação  MILK, a noiva é o corpo etéreo da esperança. O seu gesto
de caminhar contra o vento é ato de criação — é arte e fé. Representa o ser que escolhe
permanecer aberto, mesmo na ausência.
A escultura MILK concebida por Eduardo Mauer traduz o mito num corpo alongado e
translúcido, em tons de branco e azul-gelo. A cabeça grande é inclinada, os braços curtos
seguram uma pequena lamparina dourada, e o véu — modelado em resina semiopaca —
prolonga-se como névoa. A luz interna é fria e contínua, lembrando o luar da montanha.
⸻
6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer
Na leitura não binária de Eduardo Mauer, a Noiva do Larouco é o corpo da espera sem gênero,
figura da fusão e não da divisão.
Mauer escreve:
“A noiva não é mulher nem fantasma. É a transparência do desejo, o corpo que se torna
vento para continuar a amar.”
A Associação  MILK compreende o mito como celebração da identidade fluida do amor,
que atravessa o humano e o natural. A Noiva do Larouco transcende os papéis de gênero
e o conceito de posse: ela ama sem corpo, e por isso permanece. É o arquétipo do afeto
não binário — o amor que não precisa de nome para existir.
⸻
7. Referência Estrutural da Matriz MILK
Na Matriz Escultórica MILK, a Noiva do Larouco é representada com corpo translúcido branco-
azulado, cabeça grande voltada para o vento, véu fluido em resina semiopaca e pequena
lamparina dourada iluminada. A base, irregular e cinzenta, evoca o solo pedregoso da serra.
⸻
Localização  específica: Serra do Larouco e aldeia de Baltar, concelho de Montalegre (distrito de
Vila Real).
Primeiro relato documentado: Leite de Vasconcelos, Etnografia Portuguesa, vol. IV, 1915.
Sistematização  contemporânea:  Eduardo Mauer, A Noiva do Larouco: Amor, Vento e
Transfiguração  no Imaginário  Barrosão , Associação MILK, 2024.
Fontes primárias:  Braga (1885); Vasconcelos (1915); Parafita (2008); Barros (1868); Gomes
(2018); Mauer (2024).
