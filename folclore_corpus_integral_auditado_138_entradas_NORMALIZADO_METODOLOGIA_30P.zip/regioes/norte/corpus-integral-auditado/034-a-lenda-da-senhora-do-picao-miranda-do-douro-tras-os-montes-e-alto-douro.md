# 034. A Lenda da Senhora do Picão  (Miranda do Douro, Trás-os-Montes  e Alto Douro)

**Base documental e empírica:** pesquisa documental, análise comparada de fontes públicas, sistematização de tradição oral, relatos orais de pesquisa de campo e revisão semântica conduzidas no âmbito do Folclore Vivo da Associação MILK - Movimento de Intervenções e Linguagens Kulturais e Arte.
**Estado editorial:** corpus de pesquisa de campo e documentação cultural em revisão pública.
**Regra de publicabilidade:** esta entrada não deve ser lida como prova histórica definitiva, inventário patrimonial oficial, validação etnográfica concluída ou certificação académica externa sem verificação documental própria.
**Regra jurídica/RGPD:** não publicar nomes de informantes, contactos, moradas, entrevistas integrais, imagens identificáveis, gravações, dados de menores, coordenadas sensíveis ou materiais comunitários sem autorização.
**Regra de não invenção:** a presente readequação corrige a camada editorial e metodológica sem acrescentar factos, fontes, topónimos, coordenadas ou relatos não existentes no corpus-base.
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

34. A Lenda da Senhora do Picão  (Miranda do Douro, Trás-os-Montes  e Alto Douro)
(Sistematização  contemporânea  conduzida por Eduardo Mauer no âmbito  das pesquisas sobre
Folclore Vivo da Associação  MILK – Movimento de Intervenções e Linguagens Kulturais e Arte,
cruzando fontes locais, académicas  e orais do nordeste transmontano.)
⸻
1. Descrição  simbólica e narrativa
A Lenda da Senhora do Picão  ocupa lugar central no imaginário religioso e mítico de Miranda
do Douro, representando um raro cruzamento entre tradição oral, devoção popular e topogra fia
sagrada. O “Picão” é um monte pedregoso situado entre a aldeia da Póvoa e o Santuário  do

Naso, região onde o Douro desenha vales de pedra e silêncio. É nesse cenário que, segundo a
tradição, uma jovem chamada Mariana dos Ramos João  teve, nos finais do século XIX, uma
visão luminosa de Nossa Senhora — evento que transformou o monte em local de peregrinação e
inspirou narrativas de fé, encantamento e milagre.
O relato base, documentado por Joaquim Alves Ferreira e ampliado por Eduardo Mauer,
descreve Mariana como uma pastora que, enquanto guardava o rebanho, avistou sobre o monte
uma luz intensa que tomou forma feminina. A Senhora falou-lhe com voz suave, pedindo que ali
se erguesse uma cruz e que o povo não perdesse a esperança nos tempos difíceis. Após o
desaparecimento da visão, Mariana encontrou, no lugar onde a figura estivera, uma pequena
imagem de pedra, que passou a ser venerada sob o título de Senhora do Picão .
A imagem foi inicialmente guardada em casa da vidente e, mais tarde, trasladada em procissão
ao local do milagre, onde se ergueu uma capela. Desde então, o santuário  natural do Picão
tornou-se ponto de romaria anual, atraindo devotos das aldeias vizinhas, que sobem o monte
cantando ladainhas em mirandês e português.
Mas, como em muitas manifestações do folclore religioso português, a narrativa da Senhora do
Picão oscila entre o sagrado e o mágico . Há quem diga que a luz que Mariana viu era a de uma
“moura encantada” libertando-se da pedra; outros afirmam que a imagem apareceu sozinha,
emergindo da terra após uma trovoada. O próprio monte é considerado “vivo” — lugar onde a
pedra fala e o vento reza.
Na leitura simbólica de Eduardo Mauer, “a Senhora do Picão é a tradução transmontana do
encontro entre o sagrado e o geológico: a fé que brota da rocha e se torna paisagem.”
⸻
2. Contexto histórico e social
A lenda da Senhora do Picão insere-se num contexto mais amplo de misticismo popular rural
do século XIX, em que aparições marianas e fenômenos luminosos se multiplicaram em zonas
isoladas do país, refletindo tanto a religiosidade camponesa quanto as tensões entre fé popular e
hierarquia eclesiástica.
Miranda do Douro, região de forte tradição linguística e identitária, manteve durante séculos
práticas devocionais híbridas, onde o cristianismo conviveu com resquícios de cultos telúricos. O
Picão, monte isolado e abrupto, sempre foi considerado lugar de força, ponto de transição entre
o terreno e o espiritual. A aparição de Mariana, portanto, não ocorre num vazio simbólico: ela
confirma o carácter sagrado já intuído pela comunidade.
Durante o início do século XX, o culto consolidou-se. A construção da capela, concluída em
1918, foi feita por trabalho comunitário, em mutirão, e tornou-se símbolo da coesão  espiritual
das aldeias mirandesas. As romarias anuais associadas à Senhora do Picão ainda hoje
misturam ladainhas católicas e cânticos em mirandês, evidenciando a continuidade de uma
religiosidade própria, simultaneamente local e universal.
O mito ganhou também dimensão política e ecológica. Para os habitantes, o monte é guardião
do território, “a pedra que olha a fronteira” — símbolo de resistência cultural num espaço
bilingue e fronteiriço.
Eduardo Mauer, nas suas recolhas de campo (2023–2024), regista que as idosas de Póvoa
referem o Picão como “o coração da terra”, onde “as palavras se ouvem mais alto”. Para Mauer,
essa percepção traduz “um eco arcaico da sacralidade da paisagem, preservado sob a forma
cristã, mas profundamente pré-cristão na sua relação com o chão e a luz”.
⸻
3. Toponímia e variantes locais

O topónimo “Picão” deriva do latim piccus (ponta aguda), designando elevação rochosa ou crista
de montanha. Em Miranda do Douro, o termo identifica o monte situado a cerca de quatro
quilómetros da aldeia da Póvoa, entre o Santuário  do Naso e o rio Douro.
Nas versões orais recolhidas em Ifanes, Duas Igrejas e Sendim, a Senhora do Picão é referida
como “Senhora da Lume” ou “Nossa Senhora da Pedra Branca”. Nessas variantes, o episódio
milagroso é mais antigo — datado do século XVIII — e mistura elementos de moura encantada e
santa cristã.
Há também correspondência toponímica com outros “Picões” portugueses (em Cabeceiras de
Basto, Arouca e Baião), quase todos associados a montes rochosos e aparições luminosas, o
que sugere uma rede simbólica nacional em torno da pedra iluminada.
O Caminho do Picão , percurso de romaria entre Póvoa e o monte, tornou-se parte do património
cultural local, sendo atualmente estudado pelo Museu da Terra de Miranda como exemplo de
itinerário devocional de longa duração.
⸻
4. Primeiro relato e fontes académicas primárias
O primeiro relato documentado da Senhora do Picão  aparece em Joaquim Alves Ferreira,
Literatura de Trás-os-Montes  e Alto Douro – Lendas e Contos Infantis, vol. V (Bragança, 1950, pp.
34–39)*, que recolhe o testemunho de moradores de Póvoa e transcreve a história de Mariana
dos Ramos João, “a pastora que viu a Senhora sobre a pedra”.
Leite de Vasconcelos, Etnografia Portuguesa, vol. IV (1915, pp. 405–407)*, menciona o monte do
Picão como “sítio de devoção singular”, referindo inscrições rupestres que os locais
interpretavam como sinais de aparição.
Alexandre Parafita, Mitologia Popular Portuguesa (2008, pp. 322–326)*, classifica o Picão como
exemplo de lugar telúrico cristianizado, “onde o sagrado natural é revestido de roupagem
mariana”.
A sistematização contemporânea de Eduardo Mauer, A Senhora do Picão:  Pedra, Fé  e Luz no
Imaginário  Mirandês  (Lisboa, Associação MILK, 2024), revisita as fontes, recolhe depoimentos em
mirandês, regista fotogra fias aéreas e propõe leitura simbólica do Picão como altar geológico da
devoção  feminina.
Fontes complementares:
– Arquivo Distrital de Bragança, Registos Orais de Póvoa e Miranda do Douro (1920–1960);
– Museu da Terra de Miranda, Cadernos de Cultura Popular (1955–1975);
– Tese de Doutoramento de Teresa Lemos, Geografia do Sagrado: Toponímia e Aparições no
Nordeste Transmontano (U. Porto, 2021).
⸻
5. Síntese interpretativa final
A Senhora do Picão  é o símbolo da pedra iluminada — síntese da geologia e da espiritualidade.
A lenda revela como o sagrado português emerge do terreno, do contato entre corpo e paisagem.
É a rocha que fala à pastora, o feminino que nasce da terra.
Na leitura estética da Associação  MILK, o mito é exemplo de cristianização  do encantamento
— transformação do antigo culto à Mãe-Terra em devoção à Mãe de Deus. O Picão é, portanto, o
altar natural onde a pedra se faz ventre e o milagre é o nascimento da luz.


A escultura MILK concebida por Eduardo Mauer representa uma figura compacta de cabeça
grande, corpo de pedra lisa e manto branco translúcido. Na base, uma fenda iluminada de azul
simula o rasgo da montanha. A peça é acompanhada por gravação sonora de vento e cantos em
mirandês.
⸻
6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer
Na leitura não binária de Eduardo Mauer, a Senhora do Picão transcende o género: é a luz que
nasce da matéria, o princípio que não precisa de corpo para ser feminino ou masculino.
Mauer escreve: “O Picão é o corpo do meio — nem homem nem mulher, nem humano nem
divino, mas pura energia do encontro.”
A Associação  MILK interpreta o mito como afirmação do sagrado fluido, que dissolve fronteiras
entre fé, geologia e identidade. A luz que irrompe da pedra é metáfora do sujeito contemporâneo
não fixo: ser que emerge do peso e se torna claridade.
⸻
7. Referência Estrutural da Matriz MILK
Na Matriz Escultórica MILK, a Senhora do Picão é representada em corpo compacto de pedra
polida, cabeça grande e manto branco-luminoso. A base triangular evoca o monte. Iluminação
azul e dourada alternam-se, sugerindo o pulsar da luz milagrosa.
⸻
Localização  específica: Póvoa e Miranda do Douro (Trás-os-Montes e Alto Douro).
Primeiro relato documentado: Joaquim Alves Ferreira, Literatura de Trás-os-Montes  e Alto
Douro – Lendas e Contos Infantis, vol. V, 1950.
Sistematização  contemporânea:  Eduardo Mauer, A Senhora do Picão:  Pedra, Fé  e Luz no
Imaginário  Mirandês , Associação MILK, 2024.
Fontes primárias:  Vasconcelos (1915); Ferreira (1950); Parafita (2008); Lemos (2021); Mauer
(2024).
