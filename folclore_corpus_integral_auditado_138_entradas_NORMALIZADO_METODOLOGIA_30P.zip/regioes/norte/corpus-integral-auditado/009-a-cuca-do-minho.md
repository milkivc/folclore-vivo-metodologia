# 009. A Cuca do Minho

**Base documental e empírica:** pesquisa documental, análise comparada de fontes públicas, sistematização de tradição oral, relatos orais de pesquisa de campo e revisão semântica conduzidas no âmbito do Folclore Vivo da Associação MILK - Movimento de Intervenções e Linguagens Kulturais e Arte.
**Estado editorial:** corpus de pesquisa de campo e documentação cultural em revisão pública.
**Regra de publicabilidade:** esta entrada não deve ser lida como prova histórica definitiva, inventário patrimonial oficial, validação etnográfica concluída ou certificação académica externa sem verificação documental própria.
**Regra jurídica/RGPD:** não publicar nomes de informantes, contactos, moradas, entrevistas integrais, imagens identificáveis, gravações, dados de menores, coordenadas sensíveis ou materiais comunitários sem autorização.
**Regra de não invenção:** a presente readequação corrige a camada editorial e metodológica sem acrescentar factos, fontes, topónimos, coordenadas ou relatos não existentes no corpus-base.
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

A Cuca do Minho
(Sistematização  contemporânea  conduzida por Eduardo Mauer e Nuno Araújo no âmbito  das
pesquisas sobre Folclore Vivo da Associação  MILK – Movimento de Intervenções e Linguagens
Kulturais e Arte)
⸻
1. Descrição  simbólica e narrativa
A Cuca do Minho é uma das figuras mais persistentes do imaginário popular português e uma
das mais complexas no seu trânsito entre o medo, a pedagogia moral e o arquétipo feminino do
poder ancestral. Conhecida também por Coca, Cucla, Cuca Velha ou Cuca-Fada, é representada
como uma mulher de idade indefinida, de feições reptilianas, dentes pontiagudos, cabelos
longos e desgrenhados, olhos de fogo e corpo coberto por escamas esverdeadas. Em

certas aldeias é vista como bruxa que devora crianças desobedientes; noutras, como
protetora dos campos e guardiã  dos tesouros encantados.
No âmbito das investigações do programa Folclore Vivo, a Cuca aparece sempre associada à
água e ao limiar entre o dia e a noite. É vista à beira dos rios, nos poços ou em pontes antigas,
emergindo de névoas húmidas. O seu aparecimento é acompanhado de cheiro a terra molhada e
de um zumbido baixo, semelhante ao rumor das cigarras. As crianças aprendiam a temê-la: “Não
vás ao rio ao entardecer, que a Cuca te leva.” Essa ameaça, embora disciplinar, revela o eco de
um antigo mito aquático, remanescente das deusas telúricas da fertilidade.
O nome “Cuca” tem raízes profundas. Etimologicamente, deriva de cocatrix (do latim tardio
cocatrix, “serpe com cabeça de galo”), termo que deu origem ao cockatrice inglês e ao coca
espanhol — híbrido entre serpente e dragão. A mesma raiz originou a “Coca de Monção”, com
quem partilha ascendência simbólica. No entanto, no Minho, a Cuca assume feição mais
humana, feminina e noturna.
As descrições populares alternam entre grotesco e sublime: uma velha disforme de dia, uma
mulher belíssima de noite; criatura que dorme sob os moinhos e desperta nas tempestades. Em
algumas aldeias do Vale do Lima e de Ponte da Barca, acredita-se que ela vive num poço de
águas verdes, de onde sai apenas para assustar quem profana o silêncio das noites santas.
Noutras narrativas, ela é feiticeira libertadora — mulher sábia que conhece ervas e curas e que
o povo transformou em monstro para justificar o medo do saber feminino.
Segundo Eduardo Mauer e Nuno Araújo, a Cuca do Minho é figura-limite do feminino
reprimido: mulher transformada em fera pela moral cristã, símbolo da sabedoria interditada. É o
eco das sacerdotisas serpentinas do mundo céltico-lusitano, que guardavam fontes e grutas
sagradas. O seu rugido é, para Mauer, o som ancestral do poder feminino a que se tentou
silenciar.
⸻
2. Contexto histórico e social
O mito da Cuca está profundamente ligado à transição entre o paganismo e o cristianismo na
Península Ibérica. Desde a Antiguidade, a serpente era símbolo da regeneração, associada à
terra, ao conhecimento e à sexualidade. As deusas-serpente — como Epona, Nabia ou Ataecina
— povoavam o território lusitano, especialmente o Noroeste, região de fontes e rios sagrados.
Com a expansão do cristianismo, essas divindades foram reinterpretadas como demónios ou
monstros.
Durante a Idade Média, a Igreja intensi ficou a demonização do feminino associado à natureza. As
mulheres que conheciam ervas medicinais, que viviam isoladas ou que se recusavam a submeter-
se às normas sociais, tornaram-se alvo de perseguição. A Cuca nasceu desse processo de
repressão simbólica. O que fora deusa tornou-se ameaça; o sagrado feminino converteu-se em
medo popular.
No século XVII, crónicas inquisitoriais mencionam “mulheres do rio” e “bruxas-serpente” no norte
de Portugal, especialmente nas margens do Lima e do Cávado. Muitas foram acusadas de “falar
com as águas” ou “dominar trovoadas”. Essas descrições sobrepõem-se às lendas da Cuca, que
continuou viva na oralidade, associada ao controlo moral das crianças e das mulheres.
No século XIX, Teófilo Braga e Leite de Vasconcelos registaram várias versões da Cuca no
Minho, nas quais ela surge já despojada de estatuto divino, mas ainda detentora de aura mística.
As mães e avós usavam o mito como narrativa disciplinar: “A Cuca leva quem não dorme”, “A
Cuca vem buscar os mentirosos”. Contudo, sob a camada de terror infantil, persistia o eco
arcaico da guardiã das águas e da fertilidade.
No contexto social contemporâneo, a Cuca recupera nova dimensão. A Associação  MILK,
através da leitura proposta por Mauer, devolve-lhe o estatuto simbólico de resistência cultural: o

corpo feminino, híbrido e múltiplo, que sobreviveu às interdições históricas e continua a
assombrar como memória viva do sagrado interdito.
⸻
3. Toponímia e variantes locais
A presença da Cuca é particularmente forte no Vale do Lima, Ponte da Barca, Arcos de
Valdevez, Monção  e Viana do Castelo, regiões de rios e planícies agrícolas. Locais como o
Poço da Cuca (em Lavradas) e a Lomba das Cuclas (em Ponte da Barca) conservam o nome
como marca toponímica.
Existem também variantes: a Cuca do Cávado , ligada às tempestades; a Cuca das Pedras (em
Melgaço), que transforma em pedra quem a desafia; e a Cucla de Monção , versão aquática que
protege tesouros. Em algumas aldeias, a Cuca é representada em festas populares como boneco
grotesco queimado em fogueiras de São João, repetindo o ritual europeu de puri ficação pelo
fogo.
Essas variantes mostram o caráter difuso e adaptável do mito, capaz de fundir crenças pré-
cristãs, moral cristã e práticas festivas.
⸻
4. Primeiro relato e fontes académicas primárias
O primeiro registo escrito sobre a Cuca em Portugal aparece em Teófilo Braga, O Povo
Português  nos seus Costumes, Crenças e Tradições (1883, p. 416), onde se lê: “No Minho, falam
as mães às crianças da Cuca, bruxa velha de dentes compridos que mora no rio e busca os que
choram.”
Leite de Vasconcelos, Etnografia Portuguesa, vol. II (1913, p. 203), classifica-a como “entidade
aquática de origem céltica, persistente nas margens do Lima e Cávado”.
Consiglieri Pedroso, Contribuições para uma Mitologia Popular Portuguesa (1897), aponta
paralelos entre a Cuca minhota e o cocatrix europeu, observando a fusão entre serpente e mulher.
Alexandre Parafita, Mitologia Popular Portuguesa (2008), descreve a Cuca como “figura de
transição entre o medo e o sagrado, o castigo e o desejo”.
Fontes complementares incluem:
– Arquivo Municipal de Viana do Castelo, Caderno de Lendas do Lima (1875);
– Museu do Traje, coleção “Figuras Populares do Minho” (1890–1900);
– Tese de Doutoramento de Andreia Cerqueira, Monstros e Matriarcas: A Demonização  do
Feminino nas Tradições Portuguesas (U. do Minho, 2020).
⸻
5. Síntese interpretativa final
A Cuca do Minho é a imagem do poder que resiste. Monstro e deusa, velha e jovem, humana e
serpente, ela encarna o inconsciente arcaico da cultura portuguesa — o medo do feminino livre.
Sob o disfarce grotesco, a Cuca preserva a dignidade das antigas divindades da terra.
Para a Associação  MILK, o mito simboliza a recuperação  da sabedoria interditada. A Cuca
não é ameaça, mas memória; não castigo, mas retorno. A sua monstruosidade é apenas re flexo
da violência simbólica que o patriarcado impôs ao corpo feminino e à diferença.


Na escultura MILK de Eduardo Mauer, a Cuca é reinterpretada como ser híbrido: corpo
compacto e escamado, cabeça grande, olhos brilhantes e sorriso ambíguo. O verde-esmeralda
funde-se com o dourado e o negro, sugerindo profundidade e poder. A textura acetinada do
corpo imita a umidade da pele reptiliana, e o olhar frontal devolve ao espectador a força daquilo
que fora ocultado.
⸻
6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer e Nuno Araújo
A leitura não binária de Eduardo Mauer e Nuno Araújo propõe que a Cuca do Minho seja vista
como figura queer arquetípica, cuja monstruosidade nasce da incapacidade social de lidar com
a ambiguidade. O seu corpo — simultaneamente feminino e reptiliano, humano e não humano —
desafia qualquer definição rígida de género, natureza ou moralidade.
Para Mauer, a Cuca é o “corpo queer primordial da mitologia portuguesa”: aquele que, ao recusar
o binário, obriga a cultura a confrontar-se com o próprio medo da fluidez. A sua metamorfose
constante — ora velha, ora jovem, ora fera, ora mulher — traduz o movimento vital das
identidades não fixas.
A boca aberta, símbolo do apetite e da fala, representa a reivindicação do corpo falante e
desejante. A Cuca fala alto porque foi silenciada; devora porque foi privada. O seu rugido ecoa o
grito das vozes marginalizadas.
Na leitura filosófica e estética da Associação  MILK, a Cuca torna-se alegoria da emancipação
dos corpos híbridos: seres que escapam à norma e reinventam o mundo através da diferença. É
também metáfora da criação artística — processo que, como ela, se alimenta do abismo e
devolve forma ao caos.
⸻
7. Referência Estrutural da Matriz MILK
Na Matriz Escultórica MILK, a Cuca é modelada com corpo compacto e escamas estilizadas,
cabeça grande, boca semiaberta e expressão ambígua entre o riso e o grito. As cores
predominantes são verde-esmeralda, dourado e negro-azulado. O acabamento é brilhante, com
reflexos aquáticos.
A peça pode ser exibida sob luz verde e som de água corrente, evocando o regresso da deusa ao
seu domínio. A escultura simboliza o reencontro entre o sagrado e o profano, entre o corpo e a
natureza.
⸻
Localização  específica: Minho (Viana do Castelo, Ponte da Barca, Monção, Arcos de Valdevez).
Primeiro relato documentado: Teófilo Braga, O Povo Português  nos seus Costumes, Crenças e
Tradições, 1883.
Sistematização  contemporânea:  Eduardo Mauer, A Cuca do Minho: Feminino Proibido e
Memória das Águas , Associação MILK, 2024.
Fontes primárias:  Braga (1883); Vasconcelos (1913); Pedroso (1897); Parafita (2008); Cerqueira
(2020); Mauer (2024).
