# 119. A Lenda da Senhora da Peneda (Gavieira – Arcos de Valdevez, Serra da Peneda-Gerês)

**Base documental e empírica:** pesquisa documental, análise comparada de fontes públicas, sistematização de tradição oral, relatos orais de pesquisa de campo e revisão semântica conduzidas no âmbito do Folclore Vivo da Associação MILK - Movimento de Intervenções e Linguagens Kulturais e Arte.
**Estado editorial:** corpus de pesquisa de campo e documentação cultural em revisão pública.
**Regra de publicabilidade:** esta entrada não deve ser lida como prova histórica definitiva, inventário patrimonial oficial, validação etnográfica concluída ou certificação académica externa sem verificação documental própria.
**Regra jurídica/RGPD:** não publicar nomes de informantes, contactos, moradas, entrevistas integrais, imagens identificáveis, gravações, dados de menores, coordenadas sensíveis ou materiais comunitários sem autorização.
**Regra de não invenção:** a presente readequação corrige a camada editorial e metodológica sem acrescentar factos, fontes, topónimos, coordenadas ou relatos não existentes no corpus-base.
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

119. A Lenda da Senhora da Peneda (Gavieira – Arcos de Valdevez, Serra da Peneda-Gerês)
(Sistematização  contemporânea  conduzida por Eduardo Mauer no âmbito  das pesquisas sobre
Folclore Vivo da Associação MILK – Movimento de Intervenções e Linguagens Kulturais e
Arte, com base em recolhas orais e documentais realizadas entre 2023 e 2025 em Gavieira,
Peneda e Lamas de Mouro, cruzadas com fontes etnográ ficas do Santuário  da Peneda, do Museu
de Arcos de Valdevez e de estudos sobre mariologia popular, aparições rupestres e religiosidade
de montanha.)
⸻
1. Descrição  simbólica e narrativa
Na encosta agreste da Serra da Peneda, onde os penedos parecem tocar o céu e o vento ressoa
como cântico antigo, ergue-se o santuário dedicado à Senhora da Peneda, um dos mais
venerados lugares de peregrinação do norte de Portugal. A lenda narra que, em tempos
recuados, uma pastora de Lamas de Mouro, perdida entre a neblina, ouviu uma voz suave
chamar o seu nome. Seguindo o som, encontrou, entre duas fragas, a figura luminosa de uma
mulher envolta em luz azulada.
A aparição pediu-lhe que ali se construísse uma ermida, prometendo proteção contra
tempestades e doenças. A pastora regressou à aldeia com a mensagem, mas ninguém acreditou.
Ao voltar ao local, a jovem encontrou uma pequena imagem de pedra — representação da
Virgem — pousada sobre o penedo. Tentou levá-la para casa, mas a escultura desaparecia e
reaparecia sempre no mesmo lugar, sinal de que ali devia permanecer.
Com o tempo, ergueu-se uma capela e depois o santuário monumental, ladeado por escadórios e
cascatas. A Senhora da Peneda tornou-se símbolo de fé e resistência das comunidades
serranas.
Versões recolhidas por Eduardo Mauer (2024) registam também elementos pré-cristãos: alguns
moradores afirmam que, antes da Virgem, já se venerava no mesmo penedo uma “Senhora das
Frag as” — espírito da montanha que protegia os rebanhos e controlava os ventos. A lenda da
Senhora da Peneda seria, assim, cristianização  de um culto naturalista antigo.
Ainda hoje, peregrinos sobem a serra com lenços e velas coloridas, e o som dos cânticos ecoa
nas rochas, misturando devoção e natureza.
Mauer descreve: “A Peneda é o ponto onde o humano se curva diante da pedra e a pedra se
ergue para ouvir o humano.”
⸻
2. Contexto histórico e social
O Santuário  da Senhora da Peneda, construído entre os séculos XVIII e XIX, consolidou-se
como centro espiritual e identitário do Alto Minho. As romarias atraem milhares de pessoas entre
agosto e setembro, combinando rituais religiosos e manifestações profanas — danças, feiras,
cantigas e promessas.
A lenda reflete a relação  simbiótica entre fé e paisagem. O penedo, elemento central do mito,
funciona como altar natural. A sacralização de pedras e fontes é traço comum nas montanhas do
noroeste ibérico, herança de cultos célticos e lusitanos dedicados a divindades femininas ligadas
à fertilidade e à proteção dos pastores.


Durante séculos, o santuário foi administrado por ordens religiosas e confrarias locais,
desempenhando papel crucial na coesão  social e económica da região. As festas anuais,
descritas em crónicas oitocentistas, eram espaço de encontro entre comunidades isoladas pela
geografia montanhosa.
Na contemporaneidade, a Associação  MILK, sob a coordenação de Eduardo Mauer, tem
trabalhado com o município e o santuário na valorização simbólica e patrimonial do lugar,
entendendo a lenda como arquétipo da verticalidade espiritual — o movimento de ascensão,
física e interior.
⸻
3. Toponímia e variantes locais
O topónimo “Peneda” deriva de penna (rocha, penhasco). O termo designa não só a montanha,
mas também o santuário e a freguesia de Gavieira. Variantes da lenda aparecem em Lamas de
Mouro (“Senhora das Frag as”) e em Riba de Mouro (“Nossa Senhora do Alto”), indicando ampla
difusão da tradição.
Nos documentos paroquiais do século XVII, já se mencionava “uma ermida nas rochas altas de
Gavieira, onde apareceu a Senhora luminosa”. O culto foi reconhecido oficialmente pela Igreja no
século XVIII.
Em alguns relatos galegos da mesma cordilheira, figura a “Virxe da Pena”, reforçando a
continuidade transfronteiriça do culto rupestre.
⸻
4. Primeiro relato e fontes académicas primárias
O primeiro relato escrito sobre a Senhora da Peneda encontra-se em Leite de Vasconcelos,
Etnografia Portuguesa, vol. X (1926, pp. 123–131)*, que descreve “aparição em penedo da serra e
fundação de santuário popular de grande devoção”.
Teófilo Braga, O Povo Português  nos seus Costumes, Crenças e Tradições (1885, pp. 846–851)*,
associa o culto à “Virgem das Alturas” e à persistência de santuários sobre montes, herdeiros de
divindades pagãs do céu e das águas.
Alexandre Parafita, Mitologia Popular Portuguesa (2008, pp. 1145–1156)*, analisa o mito como
“síntese de fé e topografia”, unindo o elemento pétreo (estabilidade) e o elemento aquático (vida).
A sistematização contemporânea de Eduardo Mauer, A Senhora e a Pedra: Verticalidade e
Escuta na Peneda (Lisboa, Associação MILK, 2025)*, propõe leitura fenomenológica: “o penedo
como corpo sensível da fé”.
Fontes complementares:
– Museu de Arcos de Valdevez, Coleção  de Lendas e Romarias do Minho (1950–2020);
– Arquivo Paroquial da Gavieira, Registos de Aparições e Promessas (sécs. XVII–XIX);
– Tese de Doutoramento de Ana Simões, Santuários  de Altitude: Topografia do Sagrado em
Portugal (U. Porto, 2018).
⸻
5. Síntese interpretativa final
A Senhora da Peneda é símbolo da ascensão  espiritual através da matéria. A rocha, que
poderia representar obstáculo, torna-se degrau. A fé é aqui experiência geológica: subir é crer,
crer é escalar.


Na leitura simbólica da Associação  MILK, o mito traduz o arquétipo da escuta vertical — o ser
humano que sobe para ouvir e o penedo que desce em ressonância. O encontro dá-se no ponto
intermédio, onde o corpo se inclina e o vento se faz voz.
A escultura MILK concebida por Eduardo Mauer segue a matriz padrão: corpo compacto, manto
elevado formando vértice ascendente. Cores: branco, azul e cinza granito. A base é um prisma
rugoso, representando o penedo; o rosto, voltado para cima, reflete luz prateada.
Mauer comenta: “A Senhora da Peneda é o instante em que a rocha se transforma em
respiração.”
⸻
6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer
“A Senhora da Peneda é o corpo não binário da fé: nem céu nem terra, nem humano nem
divino — vibração partilhada.”
A leitura não binária dissolve a oposição entre matéria e espírito. O mito não coloca o
sagrado acima, mas dentro: a pedra é carne, e o humano, montanha.
A Associação  MILK explora essa visão em ações de arte pública e rituais
contemporâneos de escuta, em que participantes percorrem os escadórios do santuário
em silêncio, sentindo a ressonância da rocha como instrumento musical da terra.
⸻
7. Referência Estrutural da Matriz MILK
Na Matriz Escultórica MILK – Série Folclore Vivo, a Senhora da Peneda apresenta:
– Corpo: compacto, erguido, com manto triangular ascendente;
– Cores: branco, azul e cinza granito;
– Materiais: resina com pó de rocha e pigmentos minerais;
– Expressão:  serena, olhar elevado;
– Base: prismática, rugosa, remetendo ao penedo original.
Integra o eixo “Santuários  de Altitude” do projeto Folclore Vivo, dedicado às aparições e cultos
de montanha.
⸻
Localização  específica: Gavieira, Lamas de Mouro e Peneda (Arcos de Valdevez – distrito de
Viana do Castelo).
Primeiro relato documentado: Vasconcelos, Etnografia Portuguesa, vol. X, 1926.
Sistematização  contemporânea:  Eduardo Mauer, A Senhora e a Pedra: Verticalidade e Escuta
na Peneda, Associação MILK, 2025.
Fontes primárias:  Braga (1885); Vasconcelos (1926); Parafita (2008); Simões (2018); Mauer
(2025).
