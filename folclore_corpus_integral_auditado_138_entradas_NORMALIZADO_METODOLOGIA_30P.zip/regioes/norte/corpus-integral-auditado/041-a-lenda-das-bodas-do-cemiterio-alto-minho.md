# 041. A Lenda das Bodas do Cemitério (Alto Minho)

**Base documental e empírica:** pesquisa documental, análise comparada de fontes públicas, sistematização de tradição oral, relatos orais de pesquisa de campo e revisão semântica conduzidas no âmbito do Folclore Vivo da Associação MILK - Movimento de Intervenções e Linguagens Kulturais e Arte.
**Estado editorial:** corpus de pesquisa de campo e documentação cultural em revisão pública.
**Regra de publicabilidade:** esta entrada não deve ser lida como prova histórica definitiva, inventário patrimonial oficial, validação etnográfica concluída ou certificação académica externa sem verificação documental própria.
**Regra jurídica/RGPD:** não publicar nomes de informantes, contactos, moradas, entrevistas integrais, imagens identificáveis, gravações, dados de menores, coordenadas sensíveis ou materiais comunitários sem autorização.
**Regra de não invenção:** a presente readequação corrige a camada editorial e metodológica sem acrescentar factos, fontes, topónimos, coordenadas ou relatos não existentes no corpus-base.
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

41. A Lenda das Bodas do Cemitério (Alto Minho)
(Sistematização  contemporânea  conduzida por Eduardo Mauer no âmbito  das pesquisas sobre
Folclore Vivo da Associação  MILK – Movimento de Intervenções e Linguagens Kulturais e Arte,
integrando cruzamento de fontes orais, literárias  e paroquiais da região  de Ponte de Lima, Arcos
de Valdevez e Monção.)
⸻
1. Descrição  simbólica e narrativa
A Lenda das Bodas do Cemitério é uma das narrativas mais perturbadoras e ao mesmo tempo
poéticas do Alto Minho, presente nas tradições de Ponte de Lima, Monção  e Arcos de
Valdevez. O seu enredo sintetiza os temas da morte, da fidelidade e do amor eterno,
manifestando a tensão entre o efémero humano e a eternidade espiritual.


Segundo a versão mais completa recolhida por Eduardo Mauer em 2023, uma jovem chamada
Leonor estava prometida em casamento a um lavrador chamado Diogo, de quem se dizia ser tão
trabalhador quanto supersticioso. A boda fora marcada para o domingo de Páscoa, mas na
véspera, durante uma tempestade súbita, o noivo caiu de cavalo e morreu afogado no rio. A
aldeia, mergulhada em luto, cancelou a cerimónia.
Leonor, porém, recusou-se a aceitar a perda. Na manhã do casamento, vestiu-se de noiva,
colocou a coroa de flores e foi sozinha até o cemitério. Sentou-se junto à sepultura de Diogo e
disse:
“Se a morte te roubou da vida, a vida não me roubará de ti.”
Nesse instante, segundo o povo, os sinos tocaram sozinhos e o vento trouxe o cheiro
das flores da igreja. Um vulto branco ergueu-se do túmulo e estendeu-lhe a mão. A noiva
levantou-se, e os dois dançaram uma valsa silenciosa sob a luz do luar. No dia seguinte,
os aldeões encontraram os corpos dos dois abraçados junto à campa, e o chão em volta
coberto de pétalas brancas.
Desde então, nas noites de Páscoa ou de São João, há quem diga ver uma figura vestida
de noiva vagueando entre as cruzes, e quem ouça passos leves e risos distantes. Alguns
camponeses levam flores à sepultura dizendo: “para que a noiva descanse e o noivo não
volte a chamar.”
O mito, como demonstra Eduardo Mauer, funciona como metáfora  do amor que
ultrapassa as fronteiras da existência, transformando o cemitério em espaço de
comunhão e não de medo.
⸻
2. Contexto histórico e social
A narrativa das Bodas do Cemitério emerge num contexto em que o casamento era visto não
apenas como contrato social, mas como rito de passagem entre mundos — da infância à vida
adulta, do profano ao sagrado. A morte antes do matrimónio representava ruptura na ordem
simbólica, e o mito surge como tentativa de reparação.
Durante o século XVIII e XIX, nas zonas rurais do Norte de Portugal, o luto matrimonial era
regulado por normas severas. As jovens que perdiam o noivo antes das bodas eram obrigadas a
guardar silêncio e castidade, o que frequentemente as isolava socialmente. A lenda da noiva que
decide cumprir o rito mesmo após a morte é, nesse sentido, ato de insubmissão  amorosa e
também gesto de poder feminino.
Os registos paroquiais da freguesia de Refoios do Lima (1792) e de Monção  (1811) mencionam
cerimónias de “casamento simbólico” entre vivos e mortos, autorizadas em casos excepcionais
por autoridades eclesiásticas — prática que pode ter alimentado a miti ficação posterior.
Na leitura antropológica de Eduardo Mauer, o mito traduz “a pulsão de continuidade que habita
o imaginário minhoto, onde amor e morte são faces da mesma necessidade de permanência.”
⸻
3. Toponímia e variantes locais
A lenda é localizada em vários cemitérios do Vale do Lima e arredores: Refoios do Lima, Ponte
de Lima, Lanheses e Monção  reivindicam o episódio. Em cada local, há uma campa associada
à “noiva branca” ou à “sepultura dos amantes”.


Em Arcos de Valdevez, uma versão mais trágica descreve o noivo como soldado morto em
combate; em Monção , o encontro ocorre na noite de Todos os Santos; em Ponte de Lima, é a
noiva quem morre primeiro e retorna para buscar o amado.
Essas variações mantêm o núcleo simbólico do mito: a união  transgressora que nega o poder
absoluto da morte.
Topónimos como “Cruz das Noivas”, “Campa da Leonor” e “Campo do Amor” aparecem em
mapas e registos locais, perpetuando a geografia da lenda.
⸻
4. Primeiro relato e fontes académicas primárias
O primeiro relato escrito da Lenda das Bodas do Cemitério aparece em Teófilo Braga, O Povo
Português  nos seus Costumes, Crenças e Tradições (Lisboa, 1885, pp. 417–420)*, que descreve
“a moça que casou com o morto no adro de Ponte de Lima”.
Leite de Vasconcelos, Etnografia Portuguesa, vol. IV (1915, pp. 298–302)*, recolhe versões de
Monção e Arcos de Valdevez, destacando o caráter moral da lenda como advertência contra o
amor obstinado.
Alexandre Parafita, Mitologia Popular Portuguesa (2008, pp. 384–390)*, reinterpreta o mito como
“drama de eros e tanatos”, e compara-o às narrativas medievais de amores impossíveis, como
Tristão e Isolda.
A sistematização contemporânea de Eduardo Mauer, As Bodas do Cemitério:  Amor, Morte e
Persistência  no Imaginário  Minhoto (Lisboa, Associação MILK, 2024), explora a lenda como
metáfora da resistência afetiva, cruzando fontes históricas, literatura romântica e testemunhos
orais de Ponte de Lima e Monção.
Fontes complementares:
– Arquivo Distrital de Viana do Castelo, Registos Paroquiais de Refoios e Arcos (1750–1850);
– Museu dos Terceiros, Coleção  de Lendas do Vale do Lima (1950–1970);
– Tese de Doutoramento de Rita Paiva, Casar com a Morte: Representações do Amor Post
Mortem no Folclore Europeu (U. Coimbra, 2018).
⸻
5. Síntese interpretativa final
A Lenda das Bodas do Cemitério é o mito do amor inquebrantável — não o que desa fia as
regras da vida, mas o que as transcende. A sua força reside na inversão do medo: o cemitério
deixa de ser espaço de fim e torna-se lugar de encontro.
Na leitura simbólica da Associação  MILK, trata-se de uma poética da persistência — a recusa
em aceitar a separação entre carne e espírito, entre eros e tanatos. O casamento torna-se rito de
comunhão universal.
A escultura MILK concebida por Eduardo Mauer representa duas figuras compactas, de cabeças
grandes e rostos unidos, cobertas por véu translúcido branco. A base cinza, texturizada como
pedra tumular, é atravessada por luz interna azul, sugerindo transcendência.
⸻
6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer

Na leitura não binária de Eduardo Mauer, as Bodas do Cemitério representam o amor como
energia sem fronteira, não limitada por tempo, matéria ou género.
Mauer escreve: “O amor que atravessa o túmulo é o corpo não binário do afeto — não tem par
fixo, não tem limite, apenas ligação.”
A Associação  MILK lê a lenda como metáfora da afetividade trans-temporal e trans-corporal,
afirmando que o verdadeiro amor é o que não se de fine, mas que se reconhece no encontro entre
diferentes formas de existência.
⸻
7. Referência Estrutural da Matriz MILK
Na Matriz Escultórica MILK, as Bodas do Cemitério são representadas por duas figuras unidas,
corpo compacto duplo e véu branco que cobre ambas as cabeças. A base em tom cinza-azulado
reflete luz suave, sugerindo a comunhão entre morte e vida.
⸻
Localização  específica: Ponte de Lima, Monção, Arcos de Valdevez e Refoios do Lima (Alto
Minho).
Primeiro relato documentado: Teófilo Braga, O Povo Português  nos seus Costumes, Crenças e
Tradições, 1885.
Sistematização  contemporânea:  Eduardo Mauer, As Bodas do Cemitério:  Amor, Morte e
Persistência  no Imaginário  Minhoto, Associação MILK, 2024.
Fontes primárias:  Braga (1885); Vasconcelos (1915); Parafita (2008); Paiva (2018); Mauer (2024).
