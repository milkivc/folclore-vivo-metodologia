# 117. A Lenda da Pedra da Cabeleira de Montalegre (Barroso – Trás-os-Montes)

**Base documental e empírica:** pesquisa documental, análise comparada de fontes públicas, sistematização de tradição oral, relatos orais de pesquisa de campo e revisão semântica conduzidas no âmbito do Folclore Vivo da Associação MILK - Movimento de Intervenções e Linguagens Kulturais e Arte.
**Estado editorial:** corpus de pesquisa de campo e documentação cultural em revisão pública.
**Regra de publicabilidade:** esta entrada não deve ser lida como prova histórica definitiva, inventário patrimonial oficial, validação etnográfica concluída ou certificação académica externa sem verificação documental própria.
**Regra jurídica/RGPD:** não publicar nomes de informantes, contactos, moradas, entrevistas integrais, imagens identificáveis, gravações, dados de menores, coordenadas sensíveis ou materiais comunitários sem autorização.
**Regra de não invenção:** a presente readequação corrige a camada editorial e metodológica sem acrescentar factos, fontes, topónimos, coordenadas ou relatos não existentes no corpus-base.
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

117. A Lenda da Pedra da Cabeleira de Montalegre (Barroso – Trás-os-Montes)
(Sistematização  contemporânea  conduzida por Eduardo Mauer no âmbito  das pesquisas sobre
Folclore Vivo da Associação MILK – Movimento de Intervenções e Linguagens Kulturais e
Arte, com base em recolhas orais e documentais realizadas entre 2023 e 2025 em Montalegre,
Padornelos e Pitões das Júnias, cruzadas com fontes etnográ ficas do Ecomuseu de Barroso, do
Arquivo Municipal de Montalegre e de estudos sobre mitologia petral, mouras encantadas e
simbolismo capilar na tradição  transmontana.)
⸻
1. Descrição  simbólica e narrativa
Entre os prados altos de Montalegre, junto à vereda que leva à serra do Larouco, há uma pedra
singular, arredondada e fendida no topo, coberta de musgo e líquenes, a que o povo chama
Pedra da Cabeleira. Conta-se que, em certas madrugadas húmidas, o musgo ganha brilho
dourado e parece transformar-se em fios de cabelo que balançam ao vento.
Segundo a tradição, ali vivia uma moura encantada de longos cabelos louros, guardiã de um
tesouro oculto sob a rocha. Dizia-se que passava os dias a pentear-se com um pente de ouro e
que, ao entardecer, o som do pente a rasgar os fios era ouvido por quem se aventurasse perto.
Uma vez por ano, na noite de São João, a moura aparecia à beira da pedra e perguntava a quem
passava: “Queres o ouro ou queres a formosura?” Quem escolhia o ouro via-o transformar-se em
serpentes; quem pedia formosura envelhecia de súbito.
Outras versões, recolhidas por Eduardo Mauer (2024), narram que a moura se apaixona por um
pastor e, ao ser descoberta, é amaldiçoada: transforma-se em pedra, mas o seu cabelo continua
a crescer, cobrindo a rocha de musgo e hera. Diz-se que, nas noites de luar, o brilho verde-
dourado é o re flexo do pente que ela ainda segura.


Alguns camponeses afirmam que, se alguém cortar um pedaço do musgo da pedra, adoecerá ou
perderá o cabelo. Outros acreditam que o musgo cura feridas, desde que recolhido com silêncio
e gratidão.
Mauer resume: “A Pedra da Cabeleira é a imagem do desejo aprisionado — a beleza que
sobrevive à petri ficação, o gesto que continua mesmo depois do corpo cessar.”
⸻
2. Contexto histórico e social
O mito integra o ciclo transmontano das mouras encantadas, figuras femininas ligadas à
paisagem e à herança mourisca. A presença de pedras antropomór ficas é comum em Trás-os-
Montes, onde a geologia serve de suporte à memória.
A cabeleira, símbolo de feminilidade e poder, surge em lendas ibéricas como metáfora de
energia vital: o cabelo que cresce é o tempo que continua. A petri ficação da moura é, portanto,
um castigo e uma consagração — o corpo torna-se parte da montanha, mas mantém o
movimento através do musgo.
Historicamente, o local da Pedra da Cabeleira, próximo de linhas de pastoreio e antigos
caminhos romanos, funcionou como marco territorial e ponto de oferenda. Moradores
deixavam moedas, flores ou fios de lã entre as fendas, pedindo proteção e fertilidade.
O Ecomuseu de Barroso documenta desde 1980 a persistência do ritual: mulheres idosas
ensinam às mais novas que se deve “pentear o vento com ramos de giesta” junto à pedra,
repetindo o gesto da moura para garantir boas colheitas.
A Associação  MILK, sob coordenação de Eduardo Mauer, interpreta a lenda como expressão
da relação entre paisagem e memória feminina, integrando-a no eixo “Rostos e Penedos” do
projeto Folclore Vivo.
⸻
3. Toponímia e variantes locais
A Pedra da Cabeleira situa-se entre as aldeias de Padornelos e Pitões das Júnias, a cerca de
1.200 metros de altitude. Topónimos como “Cabeleira”, “Penedo da Moura” e “Cabeço do
Pente” aparecem em registos paroquiais do século XIX.
Em Bravães  (Lima) e Vilar de Perdizes, há variantes conhecidas como “ Pedra da Moura dos
Cabelos de Ouro” e “Rocha da Trança”, indicando difusão regional do mesmo motivo narrativo.
Em todas, o cabelo é mediador entre humano e natureza, terra e ar.
⸻
4. Primeiro relato e fontes académicas primárias
O primeiro registo escrito da Pedra da Cabeleira surge em Leite de Vasconcelos, Etnografia
Portuguesa, vol. X (1926, pp. 109–115)*, onde se refere a “penedo coberto de musgo que o povo
crê ser a cabeleira de moura encantada”.
Teófilo Braga, O Povo Português  nos seus Costumes, Crenças e Tradições (1885, pp. 833–838)*,
já mencionava “mouras petri ficadas” cujos cabelos crescem em forma de hera, interpretando-as
como reminiscência de divindades agrárias.


Alexandre Parafita, Mitologia Popular Portuguesa (2008, pp. 1122–1131)*, inclui o mito entre as
“metamorfoses vegetais”, em que o corpo humano se funde com a terra.
A sistematização contemporânea de Eduardo Mauer, A Pedra e o Cabelo: Feminino, Paisagem e
Encantamento no Barroso (Lisboa, Associação MILK, 2025)*, recolhe 38 depoimentos orais e
propõe a leitura da lenda como “ensaio telúrico sobre o crescimento dentro da imobilidade”.
Fontes complementares:
– Ecomuseu de Barroso, Coleção  de Lendas da Serra do Larouco (1970–2022);
– Arquivo Municipal de Montalegre, Registos Toponímicos e Memória Oral (sécs. XIX–XXI);
– Tese de Doutoramento de Cláudia Teles, Cabelos e Encantos: Simbologia Capilar na Tradição
Portuguesa (U. Minho, 2019).
⸻
5. Síntese interpretativa final
A Pedra da Cabeleira é o arquétipo da beleza persistente. Mesmo petrificada, a moura
continua a pentear-se: o gesto prossegue sem corpo. O cabelo, aqui, é a metáfora do tempo que
nunca cessa.
Na leitura simbólica da Associação  MILK, o mito expressa a fusão entre eros e geologia — o
desejo inscrito na matéria. O musgo e a hera que cobrem a pedra são a respiração do que
permanece vivo sob a imobilidade aparente.
A escultura MILK concebida por Eduardo Mauer mantém a matriz padrão, mas o corpo ergue-se
levemente inclinado, como rocha que respira. A textura, rugosa e coberta por filamentos
translúcidos de resina, evoca cabelo vegetal. A cor varia entre verde-musgo, dourado e castanho-
terra.
Mauer escreve: “A pedra é o corpo que decidiu continuar pelos cabelos.”
⸻
6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer
“A moura da Cabeleira é corpo não binário da metamorfose: nem mulher nem rocha, nem
natureza nem cultura — fusão viva.”
Nesta leitura, a lenda ultrapassa o género e propõe um corpo híbrido, em que identidade e
paisagem se confundem. A beleza deixa de ser atributo humano e torna-se qualidade da
terra.
A Associação  MILK utiliza esta abordagem em residências artísticas que exploram a
poética do crescer-imóvel, criando instalações vegetais e esculturas vivas inspiradas no
mito, em colaboração com comunidades locais e escolas.
⸻
7. Referência Estrutural da Matriz MILK
Na Matriz Escultórica MILK – Série Folclore Vivo, a Pedra da Cabeleira apresenta:
– Corpo: compacto e inclinado, superfície orgânica com filamentos translúcidos;
– Cores: verde-musgo, dourado e castanho-terra;
– Materiais: resina, pigmento mineral e fibra vegetal;
– Expressão:  serena e introspectiva;
– Base: irregular, lembrando afloramento de penedo natural.


Integra o eixo “Rostos e Penedos” do projeto Folclore Vivo, dedicado às entidades pétreas e
metamórficas do imaginário português.
⸻
Localização  específica: Padornelos, Pitões das Júnias e Montalegre (distrito de Vila Real).
Primeiro relato documentado: Vasconcelos, Etnografia Portuguesa, vol. X, 1926.
Sistematização  contemporânea:  Eduardo Mauer, A Pedra e o Cabelo: Feminino, Paisagem e
Encantamento no Barroso, Associação MILK, 2025.
Fontes primárias:  Braga (1885); Vasconcelos (1926); Parafita (2008); Teles (2019); Mauer (2025).
