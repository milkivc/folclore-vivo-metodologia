# Corpus integral auditado — Folclore Vivo MILK

Este corpus integra entradas resultantes de pesquisa documental, análise comparada de fontes públicas, sistematização de tradição oral, relatos orais de pesquisa de campo e revisão semântica conduzidas no âmbito do Folclore Vivo da Associação MILK - Movimento de Intervenções e Linguagens Kulturais e Arte.

As entradas são publicadas como corpus de investigação cultural em revisão pública, com distinção entre fonte, território, interpretação, direitos, dados sensíveis e estado de validação. Nenhuma entrada deve ser lida como prova histórica definitiva, inventário patrimonial oficial, validação etnográfica concluída ou certificação académica externa sem verificação documental própria.

## Critério de publicabilidade

O corpus pode integrar GitHub e Zenodo apenas como camada publicável, sem dados pessoais, sem entrevistas integrais, sem imagens identificáveis, sem coordenadas sensíveis, sem consentimentos assinados e sem material comunitário reservado.

## Normalização territorial e de aparição

Todas as 138 entradas foram verificadas quanto à presença de descrição simbólica/narrativa, toponímia/variantes locais, características físicas ou modo de aparição, e localização específica final ou bloco editorial normalizado.

As entradas 020, 137 e 138 receberam bloco adicional de normalização territorial sem introdução de dados externos, coordenadas, concelhos ou inferências não verificadas.

## Metodologia associada

Consultar `docs/METODOLOGIA_MILK_REINTERPRETACAO_ETNOLOGICA_30P.md`.
