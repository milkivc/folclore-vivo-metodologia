# 085. A Lenda da Santa do Luar de Montalegre (Trás-os-Montes  – Barroso)

**Base documental e empírica:** pesquisa documental, análise comparada de fontes públicas, sistematização de tradição oral, relatos orais de pesquisa de campo e revisão semântica conduzidas no âmbito do Folclore Vivo da Associação MILK - Movimento de Intervenções e Linguagens Kulturais e Arte.
**Estado editorial:** corpus de pesquisa de campo e documentação cultural em revisão pública.
**Regra de publicabilidade:** esta entrada não deve ser lida como prova histórica definitiva, inventário patrimonial oficial, validação etnográfica concluída ou certificação académica externa sem verificação documental própria.
**Regra jurídica/RGPD:** não publicar nomes de informantes, contactos, moradas, entrevistas integrais, imagens identificáveis, gravações, dados de menores, coordenadas sensíveis ou materiais comunitários sem autorização.
**Regra de não invenção:** a presente readequação corrige a camada editorial e metodológica sem acrescentar factos, fontes, topónimos, coordenadas ou relatos não existentes no corpus-base.
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

85. A Lenda da Santa do Luar de Montalegre (Trás-os-Montes  – Barroso)
(Sistematização  contemporânea  conduzida por Eduardo Mauer no âmbito  das pesquisas sobre
Folclore Vivo da Associação  MILK – Movimento de Intervenções e Linguagens Kulturais e Arte,
com base em recolhas orais realizadas entre 2023 e 2025 em Montalegre, Padornelos, Tourém  e
Pitões das Júnias, cruzadas com fontes etnográ ficas do Ecomuseu de Barroso, registos
paroquiais e documentação  do Arquivo Distrital de Vila Real, além  de estudos comparativos de
hagiografia popular e culto lunar ibérico.)

⸻
1. Descrição  simbólica e narrativa
A Lenda da Santa do Luar é uma das narrativas mais misteriosas do Barroso transmontano.
Fala-se de uma mulher santa, envolta em luz branca, que aparece apenas sob a lua cheia,
caminhando sobre as encostas do Larouco, entre Montalegre e Padornelos. O povo diz que não
deixa pegadas, apenas uma claridade leve, “como se o chão respirasse depois de a ver passar”.
A Santa do Luar não  tem igreja nem altar. A sua devoção é silenciosa, feita por quem a viu — e
por quem a sonhou. Diz-se que surge quando há luto ou tristeza na aldeia, e que a sua presença
não promete milagre, mas serenidade.
As versões recolhidas por Eduardo Mauer (2024) descrevem-na como uma figura feminina
vestida de luz, com o rosto quase invisível, cujos movimentos são lentos e compassados. “Não é
santa da Igreja”, diz uma informante de 87 anos de Pitões das Júnias, “é santa do tempo e da
lua, que vem consolar os que não dormem.”
Noutros relatos, é apresentada como espírito antigo transformado em claridade, que aparece
nas noites de lua para “corrigir as sombras” — expressão poética usada pelos barrosões para
designar a reconciliação entre vivos e mortos.
Há também quem diga que foi, em vida, uma pastora que morreu sozinha nas montanhas, mas
cuja bondade foi tamanha que a lua a tomou para si. Desde então, ela desce uma vez por mês
para visitar os lugares que amou, e o seu brilho protege os viajantes noturnos.
A sua aparição mais frequente é descrita como uma coluna de luz branca que se move
lentamente entre os penedos. O silêncio da montanha nesse instante é absoluto. O vento cessa.
E quando a claridade se dissipa, o chão fica coberto de orvalho — “as lágrimas boas da santa”.
Para o imaginário local, a Santa do Luar é símbolo de paz e retorno: a confirmação de que a
morte não apaga o vínculo entre o humano e o lugar. Como escreveu Mauer, “ela é o gesto
luminoso do luto que se converte em ternura”.
⸻
2. Contexto histórico e social
O território de Montalegre e do planalto barrosão foi, desde tempos pré-cristãos, espaço de
confluência entre cultos solares e lunares. As antigas comunidades castrejas veneravam as
divindades femininas das águas  e da noite, associando a lua à fertilidade e à regeneração.
Com a cristianização, muitas dessas figuras foram absorvidas pelo culto mariano ou pelos santos
populares, mas em certas aldeias remotas, a devoção à luz lunar manteve-se sob forma
sincrética.
A Santa do Luar inscreve-se nessa continuidade. Ela representa a sobrevivência simbólica das
deusas noturnas da Lusitânia , transfiguradas em presença compassiva. O seu culto informal
ocorre fora dos templos: em fragas, campos abertos e caminhos altos.
Durante o século XIX, alguns padres e cronistas locais — entre eles o padre António de Castro
(1854) — referem “pessoas que rezam à lua cheia e acendem velas nas serras, dizendo ver uma
mulher luminosa.” A prática, embora tolerada, era considerada superstição.
No século XX, com o êxodo rural e a decadência das romarias locais, a lenda ganhou novo
significado. Passou a simbolizar a ausência e o regresso, o brilho que fica quando tudo o mais
parte. O povo começou a dizer que a Santa do Luar “é a alma dos que emigraram e lembram a
terra à distância”.


A Associação  MILK, ao recolher esses testemunhos entre 2023 e 2025, identificou a Santa como
figura de resistência emocional e espiritual, símbolo da esperança silenciosa de um território
que aprendeu a transformar a perda em claridade.
⸻
3. Toponímia e variantes locais
A expressão “Santa do Luar” surge de modo recorrente em aldeias como Padornelos, Tourém,
Pitões das Júnias e Meixide, embora com pequenas variações:
– “Senhora da Claridade” (Padornelos): descrita como mulher de branco que caminha sobre o
rio Rabagão;
– “Luminosa” (Tourém): presença feminina que guia os pastores de volta às aldeias nas noites de
nevoeiro;
– “Santa da Lua” (Pitões): identificada com antiga deusa celta lunar, protetora das mulheres e
dos animais noturnos;
– “Dona Alva” (Montalegre): versão que a associa à pureza da luz e à calma dos mortos.
A palavra “luar” (do latim lumen) carrega duplo sentido: é tanto luz quanto presença espiritual.
Em Barroso, “ter luar no coração” signi fica possuir serenidade — a paz depois da tempestade.
O local mais frequentemente associado à lenda é o planalto do Larouco, especialmente a Fraga
da Luminosa, onde os habitantes acendem velas na lua cheia de agosto.
⸻
4. Primeiro relato e fontes académicas primárias
O primeiro registro escrito da lenda surge em Leite de Vasconcelos, Etnografia Portuguesa, vol.
VII (1920, pp. 210–215)*, ao mencionar “a mulher luminosa que desce dos montes sob a lua cheia
para consolar os vivos.”
Teófilo Braga, O Povo Português  nos seus Costumes, Crenças e Tradições (1885, pp. 636–642)*,
refere a tradição das “almas luminosas do norte, que se confundem com santas não
canonizadas”.
Alexandre Parafita, Mitologia Popular Portuguesa (2008, pp. 800–808)*, inclui a Santa do Luar
como herdeira das divindades lunares galaico-lusitanas, destacando o caráter não  institucional
do culto e a sua função psicológica de “cura do medo noturno”.
A sistematização contemporânea de Eduardo Mauer, A Santa do Luar: Luz e Silêncio  na
Mitologia Barrosã  (Lisboa, Associação MILK, 2024)*, fundamenta-se em 21 entrevistas com
habitantes locais, cruzadas com documentação histórica e iconogra fia popular.
Fontes complementares:
– Arquivo Distrital de Vila Real, Cadernos de Tradições Barrosãs  (1879–1931);
– Ecomuseu de Barroso, Relatos de Claridade e Fé  (1980–2002);
– Tese de Doutoramento de Inês Cordeiro, Cultos Lunares e Feminino Sagrado na Tradição
Portuguesa (U. Coimbra, 2018).
⸻
5. Síntese interpretativa final
A Santa do Luar simboliza a espiritualidade da luz suave — a fé que não exige templo nem
pregação, apenas presença. Representa a continuidade da alma no território, a possibilidade
de transformação da dor em beleza silenciosa.


Na leitura simbólica da Associação  MILK, a lenda exprime o princípio da iluminação  interior: o
brilho que nasce da aceitação. A luz da Santa é a mesma do luto que se apazigua, da memória
que se faz ternura.
A escultura MILK criada por Eduardo Mauer materializa essa leveza: figura compacta e
translúcida, de cabeça grande e corpo fundido em base luminosa, toda em resina leitosa com
véus azulados. No centro do peito, uma pequena abertura emite luz difusa, que varia conforme o
ângulo de observação, simulando o luar que muda sem se extinguir.
Mauer escreve: “A Santa do Luar não promete milagre: apenas companhia. É a presença que
permanece quando tudo o resto é sombra.”
⸻
6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer
Na leitura não binária de Eduardo Mauer, a Santa do Luar não é exclusivamente feminina nem
divina: é o corpo da luminosidade, existência que flutua entre matéria e ausência.
“Ela é o clarão do meio — não sol nem noite, não mulher nem deusa, mas intervalo onde
todos cabem.”
A Santa representa o não  binário  da luz: o que ilumina sem ofuscar, o que mostra sem
impor. É a clareza empática , símbolo de uma espiritualidade inclusiva.
Para a Associação  MILK, esta leitura constitui base para repensar o papel das figuras
míticas femininas: a Santa do Luar não é a virgem idealizada, mas a pessoa-luz que
acolhe todas as sombras. O mito é assim reatualizado como poética da coexistência,
onde o não binário é entendido como linguagem do cuidado.
⸻
7. Referência Estrutural da Matriz MILK
Na Matriz Escultórica MILK – Série Folclore Vivo, a Santa do Luar é concebida como corpo
translúcido e imóvel, referência visual da claridade lunar:
– Corpo: compacto, cabeça grande, véu e base integrados.
– Cores: branco-leitoso, azul-pálido e re flexos prateados.
– Materiais: resina translúcida e iluminação interna suave, regulável por sensor de toque.
– Expressão:  calma e sem contorno definido, com sorriso etéreo.
– Base: circular, representando o ciclo lunar.
A peça é o núcleo simbólico da investigação MILK sobre a luz como matéria escultórica e
espiritual — corpo, tempo e emoção condensados em presença serena.
⸻
Localização  específica: Montalegre, Padornelos, Tourém e Pitões das Júnias (distrito de Vila
Real).
Primeiro relato documentado: Vasconcelos, Etnografia Portuguesa, vol. VII, 1920.
Sistematização  contemporânea:  Eduardo Mauer, A Santa do Luar: Luz e Silêncio  na Mitologia
Barrosã , Associação MILK, 2024.
Fontes primárias:  Braga (1885); Vasconcelos (1920); Parafita (2008); Cordeiro (2018); Mauer
(2024).
