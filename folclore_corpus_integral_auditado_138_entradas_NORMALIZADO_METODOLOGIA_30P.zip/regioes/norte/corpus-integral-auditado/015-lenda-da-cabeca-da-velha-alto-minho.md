# 015. Lenda da Cabeça da Velha (Alto Minho)

**Base documental e empírica:** pesquisa documental, análise comparada de fontes públicas, sistematização de tradição oral, relatos orais de pesquisa de campo e revisão semântica conduzidas no âmbito do Folclore Vivo da Associação MILK - Movimento de Intervenções e Linguagens Kulturais e Arte.
**Estado editorial:** corpus de pesquisa de campo e documentação cultural em revisão pública.
**Regra de publicabilidade:** esta entrada não deve ser lida como prova histórica definitiva, inventário patrimonial oficial, validação etnográfica concluída ou certificação académica externa sem verificação documental própria.
**Regra jurídica/RGPD:** não publicar nomes de informantes, contactos, moradas, entrevistas integrais, imagens identificáveis, gravações, dados de menores, coordenadas sensíveis ou materiais comunitários sem autorização.
**Regra de não invenção:** a presente readequação corrige a camada editorial e metodológica sem acrescentar factos, fontes, topónimos, coordenadas ou relatos não existentes no corpus-base.
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

15. Lenda da Cabeça da Velha (Alto Minho)
(Sistematização  contemporânea  conduzida por Eduardo Mauer no âmbito  das pesquisas sobre
Folclore Vivo da Associação  MILK – Movimento de Intervenções e Linguagens Kulturais e Arte)

⸻
1. Descrição  simbólica e narrativa
A Lenda da Cabeça da Velha é uma das narrativas mais singulares do Alto Minho, centrada em
torno de uma formação rochosa antropomór fica que, vista à distância, recorda o per fil de uma
mulher idosa. Este penedo, conhecido em várias freguesias de Arcos de Valdevez e Ponte da
Barca, inspira há séculos histórias de metamorfose, culpa e redenção.
Segundo o relato oral mais difundido — recolhido por Eduardo Mauer durante o projeto Folclore
Vivo —, a “Velha” era uma pastora avarenta que, movida pela ganância, recusou dar pão a um
peregrino faminto. O homem revelou-se, então, como mensageiro divino e lançou-lhe uma
maldição: “Tão dura és no coração como pedra serás para sempre.” Instantaneamente, o corpo
da mulher petrificou-se sobre o monte, e a sua cabeça permaneceu voltada para o vale, de onde
se ouvem, em certas noites, suspiros que o povo identifica como o seu arrependimento eterno.
Em outras versões, a Velha é benevolente: uma guardiã das montanhas, que protege os rebanhos
e as fontes, aparecendo em dias de nevoeiro para indicar o caminho aos viajantes perdidos.
Nessa leitura, a pedra é símbolo da sabedoria ancestral e da permanência da memória.
A ambiguidade entre castigo e sabedoria constitui o núcleo simbólico da lenda. A Cabeça da
Velha é, ao mesmo tempo, testemunho da dureza humana e da paciência mineral,
representando a passagem do orgânico ao pétreo — a transformação da carne em tempo.
Eduardo Mauer descreve a lenda como “mito da transmutação moral em geologia ética”: a
pedra não é punição, mas recordação. A Velha permanece não como monstro, mas como
espelho do humano.
⸻
2. Contexto histórico e social
A lenda inscreve-se no contexto montanhoso e rural do Alto Minho, onde a relação entre homem
e paisagem é de profunda intimidade simbólica. A montanha, as fragas e os penedos são
frequentemente vistos como seres dotados de alma, guardiões silenciosos do território.
No século XIX, estudiosos como Teófilo Braga e Leite de Vasconcelos observaram que muitas
dessas rochas antropomórficas — “Peneda da Velha”, “Cabeça do Homem”, “Penedo do Diabo”
— correspondiam a antigos lugares de culto pagão, posteriormente reinterpretados pelo
cristianismo como sinais de castigo ou milagre.
A petrificação da Velha, na tradição oral, re flete também a moralidade rural: o valor da
generosidade e o castigo da avareza. O conto servia como pedagogia moral, especialmente
contado às crianças para ensinar a partilhar e respeitar os peregrinos.
No entanto, em estudos mais recentes, como o de Eduardo Mauer, a narrativa é reinterpretada
sob uma perspetiva ecológica e simbólica: o mito não fala apenas de culpa, mas da relação
entre humanidade e natureza. A transformação em pedra representa o retorno ao ciclo da
matéria, a reintegração da vida no corpo mineral da Terra.
Durante o século XX, a Cabeça da Velha tornou-se referência cultural na região. É comum
encontrar o motivo em lendas, canções e em artesanato local, especialmente em esculturas de
granito que reproduzem o perfil da figura.
⸻
3. Toponímia e variantes locais

Formações rochosas conhecidas como “Cabeça da Velha” existem em vários pontos do Minho,
mas as mais notórias localizam-se em Arcos de Valdevez (Monte da Peneda) e Ponte da Barca
(Serra do Oural). Em ambas, a rocha tem forma humana evidente: nariz, queixo e testa
destacados, compondo o perfil de uma anciã.
A variante de Arcos de Valdevez descreve a Velha como pastora que amaldiçoou a chuva e foi
transformada em pedra para sempre, com o rosto voltado ao céu. Já em Ponte da Barca, a lenda
fala de uma mulher que perdeu o filho na montanha e esperou tanto tempo que o vento a
endureceu.
Outras versões, recolhidas em Soajo e Gavieira, descrevem o penedo como entidade protetora,
diante da qual as mulheres deixavam flores ou pedaços de pão para pedir fertilidade e saúde.
Essa prática revela uma possível origem pré-cristã, associada ao culto das “mães pétreas” ou
matres rupestres da antiguidade céltica.
O nome “Cabeça da Velha” tornou-se também toponímico, nomeando montes, quintas e até
cafés locais, o que comprova a inserção do mito na memória coletiva e na economia simbólica da
região.
⸻
4. Primeiro relato e fontes académicas primárias
O primeiro registo escrito da Lenda da Cabeça da Velha surge em Leite de Vasconcelos,
Etnografia Portuguesa, vol. II (1913, pp. 155–159)*, onde o autor descreve “um penedo em forma
de cabeça humana no Minho, a que o povo atribui origem lendária e moral.”
Teófilo Braga, em O Povo Português  nos seus Costumes, Crenças e Tradições (1883, p. 312),
menciona lendas de petrificação feminina associadas à desobediência e ao orgulho,
comparando-as a mitos gregos como o de Níobe.
Alexandre Parafita, Mitologia Popular Portuguesa (2008, pp. 187–190)*, dedica à Cabeça da
Velha um estudo interpretativo, afirmando que “a mulher petrificada é resíduo simbólico da
Deusa-Mãe, condenada à imobilidade pelo patriarcado cristão.”
Eduardo Mauer, em Cabeça da Velha: Memória, Pedra e Gênero  no Imaginário  Minhoto (Lisboa,
Associação MILK, 2024), propõe uma leitura arqueomitológica e estética, articulando entrevistas
orais, análise morfológica da rocha e referências literárias regionais.
Fontes complementares:
– Museu D. Diogo de Sousa, Coleção  de Etnografia Minhota (1900–1935);
– Arquivo Paroquial de Arcos de Valdevez, Registos de Lendas Locais, 1892–1911;
– Tese de Mestrado de Ana Pires, A Mulher e a Pedra: Iconografia do Feminino nas Lendas do
Minho (U. Minho, 2015).
⸻
5. Síntese interpretativa final
A Cabeça da Velha é, acima de tudo, metáfora da humanização  da paisagem. Ao projetar rosto
e sentimento sobre a rocha, o povo cria ponte entre a eternidade mineral e a fragilidade humana.
A petrificação não é apenas castigo, mas consagração: o gesto de fixar no mundo o que o tempo
tentaria apagar. A Velha torna-se testemunha do território, presença que recorda a passagem do
humano pela Terra.
Para a Associação  MILK, esta lenda representa o diálogo entre corpo e matéria, mito e geologia.
O ato de olhar a pedra e reconhecer nela um rosto é exercício poético e ontológico: a natureza
devolve o olhar e inscreve-se na cultura.


Na escultura MILK de Eduardo Mauer, a Cabeça da Velha é reinterpretada como busto
monumental de rosto sereno e envelhecido, com textura rugosa e tons de cinza, areia e musgo. O
olhar, semiaberto, reflete o limiar entre o humano e o mineral.
⸻
6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer
Na leitura não binária de Eduardo Mauer, a Cabeça da Velha é figura da sabedoria transgênero
da Terra. Embora representada como mulher, a sua petrificação dissolve a distinção entre corpo
e paisagem, entre feminino e masculino, entre vida e matéria.
A pedra, sem género, é o corpo pleno da natureza. A Velha, ao fundir-se nela, transcende a
dualidade e torna-se símbolo da consciência não binária da existência.
Mauer interpreta o mito como “ato de resistência mineral ao patriarcado simbólico”: o corpo da
mulher que se transforma em montanha não morre — eterniza-se. A rocha é corpo expandido,
continente do tempo.
A Associação  MILK vê nesta leitura um espelho da contemporaneidade: a busca por identidades
múltiplas, não fixas, que se afirmam na quietude e na transformação. O rosto petri ficado da Velha
é, assim, gesto de a firmação da fluidez — ser e permanecer, mudar sendo.
⸻
7. Referência Estrutural da Matriz MILK
Na Matriz Escultórica MILK, a Cabeça da Velha é representada como busto de grandes
proporções, superfície texturizada e expressão serena. As cores predominantes são tons de
pedra, verde-musgo e cinza-prateado. O acabamento é fosco, sugerindo antiguidade e
permanência.
A instalação pode incluir iluminação lateral suave que projete sombra ampliada do rosto sobre a
parede, remetendo à presença mítica na paisagem.
⸻
Localização  específica: Arcos de Valdevez e Ponte da Barca, Alto Minho.
Primeiro relato documentado: Leite de Vasconcelos, Etnografia Portuguesa, vol. II, 1913.
Sistematização  contemporânea:  Eduardo Mauer, Cabeça da Velha: Memória, Pedra e Gênero
no Imaginário  Minhoto, Associação MILK, 2024.
Fontes primárias:  Braga (1883); Vasconcelos (1913); Parafita (2008); Pires (2015); Mauer (2024).
