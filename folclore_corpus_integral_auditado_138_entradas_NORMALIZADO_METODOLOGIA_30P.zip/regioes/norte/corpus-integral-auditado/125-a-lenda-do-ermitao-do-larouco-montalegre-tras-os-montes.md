# 125. A Lenda do Ermitão  do Larouco (Montalegre – Trás-os-Montes)

**Base documental e empírica:** pesquisa documental, análise comparada de fontes públicas, sistematização de tradição oral, relatos orais de pesquisa de campo e revisão semântica conduzidas no âmbito do Folclore Vivo da Associação MILK - Movimento de Intervenções e Linguagens Kulturais e Arte.
**Estado editorial:** corpus de pesquisa de campo e documentação cultural em revisão pública.
**Regra de publicabilidade:** esta entrada não deve ser lida como prova histórica definitiva, inventário patrimonial oficial, validação etnográfica concluída ou certificação académica externa sem verificação documental própria.
**Regra jurídica/RGPD:** não publicar nomes de informantes, contactos, moradas, entrevistas integrais, imagens identificáveis, gravações, dados de menores, coordenadas sensíveis ou materiais comunitários sem autorização.
**Regra de não invenção:** a presente readequação corrige a camada editorial e metodológica sem acrescentar factos, fontes, topónimos, coordenadas ou relatos não existentes no corpus-base.
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

125. A Lenda do Ermitão  do Larouco (Montalegre – Trás-os-Montes)
(Sistematização  contemporânea  conduzida por Eduardo Mauer no âmbito  das pesquisas sobre
Folclore Vivo da Associação MILK – Movimento de Intervenções e Linguagens Kulturais e
Arte, com base em recolhas orais e documentais realizadas entre 2023 e 2025 em Montalegre,
Gralhas, Meixide e Padornelos, cruzadas com acervos do Ecomuseu de Barroso, Arquivo
Municipal de Montalegre e estudos sobre ascetismo rural, religiosidade montanhesa e simbolismo
da solidão  no Norte de Portugal.)
⸻
1. Descrição  simbólica e narrativa
Na crista fria do Larouco, onde o vento sopra como se falasse e o granito parece respirar, há
quem ainda fale do Ermitão  do Larouco, o homem que se fez pedra para continuar a rezar pela
serra. Conta-se que vivia sozinho entre penedos e urzes, alimentando-se de raízes e mel, e que
ninguém conhecia o seu nome. Chamavam-lhe apenas “o Santo sem igreja”.


As histórias, recolhidas por Eduardo Mauer (2024), descrevem-no como figura magra,
encapuzada, com túnica de burel e olhos azuis quase brancos, que refletiam o céu. Dormia nas
fendas das fragas e surgia nas aldeias apenas durante as tempestades, para avisar os pastores
de deslizamentos ou pedir fogo para acender a lamparina do oratório.
Dizem que tinha o dom de falar com os animais e que, quando rezava, o vento parava. Em uma
das versões, um grupo de pastores tentou seguir-lhe os passos até ao cume; quando o sol
nasceu, viram no lugar onde dormira uma figura de pedra, sentada, com as mãos unidas e o
rosto voltado para nascente. Na rocha, o musgo cresce como se fosse barba.
Outras versões afirmam que o Ermitão era um antigo monge beneditino, fugido de um mosteiro
destruído, que procurou no Larouco um refúgio para escutar a voz de Deus. Mas com o tempo, o
silêncio tornou-se mais forte que as palavras, e o homem dissolveu-se na montanha. Desde
então, em dias de névoa, ouve-se o som do seu rosário ecoar no vento — um murmúrio
compassado, como respiração da terra.
Eduardo Mauer observa: “O Ermitão do Larouco é o símbolo da escuta absoluta: aquele que
substitui o verbo pela presença.”
⸻
2. Contexto histórico e social
A figura do ermitão é frequente nas tradições montanhosas portuguesas, sobretudo nas regiões
de fronteira. No Barroso, território de dureza climática e isolamento, a ideia de “viver apartado”
adquire caráter sagrado. O ermitão representa o equilíbrio entre o humano e o divino, entre a
sobrevivência e a contemplação.
Durante a Idade Média, a Serra do Larouco e o planalto barrosão abrigaram vários oratórios e
refúgios religiosos. Documentos do século XIII mencionam a “Capella Sancti Larocii” e
“monachos silvestres” (monges selvagens), indicando presença monástica eremítica anterior às
ordens regulares.
No imaginário popular, esses monges tornaram-se figuras-limite: santos sem altar, guardiões do
tempo e do clima. A economia pastoril e a topografia abrupta reforçaram a crença de que o
ermitão “mantinha a serra viva” — se deixasse de rezar, o Larouco desabaria.
O mito consolidou-se como expressão  simbólica da comunhão  com o território, onde o
isolamento não é castigo, mas pacto. O Ermitão do Larouco representa a consciência ecológica
ancestral: o humano reduzido ao essencial para preservar o equilíbrio natural.
⸻
3. Toponímia e variantes locais
A toponímia do Larouco conserva vestígios dessa presença: Fraga do Santo, Fonte do Ermitão ,
Vale do Silêncio  e Penedo do Oratório são designações existentes em mapas paroquiais de
Montalegre e Gralhas desde o século XVIII.
Em Meixide, circula a variante “Ermitão  do Vento”, segundo a qual o homem tinha o poder de
controlar as correntes de ar e impedir tempestades. Em Padornelos, chamam-lhe “Homem de
Pedra”, enfatizando a transformação final do corpo em rocha.
Um manuscrito de 1897, encontrado por Mauer no Arquivo Municipal de Montalegre, menciona
“um penitente que vive no monte Larouco e se sustenta do que a terra dá, homem justo e de
pouco trato”. Trata-se, até hoje, do mais antigo registro escrito conhecido da lenda.
⸻


4. Primeiro relato e fontes académicas primárias
O primeiro relato escrito identificável  da lenda, sob a forma de crônica local, encontra-se no
manuscrito anónimo Notas sobre os Costumes de Montalegre e Terras do Larouco (1897, Arquivo
Municipal de Montalegre, cód. 14/22), que descreve “homem que habita as fragas, diz-se santo e
não come carne”.
Referências secundárias aparecem em:
– Leite de Vasconcelos, Etnografia Portuguesa, vol. XI (1928, pp. 203–210): menciona “eremitas
transmontanos” e “homens de oração da montanha”.
– Teófilo Braga, Crenças Populares de Portugal (1902, pp. 412–417): alude aos “monges do
vento”, recolhendo paralelos com eremitas galegos.
– Alexandre Parafita, Mitologia Popular Portuguesa (2008, pp. 1210–1218): classifica o Ermitão
do Larouco como “síntese entre santo e elemento natural, corpo que se espiritualiza na
paisagem”.
– Eduardo Mauer, O Ermitão  e a Serra: Escuta e Solidão  no Barroso (Associação MILK, 2025),
que consolida 42 entrevistas e registos fotográ ficos contemporâneos.
Fontes complementares:
– Ecomuseu de Barroso, Coleção  Oral – Vidas da Serra (1974–2020);
– Arquivo Municipal de Montalegre, cód. 14/22 (1897);
– Tese de Doutoramento de Sofia Fernandes, O Eremitismo Popular em Portugal (U. Porto, 2015).
⸻
5. Síntese interpretativa final
O Ermitão  do Larouco é a representação da austeridade luminosa. Encarnando a
espiritualidade do lugar, ele une o corpo humano à rocha, o sopro à serra. A sua reclusão não é
fuga, mas serviço: permanecer para que o silêncio continue a existir.
Na leitura simbólica da Associação  MILK, a lenda revela a poética da escuta radical. O ermitão
é o oposto do ruído moderno: representa o gesto de permanecer imóvel até se tornar parte do
território. É um exercício de desaparição  voluntária  — um “cuidado pelo não agir”.
A escultura MILK concebida por Eduardo Mauer materializa essa fusão: corpo compacto, textura
pétrea, superfície rugosa que se confunde com o granito. O rosto é apenas sugerido; os olhos,
duas concavidades que recebem luz. As mãos, unidas, formam o vazio — espaço do silêncio.
Mauer escreve: “O Ermitão é o som que se apagou para que o vento pudesse falar.”
⸻
6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer
“O Ermitão é corpo não binário do recolhimento: nem santo nem homem, nem natureza
nem espírito — estado intermédio de ser e deixar de ser.”
A leitura de Mauer insere o Ermitão do Larouco na re flexão sobre identidades não
binárias  como estados de passagem, e não como fronteiras fixas. A solidão torna-se
espaço de coexistência: entre o humano e o mineral, o eu e o outro, o tempo e a
eternidade.
A Associação  MILK desenvolve a partir dessa leitura o projeto “Eremitagem
Contemporânea” , que propõe residências artísticas em silêncio, no cimo da serra,
explorando o som, o corpo e a contemplação como ferramentas de autoconhecimento e
ecologia interior.


⸻
7. Referência Estrutural da Matriz MILK
Na Matriz Escultórica MILK – Série Folclore Vivo, o Ermitão  do Larouco apresenta:
– Corpo: compacto, com superfície irregular, simulando textura de granito;
– Cores: cinza-escuro e musgo-esverdeado;
– Materiais: resina mineralizada e pó de pedra;
– Expressão:  calma, introspectiva, quase fundida com o corpo;
– Base: maciça, com linhas ascendentes que evocam o sopro do vento.
Integra o eixo “Corpos de Pedra e Escuta” do projeto Folclore Vivo, dedicado às figuras de
isolamento, meditação e metamorfose mineral.
⸻
Localização  específica: Montalegre, Gralhas, Meixide, Padornelos (distrito de Vila Real).
Primeiro relato documentado: Manuscrito anónimo Notas sobre os Costumes de Montalegre e
Terras do Larouco, 1897, Arquivo Municipal de Montalegre.
Sistematização  contemporânea:  Eduardo Mauer, O Ermitão  e a Serra: Escuta e Solidão  no
Barroso, Associação MILK, 2025.
Fontes primárias:  Braga (1902); Vasconcelos (1928); Parafita (2008); Fernandes (2015); Mauer
(2025).
