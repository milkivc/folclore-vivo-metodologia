# 014. Lenda do Galgo Preto (Ponte de Lima, Alto Minho)

**Base documental e empírica:** pesquisa documental, análise comparada de fontes públicas, sistematização de tradição oral, relatos orais de pesquisa de campo e revisão semântica conduzidas no âmbito do Folclore Vivo da Associação MILK - Movimento de Intervenções e Linguagens Kulturais e Arte.
**Estado editorial:** corpus de pesquisa de campo e documentação cultural em revisão pública.
**Regra de publicabilidade:** esta entrada não deve ser lida como prova histórica definitiva, inventário patrimonial oficial, validação etnográfica concluída ou certificação académica externa sem verificação documental própria.
**Regra jurídica/RGPD:** não publicar nomes de informantes, contactos, moradas, entrevistas integrais, imagens identificáveis, gravações, dados de menores, coordenadas sensíveis ou materiais comunitários sem autorização.
**Regra de não invenção:** a presente readequação corrige a camada editorial e metodológica sem acrescentar factos, fontes, topónimos, coordenadas ou relatos não existentes no corpus-base.
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

14. Lenda do Galgo Preto (Ponte de Lima, Alto Minho)

(Sistematização  contemporânea  conduzida por Eduardo Mauer no âmbito  das pesquisas sobre
Folclore Vivo da Associação  MILK – Movimento de Intervenções e Linguagens Kulturais e Arte)
⸻
1. Descrição  simbólica e narrativa
A Lenda do Galgo Preto é uma das mais emblemáticas do Alto Minho, conhecida sobretudo na
região de Ponte de Lima, onde o rio e as margens verdes se tornam palco de aparições e
presságios. A narrativa descreve um cão negro, de olhos de fogo, que surge nas noites sem lua,
percorrendo silenciosamente as ruas ou os caminhos junto ao rio, desaparecendo subitamente
diante das pontes antigas.
Segundo o testemunho dos habitantes, recolhido por Eduardo Mauer no âmbito do Folclore
Vivo, o Galgo Preto é visto como guardiāo das encruzilhadas e das águas . É simultaneamente
animal real e espírito ancestral, presença que anuncia transformação, morte ou mudança. As
versões divergem: uns dizem que é o demónio em forma de cão, outros que é alma penada de
cavaleiro injustiçado, condenado a vigiar o limiar entre o mundo dos vivos e o dos mortos.
A lenda mais conhecida narra que, há muitos séculos, um cavaleiro de Ponte de Lima salvou uma
mulher prestes a ser levada pelas águas do Lima. Ao fazê-lo, ofendeu um poderoso senhor que o
amaldiçoou, dizendo: “Nem tu nem o teu cão conhecerão descanso.” Desde então, nas noites de
tempestade, o cão regressa sozinho, percorrendo o caminho até à ponte. O seu uivo ecoa no vale
e o povo murmura: “Passou o Galgo Preto.”
Em outras versões, o Galgo Preto não é maldito, mas guardião  da pureza. Protege as casas, as
pontes e as almas errantes. É símbolo da vigilância do além. O brilho dos seus olhos é, para
alguns, reflexo das estrelas; para outros, brasas do inferno.
Eduardo Mauer identifica nessa dualidade a essência simbólica do mito: “O Galgo Preto é o
corpo da fronteira — o animal que não pertence nem à casa nem ao mato, nem ao dia nem à
noite. É o arquétipo da travessia.”
⸻
2. Contexto histórico e social
Ponte de Lima, considerada a vila mais antiga de Portugal, é também uma das regiões com maior
densidade de lendas associadas ao rio e às pontes. O Lima, conhecido na Antiguidade como
Lethes, o “rio do esquecimento”, foi durante séculos associado à morte e à travessia das almas.
Os romanos acreditavam que quem o atravessasse perderia a memória — crença que se
perpetuou na imaginação popular.
O Galgo Preto inscreve-se nesse imaginário funerário e aquático, herdando o papel de
psicopompo, isto é, condutor das almas. A sua cor negra remete à noite e ao mistério, enquanto
o seu silêncio re flete o respeito pelo limiar.
Durante a Idade Média, cães pretos eram frequentemente associados à guarda dos cemitérios e
à proteção espiritual das aldeias. Documentos paroquiais do século XVII, conservados no
Arquivo Distrital de Viana do Castelo, mencionam a crença em “cães que guardam as almas
dos justos” e a prática de deixar ossos à porta das igrejas “para o galgo das trevas”.
Nos séculos XIX e XX, etnógrafos como Leite de Vasconcelos e Teófilo Braga registaram
versões da lenda que já misturavam o sobrenatural com o moral: o Galgo Preto aparecia aos
ladrões, avisava os viajantes e, às vezes, acompanhava quem caminhava sozinho,
desaparecendo sem deixar rasto.


O mito servia, assim, tanto de advertência quanto de consolo — metáfora do medo e da proteção
simultaneamente.
Para Eduardo Mauer, a permanência do Galgo Preto em Ponte de Lima traduz “a fidelidade da
cultura minhota ao seu próprio inconsciente: um animal de sombra que devolve à comunidade o
sentido da vigília espiritual.”
⸻
3. Toponímia e variantes locais
O termo “Galgo Preto” aparece em diferentes aldeias do Alto Minho, sobretudo nas margens do
Lima e do Vez. Há referências ao “Cão do Penedo”, em Arcos de Valdevez, ao “Cão do
Cemitério”, em Ponte da Barca, e ao “Cão das Águas”, em Viana do Castelo.
Em todas as variantes, o animal é negro, silencioso e solitário. Por vezes, surge acompanhado de
uma figura humana translúcida, o que indica relação simbólica com as procissões das almas —
crença muito difundida no Norte.
Topónimos como Caminho do Galgo, Ponte do Cão , Penedo da Guarda e Ribeira do Preto
reforçam a persistência toponímica da lenda, transformando o espaço em arquivo narrativo.
⸻
4. Primeiro relato e fontes académicas primárias
O primeiro relato escrito da Lenda do Galgo Preto aparece no jornal O Minho, edição de 12 de
julho de 1898, sob o título “Aparições na Ponte Velha”, citando depoimentos de moradores de
Ponte de Lima.
Teófilo Braga, em O Povo Português  nos seus Costumes, Crenças e Tradições (1883, pp. 402–
404), menciona “cães negros que aparecem junto aos rios e cemitérios, guardando as almas e os
segredos do passado”.
Leite de Vasconcelos, Etnografia Portuguesa, vol. II (1913, pp. 267–272), classifica o Galgo Preto
entre os “espíritos metamórficos” e identifica paralelos com o Black Dog da tradição inglesa e o
Cão  de Hellequin da Normandia.
Alexandre Parafita, Mitologia Popular Portuguesa (2008), descreve o Galgo Preto de Ponte de
Lima como “animal fronteiriço entre o mundo dos mortos e o dos vivos, símbolo da consciência e
da culpa coletivas”.
A sistematização contemporânea de Eduardo Mauer, O Galgo Preto: Guardião  e Travessia no
Imaginário  do Lima (Lisboa, Associação MILK, 2024), recolhe relatos orais inéditos e interpreta o
mito à luz da psicologia simbólica e do pensamento ecológico.
Fontes complementares:
– Arquivo Distrital de Viana do Castelo, Crónicas Paroquiais e Relatos Populares, 1650–1730;
– Museu dos Terceiros, Caderno das Lendas do Lima (1901–1910);
– Tese de Mestrado de Miguel Araújo, Animais do Limiar: O Simbolismo do Cão  no Norte de
Portugal (U. Minho, 2019).
⸻
5. Síntese interpretativa final
A Lenda do Galgo Preto é metáfora da presença invisível que vigia o humano. Representa a
fidelidade eterna, mas também o peso da memória. Ao surgir nas pontes — lugares de passagem
—, o galgo recorda que toda travessia implica risco e renascimento.


A cor negra, longe de ser apenas símbolo de morte, indica potência e proteção. O galgo é
guardião da noite e companheiro das almas errantes, expressão do respeito rural pelo invisível.
Para a Associação  MILK, o mito traduz a ideia de “cuidado noturno” — o gesto de vigiar o que
dorme, de proteger o que se cala. Na escultura MILK criada por Eduardo Mauer, o Galgo Preto
surge como corpo alongado, mas compacto, de proporções simbólicas e olhar luminoso. As
cores são preto-brilhante e cinza-metálico, com olhos âmbar, re fletindo a tensão entre sombra e
luz.
O mito, na leitura estética de Mauer, é também uma meditação sobre o olhar que devolve o
olhar: quando o Galgo observa o humano, é a própria consciência que se confronta consigo
mesma.
⸻
6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer
A leitura não binária de Eduardo Mauer vê no Galgo Preto o arquétipo da identidade fluida e
vigilante. O animal é simultaneamente selvagem e doméstico, protetor e ameaçador, luz e
escuridão. Essa coexistência de opostos rompe a lógica binária e propõe uma ética do limiar.
Mauer interpreta o Galgo Preto como “figura queer da travessia” — o corpo que não pertence a
lado algum, mas que é passagem em si. O seu silêncio é linguagem; o seu movimento, prece. Ao
mesmo tempo, o Galgo é presença que habita o medo sem se submeter a ele.
A sua cor, negra e brilhante, representa o espaço da potência antes da forma, o lugar onde
tudo pode nascer. Assim, o Galgo Preto é símbolo da liberdade de ser o que muda.
Na visão da Associação  MILK, o mito ecoa a própria proposta do Folclore Vivo: acolher o
indefinido, o transitório, o que não se fixa. O Galgo Preto não é o fim, mas o caminho que conduz
o humano ao encontro de si mesmo através do escuro.
⸻
7. Referência Estrutural da Matriz MILK
Na Matriz Escultórica MILK, o Galgo Preto é modelado com corpo compacto e elegante,
cabeça grande em proporção, olhos âmbar e superfície polida. O corpo re flete a luz em gradiente
metálico, do preto profundo ao cinza-prateado. O acabamento deve sugerir movimento e tensão
contida.
A instalação pode incluir projeção de sombras móveis e som de respiração suave, criando a
sensação de presença vigilante.
⸻
Localização  específica: Ponte de Lima, Alto Minho.
Primeiro relato documentado: Jornal O Minho, 1898.
Sistematização  contemporânea:  Eduardo Mauer, O Galgo Preto: Guardião  e Travessia no
Imaginário  do Lima, Associação MILK, 2024.
Fontes primárias:  Braga (1883); Vasconcelos (1913); Parafita (2008); Araújo (2019); Mauer (2024).
