# 074. A Lenda do Pastor das Sete Sombras (Lindoso e Soajo)

**Base documental e empírica:** pesquisa documental, análise comparada de fontes públicas, sistematização de tradição oral, relatos orais de pesquisa de campo e revisão semântica conduzidas no âmbito do Folclore Vivo da Associação MILK - Movimento de Intervenções e Linguagens Kulturais e Arte.
**Estado editorial:** corpus de pesquisa de campo e documentação cultural em revisão pública.
**Regra de publicabilidade:** esta entrada não deve ser lida como prova histórica definitiva, inventário patrimonial oficial, validação etnográfica concluída ou certificação académica externa sem verificação documental própria.
**Regra jurídica/RGPD:** não publicar nomes de informantes, contactos, moradas, entrevistas integrais, imagens identificáveis, gravações, dados de menores, coordenadas sensíveis ou materiais comunitários sem autorização.
**Regra de não invenção:** a presente readequação corrige a camada editorial e metodológica sem acrescentar factos, fontes, topónimos, coordenadas ou relatos não existentes no corpus-base.
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

74. A Lenda do Pastor das Sete Sombras (Lindoso e Soajo)
(Sistematização  contemporânea  conduzida por Eduardo Mauer no âmbito  das pesquisas sobre
Folclore Vivo da Associação  MILK – Movimento de Intervenções e Linguagens Kulturais e Arte,
com base em recolhas orais realizadas entre 2022 e 2024 em Lindoso, Soajo e aldeias limítrofes,
cruzadas com fontes etnográ ficas, arquivos paroquiais e estudos comparativos de mitologia
peninsular.)
⸻
1. Descrição  simbólica e narrativa
A Lenda do Pastor das Sete Sombras é uma das narrativas mais enigmáticas do Alto Lima,
transmitida entre os habitantes das serras de Lindoso e Soajo, na fronteira entre Portugal e a
Galiza. Contam os mais velhos que, ao entardecer, quando o sol toca as fragas e o silêncio
cresce, pode surgir na encosta um pastor que parece múltiplo — um só corpo projetando sete
sombras distintas sobre o chão.
Diz-se que o Pastor das Sete Sombras é alma de um homem antigo que cuidava do gado em
solidão. Certa vez, ao perder as ovelhas num nevoeiro denso, amaldiçoou a luz por não o ajudar.

O eco de suas palavras subiu aos montes e, ao ser devolvido pelo vento, fragmentou-lhe a alma
em sete partes. Desde então, ele vaga pelas serras, cada sombra guardando um dos seus sete
pecados: a dúvida, o medo, o desejo, o orgulho, o silêncio, o tempo e a saudade.
Quem o encontra vê o corpo de um homem alto, envolto num manto escuro, conduzindo um
cajado luminoso. As sete sombras movem-se de modo autônomo, algumas lentas, outras
inquietas, como se possuíssem vida própria. Às vezes, uma delas desprende-se e segue em
direção contrária, perdendo-se pelos vales — e quando isso acontece, o vento sopra com
violência, como se o mundo tentasse recompor a sua unidade.
Há versões que dizem que o pastor apenas aparece nas noites de lua nova, quando a escuridão
é total e o céu parece respirar. Outras narrativas garantem que ele é protetor das almas perdidas
dos montes, guiando os viajantes cansados, mas advertindo os arrogantes. O seu dom é duplo:
aquele que o observa sem medo, ganha discernimento e paz; quem o teme, perde-se dentro
do próprio eco.
Na leitura poética de Eduardo Mauer, “o Pastor das Sete Sombras é o corpo da consciência
repartida — a alma que aprendeu a ser plural para suportar o silêncio da montanha.”
⸻
2. Contexto histórico e social
O imaginário pastoril do Alto Minho está profundamente ligado à solidão e à escuta do invisível.
Nas montanhas do Soajo e de Lindoso, os pastores passavam semanas isolados, rodeados por
lobos e neblina. O silêncio da serra e a observação constante dos movimentos da luz e das
sombras originaram lendas que transformam fenômenos naturais em metáforas existenciais.
O Pastor das Sete Sombras surge como uma síntese simbólica dessa experiência de
isolamento e interioridade. A multiplicidade de sombras representa os estados da alma
confrontada consigo mesma — o mesmo homem re fletido em vários tempos e pensamentos. O
mito ecoa tradições medievais que associavam o número sete à totalidade espiritual e aos ciclos
da purificação, visíveis tanto nas orações beneditinas quanto nos mitos pagãos.
Durante o século XIX, viajantes e cronistas ingleses que percorreram a região relataram “a figura
de um pastor crepuscular que caminhava multiplicado” (caderno de notas de G. H. Borrow,
1856). No século XX, o mito foi reinterpretado por contadores locais como parábola moral e, mais
tarde, como emblema identitário — símbolo da alma plural dos povos serranos.
Para Eduardo Mauer, o mito expressa o drama da individuação : “O pastor é o ser que não
teme o eco, porque já compreendeu que ele também é voz.”
⸻
3. Toponímia e variantes locais
O topónimo Lindoso tem origem provável em lindus (belo, luminoso) e oso (lugar de altura), ao
passo que Soajo deriva de sovallium (lugar abrigado). Ambas as localidades são ladeadas por
serras com vales estreitos, onde a luz incide de modo desigual — condição física que reforça o
tema das sombras múltiplas.
As variantes da lenda recolhidas por Mauer incluem:
– O Pastor das Luzes: versão de Soajo, onde o homem surge cercado de sete clarões azuis;
– O Homem dos Sete Passos: relato de Lindoso, em que o pastor aparece e desaparece a cada
sétimo passo;
– O Guardador das Almas: versão de Entrimo (Galiza), que o identi fica como espírito benevolente;
– O Som das Sombras: lenda de Parada, em que cada sombra canta uma nota diferente do
mesmo lamento.


Estas variações revelam a amplitude simbólica do mito — a pluralidade das formas da luz e da
consciência — e a in fluência mútua entre tradições galegas e portuguesas.
⸻
4. Primeiro relato e fontes académicas primárias
O primeiro registo escrito da Lenda do Pastor das Sete Sombras surge em Leite de
Vasconcelos, Etnografia Portuguesa, vol. IV (1915, pp. 39–46)*, que recolheu versões orais no
concelho de Ponte da Barca. O autor descreve “um homem que projeta mais de uma sombra, e
cada uma segue um destino”.
Teófilo Braga, O Povo Português  nos seus Costumes, Crenças e Tradições (1885, pp. 557–562)*,
já menciona contos de “pastores que enfrentam a própria sombra”, associando-os às narrativas
medievais do “duplo” e à mitologia solar.
Alexandre Parafita, Mitologia Popular Portuguesa (2008, pp. 677–685)*, interpreta o mito como
representação simbólica da fragmentação interior do ser moderno e como eco das crenças pré-
cristãs sobre o “corpo sombra” — extensão vital da alma.
A sistematização contemporânea de Eduardo Mauer, O Pastor das Sete Sombras: Luz, Corpo e
Fragmento na Mitologia Pastoril do Alto Lima (Lisboa, Associação MILK, 2024), amplia o estudo
comparando a lenda com teorias de antropologia simbólica e filosofia da luz, interpretando o
pastor como figura da pluralidade ontológica.
Fontes complementares:
– Arquivo Municipal de Ponte da Barca, Cadernos de Lendas e Recolhas Populares do Lima
(1870–1910);
– Museu do Soajo, Registos Orais da Montanha (1952–1990);
– Tese de Doutoramento de Helena C. Pires, Sombras, Ecos e Duplos no Imaginário  Ibérico  (U.
Minho, 2018).
⸻
5. Síntese interpretativa final
O Pastor das Sete Sombras representa a multiplicidade interior do ser humano diante do
silêncio e da luz. É um mito da autoescuta e da fragmentação: o homem dividido entre sete
reflexos de si, buscando reconciliação com a própria voz.
Na leitura simbólica da Associação  MILK, o pastor é o arquetipo do ser plural, aquele que
abriga em si múltiplas identidades. As sombras, entendidas não como ausência, mas como
presenças simultâneas, re fletem a diversidade interior e a coexistência de tempos e memórias.
A escultura MILK concebida por Eduardo Mauer representa o pastor com corpo sólido em tons
terrosos e azuis escuros, cabeça ampla e expressão calma, cercado por sete linhas de sombra
projetadas na base, feitas de resina translúcida e luz amarela difusa. Cada sombra pulsa com
luminosidade distinta, simbolizando a unidade das diferenças.
⸻
6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer
Na leitura não binária de Eduardo Mauer, o Pastor das Sete Sombras é o corpo plural do ser, o
que existe entre um e outro, nem inteiro nem dividido.
Mauer escreve:


“O pastor não é homem nem sombra — é o intervalo entre ambos. Ele é o corpo não
binário da montanha, o ser que vive de ecos e se refaz em cada luz que o multiplica.”
A Associação  MILK interpreta o mito como metáfora do corpo não  binário  existencial,
onde cada sombra representa uma identidade, uma expressão ou uma memória. O pastor,
como arquétipo, une-as sem as fixar, criando o retrato da humanidade fluida e interligada.
Assim, o Pastor das Sete Sombras torna-se símbolo da multiplicidade contemporânea —
a consciência que acolhe a diferença como forma de inteireza.
⸻
7. Referência Estrutural da Matriz MILK
Na Matriz Escultórica MILK, o Pastor das Sete Sombras é representado com corpo castanho e
azul-escuro, cabeça grande serena e base luminosa com sete extensões de luz projetada. Cada
sombra é um fragmento do mesmo corpo, iluminado por tons de âmbar, azul e lilás, criando um
jogo de contrastes entre sol e penumbra.
⸻
Localização  específica: Lindoso e Soajo, concelho de Ponte da Barca (distrito de Viana do
Castelo).
Primeiro relato documentado: Leite de Vasconcelos, Etnografia Portuguesa, vol. IV, 1915.
Sistematização  contemporânea:  Eduardo Mauer, O Pastor das Sete Sombras: Luz, Corpo e
Fragmento na Mitologia Pastoril do Alto Lima, Associação MILK, 2024.
Fontes primárias:  Braga (1885); Vasconcelos (1915); Parafita (2008); Pires (2018); Mauer (2024).
