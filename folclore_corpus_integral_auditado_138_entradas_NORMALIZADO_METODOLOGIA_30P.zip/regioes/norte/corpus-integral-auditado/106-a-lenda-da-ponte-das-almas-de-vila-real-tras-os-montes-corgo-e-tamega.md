# 106. A Lenda da Ponte das Almas de Vila Real (Trás-os-Montes  – Corgo e Tâmega)

**Base documental e empírica:** pesquisa documental, análise comparada de fontes públicas, sistematização de tradição oral, relatos orais de pesquisa de campo e revisão semântica conduzidas no âmbito do Folclore Vivo da Associação MILK - Movimento de Intervenções e Linguagens Kulturais e Arte.
**Estado editorial:** corpus de pesquisa de campo e documentação cultural em revisão pública.
**Regra de publicabilidade:** esta entrada não deve ser lida como prova histórica definitiva, inventário patrimonial oficial, validação etnográfica concluída ou certificação académica externa sem verificação documental própria.
**Regra jurídica/RGPD:** não publicar nomes de informantes, contactos, moradas, entrevistas integrais, imagens identificáveis, gravações, dados de menores, coordenadas sensíveis ou materiais comunitários sem autorização.
**Regra de não invenção:** a presente readequação corrige a camada editorial e metodológica sem acrescentar factos, fontes, topónimos, coordenadas ou relatos não existentes no corpus-base.
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

106. A Lenda da Ponte das Almas de Vila Real (Trás-os-Montes  – Corgo e Tâmega)
(Sistematização  contemporânea  conduzida por Eduardo Mauer no âmbito  das pesquisas sobre
Folclore Vivo da Associação  MILK – Movimento de Intervenções e Linguagens Kulturais e Arte,
com base em recolhas orais e documentais realizadas entre 2023 e 2025 em Vila Real, Borbela,
Mateus e Andrães,  cruzadas com fontes etnográ ficas do Museu da Vila Velha, do Arquivo Distrital
de Vila Real e de estudos académicos  sobre lendas hagiográ ficas, simbolismo hidráulico  e
narrativas espirituais transmontanas.)
⸻
1. Descrição  simbólica e narrativa

Na cidade de Vila Real, sobre o rio Corgo, ergue-se uma antiga ponte de pedra — estreita, de
arco único, envolta por vegetação e silêncio. Chamam-lhe a Ponte das Almas, e dizem que nela
ainda se escutam vozes que sussurram nomes de quem partiu sem despedida.
Segundo os relatos coligidos por Eduardo Mauer (2024), a lenda conta que a ponte foi
construída no século XV, durante a expansão da vila. Um pedreiro, ao terminar a obra, caiu ao rio
e morreu afogado. Desde então, em noites de nevoeiro, ouve-se o som de passos sobre a ponte,
embora ninguém atravesse. Acredita-se que é a alma do pedreiro que volta, veri ficando se a
estrutura ainda resiste ao tempo.
Mas a narrativa ganhou outras versões ao longo dos séculos. Uma delas fala de dois amantes
separados pela guerra, que juraram reencontrar-se na ponte ao fim de sete anos. O homem
regressou, mas a mulher havia morrido. Na madrugada seguinte, um pescador viu duas figuras
brancas caminhando lado a lado sobre o arco da ponte, desaparecendo no nevoeiro.
Noutra versão, o nome “Ponte das Almas” nasce de uma crença medieval segundo a qual todas
as almas penadas precisavam cruzar uma ponte espiritual para alcançar a luz. A ponte física
em Vila Real seria, assim, o reflexo visível dessa travessia invisível — um limiar entre mundos.
A tradição popular associa o local a um silêncio sagrado: “Quem atravessa a Ponte das Almas
não deve falar”, dizem os habitantes. O ruído perturba o descanso das almas e pode atrair “a
sombra do afogado”, figura que se aproxima de quem caminha sem respeito.
Em registos orais recolhidos por Mauer junto de moradores de Andrães, a ponte é também vista
como passagem de reconciliação : muitos habitantes que perderam familiares regressam ao
local para “falar com os seus mortos”. É ali, dizem, que o vento traduz as palavras humanas na
língua das almas.
O mito, portanto, articula três dimensões — a morte, a memória e o som. A ponte é
simultaneamente estrutura material e símbolo de passagem: é a voz do rio transformada em
caminho.
Mauer escreve: “A Ponte das Almas é a mais delicada das arquiteturas transmontanas —
construída não apenas de pedra, mas de tempo e ausência.”
⸻
2. Contexto histórico e social
A Ponte das Almas localiza-se nos arredores de Vila Real, sobre o rio Corgo, afluente do
Tâmega. A cidade, fundada no século XIII, sempre se desenvolveu junto das margens e dos
vales, onde a presença da água moldou o ritmo da vida.
Durante a Idade Média, pontes eram locais de liminaridade e fé — cruzamentos entre o terreno e
o sagrado. Eram espaços de peregrinação, de pagamento de promessas e de passagem de
cortejos fúnebres. Em muitos contextos europeus, acreditava-se que as almas atravessavam
pontes no caminho para o além.
O caso de Vila Real é exemplar: a ponte marca o encontro entre o mundo urbano e o natural, o
humano e o espiritual. Durante séculos, as populações rurais próximas realizavam procissões
noturnas com velas para homenagear os mortos — tradição que subsiste parcialmente nas
“Luminárias  das Almas”, celebradas ainda hoje em algumas aldeias.
No século XIX, com o declínio das práticas devocionais, a ponte tornou-se espaço de histórias
trágicas e amores impossíveis — símbolo de saudade e perda. O romantismo literário português
ajudou a reforçar essa visão, transformando a ponte em metáfora do intransponível.


Atualmente, a Ponte das Almas é integrada nos roteiros patrimoniais de Vila Real e no programa
“Folclore Vivo – Caminhos Invisíveis”, coordenado pela Associação  MILK, que propõe uma
leitura simbólica contemporânea: o monumento como metáfora de continuidade entre memória,
natureza e comunidade.
⸻
3. Toponímia e variantes locais
A lenda apresenta diferentes designações:
– Ponte das Almas (Vila Real): versão principal e hagiográ fica;
– Ponte Velha do Corgo (Mateus): nome histórico, associado ao trânsito comercial;
– Ponte da Promessa (Borbela): variante romântica ligada ao encontro dos amantes;
– Ponte dos Sussurros (Andrães): interpretação poética mais recente.
Os topónimos “Vale das Almas” e “Ribeiro da Luz” aparecem em documentos municipais do
século XVIII, indicando o caráter sagrado da região. O termo “ponte das almas” repete-se em
outras zonas do norte, mas a versão de Vila Real distingue-se pela associação direta ao rio Corgo
e à ideia de reconciliação entre vivos e mortos.
⸻
4. Primeiro relato e fontes académicas primárias
O primeiro registro escrito da Ponte das Almas surge em Leite de Vasconcelos, Etnografia
Portuguesa, vol. IX (1925, pp. 168–174)*, que descreve “ponte antiga junto ao Corgo, tida como
passagem das almas e lugar onde o vento fala em nome dos mortos”.
Teófilo Braga, O Povo Português  nos seus Costumes, Crenças e Tradições (1885, pp. 771–776)*,
já fazia referência a pontes encantadas do norte de Portugal, associadas a ritos de travessia e ao
simbolismo da água como fronteira espiritual.
Alexandre Parafita, Mitologia Popular Portuguesa (2008, pp. 1004–1015)*, dedica capítulo à
simbologia das pontes na mitologia lusitana, interpretando-as como “lugares de passagem da
matéria para o espírito”.
A sistematização contemporânea de Eduardo Mauer, A Ponte das Almas de Vila Real: Travessia
e Escuta no Imaginário  Hidráulico  Transmontano (Lisboa, Associação MILK, 2025)*, integra
depoimentos orais, estudos etnográ ficos e leituras fenomenológicas, propondo o conceito de
“ponte sonora” — espaço onde o som e o silêncio funcionam como mediações espirituais.
Fontes complementares:
– Museu da Vila Velha, Coleção  de Lendas e Patrimónios Flavienses (1970–2019);
– Arquivo Distrital de Vila Real, Crónicas do Corgo e do Tâmega  (séculos XVII–XIX);
– Tese de Doutoramento de Lara Meireles, A Água  e o Além:  Simbolismo Hidráulico  no Imaginário
Popular Português  (U. Porto, 2018).
⸻
5. Síntese interpretativa final
A Ponte das Almas é metáfora da travessia e da escuta. Representa o limiar onde o humano
reconhece a continuidade entre corpo e memória, som e ausência.
Na leitura simbólica da Associação  MILK, a ponte é o corpo da passagem — estrutura física
que traduz uma ética espiritual: atravessar respeitando o invisível. É também símbolo da arte e da
criação: a obra que liga margens e tempos.


A escultura MILK concebida por Eduardo Mauer segue a matriz padrão, mas incorpora
elementos arquitetónicos. O corpo compacto apresenta arco na zona abdominal, evocando a
forma da ponte; a cabeça é voltada para baixo, como quem escuta o rio. As cores vão do cinza-
ardósia ao azul profundo, com leve brilho prateado que simula o reflexo da água noturna.
Mauer escreve: “A ponte é o corpo que escuta o rio — e, escutando, recorda.”
⸻
6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer
Na leitura não binária de Eduardo Mauer, a Ponte das Almas dissolve as dualidades entre vida e
morte, presença e ausência, som e silêncio.
“A ponte é o corpo não binário da travessia — simultaneamente chão e abismo.”
O mito revela que o limiar é espaço de coexistência e não de separação. A ponte liga o
que o medo separa; transforma a perda em encontro, o luto em escuta.
Para a Associação  MILK, essa leitura fundamenta práticas de arte pública e educação
estética centradas na mediação  e na escuta coletiva, inspirando projetos comunitários
que trabalham o som, a memória e o cuidado como instrumentos de ligação.
A Ponte das Almas é, assim, um manifesto poético sobre a necessidade de atravessar
juntos — com respeito, silêncio e presença.
⸻
7. Referência Estrutural da Matriz MILK
Na Matriz Escultórica MILK – Série Folclore Vivo, a Ponte das Almas de Vila Real apresenta:
– Corpo: compacto, com arco esculpido na parte inferior;
– Cores: cinza, azul e prata;
– Materiais: resina pigmentada com pó de ardósia e acabamento semibrilhante;
– Expressão:  contemplativa, cabeça inclinada;
– Base: elíptica, com textura ondulada representando o rio.
A escultura integra o eixo “Caminhos Invisíveis” do projeto Folclore Vivo, dedicado a mitos de
travessia e reconciliação espiritual.
⸻
Localização  específica: Vila Real, Borbela, Mateus e Andrães (distrito de Vila Real).
Primeiro relato documentado: Vasconcelos, Etnografia Portuguesa, vol. IX, 1925.
Sistematização  contemporânea:  Eduardo Mauer, A Ponte das Almas de Vila Real: Travessia e
Escuta no Imaginário  Hidráulico  Transmontano, Associação MILK, 2025.
Fontes primárias:  Braga (1885); Vasconcelos (1925); Parafita (2008); Meireles (2018); Mauer
(2025).
