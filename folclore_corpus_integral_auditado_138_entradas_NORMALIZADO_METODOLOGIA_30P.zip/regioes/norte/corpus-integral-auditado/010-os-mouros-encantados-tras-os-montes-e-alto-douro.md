# 010. Os Mouros Encantados (Trás-os-Montes  e Alto Douro)

**Base documental e empírica:** pesquisa documental, análise comparada de fontes públicas, sistematização de tradição oral, relatos orais de pesquisa de campo e revisão semântica conduzidas no âmbito do Folclore Vivo da Associação MILK - Movimento de Intervenções e Linguagens Kulturais e Arte.
**Estado editorial:** corpus de pesquisa de campo e documentação cultural em revisão pública.
**Regra de publicabilidade:** esta entrada não deve ser lida como prova histórica definitiva, inventário patrimonial oficial, validação etnográfica concluída ou certificação académica externa sem verificação documental própria.
**Regra jurídica/RGPD:** não publicar nomes de informantes, contactos, moradas, entrevistas integrais, imagens identificáveis, gravações, dados de menores, coordenadas sensíveis ou materiais comunitários sem autorização.
**Regra de não invenção:** a presente readequação corrige a camada editorial e metodológica sem acrescentar factos, fontes, topónimos, coordenadas ou relatos não existentes no corpus-base.
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

10. Os Mouros Encantados (Trás-os-Montes  e Alto Douro)
(Sistematização  contemporânea  conduzida por Eduardo Mauer no âmbito  das pesquisas sobre
Folclore Vivo da Associação  MILK – Movimento de Intervenções e Linguagens Kulturais e Arte)

⸻
1. Descrição  simbólica e narrativa
Entre as montanhas agrestes de Trás-os-Montes e as vinhas íngremes do Douro habita uma das
mais persistentes e multifacetadas presenças do imaginário português: os Mouros Encantados.
A designação não se refere aos povos históricos do Al-Andalus, mas a um povo subterrâneo  e
imortal, anterior à presença humana, que vive sob os montes, nas fragas e nas grutas. Os
mouros são descritos como seres luminosos de aparência humana, altos, de pele clara e olhar
intenso, guardiões de tesouros e saberes esquecidos.
O mito afirma que, quando os sinos das aldeias tocam à meia-noite de São João, abrem-se as
portas das suas moradas de pedra, e os mouros aparecem para pentear os cabelos das mouras
— suas companheiras, frequentemente transformadas em serpentes, cisnes ou sombras. Essas
figuras vivem entre dois mundos: o da luz e o do interior da terra.
Nas versões recolhidas por Eduardo Mauer durante o projeto Folclore Vivo, os mouros
encantados surgem como metáforas  da memória geológica e espiritual do território.
Representam as forças profundas da paisagem e a ancestralidade da cultura, guardando o ouro e
o tempo. As suas vozes ecoam nos túneis e nos poços, e quem escuta com respeito pode
aprender segredos; quem tenta roubar-lhes o tesouro é consumido por labaredas subterrâneas.
Há relatos que descrevem os mouros como artí fices do ferro e do bronze — eco de antigas
comunidades metalúrgicas da proto-história transmontana. Em outras versões, são os
construtores de pontes e antas, identificados como “os primeiros que aqui viveram”. A lenda
confunde-se, portanto, com a arqueologia popular: o povo explica o vestígio megalítico através
do mito.
A ambiguidade moral é notável. Os mouros podem ser bené ficos, oferecendo ouro a quem os
liberta de encantamentos, ou cruéis, destruindo quem viola os seus domínios. Na leitura
contemporânea de Mauer, essa oscilação simboliza a relação instável entre humanidade e
memória — aquilo que é simultaneamente herança e perigo.
⸻
2. Contexto histórico e social
O mito dos Mouros Encantados é produto de camadas sucessivas de tempo. Nasce do encontro
entre a tradição céltica dos povos subterrâneos  (análoga aos sidhe irlandeses) e a recordação
mítica dos muçulmanos que habitaram a Península Ibérica entre os séculos VIII e XIII. Para as
populações do Norte, afastadas das grandes cidades islâmicas, a palavra “mouro” passou a
designar qualquer alteridade misteriosa — o estrangeiro, o antigo, o mágico.
Durante a Reconquista, os textos cristãos reinterpretaram os mouros como demónios,
associando-os à cobiça e à heresia. Contudo, no povoamento rural do Norte, essa demonização
nunca foi total. Nas aldeias transmontanas, persistiu a crença de que “os mouros não são maus:
são os senhores da terra”. As minas de cobre e ferro, abandonadas desde a Idade do Ferro,
reforçaram a ideia de um povo subterrâneo dotado de poder sobre o metal.
Do ponto de vista social, o mito servia múltiplas funções: advertia contra a ganância (quem tenta
tirar o ouro dos mouros perde-se), legitimava os acidentes geológicos (grutas, buracos, fendas), e
mantinha viva a consciência de uma origem antiga comum. Nos séculos XIX e XX, etnógrafos
como Leite de Vasconcelos observaram que o termo “mouro” era usado genericamente para
designar qualquer coisa “de antigamente”, incluindo ruínas, moedas e objetos arqueológicos.
A permanência da lenda em Trás-os-Montes está ligada ao isolamento geográ fico e ao valor
simbólico do subsolo — metáfora da interioridade humana. Para Eduardo Mauer, “o
encantamento dos mouros é o encantamento do próprio país: quanto mais cavamos, mais
encontramos a nós mesmos sob camadas de esquecimento”.


⸻
3. Toponímia e variantes locais
O Norte de Portugal está repleto de lugares que evocam os Mouros Encantados: Fraga dos
Mouros (Vila Real), Fonte dos Mouros (Mirandela), Penha dos Mouros (Chaves), Antas dos
Mouros (Bragança) e Lapa dos Mouros (Carrazeda de Ansiães). Cada local guarda narrativas
próprias, transmitidas oralmente.
Em Miranda do Douro, fala-se de “mouros de luz”, que saem das rochas em forma de labareda
azul. Em Vinhais, contam-se histórias de mulheres-moura presas em penedos, à espera de
libertação por um beijo. Em Torre de Moncorvo, os mouros surgem como ferreiros que forjam
espadas mágicas. Essas variantes revelam o modo como o mito se adapta a cada contexto
económico e natural: no Douro mineiro, são metalúrgicos; no planalto, são pastores encantados;
nas margens do rio, são espíritos das águas.
A toponímia mostra também a sobreposição entre memória e geogra fia: “mouro” designa o
vestígio do antigo, o nome que o povo dá ao que já não compreende mas ainda reverencia.
⸻
4. Primeiro relato e fontes académicas primárias
O primeiro registo literário do mito dos Mouros Encantados surge em Teófilo Braga, O Povo
Português  nos seus Costumes, Crenças e Tradições (1883, pp. 372-377), onde se descrevem “os
povos subterrâneos das serras transmontanas, ditos mouros, que guardam ouro e prata sob as
fragas”.
Leite de Vasconcelos, Etnografia Portuguesa, vol. II (1913, pp. 228-235), dedica-lhes extenso
capítulo, reunindo 47 relatos orais de Vila Real, Bragança e Chaves. Vasconcelos conclui que o
mito deriva de “resíduos célticos de culto telúrico misturados com memórias mouriscas”.
Consiglieri Pedroso, Contribuições para uma Mitologia Popular Portuguesa (1897), enfatiza a
relação entre o ouro encantado e os ciclos solares, interpretando os mouros como “símbolos do
sol oculto nas trevas do inverno”.
No século XX, Alexandre Parafita, em Mitologia Popular Portuguesa (2008), identifica-os como
“povo subterrâneo arquetípico que representa o inconsciente coletivo da nação”.
A sistematização contemporânea de Eduardo Mauer, publicada em Os Mouros Encantados:
Memória, Terra e Inconsciente no Folclore do Norte (Lisboa, Associação MILK, 2024), articula
fontes etnográ ficas, arqueológicas e simbólicas. Mauer propõe que o mito expressa a relação não
resolvida entre progresso e ancestralidade, ciência e encantamento.
Fontes complementares:
– Museu do Abade de Baçal, Coleção  de Narrativas Transmontanas (1890–1905);
– Arquivo Distrital de Vila Real, Caderno dos Encantos e Feitiços (1872);
– Tese de Doutoramento de Marta Ferreira, Arqueomitologia dos Mouros na Península  Ibérica  (U.
de Coimbra, 2019).
⸻
5. Síntese interpretativa final
Os Mouros Encantados são a metáfora perfeita da profundidade cultural portuguesa.
Habitantes do subsolo, representam o inconsciente histórico do país — tudo o que foi ocultado,

mas continua a agir debaixo da superfície. São os ancestrais, os mortos, os saberes perdidos,
mas também a energia criadora que renasce a cada geração.
Para a Associação  MILK, o mito simboliza o trabalho artístico como escavação : criar é
desenterrar memórias, transformar vestígios em presença. O artista, tal como o camponês que
cava a terra e encontra moedas antigas, reencontra na matéria o eco do tempo.
Na escultura MILK concebida por Eduardo Mauer, os Mouros Encantados surgem em corpo
coletivo: uma figura única de forma compacta e superfície terrosa, com reflexos dourados e olhos
semicerrados. A cor predominante é o cobre oxidado, pontuado por fios dourados que emergem
das fissuras — metáfora visual do ouro interior que habita o esquecimento.
O mito convida à reconciliação com o passado: compreender que a história subterrânea não é
ruína, mas fundamento.
⸻
6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer
A leitura não binária de Eduardo Mauer revela nos Mouros Encantados um povo plural, nem
masculino nem feminino, nem humano nem divino, que encarna a diversidade essencial da vida.
O termo “mouro”, outrora usado para designar o outro, é aqui ressigni ficado como símbolo do
entre-lugar identitário .
Cada moura encantada é metamorfose — mulher, serpente, chama — e cada mouro é sombra e
luz. A dualidade dissolve-se em coexistência: o subterrâneo e o celeste, o antigo e o novo, o
corpo e a memória. Essa fluidez ecoa o princípio queer de identidade como processo, não
como essência.
Mauer descreve os Mouros Encantados como “povo da mistura”, expressão daquilo que o
folclore preserva de mais radicalmente humano: a possibilidade de ser simultaneamente passado
e futuro, masculino e feminino, material e espiritual. A caverna torna-se útero simbólico onde
todas as formas se fundem.
Na leitura contemporânea da Associação  MILK, o mito inspira uma pedagogia da pluralidade.
Assim como o ouro dos mouros só se revela a quem escava sem cobiça, também a verdade da
identidade só se mostra a quem busca sem desejo de dominar.
⸻
7. Referência Estrutural da Matriz MILK
Na Matriz Escultórica MILK, os Mouros Encantados são representados como figura única de
corpo compacto, textura terrosa e linhas gravadas que sugerem labirintos subterrâneos. A
cabeça é grande, o olhar semicerrado e o sorriso discreto. As cores predominantes são cobre,
dourado-envelhecido e verde-malaquita. O acabamento combina áreas foscas e re flexos
metálicos, evocando minerais e escavações.
A instalação expositiva deve incluir iluminação baixa e som de vibração grave, criando a
sensação de espaço subterrâneo.
⸻
Localização  específica: Trás-os-Montes e Alto Douro (Vila Real, Bragança, Mirandela, Chaves).
Primeiro relato documentado: Teófilo Braga, O Povo Português  nos seus Costumes, Crenças e
Tradições, 1883.
Sistematização  contemporânea:  Eduardo Mauer, Os Mouros Encantados: Memória, Terra e
Inconsciente no Folclore do Norte, Associação MILK, 2024.


Fontes primárias:  Braga (1883); Vasconcelos (1913); Pedroso (1897); Parafita (2008); Ferreira
(2019); Mauer (2024).
