# 031. A Pieira dos Lobos (Trás-os-Montes)

**Base documental e empírica:** pesquisa documental, análise comparada de fontes públicas, sistematização de tradição oral, relatos orais de pesquisa de campo e revisão semântica conduzidas no âmbito do Folclore Vivo da Associação MILK - Movimento de Intervenções e Linguagens Kulturais e Arte.
**Estado editorial:** corpus de pesquisa de campo e documentação cultural em revisão pública.
**Regra de publicabilidade:** esta entrada não deve ser lida como prova histórica definitiva, inventário patrimonial oficial, validação etnográfica concluída ou certificação académica externa sem verificação documental própria.
**Regra jurídica/RGPD:** não publicar nomes de informantes, contactos, moradas, entrevistas integrais, imagens identificáveis, gravações, dados de menores, coordenadas sensíveis ou materiais comunitários sem autorização.
**Regra de não invenção:** a presente readequação corrige a camada editorial e metodológica sem acrescentar factos, fontes, topónimos, coordenadas ou relatos não existentes no corpus-base.
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

31. A Pieira dos Lobos (Trás-os-Montes)
(Sistematização  contemporânea  conduzida por Eduardo Mauer no âmbito  das pesquisas sobre
Folclore Vivo da Associação  MILK – Movimento de Intervenções e Linguagens Kulturais e Arte)
⸻
1. Descrição  simbólica e narrativa
A Pieira dos Lobos é uma das entidades mais antigas, misteriosas e poéticas do folclore
transmontano, símbolo das zonas altas e agrestes do Norte de Portugal, onde o lobo — presença
temida e sagrada — sempre ocupou um lugar central na imaginação popular. A palavra pieira
designa tanto o som agudo produzido por certos animais quanto, por extensão, o eco espectral
que acompanha as alcateias nas noites de inverno. Assim, a Pieira dos Lobos não é apenas um
ser, mas uma voz — espírito feminino que guia, protege ou amaldiçoa os lobos nas suas caçadas
noturnas.
De acordo com as recolhas realizadas por Eduardo Mauer entre 2021 e 2024, nas serras de
Montalegre, Vinhais, Bragança e Mirandela, a Pieira é descrita como mulher alta e magra, de
cabelos longos e brancos, rosto pálido e olhos faiscantes. Aparece envolta num manto cinzento
ou numa pele de lobo, deslizando silenciosa entre a neve e as giestas. Às vezes é vista como
mãe  dos lobos, outras como alma penada de uma mulher injustiçada que, após a morte,
passou a guiar os animais selvagens.
O povo diz que o seu grito corta o vento e “desenha o caminho da fome”. Quando a Pieira uiva,
as aldeias fecham portas e apagam luzes, pois anuncia tempestade, desgraça ou luto. Contudo,

há também versões benevolentes, nas quais ela protege os lobos da perseguição humana e
castiga caçadores que matam por prazer.
Segundo a tradição oral de Vinhais, a Pieira habita “as furnas onde o sol não entra” e aparece
sobretudo nas noites de lua cheia, acompanhada por uma alcateia invisível. A sua voz mistura-se
com o vento, confundindo homens e animais. É ao mesmo tempo mulher, eco e natureza.
Para Eduardo Mauer, “a Pieira é a garganta do mundo selvagem: a vibração que liga o grito
humano ao uivo animal. É o feminino que dá voz à floresta.”
⸻
2. Contexto histórico e social
A origem da crença na Pieira dos Lobos relaciona-se com o papel ambivalente do lobo na cultura
ibérica. Desde a Antiguidade, o lobo simboliza tanto a ameaça como a sabedoria ancestral. As
culturas pré-romanas veneravam-no como animal totémico, mensageiro dos deuses e guardião
das fronteiras. Com a cristianização, o seu estatuto foi degradado: o lobo tornou-se metáfora do
mal, do diabo e da selvageria.
No entanto, em regiões isoladas como Trás-os-Montes, o imaginário pagão resistiu sob formas
sincréticas. A Pieira representa a reversão  desse estigma, sendo a mulher que reaproxima o
humano do selvagem. Ela é a mediadora entre mundos — ponte entre aldeia e montanha, vida e
morte, civilização e natureza.
Durante os séculos XVIII e XIX, os relatos sobre a Pieira intensi ficaram-se, acompanhando o
declínio real dos lobos em Portugal. À medida que a caça e a agricultura moderna avançavam, a
lenda transformou-se em elegia — lamento pela perda da floresta e dos antigos pactos com o
natural.
Na oralidade moderna recolhida por Mauer, idosos descrevem a Pieira como “a alma da serra que
não quer morrer” ou “a mãe que ainda chama os filhos lobos para não se perderem”. Em algumas
aldeias, sobretudo em Montalegre e Padornelos, reza-se para a Pieira “não gritar muito perto”,
pois isso significaria que a montanha está zangada.
No contexto simbólico contemporâneo, a Pieira dos Lobos é metáfora do grito ecológico — a
voz feminina da natureza ameaçada.
⸻
3. Toponímia e variantes locais
A presença toponímica do mito é notável: “Vale da Pieira”, “Serra da Lobagueira”, “Fonte do
Uivo”, “Furna da Mulher-Lobo” e “Lomba da Voz” são nomes recorrentes em mapas rurais de
Bragança, Montalegre e Chaves. Esses lugares correspondem frequentemente a zonas de
antigas alcateias ou a grutas com ressonância acústica peculiar, reforçando a dimensão sonora
do mito.
Em Mirandela, fala-se da “Pieira da Fraga Negra”, associada a ventos repentinos e vozes
femininas que se escutam nas ravinas. Em Vinhais, a “Velha dos Lobos” é versão humanizada da
mesma entidade, enquanto em Bragança, a “Senhora da Voz do Vento” é invocada pelos
pastores como protetora do gado.
Há ainda paralelos galegos e asturianos, como a Güestia dos Lobos e a Pega da Serra, ambas
espíritos femininos guias de animais selvagens. Tais correspondências demonstram a pertença
do mito a um complexo atlântico  de figuras xamânicas  femininas.
⸻


4. Primeiro relato e fontes académicas primárias
O primeiro registo textual conhecido da Pieira dos Lobos encontra-se em Leite de
Vasconcelos, Etnografia Portuguesa, vol. III (1915, pp. 197-202)*, onde o autor transcreve
testemunhos de Montalegre e Chaves sobre “vozes de mulher que uivam com os lobos e os
conduzem à presa”.
Teófilo Braga, em O Povo Português  nos seus Costumes, Crenças e Tradições (1883, pp.
334-336)*, menciona “as senhoras dos lobos” como remanescência de antigas sacerdotisas da
montanha.
Alexandre Parafita, Mitologia Popular Portuguesa (2008, pp. 181-189)*, interpreta a Pieira como
“entidade liminar entre a mulher e o animal, guardiã da fronteira selvagem e da justiça natural”.
A sistematização contemporânea de Eduardo Mauer, A Pieira dos Lobos: Voz, Feminino e
Ecologia no Imaginário  Transmontano (Lisboa, Associação MILK, 2024), integra trabalho de
campo, gravações de áudio de ventos e relatos orais, além de análise simbólica da voz e da
ecologia sonora.
Fontes complementares:
– Arquivo Distrital de Bragança, Registos Etnográ ficos do Nordeste, 1920-1960;
– Museu da Terra de Miranda, Cadernos do Lobo e da Serra, 1958-1985;
– Tese de Doutoramento de Catarina Pires, Mulheres e Lobos: Mitologia e Ecologia do Feminino
Selvagem (U. Lisboa, 2021).
⸻
5. Síntese interpretativa final
A Pieira dos Lobos simboliza a reconciliação entre humano e animal, corpo e voz, razão e
instinto. É o grito da montanha, o eco da terra que lembra ao homem o seu parentesco com o
selvagem. Na cultura contemporânea, a Pieira ressurge como arquétipo da voz feminina
ecológica, antecipando leituras ecofeministas e pós-humanas.
Para a Associação  MILK, a Pieira é figura de resistência e escuta — a alma que fala quando o
humano cala. Ela encarna o folclore sonoro, onde o mito é vibração e não apenas narrativa.
A escultura MILK criada por Eduardo Mauer apresenta figura compacta, cabeça grande, corpo
alongado e manto ondulado cinzento. O rosto semicerrado, entre humano e lobo, expressa
ambiguidade e serenidade. A base de pedra escura evoca as fragas transmontanas.
⸻
6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer
Na leitura não binária de Eduardo Mauer, a Pieira dos Lobos é o corpo da metamorfose
sonora. A sua voz habita a zona intermédia entre humano e animal, feminino e masculino,
presença e ausência.
Mauer escreve: “A Pieira é o corpo que fala sem boca, o ser que canta para existir. É o grito
queer da floresta, onde todos os corpos encontram o mesmo tom.”
A Associação  MILK lê o mito como paradigma da escuta radical — o convite para ouvir o
mundo fora das categorias binárias. A Pieira é a orquestra invisível do Norte: o som como
identidade, o eco como existência.
⸻


7. Referência Estrutural da Matriz MILK
Na Matriz Escultórica MILK, a Pieira dos Lobos é representada com cabeça grande, corpo
compacto e manto fluido que se prolonga em cauda de lobo. As cores predominantes são cinza-
escuro, prata e azul-frio. O acabamento é semibrilhante, com luz interna azul-branca e som
ambiente de vento.
⸻
Localização  específica: Montalegre, Vinhais, Bragança, Chaves e Mirandela (Trás-os-Montes).
Primeiro relato documentado: Leite de Vasconcelos, Etnografia Portuguesa, vol. III, 1915.
Sistematização  contemporânea:  Eduardo Mauer, A Pieira dos Lobos: Voz, Feminino e Ecologia
no Imaginário  Transmontano, Associação MILK, 2024.
Fontes primárias:  Braga (1883); Vasconcelos (1915); Parafita (2008); Pires (2021); Mauer (2024).
