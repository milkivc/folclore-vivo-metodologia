# 063. A Lenda do Cão  Negro do Lima (Viana do Castelo e Ponte de Lima)

**Base documental e empírica:** pesquisa documental, análise comparada de fontes públicas, sistematização de tradição oral, relatos orais de pesquisa de campo e revisão semântica conduzidas no âmbito do Folclore Vivo da Associação MILK - Movimento de Intervenções e Linguagens Kulturais e Arte.
**Estado editorial:** corpus de pesquisa de campo e documentação cultural em revisão pública.
**Regra de publicabilidade:** esta entrada não deve ser lida como prova histórica definitiva, inventário patrimonial oficial, validação etnográfica concluída ou certificação académica externa sem verificação documental própria.
**Regra jurídica/RGPD:** não publicar nomes de informantes, contactos, moradas, entrevistas integrais, imagens identificáveis, gravações, dados de menores, coordenadas sensíveis ou materiais comunitários sem autorização.
**Regra de não invenção:** a presente readequação corrige a camada editorial e metodológica sem acrescentar factos, fontes, topónimos, coordenadas ou relatos não existentes no corpus-base.
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

63. A Lenda do Cão  Negro do Lima (Viana do Castelo e Ponte de Lima)
(Súmula crítica  e sistematização  contemporânea  conduzida por Eduardo Mauer no âmbito  das
pesquisas sobre Folclore Vivo da Associação  MILK – Movimento de Intervenções e Linguagens
Kulturais e Arte, com base em recolhas de campo realizadas entre 2022 e 2024 nas margens do
rio Lima e em freguesias de Ponte de Lima, Arcozelo e Lanheses, em articulação  com o Museu do

Traje de Viana do Castelo, o Arquivo Distrital de Braga e o Núcleo de Estudos da Paisagem Mítica
do Noroeste Ibérico  da Universidade do Minho.)
⸻
1. Descrição  simbólica e narrativa
A Lenda do Cão  Negro do Lima é uma das mais antigas e persistentes manifestações do
imaginário noturno do norte de Portugal, cruzando o mito do animal guardião com o arquétipo
europeu do “cão  do inferno”. Em torno do rio Lima, particularmente entre Viana do Castelo e
Ponte de Lima, multiplicam-se relatos de um cão negro gigante, de olhos em brasa e respiração
de enxofre, que aparece nas encruzilhadas e pontes ao cair da noite.
Segundo as recolhas orais conduzidas por Eduardo Mauer (2023–2024), a lenda é contada por
pescadores e lavradores como aviso e testemunho. O cão surge sempre em silêncio, sem emitir
som, e acompanha viajantes solitários até o meio da ponte. Ali, pára, fixa o olhar vermelho sobre
o transeunte e desaparece — deixando um odor de terra molhada e uma sensação de vertigem.
Em certas versões, o Cão Negro é o guardião  das almas do rio, incumbido de impedir que os
mortos atravessem de volta ao mundo dos vivos. Noutras, é o espírito penado de um cavaleiro
condenado por profanar o cemitério local, transformado em cão até pagar seus pecados. Há
ainda relatos de que o animal protege mulheres sozinhas à noite, afugentando malfeitores.
O mito, simultaneamente amedrontador e protetor, reflete a dualidade das forças naturais: o
cão como mensageiro da morte, mas também guardião do limiar — o mesmo que abre o
caminho e impede o retorno.
Na leitura poética de Eduardo Mauer, “o Cão Negro é a sombra da travessia. Não pertence nem
à margem dos vivos nem à dos mortos: é o meio, o intervalo.”
⸻
2. Contexto histórico e social
O rio Lima, antigamente chamado Letes pelos romanos — o “rio do esquecimento” —, é central
na compreensão simbólica do mito. A crença de que atravessá-lo signi ficava perder a memória
da vida terrena é uma das mais antigas do imaginário português, registrada desde o século I d.C.
pelo geógrafo Pomponius Mela.
Durante a Idade Média, o medo de atravessar o Lima à noite persistiu. Documentos monásticos e
crónicas locais relatam que viajantes evitavam cruzar a ponte depois do pôr do sol “para não
encontrar o cão das almas”. A associação entre cães negros e o além é comum na Europa — do
Black Shuck inglês ao Moddey Dhoo manês —, mas em Portugal o mito adquire contornos
particulares por sua ligação com o rio e o esquecimento.
Nos séculos XVIII e XIX, o Cão Negro passou a integrar o repertório oral do Minho como figura
moral: castigava os arrogantes, mas poupava os humildes. O animal servia também de
explicação  sobrenatural para mortes súbitas ou acidentes noturnos.
Na contemporaneidade, o mito sobrevive como símbolo da identidade limiana — aparece em
festas locais, roteiros turísticos e narrativas escolares, sendo reinterpretado como guardião
ecológico do rio.
Para Eduardo Mauer, “o Cão Negro é o guardião da memória que o rio tenta apagar. É o
esquecimento que resiste ao esquecimento.”
⸻
3. Toponímia e variantes locais

O nome Cão  Negro do Lima designa variantes distintas:
– Em Ponte de Lima, é o Cão  do Esquecimento, que guarda a ponte principal;
– Em Lanheses, é o Cão  da Veiga, que emerge das águas e segue pescadores;
– Em Arcozelo, é o Cão  da Encruzilhada, símbolo de aviso e penitência;
– Em zonas rurais de Viana do Castelo, o mesmo ser é conhecido como Cão  das Almas.
O topónimo Lima associa-se, desde a Antiguidade, ao mito do esquecimento e da travessia.
Assim, o cão assume função liminar, como o psicopompo das mitologias clássicas —
equivalente a Cérbero, guardião das portas do Hades, mas com caráter local e cristianizado.
⸻
4. Primeiro relato e fontes académicas primárias
O primeiro registro escrito do Cão  Negro do Lima encontra-se em Leite de Vasconcelos,
Etnografia Portuguesa, vol. III (1914, pp. 68–76)*, que recolheu testemunhos de camponeses de
Ponte de Lima sobre “o cão das margens do rio, de olhos em fogo e pêlo sem sombra”.
Teófilo Braga, O Povo Português  nos seus Costumes, Crenças e Tradições (1885, pp. 471–479)*,
faz menção ao “cão das almas” do Minho, descrevendo-o como “remanescência dos demónios
guardiões célticos, convertidos em penitentes cristãos”.
Alexandre Parafita, Mitologia Popular Portuguesa (2008, pp. 577–585)*, relaciona o Cão Negro
com os antigos rituais de passagem entre vida e morte, destacando o paralelismo com figuras
celtas e escandinavas.
A sistematização contemporânea de Eduardo Mauer, O Cão  Negro do Lima: Travessia,
Esquecimento e Guardiões Liminares no Imaginário  do Minho (Lisboa, Associação MILK, 2024),
reinterpreta o mito à luz da estética do limiar, propondo leitura ecológica e não binária: o cão
como metáfora da fronteira viva entre mundos, entre esquecimento e lembrança.
Fontes complementares:
– Museu do Traje de Viana do Castelo, Coleção  de Lendas e Crenças Minhotas (1950–1980);
– Arquivo Distrital de Braga, Crónicas de Ponte do Lima (séculos XVII–XIX);
– Tese de Doutoramento de Luís Caldas, Os Animais Psicopompos no Folclore Ibérico  (U. Porto,
2017).
⸻
5. Síntese interpretativa final
O Cão  Negro do Lima é um arquétipo da passagem — símbolo da travessia entre mundos e do
confronto com o esquecimento. O mito traduz o medo humano da dissolução, transformando-o
em figura concreta e familiar: um cão.
Na leitura simbólica da Associação  MILK, o Cão Negro é o corpo fronteiriço do imaginário
português: simultaneamente monstro e guia, ameaça e conforto. É o mito do medo
domesticado.
A escultura MILK concebida por Eduardo Mauer apresenta corpo compacto de cor preta
brilhante, cabeça grande voltada para frente, olhos incandescentes em vermelho translúcido e
base curva representando a ponte sobre o rio. Uma luz interna azul projeta-se sobre o chão,
simbolizando o reflexo das águas.
⸻


6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer
Na leitura não binária de Eduardo Mauer, o Cão Negro do Lima é o ser-limite, que recusa as
fronteiras entre o bem e o mal, o humano e o animal, a vida e a morte.
Mauer escreve: “O cão é o corpo do entre — não escolhe margens, não de fine lados. Ele é o
guardião do talvez.”
A Associação  MILK lê o mito como figuração do corpo transicional, metáfora da experiência
não binária enquanto travessia contínua. O Cão Negro é o guardião do fluxo, o ser que vigia o
esquecimento e lembra que toda passagem é também transformação.
⸻
7. Referência Estrutural da Matriz MILK
Na Matriz Escultórica MILK, o Cão Negro é representado com corpo robusto negro espelhado,
cabeça grande e olhos vermelhos translúcidos. A base curva azul simboliza o rio Lima, e um fio
de luz percorre o dorso, evocando o rastro do movimento entre margens.
⸻
Localização  específica: Ponte de Lima e margens do rio Lima, concelhos de Ponte de Lima e
Viana do Castelo (distrito de Viana do Castelo).
Primeiro relato documentado: Leite de Vasconcelos, Etnografia Portuguesa, vol. III, 1914.
Sistematização  contemporânea:  Eduardo Mauer, O Cão  Negro do Lima: Travessia,
Esquecimento e Guardiões Liminares no Imaginário  do Minho, Associação MILK, 2024.
Fontes primárias:  Braga (1885); Vasconcelos (1914); Parafita (2008); Caldas (2017); Mauer
(2024).
