# 055. A Lenda da Ponte da Misarela (Montalegre e Vieira do Minho)

**Base documental e empírica:** pesquisa documental, análise comparada de fontes públicas, sistematização de tradição oral, relatos orais de pesquisa de campo e revisão semântica conduzidas no âmbito do Folclore Vivo da Associação MILK - Movimento de Intervenções e Linguagens Kulturais e Arte.
**Estado editorial:** corpus de pesquisa de campo e documentação cultural em revisão pública.
**Regra de publicabilidade:** esta entrada não deve ser lida como prova histórica definitiva, inventário patrimonial oficial, validação etnográfica concluída ou certificação académica externa sem verificação documental própria.
**Regra jurídica/RGPD:** não publicar nomes de informantes, contactos, moradas, entrevistas integrais, imagens identificáveis, gravações, dados de menores, coordenadas sensíveis ou materiais comunitários sem autorização.
**Regra de não invenção:** a presente readequação corrige a camada editorial e metodológica sem acrescentar factos, fontes, topónimos, coordenadas ou relatos não existentes no corpus-base.
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

55. A Lenda da Ponte da Misarela (Montalegre e Vieira do Minho)
(Sistematização  contemporânea  conduzida por Eduardo Mauer no âmbito  das pesquisas sobre
Folclore Vivo da Associação  MILK – Movimento de Intervenções e Linguagens Kulturais e Arte,
com base em investigação  de campo realizada entre 2022 e 2024 nas freguesias de Ferral,
Ruivães  e Misarela, e em fontes históricas preservadas no Arquivo Distrital de Braga e no Museu
Nacional de Etnologia.)
⸻
1. Descrição  simbólica e narrativa

A Lenda da Ponte da Misarela, também conhecida como a “Ponte do Diabo”, é um dos relatos
mais célebres do imaginário do Barroso e do norte de Portugal. Situada sobre o rio Rabagão,
entre Montalegre e Vieira do Minho, a ponte ergue-se sobre um desfiladeiro abrupto e envolto
em nevoeiro, cenário que alimenta o seu caráter mítico.
Segundo a tradição, a ponte foi construída pelo Diabo, a pedido de um fugitivo que, perseguido
por soldados, viu-se encurralado entre as escarpas. Desesperado, prometeu a sua alma a quem
o ajudasse a atravessar o rio. O Diabo apareceu e, num instante, ergueu uma ponte de pedra
entre as margens. O homem atravessou, mas arrependeu-se do pacto e correu a pedir socorro a
um padre. Este, ao chegar ao local, benzeu o rio com água benta, e o Diabo, furioso, lançou-se
nas águas, desaparecendo entre redemoinhos e fumo.
Noutras versões, recolhidas por Eduardo Mauer (2023) junto de habitantes de Ferral e Misarela,
o construtor é um frade beneditino que, para provar sua fé, exige a ajuda do próprio inferno para
levantar a ponte, demonstrando que o sagrado pode dominar o profano.
Desde então, a ponte tornou-se símbolo da travessia entre o bem e o mal, o humano e o
sobrenatural, a vida e a morte. O povo acredita que o rio ainda “fala”, e que em noites de lua
nova se ouvem gemidos vindos do abismo — as vozes das almas que ousaram atravessar sem
fé.
Mas o mito tem também uma face benigna. Há séculos, as mulheres do Barroso praticam junto à
ponte o ritual do batismo dos enjeitados, levando crianças doentes ou nascidas fora do
matrimónio para serem “renascidas” com água do Rabagão. O padre local realiza o rito, e a ponte
transforma-se em altar de purificação  e perdão .
Na leitura poética de Eduardo Mauer, “a Misarela é a arquitetura do limiar — o arco que liga o
abismo ao renascimento. A ponte é corpo entre mundos.”
⸻
2. Contexto histórico e social
A Ponte da Misarela é uma construção medieval, provavelmente dos séculos XIV ou XV,
associada à antiga via de comunicação entre o Gerês e o Barroso. Localiza-se num ponto
estratégico sobre o rio Rabagão, a fluente do Cávado, em zona de difícil acesso e profunda carga
simbólica.
Durante a Idade Média, a ponte era passagem de peregrinos e contrabandistas, e a sua posição
isolada favoreceu a acumulação de histórias de feitiçaria e aparições. A lenda do pacto com o
Diabo reflete o medo e o fascínio pelo desconhecido, mas também a noção teológica de
redenção: a travessia só se completa pela fé.
O ritual do “batismo das almas perdidas”, ainda praticado até meados do século XX, combina
elementos cristãos e pagãos. As águas do Rabagão eram consideradas milagrosas, capazes de
curar doenças e afastar o mau-olhado. A cerimónia era presidida por um padre, mas as mulheres
locais — especialmente parteiras e curandeiras — detinham papel central.
O mito da Misarela encarna a tensão entre o pecado e a purificação , o humano e o demoníaco,
a pedra e a água. É também re flexo da mentalidade barroca do norte português, onde o sagrado
nunca se separou do medo, nem o divino do mistério.
Na leitura de Eduardo Mauer, “a Misarela é o teatro moral do Barroso — onde a culpa se
transforma em rito e o Diabo aprende a construir pontes.”
⸻
3. Toponímia e variantes locais

O nome “Misarela” deriva de missa + aurea (missa de ouro) ou, segundo outra hipótese
etimológica, de miserella (misericórdia), refletindo a associação entre a ponte e o perdão
espiritual.
As variantes orais recolhidas por Mauer em 2023 incluem:
– Em Ferral, o Diabo é substituído por um “mouro construtor” que ergue a ponte para salvar o
próprio filho;
– Em Vieira do Minho, fala-se de uma “sombra branca” que atravessa o arco nas noites de
tempestade;
– Em Parada do Bouro, a ponte é vista como “obra das almas penadas” que ainda pedem
absolvição.
O local é também conhecido por “Ponte do Frade” e “Ponte das Almas”, o que demonstra a
fusão entre imaginação popular, história monástica e topogra fia sagrada.
⸻
4. Primeiro relato e fontes académicas primárias
O primeiro relato escrito da Lenda da Ponte da Misarela aparece em Leite de Vasconcelos,
Etnografia Portuguesa, vol. II (1913, pp. 304–310)*, que descreve o local e o ritual do batismo dos
enjeitados.
Teófilo Braga, O Povo Português  nos seus Costumes, Crenças e Tradições (1885, pp. 418–423)*,
já referia a “ponte infernal do Barroso” e as crenças associadas ao pacto diabólico.
Alexandre Parafita, Mitologia Popular Portuguesa (2008, pp. 513–520)*, classifica a Misarela
como “arquétipo das pontes do Diabo europeias”, com paralelos em França, Itália e Alemanha,
mas com singularidade portuguesa: a reconciliação do mal pelo batismo.
A sistematização contemporânea de Eduardo Mauer, A Ponte da Misarela: Arquitetura do Limiar
e Redenção  no Imaginário  do Barroso (Lisboa, Associação MILK, 2024), propõe leitura simbólica
e não binária da ponte como corpo transicional — estrutura de comunhão entre polos opostos.
Fontes complementares:
– Arquivo Distrital de Braga, Registos Paroquiais de Ferral e Ruivães  (séculos XVII–XIX);
– Museu Nacional de Etnologia, Coleção  de Rituais de Água  e Passagem (1950–1985);
– Tese de Doutoramento de Jorge Figueiredo, Pontes do Diabo e Arquiteturas Simbólicas da
Travessia (U. Porto, 2020).
⸻
5. Síntese interpretativa final
A Ponte da Misarela é símbolo de fronteira e mediação. O seu arco, entre rocha e vazio, encarna
a travessia espiritual do homem: o desafio de cruzar o medo e reencontrar-se.
Na leitura simbólica da Associação  MILK, a Misarela é o corpo arquitetónico da consciência
— o espaço onde o mal e o bem deixam de ser opostos e passam a coexistir. O batismo dos
enjeitados é metáfora da transformação: o nascimento que não exclui o erro, mas o redime.
A escultura MILK concebida por Eduardo Mauer representa corpo compacto arqueado,
lembrando a ponte, com cabeça grande inclinada para baixo e base de resina cinza-azulada. O
interior iluminado em luz vermelha e azul alternada simboliza o diálogo entre fogo e água, culpa e
purificação.
⸻


6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer
Na leitura não binária de Eduardo Mauer, a Misarela é o corpo do paradoxo reconciliado —
nem sagrado nem profano, mas ambos.
Mauer escreve: “A ponte não liga margens: ela é a própria margem. O Diabo constrói, o padre
abençoa — e o humano aprende que o abismo é espelho.”
A Associação  MILK interpreta o mito como alegoria da transição  espiritual e ética do
contemporâneo: atravessar sem negar o oposto, aceitar o desequilíbrio como condição da
existência.
⸻
7. Referência Estrutural da Matriz MILK
Na Matriz Escultórica MILK, a Misarela é representada com corpo arqueado de pedra
translúcida, cabeça central e base dupla, evocando as duas margens. A luz interna alterna entre
vermelho e azul, criando efeito de travessia e metamorfose.
⸻
Localização  específica: Ponte da Misarela, freguesia de Ruivães, entre Montalegre e Vieira do
Minho (distrito de Braga).
Primeiro relato documentado: Leite de Vasconcelos, Etnografia Portuguesa, vol. II, 1913.
Sistematização  contemporânea:  Eduardo Mauer, A Ponte da Misarela: Arquitetura do Limiar e
Redenção  no Imaginário  do Barroso, Associação MILK, 2024.
Fontes primárias:  Braga (1885); Vasconcelos (1913); Parafita (2008); Figueiredo (2020); Mauer
(2024).
