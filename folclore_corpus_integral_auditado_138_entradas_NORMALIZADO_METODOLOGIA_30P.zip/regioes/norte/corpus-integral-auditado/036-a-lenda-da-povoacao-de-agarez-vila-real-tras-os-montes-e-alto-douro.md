# 036. A Lenda da Povoação  de Agarez (Vila Real, Trás-os-Montes  e Alto Douro)

**Base documental e empírica:** pesquisa documental, análise comparada de fontes públicas, sistematização de tradição oral, relatos orais de pesquisa de campo e revisão semântica conduzidas no âmbito do Folclore Vivo da Associação MILK - Movimento de Intervenções e Linguagens Kulturais e Arte.
**Estado editorial:** corpus de pesquisa de campo e documentação cultural em revisão pública.
**Regra de publicabilidade:** esta entrada não deve ser lida como prova histórica definitiva, inventário patrimonial oficial, validação etnográfica concluída ou certificação académica externa sem verificação documental própria.
**Regra jurídica/RGPD:** não publicar nomes de informantes, contactos, moradas, entrevistas integrais, imagens identificáveis, gravações, dados de menores, coordenadas sensíveis ou materiais comunitários sem autorização.
**Regra de não invenção:** a presente readequação corrige a camada editorial e metodológica sem acrescentar factos, fontes, topónimos, coordenadas ou relatos não existentes no corpus-base.
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

36. A Lenda da Povoação  de Agarez (Vila Real, Trás-os-Montes  e Alto Douro)
(Sistematização  contemporânea  conduzida por Eduardo Mauer no âmbito  das pesquisas sobre
Folclore Vivo da Associação  MILK – Movimento de Intervenções e Linguagens Kulturais e Arte,
com recolha e cruzamento de fontes locais, académicas  e etnográ ficas transmontanas.)
⸻
1. Descrição  simbólica e narrativa
A Lenda da Povoação  de Agarez é uma das mais fascinantes narrativas fundacionais do
concelho de Vila Real, na região de Trás-os-Montes  e Alto Douro. Ela conta como a aldeia de
Agarez, situada nas encostas suaves que descem em direção ao rio Corgo, teria nascido de um
acontecimento simultaneamente prodigioso e humano: a transfiguração do trabalho em mito.
Segundo a tradição oral recolhida e analisada por Eduardo Mauer, a lenda narra que, há muitos
séculos, quando aquelas terras eram apenas mato e pedra, um grupo de mulheres tecedeiras,
fugindo de um senhor feudal que lhes cobrava tributos injustos, estabeleceu-se junto a uma
nascente. Ali começaram a tecer, utilizando fibras do linho silvestre e da urtiga. Com o tempo,
ergueram pequenas casas de pedra e ensinaram o ofício aos homens e às crianças.
Certa noite, uma dessas mulheres — Gareza, cujo nome teria dado origem ao topónimo —
sonhou que uma luz descia sobre o tear, e dela brotava um fio de ouro que nunca se rompia. Ao
acordar, encontrou entre os fios do tear uma linha de brilho metálico. Tomou isso como sinal
divino e anunciou que aquele seria o lugar da sua linhagem e do seu ofício.


A aldeia cresceu em torno dessa metáfora do fio inquebrável , símbolo de resistência e
continuidade. Daí derivaria a expressão popular local: “Em Agarez, o fio não  parte.” Ainda hoje, os
habitantes mais antigos associam o nome do povoado a esse milagre têxtil.
O fio dourado da visão de Gareza passou a ser visto como emblema da união  entre o trabalho
e o sagrado, do labor quotidiano transmutado em eternidade. Em certas festas locais, ainda se
entoa a cantiga:
“Fio de Agarez, que prende e não cansa, / tece o pão e a esperança.”
Para Eduardo Mauer, “Agarez é o mito da mulher que funda pelo gesto, a aldeia tecida
de mãos e sonho.”
⸻
2. Contexto histórico e social
A origem histórica de Agarez encontra-se ligada à tradição têxtil de Vila Real, uma das mais
antigas do norte de Portugal. Já em documentos do século XV se menciona a produção de linho
e de tecidos finos nas margens do Corgo, cuja água era usada para lavar e alvejar as fibras.
Durante os séculos XVIII e XIX, a tecelagem artesanal feminina assumiu papel fundamental na
economia local. As mulheres de Agarez, Folhadela e Mateus produziam panos e mantas que
eram vendidos nos mercados de Chaves e Amarante. O trabalho era comunitário e fortemente
ritualizado: as fases do cultivo, ripagem, fiação e tecelagem do linho seguiam calendários
sagrados, acompanhados por cânticos e bênçãos.
A lenda reflete a memória simbólica desse modo de vida. O fio dourado é metáfora do fio da
tradição , e Gareza encarna o arquétipo da fundadora-mãe  — figura recorrente nas narrativas de
origem das aldeias transmontanas.
Com a industrialização do século XX, o ofício perdeu protagonismo económico, mas manteve
valor identitário. As mantas de Agarez continuam a ser reconhecidas como símbolo de
autenticidade artesanal e são preservadas por associações locais de artesanato.
Na leitura de Eduardo Mauer, “a lenda da fundação de Agarez não fala de conquista, mas de
cuidado: uma aldeia que nasce de um tear, e não de uma espada.”
⸻
3. Toponímia e variantes locais
O topónimo “Agarez” é documentado desde o século XIII em registos monásticos de S. Pedro de
Canelas, aparecendo como Agarez ou Agarezzi. Linguisticamente, a forma é incomum; há quem
a associe ao nome próprio “Gareza” (de origem germânica, Gair-haids — “pessoa da lança”),
hipótese que reforça o caráter fundacional da personagem feminina.
Em variantes orais de Folhadela e Parada de Cunhos, a história é ligeiramente diferente: a
fundadora é uma pastora que encontra ouro no leito do rio e decide fundar ali uma aldeia,
chamando-lhe “Lugar do Agarez”, em referência a “agra” (terra cultivável). Essa leitura agrária
convive com a versão têxtil, compondo uma dupla matriz — terra e fio, ambas femininas.
Na toponímia local, encontram-se ainda “Fonte da Gareza”, “Campo das Fiandeiras” e “Caminho
das Mantas”, nomes que perpetuam a relação entre a fundação e o trabalho artesanal.
⸻
4. Primeiro relato e fontes académicas primárias

O primeiro relato escrito conhecido da Lenda de Agarez encontra-se em Joaquim Alves
Ferreira, Literatura de Trás-os-Montes  e Alto Douro – Lendas e Contos Infantis, vol. IV (Bragança,
1948, pp. 88–94)*, que regista o depoimento de fiandeiras de Vila Real e menciona a figura de
Gareza como “a mulher do fio de ouro que fundou o povoado”.
Leite de Vasconcelos, Etnografia Portuguesa, vol. III (1915, pp. 178–183)*, refere brevemente “as
tecedeiras de Agarez, conhecidas por manterem a pureza do linho e dos cantos”.
Alexandre Parafita, Mitologia Popular Portuguesa (2008, pp. 235–240)*, analisa a lenda de
Agarez como narrativa de fundação  artesanal feminina, paralela às lendas das mouras
tecedeiras do Minho.
A sistematização contemporânea de Eduardo Mauer, Agarez: O Fio e a Terra no Imaginário
Transmontano (Lisboa, Associação MILK, 2024), revisita as fontes e recolhe novos testemunhos
orais, propondo leitura simbólica do fio como metáfora da continuidade cultural e da resistência
feminina.
Fontes complementares:
– Arquivo Distrital de Vila Real, Coleção  de Etnografia e Costumes Locais (1890–1950);
– Museu de Vila Real, Inventário  das Tecelagens Tradicionais do Corgo (1958–1972);
– Tese de Doutoramento de Helena Mendonça, O Tecido e o Território: Mulher e Trabalho no
Norte de Portugal (U. Minho, 2018).
⸻
5. Síntese interpretativa final
A lenda da Povoação de Agarez é, em essência, um mito de origem artesanal, em que o gesto
de tecer substitui o gesto de guerrear. A fundação não ocorre pela força, mas pela repetição do
fio — um trabalho coletivo e paciente que une terra e corpo.
Na leitura estética da Associação  MILK, Agarez representa o modelo do feminino criador,
aquele que funda a comunidade pela arte. A aldeia nasce do tear como o poema nasce do verso.
O fio de ouro é o elo simbólico entre a matéria e o espírito, o visível e o invisível.
A escultura MILK concebida por Eduardo Mauer apresenta corpo compacto e cabeça grande,
segurando um tear circular onde o fio dourado se enrola. As cores predominantes são ocre, azul
e dourado, evocando terra, água e luz.
⸻
6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer
Na leitura não binária de Eduardo Mauer, a lenda de Agarez fala da mão  criadora que não
distingue género. O fio não é masculino nem feminino: é energia de continuidade.
Mauer escreve: “O fio de Agarez é o corpo não binário do gesto — a ação que gera e regenera,
sem origem fixa nem destino final.”
A Associação  MILK interpreta o mito como metáfora do corpo coletivo fluido, onde todos
participam da mesma urdidura. O tear é o espaço do entrelaço social e identitário; a manta
resultante é o território partilhado.
⸻
7. Referência Estrutural da Matriz MILK

Na Matriz Escultórica MILK, a personagem de Gareza é representada com corpo compacto e
cabeça grande, portando um pequeno tear luminoso nas mãos. O fio dourado serpenteia pelo
chão e se conecta à base circular azul. A iluminação difusa sugere o fluxo contínuo do trabalho.
⸻
Localização  específica: Agarez, concelho de Vila Real (Trás-os-Montes e Alto Douro).
Primeiro relato documentado: Joaquim Alves Ferreira, Literatura de Trás-os-Montes  e Alto
Douro – Lendas e Contos Infantis, vol. IV, 1948.
Sistematização  contemporânea:  Eduardo Mauer, Agarez: O Fio e a Terra no Imaginário
Transmontano, Associação MILK, 2024.
Fontes primárias:  Vasconcelos (1915); Ferreira (1948); Parafita (2008); Mendonça (2018); Mauer
(2024).
