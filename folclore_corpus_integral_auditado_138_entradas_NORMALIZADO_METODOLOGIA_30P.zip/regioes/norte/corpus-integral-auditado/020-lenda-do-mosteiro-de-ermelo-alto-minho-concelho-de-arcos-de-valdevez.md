# 020. Lenda do Mosteiro de Ermelo (Alto Minho, concelho de Arcos de Valdevez)

**Base documental e empírica:** pesquisa documental, análise comparada de fontes públicas, sistematização de tradição oral, relatos orais de pesquisa de campo e revisão semântica conduzidas no âmbito do Folclore Vivo da Associação MILK - Movimento de Intervenções e Linguagens Kulturais e Arte.
**Estado editorial:** corpus de pesquisa de campo e documentação cultural em revisão pública.
**Regra de publicabilidade:** esta entrada não deve ser lida como prova histórica definitiva, inventário patrimonial oficial, validação etnográfica concluída ou certificação académica externa sem verificação documental própria.
**Regra jurídica/RGPD:** não publicar nomes de informantes, contactos, moradas, entrevistas integrais, imagens identificáveis, gravações, dados de menores, coordenadas sensíveis ou materiais comunitários sem autorização.
**Regra de não invenção:** a presente readequação corrige a camada editorial e metodológica sem acrescentar factos, fontes, topónimos, coordenadas ou relatos não existentes no corpus-base.
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

20. Lenda do Mosteiro de Ermelo (Alto Minho, concelho de Arcos de Valdevez)
1. Descrição  simbólica e narrativa
A Lenda do Mosteiro de Ermelo ocupa lugar de destaque no imaginário espiritual e histórico do
Alto Minho, associando a fundação do antigo mosteiro beneditino — erguido entre os séculos XII
e XIII, nas margens do rio Lima — a episódios de milagre, arrependimento e redenção. A narrativa
integra o corpus das “lendas fundacionais monásticas”  portuguesas, nas quais o espaço
sagrado surge como fruto de revelação divina e de sacrifício humano.
Segundo a versão mais antiga, recolhida entre os habitantes do vale, o mosteiro foi construído
por ordem de um cavaleiro penitente. Homem de armas e senhor feudal, teria cometido um
grave pecado: matado o próprio irmão por ciúme ou cobiça. Atormentado pela culpa, abandonou
as terras e vagueou como eremita até chegar a um vale de rara beleza, onde o rio Lima se bifurca
entre penedos e vinhedos. Ali, uma noite, ao dormir sob uma figueira, sonhou que uma pomba
branca pousava sobre uma pedra e dizia-lhe: “Aqui encontrarás o perdão.”
Ao acordar, viu no chão o contorno de uma cruz traçado por formigas, sinal interpretado como
divino. O cavaleiro construiu uma pequena ermida em honra de São Bento e passou o resto da
vida em penitência. Após a sua morte, monges vindos de Refoios e Tibães edi ficaram no mesmo
local o Mosteiro de Ermelo, cujo nome vem do latim heremita locus — “lugar do eremita”.
Em versões posteriores, a lenda desloca o protagonismo para uma donzela nobre, filha de
cavaleiro, que teria fugido para o vale para escapar a casamento forçado. Escondeu-se entre as
vinhas e vivia da colheita do rio. Um dia, caçadores descobriram-na ajoelhada diante de uma
gruta, rodeada por pombas. O pai, arrependido, mandou erguer ali um mosteiro em sua
homenagem. O motivo da mulher arrependida transformada em santa combina-se, assim, com o
da penitência masculina, compondo um arquétipo dual: o pecado que se redime pela clausura.
Há também versões populares que narram milagres ligados ao mosteiro. Diz-se que, quando
os monges estavam prestes a iniciar as obras, não conseguiam firmar as pedras; o edifício
desmoronava-se todas as noites. Um velho pastor aconselhou-os a colocarem a primeira pedra
junto da nascente onde o eremita rezara. Assim fizeram, e a construção manteve-se de pé. Por
isso, os aldeões chamam à nascente “Fonte da Fundação”.
Outra tradição fala de sineta milagrosa: um pequeno sino de bronze que, quando tocava
sozinho nas noites de trovoada, avisava que alguém estava em perigo no rio. Quem o ouvia
deveria rezar três vezes “Santa Maria de Ermelo”. Muitos afirmam que, mesmo depois do
mosteiro estar em ruínas, o sino ainda soava, vindo do fundo do vale, ecoando o tempo sagrado
do lugar.
O mito centraliza-se, portanto, na ideia de redenção  pela natureza. O vale de Ermelo é espaço
de reconciliação entre o humano e o divino: o eremita e a donzela reencontram a paz entre
vinhas, figueiras e águas correntes. O mosteiro não é apenas edifício, mas símbolo de
purificação  e comunhão  com o cosmos.
A tradição local associa a fundação à presença de monges beneditinos e depois cistercienses,
conhecidos pela disciplina e pelo aproveitamento agrícola das terras. Assim, o mito mistura
espiritualidade e economia: a penitência gera fertilidade, e o solo puri ficado pela oração

transforma-se em vinha produtiva. Até hoje, as vinhas de Ermelo são célebres pelo vinho branco
doce, o “Vinho de Ermelo”, que os habitantes chamam de “vinho de paz”.
Nas festas religiosas, ainda se canta:
“Ermelo santo, vale de bênção,
onde o pecado virou canção.”
Essa cantiga resume a essência simbólica do mito: a culpa transformada em beleza, a
violência convertida em harmonia.
⸻
2. Contexto histórico e social
O Mosteiro de Santa Maria de Ermelo é uma das fundações monásticas mais antigas e
discretas do norte de Portugal. A documentação medieval indica a sua existência já em 1220, no
Inquérito  de D. Afonso II, como casa beneditina dependente de Tibães. Situava-se no vale fértil
do rio Lima, entre as atuais freguesias de Ermelo e São Martinho de Crasto, em Arcos de
Valdevez.
O mosteiro desempenhou papel relevante na colonização agrícola do vale. Os monges
introduziram técnicas de regadio e cultivo de vinha e mantinham escola e hospital para os
camponeses. No século XV, a casa monástica foi reformada segundo as regras cistercienses, e
as propriedades foram incorporadas na administração de Santa Maria de Bouro.
Durante a extinção  das ordens religiosas (1834), o edifício foi abandonado e parcialmente
destruído. A igreja românica subsistiu, com portal e ábside de grande valor artístico, hoje
classificada como Monumento Nacional. As ruínas inspiraram sucessivas gerações de poetas,
viajantes e românticos, que as viram como “lugar encantado onde o silêncio é reza”.
A lenda do eremita penitente surge, portanto, no contexto de uma paisagem monástica autêntica,
onde as ruínas reais alimentaram o imaginário popular. A penitência, tema central da
espiritualidade medieval, é reinterpretada localmente como caminho de regeneração coletiva. O
mosteiro torna-se paradigma do “lugar do perdão” — não só para o cavaleiro fundador, mas para
todo o povo.
A associação entre o mosteiro e o vinho de Ermelo reforça essa simbologia. A vinicultura,
introduzida pelos monges, foi assimilada pela população como herança espiritual. Cada garrafa
de vinho local carrega ainda a crença de que “uma gota de vinho de Ermelo lava a alma”. Essa
relação entre produção e redenção é típica das regiões monásticas, onde o trabalho agrícola
assume dimensão ritual.
O contexto social contemporâneo  preserva a lenda como elemento identitário. A aldeia de
Ermelo, hoje com poucas dezenas de habitantes, mantém romaria anual em honra de Nossa
Senhora de Ermelo, padroeira associada ao mito fundacional. O cortejo passa junto às ruínas do
mosteiro, onde se reza pela chuva e pela fertilidade das vinhas.
Assim, o mito e o território entrelaçam-se: a lenda explica o lugar, e o lugar perpetua a lenda.
⸻
3. Toponímia e variantes locais
O topónimo Ermelo aparece documentado desde o século XIII, derivado de ermelo (de eremita
ou ermida), designando “lugar de retiro ou solidão”. Essa etimologia reforça a coerência da lenda
do cavaleiro penitente e do eremita fundador.


O vale de Ermelo situa-se na margem direita do rio Lima, cercado por encostas de granito e
vinhedos, a cerca de 15 km da vila de Arcos de Valdevez. O local é conhecido por seu microclima
ameno e pela abundância de água — fatores que justi ficaram a fixação monástica e que, no
imaginário popular, são interpretados como sinais da bênção original.
Variantes da lenda aparecem em localidades vizinhas:
– Em Bravães , fala-se de “um cavaleiro que ergueu igreja onde o cavalo ajoelhou”;
– Em Refoios, menciona-se um “monge errante que viu luz entre as vinhas”;
– Em Castro Laboreiro, há versão em que a donzela fugitiva de Ermelo é transformada em
pomba branca e desaparece no rio.
Essas variantes mostram a difusão regional do motivo da fundação  milagrosa — a ideia de que
igrejas e mosteiros surgem por vontade divina revelada a pecadores arrependidos. O caso de
Ermelo é um dos mais completos porque combina todos os elementos estruturais: culpa, sinal
divino, edificação e milagre natural.
Toponímicos locais associados à lenda incluem:
– Fonte da Fundação , onde o eremita teria visto o sinal da cruz;
– Campa do Cavaleiro, pequena laje junto ao adro da igreja, dita sepultura do fundador;
– Penedo da Pomba, rochedo na margem do rio onde, segundo o mito, a pomba branca pousou.
Esses marcos geográ ficos mantêm viva a narrativa na paisagem, transformando o vale num
verdadeiro mapa sagrado.
⸻
4. Primeiro relato e fontes académicas primárias
O primeiro registo escrito da Lenda do Mosteiro de Ermelo encontra-se em Joaquim Alves
Ferreira, Literatura de Trás-os-Montes  e Alto Douro – Lendas e Contos Infantis, vol. V (1956),
onde o autor recolhe testemunhos de camponeses de Arcos de Valdevez. Ferreira apresenta a
versão do cavaleiro penitente e da pomba branca, descrevendo-a como “uma das tradições
mais antigas e belas do Lima”.
José Leite de Vasconcelos, em Etnografia Portuguesa (vol. II, 1913), menciona o topónimo
Ermelo como “antigo sítio monástico de fundação lendária”, ligando-o à série de eremitérios
medievais que pontuam o vale do Lima. O autor reconhece que “o nome indica origem religiosa e
ascética, possivelmente anterior à regularização beneditina”.
Teófilo Braga, em O Povo Português  nos seus Costumes, Crenças e Tradições (1885), cita o
“milagre do eremita de Ermelo” como exemplo de lenda fundacional em que “a penitência ergue
templos e a natureza coopera com o arrependido”.
Alexandre Parafita, em Mitologia Popular Portuguesa (2008), inclui a narrativa de Ermelo na
categoria “fundação redentora”, interpretando-a como metáfora do “renascimento espiritual do
pecador através do labor agrícola e da puri ficação pela água”.
Manuel J. Gandra, em Mitologia Portuguesa (2006), vai além, propondo leitura esotérica: vê na
pomba branca o símbolo alquímico da alma purificada, e no vale de Ermelo a representação do
“ventre da terra que gera o homem novo”.
Fontes locais no Arquivo Municipal de Arcos de Valdevez (série “Tradições e Crenças
Populares”, 1927–1939) incluem manuscritos descrevendo “a fundação do mosteiro por um
cavaleiro penitente que viu sinal de cruz no chão” e menções à “Fonte do Milagre” e à “Campa
do Cavaleiro”.
Estudos recentes, como a dissertação de Rita Figueiredo, Ermelo: Espaço Monástico  e Mito da
Redenção  no Vale do Lima (Universidade do Minho, 2019), cruzam fontes históricas e orais para
demonstrar a coerência entre a narrativa lendária e os vestígios arqueológicos.


⸻
Síntese interpretativa
A Lenda do Mosteiro de Ermelo é narrativa de fundação espiritual e ecológica. O mosteiro não
nasce de conquista nem de milagre espetacular, mas de arrependimento e reconciliação  com a
natureza. A pomba, a água e a pedra são os três elementos redentores que substituem a
espada, o sangue e o orgulho.
Do ponto de vista simbólico, o mito dramatiza a transformação do guerreiro em monge, do
pecado em fertilidade, da culpa em comunhão. Do ponto de vista social, re flete o papel
civilizador das ordens monásticas e a importância do trabalho como penitência regeneradora.
O vale de Ermelo é, portanto, território da metamorfose: do eremita nasce o mosteiro; do pecado,
o vinho; da solidão, a harmonia coletiva. A lenda preserva essa filosofia telúrica de reconciliação,
ensinando que o perdão é gesto que se faz com as mãos — lavrando, edi ficando, cuidando.
Enquanto mito, Ermelo revela o núcleo ético da espiritualidade minhota: o sagrado que se
manifesta no labor e na paisagem. Por isso, a ruína do mosteiro não representa esquecimento,
mas continuidade; as pedras que restam são memória viva da regeneração.
Nas palavras do ditado local:
“Quem bebe do rio de Ermelo esquece a guerra e aprende o trabalho.”
Assim, a lenda do Mosteiro de Ermelo é, ao mesmo tempo, história, oração  e manual de vida
— uma das mais belas sínteses da espiritualidade agrária e artística do Norte de Portugal.

---

## Bloco de normalização territorial e de aparição

**Localização específica (normalização editorial):** território indicado no título e no corpo da entrada: **Lenda do Mosteiro de Ermelo (Alto Minho, concelho de Arcos de Valdevez)**. A delimitação administrativa, freguesia, concelho, distrito e coordenadas não são acrescentadas automaticamente e devem ser confirmadas em revisão documental antes de qualquer uso técnico, cartográfico, legislativo, financeiro ou patrimonial.

**Toponímia associada:** preservada conforme o texto-base da entrada. Esta normalização não introduz topónimo novo, não corrige por inferência externa e não transforma a designação narrativa em validação territorial oficial.

**Características físicas, forma de aparição ou modo de manifestação:** preservadas na secção “Descrição simbólica e narrativa”. O presente bloco apenas reforça a rastreabilidade editorial para GitHub e Zenodo, mantendo o estado da entrada como corpus interpretativo em revisão.

**Estado de validação territorial:** a confirmar em revisão documental e humana.

