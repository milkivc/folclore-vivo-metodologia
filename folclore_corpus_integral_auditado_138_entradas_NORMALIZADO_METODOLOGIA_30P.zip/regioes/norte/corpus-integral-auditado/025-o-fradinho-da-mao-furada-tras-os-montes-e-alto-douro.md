# 025. O Fradinho da Mão  Furada (Trás-os-Montes  e Alto Douro)

**Base documental e empírica:** pesquisa documental, análise comparada de fontes públicas, sistematização de tradição oral, relatos orais de pesquisa de campo e revisão semântica conduzidas no âmbito do Folclore Vivo da Associação MILK - Movimento de Intervenções e Linguagens Kulturais e Arte.
**Estado editorial:** corpus de pesquisa de campo e documentação cultural em revisão pública.
**Regra de publicabilidade:** esta entrada não deve ser lida como prova histórica definitiva, inventário patrimonial oficial, validação etnográfica concluída ou certificação académica externa sem verificação documental própria.
**Regra jurídica/RGPD:** não publicar nomes de informantes, contactos, moradas, entrevistas integrais, imagens identificáveis, gravações, dados de menores, coordenadas sensíveis ou materiais comunitários sem autorização.
**Regra de não invenção:** a presente readequação corrige a camada editorial e metodológica sem acrescentar factos, fontes, topónimos, coordenadas ou relatos não existentes no corpus-base.
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

25. O Fradinho da Mão  Furada (Trás-os-Montes  e Alto Douro)
(Sistematização  contemporânea  conduzida por Eduardo Mauer no âmbito  das pesquisas sobre
Folclore Vivo da Associação  MILK – Movimento de Intervenções e Linguagens Kulturais e Arte)
⸻
1. Descrição  simbólica e narrativa
O Fradinho da Mão  Furada é uma das figuras mais complexas e fascinantes do folclore
transmontano, oscilando entre a travessura e o sagrado, o riso e o medo. De acordo com a
tradição oral recolhida por Eduardo Mauer nas aldeias de Miranda do Douro, Mogadouro,
Vinhais e Bragança, trata-se de um pequeno frade encapuçado, de rosto pálido e sorriso
zombeteiro, que surge nas noites de vento, entrando nas casas sem pedir licença. É conhecido
por roubar pão, vinho e moedas, mas, paradoxalmente, também por conceder pequenos favores:
“cura uma dor, abre um armário trancado, ou faz o fogo acender-se de novo”.
O traço mais característico da criatura é a mão  direita atravessada por um buraco, visível
quando estende o braço para pedir esmola ou abençoar. A “mão furada” é o sinal do seu destino
— punição e milagre em simultâneo.


Conta-se que, em tempos, o Fradinho fora um verdadeiro monge franciscano que roubara
moedas do cofre do convento. Descoberto, foi amaldiçoado a vaguear eternamente até devolver
o último vintém roubado. Desde então, reaparece nas aldeias nas noites de lua minguante,
batendo às janelas e oferecendo “bênçãos pagas”.
Outras versões, recolhidas em Mogadouro, apresentam o Fradinho como espírito protetor dos
pobres, que castiga os avarentos e recompensa os generosos. Em Vinhais, diz-se que ele anda
montado num galo preto e que o buraco da mão deixa passar a luz das almas.
Para Eduardo Mauer, “o Fradinho da Mão Furada é a figura-ponte entre o santo e o bufão. É o
mediador entre o sagrado institucional e o sagrado popular — aquele que paga o preço do dom.”
⸻
2. Contexto histórico e social
O mito do Fradinho insere-se na tradição portuguesa das figuras monásticas  ambíguas, que
proliferaram a partir do século XVII, quando o prestígio das ordens religiosas começou a declinar
e a cultura popular reagiu com ironia à autoridade clerical.
Os “fradinhos”, “padrecos” e “monges zombeteiros” eram protagonistas de contos burlescos e
moralizantes, denunciando a hipocrisia e o apego ao ouro. O Fradinho da Mão Furada cristaliza
essa crítica, mas confere-lhe dimensão mística: o pecado e a penitência coexistem no mesmo
corpo.
Em Trás-os-Montes, onde a religiosidade popular sempre conviveu com práticas mágicas, o frade
diminuto tornou-se também espírito doméstico. Como os trasgos e duendes ibéricos, entra nas
casas para baralhar, mas não para destruir.
No século XIX, Teófilo Braga e Leite de Vasconcelos registaram versões dispersas em que o
Fradinho é confundido com o diabo travestido. Já no século XX, Alexandre Parafita reinterpreta-
o como símbolo da moral reversa: o ladrão que se converte em benfeitor.
Para Mauer, a longevidade do mito explica-se porque ele incorpora “a contradição central da
alma portuguesa — piedade e picardia, culpa e riso — num mesmo gesto”.
⸻
3. Toponímia e variantes locais
A lenda é predominante em Trás-os-Montes  e Alto Douro, mas há registos no Alto Minho e na
Beira Alta, com pequenas variações. Em Miranda do Douro, chama-se “Fradinho da Luz”,
porque a mão furada brilha; em Vinhais, “Frade da Esquina”, pois aparece sempre junto aos
caminhos; em Mogadouro, é “Padrezinho das Sombras”.
Algumas casas rurais ainda mantêm orifícios circulares nas portas — “buracos do Fradinho” —
por onde se dizia que ele entrava sem abrir. Há também topónimos como “Fonte do Fradinho” e
“Lomba do Frade”, que indicam fixação territorial do mito.
Nos concelhos de Bragança e Mogadouro, as festas de Todos os Santos incluíam o costume de
deixar um copo de vinho e um pedaço de pão na janela “para o frade das almas”, tradição ainda
viva em aldeias envelhecidas.
⸻
4. Primeiro relato e fontes académicas primárias

O primeiro registo literário do Fradinho da Mão  Furada aparece em Leite de Vasconcelos,
Etnografia Portuguesa, vol. II (1913, pp. 245–250)*, onde o autor descreve “um espírito
zombeteiro com hábito de frade, de pequena estatura, dotado de mão perfurada”.
Teófilo Braga, O Povo Português  nos seus Costumes, Crenças e Tradições (1883, pp. 334–337)*,
menciona a história de um frade amaldiçoado a servir eternamente as casas dos pobres,
“restituindo com milagres o que roubou com moedas”.
Alexandre Parafita, Mitologia Popular Portuguesa (2008, pp. 401–406)*, analisa a figura como
herdeira dos “trasgos” ibéricos e dos “frailes burladores” espanhóis, símbolos da crítica popular
ao poder religioso.
A sistematização contemporânea de Eduardo Mauer, O Fradinho da Mão  Furada: Entre o
Sagrado e o Cómico no Imaginário  Transmontano (Lisboa, Associação MILK, 2024), combina
recolhas orais e iconografia de ex-votos, abordando a figura como alegoria da redenção  pelo
riso.
Fontes complementares:
– Arquivo Distrital de Bragança, Registos de Lendas Populares do Nordeste Português  (1930–
1955);
– Museu do Abade de Baçal, Cadernos Etnográ ficos Transmontanos (1952–1968);
– Tese de Doutoramento de Marta Costa, O Riso e a Culpa no Folclore Português  (U. Coimbra,
2018).
⸻
5. Síntese interpretativa final
O Fradinho da Mão Furada é um santo profano, expressão do dualismo português entre moral e
ironia. Ele representa o poder de rir de si mesmo, transformando o pecado em parábola. O
buraco da mão é símbolo da falta que liberta: o vazio que permite a passagem da luz.
Na leitura estética da Associação  MILK, o Fradinho personifica o Folclore Vivo na sua vertente
carnavalesca — o espaço onde o erro se converte em arte. Ele é simultaneamente o mendigo e o
milagre, o que tira e o que devolve.
Na escultura MILK concebida por Eduardo Mauer, o Fradinho aparece em posição dinâmica,
com corpo compacto e cabeça grande. A túnica curta de cor castanha e o buraco na mão direita
são elementos centrais. Do orifício emana luz dourada.
⸻
6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer
Na leitura não binária de Eduardo Mauer, o Fradinho da Mão Furada é o corpo híbrido da
redenção , simultaneamente pecador e santo, masculino e feminino, humano e espírito. A sua
mão vazada é o portal do entre-ser — a ferida que une.
Mauer escreve: “O Fradinho é o corpo queer da fé. A mão aberta é vagina e estigma, vazio e
passagem.” A sua luz interior dissolve o binário entre culpa e perdão, transformando a punição
em transfiguração.
A Associação  MILK lê a figura como manifesto pós-religioso da compaixão : a santidade nas
margens, o milagre risível, o corpo que redime sem hierarquia.
⸻


7. Referência Estrutural da Matriz MILK
Na Matriz Escultórica MILK, o Fradinho da Mão Furada apresenta-se de pé, hábito castanho-
avermelhado, cabeça grande e rosto sereno. A mão direita, perfurada, contém luz interna que se
projeta sobre o chão.
As cores predominantes são castanho-terroso, dourado e bege. A instalação pode incluir som de
sineta distante e respiração leve, evocando presença silenciosa.
⸻
Localização  específica: Miranda do Douro, Mogadouro, Vinhais e Bragança, Trás-os-Montes e
Alto Douro.
Primeiro relato documentado: Leite de Vasconcelos, Etnografia Portuguesa, vol. II, 1913.
Sistematização  contemporânea:  Eduardo Mauer, O Fradinho da Mão  Furada: Entre o Sagrado e
o Cómico no Imaginário  Transmontano, Associação MILK, 2024.
Fontes primárias:  Braga (1883); Vasconcelos (1913); Parafita (2008); Costa (2018); Mauer (2024).
