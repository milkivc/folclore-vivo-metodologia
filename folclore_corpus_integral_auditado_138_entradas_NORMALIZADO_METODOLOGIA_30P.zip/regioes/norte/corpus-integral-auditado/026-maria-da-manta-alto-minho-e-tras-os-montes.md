# 026. Maria da Manta (Alto Minho e Trás-os-Montes)

**Base documental e empírica:** pesquisa documental, análise comparada de fontes públicas, sistematização de tradição oral, relatos orais de pesquisa de campo e revisão semântica conduzidas no âmbito do Folclore Vivo da Associação MILK - Movimento de Intervenções e Linguagens Kulturais e Arte.
**Estado editorial:** corpus de pesquisa de campo e documentação cultural em revisão pública.
**Regra de publicabilidade:** esta entrada não deve ser lida como prova histórica definitiva, inventário patrimonial oficial, validação etnográfica concluída ou certificação académica externa sem verificação documental própria.
**Regra jurídica/RGPD:** não publicar nomes de informantes, contactos, moradas, entrevistas integrais, imagens identificáveis, gravações, dados de menores, coordenadas sensíveis ou materiais comunitários sem autorização.
**Regra de não invenção:** a presente readequação corrige a camada editorial e metodológica sem acrescentar factos, fontes, topónimos, coordenadas ou relatos não existentes no corpus-base.
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

26. Maria da Manta (Alto Minho e Trás-os-Montes)
(Sistematização  contemporânea  conduzida por Eduardo Mauer no âmbito  das pesquisas sobre
Folclore Vivo da Associação  MILK – Movimento de Intervenções e Linguagens Kulturais e Arte)
⸻
1. Descrição  simbólica e narrativa
A Maria da Manta é uma das entidades mais obscuras e temidas do folclore do Norte de
Portugal. As tradições orais descrevem-na como uma mulher alta, envolta num manto negro que
lhe cobre o rosto e o corpo até os pés, surgindo junto a rios, poços e neblinas ao entardecer. O
seu olhar é descrito como fogo vivo, e as mãos, quando visíveis, lembram garras longas de cor
azulada. É tida como uma figura de advertência e castigo — a personi ficação do medo moral,
sobretudo das crianças e dos viajantes noturnos.
Os mais antigos relatos de Viana do Castelo, Melgaço e Bragança dizem que Maria da Manta
aparece nas noites em que “o vento corta o vale” ou quando “o nevoeiro desce sobre o rio”. Diz-
se que chama os transeuntes com voz doce e longínqua, oferecendo abrigo sob o seu manto.
Quem aceita o convite desaparece — “sumido para o fundo do rio”, como repetem as versões
orais.
Outras narrativas, menos punitivas, descrevem-na como guardiã da água, protetora das mulheres
violentadas e das crianças órfãs. Nesse caso, o seu manto é refúgio e não armadilha. Ela recolhe
as almas perdidas e as leva “para o outro lado do nevoeiro”.
A dualidade da figura — protetora e destruidora — é uma das marcas que mais fascinam os
investigadores. Segundo Eduardo Mauer, “Maria da Manta é o corpo ambíguo do feminino: o
ventre que abriga e o abismo que engole.”
O nome “Maria”, comum nas lendas portuguesas, associa a figura à dimensão popular do
sagrado; já “Manta” sugere tanto o pano que cobre quanto o gesto de envolver. Assim, o próprio
nome contém a tensão central da lenda: esconder ou proteger, disfarçar ou abrigar.
⸻
2. Contexto histórico e social
A lenda da Maria da Manta surge associada às margens do rio Lima e do rio Minho, estendendo-
se às serras de Trás-os-Montes, onde se cruzam antigas crenças aquáticas e femininas. O

contexto histórico remonta provavelmente à Idade Média, quando proliferavam as narrativas de
mulheres-feiticeiras ligadas à água e ao luar.
A tradição oral do Alto Minho descreve-a como “a sombra que vem da água” e relaciona a sua
aparição com mortes por afogamento, especialmente de crianças. Há registros de que, até o
início do século XX, mães e avós invocavam a Maria da Manta para amedrontar as crianças que
se aproximavam dos poços — “Sai daí, que a Maria da Manta te leva!”.
Mas, como demonstra Eduardo Mauer nas suas recolhas contemporâneas, por trás do aviso
punitivo existe também um substrato simbólico de proteção materna e ecológica. A figura serve
como metáfora da fronteira entre o humano e o natural — o ponto em que a água deixa de ser
utilidade e se torna mistério.
O mito, portanto, cumpre uma dupla função social: disciplinar e pedagógica, mas também ritual e
espiritual. Representa o respeito pela natureza e pelos limites da curiosidade humana.
Historicamente, a lenda reflete as relações de gênero e poder no mundo rural. Ao ser construída
como corpo perigoso, Maria da Manta encarna o medo da autonomia feminina e a repressão das
vozes femininas livres. É a mulher que age fora das regras, que caminha sozinha à noite, que
detém o poder da escolha — e, por isso, é transformada em monstro.
⸻
3. Toponímia e variantes locais
O mito é amplamente difundido no Alto Minho (Viana do Castelo, Ponte de Lima, Melgaço,
Monção) e em regiões de Trás-os-Montes  (Vinhais, Bragança, Mogadouro). Há registos também
no Douro Litoral, em aldeias de Amarante e Baião , sempre relacionados com cursos d’água e
vales de neblina.
Em Ponte de Lima, fala-se na “Maria da Manta do Rio Trovela”, que aparece nas noites de
trovoada; em Melgaço, a “Maria do Luar”, descrita como mulher de olhos brancos que protege
pescadores; e em Vinhais, a “Moura da Manta”, figura mais ligada ao encantamento e ao ouro
escondido.
Topónimos como “Poço da Manta”, “Vale das Mantas” e “Fonte da Maria” são encontrados em
diversas freguesias do Norte, indiciando persistência do mito na memória toponímica.
Há ainda tradições locais associadas à queima da manta — ritual de puri ficação realizado em
certas aldeias do Minho na noite de São João, em que se queimavam panos velhos junto a rios,
como forma de afastar maus espíritos.
⸻
4. Primeiro relato e fontes académicas primárias
O primeiro relato escrito sobre a Maria da Manta surge em Nuno Matos Valente, Bestiário
Tradicional Português  (Lisboa, 2017, pp. 58–63)*, que compila e analisa variantes orais do Minho
e de Trás-os-Montes. O autor descreve-a como “ figura noturna que vagueia entre o medo e a
piedade, símbolo do desconhecido feminino da água”.
Fontes mais antigas, como Leite de Vasconcelos, Etnografia Portuguesa, vol. III (1915, pp. 190–
194)*, mencionam “mulheres das águas” e “fantasmas de mantas” sem nome próprio,
associando-as a mouras encantadas.
Alexandre Parafita, Mitologia Popular Portuguesa (2008, pp. 210–215)*, identifica a Maria da
Manta como sobrevivência dos mitos das ninfas aquáticas e das mouras mouriscas — arquétipos
do feminino sedutor e proibido.


A sistematização contemporânea de Eduardo Mauer, Maria da Manta: Feminino, Água  e Medo
no Imaginário  do Norte Português  (Lisboa, Associação MILK, 2024), reúne fontes etnográ ficas,
entrevistas, fotografias de campo e análise simbólica comparada com mitos aquáticos da Europa
Atlântica.
Fontes complementares:
– Arquivo Distrital de Viana do Castelo, Cadernos de Tradições do Minho, 1930–1960;
– Museu da Terra de Miranda, Registos Orais de Trás-os-Montes , 1950–1975;
– Tese de Doutoramento de Joana Lobo, Mulheres da Água:  Género  e Paisagem no Folclore
Português  (U. Lisboa, 2019).
⸻
5. Síntese interpretativa final
A Maria da Manta é uma das expressões mais densas do feminino aquático português.
Representa a tensão entre o acolher e o destruir, o consolo e o castigo, o eros e o thanatos. É a
Senhora das Águas escuras, herdeira das mouras encantadas e das ninfas pré-cristãs, mas
transfigurada pela moral popular.
Na leitura da Associação  MILK, Maria da Manta simboliza a pedagogia do medo como forma de
preservação do mistério. Ao criar uma figura que amedronta, o povo protege o sagrado.
A escultura MILK concebida por Eduardo Mauer apresenta uma figura compacta, de cabeça
grande e corpo coberto por uma manta fluida em tons de preto e azul petróleo. A base espelhada
evoca a superfície da água. Uma luz interna vermelha simboliza o coração escondido sob o
manto.
⸻
6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer
Na leitura não binária de Eduardo Mauer, Maria da Manta é a entidade fluida por excelência. O
seu corpo encoberto dissolve os limites do género e do rosto. É um ser sem forma fixa — ora
mulher, ora neblina, ora sombra.
Mauer escreve: “A Manta é o véu da indeterminação. O corpo sob o pano é a metáfora do devir,
do que não precisa ser nomeado.”
A Associação  MILK interpreta o mito como oportunidade de reflexão sobre visibilidade e
invisibilidade. O manto não esconde — protege o direito de ser ambíguo. Maria da Manta, na
leitura contemporânea, é o ícone queer do anonimato poético: o corpo que escolhe não ser lido.
⸻
7. Referência Estrutural da Matriz MILK
Na Matriz Escultórica MILK, Maria da Manta é modelada com base oval espelhada e corpo
compacto coberto por manto ondulante. A cabeça grande e lisa, sem feições definidas,
representa o anonimato. As cores predominantes são preto, azul profundo e cinza metálico.
A instalação pode incluir iluminação vermelha interna e som ambiente de água em movimento e
murmúrios indistintos.
⸻
Localização  específica: Alto Minho (Viana do Castelo, Melgaço, Ponte de Lima) e Trás-os-
Montes (Bragança, Vinhais, Mogadouro).


Primeiro relato documentado: Nuno Matos Valente, Bestiário  Tradicional Português , 2017.
Sistematização  contemporânea:  Eduardo Mauer, Maria da Manta: Feminino, Água  e Medo no
Imaginário  do Norte Português , Associação MILK, 2024.
Fontes primárias:  Vasconcelos (1915); Parafita (2008); Valente (2017); Lobo (2019); Mauer (2024).
