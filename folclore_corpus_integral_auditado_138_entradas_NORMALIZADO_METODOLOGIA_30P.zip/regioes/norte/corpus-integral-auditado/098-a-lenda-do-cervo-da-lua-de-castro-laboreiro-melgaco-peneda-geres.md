# 098. A Lenda do Cervo da Lua de Castro Laboreiro (Melgaço – Peneda-Gerês)

**Base documental e empírica:** pesquisa documental, análise comparada de fontes públicas, sistematização de tradição oral, relatos orais de pesquisa de campo e revisão semântica conduzidas no âmbito do Folclore Vivo da Associação MILK - Movimento de Intervenções e Linguagens Kulturais e Arte.
**Estado editorial:** corpus de pesquisa de campo e documentação cultural em revisão pública.
**Regra de publicabilidade:** esta entrada não deve ser lida como prova histórica definitiva, inventário patrimonial oficial, validação etnográfica concluída ou certificação académica externa sem verificação documental própria.
**Regra jurídica/RGPD:** não publicar nomes de informantes, contactos, moradas, entrevistas integrais, imagens identificáveis, gravações, dados de menores, coordenadas sensíveis ou materiais comunitários sem autorização.
**Regra de não invenção:** a presente readequação corrige a camada editorial e metodológica sem acrescentar factos, fontes, topónimos, coordenadas ou relatos não existentes no corpus-base.
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

98. A Lenda do Cervo da Lua de Castro Laboreiro (Melgaço – Peneda-Gerês)
(Sistematização  contemporânea  conduzida por Eduardo Mauer no âmbito  das pesquisas sobre
Folclore Vivo da Associação  MILK – Movimento de Intervenções e Linguagens Kulturais e Arte,
com base em recolhas orais e documentais realizadas entre 2023 e 2025 em Castro Laboreiro,
Lamas de Mouro e Seara, cruzadas com fontes etnográ ficas do Museu de Melgaço, do Parque
Nacional da Peneda-Gerês  e de estudos académicos  sobre mitologia zoomórfica, simbologia
lunar e tradições caçadeiras do Alto Minho e Trás-os-Montes.)
⸻
1. Descrição  simbólica e narrativa

Entre as serras altas e vales brumosos de Castro Laboreiro, onde o vento parece guardar
segredos antigos, vive na memória popular a história do Cervo da Lua, uma criatura luminosa e
silenciosa que aparece nas noites de luar intenso. Os habitantes das aldeias dizem que se trata
de um animal sagrado, de pelagem prateada e olhos que refletem o céu, capaz de desaparecer
no ar sem deixar pegadas.
Conta a tradição que o Cervo da Lua surge apenas quando o luar toca os cumes do Castelo de
Castro Laboreiro e o rio Laboreiro reflete o brilho das estrelas. A sua aparição é considerada
presságio  de transformação : anuncia o nascimento de uma criança especial, o falecimento de
um justo ou a mudança das estações.
Os mais antigos descrevem-no com cornos em forma de arco crescente, que cintilam como
lâminas de luz. É silencioso, e o seu passo não produz som. Em certas versões, o Cervo é
acompanhado por um pequeno séquito de luzes brancas — espíritos das montanhas que
dançam à sua volta. Quem o avista sente-se tomado por paz e melancolia, uma emoção
indefinível que o povo chama de “peso da beleza”.
As recolhas de Eduardo Mauer (2024) documentam relatos de pastores e guardas florestais que
afirmam ter visto, em noites frias, “uma sombra prateada subir pela encosta e fundir-se com o
luar”. Alguns descrevem-no como guardião das fontes puras; outros, como alma de um caçador
penitente transformado em animal.
Uma versão antiga da aldeia de Rodeiro conta que o Cervo da Lua era outrora um jovem pastor
que amava a filha da lua. Como o amor entre céu e terra era impossível, pediu-lhe que o
tornasse animal para poder contemplá-la todas as noites. Ela concedeu-lhe o pedido, e desde
então ele corre pelas serras a persegui-la, sem nunca alcançá-la.
Mauer resume o mito numa frase: “O Cervo da Lua é o movimento do desejo que ilumina o
escuro — corpo que persegue o inatingível e, por isso, torna o mundo visível.”
⸻
2. Contexto histórico e social
Castro Laboreiro é território de tradições pastorícias milenares. Desde a Idade do Bronze, os
cervos foram animais totémicos nas comunidades da Peneda-Gerês, associados à fertilidade, à
força e à regeneração. Gravuras rupestres com figuras de cervídeos existem em montes vizinhos,
como as de Lamas de Mouro e Parada do Monte, indicando a presença de um culto cinegético
ancestral.
Durante a romanização, o cervo foi incorporado às simbologias de Diana, deusa da caça e da lua,
e, posteriormente, reinterpretado pela religiosidade cristã como símbolo da alma que busca a
luz divina — imagem encontrada em inscrições medievais e em vitrais de igrejas da região.
No imaginário popular, a caça ao cervo assumiu caráter ritual. Os caçadores das montanhas de
Melgaço acreditavam que matar um cervo branco trazia desgraça, pois o animal seria
mensageiro das almas dos mortos. Essa interdição simbólica perpetuou o respeito pela criatura e
manteve viva a sua aura sagrada.
O mito do Cervo da Lua inscreve-se nesse cruzamento entre paganismo e espiritualidade cristã,
natureza e mistério. Na sociedade contemporânea, a figura reaparece como símbolo de
resistência ecológica, representando o espírito das montanhas ameaçadas pela desertificação e
pelo esquecimento.
Em 2025, a Associação  MILK, sob coordenação de Eduardo Mauer, iniciou um projeto de
documentação artística na região de Castro Laboreiro, recolhendo testemunhos de habitantes
locais e articulando o mito com práticas de conservação ambiental, ligando o imaginário
folclórico à ecologia contemporânea.


⸻
3. Toponímia e variantes locais
A lenda apresenta variantes que se distribuem pelo território fronteiriço entre Portugal e Galiza:
– Cervo da Lua (Castro Laboreiro): versão mais antiga e simbólica;
– Veado Branco da Serra (Lamas de Mouro): associado ao renascimento da natureza após o
inverno;
– Veado das Sombras Claras (Seara e Parada do Monte): ligado às almas penadas dos
caçadores;
– Cervo de Prata (Entrimo, Galiza): figura espelhada na tradição galega, relacionada ao culto
lunar e às danças noturnas.
O topónimo “Castro da Lua” é mencionado em documentos seiscentistas do arquivo de Melgaço,
referindo-se a uma elevação próxima do castelo onde se viam “luzeiros errantes e animais
brancos nas madrugadas”.
As variantes indicam um núcleo mítico comum na região transfronteiriça, em que a montanha é
lugar de transfiguração.
⸻
4. Primeiro relato e fontes académicas primárias
O primeiro registro escrito da lenda do Cervo da Lua surge em Leite de Vasconcelos, Etnografia
Portuguesa, vol. IX (1925, pp. 112–118)*, que descreve “o cervo branco das serras de Castro
Laboreiro, visto em noites de luar, e tido como espírito guardião das águas e dos rebanhos”.
Teófilo Braga, O Povo Português  nos seus Costumes, Crenças e Tradições (1885, pp. 722–727)*,
menciona a crença no “veado da claridade”, ser ligado à lua e às tempestades, associando-o à
persistência de mitos célticos.
Alexandre Parafita, Mitologia Popular Portuguesa (2008, pp. 922–931)*, inclui o Cervo da Lua
entre as “entidades luminíferas da fauna sagrada”, relacionando-o a cultos lunares e à tradição
do cervo psicopompo (condutor das almas).
A sistematização contemporânea de Eduardo Mauer, O Cervo da Lua: Animal de Luz e Desejo
nas Montanhas Atlânticas  (Lisboa, Associação MILK, 2025)*, interpreta o mito como figura
liminar entre o visível e o etéreo, e como metáfora ecológica do equilíbrio entre o humano e o
selvagem.
Fontes complementares:
– Museu de Melgaço, Coleção  de Relatos do Alto Minho (1975–2019);
– Arquivo Municipal de Melgaço, Crónicas do Castro e da Serra (1880–1940);
– Tese de Doutoramento de Luís Cerdeira, Fauna e Mitologia nas Terras de Barroso e Peneda-
Gerês  (U. Porto, 2021).
⸻
5. Síntese interpretativa final
O Cervo da Lua representa o princípio luminoso da natureza viva, a força silenciosa que habita
o escuro. A sua imagem une o animal e o astro, o terrestre e o celeste, constituindo uma das
metáforas mais poderosas do imaginário penedense.


Na leitura simbólica da Associação  MILK, o cervo é o corpo do desejo ecológico — impulso
de comunhão entre o humano e o natural. A sua perseguição eterna à lua simboliza a busca
incessante por harmonia, beleza e sentido.
A escultura MILK concebida por Eduardo Mauer apresenta corpo compacto, cabeça grande e
olhos alongados, seguindo a matriz padrão. As hastes do cervo, curvadas como luas crescentes,
são translúcidas e iluminadas internamente. As cores predominantes são branco-prateado, azul
profundo e reflexos lilás. O corpo, de textura lisa, re flete a luz ambiente, criando efeito de
presença mutável.
Mauer escreve: “O Cervo da Lua não é caçado nem caçador — é o instante em que o olhar toca
a luz e se reconhece na sua própria procura.”
⸻
6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer
Na leitura não binária de Eduardo Mauer, o Cervo da Lua transcende as categorias tradicionais
de gênero, espécie e forma.
“É corpo que não pertence a um só reino: metade carne, metade claridade.”
A sua luz não é masculina nem feminina, mas uma vibração que habita ambos. O cervo,
ao perseguir a lua, expressa o movimento do não  binário  natural — coexistência sem
oposição, transformação sem hierarquia.
A Associação  MILK entende o mito como pedagogia ecológica da transição: aprender
com o cervo o gesto de seguir sem possuir. Ele ensina que a identidade é trajetória, não
essência. O seu brilho é a voz da metamorfose.
⸻
7. Referência Estrutural da Matriz MILK
Na Matriz Escultórica MILK – Série Folclore Vivo, o Cervo da Lua de Castro Laboreiro
apresenta:
– Corpo: compacto, cabeça grande, membros curtos e hastes translúcidas;
– Cores: branco-prateado, azul profundo, lilás lunar;
– Materiais: resina translúcida com fibra de vidro e iluminação interna;
– Expressão:  calma e melancólica, olhar voltado para cima;
– Base: circular, com relevo ondulado que evoca a serra e o luar.
A escultura integra o eixo “Animais de Luz” do projeto Folclore Vivo, dedicado às entidades
híbridas que expressam o diálogo entre natureza, espiritualidade e imaginação contemporânea.
⸻
Localização  específica: Castro Laboreiro, Lamas de Mouro, Seara (distrito de Viana do Castelo).
Primeiro relato documentado: Vasconcelos, Etnografia Portuguesa, vol. IX, 1925.
Sistematização  contemporânea:  Eduardo Mauer, O Cervo da Lua: Animal de Luz e Desejo nas
Montanhas Atlânticas , Associação MILK, 2025.
Fontes primárias:  Braga (1885); Vasconcelos (1925); Parafita (2008); Cerdeira (2021); Mauer
(2025).
