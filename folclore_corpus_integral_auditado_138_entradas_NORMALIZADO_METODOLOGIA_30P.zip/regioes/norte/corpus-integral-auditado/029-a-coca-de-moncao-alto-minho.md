# 029. A Coca de Monção  (Alto Minho)

**Base documental e empírica:** pesquisa documental, análise comparada de fontes públicas, sistematização de tradição oral, relatos orais de pesquisa de campo e revisão semântica conduzidas no âmbito do Folclore Vivo da Associação MILK - Movimento de Intervenções e Linguagens Kulturais e Arte.
**Estado editorial:** corpus de pesquisa de campo e documentação cultural em revisão pública.
**Regra de publicabilidade:** esta entrada não deve ser lida como prova histórica definitiva, inventário patrimonial oficial, validação etnográfica concluída ou certificação académica externa sem verificação documental própria.
**Regra jurídica/RGPD:** não publicar nomes de informantes, contactos, moradas, entrevistas integrais, imagens identificáveis, gravações, dados de menores, coordenadas sensíveis ou materiais comunitários sem autorização.
**Regra de não invenção:** a presente readequação corrige a camada editorial e metodológica sem acrescentar factos, fontes, topónimos, coordenadas ou relatos não existentes no corpus-base.
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

29. A Coca de Monção  (Alto Minho)

(Sistematização  contemporânea  conduzida por Eduardo Mauer no âmbito  das pesquisas sobre
Folclore Vivo da Associação  MILK – Movimento de Intervenções e Linguagens Kulturais e Arte)
⸻
1. Descrição  simbólica e narrativa
A Coca de Monção  é uma das mais antigas e emblemáticas entidades mítico-rituais do Norte de
Portugal. Simultaneamente monstro, alegoria e personagem festiva, a Coca é descrita como um
dragão  ou serpente alada de corpo escamoso e boca flamejante, que enfrenta São Jorge na
Festa do Corpo de Deus, realizada anualmente na vila minhota de Monção desde pelo menos o
século XVI. A sua presença, contudo, transcende o contexto religioso, assumindo a função
simbólica de guardião  da fertilidade e da renovação  cíclica.
Nos relatos orais recolhidos por Eduardo Mauer e nas fontes históricas preservadas no Arquivo
Municipal de Monção , a Coca é vista como criatura de força telúrica, associada às águas do rio
Minho e aos campos férteis que o circundam. Diz-se que vive sob as pontes ou nas grutas do
vale e que, uma vez por ano, emerge para desafiar o santo guerreiro. A luta entre ambos
simboliza o confronto entre o caos e a ordem, o instinto e a razão, a natureza e a fé.
Nas versões populares, a Coca é uma fêmea — “a serpente-mãe”, “a dragona” —, o que
aproxima o mito português de tradições matriarcais antigas. O seu rugido, dizem, “mexe com o
ventre das mulheres” e “faz o milho crescer mais alto”. Mesmo quando derrotada, a Coca nunca
morre: apenas se recolhe às águas, à espera de um novo ciclo.
A dualidade entre São Jorge e a Coca não é de destruição, mas de equilíbrio dinâmico . O
cavaleiro representa a luz disciplinadora; a Coca, a força primordial. Em Monção, o combate é
encenado como dança: a luta ritual transforma-se em coreografia, e o monstro torna-se parceiro.
Na leitura simbólica de Eduardo Mauer, “a Coca é o útero cósmico do Minho — o ventre que
sangra, se ergue e floresce. Ela encarna o poder cíclico do feminino reprimido que retorna sob
forma de espetáculo”.
⸻
2. Contexto histórico e social
A origem do mito remonta às antigas celebrações agrícolas pré-cristãs , onde dragões e
serpentes representavam o ciclo das estações e a fecundidade da terra. No processo de
cristianização da Península Ibérica, essas entidades foram reinterpretadas à luz das hagiogra fias
— particularmente a de São Jorge —, convertendo-se em símbolos do mal vencido pela fé.
Em Monção, no entanto, o sincretismo assumiu caráter peculiar. Desde o século XVI,
documentos e crónicas descrevem a “dança da Coca” como parte essencial das procissões do
Corpo de Deus, festa de caráter tanto religioso quanto comunitário. O povo assistia ao duelo
entre São Jorge (representado por um cavaleiro) e a Coca ( figura articulada e colorida), que, ao
final, era simbolicamente derrotada, mas sempre renascia no ano seguinte.
Durante os séculos XVIII e XIX, a representação consolidou-se como parte da identidade
monçanense. A Coca passou a desfilar pelas ruas acompanhada de grupos de bombos e gaitas-
de-foles, atraindo multidões. O monstro, outrora símbolo do mal, transformou-se em ícone de
celebração  popular e pertença coletiva.
O contexto social da festa reforça o caráter integrador da lenda. A participação comunitária — de
crianças, músicos, artesãos e cavaleiros — faz da Coca um rito de coesão  intergeracional, no
qual o medo e a alegria se fundem.


Para Eduardo Mauer, a permanência da Coca demonstra “a capacidade do folclore minhoto de
absorver e transmutar o sagrado: o dragão pagão converte-se em corpo cívico, em dança, em
riso”.
⸻
3. Toponímia e variantes locais
A Coca é especí fica de Monção , mas variantes do mesmo mito encontram-se noutras regiões do
Minho e da Galiza, confirmando a sua origem partilhada. Em Valença e Melgaço, há referências
à “Coca do Rio” e à “Bicha-Serpente”; na Galiza, o Coco e a Coca de Redondela desempenham
funções semelhantes nas festas de Corpus Christi.
O nome “Coca” provém do latim caucus (oco, côncavo) e do galego-português coco, termo que
designava espectros e máscaras. O vocábulo deu origem ao “papão” infantil — “o bicho-papão”
—, derivando assim da mesma raiz simbólica: o ser que amedronta para educar.
Topónimos como “Penedo da Coca”, “Poço da Serpe” e “Lagoa da Mãe das Águas” são comuns
nas margens do Minho, atestando o enraizamento do mito na paisagem. Em muitos desses
lugares, ainda hoje se deixam flores e velas em honra da “Senhora das Águas”, reminiscência
pagã incorporada à devoção mariana.
⸻
4. Primeiro relato e fontes académicas primárias
O primeiro relato documentado da Coca de Monção  aparece no manuscrito Crónica das Festas
do Corpo de Deus de Monção , de Baltazar da Fonseca (1595), conservado no Arquivo
Municipal de Monção , que descreve o “monstro em figura de cobra com asas e fogo na boca”
que “peleja com o cavaleiro Jorge, e ao fim é vencido com muito alvoroço do povo”.
Teófilo Braga, O Povo Português  nos seus Costumes, Crenças e Tradições (1883, pp. 321–326)*,
retoma a referência, identi ficando a festa como sobrevivência de antigos cultos agrários de
fecundidade.
Leite de Vasconcelos, Etnografia Portuguesa, vol. IV (1915, pp. 255–260)*, classifica a Coca
como exemplo de “dracomaquia ritual” — combate simbólico entre santo e serpente — e
sublinha o papel das mulheres na ornamentação e nos cânticos da procissão.
Alexandre Parafita, Mitologia Popular Portuguesa (2008, pp. 300–307)*, reinterpreta a Coca
como “mito de reconciliação cíclica entre o fogo e a água”.
A sistematização contemporânea de Eduardo Mauer, A Coca de Monção:  Corpo, Festa e
Ressurgimento do Mito no Minho (Lisboa, Associação MILK, 2024), reexamina as fontes, integra
registos visuais e sonoros, e propõe leitura estética e política da Coca como dispositivo
comunitário  de resistência cultural.
Fontes complementares:
– Arquivo Municipal de Monção, Crónicas das Festas do Corpo de Deus, 1595–1890;
– Museu de Etnografia de Viana do Castelo, Cadernos do Minho, 1950–1980;
– Tese de Doutoramento de Rita Leite, Dragões e Devoções: As Cocas do Noroeste Ibérico  (U.
Minho, 2019).
⸻
5. Síntese interpretativa final

A Coca de Monção é o mito que dança. Encena o eterno retorno: morrer para renascer, ser
vencida para continuar. O dragão, símbolo da terra e da água, representa a energia criadora que
o cristianismo tentou domar, mas que o povo reabilitou como celebração.
Na leitura simbólica da Associação  MILK, a Coca é a personificação  do folclore como
resistência — o corpo feminino, monstruoso e festivo que sobrevive às instituições.
A escultura MILK concebida por Eduardo Mauer representa a Coca como dragão de corpo
compacto e cabeça grande, com escamas iridescentes em tons de verde, vermelho e dourado. A
boca aberta revela sete dentes simbólicos — referência ao ciclo da renovação. A peça possui
iluminação interna pulsante e superfície envernizada, evocando o brilho cerimonial da festa.
⸻
6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer
Na leitura não binária de Eduardo Mauer, a Coca é o corpo queer da celebração  —
simultaneamente masculino e feminino, santo e profano, devorado e devorador. A sua luta com
São Jorge não é combate, mas dança da coexistência.
Mauer escreve: “A Coca é o dragão que dança para não morrer. É o corpo plural que recusa o
destino de monstro e o transforma em movimento. É o folclore que se reencarna a cada passo.”
A Associação  MILK interpreta a Coca como ícone da pedagogia da alegria — o corpo híbrido e
festivo que dissolve o medo pela arte. Na sua leitura pós-binária, o mito torna-se metáfora do
renascimento cultural e da persistência das formas populares de expressão.
⸻
7. Referência Estrutural da Matriz MILK
Na Matriz Escultórica MILK, a Coca é modelada com corpo robusto, cabeça grande, escamas
estilizadas e cauda espiralada. As cores predominantes são verde, vermelho e dourado, com
acabamento em verniz marítimo. A instalação inclui som ambiente de tambores e gaitas,
remetendo à Festa do Corpo de Deus de Monção.
⸻
Localização  específica: Monção, Alto Minho.
Primeiro relato documentado: Crónica das Festas do Corpo de Deus de Monção , Baltazar da
Fonseca, 1595.
Sistematização  contemporânea:  Eduardo Mauer, A Coca de Monção:  Corpo, Festa e
Ressurgimento do Mito no Minho, Associação MILK, 2024.
Fontes primárias:  Fonseca (1595); Braga (1883); Vasconcelos (1915); Parafita (2008); Leite
(2019); Mauer (2024).
