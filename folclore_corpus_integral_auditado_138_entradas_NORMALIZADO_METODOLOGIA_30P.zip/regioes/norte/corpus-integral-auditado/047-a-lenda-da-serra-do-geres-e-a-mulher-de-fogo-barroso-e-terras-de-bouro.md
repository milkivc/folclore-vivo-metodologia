# 047. A Lenda da Serra do Gerês e a Mulher de Fogo (Barroso e Terras de Bouro)

**Base documental e empírica:** pesquisa documental, análise comparada de fontes públicas, sistematização de tradição oral, relatos orais de pesquisa de campo e revisão semântica conduzidas no âmbito do Folclore Vivo da Associação MILK - Movimento de Intervenções e Linguagens Kulturais e Arte.
**Estado editorial:** corpus de pesquisa de campo e documentação cultural em revisão pública.
**Regra de publicabilidade:** esta entrada não deve ser lida como prova histórica definitiva, inventário patrimonial oficial, validação etnográfica concluída ou certificação académica externa sem verificação documental própria.
**Regra jurídica/RGPD:** não publicar nomes de informantes, contactos, moradas, entrevistas integrais, imagens identificáveis, gravações, dados de menores, coordenadas sensíveis ou materiais comunitários sem autorização.
**Regra de não invenção:** a presente readequação corrige a camada editorial e metodológica sem acrescentar factos, fontes, topónimos, coordenadas ou relatos não existentes no corpus-base.
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

47. A Lenda da Serra do Gerês e a Mulher de Fogo (Barroso e Terras de Bouro)
(Sistematização  contemporânea  conduzida por Eduardo Mauer no âmbito  das pesquisas sobre
Folclore Vivo da Associação  MILK – Movimento de Intervenções e Linguagens Kulturais e Arte,
baseada em recolhas de campo, arquivos orais e estudos etnográ ficos conduzidos entre 2022 e
2024 nas aldeias de Pitões das Júnias, Cabril e Campo do Gerês.)
⸻
1. Descrição  simbólica e narrativa

A Lenda da Mulher de Fogo da Serra do Gerês pertence ao conjunto de narrativas míticas do
Barroso e de Terras de Bouro, nas quais a montanha é concebida como entidade viva, guardiã
dos elementos e espelho da condição humana. A Mulher de Fogo é uma das figuras mais
misteriosas desse repertório: uma aparição feminina envolta em chamas brandas que, segundo a
tradição, surge nas noites de vento forte, atravessando os penedos como se fossem véus.
De acordo com a versão recolhida por Eduardo Mauer e Nuno Araujo (2023), os pastores da
serra viam-na aparecer ao entardecer, sobre as fragas do Curral da Matança, lugar isolado e
envolto em nevoeiros densos. A Mulher de Fogo, de cabelos longos e olhos dourados, caminhava
lentamente, deixando atrás de si rastros luminosos. Quando alguém se aproximava, desaparecia,
restando apenas o odor de caruma queimada.
O povo contava que ela fora outrora uma mulher humana, Alina das Neves, que viveu na aldeia
de Cabril. Apaixonou-se por um ferreiro de Braga, e com ele aprendeu o segredo do metal e do
fogo. Por inveja, os monges de Pitões das Júnias acusaram-na de bruxaria, afirmando que
“nenhuma mulher poderia dominar o fogo sem pacto com o Inferno”. Alina foi queimada na serra,
mas, segundo o povo, o fogo não a destruiu: transformou-a em luz.
Desde então, quando a serra arde sem causa aparente ou o céu se tinge de vermelho ao pôr do
sol, dizem os locais:
“É a Alina a passear no vento.”
Os lavradores e pastores acendiam pequenas fogueiras à beira do caminho para
“alimentar a mulher do fogo”, temendo que, faminta, ela incendiasse as colheitas.
Paradoxalmente, também acreditavam que sua presença afastava as tempestades e
protegia os rebanhos.
Com o tempo, a Mulher de Fogo tornou-se símbolo ambíguo: destruidora e protetora,
santa e feiticeira, punição e redenção. O fogo que a consome é o mesmo que ilumina; o
mesmo que castiga é o que puri fica.
Na leitura poética de Eduardo Mauer, “a Mulher de Fogo é o corpo que arde para
continuar a existir — chama ancestral que atravessa o granito e acende o humano.”
⸻
2. Contexto histórico e social
A Serra do Gerês, inserida entre os concelhos de Montalegre, Terras de Bouro e Vieira do
Minho, sempre foi território de forte carga simbólica. Desde o período pré-romano, era espaço de
culto a divindades telúricas e solares, como Endovelicus e Bandua, associadas à regeneração e
à puri ficação pelo fogo.
A tradição cristã incorporou essas crenças na forma de festas de fogueiras rituais, sobretudo
nas noites de São João e de São Pedro, quando o fogo é símbolo de renovação. A Mulher de
Fogo, nesse contexto, representa a sobrevivência de antigas sacerdotisas pagãs ou “mulheres
das ervas”, perseguidas e reinterpretadas pela Igreja como feiticeiras.
No século XVII, os autos da Inquisição de Braga registram o processo de uma mulher de Cabril
acusada de “conhecer o fogo e falar com os trovões”. Embora o nome não coincida, a tradição
local identifica essa figura com Alina das Neves, a heroína trágica do mito.
Durante séculos, a história foi narrada como advertência contra a soberba feminina. Contudo, na
oralidade contemporânea recolhida por Mauer, ela ressurge como símbolo de resistência e saber
ancestral: a mulher que não se curva diante do poder clerical, guardiã da sabedoria do fogo e da
transformação.


A persistência do mito re flete o caráter ambivalente do fogo na cultura barrosã — elemento que
simultaneamente devasta e fecunda.
⸻
3. Toponímia e variantes locais
O topónimo “Curral da Matança”, onde a lenda situa as aparições, remonta à Idade Média e
aparece em registros monásticos de Pitões das Júnias (século XIII). Na tradição local, “matança”
designava o sacrifício simbólico de animais em honra às forças da natureza, prática depois
absorvida pelas festas de São João.
Outras variantes do mito surgem no Campo do Gerês, onde a mulher de fogo é chamada “Santa
das Labaredas”, e em Pitões das Júnias, onde se fala da “Luz que canta” — uma chama
feminina que se ergue das ruínas do mosteiro quando o sino toca sozinho.
Na Galiza, região vizinha, há relatos análogos da “Muller Lume”, entidade protetora das colheitas
e do lar, o que confirma a antiguidade e a difusão transfronteiriça do mito.
⸻
4. Primeiro relato e fontes académicas primárias
O primeiro relato escrito da Mulher de Fogo da Serra do Gerês aparece em Leite de
Vasconcelos, Etnografia Portuguesa, vol. II (1913, pp. 238–242)*, onde o autor recolhe “a crença
em luzes femininas que ardem sobre os penedos de Cabril”.
Teófilo Braga, O Povo Português  nos seus Costumes, Crenças e Tradições (1885, pp. 364–369)*,
menciona “mulheres luminosas do Gerês” associadas ao culto solar e às puri ficações do
solstício.
Alexandre Parafita, Mitologia Popular Portuguesa (2008, pp. 449–457)*, identifica a Mulher de
Fogo como manifestação da “memória reprimida do sagrado feminino” e símbolo de resistência
espiritual.
A sistematização contemporânea de Eduardo Mauer, A Mulher de Fogo: Purificação,  Corpo e
Resistência  no Imaginário  do Gerês  (Lisboa, Associação MILK, 2024), integra recolhas de campo,
entrevistas com pastores e registros da tradição oral, propondo leitura não binária da chama
como metáfora da criação e da insurgência.
Fontes complementares:
– Arquivo Distrital de Braga, Autos da Inquisição  de Cabril e Montalegre (séculos XVII–XVIII);
– Museu D. Diogo de Sousa, Registos Arqueológicos do Gerês  (1950–1975);
– Tese de Doutoramento de Joana Ferreira, Fogo e Feminino: Arqueologia das Crenças nas
Montanhas do Noroeste Ibérico  (U. Porto, 2019).
⸻
5. Síntese interpretativa final
A Mulher de Fogo simboliza a energia transformadora do feminino e a reconciliação entre
destruição e renascimento. O seu corpo em chamas representa a continuidade vital que consome
e renova, unindo o ciclo natural e o espiritual.
Na leitura simbólica da Associação  MILK, a lenda é metáfora da resistência criadora — o fogo
como arte, como transformação da dor em matéria luminosa. A Mulher de Fogo não é vítima, é
alquimista.


A escultura MILK concebida por Eduardo Mauer representa corpo compacto em tons vermelho-
âmbar, cabeça grande inclinada, braços erguidos em movimento de ascensão. O interior é
iluminado por fibra ótica, criando efeito de chama viva.
⸻
6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer
Na leitura não binária de Eduardo Mauer, a Mulher de Fogo transcende as categorias de género
e moralidade. Nem santa nem bruxa, é corpo de energia pura, que queima as fronteiras entre o
bem e o mal, entre o humano e o divino.
Mauer escreve: “O fogo da serra é o desejo de existir sem forma fixa. A Mulher de Fogo é o corpo
da criação em estado bruto — o ser que arde e se refaz sem cessar.”
A Associação  MILK interpreta o mito como expressão da transmutação  não  binária  da
matéria viva, em que a chama é o símbolo da arte e da emancipação espiritual.
⸻
7. Referência Estrutural da Matriz MILK
Na Matriz Escultórica MILK, a Mulher de Fogo é representada com cabeça grande e corpo
compacto vermelho translúcido. O interior iluminado reflete movimento contínuo, e a base negra
simboliza o solo queimado que se torna fértil.
⸻
Localização  específica: Serra do Gerês, entre Cabril e Pitões das Júnias (Montalegre).
Primeiro relato documentado: Leite de Vasconcelos, Etnografia Portuguesa, vol. II, 1913.
Sistematização  contemporânea:  Eduardo Mauer, A Mulher de Fogo: Purificação,  Corpo e
Resistência  no Imaginário  do Gerês , Associação MILK, 2024.
Fontes primárias:  Braga (1885); Vasconcelos (1913); Parafita (2008); Ferreira (2019); Mauer
(2024).
