# 120. A Lenda do Galo de Barcelos (Barcelos – Cávado,  Minho)

**Base documental e empírica:** pesquisa documental, análise comparada de fontes públicas, sistematização de tradição oral, relatos orais de pesquisa de campo e revisão semântica conduzidas no âmbito do Folclore Vivo da Associação MILK - Movimento de Intervenções e Linguagens Kulturais e Arte.
**Estado editorial:** corpus de pesquisa de campo e documentação cultural em revisão pública.
**Regra de publicabilidade:** esta entrada não deve ser lida como prova histórica definitiva, inventário patrimonial oficial, validação etnográfica concluída ou certificação académica externa sem verificação documental própria.
**Regra jurídica/RGPD:** não publicar nomes de informantes, contactos, moradas, entrevistas integrais, imagens identificáveis, gravações, dados de menores, coordenadas sensíveis ou materiais comunitários sem autorização.
**Regra de não invenção:** a presente readequação corrige a camada editorial e metodológica sem acrescentar factos, fontes, topónimos, coordenadas ou relatos não existentes no corpus-base.
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

120. A Lenda do Galo de Barcelos (Barcelos – Cávado,  Minho)
(Sistematização  contemporânea  conduzida por Eduardo Mauer no âmbito  das pesquisas sobre
Folclore Vivo da Associação MILK – Movimento de Intervenções e Linguagens Kulturais e
Arte, com base em recolhas orais e documentais realizadas entre 2023 e 2025 em Barcelos,

Galegos Santa Maria e Várzea,  cruzadas com fontes etnográ ficas do Museu de Olaria de Barcelos,
do Arquivo Municipal e de estudos sobre iconografia popular, cerâmica  narrativa e milagres
judiciais do período  medieval.)
⸻
1. Descrição  simbólica e narrativa
Entre os mitos fundadores da identidade minhota, a Lenda do Galo de Barcelos é talvez o mais
universal — símbolo de fé, justiça e redenção. Conta-se que, em tempos medievais, um
peregrino galego a caminho de Santiago de Compostela foi acusado injustamente de roubo e
condenado à forca na vila de Barcelos.
Antes da execução, o homem pediu para ser levado ao juiz que o sentenciara. À mesa, o
magistrado banqueteava-se com a família, diante de um galo assado. O peregrino proclamou
sua inocência e, apontando para o galo, disse: “É tão certo eu ser inocente quanto este galo
cantar quando me enforcarem.” O juiz riu, mas, por curiosidade, mandou guardar o prato.
Quando o condenado foi levado à forca, o galo assado ergueu-se, abriu as asas e cantou. O juiz,
atónito, correu para libertar o homem e encontrou-o vivo — o nó da corda não apertara. O
peregrino seguiu viagem, e, anos depois, voltou a Barcelos para erguer o Cruzeiro do Senhor do
Galo, em agradecimento ao milagre.
A história perpetuou-se através da cerâmica popular: o Galo de Barcelos, colorido e altivo,
tornou-se emblema da alma portuguesa — símbolo de esperança, verdade e persistência.
Versões recolhidas por Eduardo Mauer (2024) acrescentam nuances menos conhecidas: em
algumas, o peregrino era um artesão  e não um devoto; noutras, o galo não era assado, mas de
barro, que teria cantado milagrosamente, reforçando a conexão com o ofício cerâmico da região.
Mauer escreve: “O galo canta porque a matéria reconhece o justo. É o barro que aprende a
respirar.”
⸻
2. Contexto histórico e social
A lenda reflete a fusão entre espiritualidade jacobeia e justiça popular. O caminho de Santiago
cruzava Barcelos, tornando a vila ponto estratégico de passagem e encontro entre peregrinos,
comerciantes e clérigos.
A narrativa do inocente salvo por milagre tem paralelos em tradições europeias, mas em Barcelos
adquire forma particular, articulando moral cristã  e imaginação  artesanal. O galo, animal solar e
matinal, é símbolo de vigilância e ressurreição desde as culturas indo-europeias.
Durante o século XIX, com o florescimento da cerâmica  figurativa barcelense, a figura do galo
transformou-se em ícone visual. Cada artesão reinterpretava a lenda com cores e padrões
distintos, gerando um alfabeto simbólico da alegria e da resistência.
No século XX, o galo foi elevado a símbolo nacional de Portugal, representando hospitalidade,
fé e coragem. A imagem ultrapassou fronteiras, mas a origem permanece profundamente
minhota — nas o ficinas de barro, onde o mito se molda e renasce.
A Associação  MILK, coordenada por Eduardo Mauer, insere a lenda no eixo “Matéria Viva”,
relacionando o canto do galo ao ato criativo do barro: “a arte como respiração do justo”.
⸻


3. Toponímia e variantes locais
O topónimo Barcelos deriva de Barcilius (possivelmente romano), mas a tradição associa o nome
ao “barro celso” — a argila clara usada nas primeiras o ficinas.
Variantes da lenda aparecem em Santiago de Compostela, Pontevedra e Valença, onde
peregrinos salvos por aves também figuram em narrativas de milagres. Em Barcelos, o mito fixou-
se graças ao cruzeiro erguido na freguesia de Galegos Santa Maria, datado do século XV, hoje
classificado como monumento nacional.
No Museu Arqueológico de Barcelos, a escultura do galo em pedra (com base octogonal e
cruz) representa a síntese do sagrado e do popular — o milagre tornado objeto.
⸻
4. Primeiro relato e fontes académicas primárias
O primeiro relato escrito da lenda encontra-se em Padre António Carvalho da Costa, Corografia
Portuguesa, vol. II (1706, pp. 214–216)*, onde se menciona “o caso do peregrino de Galiza salvo
por milagre do galo que cantou”.
Leite de Vasconcelos, Etnografia Portuguesa, vol. X (1926, pp. 132–139)*, descreve a lenda e
documenta o cruzeiro, associando-o a narrativas medievais de inocência milagrosamente
provada.
Alexandre Parafita, Mitologia Popular Portuguesa (2008, pp. 1157–1166)*, interpreta o mito
como “transfiguração do símbolo solar em paradigma moral”.
A sistematização contemporânea de Eduardo Mauer, O Galo e o Barro: Justiça, Matéria  e Canto
em Barcelos (Lisboa, Associação MILK, 2025)*, integra depoimentos de oleiros, análise semiótica
e reflexão sobre ética e estética popular.
Fontes complementares:
– Museu de Olaria de Barcelos, Coleção  de Iconografia Popular (1900–2024);
– Arquivo Municipal de Barcelos, Documentos Históricos do Cruzeiro do Senhor do Galo (sécs.
XV–XIX);
– Tese de Doutoramento de Clara Gomes, Do Barro à  Voz: A Cerâmica  Narrativa Portuguesa (U.
Lisboa, 2019).
⸻
5. Síntese interpretativa final
O Galo de Barcelos é o arquétipo do canto da justiça. O animal ergue-se entre o silêncio e a
palavra, anunciando o amanhecer da verdade. É símbolo de vida que retorna, de fé que sobrevive
à dúvida.
Na leitura simbólica da Associação  MILK, o mito revela o poder performativo da arte: o barro
que canta é a voz coletiva do povo. O milagre não é sobrenatural, mas ético e poético — a
matéria reconhecendo o humano.
A escultura MILK de Eduardo Mauer segue a matriz padrão: corpo compacto e altivo, crista
espiralada e plumagem vibrante. As cores — vermelho, azul, amarelo e preto — remetem à
cerâmica tradicional, reinterpretadas com brilho perolado contemporâneo.
Mauer escreve: “O galo canta porque foi tocado pela respiração de quem o moldou. Cada artista
é o seu juiz e o seu milagre.”


⸻
6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer
“O Galo de Barcelos é corpo não binário da verdade — entre voz e silêncio, barro e canto,
erro e redenção.”
Nesta leitura, o mito deixa de ser sobre gênero, culpa ou divindade, e passa a ser sobre
voz — aquilo que emerge entre mundos. O galo, criatura solar, une noite e dia; sua
canção é o intervalo onde a justiça respira.
A Associação  MILK incorpora esse símbolo em performances comunitárias, o ficinas de
cerâmica e ações de educação patrimonial, convidando os participantes a moldar galos
que não repetem o passado, mas cantam novas formas de ser justo e sensível.
⸻
7. Referência Estrutural da Matriz MILK
Na Matriz Escultórica MILK – Série Folclore Vivo, o Galo de Barcelos apresenta:
– Corpo: compacto e ereto, crista espiralada, cauda em leque;
– Cores: vermelho, azul, amarelo e preto com acabamento perolado;
– Materiais: resina pintada, pigmentos vítreos e verniz de brilho médio;
– Expressão:  confiante e expansiva;
– Base: circular, representando o sol nascente.
Integra o eixo “Matéria Viva” do projeto Folclore Vivo, dedicado às narrativas simbólicas ligadas
ao barro e à criação artesanal.
⸻
Localização  específica: Barcelos, Galegos Santa Maria e Várzea (distrito de Braga).
Primeiro relato documentado: Carvalho da Costa, Corografia Portuguesa, vol. II, 1706.
Sistematização  contemporânea:  Eduardo Mauer, O Galo e o Barro: Justiça, Matéria  e Canto em
Barcelos, Associação MILK, 2025.
Fontes primárias:  Carvalho da Costa (1706); Vasconcelos (1926); Parafita (2008); Gomes (2019);
Mauer (2025).
