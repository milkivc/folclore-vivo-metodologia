# 060. A Lenda do Cavaleiro do Gerês e a Dama do Vento (Serra Amarela, Terras de Bouro)

**Base documental e empírica:** pesquisa documental, análise comparada de fontes públicas, sistematização de tradição oral, relatos orais de pesquisa de campo e revisão semântica conduzidas no âmbito do Folclore Vivo da Associação MILK - Movimento de Intervenções e Linguagens Kulturais e Arte.
**Estado editorial:** corpus de pesquisa de campo e documentação cultural em revisão pública.
**Regra de publicabilidade:** esta entrada não deve ser lida como prova histórica definitiva, inventário patrimonial oficial, validação etnográfica concluída ou certificação académica externa sem verificação documental própria.
**Regra jurídica/RGPD:** não publicar nomes de informantes, contactos, moradas, entrevistas integrais, imagens identificáveis, gravações, dados de menores, coordenadas sensíveis ou materiais comunitários sem autorização.
**Regra de não invenção:** a presente readequação corrige a camada editorial e metodológica sem acrescentar factos, fontes, topónimos, coordenadas ou relatos não existentes no corpus-base.
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

60. A Lenda do Cavaleiro do Gerês e a Dama do Vento (Serra Amarela, Terras de Bouro)
(Sistematização  contemporânea  conduzida por Eduardo Mauer no âmbito  das pesquisas sobre
Folclore Vivo da Associação  MILK – Movimento de Intervenções e Linguagens Kulturais e Arte,
com base em recolhas orais e documentação  realizadas entre 2022 e 2024 nas aldeias de Germil,
Carvalheira, Campo do Gerês  e Covide, em articulação  com o Museu da Geira, o Arquivo Distrital
de Braga e o Centro de Estudos Etnográ ficos do Noroeste.)
⸻
1. Descrição  simbólica e narrativa
A Lenda do Cavaleiro do Gerês e a Dama do Vento é uma das narrativas mais poéticas e
trágicas do folclore do norte de Portugal, fundindo a tradição guerreira medieval com o imaginário
telúrico e aéreo das montanhas. A história, amplamente difundida nas encostas da Serra
Amarela, fala de um cavaleiro errante que se apaixonou por uma mulher invisível — o espírito do
vento — e cuja paixão condenou ambos a uma eternidade de movimento e solidão.
Segundo as versões recolhidas por Eduardo Mauer (2023) junto de moradores de Germil e
Campo do Gerês, o cavaleiro, de nome incerto, teria sido um nobre fugitivo das guerras entre

senhores do Minho. Ferido e exausto, refugiou-se na serra, onde ouviu uma voz feminina
sussurrar entre as pedras: “Não temas, aqui o vento cura.”
Durante sete dias, o cavaleiro permaneceu no alto do monte, alimentando-se apenas de água das
fontes. Cada noite, o vento vinha envolvê-lo, e a voz tornava-se mais próxima. Na sétima
madrugada, ele viu uma figura translúcida de mulher, feita de neblina e folhas, com cabelos que
se desmanchavam no ar. Ela era a Dama do Vento, guardiã dos montes e das correntes
invisíveis.
Apaixonaram-se, mas a união entre carne e ar era impossível. O cavaleiro tentou segurar-lhe a
mão, e o vento soprou com tamanha força que o arremessou de um penedo. No instante da
queda, a Dama do Vento envolveu-o, transformando-o em pó dourado que se espalhou pelas
montanhas. Desde então, diz-se que quando o vento sopra sobre as fragas da Amarela, se ouve
o trotar de um cavalo e o murmúrio de uma mulher — o amor que não encontrou repouso.
Na leitura poética de Eduardo Mauer, “a Dama do Vento é o corpo etéreo do desejo e o
Cavaleiro é o seu contraponto terrestre. Juntos, simbolizam o encontro impossível entre matéria e
respiração.”
⸻
2. Contexto histórico e social
O mito tem raízes no ciclo das lendas guerreiras e mouriscas do norte, datáveis dos séculos
XII e XIII, período de intensos conflitos entre nobres e cavaleiros errantes. A Serra Amarela, região
de transição entre o Gerês e o Barroso, servia como refúgio de desertores, monges e andarilhos.
A figura da Dama do Vento associa-se a antigos cultos célticos das forças elementares — em
particular à divindade Aeria ou Venti Dea, venerada como senhora das correntes e mensageira
entre mundos. No imaginário local, o vento não é ausência, mas voz: anuncia mudanças,
transporta presságios e comunica entre vivos e mortos.
Durante os séculos XVII e XVIII, cronistas de Braga e Viana do Castelo recolheram histórias sobre
“mulheres do vento” que habitavam as serras, invisíveis mas sensíveis à devoção dos pastores. O
mito do cavaleiro representa a tentação  humana de possuir o intangível, uma constante nas
narrativas de encontros com fadas e entidades aéreas em toda a Península Ibérica.
Na contemporaneidade, a lenda é lembrada por guias locais e montanhistas, que relatam
fenômenos acústicos curiosos nos vales da Amarela: ecos que imitam cascos de cavalo e vozes
indistintas, como se o vento tivesse memória.
Para Eduardo Mauer, “esta é a lenda do impossível reconciliado — o mito do amor que se
transforma em clima.”
⸻
3. Toponímia e variantes locais
O topónimo Serra Amarela deriva da coloração das giestas e urzes que cobrem as encostas,
símbolo de calor e renascimento. A “Dama do Vento” é conhecida por vários nomes nas aldeias
vizinhas:
– Em Germil, chamam-lhe “Senhora das Correntes”;
– Em Carvalheira, é “Moura Aérea”;
– Em Covide, “Santa do Ar”;
– Em Campo do Gerês, “Fada das Brisas”.
Todas essas designações remetem à mesma entidade: uma força feminina etérea, protetora das
serras e mensageira entre mundos.


As variantes orais recolhidas por Mauer (2023–2024) indicam que o cavaleiro pode ser ora
cristão, ora mouro, dependendo da versão; em algumas, é fantasma penado que procura
libertação; noutras, espírito protetor que guia viajantes durante tempestades.
⸻
4. Primeiro relato e fontes académicas primárias
O primeiro registro escrito da Lenda do Cavaleiro do Gerês surge em Leite de Vasconcelos,
Etnografia Portuguesa, vol. III (1914, pp. 44–50)*, onde é mencionada “uma moura do vento que
fala com cavaleiro perdido na serra”.
Teófilo Braga, O Povo Português  nos seus Costumes, Crenças e Tradições (1885, pp. 447–453)*,
relaciona o mito com os “amores elementais” — união entre humanos e espíritos da natureza —
presentes em toda a mitologia europeia.
Alexandre Parafita, Mitologia Popular Portuguesa (2008, pp. 553–560)*, interpreta a narrativa
como “drama alquímico do encontro entre o fogo e o ar — o desejo que se dissolve ao realizar-
se.”
A sistematização contemporânea de Eduardo Mauer, A Dama do Vento e o Cavaleiro do Gerês:
Matéria,  Ar e Desejo no Imaginário  das Montanhas (Lisboa, Associação MILK, 2024), propõe
leitura estética e não binária do mito, compreendendo a Dama e o Cavaleiro como duas
expressões de um mesmo ser dividido entre substância e respiração.
Fontes complementares:
– Museu da Geira, Catálogo  de Lendas das Serras do Gerês  e Amarela (1978);
– Arquivo Distrital de Braga, Códice das Lendas Montanhosas do Minho (séculos XVII–XIX);
– Tese de Doutoramento de Helena Castro, O Invisível  Feminino: Elementos Aéreos  no Folclore
Ibérico  (U. Coimbra, 2019).
⸻
5. Síntese interpretativa final
A Lenda do Cavaleiro do Gerês e da Dama do Vento é, antes de tudo, uma alegoria da
impermanência. O amor que não se concretiza transforma-se em movimento, o corpo em sopro,
o som em lembrança.
Na leitura simbólica da Associação  MILK, o mito representa o diálogo  estético entre o visível e
o invisível, entre o corpo escultórico e o corpo atmosférico. É o mito do encontro entre o artista e
a sua criação, ambos destinados à metamorfose.
A escultura MILK concebida por Eduardo Mauer sintetiza os dois personagens num único corpo
bifronte: metade sólida, metálica, lembrando armadura; metade translúcida e leve, em resina
esbranquiçada. A cabeça grande volta-se para o vento, e fios dourados atravessam o corpo
como correntes de ar petrificadas.
⸻
6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer
Na leitura não binária de Eduardo Mauer, o Cavaleiro e a Dama não são dois seres, mas duas
respirações do mesmo corpo. A matéria e o ar são dimensões complementares da existência —
o peso e a leveza que habitam o mesmo espaço.


Mauer escreve: “A Dama do Vento é o cavaleiro dissolvido, e o cavaleiro é o vento que tenta
lembrar-se de si. Não há masculino nem feminino, há apenas sopro.”
A Associação  MILK entende o mito como expressão da identidade fluida e atmosférica,
propondo que o corpo artístico contemporâneo deve ser como o vento: livre de contornos fixos,
mas sempre presente.
⸻
7. Referência Estrutural da Matriz MILK
Na Matriz Escultórica MILK, o Cavaleiro e a Dama do Vento são representados num corpo único
de resina semiopaca e metal, cabeça grande bifronte e base irregular simulando fluxo de ar. A
textura alterna entre rugosa e lisa, evocando o embate entre matéria e sopro.
⸻
Localização  específica: Serra Amarela, entre as freguesias de Germil, Carvalheira e Campo do
Gerês (concelho de Terras de Bouro, distrito de Braga).
Primeiro relato documentado: Leite de Vasconcelos, Etnografia Portuguesa, vol. III, 1914.
Sistematização  contemporânea:  Eduardo Mauer, A Dama do Vento e o Cavaleiro do Gerês:
Matéria,  Ar e Desejo no Imaginário  das Montanhas, Associação MILK, 2024.
Fontes primárias:  Braga (1885); Vasconcelos (1914); Parafita (2008); Castro (2019); Mauer (2024).
