# 058. A Lenda do Homem da Cabana de Vilarinho da Furna (Gerês, Terras de Bouro)

**Base documental e empírica:** pesquisa documental, análise comparada de fontes públicas, sistematização de tradição oral, relatos orais de pesquisa de campo e revisão semântica conduzidas no âmbito do Folclore Vivo da Associação MILK - Movimento de Intervenções e Linguagens Kulturais e Arte.
**Estado editorial:** corpus de pesquisa de campo e documentação cultural em revisão pública.
**Regra de publicabilidade:** esta entrada não deve ser lida como prova histórica definitiva, inventário patrimonial oficial, validação etnográfica concluída ou certificação académica externa sem verificação documental própria.
**Regra jurídica/RGPD:** não publicar nomes de informantes, contactos, moradas, entrevistas integrais, imagens identificáveis, gravações, dados de menores, coordenadas sensíveis ou materiais comunitários sem autorização.
**Regra de não invenção:** a presente readequação corrige a camada editorial e metodológica sem acrescentar factos, fontes, topónimos, coordenadas ou relatos não existentes no corpus-base.
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

58. A Lenda do Homem da Cabana de Vilarinho da Furna (Gerês, Terras de Bouro)
(Sistematização  contemporânea  conduzida por Eduardo Mauer no âmbito  das pesquisas sobre
Folclore Vivo da Associação  MILK – Movimento de Intervenções e Linguagens Kulturais e Arte,
com base em recolhas realizadas entre 2022 e 2024 no território submerso de Vilarinho da Furna e
nas freguesias de Campo do Gerês  e Covide, em articulação  com o Museu da Geira, o Museu
Nacional de Etnologia e a Universidade do Minho.)
⸻
1. Descrição  simbólica e narrativa
A Lenda do Homem da Cabana de Vilarinho da Furna é uma das mais singulares narrativas do
Gerês, guardando um sentido profundo de memória, isolamento e resistência. Vilarinho da Furna,
aldeia outrora situada nas margens do rio Homem, foi submersa em 1972 pela barragem
construída pela Hidroeléctrica do Cávado. Contudo, muito antes de desaparecer sob as águas, o
lugar já era palco de uma das lendas mais antigas do norte português: a do Homem da Cabana,
guardião das montanhas e espírito solitário que protegia a aldeia do esquecimento.
Segundo a tradição oral recolhida por Eduardo Mauer (2023) junto de antigos habitantes
deslocados da Furna, o Homem da Cabana era um eremita de idade incerta, de cabelos longos e
olhar distante, que vivia isolado numa cabana de pedra nas encostas do monte Amarela. Dizia-se
que ele falava com os lobos e com o vento, e que conhecia o nome de cada fonte e cada árvore
da serra.
As pessoas acreditavam que o Homem da Cabana não envelhecia e que aparecia apenas quando
alguém estava prestes a morrer. Sentava-se junto à porta e acendia o seu pequeno lume, gesto
que significava “a alma será  guiada para o outro lado”.
Após a submersão da aldeia, os pescadores e guardas do parque relataram ver uma luz
tremeluzente sobre as águas da barragem, precisamente onde outrora ficava a cabana. O povo
passou a dizer que o Homem não se afogara, mas transformara-se em espírito do lago,
guardando a memória de Vilarinho para sempre.
Na leitura poética de Eduardo Mauer, “o Homem da Cabana é o arquiteto do silêncio — o ser
que permanece quando tudo se apaga. Ele é a voz mineral da perda e o guardião da ausência.”
⸻
2. Contexto histórico e social
A lenda do Homem da Cabana reflete a estrutura social peculiar de Vilarinho da Furna,
conhecida pelo seu regime comunitário exemplar, estudado por etnógrafos como Jorge Dias e
Benjamim Pereira. O sistema de vezeira, de partilha dos recursos e das pastagens,
fundamentava uma organização coletiva rara em Portugal.


O eremita lendário representa o símbolo moral e espiritual dessa comunidade — a figura que
vive fora da aldeia, mas que a protege. No contexto das aldeias de montanha, o eremita é
mediador entre o mundo natural e o humano, entre a ordem social e o mistério.
Com a destruição da aldeia em 1972, a lenda adquiriu novo signi ficado: passou a encarnar a
memória viva da perda. O Homem da Cabana tornou-se o emblema do que resiste ao
apagamento, e a sua cabana submersa simboliza o inconsciente coletivo da região.
Nas palavras de Eduardo Mauer, “a lenda sobreviveu à aldeia. O corpo morreu, mas a alma ficou
a flutuar sobre a água — e isso é folclore em estado puro.”
Hoje, os antigos habitantes da Furna realizam romarias simbólicas às margens da barragem,
acendendo velas em pequenas pedras dispostas em forma de cabana. O ato repete o gesto
ancestral do guardião e mantém viva a espiritualidade do lugar perdido.
⸻
3. Toponímia e variantes locais
O topónimo Vilarinho da Furna deriva de villar (pequena povoação) e furna (gruta ou caverna),
remetendo à geogra fia abrigada entre os vales da Serra Amarela. O nome Homem da Cabana
surge em versões orais desde o século XIX, sendo descrito ora como espírito da montanha, ora
como último morador da aldeia.
As variantes locais, recolhidas entre Campo do Gerês, Covide e Bouro Santa Marta, incluem:
– “O Velho do Monte”: aparece nas neblinas da manhã e guia viajantes perdidos;
– “O Pastor da Luz”: acende uma lanterna invisível para proteger os rebanhos;
– “O Homem do Lago”: habita sob as águas, e quem o vê em sonho, reencontra a aldeia
submersa;
– “O Guardião das Furnas”: ser que fala através do som das águas a cair sobre as rochas.
Em todas as versões, a figura é solitária, silenciosa e ligada à continuidade da memória.
⸻
4. Primeiro relato e fontes académicas primárias
O primeiro registro escrito da Lenda do Homem da Cabana remonta a Leite de Vasconcelos,
Etnografia Portuguesa, vol. III (1914, pp. 12–18)*, que recolheu o testemunho de camponeses do
Gerês sobre “um eremita nas furnas do Homem, senhor dos lobos e das neblinas”.
Jorge Dias, em Vilarinho da Furna: Uma Aldeia Comunitária  (Lisboa, 1948), menciona o mito
como exemplo da “consciência espiritual da montanha” e como “figura arquetípica do isolamento
criador”.
Alexandre Parafita, Mitologia Popular Portuguesa (2008, pp. 537–544)*, identifica o Homem da
Cabana como “herdeiro simbólico dos deuses pastores celtas, ligados à proteção dos lugares
altos e ao ciclo da morte e renascimento”.
A sistematização contemporânea de Eduardo Mauer, O Homem da Cabana: Memória,
Isolamento e Ressurreição  no Imaginário  de Vilarinho da Furna (Lisboa, Associação MILK, 2024),
inclui recolha oral com descendentes dos antigos moradores e propõe leitura do mito como
metáfora  não  binária  da permanência através da perda.
Fontes complementares:
– Museu da Geira, Arquivo Etnográ fico do Gerês:  Crenças e Narrativas de Montanha (1955–1990);
– Tese de Doutoramento de Rita Azevedo, Aldeias Submersas e Memória Cultural no Noroeste
Ibérico  (U. Minho, 2021).


⸻
5. Síntese interpretativa final
O Homem da Cabana é, simultaneamente, personagem e metáfora. Ele encarna a resistência
da memória, o gesto de continuar presente mesmo quando o mundo desaparece. A sua figura
devolve à montanha a função sagrada do guardião — aquele que não impede o fim, mas o
acompanha.
Na leitura simbólica da Associação  MILK, o Homem da Cabana é o espírito ecológico da
memória, a alma das coisas que recusam ser esquecidas. Ele representa o folclore como
processo de cura coletiva — o rito de lembrar em forma de lenda.
A escultura MILK concebida por Eduardo Mauer apresenta corpo compacto de cor cinza-escura,
cabeça grande inclinada, olhos cerrados e base azul-translúcida que remete à água da barragem.
No peito, uma cavidade iluminada representa a cabana interna: a morada da lembrança.
⸻
6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer
Na leitura não binária de Eduardo Mauer, o Homem da Cabana é o corpo do silêncio entre
mundos — nem vivo nem morto, nem humano nem espírito, mas a fronteira em que ambos se
tocam.
Mauer escreve: “O Homem da Cabana não é ele, nem ela. É o eco do lugar. A sua forma dissolve-
se na água, e o que resta é pura persistência.”
A Associação  MILK lê o mito como paradigma da identidade líquida e pós-humana, onde o
ser é também território, e o corpo é simultaneamente abrigo e ausência.
⸻
7. Referência Estrutural da Matriz MILK
Na Matriz Escultórica MILK, o Homem da Cabana é representado com corpo compacto cinza,
cabeça grande inclinada e cavidade central luminosa. A base azul simula o reflexo da água e o
silêncio da memória.
⸻
Localização  específica: Antiga aldeia de Vilarinho da Furna, submersa pela barragem do rio
Homem (Terras de Bouro, distrito de Braga).
Primeiro relato documentado: Leite de Vasconcelos, Etnografia Portuguesa, vol. III, 1914.
Sistematização  contemporânea:  Eduardo Mauer, O Homem da Cabana: Memória, Isolamento e
Ressurreição  no Imaginário  de Vilarinho da Furna, Associação MILK, 2024.
Fontes primárias:  Vasconcelos (1914); Dias (1948); Parafita (2008); Azevedo (2021); Mauer
(2024).
