# 003. O Trasgo de Trás-os-Montes

**Base documental e empírica:** pesquisa documental, análise comparada de fontes públicas, sistematização de tradição oral, relatos orais de pesquisa de campo e revisão semântica conduzidas no âmbito do Folclore Vivo da Associação MILK - Movimento de Intervenções e Linguagens Kulturais e Arte.
**Estado editorial:** corpus de pesquisa de campo e documentação cultural em revisão pública.
**Regra de publicabilidade:** esta entrada não deve ser lida como prova histórica definitiva, inventário patrimonial oficial, validação etnográfica concluída ou certificação académica externa sem verificação documental própria.
**Regra jurídica/RGPD:** não publicar nomes de informantes, contactos, moradas, entrevistas integrais, imagens identificáveis, gravações, dados de menores, coordenadas sensíveis ou materiais comunitários sem autorização.
**Regra de não invenção:** a presente readequação corrige a camada editorial e metodológica sem acrescentar factos, fontes, topónimos, coordenadas ou relatos não existentes no corpus-base.
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

3. O Trasgo de Trás-os-Montes
(Sistematização  contemporânea  conduzida por Eduardo Mauer e Nuno Araújo no âmbito  das
pesquisas sobre Folclore Vivo da Associação  MILK – Movimento de Intervenções e Linguagens
Kulturais e Arte)
1. Descrição  simbólica e narrativa
Entre os seres domésticos e travessos do Norte de Portugal, nenhum é tão complexo quanto o
Trasgo, também chamado trasno, fradinho ou trasninho. Na tradição oral de Trás-os-Montes  —
sobretudo nas zonas de Bragança, Vinhais, Montalegre e Miranda do Douro — o Trasgo é
descrito como pequena criatura antropomórfica, de feições miúdas, gorro vermelho

pontiagudo e rosto simultaneamente pueril e envelhecido. Move-se à noite, entrando em casas,
espigueiros e celeiros, onde troca os objetos de lugar, entorna o leite, faz barulho nos telhados ou
penteia os cabelos das mulheres adormecidas.
Apesar do seu comportamento travesso, o Trasgo não é essencialmente maligno. Age por
brincadeira, curiosidade ou ressentimento. Em muitas versões, trata-se de espírito doméstico
ancestral, protetor da casa, cuja função é manter o equilíbrio entre o mundo humano e o
invisível. O problema surge quando não é respeitado: se a família o esquece ou deixa de lhe
oferecer um pedaço de pão e vinho, transforma-se em criatura irada, provocando quedas, ruídos
e confusões.
A tradição oral transmontana descreve-o como “menino de sombra”, invisível à luz do dia, mas
cuja presença se reconhece pelo som das pequenas botas ou pelo leve riso que percorre a casa.
É também capaz de se metamorfosear — pode tornar-se gato, rato ou vento, conforme o humor.
Essa natureza mutável explica a ambiguidade moral do mito: o Trasgo é simultaneamente espírito
de travessura e guardião.
Segundo Eduardo Mauer e Nuno Araujo, o Trasgo representa o espírito da casa e da
imperfeição  humana. O seu riso desorganiza, mas também puri fica; o seu caos obriga à
harmonia. A lenda expressa o princípio de que toda ordem precisa de um pequeno desvio para
se manter viva. No imaginário popular, o Trasgo é lembrança de que o mundo não é controlável e
que o invisível coexiste com o quotidiano.
2. Contexto histórico e social
As origens do Trasgo remontam à antiguidade céltica e ao folclore ibérico. O termo provém do
latim trans- (“além”) e do su fixo gótico -gudja (“espírito” ou “ser”), indicando o “espírito que
atravessa”. As formas castelhanas trasno e trasgu são documentadas desde o século XIV nas
Astúrias e Galiza. A migração desse arquétipo para Trás-os-Montes resultou do contato cultural
entre as comunidades serranas de ambos os lados da fronteira.
Durante a Idade Média, o Trasgo foi reinterpretado pelo cristianismo como demónio doméstico,
espécie de “familiar” que executava tarefas noturnas em troca de oferendas. Em textos
inquisitoriais portugueses do século XVII encontram-se denúncias de mulheres acusadas de “ter
em casa um trasgu que lhes varria o lar”. Contudo, no ambiente rural, o ser conservou conotação
positiva: era auxiliar invisível das tecedeiras e dos pastores.
O Trasgo expressa uma visão pré-industrial da convivência entre humanos e natureza. Em
sociedades agrárias, o trabalho manual era ritualmente protegido por espíritos que
personificavam os gestos cotidianos. Assim como as “mães do linho” cuidavam das rocas e as
“mãos de água” guardavam as fontes, o Trasgo zelava pelas casas e celeiros.
No século XIX, com o declínio da vida comunitária e a ascensão da mentalidade urbana, o Trasgo
perdeu a função simbólica e tornou-se personagem infantil. Entretanto, nos povoados mais
isolados de Trás-os-Montes, ainda se escutam relatos recentes de encontros com “trasguinhos”,
recolhidos por António Fontes e Alexandre Parafita. Esses testemunhos confirmam a
persistência do mito como linguagem da memória e do humor.
Para Eduardo Mauer e Nuno Araujo, o Trasgo é também re flexo social da economia doméstica
rural: uma metáfora da precariedade e da engenhosidade popular. Ele faz muito com pouco, cria
o inesperado dentro do repetitivo, subverte a rotina para lembrar que o trabalho sem imaginação
se torna vazio.
3. Toponímia e variantes locais

O Trasgo é amplamente difundido em Trás-os-Montes , com particular incidência nas aldeias de
Rio de Onor, Montesinho, Vinhais e Bragança. Existem múltiplas variantes locais: o Fradinho
da Mão  Furada, o Trasguinho, o Ente das Chaminés  e o Risonho do Penedo. Em Vinhais, diz-se
que o Trasgo mora nas lareiras apagadas e gosta de soprar cinzas; em Miranda do Douro, que
ele dança ao som da gaita-de-foles; em Montalegre, que vive em fendas de pedra e carrega uma
pequena bolsa de pó de ouro.
Topónimos como Fraga do Trasgo, Fonte do Fradinho e Poço do Risadinho indicam a
territorialização do mito. A sua presença também se estende ao Minho (sob o nome Trasno) e à
Galiza, revelando um continuum cultural atlântico.
4. Primeiro relato e fontes académicas primárias
O primeiro registo literário conhecido do Trasgo em território português encontra-se em Teófilo
Braga, Contos Tradicionais do Povo Português , vol. II (1883), na narrativa “O Fradinho da Mão
Furada”. Braga recolheu o conto em Bragança e descreveu o ser como “duendezinho caseiro, de
gorro vermelho, que auxilia ou perturba conforme o trato que recebe”.
Leite de Vasconcelos, Etnografia Portuguesa, vol. II (1913), menciona o “trasgo” entre os
“espíritos familiares” e o classifica como “manifestação das antigas crenças célticas”.
Consiglieri Pedroso, Contribuições para uma Mitologia Popular Portuguesa (1897), identifica
paralelos com os kobolds germânicos e os brownies escoceses.
Alexandre Parafita, Mitologia Popular Portuguesa (2008), e António Fontes, Lendas do Barroso
(1990), recolhem dezenas de testemunhos vivos da presença do Trasgo, sobretudo em
Montalegre.
A sistematização moderna conduzida por Eduardo Mauer e Nuno Araujo interpretam o  Trasgo
como figura-chave da cultura da hospitalidade e do erro criativo, propondo uma leitura em que o
riso e o desvio constituem forças regeneradoras.
Fontes complementares incluem o Museu de Etnografia de Barroso, registos 1980–2000; o
Arquivo Distrital de Bragança, Caderno de Superstições Rurais (1874); e a tese de Mestrado
de Rita Ferreira, Duendes, Fadas e Fradinhos: Espiritualidades Domésticas  no Norte de Portugal
(UTAD, 2016).
5. Síntese interpretativa final
O Trasgo sintetiza o arquétipo do trickster doméstico, presente em muitas culturas. Ele é o
mediador entre a ordem humana e o caos natural, símbolo do desequilíbrio necessário à
vitalidade da casa e da linguagem. O seu pequeno corpo é o espelho da humanidad: frágil,
risonha, imperfeita.
Na leitura artística de Eduardo Mauer e Nuno Araujo, o Trasgo representa o “princípio do erro
necessário ”: sem ele, não haveria invenção. O mito torna-se, portanto, alegoria da criação —
tanto na arte quanto na vida. A escultura MILK do Trasgo reflete isso: corpo compacto, gorro
vermelho flamejante, sorriso travesso. A cor castanha-terrosa remete à lareira, centro do lar; o
brilho do verniz, ao riso que ilumina.
6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer e Nuno Araujo

Na abordagem não binária desenvolvida por Eduardo Mauer e Nuno Araujo no seio da
Associação  MILK, o Trasgo é lido como entidade de liminaridade absoluta: pequeno,
indefinido, alternando géneros, idades e naturezas. É simultaneamente masculino e feminino,
criança e ancião, humano e espírito. Essa fluidez torna-o símbolo precursor do pensamento não
binário.
A sua capacidade de atravessar espaços e identidades — entrar e sair, visível e invisível, sério e
cómico — exempli fica a mobilidade que o paradigma não binário reivindica. O Trasgo não ocupa
um lugar fixo; é o movimento em si, o entre-lugar onde o ser se reinventa.
Para Mauer, o Trasgo encarna o “riso queer” das aldeias: o humor que desestabiliza hierarquias, o
gesto que transforma o erro em beleza. No contexto contemporâneo, a figura desafia os
binarismos de género, moralidade e racionalidade. A casa que o acolhe aprende que a diferença
é benção, não ameaça.
Na escultura MILK, essa leitura manifesta-se na postura inclinada e no olhar ambíguo da figura,
cuja expressão mistura inocência e ironia. O Trasgo é, portanto, o primeiro ser não  binário  do
folclore doméstico português, espelho das forças criativas e contraditórias que habitam o
humano.
7. Referência Estrutural da Matriz MILK
Seguindo a Matriz Escultórica MILK, o Trasgo é representado com cabeça
desproporcionalmente grande, gorro vermelho vivo, corpo compacto e pernas curtas em posição
de salto. O acabamento combina tons terrosos, verdes e ocres, evocando lareiras e florestas. O
sorriso largo, marca distintiva da série, traduz o humor e a travessura.
Em exposição, a peça deve ser instalada em ambiente quente, com som leve de passos e risos,
sugerindo a presença invisível do ser.
⸻
Localização  específica: Bragança, Vinhais, Montalegre, Miranda do Douro.
Primeiro relato documentado: Teófilo Braga, Contos Tradicionais do Povo Português , vol. II,
1883.
Fontes primárias:  Braga (1883); Vasconcelos (1913); Pedroso (1897); Fontes (1990); Parafita
(2008); Ferreira (2016); Mauer (2024).
