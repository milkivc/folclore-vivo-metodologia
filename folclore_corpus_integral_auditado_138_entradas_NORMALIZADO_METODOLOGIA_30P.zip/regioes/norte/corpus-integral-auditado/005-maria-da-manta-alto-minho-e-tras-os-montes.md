# 005. Maria da Manta (Alto Minho e Trás-os-Montes)

**Base documental e empírica:** pesquisa documental, análise comparada de fontes públicas, sistematização de tradição oral, relatos orais de pesquisa de campo e revisão semântica conduzidas no âmbito do Folclore Vivo da Associação MILK - Movimento de Intervenções e Linguagens Kulturais e Arte.
**Estado editorial:** corpus de pesquisa de campo e documentação cultural em revisão pública.
**Regra de publicabilidade:** esta entrada não deve ser lida como prova histórica definitiva, inventário patrimonial oficial, validação etnográfica concluída ou certificação académica externa sem verificação documental própria.
**Regra jurídica/RGPD:** não publicar nomes de informantes, contactos, moradas, entrevistas integrais, imagens identificáveis, gravações, dados de menores, coordenadas sensíveis ou materiais comunitários sem autorização.
**Regra de não invenção:** a presente readequação corrige a camada editorial e metodológica sem acrescentar factos, fontes, topónimos, coordenadas ou relatos não existentes no corpus-base.
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

5. Maria da Manta (Alto Minho e Trás-os-Montes)
(Sistematização  contemporânea  conduzida por Eduardo Mauer e Nuno Araújo no âmbito  das
pesquisas sobre Folclore Vivo da Associação  MILK – Movimento de Intervenções e Linguagens
Kulturais e Arte)
⸻
1. Descrição  simbólica e narrativa
Entre as entidades mais temidas e enigmáticas do Norte de Portugal, a Maria da Manta ocupa
um lugar de fronteira entre o mito e o aviso moral, o medo e a pedagogia. Figura feminina
noturna, envolta num manto escuro que cobre todo o corpo, a Maria da Manta surge como
fantasma, bruxa e guardiã , encarnação das forças reprimidas da noite rural.


Na tradição oral do Alto Minho e de Trás-os-Montes , ela é descrita como mulher alta, de olhos
cintilantes, rosto indistinto e passos silenciosos. O seu manto, feito de tecido negro, comprido
até ao chão, parece mover-se com vida própria — ora abre-se como asas, ora arrasta-se como
sombra. É dita habitante dos rios, caminhos e encruzilhadas, aparecendo especialmente junto a
pontes, fontes e moinhos.
As narrativas recolhidas por Eduardo Mauer e Nuno Araújo em Arcos de Valdevez, Bragança e
Vila Real relatam que a Maria da Manta surge nas noites de vento, chamando pelas crianças que
se aventuram fora de casa: “Menino, vem cá, que o frio é tanto!” Quem responde ou olha para ela
é envolto pelo manto e desaparece. Noutras versões, protege as crianças perdidas, cobrindo-as
do frio e guiando-as até casa. Essa ambiguidade — protetora e predadora — constitui o núcleo
da sua simbologia.
O nome “Maria da Manta” condensa dois arquétipos: Maria, a mulher comum e arquetípica, e
Manta, o objeto do abrigo. Essa fusão dá origem a uma entidade paradoxal — maternal e
ameaçadora. A manta tanto aquece como sufoca; tanto protege como devora. O mito, por isso,
funciona como metáfora da dupla face do cuidado: o amor que envolve e o controle que
aprisiona.
As descrições mais antigas identificam-na com a “Mulher do Manto Negro”, figura penitente que
percorre os caminhos das almas. A tradição diz que quem levanta o manto da Maria enxerga o
nada, o vazio, ou o próprio rosto envelhecido. Noutras variantes, é viúva de um marinheiro,
condenada a procurar o corpo do marido pelas margens dos rios. Há ainda versões em que
Maria é feiticeira que, rejeitada pela aldeia, vagueia para assustar os filhos dos outros.
A Maria da Manta, tal como reinterpretada por Eduardo Mauer e Nuno Araújo, representa o
princípio do cuidado ferido: a dimensão maternal e feminina deformada pela exclusão social. O
manto torna-se símbolo do invisível — o tecido que separa o mundo daquilo que não pode ser
nomeado.
⸻
2. Contexto histórico e social
O mito da Maria da Manta surge num contexto histórico de forte religiosidade e repressão moral,
sobretudo nas comunidades rurais do Minho e Trás-os-Montes entre os séculos XVII e XIX. Numa
sociedade marcada pela vigilância comunitária, a mulher viúva, solteira ou independente era
frequentemente alvo de suspeita. As “marias do manto”, mulheres que usavam capas negras
para se proteger do frio e da censura social, tornaram-se arquétipo da alteridade feminina:
discretas, solitárias, misteriosas.
As fontes paroquiais e inquisitoriais referem múltiplas “mulheres de manto” acusadas de feitiçaria,
melancolia ou loucura. Essas figuras, marginalizadas, alimentaram o imaginário popular,
transformando-se em personagens míticas. O medo da Maria da Manta é, portanto, o medo da
mulher livre — aquela que anda sozinha à noite, que fala baixo mas sabe demais, que acolhe e
ameaça simultaneamente.
No plano social, a lenda funcionava como instrumento de controle comportamental infantil.
Contar às crianças que “a Maria da Manta leva quem anda fora de casa” servia para manter a
disciplina familiar. Mas, sob essa camada moral, esconde-se uma dimensão mais profunda: o
reconhecimento de uma presença feminina arcaica, ligada às forças noturnas e lunares.
Os estudos de Leite de Vasconcelos (Etnografia Portuguesa, vol. II, 1913) e Consiglieri Pedroso
(Contribuições para uma Mitologia Popular Portuguesa, 1897) apontam para a continuidade entre
as Marias do manto e as antigas “donas de capa” dos rituais medievais de fertilidade e cura.
Nessas cerimónias, o manto era símbolo da passagem entre a vida e a morte, entre o calor e o
frio.


Com o passar dos séculos, a Maria da Manta sobreviveu como lenda moral e figura carnavalesca.
Em algumas freguesias de Arcos de Valdevez e Bragança, é ainda representada em procissões
noturnas, carregando uma lanterna e um manto gigante. Essa teatralidade demonstra a resiliência
do mito, transformando o medo em celebração.
Para a Associação  MILK, o mito é hoje interpretado como espelho das estruturas de exclusão e
cuidado — a mulher que a sociedade teme é a mesma que a sustenta.
⸻
3. Toponímia e variantes locais
A presença da Maria da Manta é atestada em múltiplos topónimos e versões regionais:
– Arcos de Valdevez – “Fonte da Manta”, onde se diz que a mulher aparece penteando-se à
meia-noite;
– Bragança – “Vale da Maria”, lugar de nevoeiros espessos;
– Vila Real – “Caminho das Mantas”, antigo trilho de pastores;
– Mirandela – “Poço da Manta”, fonte profunda onde se ouviam vozes femininas;
– Chaves – “Lomba da Maria da Manta”, associada a ruídos noturnos e cheiros de alfazema.
Variedades linguísticas incluem Maria Manta, Maria das Capas e Mulher do Manto. Em certas
aldeias do Minho, o nome “Maria” é substituído por “Ana” ou “Teresa”, mas o arquétipo mantém-
se: mulher envolta em pano escuro, mediadora entre mundos.
⸻
4. Primeiro relato e fontes académicas primárias
O primeiro registo escrito conhecido da Maria da Manta surge em Teófilo Braga, O Povo
Português  nos seus Costumes, Crenças e Tradições (1883, p. 497), sob a forma de nota
etnográ fica: “Em terras do Minho fala-se de uma Maria coberta de manto que aparece aos
caminhantes, ora para os guiar, ora para os extraviar.”
José Leite de Vasconcelos (Etnografia Portuguesa, vol. II, 1913) descreve-a como “fantasma
feminino de manto negro, intermediário entre as mouras encantadas e as almas penadas”.
Consiglieri Pedroso (1897) classifica-a como “variante moderna da lamia ibérica”, associando o
manto ao ventre animal das antigas deusas da noite.
Alexandre Parafita, em Mitologia Popular Portuguesa (2008), analisa a Maria da Manta como
“figura liminar entre o terror e a ternura”.
Mauer e Araújo propõem a leitura da Maria da Manta como “mãe invertida”, cuja função
simbólica é revelar as feridas do cuidado — o amor reprimido, o medo projetado, o abrigo que se
transforma em prisão.
Fontes complementares:
– Arquivo Municipal de Arcos de Valdevez, Livro de Lendas e Costumes (1857);
– DGPC, Inventário do Património Imaterial, registo “Mulheres de Manto” (2018);
– Tese de Doutoramento de Inês Loureiro, A Sombra Materna: Figurações do Feminino no
Folclore do Norte de Portugal (U. do Minho, 2019).
⸻
5. Síntese interpretativa final
A Maria da Manta é a sombra do lar e da memória, a encarnação dos medos e afetos que
estruturam a vida comunitária. A sua ambiguidade — entre cuidado e castigo — re flete a

complexidade do amor humano e do feminino social. É a mãe que a aldeia teme e, ao mesmo
tempo, invoca.
Na leitura contemporânea da Associação  MILK, a Maria da Manta é símbolo de reconciliação
com a sombra: o reconhecimento das feridas históricas da mulher e da noite. O seu manto deixa
de ocultar para acolher; transforma-se em metáfora da proteção radical.
Na escultura MILK concebida por Eduardo Mauer e Nuno Araújo, a Maria da Manta apresenta
corpo compacto, cabeça grande, expressão serena e olhos luminosos sob um manto negro
translúcido. O sorriso é enigmático e o gesto das mãos — ora aberto, ora recolhido — traduz a
tensão entre abrigar e libertar.
⸻
6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer
A abordagem não binária proposta por Eduardo Mauer e Nuno Araújo vê na Maria da Manta o
corpo-ponte entre o masculino e o feminino, o calor e o frio, a presença e a ausência. O manto,
que cobre e revela, é símbolo do entre-lugar, o espaço da fluidez identitária.
A figura recusa a definição: é mulher e sombra, abrigo e ameaça, humano e espírito. Essa
indefinição faz da Maria da Manta um ícone da não  binariedade simbólica — o ser que não
cabe em nenhuma categoria e, por isso mesmo, revela a totalidade.
Mauer propõe ler o manto como “pele expandida do corpo queer”: superfície que protege da
violência e, simultaneamente, a firma o direito à visibilidade. O medo que a Maria inspira é o medo
do corpo livre — o corpo que não se submete às formas impostas.
Ao reintroduzir o mito no discurso artístico contemporâneo, a Associação  MILK transforma a
Maria da Manta em alegoria da identidade plural: cada pessoa é um manto em movimento, um
tecido de luz e sombra em busca de aceitação.
⸻
7. Referência Estrutural da Matriz MILK
Na Matriz Escultórica MILK, a Maria da Manta é concebida como figura envolta num grande
manto esculpido, que se funde ao corpo compacto da série Folclore Vivo. A cabeça,
desproporcional e expressiva, mantém o olhar sereno; o sorriso é quase invisível. As cores
predominantes — preto, cinza-azulado e lilás metálico — evocam a noite, o mistério e a ternura.
O acabamento é fosco, com áreas brilhantes simulando o re flexo do luar.
Em instalação expositiva, a peça deve surgir em penumbra, sob som ambiente de vento e água,
representando o sussurro do manto em movimento.
⸻
Localização  específica: Alto Minho (Arcos de Valdevez, Viana do Castelo), Trás-os-Montes
(Bragança, Mirandela, Vila Real).
Primeiro relato documentado: Teófilo Braga, O Povo Português  nos seus Costumes, Crenças e
Tradições, 1883.
Fontes primárias:  Braga (1883); Vasconcelos (1913); Pedroso (1897); Parafita (2008); Loureiro
(2019);
