# 004. O Fradinho da Mão Furada (Trás-os-Montes e Douro)

**Base documental e empírica:** pesquisa documental, análise comparada de fontes públicas, sistematização de tradição oral, relatos orais de pesquisa de campo e revisão semântica conduzidas no âmbito do Folclore Vivo da Associação MILK - Movimento de Intervenções e Linguagens Kulturais e Arte.
**Estado editorial:** corpus de pesquisa de campo e documentação cultural em revisão pública.
**Regra de publicabilidade:** esta entrada não deve ser lida como prova histórica definitiva, inventário patrimonial oficial, validação etnográfica concluída ou certificação académica externa sem verificação documental própria.
**Regra jurídica/RGPD:** não publicar nomes de informantes, contactos, moradas, entrevistas integrais, imagens identificáveis, gravações, dados de menores, coordenadas sensíveis ou materiais comunitários sem autorização.
**Regra de não invenção:** a presente readequação corrige a camada editorial e metodológica sem acrescentar factos, fontes, topónimos, coordenadas ou relatos não existentes no corpus-base.
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

4. O Fradinho da Mão Furada (Trás-os-Montes e Douro)
(Sistematização  contemporânea  conduzida por Eduardo Mauer e Nuno Araújo no âmbito  das
pesquisas sobre Folclore Vivo da Associação  MILK – Movimento de Intervenções e Linguagens
Kulturais e Arte)
⸻
1. Descrição  simbólica e narrativa
O Fradinho da Mão  Furada é uma das figuras mais emblemáticas e inquietantes do folclore
transmontano e duriense. O seu nome, à primeira vista risível, oculta um conjunto de signi ficados
morais, espirituais e metafísicos de rara densidade. Conhecido também como fradinho travesso,
mongezinho ou padrezinho de sombra, trata-se de um espírito diminuto, geralmente masculino,
vestido com hábito franciscano ou dominicano, rosto miúdo e expressão zombeteira, cuja mão
direita possui um orifício que atravessa toda a palma.


Segundo as narrativas orais recolhidas por Eduardo Mauer e Nuno Araújo nas zonas de
Bragança, Murça e Peso da Régua, o Fradinho aparece durante a noite nas casas das aldeias,
aproximando-se do lume ou das camas, sempre com intenção ambígua: ora ajuda os moradores,
arrumando a cozinha e acendendo o fogo, ora lhes prega partidas, misturando farinha com cinza
ou trocando os sapatos. A sua presença é reconhecida pelo som de pequenos passos e pelo riso
abafado que ecoa nas paredes.
A característica da “mão furada” é o traço de finidor do mito. A mão perfurada impossibilita o
toque pleno, simbolizando a incapacidade de reter — o Fradinho não consegue segurar objetos,
dinheiro ou alimento; tudo lhe escapa entre os dedos. Este detalhe transforma a lenda numa
parábola moral sobre a avareza e a impermanência: aquele que tudo quer possuir, perde tudo.
Por outro lado, o orifício na mão pode ser lido como estigma sagrado, lembrando as chagas de
Cristo. Essa duplicidade — pecado e santidade, riso e sofrimento — constitui o cerne da figura.
O Fradinho é simultaneamente tentador e penitente, espelho grotesco do próprio clero.
Em algumas versões antigas, o Fradinho teria sido um monge que roubou pão do convento e foi
amaldiçoado: condenado a vagar até o fim dos tempos, com a mão vazada para nunca mais
poder reter o que não lhe pertence. Noutras variantes, é um espírito benevolente, vítima de falsa
acusação, que ajuda as famílias pobres em troca de preces.
O mito, portanto, move-se entre extremos: da sátira anticlerical ao conto moral, da superstição
doméstica à alegoria teológica. Para Eduardo Mauer e Nuno Araújo, o Fradinho representa a
sombra ética da religiosidade popular — o lado humano e falível da fé que, ao ser
ridicularizado, torna-se mais próximo e verdadeiro.
⸻
2. Contexto histórico e social
A origem do Fradinho remonta à Idade Média, período em que o clero detinha poder social e
simbólico nas comunidades rurais. Os monges mendicantes, que percorriam o Norte de Portugal
pregando e pedindo esmolas, inspiraram respeito e desconfiança. A sua presença constante nas
aldeias gerou tanto devoção quanto sátira. O povo criou versões caricaturais desses frades —
pequenos, gananciosos, curiosos —, transformando-os em personagens do imaginário moral.
Durante os séculos XVII e XVIII, com a decadência dos conventos e a repressão inquisitorial, o
Fradinho consolidou-se como espírito doméstico punitivo. As famílias acreditavam que o
fradinho visitava as casas para testar a honestidade dos moradores. As crianças eram advertidas:
“Não mintas, que o Fradinho tem a mão furada e vê tudo.”
Os estudos etnográ ficos de Leite de Vasconcelos (Etnografia Portuguesa, vol. II, 1913) e Teófilo
Braga (Contos Tradicionais do Povo Português , 1883) revelam que o mito era particularmente
forte nas margens do Douro e de Trás-os-Montes, áreas de intensa religiosidade popular. O
Fradinho surge como herdeiro direto das lendas medievais sobre monges penitentes e fantasmas
de conventos.
No século XIX, com o anticlericalismo republicano, a figura foi reinterpretada como crítica social:
o pequeno frade travesso simbolizava a hipocrisia religiosa e a corrupção moral. Nas narrativas
mais recentes, recolhidas por Mauer, o Fradinho perdeu o tom punitivo e tornou-se símbolo do
humor e da ironia rural, sendo invocado para explicar acontecimentos domésticos inexplicáveis:
pratos que caem, luzes que oscilam, portas que rangem.
Para a Associação  MILK, o Fradinho é hoje lido como figura de desobediência e sabedoria
popular, símbolo do riso que desarma o dogma e devolve à fé a sua dimensão humana.
⸻


3. Toponímia e variantes locais
A tradição do Fradinho está amplamente disseminada no Norte, especialmente em Vila Real,
Murça, Alijó, Régua, Mogadouro e Bragança. Lugares como a Fonte do Fradinho (Vila Real), a
Capela do Mão  Furada (Murça) e a Casa do Mongezinho (Peso da Régua) são citados em
relatos orais e arquivos locais.
Existem variantes notáveis: o Fradinho das Chamas (em Vilar de Perdizes), que aparece junto ao
fogo; o Frade de Ouro (em Alijó), espírito protetor das colheitas; e o Fradinho dos Sinos (em
Lamego), que toca os sinos de madrugada para avisar de tempestades.
A versão duriense associa o Fradinho às caves do vinho do Porto — diz-se que ele protege os
tonéis e faz barulho quando a safra é boa. Essa adaptação demonstra a vitalidade e a
capacidade de reinvenção do mito no contexto económico local.
⸻
4. Primeiro relato e fontes académicas primárias
O primeiro relato escrito conhecido do Fradinho da Mão Furada aparece em Teófilo Braga,
Contos Tradicionais do Povo Português , vol. II (1883), sob o título “O Fradinho Travesso”. Braga
recolheu o conto em Murça e descreveu o ser como “espírito de frade pequeno, penitente e
folgazão”.
Leite de Vasconcelos (Etnografia Portuguesa, vol. II, 1913) inclui a figura entre os “duendes de
hábito religioso”, destacando a simbologia da mão vazada.
Consiglieri Pedroso, Contribuições para uma Mitologia Popular Portuguesa (1897), aponta a
semelhança com os monacillos espanhóis e os brownies escoceses.
Alexandre Parafita, Mitologia Popular Portuguesa (2008), interpreta o Fradinho como “síntese
entre moral cristã e humor pagão”.
A sistematização contemporânea foi conduzida por Eduardo Mauer e Nuno Araújo no estudo O
Fradinho e o Riso: Ironia, Fé  e Dissidência  no Norte de Portugal (Associação MILK, 2024),
resultado de pesquisa de campo e análise simbólica comparada. Mauer propõe que o orifício na
mão representa a falha sagrada — a imperfeição que torna o humano divino.
Fontes complementares:
– Arquivo Distrital de Vila Real, Caderno de Lendas Religiosas (1878);
– Museu de Lamego, coleção “Imaginário Popular e Iconogra fia Religiosa”;
– Tese de Mestrado de Tiago Pereira, O Humor e o Sagrado nas Lendas Transmontanas (UTAD,
2017).
⸻
5. Síntese interpretativa final
O Fradinho da Mão Furada sintetiza a essência do folclore português: humor e transcendência
coexistindo no mesmo corpo. Ele ri do poder, mas mantém o gesto devoto. É caricatura e
bênção. A sua mão furada é ferida e graça; é a abertura por onde passa a luz.
Para a Associação  MILK, o mito adquire valor contemporâneo como figura da resistência
cultural: o riso popular que desarticula hierarquias. O Fradinho é a consciência que o sagrado tem
de si próprio — uma gargalhada divina.


Na escultura MILK, concebida por Eduardo Mauer e Nuno Araújo o Fradinho é representado
com hábito castanho estilizado, cabeça grande, expressão maliciosa e palma perfurada que
deixa passar a luz. As cores predominantes são castanho, dourado e vermelho-ferrugem.
6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer
Na leitura não binária desenvolvida por Eduardo Mauer e Nuno Araújo, o Fradinho da Mão
Furada é símbolo da fluidez entre fé e desejo, corpo e espírito, masculino e feminino. Apesar
de vestido de frade, sua voz e gestos oscilam entre a delicadeza e a irreverência. Ele transcende
o género e o estatuto religioso: é o monge que ri do seu voto, o corpo que habita a culpa e a
transforma em liberdade.
O orifício da mão torna-se metáfora visual da ausência produtiva: o vazio que não nega, mas
expande. É o espaço por onde passam as identidades e onde o binário se dissolve. Para Mauer,
o Fradinho representa “a santidade queer” — a possibilidade de ser sagrado e profano ao mesmo
tempo.
Essa interpretação insere-se na filosofia da Associação  MILK, que vê o folclore como território
fluido. O Fradinho, ao rir, desarma o dogma e restitui ao corpo o direito de existir fora das
categorias rígidas.
7. Referência Estrutural da Matriz MILK
Na Matriz Escultórica MILK, o Fradinho da Mão Furada segue o cânone da série Folclore Vivo:
cabeça grande e expressiva, corpo compacto, braços curtos e mão direita perfurada que deixa
ver o interior oco. O sorriso é sarcástico e terno; o hábito, estilizado com acabamento em verniz
acetinado. A peça deve ser iluminada por baixo, para que a luz atravesse o orifício, simbolizando
o trânsito entre o visível e o invisível.
Localização  específica: Trás-os-Montes e Douro (Murça, Vila Real, Régua, Bragança, Lamego).
Primeiro relato documentado: Teófilo Braga, Contos Tradicionais do Povo Português , vol. II,
1883.
Fontes primárias:  Braga (1883); Vasconcelos (1913); Pedroso (1897); Parafita (2008); Pereira
(2017); Mauer (2024).
