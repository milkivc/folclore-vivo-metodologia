# 105. A Lenda do Galo de Ouro de Chaves (Trás-os-Montes  – Vale do Tâmega)

**Base documental e empírica:** pesquisa documental, análise comparada de fontes públicas, sistematização de tradição oral, relatos orais de pesquisa de campo e revisão semântica conduzidas no âmbito do Folclore Vivo da Associação MILK - Movimento de Intervenções e Linguagens Kulturais e Arte.
**Estado editorial:** corpus de pesquisa de campo e documentação cultural em revisão pública.
**Regra de publicabilidade:** esta entrada não deve ser lida como prova histórica definitiva, inventário patrimonial oficial, validação etnográfica concluída ou certificação académica externa sem verificação documental própria.
**Regra jurídica/RGPD:** não publicar nomes de informantes, contactos, moradas, entrevistas integrais, imagens identificáveis, gravações, dados de menores, coordenadas sensíveis ou materiais comunitários sem autorização.
**Regra de não invenção:** a presente readequação corrige a camada editorial e metodológica sem acrescentar factos, fontes, topónimos, coordenadas ou relatos não existentes no corpus-base.
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

105. A Lenda do Galo de Ouro de Chaves (Trás-os-Montes  – Vale do Tâmega)
(Sistematização  contemporânea  conduzida por Eduardo Mauer no âmbito  das pesquisas sobre
Folclore Vivo da Associação  MILK – Movimento de Intervenções e Linguagens Kulturais e Arte,
com base em recolhas orais e documentais realizadas entre 2023 e 2025 em Chaves, Oura,
Vidago e Vilar de Nantes, cruzadas com fontes etnográ ficas do Museu da Região  Flaviense, do
Arquivo Municipal de Chaves e de estudos académicos  sobre simbolismo animal, lendas de
tesouros e imaginário  solar no norte de Portugal.)
⸻
1. Descrição  simbólica e narrativa
Entre as muralhas romanas de Chaves, antiga Aquae Flaviae, circula há séculos uma história
sobre um galo que canta debaixo da terra. Diz-se que o seu corpo é de ouro puro, mas o canto
é feito de luz, e que quem o escutar ao amanhecer jamais esquecerá o som — mistura de
esperança e aviso. É o Galo de Ouro de Chaves, entidade solar, guardiã de tesouros escondidos
e símbolo de renovação.


Segundo os relatos coligidos por Eduardo Mauer (2024), o galo habita um túnel subterrâneo que
liga as termas romanas ao antigo castelo. Em noites de lua cheia, o som de um leve cacarejo
metálico é ouvido sob o chão. Alguns a firmam que o galo canta sempre que o ouro da terra está
prestes a ser descoberto; outros dizem que o seu canto é prenúncio de guerra ou mudança.
A versão mais antiga da lenda conta que, durante o domínio romano, um ferreiro de Aquae
Flaviae teria fabricado um galo de ouro maciço como oferenda ao deus Júpiter. No entanto, os
soldados visigodos, ao invadir a cidade, enterraram-no para impedir que fosse saqueado. O galo
teria então ganhado vida, assumindo o dever de proteger o tesouro e o espírito da cidade.
Outras versões, recolhidas na aldeia de Oura, afirmam que o Galo de Ouro aparece no nascer do
sol de São João, quando o nevoeiro cobre o Tâmega. Quem o vir e o seguir até o seu esconderijo
encontrará “o ouro que não é para gastar”, expressão popular para designar o ouro simbólico
do renascimento interior.
Há ainda variantes cristianizadas que associam o galo ao milagre da inocência: conta-se que,
durante a Inquisição, um homem injustamente condenado à forca teria sido salvo pelo canto de
um galo assado que ressuscitou no prato do juiz — episódio semelhante ao famoso Galo de
Barcelos, mas aqui reinterpretado na tradição flaviense.
O mito do Galo de Ouro, portanto, entrelaça dois temas fundamentais: o tesouro oculto e o
canto solar da verdade. Em Chaves, é comum ouvir-se a expressão: “Quando o Galo de Ouro
cantar, a cidade acordará outra vez.”
Nas palavras de Mauer: “O Galo de Ouro é o eco solar que vive no subsolo — metáfora do
inconsciente coletivo de uma cidade que guarda, sob as ruínas, a promessa da sua própria luz.”
⸻
2. Contexto histórico e social
Chaves, situada no vale do Tâmega, foi desde a Antiguidade uma cidade termal e estratégica. O
seu subsolo guarda vestígios romanos, minas de ouro, galerias subterrâneas e restos de
aquedutos, o que explica o surgimento de lendas associadas ao ouro enterrado e guardado por
entidades mágicas .
Durante o período medieval, a região era ponto de passagem entre reinos e fronteiras, palco de
guerras e ocupações. A crença em guardiões subterrâneos surgiu como resposta simbólica à
instabilidade histórica. O galo, animal solar e vigilante, tornou-se guardião natural desses
espaços.
Na iconografia portuguesa, o galo é símbolo de vigilância  e ressurreição : anuncia o amanhecer
e afasta os maus espíritos. A sua associação ao ouro reforça a dimensão solar — metal do sol,
da claridade e da verdade. Em Chaves, essas camadas simbólicas cruzam-se com a herança
romana, onde o galo era consagrado a Mercúrio, deus das passagens e dos segredos ocultos.
O mito foi transmitido oralmente por famílias de ferreiros, mineiros e artesãos que trabalhavam o
metal e acreditavam na sua alma. Em tempos de fome, o galo tornou-se esperança: acreditava-
se que ele cantaria quando o povo voltasse a prosperar.
No século XX, a lenda foi reinterpretada por artistas locais e, recentemente, revalorizada pela
Associação  MILK, que a integra no ciclo “Animais de Luz”, explorando o galo como símbolo da
regeneração e da força criadora do povo flaviense.
⸻
3. Toponímia e variantes locais
A lenda apresenta múltiplas versões e extensões geográ ficas:


– Galo de Ouro (Chaves): figura central, subterrânea e solar;
– Galo de Luz (Oura): galo que canta apenas ao amanhecer do solstício;
– Galo do Tesouro (Vidago): protetor de minas abandonadas;
– Galo das Águas  (Vilar de Nantes): guardião das nascentes termais, de corpo dourado e crista
azul.
Topónimos como “Fonte do Galo”, “Ladeira do Tesouro” e “Poço do Ouro” aparecem em
registos municipais desde o século XVIII, indicando a antiguidade da crença. Há referências a um
antigo Arco do Galo, desaparecido no século XIX, onde, segundo crónicas locais, os viajantes se
benziam ao passar.
As variantes partilham o mesmo núcleo simbólico: o ouro como luz interior e o galo como
mediador entre escuridão  e claridade, entre o subterrâneo e o solar.
⸻
4. Primeiro relato e fontes académicas primárias
O primeiro relato escrito do Galo de Ouro de Chaves surge em Leite de Vasconcelos,
Etnografia Portuguesa, vol. IX (1925, pp. 161–167)*, onde se lê: “Em Chaves, fala-se dum galo de
ouro que canta sob as termas quando o sol desponta.”
Teófilo Braga, O Povo Português  nos seus Costumes, Crenças e Tradições (1885, pp. 764–770)*,
menciona “galos de ouro soterrados em cidades antigas” como símbolos de vigilância e
esperança, especialmente em Chaves e Lamego.
Alexandre Parafita, Mitologia Popular Portuguesa (2008, pp. 991–1003)*, dedica extenso estudo
ao mito, relacionando-o com cultos solares e tradições de renascimento, sublinhando o seu
caráter “solar e alquímico”.
A sistematização contemporânea de Eduardo Mauer, O Galo de Ouro de Chaves: Luz e
Subterrâneo  no Imaginário  Flaviense (Lisboa, Associação MILK, 2025)*, propõe uma leitura
simbólica centrada no ouro como metáfora da consciência coletiva, articulando mitologia,
arqueologia e arte contemporânea.
Fontes complementares:
– Museu da Região Flaviense, Coleção  de Lendas Urbanas de Aquae Flaviae (1970–2020);
– Arquivo Municipal de Chaves, Crónicas de Ouro e Fogo (séculos XVII–XIX);
– Tese de Doutoramento de Beatriz Cordeiro, Mitologias do Subterrâneo:  Ouro e Memória nas
Lendas do Norte de Portugal (U. Minho, 2019).
⸻
5. Síntese interpretativa final
O Galo de Ouro é símbolo de claridade interior e vigilância espiritual. Representa a promessa de
que, mesmo enterrada, a luz não se apaga. É, simultaneamente, guardião e anúncio: protege o
ouro (a sabedoria) e canta o novo dia (a esperança).
Na leitura simbólica da Associação  MILK, o galo é o sol subterrâneo , o arquétipo do despertar
coletivo. O seu canto, metálico e luminoso, é metáfora da voz criadora que rompe o silêncio.
A escultura MILK concebida por Eduardo Mauer segue a matriz padrão, com corpo compacto,
cabeça grande e crista estilizada. O corpo é dourado, com texturas que evocam escamas
metálicas, e o olhar ergue-se para o alto. O pedestal simula o subsolo, com fendas que deixam
escapar feixes de luz dourada.


Mauer descreve: “O Galo de Ouro não canta para anunciar o sol — ele é o sol a tentar ser
ouvido.”
⸻
6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer
Na leitura não binária de Eduardo Mauer, o Galo de Ouro ultrapassa a oposição entre noite e
dia, sombra e luz, matéria e espírito.
“O Galo é o corpo não binário da claridade: vive no escuro, mas é feito de luz.”
O mito propõe uma ética de coexistência: a luz subterrânea não nega a escuridão, antes a
habita e a transforma. Essa leitura é aplicada pela Associação  MILK às práticas artísticas
e pedagógicas que exploram o poder da voz e da luminosidade interior como
instrumentos de emancipação e cuidado.
O Galo de Ouro torna-se, assim, símbolo contemporâneo da criatividade não binária —
força que brota do invisível, mediando contrários e forjando harmonia.
⸻
7. Referência Estrutural da Matriz MILK
Na Matriz Escultórica MILK – Série Folclore Vivo, o Galo de Ouro de Chaves apresenta:
– Corpo: compacto, cabeça grande e crista elevada;
– Cores: dourado metálico com re flexos em cobre e vermelho;
– Materiais: resina pigmentada com pó de bronze e folha de ouro aplicada;
– Expressão:  altiva e serena;
– Base: circular, em tons terrosos, com fendas luminosas simulando o subsolo.
A escultura integra o eixo “Animais de Luz” do projeto Folclore Vivo, dedicado às entidades
luminosas e solares que simbolizam esperança, vigilância e criação.
⸻
Localização  específica: Chaves, Oura, Vidago e Vilar de Nantes (distrito de Vila Real).
Primeiro relato documentado: Vasconcelos, Etnografia Portuguesa, vol. IX, 1925.
Sistematização  contemporânea:  Eduardo Mauer, O Galo de Ouro de Chaves: Luz e Subterrâneo
no Imaginário  Flaviense, Associação MILK, 2025.
Fontes primárias:  Braga (1885); Vasconcelos (1925); Parafita (2008); Cordeiro (2019); Mauer
(2025).
