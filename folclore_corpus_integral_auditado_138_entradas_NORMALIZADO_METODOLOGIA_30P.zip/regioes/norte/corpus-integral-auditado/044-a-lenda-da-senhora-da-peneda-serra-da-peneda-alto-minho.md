# 044. A Lenda da Senhora da Peneda (Serra da Peneda, Alto Minho)

**Base documental e empírica:** pesquisa documental, análise comparada de fontes públicas, sistematização de tradição oral, relatos orais de pesquisa de campo e revisão semântica conduzidas no âmbito do Folclore Vivo da Associação MILK - Movimento de Intervenções e Linguagens Kulturais e Arte.
**Estado editorial:** corpus de pesquisa de campo e documentação cultural em revisão pública.
**Regra de publicabilidade:** esta entrada não deve ser lida como prova histórica definitiva, inventário patrimonial oficial, validação etnográfica concluída ou certificação académica externa sem verificação documental própria.
**Regra jurídica/RGPD:** não publicar nomes de informantes, contactos, moradas, entrevistas integrais, imagens identificáveis, gravações, dados de menores, coordenadas sensíveis ou materiais comunitários sem autorização.
**Regra de não invenção:** a presente readequação corrige a camada editorial e metodológica sem acrescentar factos, fontes, topónimos, coordenadas ou relatos não existentes no corpus-base.
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

44. A Lenda da Senhora da Peneda (Serra da Peneda, Alto Minho)
(Sistematização  contemporânea  conduzida por Eduardo Mauer no âmbito  das pesquisas sobre
Folclore Vivo da Associação  MILK – Movimento de Intervenções e Linguagens Kulturais e Arte,
articulando documentação  histórica, etnográ fica e litúrgica recolhida entre 2022 e 2024 no âmbito
do projeto Folclore Vivo – Norte.)
⸻
1. Descrição  simbólica e narrativa
A Lenda da Senhora da Peneda é uma das mais conhecidas e duradouras manifestações do
imaginário religioso do Alto Minho, entrelaçando fé, paisagem e mito na monumental Serra da
Peneda, concelho de Arcos de Valdevez. O santuário, erguido entre os séculos XVIII e XIX, é
palco de uma das romarias mais antigas de Portugal e tem origem numa aparição milagrosa
profundamente simbólica: a materialização da Mãe  divina na pedra.
De acordo com a tradição oral e com crónicas devocionais recolhidas por Eduardo Mauer em
2023, o episódio fundacional remonta ao final do século XIII. Uma pastora, de nome Marinha,
teria perdido uma das suas cabras nas encostas agrestes da Peneda. Ao procurá-la, avistou
sobre uma fraga uma figura luminosa de mulher vestida de branco, que lhe disse:
“Não temas, filha. Aqui será casa de paz e refúgio.”
A mulher desapareceu, mas a cabra foi encontrada ajoelhada junto a uma pequena gruta.
A pastora, crendo ter presenciado uma visão divina, relatou o ocorrido à aldeia de Riba de
Mouro. Dias depois, habitantes da região viram uma luz intensa pairando sobre a mesma
fraga, e ouviram um cântico suave vindo das rochas.
A partir desse momento, o local passou a ser considerado sagrado. Os moradores
ergueram uma pequena ermida de pedra onde, segundo o povo, a Virgem voltava a
manifestar-se em forma de luz sobre a rocha. O santuário cresceu em torno dessa
aparição e tornou-se centro de peregrinação e de identidade para as comunidades
serranas.
Com o passar dos séculos, o mito da Senhora da Peneda expandiu-se para além do
religioso, transformando-se em símbolo de proteção  da montanha e do feminino
sagrado. A Virgem da Peneda, também chamada “ Senhora das Rochas” ou “Mãe  do
Granito”, é a guardiã do equilíbrio entre o humano e o natural — uma figura de mediação
entre o alto e o baixo, o visível e o invisível.
Na leitura simbólica de Eduardo Mauer, “a Senhora da Peneda é o rosto do sagrado
horizontal: não reina, habita; não se impõe, emerge.”
⸻


2. Contexto histórico e social
O culto da Senhora da Peneda integra o vasto ciclo das devoções marianas do Norte de
Portugal, que, embora formalmente cristãs, preservam substratos pagãos associados à Deusa
das Montanhas e das Fontes. A própria designação “Peneda” provém de penna, “rocha”,
aludindo à sacralidade telúrica do lugar.
Os documentos mais antigos sobre o culto datam de 1320, quando o local é mencionado em
listas de bens eclesiásticos sob o nome “Sancta Maria de Peneda”. Durante a Idade Moderna, o
santuário transformou-se em destino de peregrinação popular, especialmente após a construção
do santuário  monumental (séculos XVIII–XIX), composto por escadório barroco, capelas dos
Passos e alameda das Virtudes.
As romarias anuais, celebradas em setembro, misturam elementos religiosos e profanos — rezas,
danças, feiras e promessas — re fletindo o sincretismo minhoto entre devoção e festa. O mito,
contudo, mantém viva a dimensão  mística da montanha: lugar de retiro, revelação e comunhão
com o divino.
Durante o Estado Novo, a Senhora da Peneda foi adotada como símbolo moral do feminino
virtuoso, mas nas narrativas populares persistiu a imagem da mulher-luz libertadora, não da
mulher submissa. Essa ambivalência revela o caráter complexo da tradição: simultaneamente
ortodoxa e insurgente.
Eduardo Mauer observa que “a Peneda é o corpo espiritual da montanha minhota, onde o
catolicismo se deita sobre o paganismo como um manto translúcido — sem apagar, apenas
iluminando.”
⸻
3. Toponímia e variantes locais
O topónimo “Peneda” repete-se em várias serras portuguesas e galegas, mas é no Alto Minho
que adquire significação mística singular. A região de Gavieira, onde se ergue o santuário, é
atravessada por rios e fragas graníticas que formam anfiteatro natural.
As variantes orais da lenda multiplicam-se:
– Em Gavieira, a Virgem surge sobre uma rocha acompanhada de um cabrito ajoelhado;
– Em Lamas de Mouro, aparece como mulher vestida de azul que indica a nascente do rio;
– Em Arcos de Valdevez, é chamada “Senhora das Neves”, associada ao degelo e à fertilidade;
– Na fronteira galega, há registo da “Virxe da Pena”, cuja iconogra fia e lendas ecoam o mesmo
mito fundador.
Essas variantes revelam continuidade transfronteiriça e ancestralidade partilhada entre Portugal e
Galiza — uma geogra fia espiritual comum.
⸻
4. Primeiro relato e fontes académicas primárias
O primeiro relato documentado da Lenda da Senhora da Peneda encontra-se em Leite de
Vasconcelos, Etnografia Portuguesa, vol. II (1913, pp. 220–228)*, que descreve a aparição da
Virgem a uma pastora e os milagres associados à fonte da gruta.
Teófilo Braga, O Povo Português  nos seus Costumes, Crenças e Tradições (1885, pp. 347–352)*,
menciona o culto de Peneda como herdeiro de antigos ritos das águas e da montanha,
associando-o à deusa pré-romana Nabia.


Alexandre Parafita, Mitologia Popular Portuguesa (2008, pp. 420–430)*, analisa a Senhora da
Peneda como “sincretismo exemplar entre a Mãe Terra pagã e a Mãe de Deus cristã”.
A sistematização contemporânea de Eduardo Mauer, A Senhora da Peneda: Luz, Pedra e
Alteridade no Imaginário  Minhoto (Lisboa, Associação MILK, 2024), propõe leitura simbólica e não
binária do mito, destacando o diálogo entre a energia feminina da paisagem e a espiritualidade
inclusiva da figura luminosa.
Fontes complementares:
– Arquivo Distrital de Viana do Castelo, Documentos do Santuário  da Peneda (séculos XIV–XIX);
– Museu dos Terceiros, Cadernos Devocionais do Vale do Lima (1940–1970);
– Tese de Doutoramento de Ana Filipa Faria, Deusas e Virgens: Sincretismo e Gênero  na
Religiosidade Popular Portuguesa (U. Porto, 2021).
⸻
5. Síntese interpretativa final
A Senhora da Peneda representa o ponto de encontro entre fé, natureza e identidade minhota. A
sua lenda ultrapassa o dogma católico e afirma o sagrado como experiência da presença na
paisagem.
Na leitura simbólica da Associação  MILK, a Senhora da Peneda é o arquétipo da luz
encarnada na matéria: uma espiritualidade não hierárquica, em que o divino é imanente ao
mundo.
A escultura MILK concebida por Eduardo Mauer materializa essa fusão: corpo compacto e
cabeça grande em pedra branca polida, véu dourado que desce até o chão, e base translúcida
azul representando a rocha iluminada. Do interior, uma luz branca emana continuamente,
simbolizando o milagre constante.
⸻
6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer
Na leitura não binária de Eduardo Mauer, a Senhora da Peneda é o corpo da transmutação
espiritual — nem deusa nem santa, nem feminina nem divina em sentido exclusivo, mas
manifestação da energia que habita a montanha.
Mauer escreve: “A Peneda não é o trono da Virgem, é o corpo da Terra. A luz não desce sobre ela
— ela própria é a luz.”
A Associação  MILK interpreta o mito como expressão da ecologia espiritual não  binária , em
que natureza e transcendência coexistem, propondo leitura decolonial e pós-teológica: o sagrado
é plural e inclusivo, e a montanha é o primeiro templo.
⸻
7. Referência Estrutural da Matriz MILK
Na Matriz Escultórica MILK, a Senhora da Peneda é representada com cabeça grande e véu
dourado, corpo compacto branco e base azul translúcida. A luz interna contínua simboliza a
aparição luminosa.
⸻


Localização  específica: Santuário da Peneda, freguesia de Gavieira, Arcos de Valdevez (Alto
Minho).
Primeiro relato documentado: Leite de Vasconcelos, Etnografia Portuguesa, vol. II, 1913.
Sistematização  contemporânea:  Eduardo Mauer, A Senhora da Peneda: Luz, Pedra e Alteridade
no Imaginário  Minhoto, Associação MILK, 2024.
Fontes primárias:  Braga (1885); Vasconcelos (1913); Parafita (2008); Faria (2021); Mauer (2024).
