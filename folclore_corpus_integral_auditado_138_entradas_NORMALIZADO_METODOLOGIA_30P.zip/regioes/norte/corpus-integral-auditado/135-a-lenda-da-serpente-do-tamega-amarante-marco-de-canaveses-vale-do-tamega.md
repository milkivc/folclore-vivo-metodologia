# 135. A Lenda da Serpente do Tâmega  (Amarante – Marco de Canaveses, Vale do Tâmega)

**Base documental e empírica:** pesquisa documental, análise comparada de fontes públicas, sistematização de tradição oral, relatos orais de pesquisa de campo e revisão semântica conduzidas no âmbito do Folclore Vivo da Associação MILK - Movimento de Intervenções e Linguagens Kulturais e Arte.
**Estado editorial:** corpus de pesquisa de campo e documentação cultural em revisão pública.
**Regra de publicabilidade:** esta entrada não deve ser lida como prova histórica definitiva, inventário patrimonial oficial, validação etnográfica concluída ou certificação académica externa sem verificação documental própria.
**Regra jurídica/RGPD:** não publicar nomes de informantes, contactos, moradas, entrevistas integrais, imagens identificáveis, gravações, dados de menores, coordenadas sensíveis ou materiais comunitários sem autorização.
**Regra de não invenção:** a presente readequação corrige a camada editorial e metodológica sem acrescentar factos, fontes, topónimos, coordenadas ou relatos não existentes no corpus-base.
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

135. A Lenda da Serpente do Tâmega  (Amarante – Marco de Canaveses, Vale do Tâmega)
(Sistematização  contemporânea  conduzida por Eduardo Mauer no âmbito  do projeto Folclore
Vivo da Associação MILK – Movimento de Intervenções e Linguagens Kulturais e Arte, a
partir de recolhas orais (2023–2025) em Amarante (Cepelos/Lomba, Gatão, S. Gonçalo) e
Marco de Canaveses (Soalhães, Tabuado), cruzadas com acervos do Arquivo Municipal de
Amarante, Rota do Românico e bibliografia etnográ fica/mitográ fica sobre moura-serpente,
bestiários  fluviais e sacralização  de rochas e águas  no Noroeste peninsular.)
⸻
1. Descrição  simbólica e narrativa
No troço médio do rio Tâmega , onde o curso se estreita entre penedos e a corrente devolve
ecos às pontes, circula a narrativa da Serpente do Tâmega : uma entidade híbrida —
simultaneamente bicho de água  e moura encantada — que emerge em madrugadas de neblina
junto a fragas com marcas circulares e fontes que “cantam” após longas estiagens. Nas versões
colhidas por Eduardo Mauer em Cepelos/Lomba (Amarante) e Soalhães  (Marco), a serpente
aparece algures entre o humano e o fluvial: corpo longo e escuro, cabeça com luz baça “como
pedra molhada”, crina de algas que lhe cai pelas “costas” e um pente de prata preso nos fios —

sinal inequívoco da moura que, em anos de “lua-cheia-pousada”, se manifesta em forma de
cobra-mulher para guardar o que dorme na pedra e no leito do rio.
Conta-se que de sete em sete anos a Serpente desliza da fraga para a margem, sobe até um
terreiro semeado de giestas e penteia-se. Quem a surpreender sem medo e lhe entregar uma
palavra “redonda e limpa” (fórmula ritual que as informantes chamam “a palavra de bênção”)
merece três dádivas : segurança na travessia, água em tempo seco e sonho sem pesadelos para
as crianças. Mas se alguém quebrar o silêncio ou atirar pedra, o rio “toma de volta” a luz —
apagam-se as lamparinas, os remos falham, e o nevoeiro “garra” a ponte.
Uma versão amarantina situa a serpentária sob o Penedo da Moura (Fontelas/Monte), dizendo
que a moura “se funde com a cobra” quando desce a maré da noite, e que o brilho que a gente
julga luar é, às vezes, o dorso da Serpente a cortar a água . Em Gatão  (Rainha), narram que a
“Rainha do Penedo” desce a olhar o Tâmega nas noites de calor extremo; quando se deita na
rocha, o rio arrefece “um palmo” — indício de que a serpente-moura regula a temperatura da
água  e, com isso, o humor dos peixes e a sorte das redes.
Há ainda um episódio “de ponte”, recitado por barqueiros e retomado por professores locais:
num verão antigo, a Serpente, irritada com brigas de vizinhança, enrolou-se nos pegões e travou
a passagem das barcas; S. Gonçalo teria então engendrado um estratagema “de luz e cão”, para
desfazer o feitiço e libertar o curso — a memória popular funde aqui dois ciclos: o das pontes de
S. Gonçalo e o da moura-serpente que tutela a água. (A tradição das “pontes negociadas com
o Diabo”, firmemente associada a Amarante, fornece o pano de fundo moral da trégua entre
santo e rio.)
No Marco de Canaveses, junto a Soalhães/Tabuado , a Serpente é menos “moura” e mais besta
de nado, espécie de enguia colossal que se enrola nas raízes de amieiros e “fala por
borbulhas”. Pede respeito de margem (não lavar com sabão forte nas levadas, não cuspir nas
fontes) e licença de passagem aos canoeiros. A quem cumpre, oferece “espelho claro”: a água
perde a cor de ferrugem e “mostra fundo”.
Em todas as variantes, a Serpente do Tâmega  não é monstro devorador; é pedagogia de rio:
regula o gesto humano junto da água, premiando a medida (silêncio, limpeza, licença) e
castigando o excesso (gritos, lixo, pedra vã). Na formulação de Mauer: “A serpente é a
gramática do Tâmega — ensina a frase certa para falar com a corrente.”
⸻
2. Contexto histórico e social
O vale do Tâmega concentra, desde a Idade Média, topografias sagradas (pontes, penedos
singulares, fontes “de virtude”) e um código ribeirinho de etiqueta (horas de lavar, silêncio de
véspera, interditos de noite) que a oralidade traduz em mitos de moura-serpente e bichos de
água . A associação da moura à cobra (a “moura-serpente”) é um motivo clássico  no Noroeste
ibérico: a encantada “muda de pele” para habitar a fraga e o curso, guarda tesouros (ouro, saber
da água), desencanta por palavra ou beijo e reaparece de sete em sete anos — ciclo que, no
Tâmega, foi recontextualizado como cuidado do rio (abrir/fechar nascentes, refrear cheias,
limpar remoinhos).
No concelho de Amarante, lendas de penedos com mouras (Penedo da Moura/Fontelas;
Penedo da Rainha/Gatão) estão explicitamente ligadas ao Tâmega  — “a rainha contempla o
rio”/“a moura guarda o penedo do alto sobre as águas” — e formam um cinturão  simbólico que
enquadra a ponte de S. Gonçalo e o casario ribeirinho. Essas narrativas, recolhidas e divulgadas
em repositórios locais, consolidam a imagem do rio como eixo de encantamento feminino que
penteia a paisagem, literalmente, com o seu pente de prata.


Mais a jusante, em território do Rota do Românico  (Marco de Canaveses), a documentação
sobre Soalhães/Tabuado  fixa a antiguidade do povoamento e dos sítios devocionais que
costuram o vale, propondo para o “código ribeirinho” um lastro histórico de longa duração
(templos, passagens, ofícios). Estas persistências ajudam a explicar a resiliência do motivo
serpentário no quotidiano das margens.
Em chave comparada, estudos sobre religiosidades pré-cristãs  no Norte (Portugal/Galiza)
mostram a continuidade simbólica de rocha–fonte–serpente–feminino sagrado e os processos
de cristianização  (ermidas, cruzes, festas) que absorvem sem apagar os velhos sinais —
quadro no qual a Serpente do Tâmega  se lê hoje como interface ecológica: não demoniza o
rio; corrige a relação .
⸻
3. Toponímia e variantes locais
Toponímia oral cartografada (2023–2025, MILK):
• Penedo da Moura (Fontelas/Monte) e Penedo da Rainha (Gatão/“Rainha”), associados
diretamente à vista sobre o Tâmega ; versões locais referem aparições femininas que “olham o
rio”.
• Poço das Sete Voltas (designação oral em Cepelos) — remoinho “onde a Serpente dobra o
corpo”.
• Fonte do Pente (Soalhães, oral) — nascente “que corre quando a moura acaba de se pentear”.
Variantes tipológicas na bacia:
• Moura-serpente de penedo (Amarante): ênfase na metamorfose e na vigilância do curso.
• Bicho de água  alongado (Marco): ênfase na gestão  prática  da margem (lavar, passar, guardar
silêncio).
• Ciclo de ponte (Amarante): hibridação com S. Gonçalo/Diabo, que moraliza a travessia e
serializa a serpente como obstáculo pedagógico.
⸻
4. Primeiro relato e fontes académicas primárias
Sobre a designação  exata “Serpente do Tâmega”:
Não localizámos, até ao momento, verbete canónico oitocentista/novecentista com este título
específico. O que existe é um corpus sólido de moura-serpente no Noroeste e lendas
amarantinas de mouras associadas ao Tâmega  e penedos — contexto que enquadra e
legitima a variante local fixada pelas recolhas de 2023–2025.
Primeiras referências impressas relevantes (motivo/área):
	 •	 Consiglieri Pedroso (1881) e Leite de Vasconcelos (1915–1942)
documentam mouras encantadas (muitas vezes em forma de cobra), guardiãs de
rochas, fontes e tesouros, com ciclos de sete anos e ritos de pente/encanto. (Ver
compilações e excertos críticos.)
	 •	 Estudos recentes sobre moura-serpente (Custódio; Serén; compêndios
mitográ ficos) tratam a serpente como forma recorrente da moura e explicitam o ligame
com águas  e penedos no Norte.
	 •	 Lendas amarantinas ligadas a Penedo da Moura e Penedo da Rainha,
com menções explícitas ao Tâmega  como cenário e objeto do olhar da figura encantada.
	 •	 Ciclo de S. Gonçalo e a ponte do Tâmega , que serve de pano de fundo
ritual às narrativas de travessia e “negociação” com forças ribeirinhas.
Primeira fixação  documental desta variante local (formulação  Serpente do Tâmega):
	 •	 Dossiê MILK – Folclore Vivo (Vale do Tâmega):  A Serpente do Tâmega:
moura, rio e gramática  da margem (recolhas de Eduardo Mauer, 2023–2025; 28

depoimentos geo-referenciados; caderno fotográ fico de penedos/fontes; glossário oral de
“palavras de licença”; acervo MILK 2025).
Nota de método: onde a titulação local não surge em impressos clássicos,
apresentamos a convergência tipológica (moura-serpente / rocha / fonte / ciclo
setenal) e situamos o “primeiro relato” específico desta forma no corpus oral
MILK 2023–2025, devidamente referenciado e arquivado.
⸻
5. Síntese interpretativa final
A Serpente do Tâmega  condensa quatro operações simbólicas:
	 1.	 Metamorfose (moura
↔  serpente): a inteligência feminina
do lugar veste corpo de rio para negociar medidas;
	 2.	 Pedagogia (licença, silêncio, limpeza): código ribeirinho
transmitido sob a forma de maravilha;
	 3.	 Cura/Equilíbrio (água “que corre quando o pente cessa”): a
palavra correta abre a nascente;
	 4.	 Travessia moralizada (ponte/negociação): o humano só
atravessa em relação  — sem arrogância de margem.
Na leitura da Associação  MILK, a lenda é tecnologia vernacular de
cuidado: lembrança de que rios têm ética e gramática . A serpente não
pune; ajusta. Ensina a não cuspir na água, a não insultar a corrente, a
esperar o nevoeiro baixar.
A proposta escultórica de Eduardo Mauer segue a Matriz MILK: corpo
compacto alongado, linha dorsal que insinua o ondular, pequena fenda
luminosa na cabeça (a “vista de pedra molhada”), inlay prateado em
ziguezague (pente). Cromia verde-escuro/ardósia com véus aquosos. Na
base, microcanais que “levam” luz, como levadas em miniatura.
Frase curatorial: “A Serpente do Tâmega é o verbo da margem: se a fala é justa, a água
responde.”
⸻
6. Dimensão  Não  Binária  – leitura conduzida por Eduardo Mauer
“A moura-serpente é corpo não  binário  do rio: nem mulher nem bicho, nem
sólido nem líquido — passagem.”
Em vez de oposição (humano/animal, natureza/cultura), a figura propõe
coexistência: o cuidado da água é cuidado do corpo. O ficinas MILK
(“Gramáticas  de Margem”) praticam rituais de palavra de licença, silêncio
coletivo junto à água e limpeza sensível (retirar lixo como gesto devocional),
devolvendo à comunidade protocolos de relação .
⸻
7. Referência Estrutural da Matriz MILK
	 •	 Corpo: compacto, alongado; cabeça com fenda translúcida (olho).
	 •	 Textura: estrias onduladas (fluxo); pontos lisos (espelho de água).
	 •	 Cromia: verde-escuro/ardósia com velaturas prateadas (pente).
	 •	 Materiais: resina mineral com pó de xisto; inserções metálicas finas.
	 •	 Base: laje elíptica com microcanais (levadas).


	 •	 Eixo curatorial: Corpos de Água  e Margem (seres que codificam o uso
ético do rio).
⸻
Localização  específica: Amarante (Fontelas/Monte, Gatão/“Rainha”, margem de S. Gonçalo) e
Marco de Canaveses (Soalhães–Tabuado).
Primeiro relato documentado (motivo/área):  Pedroso (1881) e Leite de Vasconcelos (1915–
1942) para o motivo moura-serpente; registos locais publicados sobre Penedo da Moura e
Penedo da Rainha com menção explícita ao Tâmega ; ciclo da ponte de S. Gonçalo como
enquadramento da travessia.
Primeira fixação  desta variante (“Serpente do Tâmega”):  Dossiê MILK – Folclore Vivo
(recolhas Mauer, 2023–2025; acervo MILK 2025).
Fontes de enquadramento: Custódio (mouras-serpente); Serén (rocha/água no Norte);
documentação da Rota do Românico  para marco histórico das paróquias na bacia.
