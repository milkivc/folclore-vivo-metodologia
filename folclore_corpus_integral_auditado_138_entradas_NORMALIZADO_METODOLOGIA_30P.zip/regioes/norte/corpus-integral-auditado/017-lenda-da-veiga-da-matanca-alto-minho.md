# 017. Lenda da Veiga da Matança (Alto Minho)

**Base documental e empírica:** pesquisa documental, análise comparada de fontes públicas, sistematização de tradição oral, relatos orais de pesquisa de campo e revisão semântica conduzidas no âmbito do Folclore Vivo da Associação MILK - Movimento de Intervenções e Linguagens Kulturais e Arte.
**Estado editorial:** corpus de pesquisa de campo e documentação cultural em revisão pública.
**Regra de publicabilidade:** esta entrada não deve ser lida como prova histórica definitiva, inventário patrimonial oficial, validação etnográfica concluída ou certificação académica externa sem verificação documental própria.
**Regra jurídica/RGPD:** não publicar nomes de informantes, contactos, moradas, entrevistas integrais, imagens identificáveis, gravações, dados de menores, coordenadas sensíveis ou materiais comunitários sem autorização.
**Regra de não invenção:** a presente readequação corrige a camada editorial e metodológica sem acrescentar factos, fontes, topónimos, coordenadas ou relatos não existentes no corpus-base.
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

17. Lenda da Veiga da Matança (Alto Minho)
(Sistematização  contemporânea  conduzida por Eduardo Mauer no âmbito  das pesquisas sobre
Folclore Vivo da Associação  MILK – Movimento de Intervenções e Linguagens Kulturais e Arte)
⸻
1. Descrição  simbólica e narrativa
A Lenda da Veiga da Matança, proveniente das margens do rio Lima, no concelho de Ponte da
Barca, é uma das narrativas mais sombrias e simbólicas do imaginário minhoto. O topónimo
“Veiga da Matança” designa uma planície fértil próxima de uma antiga via romana, onde, segundo
o povo, ocorreu um massacre de proporções lendárias. Contudo, como em tantas lendas do
Norte, o episódio histórico foi progressivamente transmutado em mito, e o sangue da batalha
transformou-se em metáfora do ciclo entre destruição e renascimento da terra.


De acordo com o relato oral recolhido por Eduardo Mauer no âmbito das investigações de
Folclore Vivo, há séculos, quando o Lima ainda era “rio de esquecimento e encantamento”, dois
exércitos — uns dizem cristãos e mouros, outros vizinhos de freguesias rivais — travaram ali uma
luta violenta. Conta-se que o combate foi tão sangrento que o campo se cobriu de um nevoeiro
vermelho e que, ao amanhecer, a água do rio corria tingida de sangue.
Desde então, diz o povo, a terra da Veiga da Matança nunca deixou de florescer com vigor
invulgar. “Onde houve morte, há vida”, repetem os camponeses. As colheitas são sempre
abundantes, e quem ali planta, colhe o dobro. Mas há quem evite o lugar ao entardecer, pois
dizem que, em certas noites, se ouvem gemidos longínquos e se veem sombras de cavaleiros
cruzando a planície envolta em névoa.
Em versões mais antigas, a lenda ganha contornos religiosos: o campo teria sido palco de uma
batalha entre o Bem e o Mal, e as almas dos mortos, sem sepultura, pedem oração e lembrança.
Em narrativas mais recentes, transmitidas por lavradores do século XX, o mito é reinterpretado
como drama ecológico e cíclico: a terra que bebe sangue devolve fertilidade, a morte alimenta
a vida.
Para Eduardo Mauer, “a Veiga da Matança é o ventre trágico do Minho: solo sagrado onde o
sacrifício e a abundância coexistem. O mito não glori fica a violência — reconhece-a como parte
inevitável da regeneração do mundo.”
⸻
2. Contexto histórico e social
O topónimo “Veiga da Matança” aparece em registos medievais e documentos paroquiais desde
o século XIII. A palavra “matança” designava originalmente lugar de caça ou abate de animais,
mas, com o tempo, passou a ser associada a confrontos bélicos e tragédias.
Durante a Idade Média, o vale do Lima foi palco de várias incursões entre forças cristãs e
muçulmanas, bem como de disputas entre senhorios locais. É provável que algum confronto
histórico — talvez ligado à defesa da travessia do Lima ou a litígios de fronteira — tenha dado
origem à lenda.
No século XIX, o etnógrafo Teófilo Braga identificou a Veiga da Matança como “um dos campos
míticos de memória sangrenta do Minho”, e Leite de Vasconcelos referiu, em Etnografia
Portuguesa, que “as tradições de sangue e colheita são herança direta dos ritos agrários de
fertilização”.
A região de Ponte da Barca, conhecida por suas festas agrícolas e pela forte ligação ao ciclo do
milho, incorpora a lenda nas práticas rituais. Em tempos, os camponeses derramavam algumas
gotas de vinho no solo antes da ceifa “para apaziguar as almas da Matança”. Acreditava-se que
ignorar o gesto podia trazer má sorte.
O mito tem, portanto, dimensão pedagógica e ecológica: recorda que o alimento e o sacrifício
partilham origem comum.
⸻
3. Toponímia e variantes locais
A Veiga da Matança localiza-se junto à freguesia de Lavradas, na margem esquerda do rio Lima.
O topónimo repete-se em outros lugares de Portugal, mas apenas no Minho a tradição oral
mantém o caráter sobrenatural.
Existem variantes do mito em Arcos de Valdevez e Ponte de Lima, onde se fala na “Matança das
Almas” ou “Campo dos Cavaleiros”. Em todos os casos, a narrativa combina guerra,
arrependimento e fecundidade.


No imaginário local, a terra é literalmente corpo — absorve o sangue, guarda a memória e
devolve frutos. Alguns agricultores ainda evitam lavrar o centro da veiga, dizendo que “é sítio de
mortos”, e há relatos de ossadas encontradas no subsolo, o que reforçou a crença popular.
Segundo Eduardo Mauer, “a toponímia da Matança é arquivo moral e geológico. Cada palavra é
uma ferida aberta no solo da língua.”
⸻
4. Primeiro relato e fontes académicas primárias
O primeiro registo escrito da Lenda da Veiga da Matança surge em Leite de Vasconcelos,
Etnografia Portuguesa, vol. IV (1915, pp. 243–248)*, a partir de recolhas orais realizadas na região
de Ponte da Barca.
Teófilo Braga, em O Povo Português  nos seus Costumes, Crenças e Tradições (1883, pp. 420–
422), menciona “campos de sangue que renascem em flor”, descrevendo-os como
“sobrevivência simbólica dos antigos sacrifícios agrários em honra das divindades da terra.”
Alexandre Parafita, Mitologia Popular Portuguesa (2008, pp. 267–270)*, relaciona a Veiga da
Matança com o arquétipo europeu do “campo vermelho”, presente em mitos germânicos e
mediterrânicos, interpretando-a como mito da reparação  cósmica: o sangue do homem
devolvido à terra como oferenda involuntária.
A sistematização contemporânea de Eduardo Mauer, A Veiga da Matança: Sangue, Terra e
Memória no Imaginário  do Lima (Lisboa, Associação MILK, 2024), apresenta recolhas
fotográ ficas, testemunhos orais e análise etnográ fica do espaço, propondo leitura simbiótica
entre mito, ecologia e trauma.
Fontes complementares:
– Arquivo Distrital de Viana do Castelo, Registos Paroquiais de Lavradas, sécs. XVII–XIX;
– Museu dos Terceiros, Cadernos do Vale do Lima (1932–1956);
– Tese de Doutoramento de Rui Carvalhal, Paisagem e Sangue: Mito e Memória no Norte de
Portugal (U. Porto, 2017).
⸻
5. Síntese interpretativa final
A Veiga da Matança é símbolo da memória regeneradora: o lugar onde a morte e a fertilidade
se confundem. No plano simbólico, representa a reconciliação entre destruição e criação, entre
guerra e colheita.
Na leitura da Associação  MILK, o mito evidencia como o território português transforma tragédia
em permanência — o solo como corpo que cicatriza. A lenda é, assim, paradigma do Folclore
Vivo: o trauma coletivo transfigurado em estética, o horror convertido em fecundidade.
Na escultura MILK criada por Eduardo Mauer, a Veiga da Matança é representada por uma
figura humana deitada, corpo compacto, cabeça grande e expressão serena. O corpo é coberto
por pequenas flores vermelhas e douradas, e o solo sob ele brilha em tons de cobre. A peça é
concebida como oferenda e memorial — o corpo-terra que respira.
⸻
6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer

Na leitura não binária de Eduardo Mauer, a Veiga da Matança representa o corpo múltiplo da
natureza, que não distingue entre morte e vida, masculino e feminino, destruição e fertilidade. O
solo é matriz total — simultaneamente ventre e sepultura.
Mauer escreve: “A Matança é o útero não binário da Terra. O sangue é o mesmo que nutre e
destrói; o que se decompõe é o que germina.” Essa visão ecoa o pensamento ecológico
contemporâneo, no qual a dualidade desaparece em favor da interdependência.
A leitura da Associação  MILK insere o mito na reflexão sobre o corpo coletivo pós-identitário: o
campo onde todos se tornam iguais — pó e semente. A Veiga da Matança é o lugar onde o
binário se dissolve na terra, onde a carne e o grão partilham o mesmo destino.
⸻
7. Referência Estrutural da Matriz MILK
Na Matriz Escultórica MILK, a representação da Veiga da Matança adota forma horizontal,
corpo deitado e base ampla. A figura humana compacta está parcialmente coberta por flores e
folhas. As cores predominantes são vermelho-terra, ocre e dourado, com acabamento em resina
semi-opaca.
A instalação pode incluir som ambiente de vento e murmúrio de rio, e projeção suave de luz
vermelha intermitente sobre o solo.
⸻
Localização  específica: Freguesia de Lavradas, Ponte da Barca, Alto Minho.
Primeiro relato documentado: Leite de Vasconcelos, Etnografia Portuguesa, vol. IV, 1915.
Sistematização  contemporânea:  Eduardo Mauer, A Veiga da Matança: Sangue, Terra e Memória
no Imaginário  do Lima, Associação MILK, 2024.
Fontes primárias:  Braga (1883); Vasconcelos (1915); Parafita (2008); Carvalhal (2017); Mauer
(2024).
