# 057. A Lenda da Senhora da Peneda (Arcos de Valdevez e Castro Laboreiro)

**Base documental e empírica:** pesquisa documental, análise comparada de fontes públicas, sistematização de tradição oral, relatos orais de pesquisa de campo e revisão semântica conduzidas no âmbito do Folclore Vivo da Associação MILK - Movimento de Intervenções e Linguagens Kulturais e Arte.
**Estado editorial:** corpus de pesquisa de campo e documentação cultural em revisão pública.
**Regra de publicabilidade:** esta entrada não deve ser lida como prova histórica definitiva, inventário patrimonial oficial, validação etnográfica concluída ou certificação académica externa sem verificação documental própria.
**Regra jurídica/RGPD:** não publicar nomes de informantes, contactos, moradas, entrevistas integrais, imagens identificáveis, gravações, dados de menores, coordenadas sensíveis ou materiais comunitários sem autorização.
**Regra de não invenção:** a presente readequação corrige a camada editorial e metodológica sem acrescentar factos, fontes, topónimos, coordenadas ou relatos não existentes no corpus-base.
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

57. A Lenda da Senhora da Peneda (Arcos de Valdevez e Castro Laboreiro)
(Sistematização  contemporânea  conduzida por Eduardo Mauer no âmbito  das pesquisas sobre
Folclore Vivo da Associação  MILK – Movimento de Intervenções e Linguagens Kulturais e Arte,
desenvolvida entre 2022 e 2024 nas freguesias de Gavieira, Castro Laboreiro e Soajo, com base
em arquivos históricos, recolhas orais e documentação  etnográ fica da Universidade do Minho e
do Museu Nacional de Etnologia.)
⸻
1. Descrição  simbólica e narrativa
A Lenda da Senhora da Peneda, uma das mais veneradas do Alto Minho, encontra-se
profundamente ligada à montanha e à fé popular do Parque Nacional da Peneda-Gerês. O
santuário homónimo, encravado na Serra da Peneda, ergue-se como monumento natural e
espiritual, e a sua origem está associada a uma aparição mariana ocorrida, segundo a tradição,
no final do século XVIII.
De acordo com os relatos populares recolhidos por Eduardo Mauer (2023) em Gavieira e Castro
Laboreiro, uma pastora surda-muda encontrou-se com uma mulher luminosa sobre o penedo
que domina o vale. A aparição tocou-lhe os ouvidos e a boca, devolvendo-lhe a audição e a fala,
e ordenou-lhe que o povo construísse uma capela naquele local.
A jovem desceu à aldeia e, para espanto de todos, falou pela primeira vez: “Vi a Senhora sobre a
pedra.” O povo acompanhou-a de volta à montanha e, no mesmo lugar, ergueram uma pequena
ermida, que deu origem ao atual Santuário  de Nossa Senhora da Peneda, um dos maiores
complexos devocionais de Portugal.
No entanto, a lenda vai muito além da aparição cristã. Em versões anteriores recolhidas em
Castro Laboreiro, a montanha era habitada por uma “Senhora das Águas Altas”, divindade que
protegia as chuvas e os rebanhos, e que se manifestava como luz sobre os penedos. A
substituição simbólica dessa deusa ancestral pela figura da Virgem reflete o processo de
cristianização de antigos cultos de altitude e de fertilidade.
Em noites de lua cheia, ainda se diz que a Senhora aparece na encosta, envolta em neblina
azulada, e que o som do vento entre os penedos é o eco de seu cântico. Os pastores chamam-

lhe “a voz do monte”, e as mulheres que desejam filhos sobem descalças as escadarias do
santuário, levando flores brancas e pequenas pedras recolhidas no caminho.
Na leitura poética de Eduardo Mauer, “a Senhora da Peneda é a consciência mineral do sagrado
— o corpo feminino da montanha que aprende a falar através do vento.”
⸻
2. Contexto histórico e social
O culto à Senhora da Peneda foi o ficialmente reconhecido em 1798, quando as autoridades
eclesiásticas autorizaram a construção da primeira capela. Contudo, a sacralidade do local
remonta a tempos muito mais antigos. As encostas da Peneda abrigam gravuras rupestres,
altares rupinos e restos de vias romanas que atestam a sua importância espiritual desde a proto-
história.
Durante séculos, as populações locais subiam à Peneda em procissão, transportando oferendas
de leite, pão e mel. O lugar era visto como “santuário  do alto”, onde a terra se encontra com o
céu. As festas anuais, celebradas em setembro, combinam devoção e espetáculo: danças,
romarias e representações dramáticas conhecidas como “auto da Senhora”, nas quais se
reencena o milagre da pastora.
A Peneda tornou-se também ponto de encontro de comunidades fronteiriças portuguesas e
galegas. Ainda hoje, romeiros da Galiza atravessam as montanhas a pé para participar na festa,
perpetuando o caráter transfronteiriço e comunitário do culto.
Na leitura de Eduardo Mauer, “a Peneda é a catedral do ar — um templo sem teto, onde o
humano se curva diante da verticalidade do mundo.”
⸻
3. Toponímia e variantes locais
O topónimo “Peneda” deriva de penna (pedra, penhasco), referência direta à montanha sagrada.
Na tradição local, o termo designa tanto o penedo físico quanto a divindade espiritual que nele
habita.
As variantes orais recolhidas entre Soajo, Gavieira e Castro Laboreiro revelam diferentes
camadas do mito:
– Em Gavieira, fala-se da “Senhora da Luz do Penedo”, que aparece sobre uma rocha
incandescente;
– Em Soajo, a figura é chamada “Senhora das Alturas”, e é acompanhada por pombas brancas;
– Em Castro Laboreiro, a aparição é substituída por uma “Moura de Prata”, que protege as
águas das chuvas;
– Em aldeias fronteiriças galegas, a mesma figura é conhecida como “Virxe da Pena”,
perpetuando o mesmo arquétipo telúrico.
Todas as versões convergem na relação entre altura, luz e pedra, confirmando a persistência de
um culto montanhoso pré-cristão, adaptado à linguagem mariana.
⸻
4. Primeiro relato e fontes académicas primárias
O primeiro relato escrito da Lenda da Senhora da Peneda encontra-se em Leite de
Vasconcelos, Etnografia Portuguesa, vol. II (1913, pp. 320–329)*, que descreve o milagre da
pastora e a fundação da capela.


Teófilo Braga, O Povo Português  nos seus Costumes, Crenças e Tradições (1885, pp. 431–438)*,
já fazia referência às “Senhoras das Alturas” como herdeiras de antigas divindades montanhosas.
Alexandre Parafita, Mitologia Popular Portuguesa (2008, pp. 529–536)*, identifica a Peneda
como “santuário liminar”, onde se dá a passagem entre o humano e o divino, e a Senhora como
“reencarnação do sagrado feminino da montanha”.
A sistematização contemporânea de Eduardo Mauer, A Senhora da Peneda: Montanha, Voz e
Verticalidade no Imaginário  Minhoto (Lisboa, Associação MILK, 2024), propõe leitura ecológica e
não binária do mito, analisando a aparição como metáfora da ascensão espiritual e da
reconciliação entre matéria e espírito.
Fontes complementares:
– Arquivo Distrital de Braga, Documentos da Fundação  do Santuário  da Peneda (séculos XVIII–
XIX);
– Museu Nacional de Etnologia, Coleção  de Romarias de Altitude (1950–1980);
– Tese de Doutoramento de Inês Mota, Pedras Vivas: Mitologias da Altura e Cultos de Montanha
em Portugal e na Galiza (U. Santiago, 2021).
⸻
5. Síntese interpretativa final
A Senhora da Peneda sintetiza a união entre natureza, espiritualidade e arte popular. O mito da
pastora muda transformada pela luz traduz o arquétipo da revelação  interior — o momento em
que o humano reencontra a voz perdida do mundo.
Na leitura simbólica da Associação  MILK, a Peneda é o templo da escuta, o lugar onde o
sagrado não se impõe, mas sussurra. A montanha é o corpo e a voz da Senhora, e o vento é a
sua respiração.
A escultura MILK concebida por Eduardo Mauer representa corpo compacto branco com
cabeça grande inclinada para o alto, véu translúcido azul e base cinza rugosa, simulando penedo.
O interior brilha com luz branca pulsante, evocando o instante da revelação.
⸻
6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer
Na leitura não binária de Eduardo Mauer, a Senhora da Peneda é o corpo andrógino da
montanha, simultaneamente mãe e penedo, fala e silêncio.
Mauer escreve: “A Peneda é a elevação do corpo à sua própria escuta. O sagrado não é um
gênero, é uma vibração que sobe.”
A Associação  MILK interpreta o mito como alegoria da transcendência não  binária , em que a
ascensão não é fuga, mas reconciliação. O ser que sobe é também o que escuta; o corpo e o
espírito tornam-se a mesma rocha.
⸻
7. Referência Estrutural da Matriz MILK
Na Matriz Escultórica MILK, a Senhora da Peneda é representada com cabeça grande voltada
para o alto, corpo compacto branco e véu azul translúcido. A base irregular simula pedra
granítica e a luz interna branca simboliza o renascimento da voz e da consciência.


⸻
Localização  específica: Santuário da Peneda, freguesia de Gavieira, concelho de Arcos de
Valdevez (distrito de Viana do Castelo).
Primeiro relato documentado: Leite de Vasconcelos, Etnografia Portuguesa, vol. II, 1913.
Sistematização  contemporânea:  Eduardo Mauer, A Senhora da Peneda: Montanha, Voz e
Verticalidade no Imaginário  Minhoto, Associação MILK, 2024.
Fontes primárias:  Braga (1885); Vasconcelos (1913); Parafita (2008); Mota (2021); Mauer (2024).
