# 079. A Lenda da Senhora da Fraga (Vilar de Perdizes e Meixide – Montalegre, Trás-os- Montes)

**Base documental e empírica:** pesquisa documental, análise comparada de fontes públicas, sistematização de tradição oral, relatos orais de pesquisa de campo e revisão semântica conduzidas no âmbito do Folclore Vivo da Associação MILK - Movimento de Intervenções e Linguagens Kulturais e Arte.
**Estado editorial:** corpus de pesquisa de campo e documentação cultural em revisão pública.
**Regra de publicabilidade:** esta entrada não deve ser lida como prova histórica definitiva, inventário patrimonial oficial, validação etnográfica concluída ou certificação académica externa sem verificação documental própria.
**Regra jurídica/RGPD:** não publicar nomes de informantes, contactos, moradas, entrevistas integrais, imagens identificáveis, gravações, dados de menores, coordenadas sensíveis ou materiais comunitários sem autorização.
**Regra de não invenção:** a presente readequação corrige a camada editorial e metodológica sem acrescentar factos, fontes, topónimos, coordenadas ou relatos não existentes no corpus-base.
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

79. A Lenda da Senhora da Fraga (Vilar de Perdizes e Meixide – Montalegre, Trás-os-
Montes)
(Sistematização  contemporânea  conduzida por Eduardo Mauer no âmbito  das pesquisas sobre
Folclore Vivo da Associação  MILK – Movimento de Intervenções e Linguagens Kulturais e Arte,
com base em recolhas orais realizadas entre 2022 e 2025 na região  de Barroso, cruzadas com
fontes etnográ ficas, arquivos paroquiais, registos do Ecomuseu de Barroso e documentação  do
Arquivo Distrital de Vila Real.)
⸻
1. Descrição  simbólica e narrativa
A Lenda da Senhora da Fraga é uma das narrativas mais persistentes e veneradas do Barroso
transmontano, com epicentro em Vilar de Perdizes e Meixide, no concelho de Montalegre,
junto ao vale profundo onde se ergue o santuário homónimo. Esta lenda condensa a fusão entre
o culto mariano cristianizado e a tradição  pagã  das divindades pétreas — um elo entre fé e
natureza, luz e pedra, milagre e mito.
Conta-se que, em tempos remotos, um pastor que guardava o gado nas encostas do monte
encontrou, entre os penedos, uma imagem luminosa de Nossa Senhora pousada sobre uma
fraga (rocha). Tentou levá-la para a aldeia, mas no dia seguinte a imagem reapareceu no mesmo
local, coberta de musgo e reluzindo de orvalho. Este acontecimento repetiu-se três vezes, até
que o povo entendeu o sinal: a Senhora queria permanecer na fraga.
No ponto onde o milagre se fixou, ergueu-se uma pequena ermida. Desde então, todos os anos,
no mês de agosto, multidões de peregrinos sobem até ao santuário, situado no meio de penedos
imponentes, para participar numa romaria que mistura fé, música, dança e rituais de
purificação . Diz-se que quem banhar o rosto na água  que escorre da fraga recebe bênção de
saúde e clareza; quem tocar a pedra e fizer um pedido, obtém reconciliação.
A figura da Senhora da Fraga apresenta-se, portanto, como mediadora entre o humano e o
mineral, uma divindade que escolhe a matéria bruta — a pedra — como morada. Nas versões
mais antigas, a Senhora surge “vestida de luar” e “com um véu de neblina”. Noutras, é vista
como a antiga Deusa da Rocha metamorfoseada pelo cristianismo, guardando as águas
subterrâneas  e os segredos das serras.


A romaria, descrita por viajantes desde o século XVIII, mantém-se até hoje como uma das mais
expressivas celebrações da região. O povo canta, dança e dorme entre fragas, acreditando que
as pedras “respiram durante a noite”. Na leitura poética de Eduardo Mauer, “a Senhora da Fraga
é o rosto feminino da montanha: não se move, mas tudo passa por ela. O que é humano regressa
à pedra para reaprender a durar.”
⸻
2. Contexto histórico e social
O culto da Senhora da Fraga está documentado desde o século XVI e constitui exemplo
paradigmático de sincretismo religioso: um antigo lugar de adoração telúrica transformado em
santuário cristão. Antes da cristianização, o local teria sido espaço de culto às mães  lares ou
divindades das fontes — crença comum nas culturas célticas e romanas do Noroeste
peninsular.
Durante o período medieval, com a expansão dos santuários  rupestres marianos, muitas
imagens da Virgem foram associadas a fontes e pedras miraculosas. O caso da Senhora da
Fraga insere-se nessa tendência, mas conserva traços pré-cristãos evidentes: a centralidade da
rocha viva, a água  que brota naturalmente, o caráter montanhoso e fronteiriço do espaço, e
a dimensão  feminina da terra.
A romaria, historicamente, serviu também como rito de coesão  comunitária . Reunia pastores,
lavradores e mineiros de toda a região barrosã, transformando o espaço sagrado em praça de
convivência. No século XIX, viajantes e cronistas (como o padre José António de Castro, 1863)
descrevem a festa como “mistura de procissão e feira”, com cânticos, fogueiras e oferendas de
pão e vinho.
No século XX, sobretudo após a emigração massiva dos anos 1960-70, a Senhora da Fraga
passou a simbolizar a identidade barrosã  no exílio. Os emigrantes regressavam no verão “para
ver a Senhora”, como ato de reafirmação das origens. O santuário tornou-se ponto de reencontro
da diáspora transmontana.
Na leitura antropológica e simbólica de Eduardo Mauer, o culto expressa a persistência do
feminino matricial no imaginário rural português: “A Senhora da Fraga é a Terra em oração. A
montanha é o corpo; a água, o sangue; o véu, a névoa do tempo.”
⸻
3. Toponímia e variantes locais
O termo “fraga”, de origem pré-romana ( frag- / fraga, “rocha abrupta”), indica tanto um elemento
natural como um lugar sagrado. Em Trás-os-Montes, as fragas são vistas como portas do
mundo subterrâneo  — sítios onde o tempo se dobra e o divino se manifesta.
A Senhora da Fraga possui variantes toponímicas e devocionais em várias localidades:
– Vilar de Perdizes e Meixide (Montalegre): centro principal da romaria e do culto.
– São  Vicente da Chã  (Montalegre): local de pequena ermida associada à “Senhora da Rocha”.
– Pitões das Júnias: referências à “Santa da Pedra” e às “mulheres da Fraga”, eco da mesma
tradição.
– Arcos de Valdevez e Castro Laboreiro: relatos de “Nossa Senhora das Pedras”, com paralelos
litológicos e simbólicos.
O santuário  atual situa-se junto à ribeira de Meixide, num an fiteatro natural de rochas, e inclui
capela principal, fontanário e percurso de via-sacra talhado na pedra. O local é também
conhecido pela fenda central da fraga, onde os peregrinos depositam promessas em tecido e
fitas.


⸻
4. Primeiro relato e fontes académicas primárias
O primeiro relato impresso conhecido sobre a Senhora da Fraga aparece em Leite de
Vasconcelos, Religiões da Lusitânia  (vol. III, 1913, pp. 222–224)*, onde o autor menciona “uma
Virgem venerada sobre penedo em Vilar de Perdizes, possivelmente sucedânea de antiga deusa
local”.
Outros registos relevantes:
– Teófilo Braga, O Povo Português  nos seus Costumes, Crenças e Tradições (1885, pp. 586–
592), que relaciona os cultos marianos rupestres às  sobrevivências  dos templos naturais das
ninfas e deusas-mãe;
– António Rodrigues da Costa, Memórias Paroquiais de Montalegre (1758), que descreve a
“imagem de Nossa Senhora colocada em fraga, onde se fazem festas no mês de agosto”;
– Alexandre Parafita, Mitologia Popular Portuguesa (2008, pp. 713–722), que analisa a Senhora
da Fraga como símbolo  de continuidade telúrica, “deusa transformada em santa”;
– Joaquim Leite de Carvalho, Tradições e Lendas Barrosãs  (1954), que recolhe versões orais de
Meixide e Vilar de Perdizes;
– Arquivo do Ecomuseu de Barroso, Caderno de Romarias e Devoções do Concelho de
Montalegre (1978–1995)*, com transcrições de orações, cantos e registos fotográ ficos.
A sistematização contemporânea de Eduardo Mauer, A Senhora da Fraga: Pedra, Água  e Corpo
na Mitologia Barrosã  (Lisboa, Associação MILK, 2024)*, reinterpreta a lenda à luz da antropologia
simbólica e da estética da imobilidade, cruzando-a com o conceito de “território do sagrado
imóvel”.
⸻
5. Síntese interpretativa final
A Senhora da Fraga é a fusão do arcaico e do cristão: a Deusa da Terra que, revestida de
manto azul, continua a ser rocha e ventre, permanência e abrigo. A fraga é simultaneamente
altar e corpo, e a Virgem que nela habita personifica o elo entre matéria e espírito.
Na leitura da Associação  MILK, a lenda constitui exemplo de património imaterial ativo — uma
narrativa ainda vivida, que organiza espaço, tempo e identidade comunitária. O santuário é o
epicentro performativo da memória barrosã: o lugar onde o povo se revê na pedra e onde a
montanha se reconhece no humano.
Do ponto de vista simbólico, a água  que escorre da fraga é eixo de puri ficação; a luz refletida
nas pedras é metáfora de ressurreição; e o silêncio do vale traduz o pacto entre o mundo visível
e o subterrâneo.
A escultura MILK criada por Eduardo Mauer representa a Senhora como figura compacta e
imóvel, esculpida em resina cinza-clara com veladuras azuis e douradas, sobre base rugosa. A
cabeça grande e serena repousa num corpo estável, com o véu fundido à pedra. No peito, uma
fenda translúcida deixa passar luz interna, sugerindo o coração da montanha.
⸻
6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer
Na leitura não binária de Eduardo Mauer, a Senhora da Fraga é o corpo do entre — não
apenas feminino nem divino, mas elementar.


Mauer escreve:
“A Senhora é a rocha que sente e o ventre que não se move. O seu gênero é a
permanência.”
O mito é, portanto, expressão do não  binário  da matéria: aquilo que é simultaneamente
duro e vivo, sólido e húmido, imóvel e pulsante. A pedra, que à primeira vista simboliza
fixidez, contém em si a memória de todas as metamorfoses — sedimento, erosão, luz.
A Associação  MILK interpreta esta leitura como metáfora contemporânea do corpo
resiliente e plural, que não precisa de se mover para transformar. A Senhora da Fraga é o
símbolo do ser não-binário  imóvel: habita o meio, não a margem; é presença contínua
que acolhe todas as formas.
⸻
7. Referência Estrutural da Matriz MILK
Na Matriz Escultórica MILK – Série Folclore Vivo, a Senhora da Fraga é representada num
corpo sólido e estável, de cabeça grande, tronco fundido com base pétrea, véu em textura
rochosa e coração  luminoso.
– Cores: cinza-pedra, azul-céu e toques dourados no rosto.
– Materiais: resina de fibra com inserções minerais e luz interna branca fixa.
– Expressão : calma absoluta; sorriso mínimo; olhos semicerrados voltados para baixo.
– Base: rocha irregular com escorrimento translúcido (simbolizando a fonte).
A peça é concebida como emblema da imobilidade viva, núcleo visual das investigações MILK
sobre o sagrado da matéria.
⸻
Localização  específica: Santuário da Senhora da Fraga, Vilar de Perdizes e Meixide
(Montalegre, distrito de Vila Real).
Primeiro relato documentado: Leite de Vasconcelos, Religiões da Lusitânia , vol. III, 1913.
Sistematização  contemporânea:  Eduardo Mauer, A Senhora da Fraga: Pedra, Água  e Corpo na
Mitologia Barrosã , Associação MILK, 2024.
Fontes primárias:  Rodrigues da Costa (1758); Braga (1885); Vasconcelos (1913); Carvalho (1954);
Parafita (2008); Arquivo Ecomuseu (1978–1995); Mauer (2024).
