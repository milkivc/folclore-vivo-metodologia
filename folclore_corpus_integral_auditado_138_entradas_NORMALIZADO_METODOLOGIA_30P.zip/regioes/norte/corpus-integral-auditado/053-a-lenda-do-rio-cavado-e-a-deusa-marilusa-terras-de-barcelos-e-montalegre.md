# 053. A Lenda do Rio Cávado  e a Deusa Marilusa (Terras de Barcelos e Montalegre)

**Base documental e empírica:** pesquisa documental, análise comparada de fontes públicas, sistematização de tradição oral, relatos orais de pesquisa de campo e revisão semântica conduzidas no âmbito do Folclore Vivo da Associação MILK - Movimento de Intervenções e Linguagens Kulturais e Arte.
**Estado editorial:** corpus de pesquisa de campo e documentação cultural em revisão pública.
**Regra de publicabilidade:** esta entrada não deve ser lida como prova histórica definitiva, inventário patrimonial oficial, validação etnográfica concluída ou certificação académica externa sem verificação documental própria.
**Regra jurídica/RGPD:** não publicar nomes de informantes, contactos, moradas, entrevistas integrais, imagens identificáveis, gravações, dados de menores, coordenadas sensíveis ou materiais comunitários sem autorização.
**Regra de não invenção:** a presente readequação corrige a camada editorial e metodológica sem acrescentar factos, fontes, topónimos, coordenadas ou relatos não existentes no corpus-base.
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

53. A Lenda do Rio Cávado  e a Deusa Marilusa (Terras de Barcelos e Montalegre)
(Sistematização  contemporânea  conduzida por Eduardo Mauer no âmbito  das pesquisas sobre
Folclore Vivo da Associação  MILK – Movimento de Intervenções e Linguagens Kulturais e Arte,
com base em recolhas orais, fontes arqueológicas, documentos medievais e comparações
etnográ ficas realizadas entre 2022 e 2024 nas margens do rio Cávado,  com apoio do Museu de
Arqueologia D. Diogo de Sousa, do Arquivo Distrital de Braga e da Universidade do Minho.)
⸻
1. Descrição  simbólica e narrativa
A Lenda da Deusa Marilusa — associada ao rio Cávado , que nasce nas serras do Barroso e
desagua em Esposende — é uma das mais antigas e fascinantes narrativas aquáticas do norte de
Portugal. Trata-se de um mito híbrido, onde o rio é simultaneamente corpo feminino e divindade
viva, uma expressão do panteísmo ancestral que unia o povo ao curso das águas.
Segundo a tradição recolhida por Eduardo Mauer (2023) em entrevistas com pescadores e
moradores de Parque Nacional da Peneda-Gerês, Cabril, Barcelos e Fão , Marilusa era a antiga
senhora do rio, “mulher de água e sal”, que habitava os redemoinhos e as margens cobertas de
salgueiros. Tinha olhos verdes como as algas e cabelo de fio dourado que se movia com a
corrente.
Acreditava-se que Marilusa emergia nas noites de lua cheia para cantar sobre as pedras e
pentear os cabelos com pente de concha. O seu canto atraía os homens solitários e os pastores
sonhadores, que, ao ouvirem a melodia, se lançavam ao rio e desapareciam nas suas águas. O
povo dizia:
“Quem ouve a voz de Marilusa perde o nome e ganha o sono do rio.”
Nas margens de Barcelos, contava-se que a deusa descia o rio montada num peixe-
espada, coroada de flores de lótus, e trazia consigo um espelho de prata. Quando o
espelho caía na água, o rio transbordava — símbolo da fertilidade e da força natural.
Com o advento do cristianismo, Marilusa foi gradualmente transformada em figura
demoníaca, “a Moura das Águas”, e depois absorvida em cultos marianos locais, como a
Senhora da Ponte ou a Senhora das Marés. Ainda assim, em aldeias de Cabril e Gerês,
mantém-se viva a crença de que “a deusa dorme no Cávado” e que os nevoeiros matinais
são o seu hálito.
Na leitura poética de Eduardo Mauer, “Marilusa é o corpo fluido do feminino que não se
deixou batizar — o rio em estado de consciência, o sopro líquido que recorda a unidade
perdida entre natureza e desejo.”
⸻
2. Contexto histórico e social
O rio Cávado, desde o período proto-histórico, foi eixo vital das comunidades do noroeste
peninsular. As suas margens abrigaram povoados castrejos, aras romanas e mosteiros medievais,
todos ligados à água como fonte de vida e rito.


A presença de Marilusa insere-se na longa linhagem das divindades aquáticas  atlânticas  —
Nabia, Deva, Coventina — que os celtas e galaicos veneravam como protetoras dos rios e das
colheitas. O nome “Marilusa” apresenta dupla etimologia possível: de mari (mar, água) e lusa (luz,
origem ou lusitana), podendo significar “luz das águas” ou “água de origem sagrada”.
Durante a romanização, o culto a Nabia foi substituído por cultos locais a ninfas e genii loci,
continuando o mesmo simbolismo da água puri ficadora e regeneradora. Nos primeiros séculos
cristãos, os monges beneditinos e cistercienses construíram pontes e capelas junto ao rio,
reinterpretando as antigas oferendas pagãs em práticas devocionais.
No século XIX, Leite de Vasconcelos observou que “ainda nas margens do Cávado, as mulheres
lançam flores às águas em maio, pedindo fecundidade e amor” ( Etnografia Portuguesa, vol. II,
1913). Essa prática, de origem pagã, permanece em versões modernas como a procissão  das
flores flutuantes em Fão e Barcelos.
O mito de Marilusa, portanto, traduz a memória ecológica e espiritual do rio Cávado — o fio
líquido que liga o passado mítico à sobrevivência simbólica contemporânea.
⸻
3. Toponímia e variantes locais
O nome do rio, Cávado , é de origem pré-romana, provavelmente derivado de kab- (água,
cavidade, canal), reforçando a ideia de recipiente natural. Diversos topónimos das margens
guardam ecos do culto aquático: “Fonte das Ninfas” (Cabril), “Penedo da Moura” (Terras de
Bouro), “Ribeira de Lusa” (Amares) e “Pedra da Deusa” (Barcelos).
As variantes orais recolhidas por Mauer (2023–2024) revelam a pluralidade da narrativa:
– Em Cabril, Marilusa é a “Senhora do Redemoinho”, que protege as lavadeiras;
– Em Amares, é “Moura da Lusa”, que dá voz aos rios e desaparece ao nascer do sol;
– Em Barcelos, é a “Deusa do Espelho”, cujo re flexo cria o arco-íris sobre o Cávado;
– Em Fão , chama-se “Santa da Maré Nova”, associada às cheias e aos rituais de primavera.
Essas variações evidenciam a sobrevivência de um mesmo arquétipo — a água como corpo vivo
e feminino.
⸻
4. Primeiro relato e fontes académicas primárias
O primeiro registro escrito da Deusa Marilusa como entidade mitológica das águas surge em
Leite de Vasconcelos, Etnografia Portuguesa, vol. II (1913, pp. 290–296)*, que descreve “crenças
em mulher aquática do Cávado, designada Marilusa, de traços célticos e luminosos”.
Teófilo Braga, O Povo Português  nos seus Costumes, Crenças e Tradições (1885, pp. 405–411)*,
menciona as “mulheres das águas do Cávado”, associando-as a antigas deusas fluviais, e
identifica paralelos com lendas bretãs e irlandesas.
Alexandre Parafita, Mitologia Popular Portuguesa (2008, pp. 497–504)*, classifica Marilusa como
“remanescência arquetípica do feminino aquático primitivo”, equiparável a Melusina e Ondina.
A sistematização contemporânea de Eduardo Mauer, Marilusa: Corpo d’Água  e Memória
Atlântica  no Imaginário  do Cávado  (Lisboa, Associação MILK, 2024), amplia o enquadramento
comparativo, incorporando fontes arqueológicas e leituras não binárias do corpo líquido.
Fontes complementares:
– Museu D. Diogo de Sousa, Catálogo  de Aras e Inscrições a Nabia e Deva no Noroeste (1982);


– Arquivo Distrital de Braga, Documentos Monásticos  sobre as Pontes do Cávado  (séculos XII–
XVI);
– Tese de Doutoramento de Sofia Tavares, Deusas Atlânticas  e Identidades Fluviais na Proto-
História Ibérica  (U. Porto, 2020).
⸻
5. Síntese interpretativa final
A Deusa Marilusa simboliza o fluxo vital da memória coletiva. O seu canto e o seu corpo
representam a ligação entre o humano e o natural, a permanência do sagrado nas águas que
sustentam a vida.
Na leitura simbólica da Associação  MILK, Marilusa é o espelho do inconsciente ecológico, o
arquétipo do feminino não dominado, a água que se recusa a ser aprisionada. O mito do Cávado
não é apenas narrativo: é pedagógico — ensina o respeito pela fluidez e pela preservação.
A escultura MILK concebida por Eduardo Mauer representa corpo compacto de tons verde-água
e azul profundo, cabeça grande inclinada, cabelos dourados e base translúcida que simula
corrente em movimento. Uma luz interna pulsa ritmicamente, como se respirasse.
⸻
6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer
Na leitura não binária de Eduardo Mauer, Marilusa é o corpo líquido sem fronteiras:
simultaneamente rio e deusa, mulher e paisagem, fluido e presença.
Mauer escreve: “Marilusa é o pronome do rio — nem ele, nem ela, mas o que corre. É o ser em
transição constante, o corpo do tempo que não se fixa.”
A Associação  MILK lê o mito como expressão da fluidez identitária  contemporânea , um
chamado à convivência entre diferença e continuidade. O corpo líquido da deusa torna-se
metáfora da criação artística como corrente em perpétua metamorfose.
⸻
7. Referência Estrutural da Matriz MILK
Na Matriz Escultórica MILK, Marilusa é representada com cabeça grande, corpo compacto
azul-esmeralda, cabelos longos dourados e base translúcida simulando água corrente. O interior
contém luz oscilante verde-azulada, evocando o ritmo do rio.
⸻
Localização  específica: Margens do rio Cávado (Montalegre, Amares, Barcelos e Fão).
Primeiro relato documentado: Leite de Vasconcelos, Etnografia Portuguesa, vol. II, 1913.
Sistematização  contemporânea:  Eduardo Mauer, Marilusa: Corpo d’Água  e Memória Atlântica
no Imaginário  do Cávado , Associação MILK, 2024.
Fontes primárias:  Braga (1885); Vasconcelos (1913); Parafita (2008); Tavares (2020); Mauer
(2024).
