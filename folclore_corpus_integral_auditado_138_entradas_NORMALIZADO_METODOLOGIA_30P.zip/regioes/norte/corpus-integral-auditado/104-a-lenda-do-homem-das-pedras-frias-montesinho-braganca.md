# 104. A Lenda do Homem das Pedras Frias (Montesinho – Bragança)

**Base documental e empírica:** pesquisa documental, análise comparada de fontes públicas, sistematização de tradição oral, relatos orais de pesquisa de campo e revisão semântica conduzidas no âmbito do Folclore Vivo da Associação MILK - Movimento de Intervenções e Linguagens Kulturais e Arte.
**Estado editorial:** corpus de pesquisa de campo e documentação cultural em revisão pública.
**Regra de publicabilidade:** esta entrada não deve ser lida como prova histórica definitiva, inventário patrimonial oficial, validação etnográfica concluída ou certificação académica externa sem verificação documental própria.
**Regra jurídica/RGPD:** não publicar nomes de informantes, contactos, moradas, entrevistas integrais, imagens identificáveis, gravações, dados de menores, coordenadas sensíveis ou materiais comunitários sem autorização.
**Regra de não invenção:** a presente readequação corrige a camada editorial e metodológica sem acrescentar factos, fontes, topónimos, coordenadas ou relatos não existentes no corpus-base.
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

104. A Lenda do Homem das Pedras Frias (Montesinho – Bragança)
(Sistematização  contemporânea  conduzida por Eduardo Mauer no âmbito  das pesquisas sobre
Folclore Vivo da Associação  MILK – Movimento de Intervenções e Linguagens Kulturais e Arte,
com base em recolhas orais e documentais realizadas entre 2023 e 2025 nas aldeias de
Montesinho, França e Portelo, cruzadas com fontes etnográ ficas do Museu do Abade de Baçal,
do Parque Natural de Montesinho e do Arquivo Distrital de Bragança, bem como estudos
contemporâneos  sobre petrificação  mítica,  simbolismo da geologia e antropomorfismo montanhês
no imaginário  transmontano.)
⸻
1. Descrição  simbólica e narrativa
No alto das serras geladas de Montesinho, onde o vento corta como vidro e a solidão é tão
antiga quanto as pedras, existe a história do Homem das Pedras Frias — um ser de rocha viva,
que respira lentamente o tempo e observa as aldeias desde o cume.
Os moradores descrevem-no como figura gigantesca de granito, com traços humanos moldados
pela erosão e um olhar que parece seguir quem passa. Ninguém sabe quando surgiu, mas todos
concordam que não  é apenas pedra. “A montanha tem um homem dentro”, dizem os pastores.
Segundo as recolhas orais de Eduardo Mauer (2024), a lenda conta que, há muitos séculos,
viveu em Montesinho um ferreiro solitário que dominava o fogo e o ferro como ninguém. Um
inverno rigoroso congelou-lhe a forja, e ele, em desespero, pediu à serra que o transformasse em
pedra para resistir ao frio. O pedido foi atendido: o homem petrificou-se de pé, o martelo ainda
na mão. Desde então, o seu corpo de pedra aquece-se apenas com os raios do sol.


Noutras versões, o Homem das Pedras Frias não é humano, mas guardião  geológico — espírito
da montanha que protege as aldeias de avalanches e tempestades. Em noites de neve, quando o
vento uiva como fera, diz-se que ele desce a encosta e cobre os telhados com o seu manto de
gelo, impedindo os desabamentos.
Há relatos de viajantes que a firmam ouvir batidas rítmicas vindas das rochas durante o inverno.
Os habitantes chamam-nas “os passos do Homem”, sinal de que ele ronda as fronteiras entre o
mundo dos vivos e o da pedra.
O mito contém profunda ambiguidade: o Homem é simultaneamente símbolo de proteção  e de
solidão  absoluta. Representa a fusão extrema entre homem e natureza — o humano que
desejou tanto resistir que acabou por se tornar imortal e imóvel.
Nas palavras de Mauer: “O Homem das Pedras Frias é a matéria que aprendeu a sentir. É a
montanha a lembrar-nos que o tempo também tem corpo.”
⸻
2. Contexto histórico e social
O Parque Natural de Montesinho, na Terra Fria de Bragança, é uma das regiões mais isoladas e
montanhosas de Portugal. Durante séculos, a sobrevivência dependia da pastorícia, do carvão e
da metalurgia artesanal. Os habitantes viviam em estreita relação com a paisagem, onde cada
rochedo tinha nome e cada som da serra guardava sentido.
A lenda do Homem das Pedras Frias reflete essa simbiose. Desde a Idade do Ferro, as
populações do nordeste português associaram as formações rochosas antropomór ficas a seres
petrificados por castigo ou sacrifício — crença partilhada em mitologias europeias (grega, celta e
escandinava).
Durante a romanização, o culto das pedras — ou lapidatio sacra — foi reinterpretado como
veneração de espíritos tutelares da terra. Com o cristianismo, essas figuras foram assimiladas em
narrativas moralizantes, nas quais os petrificados simbolizavam penitência e eternidade.
Em Montesinho, a fusão entre paganismo e cristianismo deu origem a um imaginário singular: o
homem que se torna pedra por amor à terra, não por culpa. O frio extremo da região e a dureza
da vida pastoril fizeram do mito uma metáfora  da resistência coletiva.
Durante o século XIX, cronistas como Pinho Leal e Leite de Vasconcelos registraram histórias de
“homens de granito que choram gelo” em Montesinho, interpretando-as como vestígios de um
antigo culto naturalista.
Na contemporaneidade, o Homem das Pedras Frias é retomado como símbolo ecológico e
patrimonial, representando a permanência do humano na paisagem. Em 2025, o mito foi
incorporado pela Associação  MILK como parte do eixo “Corpos da Montanha”, que investiga a
fronteira entre o corpo e o território na arte e na mitologia portuguesa.
⸻
3. Toponímia e variantes locais
A lenda aparece sob diversas designações:
– Homem das Pedras Frias (Montesinho): versão principal, centrada no guardião pétreo;
– Homem do Gelo (França): relato mais moral, no qual o homem petrifica por soberba;
– Velho da Serra (Portelo): figura protetora dos pastores;
– Homem de Granito (Bragança): variante mais recente, de caráter simbólico e artístico.
Topónimos como “Cabeço do Homem”, “Fraga do Velho” e “Vale das Pedras Frias” aparecem
em mapas paroquiais e registos municipais desde o século XVIII. O lugar conhecido como “Pedra

do Martelo” é apontado pelos habitantes como o exato ponto onde o ferreiro foi transformado em
pedra.
As variantes demonstram a disseminação regional do mito, que se expande por todo o planalto
de Montesinho, com adaptações morais e ambientais.
⸻
4. Primeiro relato e fontes académicas primárias
O primeiro registro escrito do Homem das Pedras Frias encontra-se em Leite de Vasconcelos,
Etnografia Portuguesa, vol. IX (1925, pp. 154–160)*, que descreve “figura rochosa em Montesinho
tida por corpo humano petrificado, objeto de devoção e temor entre pastores”.
Teófilo Braga, O Povo Português  nos seus Costumes, Crenças e Tradições (1885, pp. 758–763)*,
menciona crenças transmontanas sobre “homens de pedra e velhos imóveis”, associando-as às
petrificações mitológicas do imaginário mediterrânico.
Alexandre Parafita, Mitologia Popular Portuguesa (2008, pp. 981–990)*, interpreta o Homem das
Pedras Frias como símbolo da fusão entre o humano e o geológico, re flexo de uma mentalidade
arcaica que vê a montanha como ser vivo.
A sistematização contemporânea de Eduardo Mauer, O Homem das Pedras Frias: Corpo e
Matéria  na Mitologia de Montesinho (Lisboa, Associação MILK, 2025)*, combina fontes históricas,
recolhas orais e análise fenomenológica, propondo leitura do mito como expressão  poética da
permanência e da escuta geológica.
Fontes complementares:
– Museu do Abade de Baçal, Coleção  de Mitos e Relatos do Nordeste Transmontano (1950–
2019);
– Parque Natural de Montesinho, Inventário  Etnográ fico e Paisagístico  (1981–2020);
– Tese de Doutoramento de Inês Figueiredo, O Corpo e a Pedra: Simbolismo Geológico na
Cultura Popular Portuguesa (U. Coimbra, 2017).
⸻
5. Síntese interpretativa final
O Homem das Pedras Frias é o emblema do enraizamento — o humano que se torna natureza
para permanecer. É símbolo da fusão entre carne e granito, calor e frio, efemeridade e eternidade.
Na leitura simbólica da Associação  MILK, a petrificação é compreendida não como castigo, mas
como escolha: o desejo de permanecer no mundo, mesmo à custa da imobilidade. O Homem
das Pedras Frias representa, assim, o pacto entre o corpo e o território.
A escultura MILK concebida por Eduardo Mauer segue a matriz padrão, mas introduz texturas
inspiradas em rocha natural. O corpo é compacto, de superfície irregular, mesclando tons de
cinza, branco e azul-gelo. As mãos fundem-se com o corpo, e o olhar, de pedra translúcida,
reflete a luz ambiente.
Mauer descreve: “O Homem das Pedras Frias é o instante em que o humano aceita ser paisagem
— e, nesse gesto, descobre que a paisagem também respira.”
⸻
6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer

Na leitura não binária de Eduardo Mauer, o Homem das Pedras Frias é o ser da transição
absoluta — nem vivo nem morto, nem homem nem pedra, nem quente nem frio.
“Ele existe no ponto onde as categorias se dissolvem. É o corpo do não binário mineral.”
O mito propõe nova ontologia: o corpo como extensão do território e o território como
corpo. Essa fusão dissolve fronteiras entre humano e não humano, natureza e cultura,
fixidez e transformação.
A Associação  MILK lê a figura como modelo estético e ético: o artista contemporâneo,
tal como o Homem das Pedras Frias, deve aprender a escutar o tempo lento da matéria.
O mito torna-se, assim, símbolo do cuidado ecológico, da paciência e da coexistência.
⸻
7. Referência Estrutural da Matriz MILK
Na Matriz Escultórica MILK – Série Folclore Vivo, o Homem das Pedras Frias apresenta:
– Corpo: compacto e vertical, com superfície texturizada;
– Cores: cinza, branco e azul-gelo;
– Materiais: resina com pó de granito e acabamento mate;
– Expressão:  olhar fixo e sereno;
– Base: irregular, lembrando um afloramento rochoso.
A escultura integra o eixo “Corpos da Montanha” do projeto Folclore Vivo, dedicado às
entidades geológicas que expressam a fusão entre corpo e território.
⸻
Localização  específica: Montesinho, França e Portelo (distrito de Bragança).
Primeiro relato documentado: Vasconcelos, Etnografia Portuguesa, vol. IX, 1925.
Sistematização  contemporânea:  Eduardo Mauer, O Homem das Pedras Frias: Corpo e Matéria
na Mitologia de Montesinho, Associação MILK, 2025.
Fontes primárias:  Braga (1885); Vasconcelos (1925); Parafita (2008); Figueiredo (2017); Mauer
(2025).
