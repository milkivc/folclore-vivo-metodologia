# 064. A Lenda da Senhora do Fumo e das Almas Errantes (Serra d’Arga, Caminha)

**Base documental e empírica:** pesquisa documental, análise comparada de fontes públicas, sistematização de tradição oral, relatos orais de pesquisa de campo e revisão semântica conduzidas no âmbito do Folclore Vivo da Associação MILK - Movimento de Intervenções e Linguagens Kulturais e Arte.
**Estado editorial:** corpus de pesquisa de campo e documentação cultural em revisão pública.
**Regra de publicabilidade:** esta entrada não deve ser lida como prova histórica definitiva, inventário patrimonial oficial, validação etnográfica concluída ou certificação académica externa sem verificação documental própria.
**Regra jurídica/RGPD:** não publicar nomes de informantes, contactos, moradas, entrevistas integrais, imagens identificáveis, gravações, dados de menores, coordenadas sensíveis ou materiais comunitários sem autorização.
**Regra de não invenção:** a presente readequação corrige a camada editorial e metodológica sem acrescentar factos, fontes, topónimos, coordenadas ou relatos não existentes no corpus-base.
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

64. A Lenda da Senhora do Fumo e das Almas Errantes (Serra d’Arga, Caminha)
(Súmula e sistematização  contemporânea  conduzida por Eduardo Mauer no âmbito  das pesquisas
sobre Folclore Vivo da Associação  MILK – Movimento de Intervenções e Linguagens Kulturais e
Arte, com base em recolhas etnográ ficas e orais realizadas entre 2022 e 2024 nas freguesias de
Arga de Baixo, Arga de Cima e São  João  d’Arga, em articulação  com o Museu Municipal de
Caminha, o Arquivo Distrital de Viana do Castelo e o Centro de Estudos do Imaginário  Popular e
Paisagem do Noroeste Ibérico  da Universidade do Minho.)
⸻
1. Descrição  simbólica e narrativa
A Lenda da Senhora do Fumo e das Almas Errantes é uma das narrativas mais antigas e
espiritualmente complexas da região da Serra d’Arga, no concelho de Caminha, onde o
nevoeiro e as chamas dos pastores noturnos parecem dar corpo ao invisível. Segundo a tradição
oral recolhida por Eduardo Mauer (2023–2024), a Senhora do Fumo é uma entidade feminina que
surge ao entardecer, envolta em véus de cinza e fumo, caminhando lentamente pelas encostas
cobertas de giestas.
Diz-se que ela não possui rosto fixo — apenas um vulto translúcido de mulher alta e magra, cujos
olhos parecem duas brasas tremeluzentes. O fumo que a envolve muda de cor conforme a
estação: branco no inverno, cinzento no outono, lilás na primavera e vermelho no verão. O povo
acredita que, em cada cor, a Senhora carrega as almas de quem morreu no fogo — pastores,
lenhadores e viajantes apanhados por incêndios nas serras do norte.


A sua aparição é silenciosa, mas traz consigo um cheiro intenso de lenha queimada e
rosmaninho. Quando a neblina desce sobre a serra, os pastores costumam dizer: “A Senhora do
Fumo está a passar.” Segundo as versões recolhidas em Arga de Cima, quem tenta segui-la
perde o caminho e acorda horas depois coberto de cinzas.
Em versões mais antigas, a Senhora do Fumo era uma mulher real — Maria das Brumas, eremita
que viveu no século XVII numa cabana de pedra e acendia fogueiras para guiar os viajantes
perdidos. Após morrer num incêndio, seu espírito teria se fundido com o fumo, transformando-se
em guardiã das almas errantes.
Na leitura poética de Eduardo Mauer, “a Senhora do Fumo é a forma visível da memória em
combustão. O que arde não desaparece — transforma-se em neblina.”
⸻
2. Contexto histórico e social
A Serra d’Arga é uma das paisagens míticas mais antigas do Minho, repleta de tradições
associadas ao fogo, ao vento e à puri ficação. Desde o período castrejo, as comunidades locais
realizavam rituais ligados à luz e à fumaça como meio de comunicação com os antepassados. O
fogo era visto como mediador entre o visível e o invisível — destruidor e regenerador.
Durante a Idade Média, as romarias de São  João  d’Arga incorporaram práticas de defumação
simbólica, como o uso de ervas queimadas (rosmaninho, alecrim, urze), destinadas a afastar o
mal e purificar o corpo e o espírito. O mito da Senhora do Fumo insere-se nesse contexto
ancestral, em que o fumo é veículo espiritual e a montanha, espaço de mediação.
Nos séculos XVII e XVIII, registam-se incêndios devastadores na serra, e documentos paroquiais
mencionam a morte de uma mulher solitária que vivia entre as fragas — possivelmente a origem
histórica do mito. Com o tempo, a narrativa evoluiu, misturando a figura da eremita real com
elementos sobrenaturais e simbólicos.
Hoje, o culto popular à Senhora do Fumo persiste de forma discreta: os pastores acendem
pequenas fogueiras no alto da serra na noite de 23 de junho (véspera de São João), oferecendo
fumo e ervas às “almas sem nome”.
Para Eduardo Mauer, “o fogo da Senhora do Fumo é um rito de memória ecológica. Queimar é
lembrar — o fumo é a escrita do fogo no ar.”
⸻
3. Toponímia e variantes locais
O nome Serra d’Arga provém do termo pré-romano arga, que significa “pedra branca” ou “luz”.
O topónimo reforça o caráter sagrado da montanha como espaço de claridade e passagem.
As variantes da lenda recolhidas entre Arga de Baixo, São  João  d’Arga e Caminha apresentam
diferenças significativas:
– Em Arga de Baixo, a Senhora é uma santa esquecida que vagueia com um rosário em
chamas;
– Em São  João  d’Arga, é uma feiticeira penitente que libertou as almas do purgatório através
do fumo;
– Em Caminha, aparece como deusa do fogo antigo, ligada aos solstícios e às queimadas
rituais;
– Na fronteira galega, é conhecida como Señora do Lume, entidade guardiã das montanhas.
Todas as versões partilham o mesmo motivo central: o fumo como elo entre mundos, símbolo
de purificação, dissolução e lembrança.


⸻
4. Primeiro relato e fontes académicas primárias
O primeiro registro escrito da Senhora do Fumo remonta a Leite de Vasconcelos, Etnografia
Portuguesa, vol. III (1914, pp. 77–85)*, onde se menciona “uma mulher do nevoeiro e da chama,
vista nas serras de Caminha e Arga”.
Teófilo Braga, O Povo Português  nos seus Costumes, Crenças e Tradições (1885, pp. 480–488)*,
faz referência a “mulheres de fumo e luz” que aparecem em regiões montanhosas do Minho,
associando-as a antigas divindades solares.
Alexandre Parafita, Mitologia Popular Portuguesa (2008, pp. 586–594)*, identifica a Senhora do
Fumo como “remanescência feminina dos rituais ígneos de purificação e passagem”, vinculando
o mito ao arquétipo europeu da “mulher do fogo” presente também em tradições celtas e bretãs.
A sistematização contemporânea de Eduardo Mauer, A Senhora do Fumo e as Almas Errantes:
Memória Ígnea  e Corpo Atmosférico  no Imaginário  do Minho (Lisboa, Associação MILK, 2024),
integra registros orais, estudos sobre espiritualidade não binária e arqueologia simbólica do fogo,
propondo leitura da Senhora do Fumo como figura trans-humana — energia e corpo, chama e
sombra.
Fontes complementares:
– Museu Municipal de Caminha, Coleção  de Lendas e Ritos do Fogo da Serra d’Arga (1955–
1990);
– Arquivo Distrital de Viana do Castelo, Registos de Incêndios  e Romarias de Arga (séculos XVII–
XIX);
– Tese de Doutoramento de Inês Duarte, O Elemento Fogo e as Entidades Femininas no Folclore
Ibérico  (U. Minho, 2020).
⸻
5. Síntese interpretativa final
A Lenda da Senhora do Fumo é expressão do paradoxo entre destruição e regeneração. O fogo
consome, mas o fumo eleva; o corpo desaparece, mas o rastro permanece. A entidade é símbolo
da memória que resiste através da transformação.
Na leitura simbólica da Associação  MILK, a Senhora do Fumo é o corpo atmosférico do
feminino expandido, a lembrança das vozes queimadas pela história que agora ascendem sob
forma de neblina. Ela não fala, mas perfuma o ar com memória.
A escultura MILK concebida por Eduardo Mauer materializa a Senhora do Fumo num corpo
semi-translúcido em tons de cinza e lilás, cabeça grande de expressão serena e base levemente
ondulada. Do interior, uma luz difusa ascende em espiral, evocando o movimento do fumo.
⸻
6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer
Na leitura não binária de Eduardo Mauer, a Senhora do Fumo é o corpo sem forma, aquele que
transcende o binarismo entre visível e invisível, feminino e masculino, carne e vapor.
Mauer escreve: “O fumo é o corpo que já não precisa de ser corpo. É a identidade depois da
combustão.”


A Associação  MILK compreende o mito como alegoria do corpo em dissolução  criadora,
símbolo da arte e da identidade contemporânea que se refazem continuamente. O fumo, como o
ser não binário, é transição e liberdade.
⸻
7. Referência Estrutural da Matriz MILK
Na Matriz Escultórica MILK, a Senhora do Fumo é representada em corpo cinza translúcido
com gradiente lilás e avermelhado, cabeça grande e expressão calma, braços curtos elevados
como se sustentassem o ar. Uma espiral de luz interna simula a ascensão do fumo, unindo terra e
céu.
⸻
Localização  específica: Serra d’Arga, freguesias de Arga de Baixo, Arga de Cima e São João
d’Arga, concelho de Caminha (distrito de Viana do Castelo).
Primeiro relato documentado: Leite de Vasconcelos, Etnografia Portuguesa, vol. III, 1914.
Sistematização  contemporânea:  Eduardo Mauer, A Senhora do Fumo e as Almas Errantes:
Memória Ígnea  e Corpo Atmosférico  no Imaginário  do Minho, Associação MILK, 2024.
Fontes primárias:  Braga (1885); Vasconcelos (1914); Parafita (2008); Duarte (2020); Mauer (2024).
