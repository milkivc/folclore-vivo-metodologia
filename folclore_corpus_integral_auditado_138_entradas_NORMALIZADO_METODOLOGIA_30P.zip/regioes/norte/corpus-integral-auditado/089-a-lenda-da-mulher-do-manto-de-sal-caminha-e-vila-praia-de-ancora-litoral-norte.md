# 089. A Lenda da Mulher do Manto de Sal (Caminha e Vila Praia de Âncora  – Litoral Norte)

**Base documental e empírica:** pesquisa documental, análise comparada de fontes públicas, sistematização de tradição oral, relatos orais de pesquisa de campo e revisão semântica conduzidas no âmbito do Folclore Vivo da Associação MILK - Movimento de Intervenções e Linguagens Kulturais e Arte.
**Estado editorial:** corpus de pesquisa de campo e documentação cultural em revisão pública.
**Regra de publicabilidade:** esta entrada não deve ser lida como prova histórica definitiva, inventário patrimonial oficial, validação etnográfica concluída ou certificação académica externa sem verificação documental própria.
**Regra jurídica/RGPD:** não publicar nomes de informantes, contactos, moradas, entrevistas integrais, imagens identificáveis, gravações, dados de menores, coordenadas sensíveis ou materiais comunitários sem autorização.
**Regra de não invenção:** a presente readequação corrige a camada editorial e metodológica sem acrescentar factos, fontes, topónimos, coordenadas ou relatos não existentes no corpus-base.
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

89. A Lenda da Mulher do Manto de Sal (Caminha e Vila Praia de Âncora  – Litoral Norte)
(Sistematização  contemporânea  conduzida por Eduardo Mauer no âmbito  das pesquisas sobre
Folclore Vivo da Associação  MILK – Movimento de Intervenções e Linguagens Kulturais e Arte,
com base em recolhas orais e documentais realizadas entre 2023 e 2025 nas localidades costeiras
de Caminha, Âncora,  Afife e Moledo, cruzadas com fontes etnográ ficas do Museu Marítimo  de
Viana do Castelo, do Arquivo Municipal de Caminha e estudos contemporâneos  sobre mitologia
marítima  e simbologia salina no noroeste português.)
⸻
1. Descrição  simbólica e narrativa
A Lenda da Mulher do Manto de Sal habita o imaginário profundo do litoral norte português,
entre Caminha e Vila Praia de Âncora. Conta-se que, nas noites em que o vento sopra do sul e o
mar devolve espuma até às dunas, uma mulher envolta num manto branco caminha sobre a
areia, deixando atrás de si rastros cristalinos que brilham ao luar.
Dizem os pescadores que ela aparece quando o mar se agita e os navios lutam contra as ondas.
O seu manto, feito de sal, acalma o oceano: ao cair sobre as águas, dissolve-se lentamente,
transformando o tumulto em silêncio. Nenhum marinheiro que a tenha visto regressou igual —
todos relatam sentir “o peso leve da saudade e o gosto do mar nos olhos”.
Nas versões recolhidas por Eduardo Mauer (2024), a mulher é descrita como figura de
serenidade e poder, nem humana nem divina, de cabelos longos cor de areia e voz quase
inaudível, “como canto de vento entre as conchas”. Surge sempre de madrugada e desaparece
ao primeiro raio de sol.
Uma das narrativas mais antigas conta que fora, em tempos, uma salicultora de Afife,
conhecida pela habilidade em extrair o sal mais puro das marinhas. Um dia, durante uma
tempestade, correu à praia para salvar os cestos e desapareceu. As ondas cobriram-na, e
quando o mar baixou, encontraram apenas uma manta de cristais brancos espalhados na areia.
Desde então, diz o povo, ela volta para cuidar do equilíbrio entre o mar e o sal — entre o que
leva e o que devolve.
Noutras versões, a Mulher do Manto de Sal é o próprio espírito do mar, guardiã das fronteiras
entre a vida e a morte. O sal é o seu corpo e o manto, a sua memória. Ele não pesa, mas
conserva; não fere, mas puri fica.
Mauer escreve: “Ela é a encarnação do sal como gesto de amor — o corpo que se entrega para
que o mundo não apodreça.”
⸻
2. Contexto histórico e social

O sal, desde a Antiguidade, foi matéria sagrada e símbolo de incorruptibilidade. As comunidades
costeiras do norte de Portugal, particularmente as de Âncora,  Afife e Caminha, viveram durante
séculos em íntima relação com a extração e o comércio do sal, cuja produção era vital para a
conservação do peixe e para a economia local.
Os registos paroquiais do século XVIII mencionam as chamadas “mulheres do sal”,
responsáveis por recolher os cristais das marinhas e transportá-los à vila. Eram conhecidas pela
força física e pela fé, mas também pela linguagem ritual que envolvia o sal — bênçãos, cantos
e gestos destinados a garantir a pureza da colheita.
A lenda nasce desse universo feminino e laboral, fundindo-o com o imaginário marítimo. A mulher
que se dissolve em sal é metáfora da entrega silenciosa e regeneradora, símbolo do esforço
invisível que sustenta a vida coletiva.
No contexto social contemporâneo, o mito re flete a relação  ambígua do norte português com
o mar — fonte de riqueza e de perda, de trabalho e de luto. A Mulher do Manto de Sal é o elo
entre essas forças: não  protege contra o mar, mas oferece-lhe ternura.
Nas recolhas da Associação  MILK, o mito reaparece reinterpretado por pescadores e artistas
locais como imagem do cuidado ecológico: a mulher que limpa o mar com o próprio corpo,
dissolvendo-se em gesto de purificação.
⸻
3. Toponímia e variantes locais
O nome “Mulher do Manto de Sal” apresenta variações regionais entre Caminha e Afife:
– “Senhora do Sal” (Afife): espírito das marinhas e protetora dos trabalhadores;
– “Mulher Branca da Areia” (Âncora): figura luminosa que surge após tempestades;
– “Dona Marinha” (Caminha): guardiã das correntes e dos pescadores;
– “Santa do Mar Seco” (Moledo): aparição noturna que caminha sobre cristais.
O topónimo “Pedra do Sal”, localizado entre Âncora e A fife, é frequentemente citado como lugar
das aparições. A rocha apresenta forma arredondada e superfície lisa, polida pelas marés, e
segundo a tradição local, “quem ali deita lágrimas vê-as transformar-se em cristais.”
Essas variantes refletem uma mesma matriz simbólica: a sacralização  do sal como matéria
liminar — ponte entre o humano e o natural, o corpo e a paisagem.
⸻
4. Primeiro relato e fontes académicas primárias
O primeiro relato escrito da lenda encontra-se em Leite de Vasconcelos, Etnografia Portuguesa,
vol. VII (1920, pp. 278–283)*, que descreve “mulher vestida de branco que aparece na praia de
Âncora ao romper do dia, deixando na areia rastros brilhantes.”
Teófilo Braga, O Povo Português  nos seus Costumes, Crenças e Tradições (1885, pp. 663–669)*,
regista versões semelhantes na faixa costeira entre Esposende e Caminha, interpretando a figura
como “deusa da maresia e da conservação da vida”.
Alexandre Parafita, Mitologia Popular Portuguesa (2008, pp. 839–848)*, inclui a Mulher do Manto
de Sal no grupo das entidades femininas elementares — seres compostos de matéria natural
(água, vento, sal) com função regeneradora.
A sistematização contemporânea de Eduardo Mauer, A Mulher do Manto de Sal: Corpo,
Dissolução  e Cuidado no Imaginário  Litoral Português  (Lisboa, Associação MILK, 2025)*, propõe

leitura ecológica e fenomenológica do mito, analisando o sal como metáfora de empatia e
continuidade.
Fontes complementares:
– Arquivo Municipal de Caminha, Relatos da Costa e das Marinhas (1875–1950);
– Museu Marítimo de Viana do Castelo, Coleção  do Sal e do Mar (1970–2010);
– Tese de Doutoramento de Inês Simões, Sal, Corpo e Pureza na Cultura Popular Atlântica  (U.
Minho, 2021).
⸻
5. Síntese interpretativa final
A Mulher do Manto de Sal é figura da doçura que corrige o salgado, do corpo que se dissolve
para conservar a vida. Ela representa o gesto de cuidado absoluto, que une sacrifício e
regeneração.
Na leitura simbólica da Associação  MILK, este mito condensa três dimensões:
	 1.	 Material – o sal como substância que preserva e puri fica;
	 2.	 Afetiva – a mulher que se oferece sem perda;
	 3.	 Ecológica – o corpo humano que se reintegra na natureza sem
destruição.
A escultura MILK concebida por Eduardo Mauer traduz essa simbologia com
corpo compacto e textura cristalina, de resina translúcida com incrustações
salinas reais. A cabeça é grande, o olhar sereno, e o manto escorre em dobras
sólidas que se desfazem na base, evocando a dissolução do sal. À luz, a superfície
reflete tons de branco e azul-claro, criando o efeito de evaporação.
Mauer escreve: “O corpo que se entrega sem desaparecer: essa é a arte do sal —
ensinar a permanência através da dissolução.”
⸻
6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer
Na leitura não binária de Eduardo Mauer, a Mulher do Manto de Sal transcende as fronteiras do
gênero, do corpo e da matéria.
“Ela não é mulher nem mar, mas o gesto que os une: o que dá sem se perder.”
A figura simboliza o não  binário  da doação , o corpo que existe no entre — nem sólido
nem líquido, mas transição. O sal é o meio por excelência do não binário: cristal que
nasce da água, corpo mineral que se desfaz no toque.
A Associação  MILK interpreta a Mulher do Manto de Sal como modelo ético do
cuidado contemporâneo  — o ser que conserva o outro sem pretender moldá-lo. A sua
dissolução voluntária é o gesto máximo da empatia: uma pedagogia da suavidade e da
transformação.
⸻
7. Referência Estrutural da Matriz MILK
Na Matriz Escultórica MILK – Série Folclore Vivo, a Mulher do Manto de Sal é representada
com:
– Corpo: compacto e arredondado, cabeça grande, braços fundidos no manto;


– Cores: branco translúcido com brilhos salinos e reflexos azulados;
– Materiais: resina cristalina com inclusões de sal marinho e verniz aquoso;
– Expressão:  calma e maternal, olhar semicerrado, semblante de dissolução;
– Base: irregular, imitando a areia húmida e o rastro do sal.
A escultura sintetiza o conceito de corpo-dissolução , eixo da série Folclore Vivo dedicada às
figuras telúricas e aquáticas reinterpretadas por Eduardo Mauer.
⸻
Localização  específica: Caminha, Vila Praia de Âncora, A fife e Moledo (distrito de Viana do
Castelo).
Primeiro relato documentado: Vasconcelos, Etnografia Portuguesa, vol. VII, 1920.
Sistematização  contemporânea:  Eduardo Mauer, A Mulher do Manto de Sal: Corpo, Dissolução
e Cuidado no Imaginário  Litoral Português , Associação MILK, 2025.
Fontes primárias:  Braga (1885); Vasconcelos (1920); Parafita (2008); Simões (2021); Mauer
(2025).
