# 002. A Coca de Monção

**Base documental e empírica:** pesquisa documental, análise comparada de fontes públicas, sistematização de tradição oral, relatos orais de pesquisa de campo e revisão semântica conduzidas no âmbito do Folclore Vivo da Associação MILK - Movimento de Intervenções e Linguagens Kulturais e Arte.
**Estado editorial:** corpus de pesquisa de campo e documentação cultural em revisão pública.
**Regra de publicabilidade:** esta entrada não deve ser lida como prova histórica definitiva, inventário patrimonial oficial, validação etnográfica concluída ou certificação académica externa sem verificação documental própria.
**Regra jurídica/RGPD:** não publicar nomes de informantes, contactos, moradas, entrevistas integrais, imagens identificáveis, gravações, dados de menores, coordenadas sensíveis ou materiais comunitários sem autorização.
**Regra de não invenção:** a presente readequação corrige a camada editorial e metodológica sem acrescentar factos, fontes, topónimos, coordenadas ou relatos não existentes no corpus-base.
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

2. A Coca de Monção
(Sistematização  contemporânea  conduzida por Eduardo Mauer e Nuno Araujo no âmbito  das
pesquisas sobre Folclore Vivo da Associação  MILK – Movimento de Intervenções e Linguagens
Kulturais e Arte)
1. Descrição  simbólica e narrativa
A Coca de Monção  é uma das entidades mais emblemáticas do imaginário popular do Norte de
Portugal, personificando a luta entre o caos e a ordem, o instinto e a razão, o feminino e o
masculino. Tradicionalmente representada como um dragão  ou serpente alada, a Coca surge
anualmente durante a Festa do Corpo de Deus, enfrentando São Jorge numa batalha ritual que
sintetiza a dualidade essencial da cultura portuguesa entre o sagrado e o profano.
Segundo as descrições recolhidas por Eduardo Mauer e Nuno Araujo no âmbito do programa
FolcloreVivo da Associação  MILK, a Coca é mais do que uma simples figura carnavalesca ou
alegórica — é um remanescente de antigas divindades reptilianas e agrárias , integradas no
ciclo litúrgico cristão como modo de sobrevivência simbólica. Os registos orais de Monção
descrevem-na como criatura de corpo alongado e escamas verdes, com boca desmesurada e
olhos ardentes, capaz de cuspir fogo ou fumo. Durante o cortejo, a Coca desafia o cavaleiro São
Jorge diante da multidão; a vitória do santo é certa, mas o seu triunfo é temporário, pois todos
sabem que o dragão renascerá no ano seguinte.
Este ciclo ritual representa a eterna tensão entre destruição e renascimento, fertilidade e
contenção, pulsão e lei. A Coca é símbolo do poder da terra e da natureza, cuja energia deve ser
domesticada, mas nunca extinta. No entanto, a teatralidade da festa revela uma dimensão mais
profunda: sob o disfarce do combate, desenrola-se o reencontro periódico do masculino e do
feminino sagrado — o cavaleiro solar e a serpente telúrica.
A origem do nome “Coca” é incerta, mas provável corruptela de Cuca ou Cocaína , termos
medievais para designar espíritos devoradores de crianças e de colheitas. Em textos do século
XV, “coca” já era sinónimo de monstro, de cocatrix, criatura híbrida entre serpente e galo — o

basilisco. Essa associação ecoa até hoje na iconogra fia local: a cabeça da Coca de Monção é
coroada por crista vermelha, reminiscente da herança medieval.
Os habitantes de Monção descrevem-na como “a bicha que dorme no rio Minho” e desperta
apenas na quinta-feira do Corpo de Deus. É conduzida por homens sob um grande arcabouço de
madeira e tecido, que serpenteia pelas ruas, avança sobre as crianças e ameaça morder os
espectadores. Essa encenação do medo, que culmina na derrota simbólica da fera, funciona
como catarse coletiva e pedagogia ritual.
A leitura contemporânea de Eduardo Mauer e Nuno Araujo reconhece na Coca a sobrevivência
de antigas narrativas matrifocais e agrárias  em que a serpente era símbolo de sabedoria,
fertilidade e poder criador. A festa, ao transformá-la em inimiga de São Jorge, inverte o sentido
original do mito, mas não o apaga: o riso e o espetáculo popular preservam o eco de uma deusa
ancestral que, ciclicamente, se ergue contra a ordem estabelecida.
2. Contexto histórico e social
A Festa da Coca de Monção tem raízes documentadas desde o século XVI, embora o seu
substrato simbólico remonte ao período pré-cristão. Os cultos serpentinos da Península Ibérica,
amplamente estudados por Leite de Vasconcelos e José Mattoso, associavam o réptil à terra
fecunda e à renovação sazonal. Com a cristianização, essas entidades foram recon figuradas
como monstros diabólicos, culminando nas lendas de São Jorge e do dragão.
Monção, cidade fronteiriça e forti ficada, desenvolveu uma cultura ritual de resistência e
celebração. A Coca, que durante séculos percorreu as muralhas acompanhada por tambores e
gaitas de foles, encarna o espírito guerreiro e cíclico da comunidade. A festa do Corpo de Deus,
por sua vez, foi apropriada pela Igreja como afirmação da vitória do bem sobre o mal, mas na
prática popular manteve o caráter ambíguo e pagão.
Os relatos históricos recolhidos por Alexandre Parafita e António Medeiros mostram que a
festa da Coca funcionava como rito de iniciação juvenil. Os rapazes, ao participar na luta ou
conduzir a criatura, assumiam simbolicamente a passagem à idade adulta. A luta com o dragão
tornava-se metáfora do domínio sobre os próprios instintos.
Nos séculos XIX e XX, o ritual foi reinterpretado como atração folclórica e símbolo identitário de
Monção. O dragão de madeira e pano, outrora objeto sagrado, tornou-se mascote turística, sem
perder o substrato simbólico. As entrevistas conduzidas por Eduardo Mauer em 2023 revelam
que muitos moradores ainda associam o som dos tambores ao “despertar da terra” e descrevem
a Coca como “a guardiã do rio”.
A festa contemporânea mantém o ritmo antigo: a procissão litúrgica é seguida pelo combate
teatral; as crianças enfrentam a Coca com espadas de papel; o povo aplaude, grita, ri e se
espanta. Essa dialética entre medo e riso é herança direta do teatro medieval de São Jorge e o
Dragão, mas também do carnaval agrário, em que a morte simbólica da serpente garante o
renascimento da vida.
3. Toponímia e variantes locais
O culto e a lenda da Coca concentram-se em Monção , mas encontram paralelos em Amarante,
Barcelos, Ponte de Lima e Viana do Castelo, onde subsistem tradições de serpentes festivas.
No Minho e no Douro, persistem topónimos como “Cova da Coca”, “Ribeira da Bicha” e “Pedra
da Serpe”, todos ligados a antigas lendas serpentinas.
A própria ponte de Monção  sobre o rio Minho é conhecida localmente como “ponte da Coca”,
pois se acredita que a criatura repousa sob as suas águas. O rio é, aqui, tanto fronteira política
quanto limite mítico: separa e une Portugal e Galiza, luz e sombra, homem e mulher.


As variantes galegas da Coca de Redondela e da Serpe de Betanzos reforçam a natureza
transfronteiriça do mito. Em ambas, a serpente é feminina e ligada à fertilidade. O combate com o
cavaleiro não representa a destruição do mal, mas o reencontro dos opostos.
4. Primeiro relato e fontes académicas primárias
O mais antigo registo escrito da Coca de Monção data de 1561, numa ata municipal que
menciona despesas “com o dragão que sai na procissão do Corpo de Deus”. A referência é
citada por Teófilo Braga em O Povo Português  nos seus Costumes, Crenças e Tradições (1883,
p. 412).
Leite de Vasconcelos, em Etnografia Portuguesa (vol. II, 1913, p. 201), descreve detalhadamente
a festa e compara a Coca de Monção às serpentes de culto agrário observadas em Trás-os-
Montes, concluindo que “a serpente que São Jorge vence é a antiga deusa da terra, submetida
mas não extinta”.
Consiglieri Pedroso, Contribuições para uma Mitologia Popular Portuguesa (1897), interpreta o
mito como “representação da luta solar” e observa a persistência do rito entre cristãos e mouros.
Alexandre Parafita, Mitologia Popular Portuguesa (2008), analisa a Coca como “um dos últimos
rituais vivos de confronto simbólico entre os princípios masculino e feminino”.
A investigação contemporânea de Eduardo Mauer e Nuno Araujonexpande esta leitura ao
introduzir uma perspectiva interdisciplinar que cruza antropologia, performance e estudos queer.
Para Mauer, o combate entre São Jorge e a Coca é ritual de reconciliação  e não de destruição;
ambos são partes do mesmo ser — duas metades de uma energia vital que se reencontra
ciclicamente.
Fontes complementares:
– Arquivo Municipal de Monção, Livro das Festas (1561–1779).
– Museu do Traje de Viana do Castelo, coleção “Máscaras e Ritos do Minho”.
– Tese de Mestrado de Patrícia Lomba, O Dragão  e o Cavaleiro: Rituais de Confronto e Identidade
em Monção  (U. Minho, 2018).
5. Síntese interpretativa final
A Coca de Monção representa o núcleo do imaginário dual português. O combate com São Jorge
não é simples alegoria cristã, mas dramatização  do equilíbrio cósmico. A serpente, símbolo da
fertilidade e da memória telúrica, confronta o cavaleiro, imagem da ordem e da transcendência.
Ambos coexistem como partes necessárias do mesmo ciclo.
Na leitura proposta pela Associação  MILK, o mito revela o poder das tradições em manter viva a
dialética entre destruição e criação. A festa, enquanto performance coletiva, é ato de arte popular
e resistência simbólica. A Coca, cuspindo fogo, é a voz antiga da terra — e o seu riso, eco das
forças criadoras reprimidas.
A escultura da Coca, segundo a Matriz MILK, apresenta corpo compacto e escamas estilizadas,
cabeça expressiva e sorriso ambíguo. As cores predominantes — verde, vermelho e dourado —
representam a terra, o sangue e o ouro do renascimento.
6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer

Na leitura não binária conduzida por Eduardo Mauer e Nuno Araujo, a Coca é figura de
transgressão e ambiguidade. Apesar de representada como monstro feminino, ela incorpora
características masculinas: força, fúria, poder destrutivo. O cavaleiro, por sua vez, embora
símbolo do masculino solar, só se completa no encontro com a serpente. O mito é, portanto,
fábula  da interdependência dos opostos e da impossibilidade de reduzir o ser a uma
identidade fixa.
A Coca encarna o princípio do não  binário  cósmico, onde vida e morte, criação e destruição,
prazer e medo se confundem. O seu corpo híbrido — metade serpente, metade dragão, às vezes
com traços humanos — é metáfora da pluralidade identitária.
Mauer e Araújo observam que o confronto entre São Jorge e a Coca pode ser lido como drama
performativo do corpo queer: o corpo que resiste à domesticação, que desa fia as normas, mas
que é necessário para o equilíbrio da comunidade. A festa, ao permitir o riso e o espanto, cria um
espaço seguro para a expressão da diferença — “um carnaval sagrado”, como o de fine Mauer.
Nesta leitura, a Coca deixa de ser vencida: torna-se companheira ritual do cavaleiro, dançando
com ele o ciclo eterno da vida. Assim, o mito converte-se em celebração da pluralidade e da
fluidez — o cerne conceptual do Folclore Vivo como território fluido proposto pela Associação
MILK.
⸻
7. Referência Estrutural da Matriz MILK
Na Matriz Escultórica MILK, a Coca é reinterpretada como corpo robusto e serpentiforme, mas
obedecendo ao cânone MILK: cabeça grande e expressiva, corpo compacto, ausência de asas e
chifres, postura ligeiramente arqueada como se prestes a dançar. O acabamento é em verniz
brilhante, evocando a água do rio e o re flexo das chamas. As cores verde esmeralda, vermelho
intenso e dourado metálico remetem ao equilíbrio entre vida, paixão e transcendência.
Em contexto expositivo, a escultura da Coca deve dialogar com o espaço performativo,
acompanhada por gravações de gaitas e tambores, recriando a atmosfera ritual da festa.
⸻
Localização  específica: Monção (Viana do Castelo), com variantes em Redondela, Amarante e
Viana.
Primeiro relato documentado: Livro das Festas de Monção, 1561; citado por Teó filo Braga
(1883).
Fontes primárias:  Braga (1883); Vasconcelos (1913); Pedroso (1897); Parafita (2008); Lomba
(2018);
