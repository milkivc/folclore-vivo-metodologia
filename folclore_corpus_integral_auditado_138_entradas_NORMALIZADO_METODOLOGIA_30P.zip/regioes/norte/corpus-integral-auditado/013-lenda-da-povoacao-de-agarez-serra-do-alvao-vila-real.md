# 013. Lenda da Povoação  de Agarez (Serra do Alvão,  Vila Real)

**Base documental e empírica:** pesquisa documental, análise comparada de fontes públicas, sistematização de tradição oral, relatos orais de pesquisa de campo e revisão semântica conduzidas no âmbito do Folclore Vivo da Associação MILK - Movimento de Intervenções e Linguagens Kulturais e Arte.
**Estado editorial:** corpus de pesquisa de campo e documentação cultural em revisão pública.
**Regra de publicabilidade:** esta entrada não deve ser lida como prova histórica definitiva, inventário patrimonial oficial, validação etnográfica concluída ou certificação académica externa sem verificação documental própria.
**Regra jurídica/RGPD:** não publicar nomes de informantes, contactos, moradas, entrevistas integrais, imagens identificáveis, gravações, dados de menores, coordenadas sensíveis ou materiais comunitários sem autorização.
**Regra de não invenção:** a presente readequação corrige a camada editorial e metodológica sem acrescentar factos, fontes, topónimos, coordenadas ou relatos não existentes no corpus-base.
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

13. Lenda da Povoação  de Agarez (Serra do Alvão,  Vila Real)
(Sistematização  contemporânea  conduzida por Eduardo Mauer no âmbito  das pesquisas sobre
Folclore Vivo da Associação  MILK – Movimento de Intervenções e Linguagens Kulturais e Arte)
⸻
1. Descrição  simbólica e narrativa
A Lenda da Povoação  de Agarez, proveniente da Serra do Alvão, no concelho de Vila Real, é
uma das narrativas mais antigas da tradição oral transmontana sobre a origem das aldeias e o
poder sagrado do trabalho humano. O conto mistura memória histórica, crença popular e
topografia simbólica, articulando o nascimento de uma comunidade com forças míticas ligadas à
natureza.
Segundo o relato transmitido pelos habitantes de Agarez — recolhido por Eduardo Mauer no
âmbito do Folclore Vivo —, há muitos séculos a serra era apenas mato e vento. Diz-se que, num
tempo sem calendários, uma mulher solitária, vestida de negro e com um cajado de urze,
apareceu junto a uma nascente e começou a fiar o linho à beira da água. Com ela vieram outros
homens e mulheres, que ergueram casas de pedra, e a aldeia nasceu “do som do tear e do rumor
do riacho”.
A tradição conta que esta mulher, conhecida como a Fiandeira de Agarez, desaparecia ao pôr
do sol e regressava ao amanhecer. Quando alguém lhe perguntou o seu nome, ela respondeu:
“Sou o tempo que trabalha.” Ao morrer, transformou-se em pedra e permaneceu junto à fonte,
protegendo a aldeia. A pedra ainda hoje é mostrada como a “cabeça da Fiandeira”, símbolo do
espírito guardião do lugar.
As histórias de Agarez descrevem também um tempo de encantamento em que os aldeões
ouviam vozes subterrâneas nos moinhos e nas águas, interpretadas como murmúrios dos antigos
mouros. Da convivência entre mito e trabalho nasceu uma identidade coletiva baseada na
reciprocidade com a terra. O linho — elemento central da lenda — tornou-se a fibra da existência
local: planta, tecido e metáfora de continuidade.
Para Eduardo Mauer, a lenda de Agarez é “a epopeia do labor anónimo”, onde o sagrado não se
manifesta em milagres, mas no gesto quotidiano. A fiandeira representa a mulher arquetípica que,
com as mãos, liga o invisível ao tangível, o mito à economia.
⸻
2. Contexto histórico e social
Agarez é uma pequena povoação rural situada na encosta leste da Serra do Alvão, território
caracterizado por altitude elevada, solos pobres e forte tradição artesanal. Durante séculos, as
aldeias da região sustentaram-se no cultivo do linho, do centeio e na pastorícia. O ciclo do linho
— semear, arrancar, ripar, fiar, tecer — estruturava o calendário social e simbólico da
comunidade.
O trabalho coletivo feminino em torno do linho gerou narrativas míticas que conferiam sentido
espiritual à labuta. As fiandeiras, tecedeiras e lavadeiras tornaram-se figuras liminares, situadas
entre o humano e o divino. A “Fiandeira de Agarez” inscreve-se nesse imaginário, fundindo
memória económica e mito fundacional.


Durante o século XIX, etnógrafos e cronistas paroquiais registraram a sobrevivência de rituais
agrários na região, como a bênção das águas e a festa do primeiro fio. O Padre José Rodrigues,
em crónica manuscrita de 1871 (Arquivo Distrital de Vila Real), menciona que “as mulheres de
Agarez rezam à pedra da fonte, onde dizem morar o espírito da primeira fiandeira”.
A industrialização do linho e o êxodo rural do século XX provocaram o enfraquecimento da lenda,
mas não o seu desaparecimento. Atualmente, o mito reaparece em feiras de artesanato e
festivais locais, integrando a memória viva do território.
Para Eduardo Mauer, o declínio demográ fico de Agarez contrasta com a permanência simbólica
da sua lenda: “a aldeia pode esvaziar-se, mas o mito continua a tecer o que o tempo desfaz.”
⸻
3. Toponímia e variantes locais
O topónimo Agarez aparece em documentos medievais já no século XIII, designando “terras
agrestes junto ao Alvão”. A palavra deriva de agrestis (selvagem), o que reforça a ideia de
transformação da natureza bruta em território habitado.
Na tradição oral, existem variantes do mito na vizinha aldeia de Bobal, onde a fiandeira é
substituída por um pastor que ensina a povoar a serra, e em Lamas de Olo, onde se fala de
“mulheres de pedra” que protegem as fontes. Em todos os casos, o elemento comum é a
relação  criadora entre o humano e o lugar — a terra como sujeito e não como recurso.
Os habitantes mais antigos ainda hoje se referem à pedra da fonte como “a mãe de Agarez” e
evitam pisar o terreno à volta, preservando o espaço como sagrado.
⸻
4. Primeiro relato e fontes académicas primárias
O primeiro registo escrito da lenda encontra-se em Joaquim Alves Ferreira, Literatura de Trás-
os-Montes e Alto Douro – Lendas e Contos Infantis, vol. IV (Porto, 1954, pp. 41–47)*, com o título
“A Fiandeira de Agarez”. O autor recolheu a narrativa diretamente de informantes locais,
sublinhando a importância do trabalho do linho na origem da povoação.
Teófilo Braga, embora não cite Agarez, aborda lendas semelhantes em O Povo Português  nos
seus Costumes, Crenças e Tradições (1883, pp. 348–352), onde menciona “mulheres fiandeiras
encantadas que fundam povoados à beira das serras”.
Leite de Vasconcelos, Etnografia Portuguesa, vol. III (1914, pp. 287–291), analisa o mito do
trabalho feminino como origem do espaço social, associando-o às parcas greco-romanas e às
matres célticas.
Alexandre Parafita, em Mitologia Popular Portuguesa (2008), identifica Agarez como exemplo de
“lenda fundacional que consagra o feminino criador como força geológica e social”.
A sistematização contemporânea de Eduardo Mauer, Agarez: Mito, Trabalho e Memória no Alvão
(Lisboa, Associação MILK, 2024), amplia essa abordagem, propondo que a Fiandeira simboliza o
gesto artesanal como resistência cultural.
Fontes complementares:
– Arquivo Distrital de Vila Real, Crónica do Padre José  Rodrigues (1871);
– Museu da Vila Velha, Coleção  do Ciclo do Linho (1890–1930);
– Tese de Mestrado de Sofia Nogueira, Trabalho e Feminino no Folclore Transmontano (U. Porto,
2017).


⸻
5. Síntese interpretativa final
A Lenda da Povoação de Agarez é narrativa fundacional do labor como gesto sagrado. Nela, o
ato de fiar — transformar a planta em fio, o fio em tecido, o tecido em abrigo — representa a
própria constituição da comunidade. O trabalho não é castigo, mas liturgia da criação.
A Fiandeira de Agarez é símbolo do poder feminino da matéria e do tempo. O seu tear é o
universo, e cada fio representa a continuidade entre gerações. O mito ensina que habitar é tecer.
Na escultura MILK concebida por Eduardo Mauer, a figura surge sentada, corpo compacto,
cabeça grande e mãos abertas em gesto de fiar. O fio, moldado em resina transparente, liga a
figura ao solo. As cores — tons de linho, areia e azul-pálido — evocam serenidade e
permanência.
⸻
6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer
Na leitura não binária proposta por Eduardo Mauer, a Fiandeira de Agarez é arquétipo da
energia criadora além do género. Embora representada como mulher, o seu papel é universal:
ela é o tempo que produz, o corpo que faz existir.
Mauer interpreta a figura como “entidade queer do trabalho”, pois incorpora tanto a força física
(tradicionalmente atribuída ao masculino) quanto a delicadeza criativa (associada ao feminino). A
Fiandeira é o corpo intermédio que dissolve binarismos — tecelã e matéria, criadora e criada.
Na visão contemporânea da Associação  MILK, Agarez simboliza a economia afetiva e circular da
cultura: o fazer coletivo como ato de identidade fluida. Fiar é conectar — e toda conexão é gesto
não binário.
⸻
7. Referência Estrutural da Matriz MILK
Na Matriz Escultórica MILK, a Fiandeira de Agarez é modelada em posição sentada, com fio
translúcido ligando as mãos ao chão. Cabeça grande, expressão tranquila e corpo robusto. As
cores predominantes são creme, bege e azul-claro. O acabamento é fosco, com detalhes
acetinados nos fios.
A instalação expositiva pode incluir som de tear e murmúrio de água corrente, simbolizando o
ritmo da vida e do trabalho.
⸻
Localização  específica: Serra do Alvão, freguesia de Agarez, concelho de Vila Real, Trás-os-
Montes e Alto Douro.
Primeiro relato documentado: Joaquim Alves Ferreira, Literatura de Trás-os-Montes  e Alto
Douro – Lendas e Contos Infantis, vol. IV, 1954.
Sistematização  contemporânea:  Eduardo Mauer, Agarez: Mito, Trabalho e Memória no Alvão ,
Associação MILK, 2024.
Fontes primárias:  Ferreira (1954); Braga (1883); Vasconcelos (1914); Parafita (2008); Nogueira
(2017); Mauer (2024).
