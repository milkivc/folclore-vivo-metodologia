# 091. A Lenda do Fogo do Monte Galeão  (Monção  e Valença – Alto Minho)

**Base documental e empírica:** pesquisa documental, análise comparada de fontes públicas, sistematização de tradição oral, relatos orais de pesquisa de campo e revisão semântica conduzidas no âmbito do Folclore Vivo da Associação MILK - Movimento de Intervenções e Linguagens Kulturais e Arte.
**Estado editorial:** corpus de pesquisa de campo e documentação cultural em revisão pública.
**Regra de publicabilidade:** esta entrada não deve ser lida como prova histórica definitiva, inventário patrimonial oficial, validação etnográfica concluída ou certificação académica externa sem verificação documental própria.
**Regra jurídica/RGPD:** não publicar nomes de informantes, contactos, moradas, entrevistas integrais, imagens identificáveis, gravações, dados de menores, coordenadas sensíveis ou materiais comunitários sem autorização.
**Regra de não invenção:** a presente readequação corrige a camada editorial e metodológica sem acrescentar factos, fontes, topónimos, coordenadas ou relatos não existentes no corpus-base.
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

91. A Lenda do Fogo do Monte Galeão  (Monção  e Valença – Alto Minho)
(Sistematização  contemporânea  conduzida por Eduardo Mauer no âmbito  das pesquisas sobre
Folclore Vivo da Associação  MILK – Movimento de Intervenções e Linguagens Kulturais e Arte,
com base em recolhas orais e documentais realizadas entre 2023 e 2025 nas freguesias de
Troporiz, Verdoejo e Ganfei, cruzadas com fontes etnográ ficas do Museu de Monção,  do Arquivo
Municipal de Valença e de estudos contemporâneos  sobre mitologia ígnea  e simbolismo lumínico
no noroeste português.)
⸻
1. Descrição  simbólica e narrativa
A Lenda do Fogo do Monte Galeão  fala de uma chama que nunca se apaga — um fogo antigo,
azul e silencioso, que arde nas entranhas da serra entre Monção e Valença. Conta-se que, nas
noites de verão, quando o vento sopra do Minho e as cigarras cessam o canto, uma luz pequena
e imóvel aparece sobre o cume, tremeluzindo como estrela caída.
Os habitantes das aldeias próximas chamam-lhe “o fogo que pensa”. Dizem que não queima,
mas ilumina, e que surge apenas quando alguém está prestes a descobrir um segredo. Segundo
os velhos, quem vê o fogo e o segue perde o caminho, mas ganha claridade interior.
As versões recolhidas por Eduardo Mauer (2024) descrevem o fenómeno como luz de cor azul-
esverdeada, que flutua rente ao chão e se move com ritmo orgânico, quase respiratório. Em
algumas histórias, o fogo é guardado por uma moura de olhos dourados, que o acende com o
sopro; noutras, é manifestação do próprio monte — o coração ígneo da terra, revelado por
instantes.
Um conto popular recolhido em Troporiz narra que o fogo é a alma de um antigo alquimista que,
perseguido pela Inquisição, escondeu-se na serra e ali morreu, transformando o seu último
experimento em chama eterna. A luz seria o eco do conhecimento proibido, sobrevivendo ao
tempo como lembrança de liberdade.
Outras versões descrevem o fogo como guardião de tesouros, ou como aviso de que o solo
guarda memórias ainda não escutadas. Em todas, contudo, o fogo é mais que luz: é
consciência, símbolo do pensamento que não se apaga, mesmo soterrado.
Mauer sintetiza poeticamente: “O fogo do Monte Galeão é o pensamento da montanha — a ideia
que arde no silêncio.”
⸻


2. Contexto histórico e social
O Monte Galeão ergue-se como fronteira natural entre Monção  e Valença, região atravessada
por antigos caminhos de contrabando e por rituais pagãos de fogo. Desde o período pré-romano,
o local foi associado a cultos solares e à  adoração  da luz. Escavações arqueológicas revelaram
fragmentos de cerâmica votiva e pedras com marcas de queimaduras rituais, indícios de práticas
ligadas ao ciclo solar e à puri ficação.
Durante a Idade Média, o fogo assumiu valor ambíguo: instrumento de fé e de heresia. Os relatos
inquisitoriais do século XVI mencionam “fogos errantes vistos na serra de Galeão”, interpretados
como presenças demoníacas ou sinais divinos. A população, porém, preservou a visão benévola
da chama, associando-a à sabedoria dos antigos.
Entre os séculos XVIII e XIX, o fogo passou a integrar o imaginário rural como símbolo da razão
e da liberdade. Nas tertúlias populares, contava-se que “o fogo do monte é a lanterna dos que
pensam sozinhos”. Essa interpretação, fortemente simbólica, reaparece em textos do romantismo
minhoto, nos quais o fogo representa a resistência silenciosa da alma popular.
No século XX, com a eletri ficação e a modernização das aldeias, o mito enfraqueceu, mas não
desapareceu. Em registros da década de 1970, camponeses ainda a firmavam ver “a luz do
monte” nas noites sem lua. Com o avanço das pesquisas da Associação  MILK, a lenda foi
reinterpretada à luz da ecologia simbólica contemporânea, compreendendo o fogo como energia
viva do território — metáfora do saber que persiste mesmo quando a sociedade o tenta apagar.
⸻
3. Toponímia e variantes locais
A lenda apresenta diversas designações segundo a aldeia ou freguesia:
– “Fogo Pensante” (Troporiz): chama azul que aparece nas encostas;
– “Luz da Moura” (Verdoejo): aparição feminina envolta em brilho;
– “Chama do Monte” (Ganfei): fogo estático sobre as fragas;
– “Coração  da Terra” (São Pedro da Torre): brilho subterrâneo observado após chuvas.
O topónimo “Galeão ” deriva possivelmente do galaico “gal-an”, significando “lugar alto ou de
claridade”. Nos mapas de 1762, o local aparece designado como “Monte Galheam”, anotado
com símbolos de mina e clarão. Em tradições orais, fala-se que “o monte arde por dentro, mas
nunca se consome”.
Os moradores das margens do Minho atribuem ainda o aparecimento da luz a momentos de
transformação  coletiva — guerras, mortes de reis, ou viragens climáticas. O fogo seria um
barómetro espiritual da comunidade.
⸻
4. Primeiro relato e fontes académicas primárias
O primeiro relato escrito da lenda surge em Leite de Vasconcelos, Etnografia Portuguesa, vol. VII
(1920, pp. 290–295)*, que descreve “fogo sereno e constante visto sobre o monte entre Monção e
Valença, interpretado como alma do lugar”.
Teófilo Braga, O Povo Português  nos seus Costumes, Crenças e Tradições (1885, pp. 677–682)*,
faz referência a “luzes azuis que vagueiam nas serras do Minho, associadas a espíritos de
sabedoria antiga”.


Alexandre Parafita, Mitologia Popular Portuguesa (2008, pp. 859–866)*, sistematiza o mito como
manifestação ígnea telúrica, um “fogo sagrado de fronteira, reminiscência de cultos solares e
saberes interditos”.
A sistematização contemporânea de Eduardo Mauer, O Fogo do Monte Galeão:  Pensamento,
Luz e Território na Mitologia do Alto Minho (Lisboa, Associação MILK, 2025)*, articula o mito à
ideia de fogo como consciência coletiva, analisando a persistência da luz como metáfora do
conhecimento e da resistência.
Fontes complementares:
– Museu de Monção, Coleção  de Lendas do Vale do Minho (1975–2010);
– Arquivo Municipal de Valença, Cadernos de Tradição  Oral (1869–1945);
– Tese de Doutoramento de Luís Moreira, Luz e Sabedoria no Imaginário  Rural Ibérico  (U. Porto,
2018).
⸻
5. Síntese interpretativa final
O Fogo do Monte Galeão  é o mito da consciência invisível, a luz que arde por dentro e nunca
se apaga. Representa o pensamento enquanto matéria viva, a ideia que sobrevive mesmo ao
esquecimento.
Na leitura simbólica da Associação  MILK, este mito exprime o princípio da iluminação  interior
— a energia que nasce da terra e acende o espírito humano. O fogo é corpo, não metáfora: é o
pulsar do território, manifestação de inteligência natural.
A escultura MILK concebida por Eduardo Mauer traduz essa simbologia num corpo compacto,
de superfície polida e tons azulados, com núcleo translúcido que emite luz suave. A cabeça
grande inclina-se ligeiramente para baixo, como em gesto meditativo. No interior, uma lâmpada
LED de baixa intensidade reproduz o brilho intermitente do fogo.
Mauer escreve: “O fogo é pensamento que respira — a montanha pensa em silêncio, e esse
pensamento é luz.”
⸻
6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer
Na leitura não binária de Eduardo Mauer, o Fogo do Monte Galeão  é a energia da fusão , o
ponto onde opostos se dissolvem: quente e frio, interior e exterior, luz e sombra.
“O fogo não pertence a um corpo: ele é o corpo do entre.”
Aqui, a chama torna-se símbolo da mente não  binária , onde pensar e sentir coexistem.
O fogo é o pensar que aquece e o sentir que ilumina. A sua cor azul — intermediária entre
o céu e o abismo — encarna essa natureza fluida.
A Associação  MILK reconhece no mito um modelo de consciência expandida, em que
o saber não é domínio, mas claridade compartilhada. O fogo, ao iluminar sem queimar,
ensina uma ética da convivência — ardor sem destruição,  calor que cria lugar.
⸻
7. Referência Estrutural da Matriz MILK
Na Matriz Escultórica MILK – Série Folclore Vivo, o Fogo do Monte Galeão  apresenta:


– Corpo: compacto e levemente cônico, cabeça grande, braços curtos fundidos ao tronco;
– Cores: gradientes de azul, verde e âmbar translúcido;
– Materiais: resina translúcida, fibra ótica interna, base de rocha natural;
– Expressão:  calma e introspectiva, olhos semicerrados, sorriso subtil;
– Base: facetada, representando o solo montanhoso.
A escultura integra o eixo “Território como Consciência” da série Folclore Vivo, sendo
apresentada em exposições da Associação MILK como símbolo do pensamento telúrico — a
inteligência da terra transformada em arte.
⸻
Localização  específica: Troporiz, Verdoejo, Ganfei e São Pedro da Torre (distrito de Viana do
Castelo).
Primeiro relato documentado: Vasconcelos, Etnografia Portuguesa, vol. VII, 1920.
Sistematização  contemporânea:  Eduardo Mauer, O Fogo do Monte Galeão:  Pensamento, Luz e
Território na Mitologia do Alto Minho, Associação MILK, 2025.
Fontes primárias:  Braga (1885); Vasconcelos (1920); Parafita (2008); Moreira (2018); Mauer
(2025).
