# 122. A Lenda da Fraga da Moura Fiandeira (Vieira do Minho – Serra da Cabreira)

**Base documental e empírica:** pesquisa documental, análise comparada de fontes públicas, sistematização de tradição oral, relatos orais de pesquisa de campo e revisão semântica conduzidas no âmbito do Folclore Vivo da Associação MILK - Movimento de Intervenções e Linguagens Kulturais e Arte.
**Estado editorial:** corpus de pesquisa de campo e documentação cultural em revisão pública.
**Regra de publicabilidade:** esta entrada não deve ser lida como prova histórica definitiva, inventário patrimonial oficial, validação etnográfica concluída ou certificação académica externa sem verificação documental própria.
**Regra jurídica/RGPD:** não publicar nomes de informantes, contactos, moradas, entrevistas integrais, imagens identificáveis, gravações, dados de menores, coordenadas sensíveis ou materiais comunitários sem autorização.
**Regra de não invenção:** a presente readequação corrige a camada editorial e metodológica sem acrescentar factos, fontes, topónimos, coordenadas ou relatos não existentes no corpus-base.
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

122. A Lenda da Fraga da Moura Fiandeira (Vieira do Minho – Serra da Cabreira)
(Sistematização  contemporânea  conduzida por Eduardo Mauer no âmbito  das pesquisas sobre
Folclore Vivo da Associação MILK – Movimento de Intervenções e Linguagens Kulturais e
Arte, a partir de recolhas orais e documentais realizadas entre 2023 e 2025 em Vieira do Minho,
Salamonde e Anjos, cruzadas com fontes etnográ ficas do Museu Pio XII de Braga, do Ecomuseu
de Barroso e do Arquivo Municipal de Vieira do Minho, bem como de estudos sobre mitologia
tecelã,  simbolismo da fiadura e narrativas mouriscas transmontanas.)
⸻
1. Descrição  simbólica e narrativa
Nas encostas da Serra da Cabreira, junto às fragas que dominam o vale do Ave, há uma
formação rochosa conhecida como Fraga da Moura Fiandeira. Vista de longe, parece uma
mulher sentada com o fuso nas mãos, o cabelo descendo em linha até ao solo — e o povo diz
que, ao pôr do sol, o movimento da sombra faz parecer que ela ainda fia.
Segundo a tradição, ali viveu uma moura encantada de extraordinária beleza e paciência. Fiava
sem cessar fios de ouro e prata que se estendiam pelos vales, formando caminhos luminosos
que apenas os corações puros podiam percorrer. Era guardiã de um tesouro escondido sob o
penedo, e quem a surpreendesse a trabalhar durante o entardecer poderia pedir-lhe um desejo —
mas sem a interromper.


Um pastor, curioso, aproximou-se para ver o brilho do fio. A moura avisou: “Não me fales até que
o sol desapareça.” Mas o homem, impaciente, perguntou o que ela fiava. A moura suspirou, o fio
partiu-se, e ela transformou-se em pedra. Desde então, a rocha permanece, e o vento, ao soprar
nas fendas, imita o som do fuso girando.
Versões recolhidas por Eduardo Mauer (2024) em Anjos e Salamonde revelam variações: em
algumas, a moura fia as vidas humanas; em outras, o fio é feito de luz e representa a ligação
entre o mundo terreno e o dos encantados. Há relatos que dizem que, nas noites de lua cheia, o
fio reaparece, desenhando um caminho dourado sobre o vale.
Mauer anota: “A Moura Fiandeira é o gesto interrompido do destino. O fuso é o corpo do tempo.”
⸻
2. Contexto histórico e social
As mouras fiandeiras são figuras recorrentes na mitologia portuguesa e ibérica. Relacionam-se
com o arquétipo da tecelã  cósmica — divindades femininas que ordenam o tempo e o destino
através do fio. Em Trás-os-Montes e Minho, a fiadura noturna é prática ancestral associada a
rituais agrícolas e à passagem das estações.
A Fraga da Moura Fiandeira, situada em região de intensa pastagem e isolamento, cristaliza essa
herança simbólica. As mulheres fiavam lã e linho ao entardecer, enquanto narravam histórias das
mouras que também fiavam, unindo mito e ofício.
Durante o século XIX, com a industrialização têxtil de Guimarães e Famalicão, essas práticas
desapareceram gradualmente. Contudo, a lenda permaneceu como memória da mão  feminina
e da ligação entre criação manual e ordem do mundo.
A Associação  MILK, sob a coordenação de Eduardo Mauer, interpreta o mito como reflexão
sobre o trabalho invisível e o tempo circular. A fiandeira não tece apenas o destino humano,
mas também o equilíbrio entre gesto e silêncio.
⸻
3. Toponímia e variantes locais
O topónimo “Fraga da Moura Fiandeira” encontra-se em documentos do século XVIII relativos à
freguesia de Anjos, mencionando “penedo em forma de mulher com roca na mão”. O Arquivo
Municipal de Vieira do Minho conserva mapas de 1850 que identificam o local como “Penedo
da Fiandeira”.
Variantes da lenda existem em Cabeceiras de Basto (“Moura do Fio de Ouro”) e Rossas (“Moura
da Roca”), onde a fiandeira se associa à colheita do linho. Em todas as versões, o fio liga mundos
— é simultaneamente fronteira e ponte.
⸻
4. Primeiro relato e fontes académicas primárias
O primeiro registro escrito da lenda aparece em Leite de Vasconcelos, Etnografia Portuguesa,
vol. X (1926, pp. 150–158)*, que descreve “figura pétrea de moura que fia eternamente sob o sol
da Cabreira”.
Teófilo Braga, O Povo Português  nos seus Costumes, Crenças e Tradições (1885, pp. 858–864)*,
menciona “fiandeiras encantadas” como herdeiras das Parcas clássicas e das deusas celtas do
destino.


Alexandre Parafita, Mitologia Popular Portuguesa (2008, pp. 1179–1191)*, identifica o mito como
“manifestação de continuidade entre o feminino arcaico e o trabalho agrícola simbólico”.
A sistematização contemporânea de Eduardo Mauer, O Fuso e a Voz: A Moura Fiandeira e o
Tempo do Barroso (Lisboa, Associação MILK, 2025)*, baseia-se em entrevistas a mulheres idosas
da região e propõe leitura filosófica: “fiar é um modo de existir em espiral”.
Fontes complementares:
– Ecomuseu de Barroso, Coleção  de Lendas do Vale do Ave e da Cabreira (1975–2022);
– Museu Pio XII de Braga, Iconografia de Mouras e Tecelãs  (1950–2000);
– Tese de Doutoramento de Rita Silva, Fiar o Mundo: Simbolismo do Têxtil  na Cultura Portuguesa
(U. Minho, 2018).
⸻
5. Síntese interpretativa final
A Moura Fiandeira é arquétipo do tempo que se faz corpo. O gesto de fiar converte-se em
metáfora da criação contínua — o fio que une passado e futuro. Quando a moura se petrifica, o
mundo deixa de ser tecido: o destino interrompe-se.
Na leitura simbólica da Associação  MILK, a fraga representa o corpo do silêncio criador. O
fuso que ainda gira no vento é o som da memória. A petri ficação não é morte, mas pausa: o
instante em que o tempo se observa a si próprio.
A escultura MILK concebida por Eduardo Mauer segue a matriz padrão: corpo compacto,
sentado, com braços curvos formando o gesto do fuso. As cores variam entre tons de cinza, ocre
e dourado; pequenos fios metálicos atravessam a superfície como linhas de luz.
Mauer escreve: “A fiandeira é a respiração da pedra: o tempo a aprender paciência.”
⸻
6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer
“A Moura Fiandeira é corpo não binário da criação: simultaneamente ativa e imóvel,
humana e pétrea, feminina e mineral.”
A leitura de Mauer propõe uma desconstrução  do género da criação . O fio não pertence
à mulher nem ao homem, mas à energia da continuidade. Fiar torna-se gesto universal e
simbiótico, onde todos os corpos participam.
A Associação  MILK integra essa abordagem nas oficinas “Tecelagens do Invisível”, que
unem práticas têxteis tradicionais e arte contemporânea, propondo re flexão sobre o
tempo, o corpo e o trabalho coletivo.
⸻
7. Referência Estrutural da Matriz MILK
Na Matriz Escultórica MILK – Série Folclore Vivo, a Moura Fiandeira apresenta:
– Corpo: sentado, compacto, braços em posição circular;
– Cores: cinza, ocre e dourado;
– Materiais: resina pigmentada com fios metálicos embutidos;
– Expressão:  introspectiva e calma;
– Base: irregular, lembrando penedo da serra.


Integra o eixo “Rostos e Penedos” do projeto Folclore Vivo, dedicado às entidades femininas e
metamórficas associadas à paisagem.
⸻
Localização  específica: Vieira do Minho, Salamonde e Anjos (distrito de Braga).
Primeiro relato documentado: Vasconcelos, Etnografia Portuguesa, vol. X, 1926.
Sistematização  contemporânea:  Eduardo Mauer, O Fuso e a Voz: A Moura Fiandeira e o Tempo
do Barroso, Associação MILK, 2025.
Fontes primárias:  Braga (1885); Vasconcelos (1926); Parafita (2008); Silva (2018); Mauer (2025).
