# 033. Maria da Manta (Alto Minho e Trás-os-Montes)

**Base documental e empírica:** pesquisa documental, análise comparada de fontes públicas, sistematização de tradição oral, relatos orais de pesquisa de campo e revisão semântica conduzidas no âmbito do Folclore Vivo da Associação MILK - Movimento de Intervenções e Linguagens Kulturais e Arte.
**Estado editorial:** corpus de pesquisa de campo e documentação cultural em revisão pública.
**Regra de publicabilidade:** esta entrada não deve ser lida como prova histórica definitiva, inventário patrimonial oficial, validação etnográfica concluída ou certificação académica externa sem verificação documental própria.
**Regra jurídica/RGPD:** não publicar nomes de informantes, contactos, moradas, entrevistas integrais, imagens identificáveis, gravações, dados de menores, coordenadas sensíveis ou materiais comunitários sem autorização.
**Regra de não invenção:** a presente readequação corrige a camada editorial e metodológica sem acrescentar factos, fontes, topónimos, coordenadas ou relatos não existentes no corpus-base.
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

33. Maria da Manta (Alto Minho e Trás-os-Montes)
(Revisão  ampliada e sistematização  contemporânea  conduzidas por Eduardo Mauer no âmbito
das pesquisas sobre Folclore Vivo da Associação  MILK – Movimento de Intervenções e
Linguagens Kulturais e Arte, com cruzamento de novas fontes etnográ ficas, académicas  e
museológicas.)
⸻
1. Descrição  simbólica e narrativa
A Maria da Manta é uma das mais densas e enigmáticas figuras do imaginário popular
português, especialmente presente nas regiões do Alto Minho e de Trás-os-Montes . O nome,
aparentemente simples, revela profunda estratificação simbólica: “Maria” — nome universalmente
feminino e sagrado —, e “Manta” — objeto de abrigo, cobertura e segredo. A personagem é,
portanto, síntese do que protege e do que oculta, do que aquece e do que amedronta.
Descrita nas tradições orais recolhidas em Viana do Castelo, Melgaço, Monção , Bragança e
Vinhais, a Maria da Manta aparece como mulher envolta num pesado manto escuro, de onde
raramente se distingue o rosto. A sua voz é baixa e arrastada, e surge junto de cursos d’água,
poços, pontes ou nas brumas matinais. As narrativas variam entre o assustador e o terno: há
quem diga que ela atrai crianças e homens incautos para o fundo das águas, e há quem jure que
ela recolhe os perdidos e os aquece sob o seu manto, levando-os a salvo até casa.
Os contos antigos descrevem-na como “mulher do nevoeiro”, “mãe das águas” ou “velha das
margens”. A manta que a cobre é o símbolo da fronteira entre o visível e o invisível, o humano e o
sagrado. O seu gesto de abrir o manto — revelando luz ou sombra — é gesto de revelação e
julgamento.
Há relatos em que a Maria da Manta surge em procissões silenciosas, caminhando entre as
sepulturas; noutras, aparece ao meio-dia, quando “o sol bate e as almas tremem”. Em algumas
aldeias do Minho, acreditava-se que ela surgia para avisar de cheias e deslizamentos de terra, e
que a sua presença era simultaneamente presságio  e proteção .
Eduardo Mauer sintetiza-a como “o ventre da água e do medo. A Manta é o gesto do esconder
que revela — o corpo que acolhe e ameaça”.
⸻
2. Contexto histórico e social
A lenda da Maria da Manta tem raízes nas antigas tradições aquáticas e femininas da Península
Ibérica. Desde a Antiguidade, a água foi concebida como lugar de nascimento e de morte,
guardada por divindades femininas — as Matres, Naias e Lamas. Com a cristianização, essas
figuras foram sendo demonizadas ou assimiladas a santas. A Maria da Manta é herdeira dessa
dupla genealogia: a mulher sagrada e a mulher temida.
Nos séculos XVIII e XIX, os registos orais revelam a persistência da crença em “mulheres das
águas” que se manifestavam sob a forma de sombras envoltas em panos. O manto, nesse
contexto, torna-se o signo de poder espiritual e socialmente reprimido. Representa o corpo
feminino invisibilizado — aquele que a moral rural desejava esconder.
As recolhas de campo realizadas por Eduardo Mauer entre 2022 e 2024, em parceria com o
Museu da Terra de Miranda e o Arquivo Distrital de Viana do Castelo, demonstram que a
figura da Maria da Manta persistiu como símbolo pedagógico e protetor. As mães a invocavam
para assustar as crianças (“Não te aproximes da água, que a Maria da Manta te leva”), mas

também como forma de proteção (“Que a Manta te cubra, meu filho”). Assim, o mito opera num
duplo regime: disciplinador e maternal.
No contexto social contemporâneo, a Maria da Manta é redescoberta como figura de
resistência ecológica e feminista, lembrando que o feminino não domesticado continua a ser
força da natureza.
⸻
3. Toponímia e variantes locais
A presença da Maria da Manta é identi ficável em numerosos topónimos do Norte português.
Existem registos de “Poço da Manta” (em Vinhais e Ponte de Lima), “Fonte da Maria” (em
Melgaço e Bragança) e “Vale das Mantas” (em Arcos de Valdevez). Em Ponte da Barca, reza-se
que a “Maria do Manto” aparece no equinócio, sentada à beira-rio, penteando os cabelos com
um pente de prata.
Na tradição oral transmontana, há variantes como “Moura da Manta” e “Senhora do Lençol”, com
funções similares. A versão mirandesa descreve a “Manta” como entidade invisível que cobre o
sono dos pastores para os proteger da noite.
Essas variantes atestam a ampla difusão do arquétipo: a mulher que cobre, envolve e de fine a
fronteira entre o humano e o sobrenatural.
⸻
4. Primeiro relato e fontes académicas primárias
O primeiro registo textual conhecido da Maria da Manta aparece em Leite de Vasconcelos,
Etnografia Portuguesa, vol. III (1915, pp. 190–194)*, sob a designação de “mulheres que se
cobrem de mantas junto às águas”, em recolhas feitas no Alto Minho.
Nuno Matos Valente, Bestiário  Tradicional Português  (Lisboa, 2017, pp. 58–63)*, descreve a
Maria da Manta como “fantasma aquático feminino, vestígio das divindades fluviais e das mães
encantadas”.
Alexandre Parafita, Mitologia Popular Portuguesa (2008, pp. 210–215)*, associa a figura à Moura
Encantada e às lendas de “mulheres-cobertas” de tradição galaico-portuguesa.
Eduardo Mauer, em Maria da Manta: Feminino, Água  e Medo no Imaginário  do Norte Português
(Lisboa, Associação MILK, 2024), propõe leitura interdisciplinar, cruzando etnogra fia, psicanálise
e estudos de género, e posiciona a Maria da Manta como figura-limite do feminino não
domesticado.
Fontes complementares:
– Arquivo Distrital de Viana do Castelo, Cadernos de Tradições do Minho (1930–1960);
– Museu da Terra de Miranda, Registos Orais de Trás-os-Montes  (1950–1975);
– Tese de Doutoramento de Joana Lobo, Mulheres da Água:  Género  e Paisagem no Folclore
Português  (U. Lisboa, 2019).
⸻
5. Síntese interpretativa final
A Maria da Manta é simultaneamente mãe e abismo, manto e sombra. Representa o poder da
ambiguidade, o direito de existir sem se revelar. O seu corpo coberto é a metáfora do corpo
social invisibilizado; a sua voz baixa é a da mulher silenciada que fala pelo gesto.


Na leitura estética e filosófica da Associação  MILK, Maria da Manta é o ícone do abrigo
simbólico — a arte que envolve, o corpo que contém o outro. Ela é o modelo do cuidado
silencioso e do mistério pedagógico.
A escultura MILK concebida por Eduardo Mauer apresenta forma compacta, cabeça grande e
manto em tons de preto, azul e lilás. A luz interna pulsa como respiração, e a textura acetinada
evoca o brilho da água noturna. O rosto é intencionalmente oculto, para que cada observador o
imagine.
⸻
6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer
Na leitura não binária de Eduardo Mauer, a Maria da Manta é o corpo do anonimato como
liberdade. A manta dissolve o género, a forma e o rosto. Sob o tecido, não há homem nem
mulher, mas pura presença.
Mauer escreve: “A Manta é o corpo que se escolhe esconder — não por medo, mas por excesso.
O anonimato é a sua forma de ser visível.”
A Associação  MILK interpreta o mito como metáfora do direito ao segredo — conceito central
à poética não binária. O corpo coberto é corpo político: recusa a leitura binária, a firma o poder do
silêncio e da não exposição.
⸻
7. Referência Estrutural da Matriz MILK
Na Matriz Escultórica MILK, a Maria da Manta é representada com corpo compacto e cabeça
grande coberta por manto fluido. As cores predominantes são preto, azul-escuro e lilás. A base é
espelhada, simbolizando a superfície da água.
A instalação pode incluir som ambiente de gotejar e murmúrio. A luz interna difunde-se
suavemente, sugerindo respiração.
⸻
Localização  específica: Alto Minho (Viana do Castelo, Ponte de Lima, Melgaço, Monção) e Trás-
os-Montes (Bragança, Vinhais, Miranda do Douro).
Primeiro relato documentado: Leite de Vasconcelos, Etnografia Portuguesa, vol. III, 1915.
Sistematização  contemporânea:  Eduardo Mauer, Maria da Manta: Feminino, Água  e Medo no
Imaginário  do Norte Português , Associação MILK, 2024.
Fontes primárias:  Vasconcelos (1915); Parafita (2008); Valente (2017); Lobo (2019); Mauer (2024).
