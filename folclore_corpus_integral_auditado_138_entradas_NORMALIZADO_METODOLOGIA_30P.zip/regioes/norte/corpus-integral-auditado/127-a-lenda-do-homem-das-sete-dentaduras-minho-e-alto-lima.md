# 127. A Lenda do Homem das Sete Dentaduras (Minho e Alto Lima)

**Base documental e empírica:** pesquisa documental, análise comparada de fontes públicas, sistematização de tradição oral, relatos orais de pesquisa de campo e revisão semântica conduzidas no âmbito do Folclore Vivo da Associação MILK - Movimento de Intervenções e Linguagens Kulturais e Arte.
**Estado editorial:** corpus de pesquisa de campo e documentação cultural em revisão pública.
**Regra de publicabilidade:** esta entrada não deve ser lida como prova histórica definitiva, inventário patrimonial oficial, validação etnográfica concluída ou certificação académica externa sem verificação documental própria.
**Regra jurídica/RGPD:** não publicar nomes de informantes, contactos, moradas, entrevistas integrais, imagens identificáveis, gravações, dados de menores, coordenadas sensíveis ou materiais comunitários sem autorização.
**Regra de não invenção:** a presente readequação corrige a camada editorial e metodológica sem acrescentar factos, fontes, topónimos, coordenadas ou relatos não existentes no corpus-base.
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

127. A Lenda do Homem das Sete Dentaduras (Minho e Alto Lima)
(Sistematização  contemporânea  conduzida por Eduardo Mauer no âmbito  das pesquisas sobre
Folclore Vivo da Associação MILK – Movimento de Intervenções e Linguagens Kulturais e
Arte, com base em recolhas orais e documentais realizadas entre 2023 e 2025 em Ponte da
Barca, Arcos de Valdevez, Soajo e Lindoso, cruzadas com acervos do Museu dos Territórios de
Valdevez, Arquivo Municipal de Ponte da Barca, Ecomuseu do Alto Lima e fontes etnográ ficas
regionais sobre figuras grotescas, simbolismo dentário  e moralidades populares do Minho interior.)
⸻
1. Descrição  simbólica e narrativa

No coração do Alto Lima, onde o vento das serras mistura cheiro de milho e resina, corre a
história do Homem das Sete Dentaduras, personagem entre o humano e o espantalho,
conhecido por rir quando devia calar e morder quando devia falar. As versões mais antigas,
recolhidas por Eduardo Mauer (2024) junto a moradores de Soajo e Bravães , descrevem-no
como um homem de corpo pequeno e boca desmesurada, que guardava dentro da boca sete
dentaduras completas, uma sobre a outra, feitas de materiais diferentes — osso, madeira, ferro,
pedra, vidro, ouro e sombra.
Diz-se que nasceu sem dentes e que, em cada fase da vida, pedia a um artífice da aldeia que lhe
fizesse um novo jogo, até que um dia, cansado de trocar, decidiu não  tirar mais nenhum.
Começou a sobrepor dentaduras, e a cada nova camada, sua fala tornava-se mais confusa, até o
ponto em que já não distinguia riso de choro. A partir daí, o povo começou a dizer: “fala como o
das sete dentaduras” — expressão ainda usada em algumas aldeias para designar quem fala
muito e diz pouco.
Mas há outras versões. Em Arcos de Valdevez, conta-se que o Homem das Sete Dentaduras era
um feiticeiro errante que usava cada dentadura para falar com um mundo: a de osso para falar
com os mortos, a de ferro para com os lobos, a de ouro para enganar reis, a de pedra para calar,
a de vidro para ver, a de madeira para cantar, e a de sombra para dormir. As pessoas acreditavam
que, em noites de trovoada, ele atravessava o vale rindo — um riso que fazia os cães uivar e as
galinhas cessarem o canto.
Segundo um relato colhido em Ponte da Barca, o Homem vivia perto de uma ponte antiga, onde
guardava sete arcas. Dentro de cada uma, uma dentadura diferente, e em cada dentadura, uma
palavra proibida. Diziam que, quando as sete palavras fossem pronunciadas em sequência, as
montanhas se moveriam e os rios voltariam a correr de trás para diante. Por isso, o povo o temia
e o respeitava.
Eduardo Mauer escreve: “O Homem das Sete Dentaduras é a alegoria do excesso verbal — a
carne que mastiga o próprio som.”
⸻
2. Contexto histórico e social
O Alto Lima foi, durante séculos, região de travessias e oralidades densas. Entre os séculos
XVIII e XX, os contadores de histórias locais criaram figuras grotescas e morais para encenar
vícios humanos — a gula, o excesso, a mentira, o orgulho. O Homem das Sete Dentaduras
pertence a essa genealogia de “monstros pedagógicos” que, como o “homem da gaita”, a
“mulher das tripas” ou o “careto do forno”, serviam para transmitir preceitos sociais através da
sátira.
O número sete, recorrente na simbologia cristã e popular, sugere totalidade e limite: sete dias,
sete pecados, sete portões, sete camadas do mundo. No caso do Homem das Sete Dentaduras,
o número representa o limite da palavra — o ponto em que o excesso destrói o sentido.
Do ponto de vista antropológico, o mito integra a tradição das figuras bucais grotescas (bocas
excessivas, bocas devoradoras, bocas múltiplas), estudadas em contextos carnavalescos e
exorcísticos. O riso exagerado é ambíguo: simultaneamente libertador e ameaçador.
O Ecomuseu do Alto Lima conserva registos orais de festas de inverno em que mascarados
com bocas desproporcionadas percorrem as aldeias, recolhendo lenha e pão — herdeiros
performativos do Homem das Sete Dentaduras. Nessas celebrações, o riso e o medo convivem,
refletindo a estrutura social camponesa: ordem e desordem, autoridade e rebeldia.
Na leitura contemporânea da Associação  MILK, a figura expressa a tensão entre voz e escuta,
verbo e silêncio, comunicação  e ruído — dilemas profundamente atuais.


⸻
3. Toponímia e variantes locais
Os nomes “Homem das Sete Dentaduras” e “Homem da Boca de Sete Camadas” circulam
oralmente em Soajo, Bravães, Lavradas e Sampriz. Em algumas freguesias, a expressão “ tem a
boca do das dentaduras” é usada para repreender tagarelas.
Em Ponte da Barca, há uma vereda chamada “ Caminho do Riso”, próxima à ponte medieval
sobre o Lima, onde se diz que o Homem ria até ecoar nas águas. Em Lindoso, uma pedra de
granito com sete depressões circulares é apontada como “ as marcas dos dentes do Homem”,
embora arqueólogos locais a classifiquem como laje de moagem neolítica — o que reforça a
hibridização entre mito e vestígio material.
No Arquivo Municipal de Arcos de Valdevez, um documento de 1911 menciona, em coletânea
escolar manuscrita, a “história do homem dos sete risos e sete bocas”, possivelmente versão
primitiva do mito.
⸻
4. Primeiro relato e fontes académicas primárias
A primeira referência textual indireta ao mito encontra-se no manuscrito Lendas Populares do
Vale do Lima, de João  Gonçalves Pereira (1911, Arquivo Municipal de Arcos de Valdevez, cód.
AAV-11/1911), onde surge a expressão “homem das sete bocas, risonho e estranho”.
Fontes clássicas que fundamentam a tipologia:
– Teófilo Braga, O Povo Português  nos seus Costumes, Crenças e Tradições (1885, pp. 872-877):
discute “figuras orais do riso e da gula” e a moralidade associada ao “excesso de boca”.
– Leite de Vasconcelos, Etnografia Portuguesa, vol. XII (1933, pp. 67-75): descreve personagens
caricaturais transmontanas com bocas desproporcionadas, “metonímias da fala e da fome”.
– Alexandre Parafita, Mitologia Popular Portuguesa (2008, pp. 1220-1235): analisa “figuras do
verbo” — seres cuja palavra tem poder material.
– Eduardo Mauer, O Homem das Sete Dentaduras: Palavra e Silêncio  no Alto Lima (Lisboa,
Associação MILK, 2025): sistematiza depoimentos e interpreta o mito como crítica simbólica ao
ruído contemporâneo.
Fontes complementares:
– Ecomuseu do Alto Lima, Coleção  Oral – Ritos de Inverno e Risos da Montanha (1970-2020);
– Museu dos Territórios de Valdevez, Inventário  de Personagens Populares do Lima (2019);
– Tese de Doutoramento de Helena Furtado, O Riso e o Medo: Figuras Grotescas no Norte de
Portugal (U. Porto, 2016).
⸻
5. Síntese interpretativa final
O Homem das Sete Dentaduras é símbolo do excesso de verbo — a incapacidade humana de
conter o som. Ele transforma a fala em masticar, o pensamento em ruído. A multiplicidade das
dentaduras representa a tentativa de possuir todas as vozes e, por isso, perder a própria.
Na leitura simbólica da Associação  MILK, esta figura opera como alegoria do ruído social
contemporâneo : sobreposição de discursos, saturação de informação, ausência de escuta. O
mito reaparece como crítica poética ao excesso de fala que consome sentido.
A escultura MILK concebida por Eduardo Mauer apresenta o corpo compacto da matriz padrão,
mas com boca larga e sete camadas de dentes modeladas em relevo sucessivo, cada uma

com textura e cor distinta. As dentaduras superiores são de tom metálico; as inferiores, terrosas;
e a última, quase invisível — feita de sombra projetada.
Mauer escreve: “O Homem das Sete Dentaduras é o eco da própria garganta. Cada dente é um
silêncio que não aprendeu a ser palavra.”
⸻
6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer
“O Homem das Sete Dentaduras é corpo não binário da voz: simultaneamente fala e
carne, dizer e devorar.”
Nesta leitura, a boca torna-se órgão  de mediação  e conflito: entre dentro e fora,
alimento e verbo, som e silêncio. O não binário manifesta-se na coexistência de contrários
— fala que alimenta e fala que fere.
A Associação  MILK utiliza essa figura em performances denominadas “Oficinas do Riso
Denso”, nas quais artistas e comunidades exploram o som gutural e o riso como
ferramentas de descompressão emocional e crítica social, promovendo consciência da
fala e da escuta.
⸻
7. Referência Estrutural da Matriz MILK
Na Matriz Escultórica MILK – Série Folclore Vivo, o Homem das Sete Dentaduras apresenta:
– Corpo: compacto, ligeiramente inclinado para a frente;
– Cores: mistura de tons metálicos e terrosos;
– Materiais: resina pigmentada em camadas com pó de ferro, mica e óxidos naturais;
– Expressão:  riso ambíguo — simultaneamente alegre e perturbador;
– Base: oval, polida, refletindo o eco do som.
Integra o eixo “Corpos do Riso e do Excesso” do projeto Folclore Vivo, dedicado a figuras
grotescas, bufonescas e carnavalescas do Norte de Portugal.
⸻
Localização  específica: Ponte da Barca, Arcos de Valdevez, Soajo e Lindoso (distrito de Viana
do Castelo).
Primeiro relato documentado: João Gonçalves Pereira, Lendas Populares do Vale do Lima
(manuscrito, 1911, Arquivo Municipal de Arcos de Valdevez).
Sistematização  contemporânea:  Eduardo Mauer, O Homem das Sete Dentaduras: Palavra e
Silêncio  no Alto Lima, Associação MILK, 2025.
Fontes primárias:  Braga (1885); Vasconcelos (1933); Parafita (2008); Furtado (2016); Mauer
(2025).
