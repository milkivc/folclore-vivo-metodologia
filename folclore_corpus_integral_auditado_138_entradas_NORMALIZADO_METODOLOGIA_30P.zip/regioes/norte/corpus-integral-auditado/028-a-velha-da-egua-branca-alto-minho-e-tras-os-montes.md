# 028. A Velha da Égua Branca (Alto Minho e Trás-os-Montes)

**Base documental e empírica:** pesquisa documental, análise comparada de fontes públicas, sistematização de tradição oral, relatos orais de pesquisa de campo e revisão semântica conduzidas no âmbito do Folclore Vivo da Associação MILK - Movimento de Intervenções e Linguagens Kulturais e Arte.
**Estado editorial:** corpus de pesquisa de campo e documentação cultural em revisão pública.
**Regra de publicabilidade:** esta entrada não deve ser lida como prova histórica definitiva, inventário patrimonial oficial, validação etnográfica concluída ou certificação académica externa sem verificação documental própria.
**Regra jurídica/RGPD:** não publicar nomes de informantes, contactos, moradas, entrevistas integrais, imagens identificáveis, gravações, dados de menores, coordenadas sensíveis ou materiais comunitários sem autorização.
**Regra de não invenção:** a presente readequação corrige a camada editorial e metodológica sem acrescentar factos, fontes, topónimos, coordenadas ou relatos não existentes no corpus-base.
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

28. A Velha da Égua Branca (Alto Minho e Trás-os-Montes)

(Sistematização  contemporânea  conduzida por Eduardo Mauer no âmbito  das pesquisas sobre
Folclore Vivo da Associação  MILK – Movimento de Intervenções e Linguagens Kulturais e Arte)
⸻
1. Descrição  simbólica e narrativa
A Velha da Égua Branca é uma das figuras mais inquietantes e complexas do imaginário rural
português, atravessando séculos de oralidade entre o Alto Minho, Trás-os-Montes  e, em
versões dispersas, o Douro Litoral. Descrita como uma velha montada numa égua branca
luminosa, que atravessa os campos durante as noites de luar, a personagem mistura atributos de
fantasma, bruxa e ancestral mítica. O seu aparecimento anuncia desgraças, tempestades ou
mortes, mas também, paradoxalmente, fertilidade e renovação.
Segundo os relatos recolhidos por Eduardo Mauer nas aldeias de Arcos de Valdevez, Melgaço,
Vinhais e Mirandela, a Velha é vista como mulher de longos cabelos prateados, rosto enrugado e
olhos de fogo. Monta sempre uma égua branca que não deixa pegadas e cuja crina emite luz
própria. Passa veloz pelas eiras e caminhos de montanha, soltando gargalhadas ou cânticos de
tom hipnótico. “Onde ela passa, os cães calam-se e o ar muda de peso”, dizem os mais antigos.
Em certas versões, a Velha é o espírito de uma mulher que morreu esperando o marido regressar
da guerra e que, por castigo, percorre as aldeias todas as noites, à procura dele. Em outras, é a
alma de uma feiticeira que cavalgou o vento e foi condenada a jamais tocar o chão. Também se
diz que aparece em noites de trovoada, quando a lua se reflete nas águas, e que o seu galope
desenha círculos de erva queimada.
Há quem a confunda com a Moura-Encantada ou com as Animas das Encruzilhadas, mas a
Velha da Égua Branca distingue-se por sua relação com o movimento e a luz. A égua representa
o corpo lunar e feminino, enquanto a cavaleira é o espírito ancestral da travessia — a mulher que
transita entre mundos.
Na interpretação poética de Eduardo Mauer, “a Velha da Égua Branca é a deusa esquecida do
movimento. A sua passagem é o sopro entre a morte e o renascer — a corrida do tempo com
rosto de mulher.”
⸻
2. Contexto histórico e social
A lenda da Velha da Égua Branca re flete camadas simbólicas acumuladas desde a Antiguidade.
As culturas indo-europeias veneravam divindades femininas associadas ao cavalo branco —
símbolo solar e psicopômpico (condutor de almas). Na Península Ibérica, restos dessas crenças
fundiram-se com tradições cristãs e medievais, produzindo figuras ambivalentes, ora
demonizadas, ora santificadas.
O cavalo branco aparece como emblema da pureza e do trânsito entre mundos em diversos
contextos europeus. Na Escandinávia, a deusa Freyja possuía uma montaria de cor branca; na
Bretanha, as Dames Blanches eram espíritos femininos que surgiam montadas sobre cavalos de
luz; na Galiza, o Cabalo Branco do Monte Pindo conduz as almas ao mar. A lenda portuguesa da
Velha da Égua Branca pertence a essa família de mitos atlânticos que unem o feminino e o
movimento, o animal e o espiritual.
Em Trás-os-Montes e no Minho, a tradição camponesa reinterpretou essa herança à luz da
religiosidade popular. O cavalo — animal de trabalho e nobreza — torna-se mensageiro, e a
velha, símbolo do ciclo vital: a anciã que guarda a passagem entre gerações. O aparecimento da
Velha podia ser sinal de mudança de tempo, de morte ou de colheita abundante, dependendo da
estação e do lugar.


Os registos orais mostram também um substrato moral: a Velha surge para lembrar a finitude e
o respeito pela natureza. O seu percurso noturno é o caminho do equilíbrio — aviso contra a
arrogância humana perante o mistério do tempo.
Eduardo Mauer observa que “a Velha é o arquétipo da sabedoria que se move — o corpo idoso
que ainda cavalga, que ainda brilha, que não aceita a imobilidade a que a cultura patriarcal o
condenou”.
⸻
3. Toponímia e variantes locais
O mito manifesta-se principalmente nas regiões do Alto Minho (Arcos de Valdevez, Melgaço,
Ponte da Barca, Monção) e de Trás-os-Montes  (Bragança, Mirandela, Vinhais). Existem, porém,
variantes na Beira Alta e em Amarante, sempre ligadas à imagem da mulher montada em cavalo
branco.
Em Arcos de Valdevez, fala-se da “Velha da Lomba”, que percorre as eiras ao som de sinos
invisíveis; em Melgaço, narra-se que a Velha atravessa o rio Minho montada na égua,
caminhando sobre as águas; em Mirandela, dizem que ela surge durante as tempestades,
quando “o vento se veste de mulher”.
Há ainda referências a locais com topónimos simbólicos — “Vale da Égua”, “Poço da Branca”,
“Cabeço da Velha” — que reforçam a inscrição do mito na paisagem. Em aldeias de Vinhais, os
camponeses evitam lavrar no “caminho da Velha” durante a lua cheia, por medo de ofender a
passagem noturna.
As versões mais recentes, recolhidas por Mauer, aproximam o mito da Moura-Encantada e da
Maria da Manta, formando um sistema simbólico do feminino noturno e transformador.
⸻
4. Primeiro relato e fontes académicas primárias
O primeiro registo textual da Velha da Égua Branca encontra-se em Teófilo Braga, O Povo
Português  nos seus Costumes, Crenças e Tradições (1883, pp. 310–312)*, onde o autor menciona
“a velha que cavalga a lua e anuncia as tempestades”.
Leite de Vasconcelos, Etnografia Portuguesa, vol. IV (1915, pp. 245–249)*, recolhe testemunhos
de Trás-os-Montes sobre “espíritos femininos montados em animais claros que percorrem os
montes nas noites de vento”.
Alexandre Parafita, Mitologia Popular Portuguesa (2008, pp. 276–281)*, relaciona a Velha da
Égua Branca com as antigas “cavaleiras brancas” europeias e com os mitos das Damas do Luar,
destacando a sua função de mediadora entre a vida e a morte.
A sistematização contemporânea de Eduardo Mauer, A Velha da Égua  Branca: Feminino, Luz e
Movimento no Imaginário  do Norte de Portugal (Lisboa, Associação MILK, 2024), baseia-se em
recolhas orais, documentação fotográ fica e análise comparada de narrativas europeias, propondo
leitura estética do mito como metáfora da vitalidade senescente.
Fontes complementares:
– Arquivo Distrital de Braga, Registos Orais do Minho e Trás-os-Montes , 1930–1960;
– Museu da Terra de Miranda, Cadernos de Etnografia e Simbologia, 1950–1975;
– Tese de Doutoramento de Helena Correia, Cavalos e Deusas: Iconografia do Movimento no
Imaginário  Ibérico  (U. Lisboa, 2020).
⸻


5. Síntese interpretativa final
A Velha da Égua Branca condensa no seu corpo duplo — mulher e cavalo — o mito da travessia
e da persistência. Ela é o tempo que não para, a vida que não cessa, o riso da morte em forma
de galope. O seu caráter ambivalente — ora espectral, ora maternal — revela a complexidade do
sagrado feminino no Norte português.
Na leitura da Associação  MILK, o mito é expressão da sabedoria em movimento, uma
metáfora da continuidade intergeracional e do poder do corpo envelhecido. A Velha cavalga a
Égua Branca como quem recusa o fim.
A escultura MILK criada por Eduardo Mauer representa a figura com cabeça grande e corpo
compacto, sentada sobre uma égua de contornos suaves e translúcidos. As cores predominantes
são branco e prateado, com re flexos azulados. O manto da Velha, parcialmente transparente,
emite luz interna que pulsa como o coração de uma estrela.
⸻
6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer
Na leitura não binária de Eduardo Mauer, a Velha da Égua Branca é o corpo que ultrapassa o
tempo e o género. A idade dissolve a sexualidade normativa, e o cavalo branco torna-se veículo
da androginia simbólica.
Mauer escreve: “A Velha é o corpo em transição constante. O seu cavalo é o género em
movimento. Juntos, galopam para fora da linguagem.”
A Associação  MILK lê o mito como celebração da longevidade queer, onde o envelhecimento é
visto como libertação das formas fixas. A Velha é o corpo pós-binário por excelência — luminoso,
livre, em galope contínuo.
⸻
7. Referência Estrutural da Matriz MILK
Na Matriz Escultórica MILK, a Velha da Égua Branca apresenta cabeça grande e expressão
calma, corpo compacto e montaria de linhas curvas. A égua, de material translúcido, possui crina
luminosa e base espelhada.
A iluminação alterna branco e azul, simulando a passagem da lua, enquanto som ambiente
reproduz vento suave e galope ritmado.
⸻
Localização  específica: Alto Minho (Arcos de Valdevez, Melgaço, Ponte da Barca, Monção) e
Trás-os-Montes (Vinhais, Mirandela).
Primeiro relato documentado: Teófilo Braga, O Povo Português  nos seus Costumes, Crenças e
Tradições, 1883.
Sistematização  contemporânea:  Eduardo Mauer, A Velha da Égua  Branca: Feminino, Luz e
Movimento no Imaginário  do Norte de Portugal, Associação MILK, 2024.
Fontes primárias:  Braga (1883); Vasconcelos (1915); Parafita (2008); Correia (2020); Mauer
(2024).
