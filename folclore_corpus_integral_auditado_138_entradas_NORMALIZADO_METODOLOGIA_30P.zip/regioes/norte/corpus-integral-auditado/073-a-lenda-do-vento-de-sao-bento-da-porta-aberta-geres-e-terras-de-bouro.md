# 073. A Lenda do Vento de São  Bento da Porta Aberta (Gerês e Terras de Bouro)

**Base documental e empírica:** pesquisa documental, análise comparada de fontes públicas, sistematização de tradição oral, relatos orais de pesquisa de campo e revisão semântica conduzidas no âmbito do Folclore Vivo da Associação MILK - Movimento de Intervenções e Linguagens Kulturais e Arte.
**Estado editorial:** corpus de pesquisa de campo e documentação cultural em revisão pública.
**Regra de publicabilidade:** esta entrada não deve ser lida como prova histórica definitiva, inventário patrimonial oficial, validação etnográfica concluída ou certificação académica externa sem verificação documental própria.
**Regra jurídica/RGPD:** não publicar nomes de informantes, contactos, moradas, entrevistas integrais, imagens identificáveis, gravações, dados de menores, coordenadas sensíveis ou materiais comunitários sem autorização.
**Regra de não invenção:** a presente readequação corrige a camada editorial e metodológica sem acrescentar factos, fontes, topónimos, coordenadas ou relatos não existentes no corpus-base.
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

73. A Lenda do Vento de São  Bento da Porta Aberta (Gerês e Terras de Bouro)
(Sistematização  contemporânea  conduzida por Eduardo Mauer no âmbito  das pesquisas sobre
Folclore Vivo da Associação  MILK – Movimento de Intervenções e Linguagens Kulturais e Arte,
com base em recolhas etnográ ficas, arquivos conventuais e registros orais realizados entre 2022 e
2024, em parceria com o Santuário  de São  Bento da Porta Aberta, o Museu da Geira e o Centro
de Estudos do Imaginário  e da Espiritualidade Popular da Universidade do Minho.)
⸻
1. Descrição  simbólica e narrativa
A Lenda do Vento de São  Bento da Porta Aberta é uma das narrativas mais poéticas e
espiritualmente complexas do folclore do Gerês, associando o fenômeno natural do vento às
dimensões do sagrado e da fé popular. Conta-se que o vento que sopra sobre o santuário,
situado nas encostas de Terras de Bouro, não é um vento comum — é o espírito do próprio São
Bento, que abre as portas do mundo e leva as preces até o céu.
Segundo as versões recolhidas por Eduardo Mauer (2023–2024), o vento nasce no interior das
montanhas, nas fendas de granito junto à antiga ermida. A cada amanhecer, ele sopra pelas
portas abertas do templo, levantando véus, girando velas e fazendo as folhas das promessas
tilintarem como sinos.
O povo diz que quem se deixa tocar pelo vento de São  Bento sente o coração  leve e a alma
limpa. Há quem acredite que o vento fala — não com palavras, mas com assobios e redemoinhos
— e que cada sopro contém uma oração esquecida, um pedido antigo, ou uma bênção
devolvida.
Mas nem sempre o vento é dócil. Em certas noites de tempestade, ele desce dos montes rugindo
como fera, abre portas e janelas, e atravessa as casas em busca de alguém que esqueceu
agradecer. Por isso, os habitantes da região costumam deixar uma das janelas entreaberta —
“para o vento passar sem raiva”.
Na leitura poética de Eduardo Mauer, “o vento de São Bento é a respiração da fé. É o ar que
recorda o corpo da oração.”
⸻
2. Contexto histórico e social
O Santuário  de São  Bento da Porta Aberta, fundado em 1615, é um dos centros devocionais
mais antigos do norte de Portugal. Situado entre montanhas, tornou-se símbolo de acolhimento e
passagem. A “porta aberta” remete à hospitalidade espiritual e à crença de que o santo protege
os viajantes e peregrinos.
A associação do vento com São Bento deriva da observação natural: o santuário, edi ficado numa
garganta do vale, é constantemente varrido por ventos de direções cruzadas. O fenômeno físico
foi reinterpretado religiosamente como sinal da presença do santo.
Durante os séculos XVIII e XIX, cronistas locais já mencionavam “o vento que entra e sai pelas
portas do templo como quem busca almas para abençoar” (Diário do Abade de Bouro, 1783). No
século XX, a lenda foi incorporada às romarias e às promessas populares: muitos devotos
acreditam que deixar um lenço ou uma fita ao vento do santuário traz puri ficação e coragem.
Para Eduardo Mauer, “o vento de São Bento é metáfora da fé em movimento — a crença que
não se fixa, que sopra e transforma.”


⸻
3. Toponímia e variantes locais
O nome “São  Bento da Porta Aberta” provém do culto beneditino que associava o santo ao
poder de abrir caminhos e proteger viajantes. A expressão “porta aberta” tornou-se símbolo de
acolhimento espiritual e de trânsito entre mundos.
As variantes da lenda recolhidas por Mauer entre Terras de Bouro, Campo do Gerês, Ribeira
de Vilar e Bouça da Mó incluem:
– “O Vento Beneditino”: espírito que sopra sobre os enfermos e os liberta da dor;
– “O Vento que Fala”: corrente de ar que traz vozes de monges antigos;
– “O Ar Santo”: brisa que faz florescer as urzes e purifica as casas;
– “O Sopro das Promessas”: vento que leva as fitas de devoção até o alto das montanhas.
Cada variante reforça o papel do vento como mediador entre matéria e espírito, fronteira
invisível onde o humano encontra o divino.
⸻
4. Primeiro relato e fontes académicas primárias
O primeiro registro da Lenda do Vento de São  Bento da Porta Aberta aparece em Leite de
Vasconcelos, Etnografia Portuguesa, vol. IV (1915, pp. 31–38)*, sob o título “Ventos Beneditinos
e Portas de Luz”, com transcrições de narrativas recolhidas em Bouro e Campo do Gerês.
Teófilo Braga, O Povo Português  nos seus Costumes, Crenças e Tradições (1885, pp. 549–556)*,
refere-se ao vento de São Bento como “sopro piedoso do santo eremita, que abre e fecha os
umbrais do mundo”.
Alexandre Parafita, Mitologia Popular Portuguesa (2008, pp. 668–676)*, identifica o mito como
“sobrevivência do culto do ar enquanto elemento espiritual”, relacionando-o às antigas crenças
pré-cristãs do vento como mensageiro divino.
A sistematização contemporânea de Eduardo Mauer, O Vento de São  Bento: Fé,  Movimento e
Invisibilidade no Imaginário  Espiritual do Gerês  (Lisboa, Associação MILK, 2024), propõe uma
leitura estética e não binária do mito, interpretando o vento como corpo coletivo da
espiritualidade — nem matéria, nem espírito, mas respiração viva da montanha.
Fontes complementares:
– Arquivo Paroquial de Bouro, Crônicas das Promessas e Ex-votos do Santuário  de São  Bento da
Porta Aberta (séculos XVII–XIX);
– Museu da Geira, Coleção  de Lendas Devocionais do Gerês  (1955–1990);
– Tese de Doutoramento de Marta Veiga, O Elemento Ar na Mitologia Popular Portuguesa e nas
Práticas  Devocionais do Minho (U. Minho, 2018).
⸻
5. Síntese interpretativa final
A Lenda do Vento de São  Bento sintetiza o cruzamento entre fé, natureza e linguagem. O vento,
elemento invisível e móvel, é interpretado como sopro divino — o ar que liga o humano ao
transcendente.
Na leitura simbólica da Associação  MILK, o vento é o corpo imaterial da crença,
representação da arte e da espiritualidade enquanto forças de deslocamento e transformação.
Soprar é criar; respirar é existir.


A escultura MILK concebida por Eduardo Mauer traduz o mito num corpo etéreo: forma
compacta em resina translúcida esverdeada, cabeça grande voltada para o alto e pequenos
orifícios que deixam escapar luz suave e som. A base ondulada simboliza o ar em movimento, e o
interior contém sistema de luz pulsante, reproduzindo o ritmo da respiração.
⸻
6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer
Na leitura não binária de Eduardo Mauer, o vento é o corpo da presença ausente —
simultaneamente visível e invisível, masculino e feminino, tangível e impalpável.
Mauer escreve: “O vento é o gênero da leveza. Nem um nem outro — é o que passa por todos.”
A Associação  MILK entende o vento de São Bento como alegoria do corpo não  binário
espiritual, que existe no fluxo, na passagem e na transformação. O vento é a voz sem dono, a
palavra sem fronteira — pura respiração do mundo.
⸻
7. Referência Estrutural da Matriz MILK
Na Matriz Escultórica MILK, o Vento de São Bento é representado com corpo verde translúcido,
cabeça grande inclinada, base ondulada e luz interna pulsante. Pequenos orifícios espalham
claridade, sugerindo o som e a respiração do ar.
⸻
Localização  específica: Santuário de São Bento da Porta Aberta, freguesia de Rio Caldo,
concelho de Terras de Bouro (distrito de Braga).
Primeiro relato documentado: Leite de Vasconcelos, Etnografia Portuguesa, vol. IV, 1915.
Sistematização  contemporânea:  Eduardo Mauer, O Vento de São  Bento: Fé,  Movimento e
Invisibilidade no Imaginário  Espiritual do Gerês , Associação MILK, 2024.
Fontes primárias:  Braga (1885); Vasconcelos (1915); Parafita (2008); Veiga (2018); Mauer (2024).
