# 006. A Pieira dos Lobos (Trás-os-Montes e Alto Minho)

**Base documental e empírica:** pesquisa documental, análise comparada de fontes públicas, sistematização de tradição oral, relatos orais de pesquisa de campo e revisão semântica conduzidas no âmbito do Folclore Vivo da Associação MILK - Movimento de Intervenções e Linguagens Kulturais e Arte.
**Estado editorial:** corpus de pesquisa de campo e documentação cultural em revisão pública.
**Regra de publicabilidade:** esta entrada não deve ser lida como prova histórica definitiva, inventário patrimonial oficial, validação etnográfica concluída ou certificação académica externa sem verificação documental própria.
**Regra jurídica/RGPD:** não publicar nomes de informantes, contactos, moradas, entrevistas integrais, imagens identificáveis, gravações, dados de menores, coordenadas sensíveis ou materiais comunitários sem autorização.
**Regra de não invenção:** a presente readequação corrige a camada editorial e metodológica sem acrescentar factos, fontes, topónimos, coordenadas ou relatos não existentes no corpus-base.
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

6. A Pieira dos Lobos (Trás-os-Montes e Alto Minho)
(Sistematização  contemporânea  conduzida por Eduardo Mauer e Nuno Araújo no âmbito  das
pesquisas sobre Folclore Vivo da Associação  MILK – Movimento de Intervenções e Linguagens
Kulturais e Arte)
⸻
1. Descrição  simbólica e narrativa
A Pieira dos Lobos é uma das entidades mais enigmáticas e belas do imaginário serrano
português. A sua designação provém do verbo “piar” — um som que não é nem voz nem grito,
mas eco, sopro, lamento. A Pieira é descrita como mulher-sombra de cabelos longos, olhos
brilhantes e corpo envolto num véu translúcido, que se move pelas serras ao cair da noite,
acompanhada por uma alcateia invisível de lobos. O seu canto, simultaneamente doce e
lancinante, serve de guia ou de aviso aos viajantes.
Nas aldeias de Montalegre, Vinhais e Arcos de Valdevez, o povo diz que, quando o vento sopra
das montanhas e os cães se calam, ouve-se a pieira — um assobio agudo seguido do uivo
distante dos lobos. É sinal de que a “Senhora das Serras” passa. As crianças são ensinadas a
não responder ao chamamento: quem imita o som da Pieira corre o risco de ser levado para o
mato, onde os lobos lhe arrancarão a sombra.
Noutras versões, recolhidas por Eduardo Mauer e Nuno Araújo no âmbito do Folclore Vivo, a
Pieira não é predadora, mas guardadora da ordem natural. Ela assegura o equilíbrio entre
humanos e animais, punindo caçadores que matam por prazer e guiando os lobos famintos para
longe das aldeias. É, assim, uma divindade pastoral mascarada de lenda, reminiscência de
antigos cultos animistas da Ibéria.
O seu rosto nunca é visto por inteiro — diz-se que muda conforme quem a observa: pode parecer
rapariga, velha, fera ou fumo. O timbre da sua voz é descrito como mistura de vento e flauta.
Mauer observa que este som intermédio — nem humano nem animal — é o verdadeiro núcleo
simbólico da Pieira: ela habita o limiar, a fronteira entre fala e natureza, entre consciência e
instinto.
Nas versões mais poéticas, a Pieira é a primeira mulher-lobo, mãe dos ventos e dos ecos,
condenada a guiar a alcateia pela eternidade. Noutras, é alma penada de pastora que morreu a
defender os lobos de uma caçada. A multiplicidade de narrativas confirma a antiguidade do mito
e a sua função como espelho da relação ancestral do Norte com o mundo selvagem.
⸻
2. Contexto histórico e social
O mito insere-se num contexto de pastoralismo montanhês. Desde a Idade Média, os lobos
eram simultaneamente temidos e respeitados nas serras de Trás-os-Montes e Minho. Eram
concorrentes dos pastores, mas também guardiões simbólicos das fronteiras e do equilíbrio
ecológico. A figura da Pieira nasce desse paradoxo: o povo necessitava de uma mediadora
espiritual capaz de traduzir o mistério dos lobos em linguagem humana.
Registos etnográ ficos antigos mostram que, até ao século XIX, era costume deixar oferendas de
pão e sal nas fragas, “para a Senhora dos Lobos não zangar o gado”. Em tempos de inverno
rigoroso, acreditava-se que a Pieira percorria as aldeias invisível, cobrindo-as com o seu manto
de neblina para proteger dos ataques.
Os lobos, por sua vez, foram alvo de perseguição sistemática. A sua extinção progressiva
coincidiu com o declínio das crenças que lhes davam sentido simbólico. O desaparecimento da
Pieira, como observa Mauer, acompanha a modernização rural: quando o bosque se cala,

também a mitologia se extingue. Contudo, a sua memória resiste nas histórias contadas à lareira,
sobretudo por mulheres idosas que a descrevem como “voz do vento que fala com o gado”.
A nível social, a Pieira representava o poder da palavra feminina nas comunidades patriarcais.
Era ela quem advertia, cuidava e amaldiçoava. Ao mesmo tempo, o seu estatuto de entidade
marginal — solitária e noturna — espelha a exclusão das vozes femininas dissidentes.
⸻
3. Toponímia e variantes locais
Há registos toponímicos de “Fraga da Pieira”, “Vale dos Lobos” e “Caminho da Senhora que Pia”
em Montalegre, Vinhais, Lindoso e Soajo. Em Bragança, existe a expressão “no tempo da
Pieira” para designar noites de vento forte.
Variedades regionais incluem a Peeira (Minho), a Peeira das Almas (Viana do Castelo) e a Peeira
dos Cães  (Trás-os-Montes). Em todas, mantém-se o vínculo entre a mulher e o lobo, símbolo de
alteridade e liberdade.
⸻
4. Primeiro relato e fontes académicas primárias
O primeiro registo escrito da Pieira dos Lobos data de 1873, no Arquivo Pittoresco, onde o
etnógrafo Francisco Mendes Leal descreve “as vozes das serras do Barroso, conhecidas como
peeiras, que os povos julgam ser mulheres-vento a guiar os lobos”.
Teófilo Braga, em O Povo Português  nos seus Costumes, Crenças e Tradições (1883, p. 364),
inclui a “Peeira dos Lobos de Vinhais” como “figura híbrida, metade mulher, metade sopro,
espírito pastoril dos ventos”.
Leite de Vasconcelos, Etnografia Portuguesa, vol. II (1913), analisa-a como reminiscência dos
“cultos helióforos e animistas célticos”, associando-a à deusa Artio, protetora dos ursos e lobos.
Alexandre Parafita, em Mitologia Popular Portuguesa (2008), descreve a Pieira como “divindade
da mediação, sacerdotisa do bosque e senhora dos sons”.
A investigação contemporânea de Eduardo Mauer e Nuno Araújo publicada em A Pieira dos
Lobos: Voz, Corpo e Limiar no Imaginário  do Norte (Lisboa, Associação MILK, 2024), propõe uma
leitura performativa: a Pieira é corpo sonoro que dissolve fronteiras entre humano e animal. Mauer
identifica-a como arquétipo da comunicação não verbal e do feminino transgressor.
Fontes adicionais:
– Museu de Etnografia de Barroso, Caderno das Almas da Serra (1898–1910);
– Tese de Mestrado de Lara Campos, A voz feminina na mitologia pastoril portuguesa (U. Minho,
2017).
⸻
5. Síntese interpretativa final
A Pieira dos Lobos simboliza a voz do limiar: aquilo que fala sem falar, o som que media entre
mundos. É o eco ancestral das mulheres e dos lobos, criaturas marginalizadas que partilham o
destino da solidão e da força. O seu canto, que não pertence nem à linguagem nem à música, é a
metáfora do próprio folclore — um murmúrio que persiste através dos séculos.
Para a Associação  MILK, o mito constitui um espaço de reaproximação entre humanidade e
natureza. A Pieira recorda que a cultura não é oposição à selvajaria, mas sua tradução.


Na escultura MILK delineada por Eduardo Mauer e Nuno Araújo, a Pieira surge como corpo
compacto e etéreo ao mesmo tempo: cabeça grande, expressão calma, véu esculpido em resina
translúcida. As cores predominantes — cinza-prateado, branco-leitoso e azul-noturno —
representam vento, névoa e luar.
⸻
6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer
A Pieira dos Lobos é paradigma do não  binário  natural: ser híbrido que encarna
simultaneamente a voz feminina e o rugido masculino, a delicadeza e a ferocidade. O seu corpo é
trans-específico; o seu género, mutável como o vento.
Na leitura de Eduardo Mauer e Nuno Araújo, a Pieira é o “corpo sonoro queer”, entidade que
transforma a vulnerabilidade em poder. O ato de piar, som liminar entre gemido e assobio,
expressa a recusa da fala normativa. A voz da Pieira é linguagem da diferença, música dos
corpos que não se enquadram.
O lobo, companheiro e espelho, simboliza o masculino selvagem; a Pieira, o feminino do ar.
Juntos, fundem-se num mesmo ser plural. Assim, o mito torna-se alegoria da coexistência: o
humano que escuta o outro dentro de si.
A Associação  MILK lê a Pieira como manifesto da sensibilidade não  binária , em que som,
corpo e vento constituem expressões fluidas do mesmo princípio vital. O canto da Pieira é o grito
libertador de todas as vozes silenciadas.
⸻
7. Referência Estrutural da Matriz MILK
Na Matriz Escultórica MILK, a Pieira é representada com corpo compacto e véu prolongado que
simula movimento de vento. Cabeça grande, olhar sereno, sorriso leve e braços erguidos
sugerindo gesto de condução. Cores em degradé cinzento-azulado com re flexos metálicos. O
acabamento em resina translúcida evoca o ar e a luz lunar.
Em instalação, recomenda-se som ambiente de assobio leve e uivos distantes, recriando a
atmosfera da serra.
⸻
Localização  específica: Montalegre, Vinhais, Arcos de Valdevez, Soajo.
Primeiro relato documentado: Francisco Mendes Leal, Arquivo Pittoresco, 1873.
Fontes primárias:  Mendes Leal (1873); Braga (1883); Vasconcelos (1913); Parafita (2008);
Campos (2017); Mauer (2024).
