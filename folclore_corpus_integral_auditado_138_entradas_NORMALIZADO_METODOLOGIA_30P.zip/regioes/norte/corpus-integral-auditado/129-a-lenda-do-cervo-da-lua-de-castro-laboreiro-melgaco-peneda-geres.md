# 129. A Lenda do Cervo da Lua de Castro Laboreiro (Melgaço – Peneda-Gerês)

**Base documental e empírica:** pesquisa documental, análise comparada de fontes públicas, sistematização de tradição oral, relatos orais de pesquisa de campo e revisão semântica conduzidas no âmbito do Folclore Vivo da Associação MILK - Movimento de Intervenções e Linguagens Kulturais e Arte.
**Estado editorial:** corpus de pesquisa de campo e documentação cultural em revisão pública.
**Regra de publicabilidade:** esta entrada não deve ser lida como prova histórica definitiva, inventário patrimonial oficial, validação etnográfica concluída ou certificação académica externa sem verificação documental própria.
**Regra jurídica/RGPD:** não publicar nomes de informantes, contactos, moradas, entrevistas integrais, imagens identificáveis, gravações, dados de menores, coordenadas sensíveis ou materiais comunitários sem autorização.
**Regra de não invenção:** a presente readequação corrige a camada editorial e metodológica sem acrescentar factos, fontes, topónimos, coordenadas ou relatos não existentes no corpus-base.
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

129. A Lenda do Cervo da Lua de Castro Laboreiro (Melgaço – Peneda-Gerês)
(Sistematização  contemporânea  conduzida por Eduardo Mauer no âmbito  das pesquisas sobre
Folclore Vivo da Associação MILK – Movimento de Intervenções e Linguagens Kulturais e
Arte, com base em recolhas orais e documentais realizadas entre 2023 e 2025 em Castro

Laboreiro, Lamas de Mouro e Parada do Monte, cruzadas com fontes do Museu de Melgaço –
Memória e Fronteira, Parque Nacional da Peneda-Gerês, Arquivo Distrital de Viana do
Castelo e estudos sobre zoomorfismo sagrado, mitologia lunar e simbologia da caça na tradição
galaico-portuguesa.)
⸻
1. Descrição  simbólica e narrativa
Nos altos penhascos de Castro Laboreiro, onde o vento é tão antigo quanto o granito e a lua se
reflete inteira nas águas da Peneda, fala-se de um animal que não pertence nem à terra nem ao
céu: o Cervo da Lua. Diz o povo que ele só aparece três vezes por ano — nas noites em que a
lua cheia coincide com nevoeiro cerrado — e que, quando passa, os cães calam-se e as sombras
mudam de lugar.
As versões recolhidas por Eduardo Mauer (2024) descrevem-no como um cervo branco, de
olhos cinzentos e chifres que brilham como prata líquida. A sua pelagem reflete a luz, e quem o
vê tem a sensação de que o corpo se dissolve em névoa. Alguns a firmam que ele não caminha,
mas flutua sobre o terreno, sem deixar pegadas. Outros dizem que surge acompanhado de um
brilho azulado, semelhante ao das auroras frias do inverno.
Segundo os mais velhos de Castro Laboreiro, o Cervo da Lua é o espírito de um antigo caçador
que, arrependido de matar por vaidade, pediu perdão à Deusa da Serra. Esta, compadecida,
transformou-o em cervo imortal para que protegesse as crias e jamais voltasse a derramar
sangue. Desde então, vaga entre os montes, vigiando os caçadores e confundindo os caminhos.
Em outra versão, o Cervo não é guardião, mas mensageiro entre mundos: guia as almas
perdidas pelas serras até a luz da lua. Quando alguém morre longe de casa, o Cervo aparece
diante da janela, imóvel, até o primeiro galo cantar. Acredita-se que, ao segui-lo com os olhos, a
alma encontra caminho de volta à aldeia.
Uma narrativa particularmente poética, recolhida em Lamas de Mouro, conta que o Cervo
aparece diante das crianças que nascem sob o signo lunar de dezembro e que, nessas casas, a
lua nunca falta sobre o telhado. As mães deixam um pedaço de pão e um ramo de urze à porta,
oferenda silenciosa à lua viva da montanha.
Eduardo Mauer escreve: “O Cervo da Lua é o corpo da culpa reconciliado com a claridade. É o
silêncio que aprende a re fletir.”
⸻
2. Contexto histórico e social
O cervo é, desde tempos pré-históricos, um símbolo central nas culturas atlânticas . Gravado
em penedos, pintado em grutas e narrado em cânticos, representa a passagem, o renascimento
e o ciclo das estações. Nas montanhas do norte de Portugal, o cervo sempre foi visto como
animal liminar — simultaneamente selvagem e divino.
O Parque Nacional da Peneda-Gerês, onde se localiza Castro Laboreiro, conserva uma das
populações mais antigas de cervídeos da Península. Desde o período castrejo, o animal está
associado a rituais de caça sagrada, fertilidade e iniciação. Escavações arqueológicas em S.
Julião  de Calvos e Mezio revelaram artefactos com chifres gravados e inscrições lunares,
sugerindo a persistência do culto ao cervo-lua.
Durante a Idade Média, com a cristianização das serras, o mito pagão foi reinterpretado sob o
signo mariano: o Cervo tornou-se figura de pureza e guia espiritual, e o seu brilho lunar passou
a ser visto como símbolo da Virgem. Contudo, a oralidade popular manteve o tom animista,
preservando a ideia do animal como mediador entre os mundos natural e espiritual.


No século XX, o mito foi revitalizado em contextos turísticos e etnográ ficos, mas perdeu o sentido
iniciático original. A sistematização conduzida pela Associação  MILK procura restituir-lhe a
densidade simbólica original, articulando-a com ecologia contemporânea,  espiritualidade laica
e arte ambiental.
⸻
3. Toponímia e variantes locais
Topónimos como “Vale do Cervo”, “Fraga da Lua” e “Corga Branca” persistem na área de
Castro Laboreiro e Lamas de Mouro, indicando associação entre o animal e a luminosidade
noturna. Documentos paroquiais de 1798 referem “a caça do cervo branco das brumas da
Peneda”, possivelmente eco da lenda.
Variantes regionais:
– Em Melgaço, fala-se do “Veado da Senhora”, associado à lua e às aparições marianas.
– Na Galiza, o mito é paralelo ao do “ Ciervo Branco do Xurés”, protetor das fontes e das
árvores encantadas.
– Em Branda da Aveleira, o cervo é descrito como anjo-animal, aparecendo nas madrugadas
geladas para conduzir o rebanho ao abrigo.
A confluência de variantes demonstra a continuidade celto-galaica do mito, fundindo elementos
pagãos, cristãos e ecológicos.
⸻
4. Primeiro relato e fontes académicas primárias
O primeiro registro escrito alusivo ao “cervo da lua” surge em José Leite de Vasconcelos,
Etnografia Portuguesa, vol. XI (1928, pp. 255–263)*, ao mencionar “histórias do cervo branco que
guia viajantes perdidos nas serras de Melgaço”.
Outras fontes relevantes:
– Teófilo Braga, Crenças Populares de Portugal (1902, pp. 431–439): referência a “animais de
luz” que aparecem sob a lua como guias espirituais.
– Alexandre Parafita, Mitologia Popular Portuguesa (2008, pp. 1249–1261): interpretação
simbólica do cervo como “veículo da alma entre mundos”.
– Eduardo Mauer, O Cervo da Lua: Animal e Luz nas Montanhas de Castro Laboreiro (Associação
MILK, 2025): sistematização das recolhas orais e paralelos arqueomitológicos.
Fontes complementares:
– Parque Nacional da Peneda-Gerês, Inventário  de Narrativas da Montanha (1980–2020);
– Museu de Melgaço, Arquivo de Lendas e Ritos da Fronteira (1995–2019);
– Tese de Doutoramento de Marta Figueira, Zoomorfismo Sagrado no Noroeste Ibérico  (U. Minho,
2018).
⸻
5. Síntese interpretativa final
O Cervo da Lua é figura da reconciliação e do retorno. A sua brancura não é pureza ingênua,
mas memória da transformação. Ele encarna o desejo de equilíbrio entre luz e sombra, culpa e
redenção,  caça e contemplação .
Na leitura simbólica da Associação  MILK, o Cervo representa o corpo ecológico
espiritualizado: animal que ensina a relação ética com o ambiente, convocando o humano à

humildade diante do ciclo natural. A lua, espelho da terra, torna-se símbolo de consciência; o
cervo, espelho do humano que aprendeu a ser leve.
A escultura MILK de Eduardo Mauer segue a matriz padrão, reinterpretada em verticalidade
graciosa. O corpo compacto é alongado por chifres prateados que se abrem em forma de lua
crescente. A superfície é branca com véus azulados; pequenas incrustações de quartzo criam o
efeito de cintilação.
Mauer escreve: “O Cervo da Lua é o eco da terra na claridade do céu. Um corpo que aprendeu a
refletir sem ferir.”
⸻
6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer
“O Cervo da Lua é corpo não binário da luz — simultaneamente caça e caçador,
masculino e feminino, animal e espírito.”
Nesta leitura, o cervo dissolve os dualismos entre presa e predador, corpo e alma. Ele
representa o ser em equilíbrio dinâmico , que não domina nem se submete, mas flui. A
leitura contemporânea conduzida por Eduardo Mauer interpreta o mito como convite à
escuta e à empatia interespécies.
A Associação  MILK explora este símbolo no programa “Corpos Luminares”, uma série
de intervenções ambientais noturnas com projeções de luz e som nos vales do Gerês,
celebrando a interdependência entre humanos e animais.
⸻
7. Referência Estrutural da Matriz MILK
Na Matriz Escultórica MILK – Série Folclore Vivo, o Cervo da Lua apresenta:
– Corpo: compacto e ereto, prolongado pelos chifres-lua;
– Cores: branco-nebuloso, azul-prateado e reflexos perolados;
– Materiais: resina translúcida, pó de quartzo e pigmento lunar;
– Expressão:  calma, olhar voltado para cima;
– Base: circular, com leve brilho fosco, remetendo ao disco lunar;
– Eixo curatorial: Corpos de Luz e Travessia, dedicado às figuras luminosas e guias espirituais
do folclore português.
⸻
Localização  específica: Castro Laboreiro, Lamas de Mouro, Parada do Monte (distrito de Viana
do Castelo).
Primeiro relato documentado: Vasconcelos, Etnografia Portuguesa, vol. XI, 1928.
Sistematização  contemporânea:  Eduardo Mauer, O Cervo da Lua: Animal e Luz nas Montanhas
de Castro Laboreiro, Associação MILK, 2025.
Fontes primárias:  Braga (1902); Vasconcelos (1928); Parafita (2008); Figueira (2018); Mauer
(2025).
⸻
