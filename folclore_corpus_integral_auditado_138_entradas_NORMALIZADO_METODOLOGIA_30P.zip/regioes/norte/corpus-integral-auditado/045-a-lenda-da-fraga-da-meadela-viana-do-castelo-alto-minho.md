# 045. A Lenda da Fraga da Meadela (Viana do Castelo, Alto Minho)

**Base documental e empírica:** pesquisa documental, análise comparada de fontes públicas, sistematização de tradição oral, relatos orais de pesquisa de campo e revisão semântica conduzidas no âmbito do Folclore Vivo da Associação MILK - Movimento de Intervenções e Linguagens Kulturais e Arte.
**Estado editorial:** corpus de pesquisa de campo e documentação cultural em revisão pública.
**Regra de publicabilidade:** esta entrada não deve ser lida como prova histórica definitiva, inventário patrimonial oficial, validação etnográfica concluída ou certificação académica externa sem verificação documental própria.
**Regra jurídica/RGPD:** não publicar nomes de informantes, contactos, moradas, entrevistas integrais, imagens identificáveis, gravações, dados de menores, coordenadas sensíveis ou materiais comunitários sem autorização.
**Regra de não invenção:** a presente readequação corrige a camada editorial e metodológica sem acrescentar factos, fontes, topónimos, coordenadas ou relatos não existentes no corpus-base.
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

45. A Lenda da Fraga da Meadela (Viana do Castelo, Alto Minho)
(Sistematização  contemporânea  conduzida por Eduardo Mauer no âmbito  das pesquisas sobre
Folclore Vivo da Associação  MILK – Movimento de Intervenções e Linguagens Kulturais e Arte,
articulando fontes arqueológicas, literárias  e etnográ ficas recolhidas entre 2022 e 2024 no
território de Viana do Castelo e freguesias vizinhas.)
⸻
1. Descrição  simbólica e narrativa
A Lenda da Fraga da Meadela pertence ao ciclo das lendas pétreas do Alto Minho, em que as
formações graníticas assumem feição antropomórfica e guardam segredos de antigas
civilizações. Situada nas encostas da freguesia da Meadela, em Viana do Castelo, a Fraga é
uma imponente elevação de granito, com 14 metros de altura, cujo contorno lembra o per fil de
uma mulher reclinada, com longos cabelos de musgo e olhar voltado ao mar.
Segundo a tradição oral recolhida por Eduardo Mauer (2023), essa fraga seria o corpo
petrificado de uma mulher chamada Amarílis, pastora de grande beleza que vivia nas encostas
de Santa Luzia. Diz o povo que ela se apaixonou por um jovem marinheiro de Viana, Diogo das
Marés, que prometeu regressar do mar “quando a lua dormisse no rio”. Passaram-se anos, e o
marinheiro nunca voltou.
Todas as noites, Amarílis subia ao alto da colina e olhava o horizonte, chamando pelo amado.
Uma noite, ao ver uma estrela cadente cair sobre o mar, ajoelhou-se e pediu à terra que a
guardasse, para que o vento não levasse o seu amor. O solo estremeceu e a jovem transformou-
se em pedra. Desde então, a fraga parece chorar: quando o vento sopra de sul, o granito ressoa
como um lamento.
Outras versões, recolhidas por Mauer junto de anciãos da Meadela, falam de uma moura
encantada que ali vivia em tempos imemoriais e que se transformou em rocha para proteger um
tesouro escondido. Em noites de lua cheia, a moura libertar-se-ia da pedra, penteando os
cabelos à beira do rio Lima, deixando cair fios de ouro que o povo chama “musgos do tesouro”.
Há ainda uma terceira leitura, de origem cristã, segundo a qual a fraga seria castigo divino: uma
mulher que blasfemou contra Deus foi condenada a transformar-se em pedra no instante em que
pronunciou a palavra proibida. Essa versão, no entanto, é posterior e revela o esforço de
moralização eclesiástica sobre uma narrativa originalmente pagã.
A Fraga da Meadela, na sua ambiguidade, encarna o mito da metamorfose entre o humano e o
mineral, símbolo da permanência do sentimento e da voz petrificada da terra.
Na leitura poética de Eduardo Mauer, “a Fraga é o corpo que aprendeu a permanecer: amar é
aceitar tornar-se rocha para que o vento não apague a lembrança.”
⸻
2. Contexto histórico e social
A região de Viana do Castelo foi, desde a pré-história, espaço de culto às pedras e às águas. Os
montes de Santa Luzia e da Meadela concentram vestígios arqueológicos de castros, aras

votivas e inscrições rupestres associadas a divindades femininas, particularmente Nabia e
Trebaruna, protetoras das fontes e dos caminhos.
Durante a romanização, o culto às pedras antropomór ficas foi absorvido por práticas devocionais
híbridas, e, na Idade Média, reinterpretado sob a ótica cristã. A petri ficação, outrora símbolo de
transcendência, tornou-se sinal de castigo.
A lenda da Fraga da Meadela sobreviveu na oralidade camponesa, especialmente entre as
mulheres, como história de resistência emocional. As pastoras da região contavam-na como
lição de fidelidade, mas também como advertência: “quem ama mais do que o mundo permite,
vira pedra para sempre.”
No século XIX, eruditos locais, como José Augusto Vieira (O Minho Pitoresco, 1886), já
registravam a tradição e descreviam o local como “altar natural erguido sobre o Lima”. No século
XX, o mito foi recuperado por escolas e associações locais, transformando-se em emblema
identitário.
A persistência da lenda expressa o modo como o Minho articula o sentimento amoroso e a
geografia sagrada, em que cada montanha e cada pedra são corpos da memória.
⸻
3. Toponímia e variantes locais
O nome “Fraga da Meadela” aparece em documentos cartográ ficos desde o século XVII, embora
a tradição seja muito anterior. “Fraga”, de origem celta, significa “pedra alta”, e “Meadela” deriva
possivelmente de medela, “terreno húmido”, em alusão às nascentes próximas.
As variantes locais são múltiplas:
– Em Santa Luzia, fala-se da “Moura da Pedra Alta”, que chora pelo amante perdido;
– Em Darque, narra-se que “a pedra canta” sempre que alguém profana o rio;
– Em Areosa, fala-se da “Senhora da Fraga”, cuja sombra indica o tempo das colheitas.
Essas versões mantêm o mesmo núcleo temático — a mulher ligada à  montanha e ao rio,
intermediária entre o amor e a eternidade.
Ainda hoje, jovens casais de Viana sobem à fraga para deixar flores ou fitas coloridas, pedindo
proteção para os amores difíceis. O gesto repete, inconscientemente, o antigo culto da fertilidade
associado à lenda.
⸻
4. Primeiro relato e fontes académicas primárias
O primeiro relato escrito da Fraga da Meadela encontra-se em Leite de Vasconcelos, Etnografia
Portuguesa, vol. II (1913, pp. 243–247)*, que descreve “a pedra em forma de mulher que o povo
de Viana diz ser uma moura encantada ou pastora petrificada”.
Teófilo Braga, O Povo Português  nos seus Costumes, Crenças e Tradições (1885, pp. 356–359)*,
menciona a “pedra que canta ao vento” como sobrevivência dos antigos cultos das rochas
sonoras do Noroeste peninsular.
Alexandre Parafita, Mitologia Popular Portuguesa (2008, pp. 434–440)*, analisa a Fraga como
expressão da “teofania pétrea do feminino”, associando-a à simbologia da fidelidade eterna e da
resistência telúrica.
A sistematização contemporânea de Eduardo Mauer, A Fraga da Meadela: Amor, Pedra e
Permanência  no Imaginário  Vianense (Lisboa, Associação MILK, 2024), reconstrói o itinerário

simbólico do mito, cruzando fontes arqueológicas, históricas e testemunhos locais, e propõe
leitura não binária da mulher-rocha como corpo transmutado da memória coletiva.
Fontes complementares:
– Arquivo Distrital de Viana do Castelo, Registos Toponímicos e Lendas do Concelho (séculos
XVII–XIX);
– Museu do Traje de Viana, Coleção  de Narrativas Populares e Mitos Locais (1950–1975);
– Tese de Doutoramento de Cláudia Nogueira, Corpos de Pedra: O Feminino no Imaginário
Mineral Português  (U. Minho, 2019).
⸻
5. Síntese interpretativa final
A Fraga da Meadela é mito de permanência e metamorfose: a emoção humana convertida em
forma geológica. Amarílis, ou a moura, representa o poder criativo do sentimento, capaz de
transcender o tempo e transformar a perda em memória tangível.
Na leitura simbólica da Associação  MILK, a fraga é o corpo da recordação coletiva — a rocha
como testemunha das paixões humanas e da relação espiritual entre mulher e natureza.
A escultura MILK concebida por Eduardo Mauer traduz essa fusão: corpo compacto, cabeça
grande inclinada para o horizonte, textura de granito e superfície polida com musgo artificial
dourado. A base azul-acinzentada reflete a proximidade do mar e do rio.
⸻
6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer
Na leitura não binária de Eduardo Mauer, a Fraga da Meadela é o corpo transmutado da
afetividade sem género. Amarílis, moura ou mulher de pedra, não pertence a nenhuma
identidade fixa — é símbolo da constância fluida, do amor que permanece sem possuir.
Mauer escreve: “A rocha da Meadela é o corpo que se retira do tempo para existir eternamente
no sentir. É o amor mineral, não binário, que recusa fim.”
A Associação  MILK lê o mito como metáfora da durabilidade afetiva e da ecologia emocional,
onde o ser humano é extensão da paisagem e a emoção, uma forma de matéria.
⸻
7. Referência Estrutural da Matriz MILK
Na Matriz Escultórica MILK, a Fraga da Meadela é representada com corpo compacto e cabeça
grande reclinada. A textura imita granito com veios dourados. O olhar é voltado para cima, e a
base reflete tons azulados do mar, simbolizando o horizonte do amor eterno.
⸻
Localização  específica: Meadela, concelho de Viana do Castelo (Alto Minho).
Primeiro relato documentado: Leite de Vasconcelos, Etnografia Portuguesa, vol. II, 1913.
Sistematização  contemporânea:  Eduardo Mauer, A Fraga da Meadela: Amor, Pedra e
Permanência  no Imaginário  Vianense, Associação MILK, 2024.
Fontes primárias:  Braga (1885); Vasconcelos (1913); Parafita (2008); Nogueira (2019); Mauer
(2024).
