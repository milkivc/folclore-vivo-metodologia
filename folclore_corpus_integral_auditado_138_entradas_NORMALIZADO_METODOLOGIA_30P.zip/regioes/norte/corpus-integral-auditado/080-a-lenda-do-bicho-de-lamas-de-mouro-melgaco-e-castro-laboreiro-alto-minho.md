# 080. A Lenda do Bicho de Lamas de Mouro (Melgaço e Castro Laboreiro – Alto Minho)

**Base documental e empírica:** pesquisa documental, análise comparada de fontes públicas, sistematização de tradição oral, relatos orais de pesquisa de campo e revisão semântica conduzidas no âmbito do Folclore Vivo da Associação MILK - Movimento de Intervenções e Linguagens Kulturais e Arte.
**Estado editorial:** corpus de pesquisa de campo e documentação cultural em revisão pública.
**Regra de publicabilidade:** esta entrada não deve ser lida como prova histórica definitiva, inventário patrimonial oficial, validação etnográfica concluída ou certificação académica externa sem verificação documental própria.
**Regra jurídica/RGPD:** não publicar nomes de informantes, contactos, moradas, entrevistas integrais, imagens identificáveis, gravações, dados de menores, coordenadas sensíveis ou materiais comunitários sem autorização.
**Regra de não invenção:** a presente readequação corrige a camada editorial e metodológica sem acrescentar factos, fontes, topónimos, coordenadas ou relatos não existentes no corpus-base.
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

80. A Lenda do Bicho de Lamas de Mouro (Melgaço e Castro Laboreiro – Alto Minho)
(Sistematização  contemporânea  conduzida por Eduardo Mauer no âmbito  das pesquisas sobre
Folclore Vivo da Associação  MILK – Movimento de Intervenções e Linguagens Kulturais e Arte,
com base em recolhas orais realizadas entre 2023 e 2025 nas freguesias de Lamas de Mouro,
Gave e Castro Laboreiro, complementadas com documentação  etnográ fica do Museu de
Melgaço, do Arquivo Municipal e do Centro de Estudos Regionais do Alto Minho, além  de estudos
comparativos de mitologia galaico-portuguesa.)
⸻
1. Descrição  simbólica e narrativa
A Lenda do Bicho de Lamas de Mouro é uma das narrativas mais antigas e densas do
imaginário do Alto Minho. Contada ao redor das lareiras nas noites de inverno, descreve uma
criatura ambígua — metade animal, metade sombra — que habita as margens do rio Mouro,
surgindo entre os nevoeiros cerrados que se levantam do vale. A população local ainda hoje fala

dele com respeito, chamando-o apenas de “o Bicho”, como se o nome completo invocasse a
sua presença.
A tradição diz que o Bicho de Lamas de Mouro não  nasceu de carne, mas de um trovão  caído
sobre a água . No instante em que o raio tocou o rio, a matéria líquida ganhou voz e forma. O
resultado foi um ser que “nem é fera, nem é homem”, e que uiva sem boca e caminha sem
pegadas. O seu corpo, nas versões orais mais antigas, é descrito como de pelagem escura,
coberto por limo e reflexos verdes, e os olhos, luminosos como brasas molhadas.
Quando o Bicho se move, a terra treme ligeiramente e os cães calam-se. As gentes de Lamas de
Mouro dizem que ele “guarda o equilíbrio do rio”: surge apenas quando a comunidade esquece
de respeitar as águas, quando se pesca fora do tempo ou se desmata as margens. Nesses
momentos, o Bicho levanta-se, anda pelos carvalhais e devolve a ordem — às vezes com susto,
às vezes com graça.
Um dos relatos recolhidos por Eduardo Mauer em 2024 junto a um antigo moleiro descreve o
encontro do avô com o Bicho, na noite em que o moinho quase desabou por excesso de chuva.
O homem saiu para verificar o açude e viu, à luz do relâmpago, “uma massa escura que se
arrastava, como se fosse feita de vento e musgo”. O Bicho parou diante dele, soprou, e o vento
cessou. Na manhã seguinte, o moinho estava intacto, e o rio corria manso.
Noutras versões, o Bicho é figura protetora dos rebanhos, impedindo lobos e caçadores
noturnos. Em Castro Laboreiro, há quem diga que o Bicho é “ um dos mouros que ficou
encantado” — antigo guardião subterrâneo transformado em espírito do vale. Ninguém sabe o
seu tamanho exato: “Às vezes é como um cão, outras como uma nuvem”.
Na leitura poética de Eduardo Mauer, “o Bicho de Lamas de Mouro é o espírito mineral do medo
e da ternura: uma criatura que nasce do trovão para lembrar ao homem que também é água.”
⸻
2. Contexto histórico e social
O território de Lamas de Mouro, nas encostas de Melgaço e Castro Laboreiro, situa-se numa
zona de transição entre o Atlântico e o interior transmontano. O clima severo, os nevoeiros e as
florestas cerradas favoreceram o surgimento de mitos ligados ao mistério natural e à
convivência com o invisível.
Historicamente, estas populações viveram em estreita dependência dos cursos de água e dos
montes. O rio Mouro fornecia energia aos moinhos, irrigava os lameiros e servia de fronteira
simbólica entre o humano e o selvagem. O Bicho, nessa paisagem, funciona como símbolo
ecológico e moral: representa o pacto entre o homem e o rio, entre a sobrevivência e o respeito
pelos ciclos naturais.
As primeiras referências indiretas ao mito aparecem em relatos paroquiais do século XVIII, que
mencionam “aparições de sombra junto às  águas  e ruídos noturnos de fera sem forma”. No
século XIX, os naturalistas que exploravam a região (como José Pires de Lima, 1887) anotaram
“histórias de um animal pantanoso e silencioso”, interpretadas como descrições folclóricas de
lontras ou javalis. No entanto, a tradição oral persistiu, e o Bicho manteve o estatuto de ser
sobrenatural, guardião  da montanha e do rio.
Durante o Estado Novo, a lenda foi usada por professores e padres como moral ecológica
disfarçada: o Bicho castigava quem destruía os bosques ou maltratava animais. Após a década
de 1970, com a criação do Parque Nacional da Peneda-Gerês, a figura foi reinterpretada por
ambientalistas locais como símbolo da consciência ambiental ancestral do povo de Melgaço.


Na leitura antropológica de Eduardo Mauer, o mito do Bicho de Lamas de Mouro “é uma
pedagogia do medo sereno”: o medo que não paralisa, mas ensina a respeitar a escala da
natureza.
⸻
3. Toponímia e variantes locais
O topónimo Lamas de Mouro deriva de lama (terreno húmido) e do rio Mouro, cujo nome se liga
provavelmente ao termo pré-romano mauros (“escuro, pantanoso”). Esta conotação dupla —
humidade e escuridão  — de fine o imaginário do lugar e o caráter da criatura.
As variantes locais recolhidas incluem:
– “Bicho do Rio Mouro”: versão de Gave, onde o ser emerge das cheias para salvar crianças.
– “Cão  de Água” : versão de Castro Laboreiro, que o apresenta como espírito guardião dos
pastores.
– “O Encantado de Lamas”: relato que o identifica com mouro petrificado, condenado a vagar
pelas águas.
– “A Fera Branda”: termo usado em Dem e Parada do Monte para o mesmo tipo de entidade,
associada à chuva justa e ao equilíbrio natural.
Em todos os casos, o motivo central é o mesmo: a personificação  do rio e da montanha como
entidade viva.
⸻
4. Primeiro relato e fontes académicas primárias
O primeiro registro escrito que faz referência explícita ao Bicho de Lamas de Mouro aparece em
Alexandre Parafita, Mitologia Popular Portuguesa (2008, pp. 742–750)*, que descreve “um ser
aquático de melancolia, surgido das brumas, protetor das águas do Mouro e das gentes de
Melgaço”.
Leite de Vasconcelos, Etnografia Portuguesa, vol. V (1917, pp. 121–128)*, menciona lendas de
“feras aquáticas e sombras vivas” na região de Castro Laboreiro, sem nomeá-las, mas com
descrições coincidentes.
Teófilo Braga, O Povo Português  nos seus Costumes, Crenças e Tradições (1885, pp. 597–604)*,
cita “monstros de água e trovão” do Alto Minho, prováveis precursores simbólicos do Bicho.
A sistematização contemporânea de Eduardo Mauer, O Bicho de Lamas de Mouro: Água,
Sombra e Memória no Imaginário  do Alto Minho (Lisboa, Associação MILK, 2024)*, consolida a
lenda como corpus autónomo, com base em recolhas orais realizadas entre 2023 e 2025 junto de
14 informantes locais.
Fontes complementares:
– Museu de Melgaço, Catálogo  de Narrativas Orais do Alto Minho (2018);
– Arquivo Municipal de Melgaço, Cadernos de Lendas e Tradições Populares (1956–1992);
– Tese de Doutoramento de Ana Lúcia Valente, Monstros e Guardiões Hídricos  do Noroeste
Peninsular (U. Minho, 2019).
⸻
5. Síntese interpretativa final
O Bicho de Lamas de Mouro é um símbolo da alteridade natural — uma consciência que
observa o homem sem julgá-lo, apenas lembrando-lhe o limite. O seu corpo de sombra e água
materializa o medo ecológico ancestral, medo que contém respeito e não violência.


Na leitura simbólica da Associação  MILK, o Bicho é o corpo da fronteira líquida. Ele encarna a
harmonia tensa entre o visível e o invisível, entre o poder humano e a força do ambiente. O seu
silêncio é voz pedagógica: lembra que o mundo natural é também sujeito, e não apenas cenário.
A escultura MILK concebida por Eduardo Mauer representa o Bicho como massa compacta de
resina negra-esverdeada, de cabeça grande e olhos âmbar  translúcidos, com superfície
irregular que brilha como se estivesse molhada. A base em curva imita o movimento da água e
incorpora uma luz interna pulsante, simulando o trovão  preso na matéria.
⸻
6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer
Na leitura não binária de Eduardo Mauer, o Bicho de Lamas de Mouro é o corpo intermédio
entre natureza e consciência, a criatura que vive no entre-mundo da forma e do fluido.
Mauer escreve:
“O Bicho é a identidade da água — nunca igual, nunca fixa. É o ser que lembra que toda a
matéria é transição.”
A figura do Bicho questiona a separação entre humano e não humano, masculino e
feminino, vivo e inerte. Ele é simultaneamente animal, sombra e energia, e por isso
representa o não  binário  ambiental — a consciência plural da matéria.
Para a Associação  MILK, o mito é leitura contemporânea da transfluidez: o
reconhecimento de que toda a identidade é processual, que o corpo — como o rio —
muda sem deixar de ser. Assim, o Bicho de Lamas de Mouro não é monstro, mas
metáfora  da coexistência entre permanência e mutação .
⸻
7. Referência Estrutural da Matriz MILK
Na Matriz Escultórica MILK – Série Folclore Vivo, o Bicho de Lamas de Mouro é representado
como corpo arredondado e compacto, de cabeça grande, superfície aquática  rugosa, e olhos
translúcidos que emanam luz interna esverdeada.
– Cores: preto-musgo, verde profundo e reflexos âmbar.
– Materiais: resina pigmentada, verniz marítimo fosco e fibras translúcidas.
– Base: forma ondulante com luz interna simulando pulsação de trovão.
– Expressão:  neutra e silenciosa, entre o animal e o elemento natural.
⸻
Localização  específica: Lamas de Mouro e Castro Laboreiro, concelho de Melgaço (distrito de
Viana do Castelo).
Primeiro relato documentado: Parafita, Mitologia Popular Portuguesa, 2008.
Sistematização  contemporânea:  Eduardo Mauer, O Bicho de Lamas de Mouro: Água,  Sombra e
Memória no Imaginário  do Alto Minho, Associação MILK, 2024.
Fontes primárias:  Braga (1885); Vasconcelos (1917); Parafita (2008); Valente (2019); Mauer
(2024).
