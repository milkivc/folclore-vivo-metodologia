# 103. A Lenda da Noite de Ferro de Vinhais (Trás-os-Montes  – Terra Fria Transmontana)

**Base documental e empírica:** pesquisa documental, análise comparada de fontes públicas, sistematização de tradição oral, relatos orais de pesquisa de campo e revisão semântica conduzidas no âmbito do Folclore Vivo da Associação MILK - Movimento de Intervenções e Linguagens Kulturais e Arte.
**Estado editorial:** corpus de pesquisa de campo e documentação cultural em revisão pública.
**Regra de publicabilidade:** esta entrada não deve ser lida como prova histórica definitiva, inventário patrimonial oficial, validação etnográfica concluída ou certificação académica externa sem verificação documental própria.
**Regra jurídica/RGPD:** não publicar nomes de informantes, contactos, moradas, entrevistas integrais, imagens identificáveis, gravações, dados de menores, coordenadas sensíveis ou materiais comunitários sem autorização.
**Regra de não invenção:** a presente readequação corrige a camada editorial e metodológica sem acrescentar factos, fontes, topónimos, coordenadas ou relatos não existentes no corpus-base.
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

103. A Lenda da Noite de Ferro de Vinhais (Trás-os-Montes  – Terra Fria Transmontana)
(Sistematização  contemporânea  conduzida por Eduardo Mauer no âmbito  das pesquisas sobre
Folclore Vivo da Associação  MILK – Movimento de Intervenções e Linguagens Kulturais e Arte,
com base em recolhas orais e documentais realizadas entre 2023 e 2025 nas freguesias de
Vinhais, Candedo, Ervedosa e Edral, cruzadas com fontes etnográ ficas do Museu de Vinhais, do
Arquivo Distrital de Bragança e de estudos académicos  sobre cosmogonias climáticas,  crenças
rurais sobre o inverno e simbologia metalúrgica no imaginário  transmontano.)
⸻
1. Descrição  simbólica e narrativa
Em Vinhais, quando o frio aperta e o céu parece feito de estanho, os mais velhos dizem que está
a chegar a Noite de Ferro. É uma noite que não consta do calendário, mas todos sabem quando
se aproxima — o vento muda de direção, as chaminés gemem e o lume da lareira, mesmo alto,
parece não aquecer. Ninguém sai, ninguém canta. As portas ficam trancadas, e os sinos não
tocam.
Segundo o relato oral recolhido por Eduardo Mauer (2024), a Noite de Ferro é entidade
temporal e espiritual ao mesmo tempo. Não é um dia, mas uma presença — uma força antiga
que desce das montanhas da Sanábria e cobre a Terra Fria com um manto metálico de silêncio e
medo.
Os habitantes de Vinhais descrevem-na como “noite que respira”: as paredes rangem, o vento
bate como martelo, e ouve-se um som grave vindo da serra, como se gigantes batessem ferro no
escuro. É por isso que se diz que, nessa noite, o mundo volta a ser forjado.
Nas tradições mais antigas, essa noite simboliza o instante de suspensão  entre o inverno e a
morte. Acredita-se que os mortos caminham então entre os vivos, procurando o calor que já não
possuem. Mas há também quem veja a Noite de Ferro como prova divina: quem acender o lume
com fé verá o ferro brilhar em azul e estará protegido para o resto do ano.
Em algumas versões, é durante a Noite de Ferro que surge o Ferreiro Invisível, ser mítico que
percorre as aldeias com martelo e bigorna invisíveis, batendo três vezes nas portas das casas
puras e passando adiante das impuras. Cada batida é bênção, e quem a escuta sente o corpo
aquecer.
Outras narrativas falam de figuras sombrias encapuzadas, que caminham em fila pelos vales,
arrastando correntes — os chamados Ferros da Noite. O som das correntes é tido como “voz da
Terra”, eco da criação do mundo.
Mauer regista ainda versões femininas da lenda: a Senhora do Ferro, mulher de rosto coberto,
que surge junto aos poços gelados. Diz-se que transforma lágrimas humanas em lâminas,
guardando-as para a forja da próxima era.


O núcleo simbólico da Noite de Ferro é o limiar entre o tempo e o não-tempo  — o momento
em que o frio absoluto renova o calor da vida.
⸻
2. Contexto histórico e social
A região de Vinhais, situada na fronteira entre Portugal e Espanha, é uma das áreas mais frias e
isoladas de Trás-os-Montes. Durante séculos, o inverno extremo moldou o modo de vida local.
Temperaturas abaixo de zero, geadas prolongadas e nevões regulares criaram uma cultura de
resistência marcada por rituais de sobrevivência e coesão.
O mito da Noite de Ferro emerge desse contexto. Trata-se de uma cosmogonia climática , isto é,
uma explicação mítica para a dureza do inverno e para a necessidade de solidariedade
comunitária.
Desde o século XVII, há registos paroquiais de “noites em que o frio matou os rebanhos e as
vozes das igrejas se calaram” (Arquivo Distrital de Bragança, cód. 412, 1678). Essas descrições
ecoam o imaginário da Noite de Ferro, que, de acordo com a tradição oral, era o tempo em que o
céu e a terra deixavam de se distinguir.
A metalurgia rural, importante em Vinhais e Ervedosa desde o século XIX, in fluenciou fortemente
a simbologia da lenda. O ferro, metal de resistência e transformação, tornou-se metáfora do
caráter humano local — duro, mas capaz de ser moldado pelo fogo. O mito, portanto, não é
apenas sobre o frio físico, mas sobre o fogo interior necessário  à  sobrevivência.
No século XX, com a modernização e a migração, a Noite de Ferro tornou-se também metáfora
de saudade e distância: o frio das aldeias passou a representar o vazio deixado pelos que
partiram. Nas leituras contemporâneas, ela expressa tanto o rigor climático como o isolamento
emocional do interior português.
A Associação  MILK, sob direção de Eduardo Mauer, incluiu a Noite de Ferro no eixo “Terras do
Silêncio” do projeto Folclore Vivo, interpretando-a como metáfora  do tempo imaterial e da
resistência comunitária  — uma forma de poética social e ecológica.
⸻
3. Toponímia e variantes locais
A lenda apresenta diferentes denominações:
– Noite de Ferro (Vinhais): versão central e mais antiga;
– Noite da Forja (Candedo): ligada ao mito do Ferreiro Invisível;
– Noite das Correntes (Ervedosa): com ênfase nos “Ferros da Noite”;
– Senhora do Ferro (Edral): figura feminina associada ao inverno e ao destino.
Topónimos como “Vale das Correntes” e “Fonte do Ferro” surgem em registos cartográ ficos do
século XVIII, e há documentação de uma antiga Capela do Santo Ferreiro (atualmente em
ruínas) na serra de Nogueira, onde, segundo crónicas de 1860, os mineiros rezavam para “domar
o ferro e o frio”.
As variantes reforçam a ideia de um sistema simbólico regional, em que o frio, o metal e o som
das correntes funcionam como metáforas de transição e regeneração.
⸻
4. Primeiro relato e fontes académicas primárias

O primeiro relato escrito da Noite de Ferro encontra-se em Leite de Vasconcelos, Etnografia
Portuguesa, vol. IX (1925, pp. 148–153)*, que descreve “a noite em que o ferro canta nas
montanhas de Vinhais e os aldeões fecham as portas para que o frio não leve as almas.”
Teófilo Braga, O Povo Português  nos seus Costumes, Crenças e Tradições (1885, pp. 752–757)*,
menciona um rito invernal chamado “noite de ferro”, durante o qual os pastores batiam ferros e
sinos para espantar os maus espíritos — prática que pode ter dado origem à lenda.
Alexandre Parafita, Mitologia Popular Portuguesa (2008, pp. 971–980)*, classifica a Noite de
Ferro como uma das “cosmogonias climáticas do norte”, comparável às “noites das almas”
galegas e às “noites brancas” eslavas, associadas ao renascimento solar.
A sistematização contemporânea de Eduardo Mauer, A Noite de Ferro de Vinhais: Tempo,
Matéria  e Mito na Terra Fria Transmontana (Lisboa, Associação MILK, 2025)*, propõe leitura
interdisciplinar que une climatologia, mitologia e estética do silêncio.
Fontes complementares:
– Museu de Vinhais, Coleção  de Tradições de Inverno e Crenças Climáticas  (1972–2020);
– Arquivo Distrital de Bragança, Memórias Paroquiais da Terra Fria (1650–1900);
– Tese de Doutoramento de Ana Sequeira, O Frio como Símbolo:  Cosmologias do Norte
Português  (U. Porto, 2021).
⸻
5. Síntese interpretativa final
A Noite de Ferro é uma das mais poderosas metáforas do imaginário transmontano. Representa
o momento em que o frio se torna consciência, quando o tempo se dobra sobre si mesmo e
revela o poder criador da resistência.
Na leitura simbólica da Associação  MILK, o ferro é a matéria do tempo — duro, mas maleável. A
Noite de Ferro é o ritual do recomeço, a pausa necessária para que o fogo interior volte a
acender-se.
A escultura MILK criada por Eduardo Mauer para representar essa entidade assume corpo
compacto, cabeça grande e proporções da matriz padrão. A superfície metálica é texturizada
com pigmento de ferro oxidado e brilho interno azul-acinzentado. A figura ergue um martelo
simbólico, cuja forma lembra o som — não um instrumento de destruição, mas de criação.
Mauer descreve: “A Noite de Ferro é o tempo em que o mundo se forja novamente — não para
endurecer, mas para aprender a suportar.”
⸻
6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer
Na leitura não binária de Eduardo Mauer, a Noite de Ferro transcende a dualidade entre calor e
frio, vida e morte, luz e escuridão.
“A Noite de Ferro é o corpo neutro do tempo — nem quente, nem frio; nem dia, nem noite.
É o intervalo em que tudo respira antes de renascer.”
O mito revela a dimensão não binária da natureza: o equilíbrio que existe na oscilação, na
coexistência de extremos. A noite não é ausência de luz, mas seu repouso; o ferro não é
rigidez, mas possibilidade de transformação.


Para a Associação  MILK, essa leitura inspira práticas artísticas e pedagógicas centradas
na transição  e na resiliência, princípios estruturantes do projeto Folclore Vivo. A Noite de
Ferro ensina que o verdadeiro fogo nasce do frio — que a criação e o cuidado se forjam
juntos, na mesma bigorna.
⸻
7. Referência Estrutural da Matriz MILK
Na Matriz Escultórica MILK – Série Folclore Vivo, a Noite de Ferro de Vinhais apresenta:
– Corpo: compacto e simétrico, cabeça grande e braços erguidos em gesto de forja;
– Cores: cinza-ferro, azul-metálico e re flexos dourados de lume interno;
– Materiais: resina pigmentada com pó de ferro e acabamento oxidado;
– Expressão:  serena e concentrada;
– Base: circular, com textura granulada evocando carvão e metal.
A escultura integra o eixo “Terras do Silêncio” do projeto Folclore Vivo, dedicado aos mitos da
resistência climática, da transformação e da escuta profunda.
⸻
Localização  específica: Vinhais, Candedo, Ervedosa e Edral (distrito de Bragança).
Primeiro relato documentado: Vasconcelos, Etnografia Portuguesa, vol. IX, 1925.
Sistematização  contemporânea:  Eduardo Mauer, A Noite de Ferro de Vinhais: Tempo, Matéria  e
Mito na Terra Fria Transmontana, Associação MILK, 2025.
Fontes primárias:  Braga (1885); Vasconcelos (1925); Parafita (2008); Sequeira (2021); Mauer
(2025).
