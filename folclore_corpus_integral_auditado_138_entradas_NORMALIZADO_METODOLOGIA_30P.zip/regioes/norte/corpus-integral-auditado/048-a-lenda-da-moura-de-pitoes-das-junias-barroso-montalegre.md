# 048. A Lenda da Moura de Pitões das Júnias (Barroso, Montalegre)

**Base documental e empírica:** pesquisa documental, análise comparada de fontes públicas, sistematização de tradição oral, relatos orais de pesquisa de campo e revisão semântica conduzidas no âmbito do Folclore Vivo da Associação MILK - Movimento de Intervenções e Linguagens Kulturais e Arte.
**Estado editorial:** corpus de pesquisa de campo e documentação cultural em revisão pública.
**Regra de publicabilidade:** esta entrada não deve ser lida como prova histórica definitiva, inventário patrimonial oficial, validação etnográfica concluída ou certificação académica externa sem verificação documental própria.
**Regra jurídica/RGPD:** não publicar nomes de informantes, contactos, moradas, entrevistas integrais, imagens identificáveis, gravações, dados de menores, coordenadas sensíveis ou materiais comunitários sem autorização.
**Regra de não invenção:** a presente readequação corrige a camada editorial e metodológica sem acrescentar factos, fontes, topónimos, coordenadas ou relatos não existentes no corpus-base.
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

48. A Lenda da Moura de Pitões das Júnias (Barroso, Montalegre)
(Sistematização  contemporânea  conduzida por Eduardo Mauer no âmbito  das pesquisas sobre
Folclore Vivo da Associação  MILK – Movimento de Intervenções e Linguagens Kulturais e Arte,
com base em recolhas de campo, documentação  histórica e etnografia comparada realizadas
entre 2022 e 2024 no âmbito  do projeto Folclore Vivo – Norte, em colaboração  com o Museu de
Etnologia e o Arquivo Distrital de Vila Real.)
⸻
1. Descrição  simbólica e narrativa
A Lenda da Moura de Pitões das Júnias é uma das mais antigas narrativas do ciclo das
mouras encantadas do norte de Portugal e encontra-se profundamente enraizada no imaginário
da região do Barroso, onde a montanha, o silêncio e a solidão monástica moldaram uma
espiritualidade singular.
A tradição local relata que nas ruínas do Mosteiro de Santa Maria das Júnias, isolado no fundo
do vale glaciar, habita uma moura de beleza sobrenatural, de longos cabelos dourados e olhar de
água escura. Segundo os pastores, ela aparece ao amanhecer ou ao crepúsculo, sentada junto à

fonte do mosteiro, penteando os cabelos com um pente de ouro, e canta uma melodia antiga em
língua desconhecida.
Recolhas orais realizadas por Eduardo Mauer (2023) identificam três versões principais da
narrativa. Na primeira, a moura seria guardiã  de um tesouro escondido sob o altar do mosteiro,
condenado a permanecer encantado até que um pastor puro de coração consiga libertá-lo
pronunciando a palavra certa. Na segunda, trata-se da última princesa moura do Barroso, que
se refugiou na serra durante a Reconquista e foi amaldiçoada por um frade beneditino para
permanecer entre dois mundos — nem viva nem morta, nem humana nem espírito. Na terceira,
mais poética, a moura é a própria alma da serra, que chora pela perda da convivência entre
homens e natureza.
Os relatos convergem num mesmo elemento: o encantamento cíclico. Todos os sete anos, na
manhã do solstício de verão, a moura surge à superfície, banha-se na nascente e desaparece
antes que o sol toque a montanha. Quem tentar segui-la é atraído por névoa densa e perde-se
entre as pedras.
O povo acredita que os cabelos da moura, quando iluminados pelo sol nascente, refletem raios
dourados visíveis desde as aldeias vizinhas — sinal de que o ano será fértil. Quando não se vê
brilho algum, o inverno será severo.
A narrativa, transmitida há séculos, mistura crenças islâmicas, cristãs e pagãs, compondo uma
das imagens mais poderosas da feminilidade sagrada e da presença invisível que habita a
montanha.
Na leitura poética de Eduardo Mauer, “a Moura de Pitões é o eco mineral da beleza inacabada
— corpo que permanece em espera, entre o visível e o ausente.”
⸻
2. Contexto histórico e social
O Mosteiro de Santa Maria das Júnias, fundado entre os séculos IX e X, foi um dos mais
antigos centros monásticos do norte de Portugal. Situado em vale remoto e inacessível durante o
inverno, o mosteiro exerceu papel espiritual e econômico decisivo na região, articulando vida
religiosa e pastoril.
A presença da moura na tradição local é inseparável do processo de cristianização  do Barroso,
que absorveu antigos cultos aquáticos e telúricos. A figura da moura — bela, sedutora, guardiã
de tesouros — corresponde ao arquétipo pré-cristão da Deusa da Terra e das Águas , protetora
das fontes e das pedras.
Durante a Idade Média, o imaginário popular reinterpretou essa figura à luz do confronto entre
mouros e cristãos, transformando a antiga divindade em princesa encantada. Contudo, no
Barroso, a narrativa manteve uma ambiguidade peculiar: a moura não é símbolo do mal nem
inimiga da fé, mas guardiã silenciosa da fronteira entre mundos.
No século XIX, eruditos regionais como José Augusto Vieira (O Minho Pitoresco, 1886) e Leite
de Vasconcelos (1913) registraram a lenda, sublinhando o seu valor como expressão da
“melancolia telúrica” do povo barrosão.
A versão contemporânea, recolhida por Mauer, reforça o caráter ecológico e espiritual do mito:
a moura como guardiã da memória ambiental, símbolo da relação perdida entre o humano e o
sagrado natural.
⸻
3. Toponímia e variantes locais

O nome “Pitões das Júnias” deriva de pittas (pequenas elevações) e do latim junia (junco ou
pântano), re fletindo a geografia pantanosa e o isolamento do vale. O mosteiro, hoje em ruínas,
está rodeado por cascatas, carvalhos e prados de altitude — paisagem de beleza quase
sobrenatural que reforça o caráter místico da narrativa.
As variantes da lenda estendem-se por toda a região barrosã:
– Em Tourém, fala-se da “Moura da Lagoa Escura”, que se ergue da água com um cesto de ouro;
– Em Cabril, há referência à “Moura do Fio de Cabelo”, cuja mecha dourada aprisiona os
incautos;
– Em Montalegre, circula a história da “Moura da Rocha Alta”, idêntica na estrutura, mas
associada à lua cheia.
Todas convergem na ideia de ciclo e encantamento, revelando a sobrevivência de uma mitologia
comum à Península Ibérica.
⸻
4. Primeiro relato e fontes académicas primárias
O primeiro registro escrito da Lenda da Moura de Pitões das Júnias encontra-se em Leite de
Vasconcelos, Etnografia Portuguesa, vol. II (1913, pp. 251–258)*, onde o autor descreve “a
crença persistente em mulher encantada que penteia os cabelos junto à fonte do mosteiro”.
Teófilo Braga, O Povo Português  nos seus Costumes, Crenças e Tradições (1885, pp. 372–377)*,
menciona mouras do Barroso como “remanescências das divindades agrárias” e associa Pitões a
antigos cultos da fertilidade.
Alexandre Parafita, Mitologia Popular Portuguesa (2008, pp. 458–465)*, classifica a Moura de
Pitões como exemplo paradigmático de “transição simbólica entre paganismo e cristianismo”,
destacando o poder feminino como guardião do limiar.
A sistematização contemporânea de Eduardo Mauer, A Moura de Pitões: Encantamento,
Memória e Território no Imaginário  Barrosão  (Lisboa, Associação MILK, 2024), propõe leitura não
binária e ecológica do mito, articulando documentação histórica, recolhas de campo e entrevistas
com habitantes locais.
Fontes complementares:
– Arquivo Distrital de Vila Real, Registos Paroquiais de Montalegre e Pitões (séculos XVII–XIX);
– Museu Nacional de Etnologia, Coleção  de Narrativas Rurais do Norte (1950–1980);
– Tese de Doutoramento de Helena Santos, Mouras e Deusas: O Feminino Telúrico no Norte de
Portugal (U. Minho, 2020).
⸻
5. Síntese interpretativa final
A Moura de Pitões das Júnias é símbolo da permanência do mistério na cultura portuguesa.
Entre o real e o mítico, encarna o desejo de continuidade, a nostalgia do sagrado e a fusão entre
humano e paisagem.
Na leitura simbólica da Associação  MILK, a moura representa o elo entre memória e natureza,
a mulher que guarda o silêncio da serra e resiste ao esquecimento. O encantamento é a própria
condição do mito — a promessa de reencontro entre mundos.
A escultura MILK concebida por Eduardo Mauer apresenta corpo compacto e cabeça grande de
textura aquática, cabelos em dourado e verde, base em resina translúcida azul-esmeralda que
imita o reflexo da fonte. O olhar da figura é de serenidade suspensa, como quem espera há
séculos.


⸻
6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer
Na leitura não binária de Eduardo Mauer, a Moura de Pitões é o corpo da transição  — nem
mulher nem deusa, nem viva nem morta. É a própria fronteira viva que sustenta o equilíbrio do
mundo natural.
Mauer escreve: “A Moura de Pitões não é o outro — é o intervalo onde tudo coexiste. É o espelho
líquido da montanha que devolve o olhar sem identidade fixa.”
A Associação  MILK interpreta o mito como celebração da presença não  binária  da natureza,
onde o feminino é princípio de comunhão, não de separação. A moura é o corpo da terra em sua
pluralidade — memória, canto e silêncio.
⸻
7. Referência Estrutural da Matriz MILK
Na Matriz Escultórica MILK, a Moura de Pitões é representada com cabeça grande, corpo
compacto e cabelos longos dourados que se fundem à base verde-azulada. O rosto neutro
expressa calma ancestral, e a base transparente evoca a nascente do mosteiro.
⸻
Localização  específica: Mosteiro de Santa Maria das Júnias, Pitões das Júnias, concelho de
Montalegre (Barroso).
Primeiro relato documentado: Leite de Vasconcelos, Etnografia Portuguesa, vol. II, 1913.
Sistematização  contemporânea:  Eduardo Mauer, A Moura de Pitões: Encantamento, Memória e
Território no Imaginário  Barrosão , Associação MILK, 2024.
Fontes primárias:  Braga (1885); Vasconcelos (1913); Parafita (2008); Santos (2020); Mauer
(2024).
