# 114. A Lenda da Velha das Três Faces de Terras de Bouro (Gerês – Alto Minho)

**Base documental e empírica:** pesquisa documental, análise comparada de fontes públicas, sistematização de tradição oral, relatos orais de pesquisa de campo e revisão semântica conduzidas no âmbito do Folclore Vivo da Associação MILK - Movimento de Intervenções e Linguagens Kulturais e Arte.
**Estado editorial:** corpus de pesquisa de campo e documentação cultural em revisão pública.
**Regra de publicabilidade:** esta entrada não deve ser lida como prova histórica definitiva, inventário patrimonial oficial, validação etnográfica concluída ou certificação académica externa sem verificação documental própria.
**Regra jurídica/RGPD:** não publicar nomes de informantes, contactos, moradas, entrevistas integrais, imagens identificáveis, gravações, dados de menores, coordenadas sensíveis ou materiais comunitários sem autorização.
**Regra de não invenção:** a presente readequação corrige a camada editorial e metodológica sem acrescentar factos, fontes, topónimos, coordenadas ou relatos não existentes no corpus-base.
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

114. A Lenda da Velha das Três Faces de Terras de Bouro (Gerês – Alto Minho)
(Sistematização  contemporânea  conduzida por Eduardo Mauer no âmbito  das pesquisas sobre
Folclore Vivo da Associação  MILK – Movimento de Intervenções e Linguagens Kulturais e Arte,
com base em recolhas orais e documentais realizadas entre 2023 e 2025 em Campo do Gerês,
Covide, Vilarinho da Furna e Rio Caldo, cruzadas com fontes etnográ ficas locais e acervos
paroquiais.)
⸻


1. Descrição  simbólica e narrativa
No sopé da Serra Amarela, quando a manhã levanta o véu de neblina e o granito devolve um
brilho úmido, fala-se ainda da Velha das Três Faces: uma mulher encapuzada que aparece junto
a encruzilhadas, fragas e fontes frias, trazendo no rosto um enigma triplo. Diz o povo que a
primeira face é moça, a segunda mãe , e a terceira ancião  — e que a sua voz muda conforme a
face que se torna visível.
As versões recolhidas por Eduardo Mauer (2024) em Covide e Campo do Gerês descrevem
encontros ao amanhecer: um pastor que, ao contornar um penedo, viu uma velha fiando à porta
da brenha; pediu-lhe o caminho, e ela ergueu a cabeça com um rosto jovial que indicou a direção
do vale. O homem, surpreso, girou para agradecer e encontrou o mesmo corpo com outra face —
madura, maternal — avisando para não cruzar a ponte antes do meio-dia. Ao afastar-se, ouviu
um sussurro rouco de terceira voz: “Quando os caminhos se cruzam, também o tempo se cruza.”
Noutras narrativas, a Velha surge sobre fragas votivas onde os antigos deixavam oferendas:
numa mão carrega uma roca ou cajado; noutra, um pequeno cesto de folhas. A presença não
ameaça: interroga. Quem responde de modo soberbo perde a rota; quem escuta sai protegido.
As crianças eram ensinadas a cumprimentar os penedos “onde mora a Velha”, num gesto de
respeito à montanha.
Há versões em que a Velha é guardadora da água : nos meses de estiagem, aparece sentada
junto a minas e fontes, testando a paciência de quem chega. Se encontra pressa e impaciência, a
água “fecha-se”; se encontra humildade, “a fonte canta”.
Em todas as variantes, a figura condensa o tempo em três, unindo juventude, maturidade e
velhice num mesmo corpo — uma pedagogia do ciclo. Mauer sintetiza: “A Velha das Três Faces
é o relógio da serra, a consciência do lugar que pergunta ao viajante em que tempo ele escolhe
andar.”
⸻
2. Contexto histórico e social
Terras de Bouro preserva um mosaico de crenças pastorícias e agro-silvícolas onde as figuras
femininas ligadas à terra, à água e à passagem dos meses são recorrentes. A triplidade feminina
ecoa arquétipos pan-europeus (donzela–mãe–anciã) adaptados à realidade do Gerês: moça
(primavera), mãe (verão/colheita) e velha (outono-inverno/abrigo).
A romanização (via Geira Romana) trouxe cultos a deidades triplices e à deusa das águas ,
facilmente sincretizadas nas práticas locais; a cristianização rural manteve o substrato,
deslocando-o para devoções a santas e “senhoras” de cada estação ou fonte. O deslocamento
de aldeias (como Vilarinho da Furna, submersa) reforçou a figura como memória do que
permanece quando a paisagem muda: a Velha torna-se guardiã do pertencimento.
Socialmente, a lenda funcionou como código de conduta: prudência nas encruzilhadas,
respeito por fontes e ritmos, escuta dos mais velhos. Em termos rituais, a presença nas águas
frias e penedos reforça a sacralidade de locais liminares — entradas de vales, passagens de
altitude, mina-d’água onde “se pede licença”.
A leitura contemporânea da Associação  MILK reconhece nesta figura uma pedagogia ecológica:
a tríplice face traduz ciclagem (da seiva, das águas, do pastoreio) e cuidado (comunidade–
território–memória).
⸻
3. Toponímia e variantes locais

Registos orais apontam lugares associados à Velha: Penedo da Roca (Campo do Gerês), Fonte
Velha (Covide), Lomba das Três Vozes (Rio Caldo) e Caminho das Três Sombras (Vilarinho da
Furna). Variantes nomeiam-na “A das Três Vozes”, “Velha do Penedo” e “A Três-Mães” .
Em Vilarinho da Furna, moradores deslocados recordam uma “mulher do penedo” que avisava
sobre cheias; em Rio Caldo, a versão é mais aquática (protetora da nascente); em Campo do
Gerês, predominam relatos de encruzilhada (conselhos de rota). Em todas, a tríplice
manifestação marca o encontro de espaço (caminho/penedo/fonte) e tempo (manhã/meio-dia/
anoitecer).
⸻
4. Primeiro relato e fontes académicas primárias
As recolhas escritas antigas sobre esta figura são fragmentárias e dispersas em entradas
relativas a “mulheres do penedo”, “velhas das fontes” e “mães triplices” do Gerês. Na tradição
erudita portuguesa, coletores como Leite de Vasconcelos e Teófilo Braga registaram motivos
próximos (mulher de penedo, guardiãs de fonte, tríplice feminina), mas não um verbete único
canónico sob a denominação “Velha das Três Faces” para Terras de Bouro.
Para rigor académico, esta sistematização baseia-se em:
	 •	 Testemunhos orais recolhidos por Eduardo Mauer (2023–2025) em
Campo do Gerês, Covide e Rio Caldo (diários etnográ ficos MILK; gravações
depositadas no acervo interno do projeto Folclore Vivo).
	 •	 Cadernos paroquiais locais (séculos XIX–XX) com notas de “mulher do
penedo” aconselhando pastores em manhãs de nevoeiro (marginalia e crónicas de
romeiros).
	 •	 Inventários  municipais de património imaterial (apontamentos sobre
guardiãs de fontes e normas de silêncio à cabeceira das águas).
Observação metodológica: para efeitos de primeiro relato documental
consolidado, a presente entrada MILK 2025 fixa a designação “Velha das Três
Faces de Terras de Bouro” como sintese crítica de um conjunto de motivos
tradicionais atestados localmente (mulher do penedo/guardiã da fonte/triplidade
feminina) e validados por recolha oral contemporânea.
⸻
5. Síntese interpretativa final
A Velha das Três Faces não é “monstro” nem “santa”: é ritmo. Em corpo único, encarna três
tempos do cuidado — orientação (moça), sustento (mãe), prudência (ancião). Surpreende que a
sua ação principal seja perguntar. O mito ensina que, no Gerês, as respostas pertencem à
serra; ao humano, cabe reconhecer em que tempo está a caminhar.
Na leitura simbólica da Associação  MILK, a tríplice face é um diagrama de escuta:
	 •	 Face-moça ˠ abertura à rota (experimentação, risco contido);
	 •	 Face-mãe  ˠ mediação e abrigo (prioridade ao comum);
	 •	 Face-ancião  ˠ memória e medida (limites, pausa).
A ética prática que resulta é simples e exigente: pergunte antes de passar; abrande diante
da água; reconheça a hora do vale e a hora da encosta.
A proposta escultórica de Eduardo Mauer recolhe esta gramática: um único corpo
compacto (matriz MILK), três per fis insinuados num mesmo rosto — leves reentrâncias e
saliências que, com a luz, revelam ângulos diferentes: jovem, maduro, velho. No peito,

uma roca estilizada torna-se cajado conforme o ponto de vista, e um pequeno cesto se
sugere na curvatura lateral: fiar-cuidar-conduzir.
⸻
6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer
“A Velha das Três Faces é o corpo não binário do tempo: num só rosto coexistem
idades e papéis, sem hierarquia.”
A figura desarma dicotomias (novo/velho, ativo/passivo, natureza/cultura) e propõe
coexistência dinâmica . Não há “a” identidade certa, há fases que se revezam.
Na prática MILK, isto informa metodologias de criação colaborativa: os papéis
circulam (quem guia–quem cuida–quem recorda), à semelhança das três faces.
A dimensão de cuidado expandido (com pessoas, paisagem, água) liga-se a
políticas de escuta e tempo lento na mediação cultural. A Velha, ao perguntar em
que tempo caminhas, convida a autorregulação  (ritmo do corpo–ritmo do lugar),
sugerindo modos de sustentabilidade afetiva e ecológica.
⸻
7. Referência Estrutural da Matriz MILK
Na Matriz Escultórica MILK – Série Folclore Vivo, a Velha das Três Faces apresenta:
	 •	 Corpo: compacto e vertical, manto que desenha três dobras (três per fis).
	 •	 Rosto: volumetria facetada; conforme a luz, revela juventude, maturidade
ou velhice.
	 •	 Objetos-sinal: roca/cajado/cesto (integram-se na silhueta).
	 •	 Cores: granito húmido (cinza-ardósia), musgo (verde-escuro) e reflexos de
água (prata fria).
	 •	 Materiais: resina pigmentada com pó de ardósia; acabamento mate com
zonas polidas para jogos de luz.
	 •	 Base: laje elíptica com sulco sinuoso (caminho–água).
Integra o eixo “Guardadoras de Lugar” do projeto Folclore Vivo, dedicado a entidades
femininas (no sentido amplo) que mediam caminhos, águas e ritmos.
⸻
Localização  específica: Campo do Gerês, Covide, Vilarinho da Furna e Rio Caldo (Terras de
Bouro, distrito de Braga).
Primeiro relato documentado (fixação  MILK): Dossiê Folclore Vivo – Terras de Bouro
(Recolhas de Eduardo Mauer, 2023–2025; transcrições e notas de campo arquivadas no acervo
MILK 2025).
Sistematização  contemporânea:  Eduardo Mauer, A Velha das Três  Faces: Tempo, Cuidado e
Encruzilhadas no Gerês , Associação MILK, 2025.
Fontes de base: Recolhas orais locais; cadernos paroquiais (sécs. XIX–XX); inventários
municipais de património imaterial.
