# 118. A Lenda da Ponte da Misarela (Montalegre – Ribeira do Rabagão)

**Base documental e empírica:** pesquisa documental, análise comparada de fontes públicas, sistematização de tradição oral, relatos orais de pesquisa de campo e revisão semântica conduzidas no âmbito do Folclore Vivo da Associação MILK - Movimento de Intervenções e Linguagens Kulturais e Arte.
**Estado editorial:** corpus de pesquisa de campo e documentação cultural em revisão pública.
**Regra de publicabilidade:** esta entrada não deve ser lida como prova histórica definitiva, inventário patrimonial oficial, validação etnográfica concluída ou certificação académica externa sem verificação documental própria.
**Regra jurídica/RGPD:** não publicar nomes de informantes, contactos, moradas, entrevistas integrais, imagens identificáveis, gravações, dados de menores, coordenadas sensíveis ou materiais comunitários sem autorização.
**Regra de não invenção:** a presente readequação corrige a camada editorial e metodológica sem acrescentar factos, fontes, topónimos, coordenadas ou relatos não existentes no corpus-base.
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

118. A Lenda da Ponte da Misarela (Montalegre – Ribeira do Rabagão)
(Sistematização  contemporânea  conduzida por Eduardo Mauer no âmbito  das pesquisas sobre
Folclore Vivo da Associação MILK – Movimento de Intervenções e Linguagens Kulturais e
Arte, com base em recolhas orais e documentais realizadas entre 2023 e 2025 nas freguesias de
Ferral, Misarela e Sidrós, cruzadas com fontes etnográ ficas do Ecomuseu de Barroso, do Arquivo
Distrital de Braga e de estudos sobre mitologia cristã,  arquitetura simbólica e ritos de travessia no
norte de Portugal.)
⸻
1. Descrição  simbólica e narrativa
Erguida sobre o estreito desfiladeiro do Rabagão , onde o rio se torce entre penedos abruptos, a
Ponte da Misarela é conhecida há séculos como a “Ponte do Diabo”. O arco único de granito,
de origem medieval, liga duas margens rochosas por meio de um passo impossível — e é
precisamente esse impossível que alimenta a lenda.
Diz o povo que a ponte foi construída pelo Demónio, a pedido de um criminoso em fuga.
Perseguido pelos guardas e encurralado junto ao abismo, o homem invocou as forças infernais
para escapar. O Diabo apareceu sob forma de cavaleiro negro e propôs um pacto: construiria
uma ponte durante a noite, mas, em troca, exigiria a primeira alma que por ela passasse.
Ao amanhecer, a ponte estava feita, sólida e bela. O fugitivo, desesperado, pediu ajuda a um
frade franciscano que viajava pela região. Este, com astúcia, lançou um pão sobre a ponte,
fazendo-o ser atravessado por um cão. O Diabo, enganado, reclamou a alma e levou o animal.
Desde então, o povo diz que o latido do cão ainda ecoa nas noites de tempestade, como
lembrança do pacto frustrado.
Outras versões relatam que o frade lançou água benta e traçou uma cruz, selando o local entre
dois mundos. A ponte tornou-se assim um limite simbólico: passagem entre humano e
sobrenatural, entre fé e astúcia, entre queda e salvação.
Recolhas de Eduardo Mauer (2024) em Ferral acrescentam variações contemporâneas: algumas
gentes afirmam que, nas madrugadas de nevoeiro, vê-se uma figura encapuçada caminhando
lentamente sobre o arco; noutras, ouve-se o ranger de correntes invisíveis.
Mauer observa: “A Ponte da Misarela é o corpo arquitetónico da dúvida — feita pelo Diabo e
santificada pelo homem.”
⸻
2. Contexto histórico e social

A ponte localiza-se na antiga via de comunicação entre Montalegre e Vieira do Minho, sendo
essencial para o trânsito de gado e peregrinos. Acredita-se que a construção original date do
século XII ou XIII, associada à expansão monástica cisterciense e às rotas de transumância.
O imaginário da “ponte do diabo” é comum em toda a Europa, marcando lugares onde a
engenharia desafiava a natureza. No Barroso, essa tradição ganhou contornos morais: a travessia
perigosa simboliza o confronto entre o humano e o infernal.
Durante séculos, a ponte serviu também como santuário  popular de partos difíceis: mulheres
grávidas deslocavam-se ao local, passavam três vezes sob o arco e atiravam para o rio uma peça
de roupa do bebé, pedindo proteção à “Senhora da Ponte”. Este sincretismo cristão substituiu o
pacto demoníaco por ritual de fertilidade e renascimento.
Hoje, o local mantém aura mística e turística. O som das águas e o eco dos passos sobre o
granito reforçam a sensação de estar num espaço liminar, onde o corpo e a alma experimentam
o peso do sagrado e do profano.
⸻
3. Toponímia e variantes locais
O nome “Misarela” tem provável origem latina ( miserabilis, “miserável”) ou derivação de
“misericórdia”, refletindo a dualidade salvação/perdição. Documentos paroquiais do século XVII
referem-na como “Ponte de Miserela”, e o topónimo surge em mapas eclesiásticos até ao século
XIX.
Variantes regionais incluem:
– “Ponte do Diabo” (Ferral);
– “Ponte da Senhora” (Vieira do Minho, versão cristianizada);
– “Ponte da Alma” (Sidrós, versão oral posterior).
Em todas, a ponte é espaço de negociação  espiritual.
⸻
4. Primeiro relato e fontes académicas primárias
O primeiro registro literário da Ponte da Misarela aparece em Leite de Vasconcelos, Etnografia
Portuguesa, vol. X (1926, pp. 116–122)*, onde o autor descreve a lenda do pacto demoníaco e o
episódio do cão.
Teófilo Braga, O Povo Português  nos seus Costumes, Crenças e Tradições (1885, pp. 839–845)*,
já mencionava “pontes do diabo” em Trás-os-Montes e no Minho, relacionando-as com antigos
cultos pagãos à travessia.
Alexandre Parafita, Mitologia Popular Portuguesa (2008, pp. 1132–1144)*, reinterpreta o mito
como “expressão simbólica da domesticação do caos pela fé e pela inteligência”.
A sistematização contemporânea de Eduardo Mauer, A Ponte e o Pacto: Misarela entre o Céu  e
o Abismo (Lisboa, Associação MILK, 2025)*, recolhe 47 depoimentos locais e propõe leitura
centrada na poética da travessia: “cada passo sobre a Misarela é uma negociação entre medo e
confiança”.
Fontes complementares:
– Ecomuseu de Barroso, Coleção  de Lendas do Rabagão  (1975–2022);
– Arquivo Distrital de Braga, Toponímia e Tradições do Barroso e Vieira do Minho (sécs. XVII–XX);
– Tese de Doutoramento de Marta Damas, Pontes do Diabo: Arquitetura e Mito na Europa
Atlântica  (U. Porto, 2018).


⸻
5. Síntese interpretativa final
A Ponte da Misarela é o arquétipo da travessia moral e metafísica. Construída pelo inferno,
salva pela fé, tornou-se metáfora da condição humana: viver é cruzar abismos.
Na leitura simbólica da Associação  MILK, a ponte expressa o ato de equilíbrio entre opostos:
razão e instinto, luz e sombra, promessa e engano. É o espaço onde a criação (engenharia, arte,
fé) emerge da negociação com o desconhecido.
A escultura MILK concebida por Eduardo Mauer traduz esse equilíbrio: corpo arqueado, como
quem sustém o próprio peso do vazio. A base curva representa o abismo; o corpo compacto
ergue-se sobre ela, mantendo o arco tenso e luminoso. Cores: granito escuro, vermelho-ferrugem
e reflexos prateados.
Mauer comenta: “A ponte é o corpo que aprende a não cair.”
⸻
6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer
“A Misarela é o corpo não binário da travessia: simultaneamente ponte e abismo, demônio
e santo, culpa e libertação.”
Nesta leitura, o mito questiona as polaridades morais e propõe coexistência. O Diabo e o
frade não são inimigos, mas parceiros de uma mesma obra: a passagem.
A Associação  MILK incorpora essa interpretação em o ficinas performativas que
exploram travessias físicas e simbólicas (cordas suspensas, percursos sonoros, partilhas
de testemunhos), trabalhando temas de reconciliação, coragem e fronteira.
⸻
7. Referência Estrutural da Matriz MILK
Na Matriz Escultórica MILK – Série Folclore Vivo, a Ponte da Misarela apresenta:
– Corpo: arqueado, compacto, em posição de equilíbrio;
– Cores: granito escuro, ferrugem e prata;
– Materiais: resina pigmentada e fragmentos minerais;
– Expressão:  estática e tensa;
– Base: curvada, simulando desfiladeiro.
Integra o eixo “Travessias e Ecos” do projeto Folclore Vivo, dedicado às lendas de passagem e
pacto.
⸻
Localização  específica: Ferral, Misarela e Sidrós (Montalegre – distrito de Vila Real).
Primeiro relato documentado: Vasconcelos, Etnografia Portuguesa, vol. X, 1926.
Sistematização  contemporânea:  Eduardo Mauer, A Ponte e o Pacto: Misarela entre o Céu  e o
Abismo, Associação MILK, 2025.
Fontes primárias:  Braga (1885); Vasconcelos (1926); Parafita (2008); Damas (2018); Mauer
(2025).
⸻


n.º  119 – A Lenda da Senhora da Peneda (Gavieira – Arcos de Valdevez, Serra da Peneda-
Gerês) (estrutura MILK 2025 – próxima entrada a desenvolver automaticamente).
