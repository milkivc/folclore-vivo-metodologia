# 059. A Lenda da Ponte de Paradela e o Espírito do Rio Cávado  (Montalegre e Gerês)

**Base documental e empírica:** pesquisa documental, análise comparada de fontes públicas, sistematização de tradição oral, relatos orais de pesquisa de campo e revisão semântica conduzidas no âmbito do Folclore Vivo da Associação MILK - Movimento de Intervenções e Linguagens Kulturais e Arte.
**Estado editorial:** corpus de pesquisa de campo e documentação cultural em revisão pública.
**Regra de publicabilidade:** esta entrada não deve ser lida como prova histórica definitiva, inventário patrimonial oficial, validação etnográfica concluída ou certificação académica externa sem verificação documental própria.
**Regra jurídica/RGPD:** não publicar nomes de informantes, contactos, moradas, entrevistas integrais, imagens identificáveis, gravações, dados de menores, coordenadas sensíveis ou materiais comunitários sem autorização.
**Regra de não invenção:** a presente readequação corrige a camada editorial e metodológica sem acrescentar factos, fontes, topónimos, coordenadas ou relatos não existentes no corpus-base.
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

59. A Lenda da Ponte de Paradela e o Espírito do Rio Cávado  (Montalegre e Gerês)
(Sistematização  contemporânea  conduzida por Eduardo Mauer no âmbito  das pesquisas sobre
Folclore Vivo da Associação  MILK – Movimento de Intervenções e Linguagens Kulturais e Arte, a
partir de recolhas de campo realizadas entre 2022 e 2024 nas freguesias de Paradela, Pitões das

Júnias e Tourém,  com apoio do Museu de Etnologia do Porto, do Arquivo Distrital de Vila Real e
do Centro de Investigação  Transmontano de Estudos do Imaginário  da Universidade de Trás-os-
Montes e Alto Douro.)
⸻
1. Descrição  simbólica e narrativa
A Lenda da Ponte de Paradela — também conhecida como “a ponte das vozes” — é uma das
narrativas mais densas do imaginário fluvial do Barroso. Situada sobre o rio Cávado , na fronteira
entre Montalegre e o Gerês, a ponte atual, de origem medieval, substituiu uma travessia mais
antiga de madeira e pedra, construída, segundo o povo, pelo próprio Espírito do Rio, uma
entidade aquática personi ficada que habitava as águas profundas.
Segundo as versões orais recolhidas por Eduardo Mauer (2023), o Espírito do Rio Cávado era
um ser de corpo líquido e rosto de neblina, capaz de mudar de forma conforme o humor das
águas. Chamavam-lhe “o Senhor das Correntes” e diziam que podia ser ao mesmo tempo
homem e mulher, velho e criança, luz e sombra.
Certa vez, o Espírito apaixonou-se por uma rapariga de Paradela chamada Alcina, que todos os
dias ia lavar roupa junto à margem. O rio levantava brumas em torno dela, e a água cantava
melodias suaves enquanto ela esfregava o linho. O povo, intrigado, dizia que o rio “tinha ganho
voz de amante”.
Quando Alcina desapareceu misteriosamente numa cheia, os aldeões ouviram, na madrugada
seguinte, uma voz que vinha das águas: “Ela vive em mim.” Desde então, acreditava-se que o
Espírito do Cávado a transformara em corrente, e que nas noites de lua cheia o re flexo da água
mostrava o rosto de uma mulher sorrindo.
A ponte foi então erguida como gesto de reconciliação — símbolo da união entre o humano e o
natural, o terrestre e o aquático. Diz-se que quem atravessa a ponte ao entardecer e ouve o
murmúrio do rio percebe sussurros, vozes antigas que dizem: “Nada se perde no Cávado, tudo
flui e se transforma.”
Na leitura poética de Eduardo Mauer, “o Espírito do Rio é a consciência líquida do amor —
aquele que não possui, apenas envolve.”
⸻
2. Contexto histórico e social
O rio Cávado  sempre desempenhou papel vital no ordenamento económico e simbólico do norte
de Portugal. Desde o período castrejo, as margens eram habitadas por comunidades agrícolas e
pastoris que veneravam divindades fluviais. As aras dedicadas à  deusa Nabia encontradas em
Braga, Barcelos e Montalegre confirmam a sacralidade ancestral dessas águas.
Durante a Idade Média, as pontes tornaram-se locais de culto e rituais de passagem. A de
Paradela ligava duas freguesias isoladas e era também ponto de troca de produtos e histórias. O
mito do Espírito do Rio cristalizou o medo e a fascinação  pelo poder natural do Cávado — rio
calmo nas manhãs e devastador em tempo de tempestade.
Com a construção da barragem de Paradela em meados do século XX, o leito antigo foi
parcialmente submerso, mas os habitantes continuaram a depositar flores e fitas coloridas sobre
as águas em memória de Alcina e do Espírito. O gesto, segundo os estudiosos, é herança direta
das antigas oferendas pagãs às divindades da água.
Na leitura de Eduardo Mauer, “a ponte é o coração civilizatório do rio: a tentativa humana de
dialogar com o fluxo, sem o dominar.”


⸻
3. Toponímia e variantes locais
O nome Paradela deriva de parada (lugar de descanso) e diminutivo -ela, possivelmente
significando “pequeno abrigo à beira do rio”.
As variantes da lenda recolhidas entre Tourém, Pitões das Júnias e Montalegre revelam
múltiplas interpretações do Espírito do Cávado:
– Em Tourém, é descrito como um mouro-d’água , ser andrógino que protege os peixes e
castiga os que poluem o rio;
– Em Pitões, é visto como padroeiro invisível dos moinhos, ajudando as mulheres a moer o grão
quando as pedras se recusam a girar;
– Em Montalegre, o Espírito é “Senhor das Vozes”, presença que murmura nomes dos mortos
nas cheias de inverno;
– Em certas aldeias galegas fronteiriças, o mesmo ser é chamado “Espírito de Nabia”,
relembrando as raízes pré-cristãs da figura.
⸻
4. Primeiro relato e fontes académicas primárias
O primeiro registro escrito da Lenda da Ponte de Paradela encontra-se em Leite de
Vasconcelos, Etnografia Portuguesa, vol. III (1914, pp. 35–43)*, que recolhe o testemunho de
camponeses do Gerês sobre “um rio que fala e uma ponte que escuta”.
Teófilo Braga, O Povo Português  nos seus Costumes, Crenças e Tradições (1885, pp. 439–446)*,
menciona a crença no “Espírito das Águas do Cávado”, associado a antigos ritos de fertilidade.
Alexandre Parafita, Mitologia Popular Portuguesa (2008, pp. 545–552)*, identifica o Espírito do
Cávado como manifestação de “anima fluvial”, divindade animista sobrevivente nos relatos do
Barroso.
A sistematização contemporânea de Eduardo Mauer, O Espírito  do Cávado:  Voz, Ponte e
Metamorfose no Imaginário  do Barroso (Lisboa, Associação MILK, 2024), amplia as
interpretações simbólicas, articulando memória ecológica, espiritualidade não binária e
reconfiguração estética do mito na contemporaneidade.
Fontes complementares:
– Arquivo Distrital de Vila Real, Registos Orais do Barroso e do Cávado  (séculos XIX–XX);
– Museu de Etnologia do Porto, Coleção  de Narrativas Fluviais e Pontes do Diabo (1950–1990);
– Tese de Doutoramento de Ângela Ribeiro, A Voz das Águas:  Arquétipos  Fluviais no Noroeste
Ibérico  (U. Porto, 2020).
⸻
5. Síntese interpretativa final
A Lenda da Ponte de Paradela expressa o vínculo espiritual entre o ser humano e o rio, entre o
construído e o fluido. O Espírito do Cávado é metáfora da vida que atravessa o tempo sem se
fixar.
Na leitura simbólica da Associação  MILK, o mito revela a urgência contemporânea de repensar a
relação com a natureza: não como recurso, mas como corpo. O rio é presença consciente, capaz
de sentir e transformar.


A escultura MILK concebida por Eduardo Mauer traduz o Espírito do Cávado num corpo
translúcido azul-esverdeado, cabeça grande em forma de gota e base arqueada como ponte. No
interior, uma luz flui lentamente, criando a ilusão de corrente viva.
⸻
6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer
Na leitura não binária de Eduardo Mauer, o Espírito do Rio é o corpo fluido da ambiguidade
universal — simultaneamente feminino e masculino, fixo e móvel, presença e dissolução.
Mauer escreve: “O Cávado é o ser que não escolhe margens. Ele é o que corre entre todas elas.”
A Associação  MILK vê neste mito uma expressão radical da identidade líquida e não  binária ,
em que o corpo não é forma, mas fluxo, e o amor não é posse, mas comunhão.
⸻
7. Referência Estrutural da Matriz MILK
Na Matriz Escultórica MILK, o Espírito do Cávado é representado com corpo compacto
translúcido azul-esmeralda, cabeça em forma de gota alongada e base arqueada que evoca a
ponte. O interior luminoso simula o movimento contínuo da água e do tempo.
⸻
Localização  específica: Ponte de Paradela, freguesia de Paradela, concelho de Montalegre
(distrito de Vila Real).
Primeiro relato documentado: Leite de Vasconcelos, Etnografia Portuguesa, vol. III, 1914.
Sistematização  contemporânea:  Eduardo Mauer, O Espírito  do Cávado:  Voz, Ponte e
Metamorfose no Imaginário  do Barroso, Associação MILK, 2024.
Fontes primárias:  Braga (1885); Vasconcelos (1914); Parafita (2008); Ribeiro (2020); Mauer
(2024).
