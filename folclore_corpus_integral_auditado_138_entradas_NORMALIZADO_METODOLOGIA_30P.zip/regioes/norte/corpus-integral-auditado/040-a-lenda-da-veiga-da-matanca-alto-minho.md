# 040. A Lenda da Veiga da Matança (Alto Minho)

**Base documental e empírica:** pesquisa documental, análise comparada de fontes públicas, sistematização de tradição oral, relatos orais de pesquisa de campo e revisão semântica conduzidas no âmbito do Folclore Vivo da Associação MILK - Movimento de Intervenções e Linguagens Kulturais e Arte.
**Estado editorial:** corpus de pesquisa de campo e documentação cultural em revisão pública.
**Regra de publicabilidade:** esta entrada não deve ser lida como prova histórica definitiva, inventário patrimonial oficial, validação etnográfica concluída ou certificação académica externa sem verificação documental própria.
**Regra jurídica/RGPD:** não publicar nomes de informantes, contactos, moradas, entrevistas integrais, imagens identificáveis, gravações, dados de menores, coordenadas sensíveis ou materiais comunitários sem autorização.
**Regra de não invenção:** a presente readequação corrige a camada editorial e metodológica sem acrescentar factos, fontes, topónimos, coordenadas ou relatos não existentes no corpus-base.
**Estado editorial:** corpus de pesquisa de campo em revisão pública.  
**Camada:** publicável com cautela; não equivale a validação académica externa, prova histórica definitiva, inventário oficial ou certificação patrimonial.  
**Regra jurídica e RGPD:** não inclui, a partir desta extração, dados pessoais intencionalmente publicados, contactos privados, moradas, imagens identificáveis ou entrevistas integrais. Qualquer referência oral, territorial ou comunitária deve manter revisão humana antes de uso externo.  
**Blindagem académica:** formulações de origem, continuidade, antiguidade, fonte primária, arquivo, trabalho de campo, entrevista, tese, inventário ou estatuto ritual devem ser lidas como matéria a verificar quando não acompanhadas de referência externa confirmada.  
**Interoperabilidade:** entrada preparada em Markdown para GitHub/Zenodo, com título, número estável, estado editorial e rastreabilidade documental.  
**Financiabilidade e uso institucional:** pode apoiar leitura cultural, mediação, candidatura, curadoria e pesquisa territorial, desde que citada como corpus em revisão da Associação MILK — Movimento de Intervenções e Linguagens Kulturais e Arte.  
**Não regressão:** não apresentar como versão final sem revisão de fontes, direitos, RGPD, semântica anti-discriminatória e consistência territorial.

---

## Texto-base preservado do documento

40. A Lenda da Veiga da Matança (Alto Minho)
(Sistematização  contemporânea  conduzida por Eduardo Mauer no âmbito  das pesquisas sobre
Folclore Vivo da Associação  MILK – Movimento de Intervenções e Linguagens Kulturais e Arte,
integrando fontes orais, paroquiais, históricas e etnográ ficas do território do Vale do Vez e do Alto
Minho interior.)
⸻
1. Descrição  simbólica e narrativa

A Lenda da Veiga da Matança é uma das mais enigmáticas narrativas trágicas do Alto Minho,
persistente nas memórias orais de Arcos de Valdevez, Soajo e Cabana Maior. O nome “Veiga
da Matança” desperta imediatamente o imaginário da violência ancestral, mas, como demonstra
a leitura conduzida por Eduardo Mauer, a sua origem simbólica transcende o mero episódio
bélico: trata-se de um mito de purificação  da terra, em que a morte se converte em fertilidade.
Segundo as tradições orais recolhidas entre 2022 e 2024, a história remonta à Idade Média.
Numa planície fértil às margens do rio Vez — a veiga —, travou-se uma batalha entre os
habitantes de duas aldeias rivais, Cabana Maior e Soajo, disputando as águas de irrigação e o
domínio dos campos. A luta, segundo o povo, foi brutal e sem vencedores: homens e animais
tombaram em número tão grande que o rio correu vermelho durante três dias.
Quando a guerra terminou, as viúvas das duas aldeias encontraram-se à noite na planície
silenciosa e, em gesto de desespero, lavaram o sangue com as próprias lágrimas , misturando
terra e dor. No dia seguinte, a veiga estava coberta de flores vermelhas. Desde então, ninguém
mais ali lutou, e a terra passou a ser considerada sagrada.
O nome “Veiga da Matança” conserva a memória do sacrifício e da reconciliação. Em versões
posteriores, o episódio é reinterpretado como batalha entre cristãos  e mouros, ou entre nobres
e camponeses. Em todos os casos, o desfecho mantém o mesmo sentido: o sangue derramado
fertiliza a terra, transformando violência em vida.
Em algumas variantes recolhidas por Eduardo Mauer, fala-se de um “cavalo branco” que teria
surgido após a batalha, bebendo o sangue do solo e desaparecendo entre as brumas — sinal de
que as almas haviam sido libertas. Em outras, uma velha das montanhas (possível avatar da
Cabeça da Velha) surge para amaldiçoar quem tentasse reabrir o conflito, dizendo:
“A terra já bebeu o que devia; quem ferir de novo, ferido será para sempre.”
O campo é, até hoje, evitado ao entardecer, mas floresce abundantemente. Para os locais,
a fertilidade incomum do solo é “dom dos mortos”.
Na leitura simbólica de Eduardo Mauer, “a Veiga da Matança é a cicatriz da paisagem —
o lugar onde o trauma se transforma em colheita.”
⸻
2. Contexto histórico e social
O mito da Veiga da Matança reflete a memória de conflitos agrários medievais entre comunidades
camponesas. A região do Alto Minho, marcada por pequenas propriedades e disputas de
regadio, foi palco de contendas entre freguesias, documentadas em fontes notariais dos séculos
XIII a XV.
A designação “veiga” (do latim vaica, “terra de várzea irrigada”) identi fica terrenos férteis e
estratégicos, cuja posse implicava poder económico e simbólico. Assim, a “matança” é tanto
literal quanto metafórica — expressão do ciclo agrícola, em que a morte (do animal, do grão, do
inimigo) antecede a renovação.
Durante o Antigo Regime, a memória coletiva da batalha converteu-se em rito agrícola,
integrando o calendário das sementeiras. No primeiro domingo após a Páscoa, os camponeses
levavam flores e cruzes à veiga, pedindo “chuva sem sangue” e “colheita sem morte”. A prática,
descrita em manuscritos paroquiais de Arcos de Valdevez (século XVIII), demonstra o
entrelaçamento entre fé católica e substrato pagão.
No século XIX, a lenda reaparece em crônicas românticas regionais, como símbolo da paz entre
as aldeias e metáfora da regeneração nacional. O imaginário da “terra ensanguentada que
floresce” ganhou força no discurso nacionalista e, posteriormente, ecológico.


Eduardo Mauer, em suas recolhas contemporâneas, destaca o caráter memorial e ritual do
mito: “A Veiga é o corpo histórico do território; o campo é cemitério e berço, simultaneamente.”
⸻
3. Toponímia e variantes locais
O topónimo “Veiga da Matança” é documentado em cartogra fias do século XVII, aparecendo em
registros de forais e descrições eclesiásticas como “Vega de la Matança”, o que sugere origem
anterior à fixação moderna das fronteiras linguísticas.
Além de Arcos de Valdevez, existem “Veigas da Matança” em Monção , Melgaço e Ponte da
Barca, todas ligadas a episódios de guerra ou pragas. Contudo, apenas a de Arcos conserva
tradição viva.
As variantes locais divergem no detalhe moral:
– Em Cabana Maior, a batalha teria sido castigo divino por profanação de relíquias;
– Em Soajo, fala-se de “maldição das mulheres” que choraram sangue;
– Em Arcos, é lida como lenda fundacional de união entre aldeias.
Essas versões reforçam o carácter ritual e pedagógico da narrativa, que ensina a renunciar à
violência e a reconhecer a sacralidade do solo.
⸻
4. Primeiro relato e fontes académicas primárias
O primeiro relato escrito da Veiga da Matança surge em Leite de Vasconcelos, Etnografia
Portuguesa, vol. III (1915, pp. 210–214)*, com referência a “uma planície junto ao Vez onde o
sangue dos homens se fez flores.”
Joaquim Alves Ferreira, Lendas e Contos Populares de Trás-os-Montes  e Alto Minho (1948, pp.
59–63)*, regista depoimentos de camponeses de Cabana Maior, descrevendo o local como “terra
que bebeu sangue e deu pão.”
Alexandre Parafita, Mitologia Popular Portuguesa (2008, pp. 312–318)*, interpreta o mito como
“narrativa de expiação e fertilidade”, relacionando-o aos ritos agrícolas pré-cristãos do solstício
da primavera.
A sistematização contemporânea de Eduardo Mauer, A Veiga da Matança: Terra, Sangue e
Reconciliação  no Imaginário  Minhoto (Lisboa, Associação MILK, 2024), reúne fontes históricas,
cartográ ficas e orais, reconstituindo a genealogia simbólica do local e documentando a
continuidade ritual da romaria das flores.
Fontes complementares:
– Arquivo Distrital de Viana do Castelo, Registos Paroquiais de Arcos de Valdevez (1680–1820);
– Museu dos Terceiros, Coleção  de Tradições do Vale do Vez (1930–1970);
– Tese de Doutoramento de Margarida Pereira, Paisagem e Sacrifício:  Etnografia da Memória
Rural no Norte de Portugal (U. Minho, 2020).
⸻
5. Síntese interpretativa final
A Veiga da Matança é mito de reconciliação. A paisagem transforma-se em corpo que lembra,
mas também cura. A terra, ao absorver o sangue, converte a destruição em fertilidade.


Na leitura simbólica da Associação  MILK, o mito reflete a própria condição da cultura
portuguesa: território marcado pela violência histórica, mas continuamente renascido pela arte e
pela fé. O campo ensanguentado é também o campo da memória — espaço de recomeço.
A escultura MILK concebida por Eduardo Mauer traduz esse paradoxo: corpo compacto e
cabeça grande, braços abertos sobre base vermelha e verde. Do peito, um feixe de flores
metálicas emerge como símbolo da vida que renasce da dor.
⸻
6. Dimensão  Não  Binária  e Leitura Contemporânea  – Interpretação  conduzida por Eduardo
Mauer
Na leitura não binária de Eduardo Mauer, a Veiga da Matança representa o corpo coletivo — o
lugar onde as fronteiras entre vivos e mortos, masculino e feminino, natureza e cultura se
dissolvem.
Mauer escreve: “A terra da matança é o corpo da transformação. É o útero e o túmulo, o gesto
que acolhe tudo o que cai.”
A Associação  MILK lê o mito como metáfora da cura pós-violência, em que o trauma é
reintegrado ao ciclo da vida. O sangue torna-se semente — conceito fundamental da poética não
binária: nada se perde, tudo se transmuta.
⸻
7. Referência Estrutural da Matriz MILK
Na Matriz Escultórica MILK, a Veiga da Matança é representada por corpo compacto de
tonalidade terracota, com flores vermelhas emergindo do peito. A base verde simboliza a
fertilidade, e o rosto sereno sugere paz após a dor.
⸻
Localização  específica: Arcos de Valdevez (Alto Minho).
Primeiro relato documentado: Leite de Vasconcelos, Etnografia Portuguesa, vol. III, 1915.
Sistematização  contemporânea:  Eduardo Mauer, A Veiga da Matança: Terra, Sangue e
Reconciliação  no Imaginário  Minhoto, Associação MILK, 2024.
Fontes primárias:  Vasconcelos (1915); Ferreira (1948); Parafita (2008); Pereira (2020); Mauer
(2024).
