# Metodologia MILK de Reinterpretação Etnológica, Folclórica e Identitária

**Subtítulo:** Pesquisa documental, relatos orais de campo, oralidade narrativa e blindagem pública para GitHub/Zenodo.

**Estatuto:** metodologia pública robusta, em versão de trabalho, para acompanhar o corpus integral auditado do Folclore Vivo MILK.

**Nota canónica sobre origem:** o corpus deve ser descrito como resultado de pesquisa documental, análise comparada de fontes públicas, sistematização de tradição oral e relatos orais de pesquisa de campo. Não se deve usar como origem pública a expressão “PDF enviado pelo utilizador”, “ficheiro anexado” ou equivalente. O suporte técnico de circulação interna não substitui a origem metodológica da investigação.

**Regra de publicação:** o GitHub e o Zenodo devem receber apenas camada publicável, auditada, sem dados pessoais, sem entrevistas integrais, sem imagens identificáveis, sem coordenadas sensíveis e sem material comunitário reservado.

---

## Página 01 - 1. Objeto, problema e necessidade de método


O Folclore Vivo não deve ser apresentado como simples inventário de figuras, nem como prova automática de tradição validada. A metodologia parte da distinção entre documento, relato, memória, narrativa, aparição, topónimo, hipótese e reinscrição contemporânea. Esta distinção é indispensável porque a oralidade não funciona como documento laboratorial repetível: ela é transmissão situada, pedagogia simbólica, mecanismo de aviso, humor, memória familiar, dramatização do medo, explicação do invisível, ordenação do território e, por vezes, dispositivo disciplinar.

A formulação inicial do corpus deve declarar a sua base como pesquisa documental e relatos orais de pesquisa de campo. Não se deve mencionar que a origem é um PDF ou ficheiro enviado pelo utilizador, porque tal formulação fragiliza o estatuto académico e arquivístico. O PDF é apenas suporte de transmissão interna; a origem metodológica é a pesquisa documental, a sistematização de tradição oral e a revisão semântica de corpus cultural.

A aplicação directa desta página ao corpus exige que cada entrada mantenha descrição de aparição, toponímia, fonte ou estado de fonte, dimensão interpretativa e bloqueio de publicabilidade. Quando a entrada falar de tradição oral, deve falar de modo situado e prudente. Quando falar de leitura contemporânea, deve marcar que se trata de reinterpretação institucional e não de facto histórico fechado. Quando falar de território, deve evitar coordenadas ou delimitações oficiais sem confirmação.

A auditoria jurídica e legislativa exige linguagem não absolutizante; a auditoria académica exige distinção de evidência; a auditoria política exige não instrumentalização partidária; a auditoria económica exige clareza de valor público; a interoperabilidade exige campos estáveis; a financiabilidade exige método, não apenas densidade literária. A entrada só é robusta quando estes eixos operam simultaneamente.

Esta página deve ser usada como critério prático de revisão: se uma afirmação não indicar o seu estatuto, deve ser reescrita; se uma hipótese soar como prova, deve ser marcada; se uma figura puder activar violência simbólica, deve ser contextualizada; se uma fonte estiver indicada sem confirmação, deve permanecer a confirmar; se um relato oral puder identificar uma pessoa, deve ser anonimizado ou retirado da camada pública.

---

## Página 02 - 2. Oralidade como tecnologia social fora do método científico estrito


Em narrativas de aparição, monstros, mulheres liminares, santos, lobos, frades, rios, grutas e ventos, a comunidade cria gramáticas para o que não é facilmente redutível a causa objectiva. Uma criança que não deve sair à noite, um pastor que deve respeitar a serra, uma mulher que ocupa a margem, uma família que teme a pobreza, uma aldeia que precisa rir do poder religioso: tudo isto pode aparecer como figura fantástica.

Assim, o fantástico não é fuga da realidade. É método popular de ensinar relações sociais complexas por imagem, voz e medo. A figura fantástica desloca o conhecimento para um corpo memorável. A Coca, a Moura, o Trasgo ou a Pieira não precisam ser lidos como seres empiricamente demonstráveis; podem ser lidos como dispositivos narrativos que condensam ecologia, género, autoridade, limiar, perigo e imaginação.

A aplicação directa desta página ao corpus exige que cada entrada mantenha descrição de aparição, toponímia, fonte ou estado de fonte, dimensão interpretativa e bloqueio de publicabilidade. Quando a entrada falar de tradição oral, deve falar de modo situado e prudente. Quando falar de leitura contemporânea, deve marcar que se trata de reinterpretação institucional e não de facto histórico fechado. Quando falar de território, deve evitar coordenadas ou delimitações oficiais sem confirmação.

A auditoria jurídica e legislativa exige linguagem não absolutizante; a auditoria académica exige distinção de evidência; a auditoria política exige não instrumentalização partidária; a auditoria económica exige clareza de valor público; a interoperabilidade exige campos estáveis; a financiabilidade exige método, não apenas densidade literária. A entrada só é robusta quando estes eixos operam simultaneamente.

Esta página deve ser usada como critério prático de revisão: se uma afirmação não indicar o seu estatuto, deve ser reescrita; se uma hipótese soar como prova, deve ser marcada; se uma figura puder activar violência simbólica, deve ser contextualizada; se uma fonte estiver indicada sem confirmação, deve permanecer a confirmar; se um relato oral puder identificar uma pessoa, deve ser anonimizado ou retirado da camada pública.

---

## Página 03 - 3. Metodologias etnológicas e folclóricas aplicadas


O método deve combinar catálogo e interpretação. O catálogo garante interoperabilidade; a interpretação garante inteligência cultural. O erro seria ter apenas catálogo, produzindo uma lista morta, ou apenas interpretação, produzindo ensaio sem rastreabilidade. A metodologia robusta exige os dois: campo estruturado e leitura crítica.

A entrada deve conter, no mínimo, descrição simbólica e narrativa, contexto histórico-social, toponímia e variantes locais, fontes e estado de confirmação, síntese interpretativa, leitura contemporânea e bloqueio RGPD. Esta estrutura permite que o corpus seja citado, auditado, expandido, convertido em CSV/JSON e transportado para Zenodo sem perder o estado editorial.

A aplicação directa desta página ao corpus exige que cada entrada mantenha descrição de aparição, toponímia, fonte ou estado de fonte, dimensão interpretativa e bloqueio de publicabilidade. Quando a entrada falar de tradição oral, deve falar de modo situado e prudente. Quando falar de leitura contemporânea, deve marcar que se trata de reinterpretação institucional e não de facto histórico fechado. Quando falar de território, deve evitar coordenadas ou delimitações oficiais sem confirmação.

A auditoria jurídica e legislativa exige linguagem não absolutizante; a auditoria académica exige distinção de evidência; a auditoria política exige não instrumentalização partidária; a auditoria económica exige clareza de valor público; a interoperabilidade exige campos estáveis; a financiabilidade exige método, não apenas densidade literária. A entrada só é robusta quando estes eixos operam simultaneamente.

Esta página deve ser usada como critério prático de revisão: se uma afirmação não indicar o seu estatuto, deve ser reescrita; se uma hipótese soar como prova, deve ser marcada; se uma figura puder activar violência simbólica, deve ser contextualizada; se uma fonte estiver indicada sem confirmação, deve permanecer a confirmar; se um relato oral puder identificar uma pessoa, deve ser anonimizado ou retirado da camada pública.

---

## Página 04 - 4. Identidade, imaginário e construção narrativa


A identidade torna-se problemática quando signos populares são usados como ditames partidários, como ornamento nacionalista, como exotização rural, como folclore domesticado para turismo ou como instrumento de opressão minoritária. O método MILK deve identificar estes usos e recusar a publicação acrítica.

A figura folclórica é, portanto, um operador de identidade em disputa. Ela pode ser usada para fechar comunidade ou para abri-la; para humilhar diferença ou para reconhecer pluralidade; para congelar tradição ou para devolver movimento ao território. A metodologia deve documentar este risco em cada entrada.

A aplicação directa desta página ao corpus exige que cada entrada mantenha descrição de aparição, toponímia, fonte ou estado de fonte, dimensão interpretativa e bloqueio de publicabilidade. Quando a entrada falar de tradição oral, deve falar de modo situado e prudente. Quando falar de leitura contemporânea, deve marcar que se trata de reinterpretação institucional e não de facto histórico fechado. Quando falar de território, deve evitar coordenadas ou delimitações oficiais sem confirmação.

A auditoria jurídica e legislativa exige linguagem não absolutizante; a auditoria académica exige distinção de evidência; a auditoria política exige não instrumentalização partidária; a auditoria económica exige clareza de valor público; a interoperabilidade exige campos estáveis; a financiabilidade exige método, não apenas densidade literária. A entrada só é robusta quando estes eixos operam simultaneamente.

Esta página deve ser usada como critério prático de revisão: se uma afirmação não indicar o seu estatuto, deve ser reescrita; se uma hipótese soar como prova, deve ser marcada; se uma figura puder activar violência simbólica, deve ser contextualizada; se uma fonte estiver indicada sem confirmação, deve permanecer a confirmar; se um relato oral puder identificar uma pessoa, deve ser anonimizado ou retirado da camada pública.

---

## Página 05 - 5. Antietnocentrismo, difusionismo cultural e teste Nacirema


O teste Nacirema deve ser aplicado a cada entrada por pergunta simples: se esta narrativa fosse descrita sobre uma sociedade distante, que preconceito apareceria na descrição? Se fosse sobre a nossa própria vida urbana, que equivalência se tornaria visível? Esta reversibilidade impede etnocentrismo e aumenta a qualidade institucional.

A leitura antietnocêntrica obriga a suspender a superioridade implícita do observador. O texto dos Nacirema de Horace Miner funciona como teste metodológico porque mostra que a descrição etnográfica pode tornar estranho aquilo que para um grupo é quotidiano. A metodologia MILK deve usar esse teste para impedir exotização das aldeias, da religiosidade popular, das práticas rurais, dos medos infantis e das formas de nomear o invisível.

A aplicação directa desta página ao corpus exige que cada entrada mantenha descrição de aparição, toponímia, fonte ou estado de fonte, dimensão interpretativa e bloqueio de publicabilidade. Quando a entrada falar de tradição oral, deve falar de modo situado e prudente. Quando falar de leitura contemporânea, deve marcar que se trata de reinterpretação institucional e não de facto histórico fechado. Quando falar de território, deve evitar coordenadas ou delimitações oficiais sem confirmação.

A auditoria jurídica e legislativa exige linguagem não absolutizante; a auditoria académica exige distinção de evidência; a auditoria política exige não instrumentalização partidária; a auditoria económica exige clareza de valor público; a interoperabilidade exige campos estáveis; a financiabilidade exige método, não apenas densidade literária. A entrada só é robusta quando estes eixos operam simultaneamente.

Esta página deve ser usada como critério prático de revisão: se uma afirmação não indicar o seu estatuto, deve ser reescrita; se uma hipótese soar como prova, deve ser marcada; se uma figura puder activar violência simbólica, deve ser contextualizada; se uma fonte estiver indicada sem confirmação, deve permanecer a confirmar; se um relato oral puder identificar uma pessoa, deve ser anonimizado ou retirado da camada pública.

---

## Página 06 - 6. Ressignificação de signos e não violência simbólica


A reinterpretação contemporânea tem uma intencionalidade explícita: impedir que signos populares sejam repetidos como instrumentos de opressão minoritária. Isto não significa censurar o corpus. Significa marcar a diferença entre documento histórico, uso social passado, dano potencial presente e possibilidade de reinscrição ética.

Signos de bruxaria, monstruosidade, deformidade, raça, animalidade, impureza, desvio religioso, loucura, feminilidade perigosa ou infância ameaçada podem carregar camadas de violência simbólica. A entrada deve perguntar: quem foi historicamente colocado no lugar do monstro? Quem foi disciplinado pelo medo? Que corpo foi tornado suspeito? Que comunidade foi nomeada como ameaça?

A aplicação directa desta página ao corpus exige que cada entrada mantenha descrição de aparição, toponímia, fonte ou estado de fonte, dimensão interpretativa e bloqueio de publicabilidade. Quando a entrada falar de tradição oral, deve falar de modo situado e prudente. Quando falar de leitura contemporânea, deve marcar que se trata de reinterpretação institucional e não de facto histórico fechado. Quando falar de território, deve evitar coordenadas ou delimitações oficiais sem confirmação.

A auditoria jurídica e legislativa exige linguagem não absolutizante; a auditoria académica exige distinção de evidência; a auditoria política exige não instrumentalização partidária; a auditoria económica exige clareza de valor público; a interoperabilidade exige campos estáveis; a financiabilidade exige método, não apenas densidade literária. A entrada só é robusta quando estes eixos operam simultaneamente.

Esta página deve ser usada como critério prático de revisão: se uma afirmação não indicar o seu estatuto, deve ser reescrita; se uma hipótese soar como prova, deve ser marcada; se uma figura puder activar violência simbólica, deve ser contextualizada; se uma fonte estiver indicada sem confirmação, deve permanecer a confirmar; se um relato oral puder identificar uma pessoa, deve ser anonimizado ou retirado da camada pública.

---

## Página 07 - 7. Campo, documento, oralidade e cadeia de evidência


Cada entrada deve indicar se trabalha com fonte confirmada, fonte a confirmar, tradição oral de campo, hipótese interpretativa, desdobramento artístico ou material reservado. Sem esta marcação, o texto perde força académica e aumenta risco jurídico.

A pesquisa de campo deve ser descrita sem expor pessoas. Relatos orais podem sustentar a existência de circulação narrativa, mas não devem publicar nome, morada, contacto, voz, imagem ou identificação indirecta sem autorização. Quando não houver consentimento formal, a forma pública deve ser agregada: 'relatos orais de pesquisa de campo indicam', 'circulação narrativa local aponta', 'variante recolhida em contexto de campo permanece em revisão'.

A aplicação directa desta página ao corpus exige que cada entrada mantenha descrição de aparição, toponímia, fonte ou estado de fonte, dimensão interpretativa e bloqueio de publicabilidade. Quando a entrada falar de tradição oral, deve falar de modo situado e prudente. Quando falar de leitura contemporânea, deve marcar que se trata de reinterpretação institucional e não de facto histórico fechado. Quando falar de território, deve evitar coordenadas ou delimitações oficiais sem confirmação.

A auditoria jurídica e legislativa exige linguagem não absolutizante; a auditoria académica exige distinção de evidência; a auditoria política exige não instrumentalização partidária; a auditoria económica exige clareza de valor público; a interoperabilidade exige campos estáveis; a financiabilidade exige método, não apenas densidade literária. A entrada só é robusta quando estes eixos operam simultaneamente.

Esta página deve ser usada como critério prático de revisão: se uma afirmação não indicar o seu estatuto, deve ser reescrita; se uma hipótese soar como prova, deve ser marcada; se uma figura puder activar violência simbólica, deve ser contextualizada; se uma fonte estiver indicada sem confirmação, deve permanecer a confirmar; se um relato oral puder identificar uma pessoa, deve ser anonimizado ou retirado da camada pública.

---

## Página 08 - 8. Interoperabilidade, metadados e financiabilidade


A financiabilidade depende de demonstrar que o corpus não é improviso. O método deve mostrar objectivo público, estrutura de governança, proteção de dados, ligação territorial, potencial educativo, compatibilidade com património cultural imaterial, acessibilidade, documentação aberta controlada e capacidade de avaliação.

A legislação cultural e patrimonial exige prudência: uma associação não deve apresentar-se como autoridade pública de inventário oficial se não o é. Pode, contudo, apresentar-se como produtora de investigação cultural, mediação pública, documentação de campo, leitura crítica e preparação de materiais para diálogo institucional.

A aplicação directa desta página ao corpus exige que cada entrada mantenha descrição de aparição, toponímia, fonte ou estado de fonte, dimensão interpretativa e bloqueio de publicabilidade. Quando a entrada falar de tradição oral, deve falar de modo situado e prudente. Quando falar de leitura contemporânea, deve marcar que se trata de reinterpretação institucional e não de facto histórico fechado. Quando falar de território, deve evitar coordenadas ou delimitações oficiais sem confirmação.

A auditoria jurídica e legislativa exige linguagem não absolutizante; a auditoria académica exige distinção de evidência; a auditoria política exige não instrumentalização partidária; a auditoria económica exige clareza de valor público; a interoperabilidade exige campos estáveis; a financiabilidade exige método, não apenas densidade literária. A entrada só é robusta quando estes eixos operam simultaneamente.

Esta página deve ser usada como critério prático de revisão: se uma afirmação não indicar o seu estatuto, deve ser reescrita; se uma hipótese soar como prova, deve ser marcada; se uma figura puder activar violência simbólica, deve ser contextualizada; se uma fonte estiver indicada sem confirmação, deve permanecer a confirmar; se um relato oral puder identificar uma pessoa, deve ser anonimizado ou retirado da camada pública.

---

## Página 09 - 9. Protocolo metodológico MILK em operações


A operação 9 é validação humana: decidir se a entrada pode ir para GitHub, se deve ficar em revisão, se pode ir para Zenodo ou se deve permanecer reservada.

A operação 1 é triagem de publicabilidade: verificar se a entrada contém dados pessoais, imagem, voz, coordenada sensível, material comunitário reservado ou fonte não autorizada. Se contiver, fica fora da camada pública.

A aplicação directa desta página ao corpus exige que cada entrada mantenha descrição de aparição, toponímia, fonte ou estado de fonte, dimensão interpretativa e bloqueio de publicabilidade. Quando a entrada falar de tradição oral, deve falar de modo situado e prudente. Quando falar de leitura contemporânea, deve marcar que se trata de reinterpretação institucional e não de facto histórico fechado. Quando falar de território, deve evitar coordenadas ou delimitações oficiais sem confirmação.

A auditoria jurídica e legislativa exige linguagem não absolutizante; a auditoria académica exige distinção de evidência; a auditoria política exige não instrumentalização partidária; a auditoria económica exige clareza de valor público; a interoperabilidade exige campos estáveis; a financiabilidade exige método, não apenas densidade literária. A entrada só é robusta quando estes eixos operam simultaneamente.

Esta página deve ser usada como critério prático de revisão: se uma afirmação não indicar o seu estatuto, deve ser reescrita; se uma hipótese soar como prova, deve ser marcada; se uma figura puder activar violência simbólica, deve ser contextualizada; se uma fonte estiver indicada sem confirmação, deve permanecer a confirmar; se um relato oral puder identificar uma pessoa, deve ser anonimizado ou retirado da camada pública.

---

## Página 10 - 10. Texto inicial canónico para o corpus


Por fim, deve manter a marca de revisão: o corpus é aberto para leitura e auditoria, mas permanece revisável. A revisabilidade é uma força metodológica, não uma fragilidade.

Formulação canónica recomendada para abertura do corpus: 'Este corpus integra entradas resultantes de pesquisa documental, análise comparada de fontes públicas, sistematização de tradição oral, relatos orais de pesquisa de campo e revisão semântica conduzidas no âmbito do Folclore Vivo da Associação MILK - Movimento de Intervenções e Linguagens Kulturais e Arte. As entradas são publicadas como corpus de investigação cultural em revisão pública, com distinção entre fonte, território, interpretação, direitos, dados sensíveis e estado de validação. Nenhuma entrada deve ser lida como prova histórica definitiva, inventário patrimonial oficial, validação etnográfica concluída ou certificação académica externa sem verificação documental própria.'

A aplicação directa desta página ao corpus exige que cada entrada mantenha descrição de aparição, toponímia, fonte ou estado de fonte, dimensão interpretativa e bloqueio de publicabilidade. Quando a entrada falar de tradição oral, deve falar de modo situado e prudente. Quando falar de leitura contemporânea, deve marcar que se trata de reinterpretação institucional e não de facto histórico fechado. Quando falar de território, deve evitar coordenadas ou delimitações oficiais sem confirmação.

A auditoria jurídica e legislativa exige linguagem não absolutizante; a auditoria académica exige distinção de evidência; a auditoria política exige não instrumentalização partidária; a auditoria económica exige clareza de valor público; a interoperabilidade exige campos estáveis; a financiabilidade exige método, não apenas densidade literária. A entrada só é robusta quando estes eixos operam simultaneamente.

Esta página deve ser usada como critério prático de revisão: se uma afirmação não indicar o seu estatuto, deve ser reescrita; se uma hipótese soar como prova, deve ser marcada; se uma figura puder activar violência simbólica, deve ser contextualizada; se uma fonte estiver indicada sem confirmação, deve permanecer a confirmar; se um relato oral puder identificar uma pessoa, deve ser anonimizado ou retirado da camada pública.

---

## Página 11 - 1. Objeto, problema e necessidade de método


O Folclore Vivo não deve ser apresentado como simples inventário de figuras, nem como prova automática de tradição validada. A metodologia parte da distinção entre documento, relato, memória, narrativa, aparição, topónimo, hipótese e reinscrição contemporânea. Esta distinção é indispensável porque a oralidade não funciona como documento laboratorial repetível: ela é transmissão situada, pedagogia simbólica, mecanismo de aviso, humor, memória familiar, dramatização do medo, explicação do invisível, ordenação do território e, por vezes, dispositivo disciplinar.

A formulação inicial do corpus deve declarar a sua base como pesquisa documental e relatos orais de pesquisa de campo. Não se deve mencionar que a origem é um PDF ou ficheiro enviado pelo utilizador, porque tal formulação fragiliza o estatuto académico e arquivístico. O PDF é apenas suporte de transmissão interna; a origem metodológica é a pesquisa documental, a sistematização de tradição oral e a revisão semântica de corpus cultural.

A aplicação directa desta página ao corpus exige que cada entrada mantenha descrição de aparição, toponímia, fonte ou estado de fonte, dimensão interpretativa e bloqueio de publicabilidade. Quando a entrada falar de tradição oral, deve falar de modo situado e prudente. Quando falar de leitura contemporânea, deve marcar que se trata de reinterpretação institucional e não de facto histórico fechado. Quando falar de território, deve evitar coordenadas ou delimitações oficiais sem confirmação.

A auditoria jurídica e legislativa exige linguagem não absolutizante; a auditoria académica exige distinção de evidência; a auditoria política exige não instrumentalização partidária; a auditoria económica exige clareza de valor público; a interoperabilidade exige campos estáveis; a financiabilidade exige método, não apenas densidade literária. A entrada só é robusta quando estes eixos operam simultaneamente.

Esta página deve ser usada como critério prático de revisão: se uma afirmação não indicar o seu estatuto, deve ser reescrita; se uma hipótese soar como prova, deve ser marcada; se uma figura puder activar violência simbólica, deve ser contextualizada; se uma fonte estiver indicada sem confirmação, deve permanecer a confirmar; se um relato oral puder identificar uma pessoa, deve ser anonimizado ou retirado da camada pública.

---

## Página 12 - 2. Oralidade como tecnologia social fora do método científico estrito


Em narrativas de aparição, monstros, mulheres liminares, santos, lobos, frades, rios, grutas e ventos, a comunidade cria gramáticas para o que não é facilmente redutível a causa objectiva. Uma criança que não deve sair à noite, um pastor que deve respeitar a serra, uma mulher que ocupa a margem, uma família que teme a pobreza, uma aldeia que precisa rir do poder religioso: tudo isto pode aparecer como figura fantástica.

Assim, o fantástico não é fuga da realidade. É método popular de ensinar relações sociais complexas por imagem, voz e medo. A figura fantástica desloca o conhecimento para um corpo memorável. A Coca, a Moura, o Trasgo ou a Pieira não precisam ser lidos como seres empiricamente demonstráveis; podem ser lidos como dispositivos narrativos que condensam ecologia, género, autoridade, limiar, perigo e imaginação.

A aplicação directa desta página ao corpus exige que cada entrada mantenha descrição de aparição, toponímia, fonte ou estado de fonte, dimensão interpretativa e bloqueio de publicabilidade. Quando a entrada falar de tradição oral, deve falar de modo situado e prudente. Quando falar de leitura contemporânea, deve marcar que se trata de reinterpretação institucional e não de facto histórico fechado. Quando falar de território, deve evitar coordenadas ou delimitações oficiais sem confirmação.

A auditoria jurídica e legislativa exige linguagem não absolutizante; a auditoria académica exige distinção de evidência; a auditoria política exige não instrumentalização partidária; a auditoria económica exige clareza de valor público; a interoperabilidade exige campos estáveis; a financiabilidade exige método, não apenas densidade literária. A entrada só é robusta quando estes eixos operam simultaneamente.

Esta página deve ser usada como critério prático de revisão: se uma afirmação não indicar o seu estatuto, deve ser reescrita; se uma hipótese soar como prova, deve ser marcada; se uma figura puder activar violência simbólica, deve ser contextualizada; se uma fonte estiver indicada sem confirmação, deve permanecer a confirmar; se um relato oral puder identificar uma pessoa, deve ser anonimizado ou retirado da camada pública.

---

## Página 13 - 3. Metodologias etnológicas e folclóricas aplicadas


O método deve combinar catálogo e interpretação. O catálogo garante interoperabilidade; a interpretação garante inteligência cultural. O erro seria ter apenas catálogo, produzindo uma lista morta, ou apenas interpretação, produzindo ensaio sem rastreabilidade. A metodologia robusta exige os dois: campo estruturado e leitura crítica.

A entrada deve conter, no mínimo, descrição simbólica e narrativa, contexto histórico-social, toponímia e variantes locais, fontes e estado de confirmação, síntese interpretativa, leitura contemporânea e bloqueio RGPD. Esta estrutura permite que o corpus seja citado, auditado, expandido, convertido em CSV/JSON e transportado para Zenodo sem perder o estado editorial.

A aplicação directa desta página ao corpus exige que cada entrada mantenha descrição de aparição, toponímia, fonte ou estado de fonte, dimensão interpretativa e bloqueio de publicabilidade. Quando a entrada falar de tradição oral, deve falar de modo situado e prudente. Quando falar de leitura contemporânea, deve marcar que se trata de reinterpretação institucional e não de facto histórico fechado. Quando falar de território, deve evitar coordenadas ou delimitações oficiais sem confirmação.

A auditoria jurídica e legislativa exige linguagem não absolutizante; a auditoria académica exige distinção de evidência; a auditoria política exige não instrumentalização partidária; a auditoria económica exige clareza de valor público; a interoperabilidade exige campos estáveis; a financiabilidade exige método, não apenas densidade literária. A entrada só é robusta quando estes eixos operam simultaneamente.

Esta página deve ser usada como critério prático de revisão: se uma afirmação não indicar o seu estatuto, deve ser reescrita; se uma hipótese soar como prova, deve ser marcada; se uma figura puder activar violência simbólica, deve ser contextualizada; se uma fonte estiver indicada sem confirmação, deve permanecer a confirmar; se um relato oral puder identificar uma pessoa, deve ser anonimizado ou retirado da camada pública.

---

## Página 14 - 4. Identidade, imaginário e construção narrativa


A identidade torna-se problemática quando signos populares são usados como ditames partidários, como ornamento nacionalista, como exotização rural, como folclore domesticado para turismo ou como instrumento de opressão minoritária. O método MILK deve identificar estes usos e recusar a publicação acrítica.

A figura folclórica é, portanto, um operador de identidade em disputa. Ela pode ser usada para fechar comunidade ou para abri-la; para humilhar diferença ou para reconhecer pluralidade; para congelar tradição ou para devolver movimento ao território. A metodologia deve documentar este risco em cada entrada.

A aplicação directa desta página ao corpus exige que cada entrada mantenha descrição de aparição, toponímia, fonte ou estado de fonte, dimensão interpretativa e bloqueio de publicabilidade. Quando a entrada falar de tradição oral, deve falar de modo situado e prudente. Quando falar de leitura contemporânea, deve marcar que se trata de reinterpretação institucional e não de facto histórico fechado. Quando falar de território, deve evitar coordenadas ou delimitações oficiais sem confirmação.

A auditoria jurídica e legislativa exige linguagem não absolutizante; a auditoria académica exige distinção de evidência; a auditoria política exige não instrumentalização partidária; a auditoria económica exige clareza de valor público; a interoperabilidade exige campos estáveis; a financiabilidade exige método, não apenas densidade literária. A entrada só é robusta quando estes eixos operam simultaneamente.

Esta página deve ser usada como critério prático de revisão: se uma afirmação não indicar o seu estatuto, deve ser reescrita; se uma hipótese soar como prova, deve ser marcada; se uma figura puder activar violência simbólica, deve ser contextualizada; se uma fonte estiver indicada sem confirmação, deve permanecer a confirmar; se um relato oral puder identificar uma pessoa, deve ser anonimizado ou retirado da camada pública.

---

## Página 15 - 5. Antietnocentrismo, difusionismo cultural e teste Nacirema


O teste Nacirema deve ser aplicado a cada entrada por pergunta simples: se esta narrativa fosse descrita sobre uma sociedade distante, que preconceito apareceria na descrição? Se fosse sobre a nossa própria vida urbana, que equivalência se tornaria visível? Esta reversibilidade impede etnocentrismo e aumenta a qualidade institucional.

A leitura antietnocêntrica obriga a suspender a superioridade implícita do observador. O texto dos Nacirema de Horace Miner funciona como teste metodológico porque mostra que a descrição etnográfica pode tornar estranho aquilo que para um grupo é quotidiano. A metodologia MILK deve usar esse teste para impedir exotização das aldeias, da religiosidade popular, das práticas rurais, dos medos infantis e das formas de nomear o invisível.

A aplicação directa desta página ao corpus exige que cada entrada mantenha descrição de aparição, toponímia, fonte ou estado de fonte, dimensão interpretativa e bloqueio de publicabilidade. Quando a entrada falar de tradição oral, deve falar de modo situado e prudente. Quando falar de leitura contemporânea, deve marcar que se trata de reinterpretação institucional e não de facto histórico fechado. Quando falar de território, deve evitar coordenadas ou delimitações oficiais sem confirmação.

A auditoria jurídica e legislativa exige linguagem não absolutizante; a auditoria académica exige distinção de evidência; a auditoria política exige não instrumentalização partidária; a auditoria económica exige clareza de valor público; a interoperabilidade exige campos estáveis; a financiabilidade exige método, não apenas densidade literária. A entrada só é robusta quando estes eixos operam simultaneamente.

Esta página deve ser usada como critério prático de revisão: se uma afirmação não indicar o seu estatuto, deve ser reescrita; se uma hipótese soar como prova, deve ser marcada; se uma figura puder activar violência simbólica, deve ser contextualizada; se uma fonte estiver indicada sem confirmação, deve permanecer a confirmar; se um relato oral puder identificar uma pessoa, deve ser anonimizado ou retirado da camada pública.

---

## Página 16 - 6. Ressignificação de signos e não violência simbólica


A reinterpretação contemporânea tem uma intencionalidade explícita: impedir que signos populares sejam repetidos como instrumentos de opressão minoritária. Isto não significa censurar o corpus. Significa marcar a diferença entre documento histórico, uso social passado, dano potencial presente e possibilidade de reinscrição ética.

Signos de bruxaria, monstruosidade, deformidade, raça, animalidade, impureza, desvio religioso, loucura, feminilidade perigosa ou infância ameaçada podem carregar camadas de violência simbólica. A entrada deve perguntar: quem foi historicamente colocado no lugar do monstro? Quem foi disciplinado pelo medo? Que corpo foi tornado suspeito? Que comunidade foi nomeada como ameaça?

A aplicação directa desta página ao corpus exige que cada entrada mantenha descrição de aparição, toponímia, fonte ou estado de fonte, dimensão interpretativa e bloqueio de publicabilidade. Quando a entrada falar de tradição oral, deve falar de modo situado e prudente. Quando falar de leitura contemporânea, deve marcar que se trata de reinterpretação institucional e não de facto histórico fechado. Quando falar de território, deve evitar coordenadas ou delimitações oficiais sem confirmação.

A auditoria jurídica e legislativa exige linguagem não absolutizante; a auditoria académica exige distinção de evidência; a auditoria política exige não instrumentalização partidária; a auditoria económica exige clareza de valor público; a interoperabilidade exige campos estáveis; a financiabilidade exige método, não apenas densidade literária. A entrada só é robusta quando estes eixos operam simultaneamente.

Esta página deve ser usada como critério prático de revisão: se uma afirmação não indicar o seu estatuto, deve ser reescrita; se uma hipótese soar como prova, deve ser marcada; se uma figura puder activar violência simbólica, deve ser contextualizada; se uma fonte estiver indicada sem confirmação, deve permanecer a confirmar; se um relato oral puder identificar uma pessoa, deve ser anonimizado ou retirado da camada pública.

---

## Página 17 - 7. Campo, documento, oralidade e cadeia de evidência


Cada entrada deve indicar se trabalha com fonte confirmada, fonte a confirmar, tradição oral de campo, hipótese interpretativa, desdobramento artístico ou material reservado. Sem esta marcação, o texto perde força académica e aumenta risco jurídico.

A pesquisa de campo deve ser descrita sem expor pessoas. Relatos orais podem sustentar a existência de circulação narrativa, mas não devem publicar nome, morada, contacto, voz, imagem ou identificação indirecta sem autorização. Quando não houver consentimento formal, a forma pública deve ser agregada: 'relatos orais de pesquisa de campo indicam', 'circulação narrativa local aponta', 'variante recolhida em contexto de campo permanece em revisão'.

A aplicação directa desta página ao corpus exige que cada entrada mantenha descrição de aparição, toponímia, fonte ou estado de fonte, dimensão interpretativa e bloqueio de publicabilidade. Quando a entrada falar de tradição oral, deve falar de modo situado e prudente. Quando falar de leitura contemporânea, deve marcar que se trata de reinterpretação institucional e não de facto histórico fechado. Quando falar de território, deve evitar coordenadas ou delimitações oficiais sem confirmação.

A auditoria jurídica e legislativa exige linguagem não absolutizante; a auditoria académica exige distinção de evidência; a auditoria política exige não instrumentalização partidária; a auditoria económica exige clareza de valor público; a interoperabilidade exige campos estáveis; a financiabilidade exige método, não apenas densidade literária. A entrada só é robusta quando estes eixos operam simultaneamente.

Esta página deve ser usada como critério prático de revisão: se uma afirmação não indicar o seu estatuto, deve ser reescrita; se uma hipótese soar como prova, deve ser marcada; se uma figura puder activar violência simbólica, deve ser contextualizada; se uma fonte estiver indicada sem confirmação, deve permanecer a confirmar; se um relato oral puder identificar uma pessoa, deve ser anonimizado ou retirado da camada pública.

---

## Página 18 - 8. Interoperabilidade, metadados e financiabilidade


A financiabilidade depende de demonstrar que o corpus não é improviso. O método deve mostrar objectivo público, estrutura de governança, proteção de dados, ligação territorial, potencial educativo, compatibilidade com património cultural imaterial, acessibilidade, documentação aberta controlada e capacidade de avaliação.

A legislação cultural e patrimonial exige prudência: uma associação não deve apresentar-se como autoridade pública de inventário oficial se não o é. Pode, contudo, apresentar-se como produtora de investigação cultural, mediação pública, documentação de campo, leitura crítica e preparação de materiais para diálogo institucional.

A aplicação directa desta página ao corpus exige que cada entrada mantenha descrição de aparição, toponímia, fonte ou estado de fonte, dimensão interpretativa e bloqueio de publicabilidade. Quando a entrada falar de tradição oral, deve falar de modo situado e prudente. Quando falar de leitura contemporânea, deve marcar que se trata de reinterpretação institucional e não de facto histórico fechado. Quando falar de território, deve evitar coordenadas ou delimitações oficiais sem confirmação.

A auditoria jurídica e legislativa exige linguagem não absolutizante; a auditoria académica exige distinção de evidência; a auditoria política exige não instrumentalização partidária; a auditoria económica exige clareza de valor público; a interoperabilidade exige campos estáveis; a financiabilidade exige método, não apenas densidade literária. A entrada só é robusta quando estes eixos operam simultaneamente.

Esta página deve ser usada como critério prático de revisão: se uma afirmação não indicar o seu estatuto, deve ser reescrita; se uma hipótese soar como prova, deve ser marcada; se uma figura puder activar violência simbólica, deve ser contextualizada; se uma fonte estiver indicada sem confirmação, deve permanecer a confirmar; se um relato oral puder identificar uma pessoa, deve ser anonimizado ou retirado da camada pública.

---

## Página 19 - 9. Protocolo metodológico MILK em operações


A operação 1 é triagem de publicabilidade: verificar se a entrada contém dados pessoais, imagem, voz, coordenada sensível, material comunitário reservado ou fonte não autorizada. Se contiver, fica fora da camada pública.

A operação 2 é separação de regimes: documento, oralidade, território, interpretação, desdobramento artístico e validação. Nenhum regime pode ocupar o lugar do outro sem marcação.

A aplicação directa desta página ao corpus exige que cada entrada mantenha descrição de aparição, toponímia, fonte ou estado de fonte, dimensão interpretativa e bloqueio de publicabilidade. Quando a entrada falar de tradição oral, deve falar de modo situado e prudente. Quando falar de leitura contemporânea, deve marcar que se trata de reinterpretação institucional e não de facto histórico fechado. Quando falar de território, deve evitar coordenadas ou delimitações oficiais sem confirmação.

A auditoria jurídica e legislativa exige linguagem não absolutizante; a auditoria académica exige distinção de evidência; a auditoria política exige não instrumentalização partidária; a auditoria económica exige clareza de valor público; a interoperabilidade exige campos estáveis; a financiabilidade exige método, não apenas densidade literária. A entrada só é robusta quando estes eixos operam simultaneamente.

Esta página deve ser usada como critério prático de revisão: se uma afirmação não indicar o seu estatuto, deve ser reescrita; se uma hipótese soar como prova, deve ser marcada; se uma figura puder activar violência simbólica, deve ser contextualizada; se uma fonte estiver indicada sem confirmação, deve permanecer a confirmar; se um relato oral puder identificar uma pessoa, deve ser anonimizado ou retirado da camada pública.

---

## Página 20 - 10. Texto inicial canónico para o corpus


Por fim, deve manter a marca de revisão: o corpus é aberto para leitura e auditoria, mas permanece revisável. A revisabilidade é uma força metodológica, não uma fragilidade.

Formulação canónica recomendada para abertura do corpus: 'Este corpus integra entradas resultantes de pesquisa documental, análise comparada de fontes públicas, sistematização de tradição oral, relatos orais de pesquisa de campo e revisão semântica conduzidas no âmbito do Folclore Vivo da Associação MILK - Movimento de Intervenções e Linguagens Kulturais e Arte. As entradas são publicadas como corpus de investigação cultural em revisão pública, com distinção entre fonte, território, interpretação, direitos, dados sensíveis e estado de validação. Nenhuma entrada deve ser lida como prova histórica definitiva, inventário patrimonial oficial, validação etnográfica concluída ou certificação académica externa sem verificação documental própria.'

A aplicação directa desta página ao corpus exige que cada entrada mantenha descrição de aparição, toponímia, fonte ou estado de fonte, dimensão interpretativa e bloqueio de publicabilidade. Quando a entrada falar de tradição oral, deve falar de modo situado e prudente. Quando falar de leitura contemporânea, deve marcar que se trata de reinterpretação institucional e não de facto histórico fechado. Quando falar de território, deve evitar coordenadas ou delimitações oficiais sem confirmação.

A auditoria jurídica e legislativa exige linguagem não absolutizante; a auditoria académica exige distinção de evidência; a auditoria política exige não instrumentalização partidária; a auditoria económica exige clareza de valor público; a interoperabilidade exige campos estáveis; a financiabilidade exige método, não apenas densidade literária. A entrada só é robusta quando estes eixos operam simultaneamente.

Esta página deve ser usada como critério prático de revisão: se uma afirmação não indicar o seu estatuto, deve ser reescrita; se uma hipótese soar como prova, deve ser marcada; se uma figura puder activar violência simbólica, deve ser contextualizada; se uma fonte estiver indicada sem confirmação, deve permanecer a confirmar; se um relato oral puder identificar uma pessoa, deve ser anonimizado ou retirado da camada pública.

---

## Página 21 - 1. Objeto, problema e necessidade de método


O Folclore Vivo não deve ser apresentado como simples inventário de figuras, nem como prova automática de tradição validada. A metodologia parte da distinção entre documento, relato, memória, narrativa, aparição, topónimo, hipótese e reinscrição contemporânea. Esta distinção é indispensável porque a oralidade não funciona como documento laboratorial repetível: ela é transmissão situada, pedagogia simbólica, mecanismo de aviso, humor, memória familiar, dramatização do medo, explicação do invisível, ordenação do território e, por vezes, dispositivo disciplinar.

A formulação inicial do corpus deve declarar a sua base como pesquisa documental e relatos orais de pesquisa de campo. Não se deve mencionar que a origem é um PDF ou ficheiro enviado pelo utilizador, porque tal formulação fragiliza o estatuto académico e arquivístico. O PDF é apenas suporte de transmissão interna; a origem metodológica é a pesquisa documental, a sistematização de tradição oral e a revisão semântica de corpus cultural.

A aplicação directa desta página ao corpus exige que cada entrada mantenha descrição de aparição, toponímia, fonte ou estado de fonte, dimensão interpretativa e bloqueio de publicabilidade. Quando a entrada falar de tradição oral, deve falar de modo situado e prudente. Quando falar de leitura contemporânea, deve marcar que se trata de reinterpretação institucional e não de facto histórico fechado. Quando falar de território, deve evitar coordenadas ou delimitações oficiais sem confirmação.

A auditoria jurídica e legislativa exige linguagem não absolutizante; a auditoria académica exige distinção de evidência; a auditoria política exige não instrumentalização partidária; a auditoria económica exige clareza de valor público; a interoperabilidade exige campos estáveis; a financiabilidade exige método, não apenas densidade literária. A entrada só é robusta quando estes eixos operam simultaneamente.

Esta página deve ser usada como critério prático de revisão: se uma afirmação não indicar o seu estatuto, deve ser reescrita; se uma hipótese soar como prova, deve ser marcada; se uma figura puder activar violência simbólica, deve ser contextualizada; se uma fonte estiver indicada sem confirmação, deve permanecer a confirmar; se um relato oral puder identificar uma pessoa, deve ser anonimizado ou retirado da camada pública.

---

## Página 22 - 2. Oralidade como tecnologia social fora do método científico estrito


Em narrativas de aparição, monstros, mulheres liminares, santos, lobos, frades, rios, grutas e ventos, a comunidade cria gramáticas para o que não é facilmente redutível a causa objectiva. Uma criança que não deve sair à noite, um pastor que deve respeitar a serra, uma mulher que ocupa a margem, uma família que teme a pobreza, uma aldeia que precisa rir do poder religioso: tudo isto pode aparecer como figura fantástica.

Assim, o fantástico não é fuga da realidade. É método popular de ensinar relações sociais complexas por imagem, voz e medo. A figura fantástica desloca o conhecimento para um corpo memorável. A Coca, a Moura, o Trasgo ou a Pieira não precisam ser lidos como seres empiricamente demonstráveis; podem ser lidos como dispositivos narrativos que condensam ecologia, género, autoridade, limiar, perigo e imaginação.

A aplicação directa desta página ao corpus exige que cada entrada mantenha descrição de aparição, toponímia, fonte ou estado de fonte, dimensão interpretativa e bloqueio de publicabilidade. Quando a entrada falar de tradição oral, deve falar de modo situado e prudente. Quando falar de leitura contemporânea, deve marcar que se trata de reinterpretação institucional e não de facto histórico fechado. Quando falar de território, deve evitar coordenadas ou delimitações oficiais sem confirmação.

A auditoria jurídica e legislativa exige linguagem não absolutizante; a auditoria académica exige distinção de evidência; a auditoria política exige não instrumentalização partidária; a auditoria económica exige clareza de valor público; a interoperabilidade exige campos estáveis; a financiabilidade exige método, não apenas densidade literária. A entrada só é robusta quando estes eixos operam simultaneamente.

Esta página deve ser usada como critério prático de revisão: se uma afirmação não indicar o seu estatuto, deve ser reescrita; se uma hipótese soar como prova, deve ser marcada; se uma figura puder activar violência simbólica, deve ser contextualizada; se uma fonte estiver indicada sem confirmação, deve permanecer a confirmar; se um relato oral puder identificar uma pessoa, deve ser anonimizado ou retirado da camada pública.

---

## Página 23 - 3. Metodologias etnológicas e folclóricas aplicadas


O método deve combinar catálogo e interpretação. O catálogo garante interoperabilidade; a interpretação garante inteligência cultural. O erro seria ter apenas catálogo, produzindo uma lista morta, ou apenas interpretação, produzindo ensaio sem rastreabilidade. A metodologia robusta exige os dois: campo estruturado e leitura crítica.

A entrada deve conter, no mínimo, descrição simbólica e narrativa, contexto histórico-social, toponímia e variantes locais, fontes e estado de confirmação, síntese interpretativa, leitura contemporânea e bloqueio RGPD. Esta estrutura permite que o corpus seja citado, auditado, expandido, convertido em CSV/JSON e transportado para Zenodo sem perder o estado editorial.

A aplicação directa desta página ao corpus exige que cada entrada mantenha descrição de aparição, toponímia, fonte ou estado de fonte, dimensão interpretativa e bloqueio de publicabilidade. Quando a entrada falar de tradição oral, deve falar de modo situado e prudente. Quando falar de leitura contemporânea, deve marcar que se trata de reinterpretação institucional e não de facto histórico fechado. Quando falar de território, deve evitar coordenadas ou delimitações oficiais sem confirmação.

A auditoria jurídica e legislativa exige linguagem não absolutizante; a auditoria académica exige distinção de evidência; a auditoria política exige não instrumentalização partidária; a auditoria económica exige clareza de valor público; a interoperabilidade exige campos estáveis; a financiabilidade exige método, não apenas densidade literária. A entrada só é robusta quando estes eixos operam simultaneamente.

Esta página deve ser usada como critério prático de revisão: se uma afirmação não indicar o seu estatuto, deve ser reescrita; se uma hipótese soar como prova, deve ser marcada; se uma figura puder activar violência simbólica, deve ser contextualizada; se uma fonte estiver indicada sem confirmação, deve permanecer a confirmar; se um relato oral puder identificar uma pessoa, deve ser anonimizado ou retirado da camada pública.

---

## Página 24 - 4. Identidade, imaginário e construção narrativa


A identidade torna-se problemática quando signos populares são usados como ditames partidários, como ornamento nacionalista, como exotização rural, como folclore domesticado para turismo ou como instrumento de opressão minoritária. O método MILK deve identificar estes usos e recusar a publicação acrítica.

A figura folclórica é, portanto, um operador de identidade em disputa. Ela pode ser usada para fechar comunidade ou para abri-la; para humilhar diferença ou para reconhecer pluralidade; para congelar tradição ou para devolver movimento ao território. A metodologia deve documentar este risco em cada entrada.

A aplicação directa desta página ao corpus exige que cada entrada mantenha descrição de aparição, toponímia, fonte ou estado de fonte, dimensão interpretativa e bloqueio de publicabilidade. Quando a entrada falar de tradição oral, deve falar de modo situado e prudente. Quando falar de leitura contemporânea, deve marcar que se trata de reinterpretação institucional e não de facto histórico fechado. Quando falar de território, deve evitar coordenadas ou delimitações oficiais sem confirmação.

A auditoria jurídica e legislativa exige linguagem não absolutizante; a auditoria académica exige distinção de evidência; a auditoria política exige não instrumentalização partidária; a auditoria económica exige clareza de valor público; a interoperabilidade exige campos estáveis; a financiabilidade exige método, não apenas densidade literária. A entrada só é robusta quando estes eixos operam simultaneamente.

Esta página deve ser usada como critério prático de revisão: se uma afirmação não indicar o seu estatuto, deve ser reescrita; se uma hipótese soar como prova, deve ser marcada; se uma figura puder activar violência simbólica, deve ser contextualizada; se uma fonte estiver indicada sem confirmação, deve permanecer a confirmar; se um relato oral puder identificar uma pessoa, deve ser anonimizado ou retirado da camada pública.

---

## Página 25 - 5. Antietnocentrismo, difusionismo cultural e teste Nacirema


O teste Nacirema deve ser aplicado a cada entrada por pergunta simples: se esta narrativa fosse descrita sobre uma sociedade distante, que preconceito apareceria na descrição? Se fosse sobre a nossa própria vida urbana, que equivalência se tornaria visível? Esta reversibilidade impede etnocentrismo e aumenta a qualidade institucional.

A leitura antietnocêntrica obriga a suspender a superioridade implícita do observador. O texto dos Nacirema de Horace Miner funciona como teste metodológico porque mostra que a descrição etnográfica pode tornar estranho aquilo que para um grupo é quotidiano. A metodologia MILK deve usar esse teste para impedir exotização das aldeias, da religiosidade popular, das práticas rurais, dos medos infantis e das formas de nomear o invisível.

A aplicação directa desta página ao corpus exige que cada entrada mantenha descrição de aparição, toponímia, fonte ou estado de fonte, dimensão interpretativa e bloqueio de publicabilidade. Quando a entrada falar de tradição oral, deve falar de modo situado e prudente. Quando falar de leitura contemporânea, deve marcar que se trata de reinterpretação institucional e não de facto histórico fechado. Quando falar de território, deve evitar coordenadas ou delimitações oficiais sem confirmação.

A auditoria jurídica e legislativa exige linguagem não absolutizante; a auditoria académica exige distinção de evidência; a auditoria política exige não instrumentalização partidária; a auditoria económica exige clareza de valor público; a interoperabilidade exige campos estáveis; a financiabilidade exige método, não apenas densidade literária. A entrada só é robusta quando estes eixos operam simultaneamente.

Esta página deve ser usada como critério prático de revisão: se uma afirmação não indicar o seu estatuto, deve ser reescrita; se uma hipótese soar como prova, deve ser marcada; se uma figura puder activar violência simbólica, deve ser contextualizada; se uma fonte estiver indicada sem confirmação, deve permanecer a confirmar; se um relato oral puder identificar uma pessoa, deve ser anonimizado ou retirado da camada pública.

---

## Página 26 - 6. Ressignificação de signos e não violência simbólica


A reinterpretação contemporânea tem uma intencionalidade explícita: impedir que signos populares sejam repetidos como instrumentos de opressão minoritária. Isto não significa censurar o corpus. Significa marcar a diferença entre documento histórico, uso social passado, dano potencial presente e possibilidade de reinscrição ética.

Signos de bruxaria, monstruosidade, deformidade, raça, animalidade, impureza, desvio religioso, loucura, feminilidade perigosa ou infância ameaçada podem carregar camadas de violência simbólica. A entrada deve perguntar: quem foi historicamente colocado no lugar do monstro? Quem foi disciplinado pelo medo? Que corpo foi tornado suspeito? Que comunidade foi nomeada como ameaça?

A aplicação directa desta página ao corpus exige que cada entrada mantenha descrição de aparição, toponímia, fonte ou estado de fonte, dimensão interpretativa e bloqueio de publicabilidade. Quando a entrada falar de tradição oral, deve falar de modo situado e prudente. Quando falar de leitura contemporânea, deve marcar que se trata de reinterpretação institucional e não de facto histórico fechado. Quando falar de território, deve evitar coordenadas ou delimitações oficiais sem confirmação.

A auditoria jurídica e legislativa exige linguagem não absolutizante; a auditoria académica exige distinção de evidência; a auditoria política exige não instrumentalização partidária; a auditoria económica exige clareza de valor público; a interoperabilidade exige campos estáveis; a financiabilidade exige método, não apenas densidade literária. A entrada só é robusta quando estes eixos operam simultaneamente.

Esta página deve ser usada como critério prático de revisão: se uma afirmação não indicar o seu estatuto, deve ser reescrita; se uma hipótese soar como prova, deve ser marcada; se uma figura puder activar violência simbólica, deve ser contextualizada; se uma fonte estiver indicada sem confirmação, deve permanecer a confirmar; se um relato oral puder identificar uma pessoa, deve ser anonimizado ou retirado da camada pública.

---

## Página 27 - 7. Campo, documento, oralidade e cadeia de evidência


Cada entrada deve indicar se trabalha com fonte confirmada, fonte a confirmar, tradição oral de campo, hipótese interpretativa, desdobramento artístico ou material reservado. Sem esta marcação, o texto perde força académica e aumenta risco jurídico.

A pesquisa de campo deve ser descrita sem expor pessoas. Relatos orais podem sustentar a existência de circulação narrativa, mas não devem publicar nome, morada, contacto, voz, imagem ou identificação indirecta sem autorização. Quando não houver consentimento formal, a forma pública deve ser agregada: 'relatos orais de pesquisa de campo indicam', 'circulação narrativa local aponta', 'variante recolhida em contexto de campo permanece em revisão'.

A aplicação directa desta página ao corpus exige que cada entrada mantenha descrição de aparição, toponímia, fonte ou estado de fonte, dimensão interpretativa e bloqueio de publicabilidade. Quando a entrada falar de tradição oral, deve falar de modo situado e prudente. Quando falar de leitura contemporânea, deve marcar que se trata de reinterpretação institucional e não de facto histórico fechado. Quando falar de território, deve evitar coordenadas ou delimitações oficiais sem confirmação.

A auditoria jurídica e legislativa exige linguagem não absolutizante; a auditoria académica exige distinção de evidência; a auditoria política exige não instrumentalização partidária; a auditoria económica exige clareza de valor público; a interoperabilidade exige campos estáveis; a financiabilidade exige método, não apenas densidade literária. A entrada só é robusta quando estes eixos operam simultaneamente.

Esta página deve ser usada como critério prático de revisão: se uma afirmação não indicar o seu estatuto, deve ser reescrita; se uma hipótese soar como prova, deve ser marcada; se uma figura puder activar violência simbólica, deve ser contextualizada; se uma fonte estiver indicada sem confirmação, deve permanecer a confirmar; se um relato oral puder identificar uma pessoa, deve ser anonimizado ou retirado da camada pública.

---

## Página 28 - 8. Interoperabilidade, metadados e financiabilidade


A financiabilidade depende de demonstrar que o corpus não é improviso. O método deve mostrar objectivo público, estrutura de governança, proteção de dados, ligação territorial, potencial educativo, compatibilidade com património cultural imaterial, acessibilidade, documentação aberta controlada e capacidade de avaliação.

A legislação cultural e patrimonial exige prudência: uma associação não deve apresentar-se como autoridade pública de inventário oficial se não o é. Pode, contudo, apresentar-se como produtora de investigação cultural, mediação pública, documentação de campo, leitura crítica e preparação de materiais para diálogo institucional.

A aplicação directa desta página ao corpus exige que cada entrada mantenha descrição de aparição, toponímia, fonte ou estado de fonte, dimensão interpretativa e bloqueio de publicabilidade. Quando a entrada falar de tradição oral, deve falar de modo situado e prudente. Quando falar de leitura contemporânea, deve marcar que se trata de reinterpretação institucional e não de facto histórico fechado. Quando falar de território, deve evitar coordenadas ou delimitações oficiais sem confirmação.

A auditoria jurídica e legislativa exige linguagem não absolutizante; a auditoria académica exige distinção de evidência; a auditoria política exige não instrumentalização partidária; a auditoria económica exige clareza de valor público; a interoperabilidade exige campos estáveis; a financiabilidade exige método, não apenas densidade literária. A entrada só é robusta quando estes eixos operam simultaneamente.

Esta página deve ser usada como critério prático de revisão: se uma afirmação não indicar o seu estatuto, deve ser reescrita; se uma hipótese soar como prova, deve ser marcada; se uma figura puder activar violência simbólica, deve ser contextualizada; se uma fonte estiver indicada sem confirmação, deve permanecer a confirmar; se um relato oral puder identificar uma pessoa, deve ser anonimizado ou retirado da camada pública.

---

## Página 29 - 9. Protocolo metodológico MILK em operações


A operação 2 é separação de regimes: documento, oralidade, território, interpretação, desdobramento artístico e validação. Nenhum regime pode ocupar o lugar do outro sem marcação.

A operação 3 é leitura etnológica: identificar função social, contexto de transmissão, uso pedagógico, grupo afectado, lugar de circulação e variação.

A aplicação directa desta página ao corpus exige que cada entrada mantenha descrição de aparição, toponímia, fonte ou estado de fonte, dimensão interpretativa e bloqueio de publicabilidade. Quando a entrada falar de tradição oral, deve falar de modo situado e prudente. Quando falar de leitura contemporânea, deve marcar que se trata de reinterpretação institucional e não de facto histórico fechado. Quando falar de território, deve evitar coordenadas ou delimitações oficiais sem confirmação.

A auditoria jurídica e legislativa exige linguagem não absolutizante; a auditoria académica exige distinção de evidência; a auditoria política exige não instrumentalização partidária; a auditoria económica exige clareza de valor público; a interoperabilidade exige campos estáveis; a financiabilidade exige método, não apenas densidade literária. A entrada só é robusta quando estes eixos operam simultaneamente.

Esta página deve ser usada como critério prático de revisão: se uma afirmação não indicar o seu estatuto, deve ser reescrita; se uma hipótese soar como prova, deve ser marcada; se uma figura puder activar violência simbólica, deve ser contextualizada; se uma fonte estiver indicada sem confirmação, deve permanecer a confirmar; se um relato oral puder identificar uma pessoa, deve ser anonimizado ou retirado da camada pública.

---

## Página 30 - 10. Texto inicial canónico para o corpus


Por fim, deve manter a marca de revisão: o corpus é aberto para leitura e auditoria, mas permanece revisável. A revisabilidade é uma força metodológica, não uma fragilidade.

Formulação canónica recomendada para abertura do corpus: 'Este corpus integra entradas resultantes de pesquisa documental, análise comparada de fontes públicas, sistematização de tradição oral, relatos orais de pesquisa de campo e revisão semântica conduzidas no âmbito do Folclore Vivo da Associação MILK - Movimento de Intervenções e Linguagens Kulturais e Arte. As entradas são publicadas como corpus de investigação cultural em revisão pública, com distinção entre fonte, território, interpretação, direitos, dados sensíveis e estado de validação. Nenhuma entrada deve ser lida como prova histórica definitiva, inventário patrimonial oficial, validação etnográfica concluída ou certificação académica externa sem verificação documental própria.'

A aplicação directa desta página ao corpus exige que cada entrada mantenha descrição de aparição, toponímia, fonte ou estado de fonte, dimensão interpretativa e bloqueio de publicabilidade. Quando a entrada falar de tradição oral, deve falar de modo situado e prudente. Quando falar de leitura contemporânea, deve marcar que se trata de reinterpretação institucional e não de facto histórico fechado. Quando falar de território, deve evitar coordenadas ou delimitações oficiais sem confirmação.

A auditoria jurídica e legislativa exige linguagem não absolutizante; a auditoria académica exige distinção de evidência; a auditoria política exige não instrumentalização partidária; a auditoria económica exige clareza de valor público; a interoperabilidade exige campos estáveis; a financiabilidade exige método, não apenas densidade literária. A entrada só é robusta quando estes eixos operam simultaneamente.

Esta página deve ser usada como critério prático de revisão: se uma afirmação não indicar o seu estatuto, deve ser reescrita; se uma hipótese soar como prova, deve ser marcada; se uma figura puder activar violência simbólica, deve ser contextualizada; se uma fonte estiver indicada sem confirmação, deve permanecer a confirmar; se um relato oral puder identificar uma pessoa, deve ser anonimizado ou retirado da camada pública.

---

## Bibliografia e ancoragem operacional mínima

A metodologia articula antropologia da cultura, estudos de folclore, história oral, investigação-acção participativa, pesquisa comunitária, estudos de património imaterial, semiótica, teoria crítica, pedagogia crítica, metodologia qualitativa, ética de dados e interoperabilidade cultural. As referências operacionais incluem UNESCO e património cultural imaterial; Oral History Association e ética da história oral; American Folklore Society e folclorística pública; Horace Miner e o teste Nacirema; Laraia e difusionismo/cultura; Mead, Gluckman, Bourdieu, Adorno, Habermas, Merleau-Ponty, Paulo Freire, Orlando Fals Borda, Grounded Theory, Constant Comparative Method, Data Feminism, Cultural Probes, interseccionalidade, semiótica, Barthes, Kandinsky, Deleuze, Hume, Meister Eckhart e Llansol.

## Texto inicial canónico para inserir no corpus

Este corpus integra entradas resultantes de pesquisa documental, análise comparada de fontes públicas, sistematização de tradição oral, relatos orais de pesquisa de campo e revisão semântica conduzidas no âmbito do Folclore Vivo da Associação MILK - Movimento de Intervenções e Linguagens Kulturais e Arte. As entradas são publicadas como corpus de investigação cultural em revisão pública, com distinção entre fonte, território, interpretação, direitos, dados sensíveis e estado de validação. Nenhuma entrada deve ser lida como prova histórica definitiva, inventário patrimonial oficial, validação etnográfica concluída ou certificação académica externa sem verificação documental própria.
