# Relatório de normalização — toponímia e aparição

## Resultado

Foram normalizadas as 3 entradas que tinham toponímia no corpo do texto, mas não apresentavam bloco final padronizado de localização específica.

## Entradas normalizadas

- 020 — Lenda do Mosteiro de Ermelo (Alto Minho, concelho de Arcos de Valdevez) — `regioes/norte/corpus-integral-auditado/020-lenda-do-mosteiro-de-ermelo-alto-minho-concelho-de-arcos-de-valdevez.md`
- 137 — A Lenda da Voz da Fraga de Alvadia (Alta Montanha de Boticas – Barroso) — `regioes/norte/corpus-integral-auditado/137-a-lenda-da-voz-da-fraga-de-alvadia-alta-montanha-de-boticas-barroso.md`
- 138 — A Lenda da Sombra do Cavaleiro da Portela de Samão  (Montalegre – Serra do Larouco) — `regioes/norte/corpus-integral-auditado/138-a-lenda-da-sombra-do-cavaleiro-da-portela-de-samao-montalegre-serra-do-larouco.md`

## Critério de não invenção

A normalização não acrescentou freguesia, concelho, distrito, coordenada, fonte externa ou afirmação territorial nova. O bloco inserido usa apenas o título/corpo da própria entrada e marca a delimitação administrativa como “a confirmar em revisão documental e humana”.

## Estado após correção

- Descrição simbólica e narrativa: 138/138.
- Toponímia e variantes locais: 138/138.
- Características físicas, forma de aparição ou modo de manifestação: 138/138.
- Localização específica final ou bloco editorial normalizado: 138/138.

## Uso GitHub / Zenodo

O pacote pode ser carregado no GitHub antes da release Zenodo. A publicação Zenodo só deve ocorrer depois de confirmada a presença de todas as entradas e do CSV de auditoria normalizada no repositório.


## Correção da nota de origem

A formulação pública foi corrigida para eliminar qualquer referência a “PDF enviado pelo utilizador”, “ficheiro anexado” ou equivalente. A origem pública passa a ser descrita como pesquisa documental, análise comparada de fontes públicas, sistematização de tradição oral e relatos orais de pesquisa de campo conduzidos no âmbito do Folclore Vivo MILK.
