# Relatório de auditoria e incorporação — corpus integral

Documento de origem: `folclore português (1).pdf`.

## Resultado técnico

- Páginas do PDF: 422.
- Entradas detectadas e preparadas: 138.
- Numeração: 001 a 138, sem lacunas após reconstrução de títulos quebrados por extração.
- Formato de saída: Markdown + CSV.
- Diretório de destino: `regioes/norte/corpus-integral-auditado/`.

## Critério de não invenção

As entradas foram extraídas do documento fornecido. Não foram criadas novas lendas, não foram acrescentadas fontes externas e não foram completadas lacunas com conteúdo inventado.

## Readequação semântica aplicada

A readequação foi feita por cabeçalho editorial e jurídico, não por reescrita do corpo narrativo. Isto preserva o texto-base e impede alteração indevida da prova documental.

## Eixos auditados

1. Jurídico/RGPD: exclusão de estatuto de consentimento automático; alerta para dados pessoais e material comunitário.
2. Académico: distinção entre corpus em revisão, hipótese, fonte e validação.
3. Interoperabilidade: Markdown, slugs estáveis, CSV, rastreabilidade.
4. Financiabilidade: uso institucional possível apenas com estado editorial explícito.
5. Legislativo/político-económico: evita transformar corpus cultural em prova oficial sem verificação.
6. Anti-discriminação: uso público exige revisão contra violência religiosa, racial, étnica, de género, classe e território.
7. Não regressão: cada entrada traz aviso de não apresentação como versão final.

## Próximo passo obrigatório antes de Zenodo

Confirmar que este diretório entrou no repositório e que a release Zenodo aponta para o commit que contém estes ficheiros.
